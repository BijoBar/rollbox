import { useSyncExternalStore } from "react";

const emptySubscribe = () => () => {};
const clientTrue = () => true;
const serverFalse = () => false;

/** SSR-safe "is client mounted" flag without setState-in-effect. */
export function useMounted(): boolean {
  return useSyncExternalStore(emptySubscribe, clientTrue, serverFalse);
}
