"use client";

// QOL (Task 167): the public GIVEAWAYS page — active pots with a live
// countdown and a one-click JOIN, plus the winners wall. The server lazily
// draws every pot the first time the list is read after its deadline, so a
// prize never waits for the admin to click.
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Gift, Sparkles, Trophy, Users } from "lucide-react";
import { useSession } from "@/lib/session";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";

interface ActiveGw {
  id: string;
  title: string;
  prizeCoins: number;
  prizeLabel: string | null;
  winnerCount: number;
  endsAt: number;
  entries: number;
  entered: boolean;
}
interface DrawnGw {
  id: string;
  title: string;
  prizeCoins: number;
  prizeLabel: string | null;
  endsAt: number;
  winners: { playerId: string; name: string }[];
}

const pad = (n: number) => String(n).padStart(2, "0");
const parts = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  return { d: Math.floor(s / 86400), h: Math.floor((s % 86400) / 3600), m: Math.floor((s % 3600) / 60), s: s % 60 };
};

export function GiveawaysView() {
  const mounted = useMounted();
  const { player: me } = useSession();
  const { toast } = useToast();
  const [active, setActive] = useState<ActiveGw[]>([]);
  const [recent, setRecent] = useState<DrawnGw[]>([]);
  const [signedIn, setSignedIn] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/giveaways", { cache: "no-store" });
      if (!r.ok) return;
      const d = (await r.json()) as { active: ActiveGw[]; recent: DrawnGw[]; signedIn: boolean };
      setActive(d.active ?? []);
      setRecent(d.recent ?? []);
      setSignedIn(d.signedIn);
    } catch {
      /* cosmetic */
    }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(() => {
      setTick((k) => k + 1);
      void load();
    }, 15000);
    return () => window.clearInterval(t);
  }, [load]);

  const join = async (id: string, title: string) => {
    if (!me) {
      toast({ title: "Sign in with Steam to join the giveaway" });
      return;
    }
    setBusy(id);
    try {
      const r = await fetch(`/api/giveaways/${id}/join`, { method: "POST" });
      const d = (await r.json()) as { ok?: boolean; error?: string };
      if (!r.ok || !d.ok) throw new Error(d.error ?? "Failed");
      sfx.coins();
      toast({ title: `You're in — good luck at "${title}"` });
      void load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed to join" });
    } finally {
      setBusy(null);
    }
  };

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-10" aria-label="Giveaways">
        <div className="mx-auto max-w-3xl px-4">
          <div className="text-center">
            <p className="font-display flex items-center justify-center gap-2 text-[11px] font-black uppercase tracking-[0.35em] text-fuchsia-300">
              <Sparkles className="h-4 w-4" /> Free to join
            </p>
            <h1 className="font-display mt-2 text-4xl font-black tracking-wide text-white sm:text-5xl">
              GIVE<span className="text-gradient-neon">AWAYS</span>
            </h1>
            <p className="mx-auto mt-3 max-w-md text-sm font-semibold leading-relaxed text-white/50">
              The admin posts a prize pot, you hit JOIN — one entry each, winners drawn at the deadline and paid straight
              to the balance.
            </p>
          </div>

          {/* active pots */}
          {mounted && active.length === 0 ? (
            <div className="mt-10 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-14 text-center">
              <Gift className="mx-auto mb-3 h-12 w-12 text-white/20" />
              <p className="text-sm font-bold text-white/60">No giveaway is running right now</p>
              <p className="mt-1 text-xs text-white/35">Watch the site banner — the next pot can drop any time.</p>
            </div>
          ) : (
            <ul className="mt-10 space-y-3">
              {active.map((g) => {
                const t = parts(g.endsAt - Date.now()); // tick drives re-render
                void tick;
                return (
                  <li key={g.id} className="rounded-2xl border border-fuchsia-400/20 bg-black/40 p-5 shadow-[0_0_30px_rgba(217,70,239,0.07)]">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-lg font-black text-white">{g.title}</h2>
                      {g.prizeLabel && (
                        <span className="rounded-full bg-fuchsia-500/20 px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider text-fuchsia-200">
                          {g.prizeLabel}
                        </span>
                      )}
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5">
                      <span className="flex items-center gap-1.5 text-base font-black text-amber-300">
                        <Coin className="h-4 w-4" /> {g.prizeCoins}
                      </span>
                      <span className="flex items-center gap-1 text-xs font-bold text-white/50">
                        <Users className="h-3.5 w-3.5" /> {g.entries} joined
                      </span>
                      <span className="text-xs font-bold text-white/50">
                        {g.winnerCount > 1 ? `${g.winnerCount} winners` : "1 winner"}
                      </span>
                      <span className="ml-auto font-mono text-xs font-black tracking-widest text-fuchsia-300" suppressHydrationWarning>
                        {t.d > 0 ? `${t.d}d ` : ""}{pad(t.h)}:{pad(t.m)}:{pad(t.s)}
                      </span>
                    </div>
                    <button
                      type="button"
                      disabled={busy === g.id || g.entered}
                      onClick={() => void join(g.id, g.title)}
                      className={cn(
                        "mt-4 w-full rounded-xl border py-3 text-xs font-black uppercase tracking-widest transition-all",
                        g.entered
                          ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-200"
                          : "border-fuchsia-400/50 bg-fuchsia-500/20 text-white hover:bg-fuchsia-500/30 disabled:opacity-40",
                      )}
                    >
                      {g.entered ? "You're in — good luck" : busy === g.id ? "Joining…" : "Join the giveaway"}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}

          {/* winners wall */}
          {recent.length > 0 && (
            <div className="mt-12">
              <h2 className="font-display flex items-center gap-2 text-sm font-black uppercase tracking-[0.3em] text-white/60">
                <Trophy className="h-4 w-4 text-amber-300" /> Winners wall
              </h2>
              <ul className="mt-4 space-y-2">
                {recent.map((g) => (
                  <li key={g.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-xs">
                    <span className="font-bold text-white/80">{g.title}</span>
                    <span className="flex items-center gap-1 font-black text-amber-300/90">
                      <Coin className="h-3 w-3" /> {g.prizeCoins}
                    </span>
                    <span className="ml-auto text-white/60">
                      Won by <span className="font-bold text-amber-200">{g.winners.map((w) => w.name).join(", ") || "—"}</span>
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {!signedIn && (
            <p className="mt-8 text-center text-xs text-white/35">
              <Link href="/login" className="font-bold text-amber-300 hover:underline">
                Sign in with Steam
              </Link>{" "}
              to join the next pot.
            </p>
          )}
        </div>
      </main>
    </SiteShell>
  );
}
