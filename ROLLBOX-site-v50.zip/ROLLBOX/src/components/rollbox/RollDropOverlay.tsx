"use client";

import { useEffect } from "react";
import { formatCoins } from "@/lib/cases";
import { sfx } from "@/lib/sound";
import { Coin } from "./Coin";

/**
 * USER SPEC (Task 44): the ROLLDROP celebration — a full-screen overlay with
 * the raredrop.png art, shown when the ultra-rare bonus hits (case openings
 * AND battles). Click anywhere to dismiss; auto-dismisses after 4.5s.
 */
export function RollDropOverlay({ reward, onDone }: { reward: number; onDone: () => void }) {
  useEffect(() => {
    sfx.win(true);
    sfx.coins();
    const t = window.setTimeout(onDone, 4500);
    return () => window.clearTimeout(t);
  }, [onDone]);

  return (
    <div
      className="fixed inset-0 z-[70] grid place-items-center bg-black/75 backdrop-blur-sm"
      role="alertdialog"
      aria-label={`ROLLDROP — bonus of ${reward} coins`}
      onClick={onDone}
    >
      <div className="anim-pop-in relative flex flex-col items-center gap-3 rounded-3xl border-2 border-amber-300/60 bg-[#150e26]/95 px-10 py-8 text-center shadow-[0_0_80px_rgba(240,185,11,0.45)]">
        {/* rays behind the art */}
        <div
          className="pointer-events-none absolute inset-0 rounded-3xl"
          style={{
            background:
              "radial-gradient(circle at 50% 38%, rgba(240,185,11,0.28), transparent 62%)",
          }}
          aria-hidden="true"
        />
        <img
          src="/raredrop.png"
          alt="ROLLDROP"
          className="relative h-44 w-44 animate-pulse object-contain drop-shadow-[0_0_36px_rgba(240,185,11,0.8)] sm:h-52 sm:w-52"
          draggable={false}
        />
        <p className="font-display relative bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 bg-clip-text text-4xl font-black tracking-[0.18em] text-transparent drop-shadow-[0_0_26px_rgba(240,185,11,0.65)] sm:text-5xl">
          ROLLDROP!
        </p>
        <p className="relative text-xs font-black uppercase tracking-[0.3em] text-amber-300/80">
          Ultra-rare bonus drop
        </p>
        <p
          className="font-display relative rounded-xl border border-amber-400/40 bg-amber-400/15 px-5 py-2 text-2xl font-black text-amber-300 sm:text-3xl"
          title="Credited straight to your balance"
        >
          +<Coin /> {formatCoins(reward)}
        </p>
        <p className="relative text-[11px] font-semibold text-white/45">
          Credited straight to your balance • tap anywhere to continue
        </p>
      </div>
    </div>
  );
}
