"use client";

// SECURITY (Task 167): the admin panel's SECURITY tab — TOTP two-factor
// management + the append-only audit trail of every admin action.
import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Copy, KeyRound, Lock, ShieldCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";

interface AuditRow {
  id: number;
  adminId: string;
  adminName: string;
  action: string;
  target: string | null;
  meta: string | null;
  createdAt: string;
}

export function AdminSecurityTab() {
  const { toast } = useToast();
  const [st, setSt] = useState<{ configured: boolean; enabled: boolean; unlocked: boolean } | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [uri, setUri] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  const loadStatus = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/2fa", { cache: "no-store" });
      if (r.ok) setSt((await r.json()) as { configured: boolean; enabled: boolean; unlocked: boolean });
    } catch {
      /* cosmetic */
    }
  }, []);

  const loadAudit = useCallback(async (p: number) => {
    try {
      const r = await fetch(`/api/admin/audit?page=${p}`, { cache: "no-store" });
      if (r.ok) {
        const d = (await r.json()) as { rows: AuditRow[]; page: number; pages: number };
        setRows(d.rows);
        setPage(d.page);
        setPages(d.pages);
      }
    } catch {
      /* cosmetic */
    }
  }, []);

  useEffect(() => {
    void loadStatus();
    void loadAudit(1);
  }, [loadStatus, loadAudit]);

  const post = async (body: Record<string, unknown>) => {
    setBusy(true);
    try {
      const r = await fetch("/api/admin/2fa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const d = (await r.json()) as { ok?: boolean; error?: string; secret?: string; uri?: string };
      if (!r.ok || (d.error && !d.ok)) throw new Error(d.error ?? "Failed");
      return d;
    } finally {
      setBusy(false);
    }
  };

  const begin = async () => {
    sfx.click();
    try {
      const d = await post({ action: "begin" });
      setSecret(d.secret ?? null);
      setUri(d.uri ?? null);
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed" });
    }
  };

  const confirm = async () => {
    try {
      await post({ action: "confirm", code });
      sfx.coins();
      toast({ title: "2FA is ON — every admin entry now needs the authenticator" });
      setSecret(null);
      setUri(null);
      setCode("");
      void loadStatus();
      void loadAudit(1);
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed" });
    }
  };

  const disable = async () => {
    try {
      await post({ action: "disable", code });
      toast({ title: "2FA disabled" });
      setCode("");
      void loadStatus();
      void loadAudit(1);
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed" });
    }
  };

  const copy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: `${label} copied` });
    } catch {
      toast({ title: "Copy failed — select it manually" });
    }
  };

  const fmt = (iso: string) => new Date(iso).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });

  return (
    <div className="mt-5 space-y-4">
      {/* 2FA card */}
      <div className="rounded-2xl border border-white/10 bg-black/40 p-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-emerald-400" />
          <h3 className="font-display text-sm font-black uppercase tracking-widest text-white">Two-factor authentication</h3>
          <span
            className={cn(
              "ml-auto rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-wider",
              st?.enabled ? "bg-emerald-500/20 text-emerald-300" : "bg-white/10 text-white/60",
            )}
          >
            {st === null ? "…" : st.enabled ? "ON" : "OFF"}
          </span>
        </div>

        {st?.enabled ? (
          <div className="mt-3 space-y-2">
            <p className="text-xs leading-relaxed text-white/50">
              The panel demands a fresh 6-digit authenticator code every 12 hours. Disabling needs one more correct code.
            </p>
            <div className="flex gap-2">
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                dir="ltr"
                inputMode="numeric"
                placeholder="000000"
                aria-label="Authenticator code to disable 2FA"
                className="w-28 rounded-lg border border-white/15 bg-black/50 px-3 py-2 text-center font-mono text-sm tracking-[0.3em] text-white focus:border-red-400/60 focus:outline-none"
              />
              <button
                type="button"
                disabled={busy || code.length !== 6}
                onClick={() => void disable()}
                className="rounded-lg border border-red-500/50 bg-red-500/15 px-4 text-xs font-black uppercase tracking-widest text-red-300 transition-colors hover:bg-red-500/25 disabled:opacity-40"
              >
                Disable
              </button>
            </div>
          </div>
        ) : secret ? (
          <div className="mt-3 space-y-3">
            <p className="text-xs leading-relaxed text-white/50">
              1. Add a token in your authenticator app (manual entry). 2. Paste the 6-digit code it shows. 3. Confirm.
            </p>
            <div className="rounded-xl border border-white/10 bg-black/60 p-3">
              <p className="text-[10px] font-black uppercase tracking-widest text-white/40">Secret (base32)</p>
              <div className="mt-1 flex items-center gap-2">
                <code dir="ltr" className="flex-1 break-all font-mono text-sm text-emerald-300">{secret}</code>
                <button type="button" onClick={() => void copy(secret, "Secret")} className="grid h-8 w-8 place-items-center rounded-lg border border-white/15 text-white/60 hover:text-white" aria-label="Copy the secret">
                  <Copy className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="mt-2 text-[10px] font-black uppercase tracking-widest text-white/40">URI</p>
              <div className="mt-1 flex items-center gap-2">
                <code dir="ltr" className="flex-1 truncate font-mono text-[11px] text-white/60">{uri}</code>
                <button type="button" onClick={() => void copy(uri ?? "", "URI")} className="grid h-8 w-8 place-items-center rounded-lg border border-white/15 text-white/60 hover:text-white" aria-label="Copy the otpauth URI">
                  <Copy className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
            <div className="flex gap-2">
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                dir="ltr"
                inputMode="numeric"
                placeholder="000000"
                aria-label="Authenticator code to confirm 2FA"
                className="w-28 rounded-lg border border-white/15 bg-black/50 px-3 py-2 text-center font-mono text-sm tracking-[0.3em] text-white focus:border-emerald-400/60 focus:outline-none"
              />
              <button
                type="button"
                disabled={busy || code.length !== 6}
                onClick={() => void confirm()}
                className="rounded-lg border border-emerald-400/50 bg-emerald-500/20 px-4 text-xs font-black uppercase tracking-widest text-emerald-200 transition-colors hover:bg-emerald-500/30 disabled:opacity-40"
              >
                Confirm & enable
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-3 space-y-2">
            <p className="text-xs leading-relaxed text-white/50">
              A stolen admin session can approve real-money deposits. With 2FA, signing in also needs the rotating code
              from your authenticator app — the session alone buys nothing.
            </p>
            <button
              type="button"
              onClick={() => void begin()}
              className="flex items-center gap-2 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-4 py-2 text-xs font-black uppercase tracking-widest text-emerald-200 transition-colors hover:bg-emerald-500/25"
            >
              <KeyRound className="h-4 w-4" />
              Enable 2FA
            </button>
          </div>
        )}
      </div>

      {/* audit trail */}
      <div className="rounded-2xl border border-white/10 bg-black/40 p-4">
        <div className="flex items-center gap-2">
          <Lock className="h-5 w-5 text-white/70" />
          <h3 className="font-display text-sm font-black uppercase tracking-widest text-white">Audit trail</h3>
          <span className="ml-auto text-[10px] font-black uppercase tracking-widest text-white/35">append-only</span>
        </div>
        {rows.length === 0 ? (
          <p className="mt-3 text-xs text-white/40">No admin actions recorded yet.</p>
        ) : (
          <>
            <ul className="mt-3 space-y-1.5" aria-label="Audit log">
              {rows.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center gap-x-2 gap-y-0.5 rounded-lg border border-white/5 bg-white/[0.03] px-3 py-2 text-xs">
                  <span className="font-mono text-[10px] text-white/35">{fmt(r.createdAt)}</span>
                  <span className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[10px] font-black text-white/80">{r.action}</span>
                  <span className="font-semibold text-white/70">{r.adminName}</span>
                  {r.target && <span className="font-mono text-[10px] text-white/40">→ {r.target}</span>}
                  {r.meta && <span className="w-full truncate text-[10px] text-white/35">{r.meta}</span>}
                </li>
              ))}
            </ul>
            <div className="mt-3 flex items-center justify-center gap-3">
              <button
                type="button"
                disabled={page <= 1}
                onClick={() => { sfx.click(); void loadAudit(page - 1); }}
                className="grid h-8 w-8 place-items-center rounded-lg border border-white/15 text-white/60 hover:text-white disabled:opacity-30"
                aria-label="Newer audit rows"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="text-[10px] font-black uppercase tracking-widest text-white/40">page {page}/{pages}</span>
              <button
                type="button"
                disabled={page >= pages}
                onClick={() => { sfx.click(); void loadAudit(page + 1); }}
                className="grid h-8 w-8 place-items-center rounded-lg border border-white/15 text-white/60 hover:text-white disabled:opacity-30"
                aria-label="Older audit rows"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
