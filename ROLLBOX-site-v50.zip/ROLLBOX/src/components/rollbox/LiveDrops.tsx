"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { DropChip } from "./SkinTile";
import { useRealtimeEvent } from "@/lib/realtime";

/** One drop as /api/live returns it — the SAME feed for every visitor. */
interface LiveDrop {
  id: number;
  user: string;
  provider: string | null;
  caseId: string;
  skinId: string;
  wear?: string | null;
  value: number;
  isRd: boolean;
  source: string;
  at: number;
}

/**
 * THE global live-drops feed — every solo opening and every battle pull, from
 * the database, identical for every visitor in the world. Polls every 2.5s;
 * new drops slide in, and when the site is quiet the feed just goes quiet.
 */
export function LiveDrops() {
  const [drops, setDrops] = useState<LiveDrop[]>([]);
  const keyRef = useRef(0);
  const lastIdRef = useRef(0);
  const freshRef = useRef<LiveDrop[]>([]);

  const ingest = useCallback((incoming: LiveDrop[]) => {
    if (!incoming.length) return;
    lastIdRef.current = Math.max(lastIdRef.current, ...incoming.map((d) => d.id));
    // newest first, cap the burst so a busy battle doesn't flood the bar
    keyRef.current += incoming.length;
    freshRef.current = [...incoming].reverse().slice(0, 6);
    setDrops((prev) => [...freshRef.current, ...prev].slice(0, 22));
  }, []);

  // REALTIME (Task 64): the server PUSHES every real player's drop the moment
  // it lands — this feed is identical on every screen at the same instant.
  useRealtimeEvent("drop", (data) => {
    const d = data as LiveDrop | null;
    if (d && typeof d.id === "number" && d.id > lastIdRef.current) ingest([d]);
  });

  useEffect(() => {
    let stop = false;
    const tick = async () => {
      try {
        const r = await fetch("/api/live", { cache: "no-store" });
        const data = (await r.json()) as { drops: LiveDrop[] };
        if (stop) return;
        const incoming = (data.drops ?? []).filter((d) => d.id > lastIdRef.current);
        if (incoming.length) {
          ingest(incoming);
        } else if (drops.length === 0 && (data.drops ?? []).length) {
          // first load — seed with the latest history
          lastIdRef.current = Math.max(...data.drops.map((d) => d.id));
          setDrops(data.drops.slice(0, 18));
        }
      } catch {
        /* retry on the next tick */
      }
    };
    void tick();
    const iv = window.setInterval(() => void tick(), 2500);
    return () => {
      stop = true;
      window.clearInterval(iv);
    };
  }, [ingest]);
  return (
    <section
      aria-label="Live drops feed"
      className="relative z-10 border-b border-white/10 bg-[#0d0819]/80"
    >
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
        <div className="flex shrink-0 items-center gap-2 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2">
          <span className="anim-live-dot h-2 w-2 rounded-full bg-rose-500" />
          <span className="font-display text-xs font-bold tracking-wider text-rose-300">
            LIVE DROPS
          </span>
        </div>
        <div className="relative flex-1 overflow-hidden" dir="ltr">
          {/* edge fades */}
          <div className="reel-fade-r pointer-events-none absolute inset-y-0 right-0 z-10 w-20" />
          <div className="reel-fade-l pointer-events-none absolute inset-y-0 left-0 z-10 w-20" />
          {/* USER SPEC (Task 32): the row grew ~35% (h-14 → h-19) so the skin
              images land bigger and clearer */}
          <div className="flex h-19 items-center gap-2.5 overflow-hidden">
            <AnimatePresence initial={false} mode="popLayout">
              {drops.length === 0 ? (
                <span className="whitespace-nowrap px-2 text-xs font-bold text-white/35">
                  No drops yet — open a case or start a battle and every player in the world sees it here.
                </span>
              ) : (
                drops.map((d) => (
                  <motion.div
                    key={d.id}
                    layout
                    initial={{ opacity: 0, x: 40, scale: 0.8 }}
                    animate={{ opacity: 1, x: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.7 }}
                    transition={{ type: "spring", stiffness: 320, damping: 30 }}
                  >
                    <DropChip skinId={d.skinId} user={d.user} wear={d.wear ?? undefined} />
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
