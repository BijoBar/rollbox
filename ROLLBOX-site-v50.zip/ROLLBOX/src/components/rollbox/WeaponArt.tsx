"use client";

import { useId } from "react";
import type { WeaponKind } from "@/lib/cases";

/**
 * Stylized side-view weapon silhouettes (muzzle pointing right),
 * filled with a per-skin gradient. ViewBox: 0 0 120 60.
 */
export function WeaponArt({
  kind,
  colors,
  className,
}: {
  kind: WeaponKind;
  colors: [string, string];
  className?: string;
}) {
  const gid = useId().replace(/:/g, "");
  const fill = `url(#w-${gid})`;
  const dark = "rgba(0,0,0,0.38)";

  return (
    <svg viewBox="0 0 120 60" className={className} role="img" aria-hidden="true">
      <defs>
        <linearGradient id={`w-${gid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={colors[0]} />
          <stop offset="55%" stopColor={colors[0]} />
          <stop offset="100%" stopColor={colors[1]} />
        </linearGradient>
      </defs>
      <g fill={fill} stroke={dark} strokeWidth="0.8" strokeLinejoin="round">
        {kind === "ak" && (
          <>
            <path d="M6 24 L26 21 L26 36 L12 39 L3 32 Z" />
            <path d="M26 21 H84 V34 H26 Z" />
            <path d="M66 18 H92 V22 H66 Z" />
            <path d="M84 25 H113 V29 H84 Z" />
            <path d="M101 16 H104.5 V25 H101 Z" />
            <path d="M59 17 H66 V21 H59 Z" />
            <path d="M34 34 L43 35 L39 49 L30 47 Z" />
            <path d="M48 34 C48 45 54 53 64 56 L75 52 C67 48 60 42 60 34 Z" />
          </>
        )}
        {kind === "m4" && (
          <>
            <path d="M8 23 H15 V38 H8 Z" />
            <path d="M15 26 H28 V33 H15 Z" />
            <path d="M28 23 H86 V33 H28 Z" />
            <path d="M46 16 H70 V21 H46 Z" />
            <path d="M90 14 L95 25 H86 Z" />
            <path d="M86 26 H113 V29.5 H86 Z" />
            <path d="M38 33 L46 34 L41.5 48 L34 46 Z" />
            <path d="M52 33 L63 34 L61 51 L51 49 Z" />
          </>
        )}
        {kind === "awp" && (
          <>
            <path d="M42 12 H78 Q81 12 81 15 V17 Q81 20 78 20 H42 Q39 20 39 17 V15 Q39 12 42 12 Z" />
            <path d="M48 20 V24 H53 V20 Z" />
            <path d="M68 20 V24 H73 V20 Z" />
            <path d="M8 21 H26 V25 H8 Z" />
            <path d="M26 23 H88 V33 H26 Z" />
            <path d="M26 23 L11 22 L4 33 L9 42 L21 41 L26 33 Z" />
            <circle cx="14" cy="32" r="3" fill="#0b0714" stroke="none" />
            <path d="M88 26 H115 V29.5 H88 Z" />
            <path d="M56 33 H69 V42 L56 43 Z" />
            <path d="M44 33 L52 34 L48 47 L41 45 Z" />
            <path d="M70 28 L79 30.5 L78 33.5 L69 31 Z" />
          </>
        )}
        {kind === "galil" && (
          <>
            <path d="M6 22 H24 V27 H11 V33 H24 V38 H6 Z" />
            <path d="M24 22 H82 V34 H24 Z" />
            <path d="M38 16 H62 V20 H38 Z" />
            <path d="M82 26 H110 V29.5 H82 Z" />
            <path d="M99 17 H102.5 V26 H99 Z" />
            <path d="M32 34 L40 35 L36 48 L28 46 Z" />
            <path d="M48 34 C48 43 52 49 60 52 L69 49 C62 46 58 41 58 34 Z" />
          </>
        )}
        {kind === "p90" && (
          <>
            <path d="M36 8 H74 L70 14 H40 Z" />
            <path d="M22 20 C22 15 29 12 37 12 H84 C96 12 103 17 103 25 V30 C103 35 98 38.5 91 38.5 H32 C25 38.5 22 33 22 28 Z" />
            <path d="M103 24 H115 V28 H103 Z" />
            <path d="M50 38 C50 46 56 51 63 51 C69 51 72 46 70 38 Z" />
            <circle cx="60" cy="43" r="1.6" fill="#0b0714" stroke="none" />
          </>
        )}
        {kind === "mp9" && (
          <>
            <path d="M20 24 H28 V32 H20 Z" />
            <path d="M30 17 H62 V22 H30 Z" />
            <path d="M28 21 H86 V34 H28 Z" />
            <path d="M86 26 H99 V30 H86 Z" />
            <path d="M40 34 L50 35 L48 53 L38 52 Z" />
            <path d="M63 34 L71 35 L69 46 L61 45 Z" />
          </>
        )}
        {kind === "deagle" && (
          <>
            <path d="M94 13 H104 V17 H94 Z" />
            <path d="M30 16 H104 Q107 16 107 19 V25 Q107 28 104 28 H30 Q27 28 27 25 V19 Q27 16 30 16 Z" />
            <path d="M33 28 H93 V33 H33 Z" />
            <path d="M34 33 L49 34 L43 53 L28 50 Z" />
            <path d="M52 33 H57 V38 H65 V33 H70 V42 H57 L52 42 Z" />
            <path d="M58 33.5 H62 L61 39 L58.5 38 Z" />
          </>
        )}
        {kind === "glock" && (
          <>
            <path d="M32 18 H102 Q105 18 105 21 V24 Q105 27 102 27 H32 Q29 27 29 24 V21 Q29 18 32 18 Z" />
            <path d="M36 27 H94 V32 H36 Z" />
            <path d="M38 32 L53 33 L47 53 L33 51 Z" />
            <path d="M55 32 H60 V37 H67 V32 H72 V41 H60 L55 41 Z" />
          </>
        )}
        {kind === "usp" && (
          <>
            <path d="M84 16 H106 Q112 16 112 21.5 Q112 27 106 27 H84 Z" />
            <path d="M28 18 H84 Q87 18 87 21 V24 Q87 27 84 27 H28 Q25 27 25 24 V21 Q25 18 28 18 Z" />
            <path d="M32 27 H84 V32 H32 Z" />
            <path d="M34 32 L49 33 L43 53 L29 51 Z" />
            <path d="M52 32 H57 V37 H64 V32 H69 V41 H57 L52 41 Z" />
          </>
        )}
        {kind === "p250" && (
          <>
            <path d="M34 19 H94 Q97 19 97 22 V25 Q97 28 94 28 H34 Q31 28 31 25 V22 Q31 19 34 19 Z" />
            <path d="M38 28 H88 V33 H38 Z" />
            <path d="M40 33 L54 34 L48 52 L34 50 Z" />
            <path d="M56 33 H61 V38 H68 V33 H73 V42 H61 L56 42 Z" />
          </>
        )}
        {kind === "karambit" && (
          <>
            <path
              fillRule="evenodd"
              d="M22 23 A8 8 0 1 0 22 39 A8 8 0 1 0 22 23 Z M22 27.5 A3.5 3.5 0 1 1 22 34.5 A3.5 3.5 0 1 1 22 27.5 Z"
            />
            <path d="M29 25 L47 22 L50 36 L31 39 Z" />
            <path d="M47 22 C64 20 82 29 94 49 C79 37 61 35 50 38 Z" />
          </>
        )}
        {kind === "bayonet" && (
          <>
            <path d="M10 26 H34 L37 34 H12 Z" />
            <path d="M34 21 H39 V39 H34 Z" />
            <path d="M39 23 C60 19 85 21 104 28 C86 35 60 37 39 34 Z" />
            <path d="M46 28.5 H86" stroke={dark} strokeWidth="1.4" fill="none" opacity="0.55" />
          </>
        )}
        {kind === "butterfly" && (
          <>
            <rect x="16" y="20" width="40" height="8" rx="2.5" transform="rotate(-22 56 31)" />
            <rect x="16" y="26" width="40" height="8" rx="2.5" transform="rotate(24 56 31)" />
            <path d="M58 26 L100 29.5 L60 37 Z" />
            <circle cx="57" cy="31" r="2.4" fill="#0b0714" stroke="none" />
          </>
        )}
        {kind === "gloves" && (
          <>
            <path d="M38 14 C36 12 32 12 30 14 L26 20 C24 23 24 27 26 30 L30 36 L26 46 Q26 50 30 50 L58 50 Q62 50 62 46 L60 38 L66 34 C70 31 70 26 66 24 L54 20 L46 16 Z" />
            <path d="M62 46 L88 42 Q93 41 93 37 Q93 33 88 34 L62 38 Z" opacity="0.85" />
            <path d="M46 16 L54 20" stroke={dark} strokeWidth="1.2" fill="none" opacity="0.6" />
          </>
        )}
        {kind === "sticker" && (
          <>
            <path d="M30 12 L78 12 Q84 12 84 18 L84 34 L70 48 L30 48 Q24 48 24 42 L24 18 Q24 12 30 12 Z" />
            <path d="M84 34 L70 48 L70 38 Q70 34 74 34 Z" fill="rgba(0,0,0,0.45)" stroke="none" />
            <path d="M32 22 L58 22 M32 30 L66 30 M32 38 L52 38" stroke="rgba(255,255,255,0.4)" strokeWidth="2.4" fill="none" strokeLinecap="round" />
          </>
        )}
        {kind === "charm" && (
          <>
            <path d="M52 8 Q60 8 66 14 M56 14 Q62 15 66 22" stroke={dark} strokeWidth="1.6" fill="none" />
            <circle cx="60" cy="26" r="4.5" />
            <circle cx="60" cy="36" r="9" />
            <path d="M56 33 Q60 29 64 33 Q60 37 56 33 Z" fill="rgba(255,255,255,0.35)" stroke="none" />
          </>
        )}
        {kind === "agent" && (
          <>
            {/* head + helmet */}
            <circle cx="60" cy="14" r="6.5" />
            <path d="M52 12 Q60 4 68 12 L68 14 L52 14 Z" />
            {/* torso + vest */}
            <path d="M46 24 Q60 20 74 24 L77 40 Q60 44 43 40 Z" />
            <path d="M52 27 H68 L70 36 H50 Z" fill="rgba(0,0,0,0.35)" stroke="none" />
            {/* arms */}
            <path d="M43 26 L34 38 L38 42 L47 32 Z" />
            <path d="M77 26 L86 38 L82 42 L73 32 Z" />
            {/* legs */}
            <path d="M48 42 L45 56 L51 56 L54 43 Z" />
            <path d="M72 42 L75 56 L69 56 L66 43 Z" />
          </>
        )}
        {kind === "patch" && (
          <>
            {/* fabric badge with stitched border */}
            <path d="M36 12 L84 12 Q90 12 90 18 L90 42 Q90 48 84 48 L36 48 Q30 48 30 42 L30 18 Q30 12 36 12 Z" />
            <path d="M37 16 L83 16 Q86 16 86 19 L86 41 Q86 44 83 44 L37 44 Q34 44 34 41 L34 19 Q34 16 37 16 Z" fill="rgba(0,0,0,0.32)" stroke="none" />
            <path d="M40 26 H62 M40 34 H54" stroke="rgba(255,255,255,0.4)" strokeWidth="2.2" strokeLinecap="round" fill="none" />
            <circle cx="74" cy="30" r="6" fill="rgba(255,255,255,0.18)" stroke="none" />
          </>
        )}
      </g>
    </svg>
  );
}
