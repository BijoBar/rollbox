"use client";

import { useCallback, useEffect, useState } from "react";
import { Ban, Check, Clock, Copy, ExternalLink, RefreshCw, Save, Wallet as WalletIcon } from "lucide-react";
import { formatCoins } from "@/lib/cases";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";

/* ===== C7 PHASE 1: the admin WALLET tab =====
   The review desk for REAL money: the deposit queue (verify the txid on
   Tronscan, then approve = credit, or reject = nothing moves) and the
   withdrawal queue (the coins are already locked; mark PAID after sending
   the USDT, or REJECT = instant refund). Plus the config card: the site's
   USDT (TRC-20) deposit address, the min/max amounts and the master switch. */

interface DepositRow {
  id: string;
  playerId: string;
  playerName: string;
  method: string;
  amountUsd: number;
  txid: string;
  status: string;
  adminNote: string | null;
  createdAt: string;
}

interface WithdrawRow {
  id: string;
  playerId: string;
  playerName: string;
  method: string;
  amountCoins: number;
  address: string;
  status: string;
  adminNote: string | null;
  payoutTxid: string | null;
  createdAt: string;
}

interface AdminWalletData {
  raw: Record<string, string>;
  declaration: string;
  deposits: DepositRow[];
  withdrawals: WithdrawRow[];
  pendingDeposits: number;
  pendingWithdrawals: number;
}

const fmtWhen = (iso: string): string =>
  new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });

const STATUS_CLS: Record<string, string> = {
  pending: "border-amber-400/40 bg-amber-500/10 text-amber-300",
  approved: "border-emerald-400/40 bg-emerald-500/10 text-emerald-300",
  paid: "border-emerald-400/40 bg-emerald-500/10 text-emerald-300",
  rejected: "border-red-400/40 bg-red-500/10 text-red-300",
};

function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn("rounded border px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wide", STATUS_CLS[status] ?? "border-white/20 bg-white/5 text-white/50")}>
      {status.toUpperCase()}
    </span>
  );
}

export function AdminWalletTab({ onPending }: { onPending?: (pending: number) => void }) {
  const { toast } = useToast();
  const [data, setData] = useState<AdminWalletData | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  // config editor state
  const [cfgAddress, setCfgAddress] = useState("");
  const [cfgMinDep, setCfgMinDep] = useState("");
  const [cfgMaxDep, setCfgMaxDep] = useState("");
  const [cfgMinWd, setCfgMinWd] = useState("");
  const [cfgMaxWd, setCfgMaxWd] = useState("");
  const [cfgEnabled, setCfgEnabled] = useState(true);
  const [cfgBusy, setCfgBusy] = useState(false);

  const load = useCallback(async () => {
    const r = await fetch("/api/admin/wallet", { cache: "no-store" });
    if (!r.ok) return;
    const d = (await r.json()) as AdminWalletData;
    setData(d);
    setCfgAddress(d.raw["wallet.usdt_address"] === "" ? "" : d.raw["wallet.usdt_address"]);
    setCfgMinDep(d.raw["wallet.minDeposit"]);
    setCfgMaxDep(d.raw["wallet.maxDeposit"]);
    setCfgMinWd(d.raw["wallet.minWithdraw"]);
    setCfgMaxWd(d.raw["wallet.maxWithdraw"]);
    setCfgEnabled(d.raw["wallet.enabled"] === "1");
    onPending?.(d.pendingDeposits + d.pendingWithdrawals);
  }, [onPending]);

  useEffect(() => {
    void load();
    const t = window.setInterval(() => void load(), 20_000); // queues move — poll gently
    return () => window.clearInterval(t);
  }, [load]);

  const saveConfig = async () => {
    if (cfgBusy) return;
    setCfgBusy(true);
    try {
      const r = await fetch("/api/admin/wallet/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          values: {
            "wallet.enabled": cfgEnabled ? "1" : "0",
            "wallet.usdt_address": cfgAddress.trim(),
            "wallet.minDeposit": cfgMinDep,
            "wallet.maxDeposit": cfgMaxDep,
            "wallet.minWithdraw": cfgMinWd,
            "wallet.maxWithdraw": cfgMaxWd,
          },
        }),
      });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error ?? "Could not save the config");
      sfx.coins();
      toast({ title: "Wallet config saved" });
      void load();
    } catch (e) {
      sfx.error();
      toast({ title: e instanceof Error ? e.message : "Could not save the config", variant: "destructive" });
    } finally {
      setCfgBusy(false);
    }
  };

  const act = async (kind: "deposit" | "withdraw", id: string, payload: Record<string, unknown>) => {
    if (busyId) return;
    setBusyId(id);
    try {
      const r = await fetch(`/api/admin/wallet/${kind}/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const d = (await r.json()) as { error?: string; status?: string };
      if (!r.ok) throw new Error(d.error ?? "Action failed");
      sfx.coins();
      toast({ title: `Deposit ${d.status === "approved" ? "approved — balance credited" : d.status === "paid" ? "marked PAID" : d.status === "rejected" ? "rejected" : "reviewed"}` });
      void load();
    } catch (e) {
      sfx.error();
      toast({ title: e instanceof Error ? e.message : "Action failed", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const copy = async (text: string, what: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: `${what} copied` });
    } catch {
      toast({ title: "Copy failed" });
    }
  };

  const openExplorer = (txid: string) => {
    window.open(`https://tronscan.org/#/transaction/${txid}`, "_blank", "noopener");
  };

  return (
    <div className="mt-5 space-y-4" aria-label="Wallet admin">
      {/* ===== config ===== */}
      <section className="rounded-2xl border border-white/10 bg-black/40 p-4" aria-label="Wallet configuration">
        <div className="flex items-center gap-2">
          <WalletIcon className="h-4 w-4 text-amber-300" />
          <h3 className="text-sm font-black text-white">WALLET CONFIG</h3>
          <span className={cn("ml-auto rounded border px-1.5 py-0.5 text-[8px] font-black uppercase", cfgEnabled ? "border-emerald-400/40 bg-emerald-500/10 text-emerald-300" : "border-red-400/40 bg-red-500/10 text-red-300")}>
            {cfgEnabled ? "wallet open" : "wallet frozen"}
          </span>
        </div>
        <div className="mt-3 grid gap-2">
          <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-white/40" dir="ltr">
            <input type="checkbox" checked={cfgEnabled} onChange={(e) => setCfgEnabled(e.target.checked)} className="h-4 w-4 accent-emerald-400" />
            deposits &amp; withdrawals enabled
          </label>
          <input
            value={cfgAddress}
            onChange={(e) => setCfgAddress(e.target.value.trim())}
            dir="ltr"
            spellCheck={false}
            maxLength={34}
            placeholder="USDT (TRC-20) site address — T… (empty = closed)"
            aria-label="Site USDT deposit address"
            className="h-10 w-full rounded-lg border border-white/15 bg-black/50 px-3 font-mono text-xs text-white placeholder:text-white/25 focus:border-amber-400/60 focus:outline-none"
          />
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {(
              [
                ["minDeposit", cfgMinDep, setCfgMinDep, "min deposit $"],
                ["maxDeposit", cfgMaxDep, setCfgMaxDep, "max deposit $"],
                ["minWithdraw", cfgMinWd, setCfgMinWd, "min withdraw $"],
                ["maxWithdraw", cfgMaxWd, setCfgMaxWd, "max withdraw $"],
              ] as const
            ).map(([key, value, set, label]) => (
              <input
                key={key}
                value={value}
                onChange={(e) => set(e.target.value.replace(/[^0-9.]/g, ""))}
                dir="ltr"
                inputMode="decimal"
                aria-label={label}
                placeholder={label}
                className="h-10 w-full rounded-lg border border-white/15 bg-black/50 px-3 text-xs font-bold text-white placeholder:text-white/25 focus:border-amber-400/60 focus:outline-none"
              />
            ))}
          </div>
          <button
            type="button"
            disabled={cfgBusy}
            onClick={() => void saveConfig()}
            className="gold-btn flex h-10 w-full items-center justify-center gap-2 rounded-lg text-xs font-black text-black disabled:opacity-50 sm:w-40"
          >
            <Save className="h-3.5 w-3.5" />
            {cfgBusy ? "SAVING…" : "SAVE CONFIG"}
          </button>
        </div>
      </section>

      {/* ===== deposits queue ===== */}
      <section className="rounded-2xl border border-white/10 bg-black/40 p-4" aria-label="Deposit requests">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-black text-white">DEPOSITS</h3>
          {data && data.pendingDeposits > 0 && (
            <span className="grid h-4 min-w-4 place-items-center rounded-full bg-amber-500 px-1 text-[9px] font-black text-black">{data.pendingDeposits}</span>
          )}
          <button type="button" onClick={() => void load()} className="ml-auto text-white/40 hover:text-white" aria-label="Refresh the queues">
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        </div>
        {!data || data.deposits.length === 0 ? (
          <p className="mt-3 rounded-xl border border-dashed border-white/15 px-4 py-6 text-center text-xs font-bold text-white/35">No deposit requests yet.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {data.deposits.map((d) => (
              <li key={d.id} className={cn("rounded-xl border px-3 py-2.5", d.status === "pending" ? "border-amber-400/30 bg-amber-500/[0.05]" : "border-white/10 bg-white/[0.02]")}>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-display flex items-center gap-1 text-xs font-black text-white" dir="ltr">
                    <Coin className="h-3 w-3" /> {formatCoins(d.amountUsd)}
                  </span>
                  <StatusBadge status={d.status} />
                  <span className="text-[11px] font-bold text-white/70">{d.playerName}</span>
                  <span className="font-mono text-[9px] text-white/35" dir="ltr">{d.playerId}</span>
                  <span className="ml-auto text-[9px] font-bold text-white/35" dir="ltr">{fmtWhen(d.createdAt)}</span>
                </div>
                <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                  <code className="min-w-0 flex-1 truncate font-mono text-[10px] text-white/50" dir="ltr">{d.txid}</code>
                  <button type="button" onClick={() => void copy(d.txid, "The txid")} className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 bg-white/5 text-white/50 hover:text-white" aria-label="Copy the txid">
                    <Copy className="h-3 w-3" />
                  </button>
                  <button type="button" onClick={() => openExplorer(d.txid)} className="inline-flex h-7 items-center gap-1 rounded-lg border border-sky-400/30 bg-sky-500/10 px-2 text-[9px] font-black uppercase text-sky-300 hover:bg-sky-500/20" aria-label="Open on Tronscan">
                    <ExternalLink className="h-3 w-3" /> verify
                  </button>
                </div>
                {d.adminNote && <p className="mt-1 text-[10px] font-bold text-white/45">note: {d.adminNote}</p>}
                {d.status === "pending" && (
                  <div className="mt-2 flex gap-2">
                    <button
                      type="button"
                      disabled={busyId === d.id}
                      onClick={() => void act("deposit", d.id, { action: "approve" })}
                      className="flex h-8 flex-1 items-center justify-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 text-[10px] font-black uppercase text-emerald-300 hover:bg-emerald-500/25 disabled:opacity-50"
                    >
                      <Check className="h-3.5 w-3.5" /> APPROVE — credit
                    </button>
                    <button
                      type="button"
                      disabled={busyId === d.id}
                      onClick={() => {
                        const note = window.prompt("Reject note (shown to the player):") ?? "";
                        void act("deposit", d.id, { action: "reject", note });
                      }}
                      className="flex h-8 flex-1 items-center justify-center gap-1.5 rounded-lg border border-red-400/40 bg-red-500/15 text-[10px] font-black uppercase text-red-300 hover:bg-red-500/25 disabled:opacity-50"
                    >
                      <Ban className="h-3.5 w-3.5" /> REJECT
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* ===== withdrawals queue ===== */}
      <section className="rounded-2xl border border-white/10 bg-black/40 p-4" aria-label="Withdrawal requests">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-black text-white">WITHDRAWALS</h3>
          {data && data.pendingWithdrawals > 0 && (
            <span className="grid h-4 min-w-4 place-items-center rounded-full bg-amber-500 px-1 text-[9px] font-black text-black">{data.pendingWithdrawals}</span>
          )}
        </div>
        {!data || data.withdrawals.length === 0 ? (
          <p className="mt-3 rounded-xl border border-dashed border-white/15 px-4 py-6 text-center text-xs font-bold text-white/35">No withdrawal requests yet.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {data.withdrawals.map((w) => (
              <li key={w.id} className={cn("rounded-xl border px-3 py-2.5", w.status === "pending" ? "border-amber-400/30 bg-amber-500/[0.05]" : "border-white/10 bg-white/[0.02]")}>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-display flex items-center gap-1 text-xs font-black text-white" dir="ltr">
                    <Coin className="h-3 w-3" /> -{formatCoins(w.amountCoins)}
                  </span>
                  <StatusBadge status={w.status} />
                  <span className="text-[11px] font-bold text-white/70">{w.playerName}</span>
                  <span className="font-mono text-[9px] text-white/35" dir="ltr">{w.playerId}</span>
                  <span className="ml-auto text-[9px] font-bold text-white/35" dir="ltr">{fmtWhen(w.createdAt)}</span>
                </div>
                <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                  <code className="min-w-0 flex-1 truncate font-mono text-[10px] text-white/50" dir="ltr">{w.address}</code>
                  <button type="button" onClick={() => void copy(w.address, "The payout address")} className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 bg-white/5 text-white/50 hover:text-white" aria-label="Copy the payout address">
                    <Copy className="h-3 w-3" />
                  </button>
                </div>
                {w.payoutTxid && (
                  <p className="mt-1 truncate font-mono text-[10px] text-emerald-300/70" dir="ltr">payout txid: {w.payoutTxid}</p>
                )}
                {w.adminNote && <p className="mt-1 text-[10px] font-bold text-white/45">note: {w.adminNote}</p>}
                {w.status === "pending" && (
                  <div className="mt-2 flex gap-2">
                    <button
                      type="button"
                      disabled={busyId === w.id}
                      onClick={() => {
                        const payoutTxid = window.prompt("Payout txid (after you sent the USDT — optional):") ?? "";
                        void act("withdraw", w.id, { action: "paid", payoutTxid });
                      }}
                      className="flex h-8 flex-1 items-center justify-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 text-[10px] font-black uppercase text-emerald-300 hover:bg-emerald-500/25 disabled:opacity-50"
                    >
                      <Check className="h-3.5 w-3.5" /> MARK PAID
                    </button>
                    <button
                      type="button"
                      disabled={busyId === w.id}
                      onClick={() => {
                        const note = window.prompt("Reject note (shown to the player):") ?? "";
                        void act("withdraw", w.id, { action: "reject", note });
                      }}
                      className="flex h-8 flex-1 items-center justify-center gap-1.5 rounded-lg border border-red-400/40 bg-red-500/15 text-[10px] font-black uppercase text-red-300 hover:bg-red-500/25 disabled:opacity-50"
                    >
                      <Ban className="h-3.5 w-3.5" /> REJECT — refund
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      <p className="flex items-start gap-1.5 text-[10px] font-semibold leading-relaxed text-white/30">
        <Clock className="mt-0.5 h-3 w-3 shrink-0" />
        Review rule: verify every deposit txid on the explorer BEFORE approving — approving credits the balance instantly. Rejecting a withdrawal refunds the locked coins immediately.
      </p>
    </div>
  );
}
