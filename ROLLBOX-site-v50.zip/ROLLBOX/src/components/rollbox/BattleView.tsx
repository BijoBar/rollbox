"use client";

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import { Coins, RotateCcw, ShieldCheck, Swords, Trophy, Zap } from "lucide-react";
import {
  BATTLE_CASES,
  SKINS,
  formatCoins,
  oddsPct,
  rollCase,
  type CaseDef,
} from "@/lib/cases";
import { useCaseStore } from "@/lib/store";
import { xpForCase } from "@/lib/progress";
import { sfx } from "@/lib/sound";
import { SkinTile } from "./SkinTile";
import { GOLD_FLASH_BG, WinnerChip } from "./CaseOpener";
import { SiteShell } from "./SiteShell";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";

type Phase = "setup" | "battle" | "done";

/** One pre-drawn round: the player's provably-fair roll + the bot's house roll. */
interface RoundDraw {
  playerSkinId: string;
  botSkinId: string;
}

// USER SPEC (Task 100c): battle spins are LONGER and FASTER — the reels fly
// through 64 cells (was 36): player locks at 3.6s (17.8 cells/s vs the old
// 15 @ 2.4s = +18% speed), bot ~1s later keeping the suspense stagger.
const PLAYER_SPIN_MS = 3600; // player reel locks first
const BOT_SPIN_MS = 4600; // bot locks ~1s later — the suspense beat
const ROUND_GAP_MS = 750;

const randFrom = (pool: string[]) => pool[Math.floor(Math.random() * pool.length)];

export function BattleView() {
  const mounted = useMounted();
  const { toast } = useToast();

  const [caseId, setCaseId] = useState(BATTLE_CASES.find((c) => c.kind === "farm")?.id ?? BATTLE_CASES[0].id);
  const [rounds, setRounds] = useState(3);
  const [phase, setPhase] = useState<Phase>("setup");

  const [round, setRound] = useState(-1); // current round index (-1 = pre-battle / between rounds)
  const [battleId, setBattleId] = useState(0); // increments per battle — remounts reels on rematch
  const [pItems, setPItems] = useState<string[]>([]); // revealed player skins
  const [bItems, setBItems] = useState<string[]>([]); // revealed bot skins
  const [outcome, setOutcome] = useState<"win" | "lose" | null>(null);
  const [battleCase, setBattleCase] = useState<CaseDef | null>(null);
  const [draws, setDraws] = useState<RoundDraw[]>([]); // pre-drawn rounds (render-safe)

  const timersRef = useRef<number[]>([]);
  const runRoundRef = useRef<((idx: number, pool: string[], d: RoundDraw[]) => void) | null>(null);

  const later = useCallback((fn: () => void, ms: number) => {
    const id = window.setTimeout(fn, ms);
    timersRef.current.push(id);
    return id;
  }, []);

  const clearAll = useCallback(() => {
    for (const id of timersRef.current) window.clearTimeout(id);
    timersRef.current = [];
  }, []);

  // stop every timer when the page unmounts
  useEffect(() => clearAll, [clearAll]);

  const balance = useCaseStore((s) => s.balance);
  const battleCaseDef = BATTLE_CASES.find((c) => c.id === caseId) ?? BATTLE_CASES[0];
  const cost = battleCaseDef.price * rounds;
  const canAfford = balance >= cost;

  /* ---------- battle engine ---------- */

  const finish = useCallback(
    (draws: RoundDraw[]) => {
      const pTotal = draws.reduce((s, d) => s + (SKINS[d.playerSkinId]?.value ?? 0), 0);
      const bTotal = draws.reduce((s, d) => s + (SKINS[d.botSkinId]?.value ?? 0), 0);
      // tie-break: bigger single item takes it, then the player (house mercy)
      const pMax = Math.max(...draws.map((d) => SKINS[d.playerSkinId]?.value ?? 0));
      const bMax = Math.max(...draws.map((d) => SKINS[d.botSkinId]?.value ?? 0));
      const win = pTotal > bTotal || (pTotal === bTotal && pMax >= bMax);

      if (win) {
        // winner takes all — both hauls go to your inventory
        const now = Date.now();
        draws.forEach((d, i) => {
          const st = useCaseStore.getState();
          // legacy local-mirror credit (dead path — battles credit through the
          // server economy now); grantItem = inventory add with no balance math
          const credit = (skinId: string) => {
            const s = SKINS[skinId];
            st.grantItem({ id: skinId, n: s?.name ?? skinId, w: s?.name.split(" | ")[0] ?? "", r: s?.rarity ?? "consumer", p: 0, v: s?.value ?? 0, img: null });
          };
          credit(d.playerSkinId);
          credit(d.botSkinId);
        });
        sfx.win(true);
      } else {
        sfx.error();
      }
      setOutcome(win ? "win" : "lose");
      setPhase("done");
    },
    [battleCaseDef]
  );

  const runRound = useCallback(
    (idx: number, pool: string[], d: RoundDraw[]) => {
      // bumping `round` remounts both SpinReels (keyed by battleId-round):
      // each builds a fresh strip, spins with the cinematic ease and locks on the real roll
      setRound(idx);
      later(
        () => {
          if (idx + 1 < d.length) {
            later(() => runRoundRef.current?.(idx + 1, pool, d), ROUND_GAP_MS);
          } else {
            later(() => finish(d), 600);
          }
        },
        BOT_SPIN_MS + 850
      );
    },
    [finish, later]
  );

  // let the recursion go through a ref (avoids self-referencing useCallback)
  useEffect(() => {
    runRoundRef.current = runRound;
  }, [runRound]);

  const startBattle = useCallback(() => {
    const st = useCaseStore.getState();
    const total = battleCaseDef.price * rounds;
    if (!st.pay(total, rounds)) {
      sfx.error();
      toast({
        title: "Not enough funds",
        description: `A ${rounds}-round battle costs $${formatCoins(total)}. Grab your free daily cases every 24h — or sell items from your inventory.`,
        variant: "destructive",
      });
      return;
    }
    sfx.click();

    // XP grant only — no reward, no level-up toast (level is DB state)
    st.grantXp(xpForCase(battleCaseDef.price) * rounds);

    // pre-draw every round: player rolls are provably fair, bot uses house RNG
    const after = useCaseStore.getState();
    const newDraws: RoundDraw[] = Array.from({ length: rounds }, () => ({
      playerSkinId: after.drawCase(battleCaseDef).skin.id,
      botSkinId: rollCase(battleCaseDef).id,
    }));
    setDraws(newDraws);

    setBattleCase(battleCaseDef);
    setPItems([]);
    setBItems([]);
    setOutcome(null);
    setRound(-1);
    setBattleId((b) => b + 1);
    setPhase("battle");
    const pool = battleCaseDef.items.map((i) => i.skinId);
    sfx.caseOpen(); // cinematic latch before round 1
    later(() => runRoundRef.current?.(0, pool, newDraws), 700);
  }, [battleCaseDef, rounds, later, toast]);

  const backToSetup = useCallback(() => {
    clearAll();
    setPhase("setup");
    setOutcome(null);
    setPItems([]);
    setBItems([]);
  }, [clearAll]);

  /* ---------- derived UI data ---------- */
  const pTotal = pItems.reduce((s, id) => s + (SKINS[id]?.value ?? 0), 0);
  const bTotal = bItems.reduce((s, id) => s + (SKINS[id]?.value ?? 0), 0);
  const haulTotal = draws.reduce(
    (s, d) => s + (SKINS[d.playerSkinId]?.value ?? 0) + (SKINS[d.botSkinId]?.value ?? 0),
    0
  );

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-10" aria-label="Case Battles">
        <div className="bg-grid absolute inset-0" aria-hidden="true" />
        <div className="anim-orb pointer-events-none absolute left-[10%] top-20 h-64 w-64 rounded-full bg-fuchsia-500/10 blur-3xl" aria-hidden="true" />
        <div className="anim-orb pointer-events-none absolute right-[8%] top-64 h-56 w-56 rounded-full bg-violet-500/10 blur-3xl" style={{ animationDelay: "-6s" }} aria-hidden="true" />

        <div className="relative mx-auto max-w-5xl px-4">
          {/* hero */}
          <div className="text-center">
            <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl border border-fuchsia-400/30 bg-fuchsia-400/10 shadow-[0_0_36px_rgba(217,70,239,0.3)]">
              <Swords className="h-9 w-9 text-fuchsia-300" />
            </span>
            <h1 className="font-display text-4xl font-black tracking-wide text-white md:text-5xl">
              CASE <span className="text-gradient-neon">BATTLES</span>
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-white/60 md:text-base">
              You vs the ROLLBOX Bot — same case, same rounds, both hauls on the line.
              Highest total value takes <span className="font-bold text-amber-300">everything</span>.
            </p>
          </div>

          {/* ================= SETUP ================= */}
          {phase === "setup" && (
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="mx-auto mt-8 max-w-2xl rounded-2xl border border-fuchsia-500/25 bg-[#100a1e]/90 p-6 shadow-[0_0_50px_rgba(147,51,234,0.15)]"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <p className="mb-1.5 text-xs font-black uppercase tracking-wider text-white/45">Battle case</p>
                  <Select value={caseId} onValueChange={setCaseId}>
                    <SelectTrigger
                      className="border-white/10 bg-black/40 text-sm text-white/85"
                      aria-label="Choose the battle case"
                    >
                      <SelectValue placeholder="Choose a case" />
                    </SelectTrigger>
                    <SelectContent className="max-h-80 border-white/10 bg-[#150e26]">
                      {BATTLE_CASES.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.name} — <Coin />{formatCoins(c.price)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <p className="mb-1.5 text-xs font-black uppercase tracking-wider text-white/45">Rounds</p>
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((n) => (
                      <button
                        key={n}
                        onClick={() => {
                          setRounds(n);
                          sfx.click();
                        }}
                        aria-pressed={rounds === n}
                        className={cn(
                          "font-display h-9 flex-1 rounded-lg text-xs font-black transition-all",
                          rounds === n
                            ? "gold-btn text-black shadow-[0_0_16px_rgba(240,185,11,0.5)]"
                            : "bg-white/5 text-white/55 hover:bg-white/10 hover:text-white"
                        )}
                      >
                        x{n}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-5 grid grid-cols-3 gap-3 text-center">
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3">
                  <p className="font-display text-lg font-black text-amber-300"><Coin />{formatCoins(cost)}</p>
                  <p className="text-[10px] font-bold uppercase tracking-wide text-white/45">Entry cost</p>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3">
                  <p className="font-display text-lg font-black text-fuchsia-300">{rounds * 2}</p>
                  <p className="text-[10px] font-bold uppercase tracking-wide text-white/45">Items on the line</p>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3">
                  <p className={cn("font-display text-lg font-black", canAfford ? "text-emerald-300" : "text-red-400")}>
                    <Coin />{formatCoins(mounted ? balance : 0)}
                  </p>
                  <p className="text-[10px] font-bold uppercase tracking-wide text-white/45">Your balance</p>
                </div>
              </div>

              <button
                onClick={startBattle}
                disabled={mounted && !canAfford}
                className="neon-btn mt-5 flex w-full items-center justify-center gap-2 rounded-xl px-8 py-4 text-lg font-black text-white disabled:cursor-not-allowed"
              >
                <Swords className="h-5 w-5" />
                Create Battle • <Coin />{formatCoins(cost)}
              </button>
              {mounted && !canAfford && (
                <p className="mt-2 text-center text-xs font-bold text-red-400">
                  Not enough funds for this battle — pick a cheaper case or fewer rounds.
                </p>
              )}

              <div className="mt-4 flex items-start gap-2 rounded-xl border border-emerald-500/25 bg-emerald-500/5 px-4 py-3">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                <p className="text-xs leading-relaxed text-white/60">
                  <span className="font-bold text-emerald-300">Provably fair:</span> every roll of yours comes from
                  the HMAC seed commitment and lands in your roll history. The bot plays with house RNG —
                  winner takes both hauls.
                </p>
              </div>
            </motion.div>
          )}

          {/* ================= BATTLE ================= */}
          {phase === "battle" && battleCase && (
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="mt-8 rounded-2xl border border-fuchsia-500/25 bg-[#100a1e]/90 p-5 shadow-[0_0_50px_rgba(147,51,234,0.15)] sm:p-6"
            >
              {/* round progress */}
              <div className="mb-5 flex items-center justify-center gap-2">
                {draws.map((_, i) => (
                  <span
                    key={i}
                    aria-current={i === round}
                    className={cn(
                      "font-display grid h-7 w-7 place-items-center rounded-lg text-[11px] font-black",
                      i < round
                        ? "bg-white/10 text-white/50"
                        : i === round
                          ? "gold-btn text-black shadow-[0_0_14px_rgba(240,185,11,0.6)]"
                          : "bg-white/5 text-white/35"
                    )}
                  >
                    {i + 1}
                  </span>
                ))}
                <span className="ml-2 text-xs font-bold uppercase tracking-wider text-white/45">
                  {round >= 0 ? `Round ${round + 1} / ${draws.length}` : "Get ready"} — {battleCase.name}
                </span>
              </div>

              {round < 0 && (
                <p className="font-display flex items-center justify-center gap-2 py-12 text-sm font-black tracking-[0.3em] text-fuchsia-300">
                  <Zap className="h-4 w-4 animate-pulse" fill="currentColor" />
                  GET READY...
                </p>
              )}

              {round >= 0 && draws[round] && (
                <div className="grid items-start gap-4 md:grid-cols-[1fr_auto_1fr]">
                  {/* player column */}
                  <BattleSide title="YOU" accent="#a78bfa" items={pItems} total={pTotal}>
                    <SpinReel
                      key={`p-${battleId}-${round}`}
                      pool={battleCase.items.map((i) => i.skinId)}
                      target={draws[round].playerSkinId}
                      duration={PLAYER_SPIN_MS}
                      flashOnLock={oddsPct(battleCase, draws[round].playerSkinId) <= 10}
                      onDone={() => setPItems((items) => [...items, draws[round].playerSkinId])}
                    />
                  </BattleSide>

                  {/* vs */}
                  <div className="mx-auto grid h-12 w-12 place-items-center rounded-full border border-white/15 bg-black/50 font-display text-sm font-black text-white/70 md:mt-16">
                    VS
                  </div>

                  {/* bot column */}
                  <BattleSide title="BOT" accent="#fb7185" items={bItems} total={bTotal}>
                    <SpinReel
                      key={`b-${battleId}-${round}`}
                      pool={battleCase.items.map((i) => i.skinId)}
                      target={draws[round].botSkinId}
                      duration={BOT_SPIN_MS}
                      flashOnLock={oddsPct(battleCase, draws[round].botSkinId) <= 10}
                      onDone={() => setBItems((items) => [...items, draws[round].botSkinId])}
                    />
                  </BattleSide>
                </div>
              )}

              {/* live per-box score — fills in as each side locks */}
              <BattleScore draws={draws} pItems={pItems} bItems={bItems} />
            </motion.div>
          )}

          {/* ================= RESULT ================= */}
          {phase === "done" && battleCase && outcome && (
            <motion.div
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
              className={cn(
                "mx-auto mt-8 max-w-2xl rounded-2xl border p-8 text-center",
                outcome === "win"
                  ? "border-amber-400/50 bg-gradient-to-b from-amber-400/10 to-transparent"
                  : "border-red-500/40 bg-gradient-to-b from-red-500/10 to-transparent"
              )}
              role="status"
            >
              <span
                className={cn(
                  "mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full border",
                  outcome === "win"
                    ? "border-amber-400/50 bg-amber-400/15 text-amber-300"
                    : "border-red-500/40 bg-red-500/10 text-red-400"
                )}
              >
                {outcome === "win" ? <Trophy className="h-8 w-8" /> : <Swords className="h-8 w-8" />}
              </span>
              <h2
                className={cn(
                  "font-display text-3xl font-black tracking-wide md:text-4xl",
                  outcome === "win" ? "text-amber-300" : "text-red-400"
                )}
              >
                {outcome === "win" ? "VICTORY!" : "DEFEAT"}
              </h2>
              {outcome === "win" ? (
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-white/65">
                  You out-rolled the bot — all{" "}
                  <span className="font-bold text-amber-300">{rounds * 2} items</span> worth{" "}
                  <span className="font-bold text-amber-300"><Coin />{formatCoins(haulTotal)}</span> were added to your
                  inventory. Sell them or keep the flex.
                </p>
              ) : (
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-white/65">
                  The bot took both hauls this time. Your rolls are always provably fair — run it back and take
                  what&apos;s yours.
                </p>
              )}

              {/* full battle calculation — per box + grand totals per player */}
              <BattleScore draws={draws} pItems={pItems} bItems={bItems} totals />

              <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
                <button
                  onClick={startBattle}
                  className="neon-btn flex items-center gap-1.5 rounded-xl px-6 py-3 text-sm font-black text-white"
                >
                  <RotateCcw className="h-4 w-4" />
                  Rematch • <Coin />{formatCoins(battleCase.price * rounds)}
                </button>
                <button
                  onClick={backToSetup}
                  className="rounded-xl border border-white/20 bg-white/5 px-6 py-3 text-sm font-bold text-white/80 transition-colors hover:bg-white/10 hover:text-white"
                >
                  <Coins className="mr-1 inline h-4 w-4" />
                  New Battle
                </button>
              </div>
            </motion.div>
          )}
        </div>
      </main>
    </SiteShell>
  );
}

/* ===== one side of the battlefield ===== */
function BattleSide({
  title,
  accent,
  items,
  total,
  children,
}: {
  title: string;
  accent: string;
  items: string[];
  total: number;
  children: ReactNode;
}) {
  return (
    <div
      className="rounded-2xl border p-5"
      style={{ borderColor: accent + "44", background: `radial-gradient(ellipse 90% 60% at 50% 0%, ${accent}12, transparent 70%), #120c20` }}
    >
      <div className="mb-3 flex items-center justify-between">
        <span className="font-display text-sm font-black tracking-widest" style={{ color: accent }}>
          {title}
        </span>
        <span className="font-display flex items-center gap-1 text-sm font-black text-amber-300">
          <Coin />{formatCoins(total)}
        </span>
      </div>

      {/* live roulette reel — spins with the case-opener animation and locks on the real roll */}
      {children}

      {/* revealed items */}
      {items.length > 0 && (
        <div className="mt-3 flex flex-wrap justify-center gap-1.5" aria-label={`${title} revealed items`}>
          {items.map((id, i) => (
            <SkinTile key={`${id}-${i}`} skinId={id} compact showValue={false} className="h-16 w-16" artClassName="h-9" />
          ))}
        </div>
      )}
      {items.length === 0 && (
        <p className="mt-3 text-center text-[11px] font-bold uppercase tracking-wider text-white/30">
          No items yet
        </p>
      )}
    </div>
  );
}

/* ===== battle reel — the same cinematic roulette as the case opener ===== */

const REEL_LEN = 72;
const REEL_WINNER = 64;

function battleDims() {
  const mobile = typeof window !== "undefined" && window.innerWidth < 640;
  return { itemH: mobile ? 84 : 96, gap: 6 };
}

interface ReelCell {
  key: number;
  skinId: string;
  isWinner?: boolean;
}

function SpinReel({
  pool,
  target,
  duration,
  flashOnLock,
  onDone,
}: {
  pool: string[];
  target: string;
  duration: number;
  flashOnLock: boolean;
  onDone: () => void;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const stripRef = useRef<HTMLDivElement>(null);
  const streaksRef = useRef<HTMLDivElement>(null);
  const [locked, setLocked] = useState(false);
  const [tension, setTension] = useState(false);
  const tensionRef = useRef(false);
  const onDoneRef = useRef(onDone);
  useEffect(() => {
    onDoneRef.current = onDone;
  }, [onDone]);

  // strip is built once at mount — the reel is remounted per round via key
  const [strip] = useState<ReelCell[]>(() =>
    Array.from({ length: REEL_LEN }, (_, i) => ({
      key: i,
      skinId: i === REEL_WINNER ? target : randFrom(pool),
      isWinner: i === REEL_WINNER,
    }))
  );

  useEffect(() => {
    const { itemH, gap } = battleDims();
    const containerH = wrapRef.current?.clientHeight ?? 176;
    // winner cell lands dead-center on the yellow marker — no random offset
    const targetY = REEL_WINNER * (itemH + gap) + itemH / 2 - containerH / 2;
    const t0 = performance.now();
    const velMax = (targetY * 4) / (duration / 1000);
    let raf = 0;
    let lastTick = -1;
    let lastTickAt = 0;

    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / duration);
      const eased = 1 - Math.pow(1 - p, 4);
      // derivative of the quartic ease-out → live velocity for ticks / streaks
      const vel = 4 * Math.pow(1 - p, 3) * (targetY / (duration / 1000));
      const vNorm = Math.min(1, vel / velMax);

      // vertical spin: rAF writes Y-only translate3d (no CSS translate conflicts)
      if (stripRef.current) {
        stripRef.current.style.transform = `translate3d(0, ${-(eased * targetY)}px, 0)`;
      }
      if (streaksRef.current) streaksRef.current.style.opacity = (vNorm * 0.75).toFixed(2);

      // ratchet ticks — one per cell passing the marker
      const idx = Math.floor((eased * targetY) / (itemH + gap));
      const now = performance.now();
      if (idx !== lastTick && now - lastTickAt > 18) {
        lastTick = idx;
        lastTickAt = now;
        sfx.tick(vNorm);
      }

      if (p > 0.84 && !tensionRef.current) {
        tensionRef.current = true;
        setTension(true);
      }

      if (p < 1) {
        raf = requestAnimationFrame(step);
      } else {
        if (streaksRef.current) streaksRef.current.style.opacity = "0";
        sfx.lock();
        setLocked(true);
        onDoneRef.current();
      }
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [duration]);

  const jp = locked && SKINS[target]?.rarity === "contraband";

  return (
    <div
      ref={wrapRef}
      className={cn(
        "relative h-44 overflow-hidden rounded-xl border border-white/10 sm:h-56",
        "bg-[radial-gradient(ellipse_at_center,#160f2b_0%,#0b0716_72%)]",
        locked && "ring-1 ring-amber-300/40"
      )}
      dir="ltr"
    >
      {/* center marker — horizontal LINE only (Task 135: diamond removed) */}
      <div className="absolute inset-x-0 top-1/2 z-20 h-0" aria-hidden="true">
        <div
          className={cn(
            "absolute inset-x-0 top-0 h-[2px] -translate-y-1/2 bg-gradient-to-r from-transparent via-amber-300 to-transparent transition-shadow",
            tension && "shadow-[0_0_22px_rgba(240,185,11,1)]"
          )}
        />
      </div>
      {/* edge fades + speed streaks */}
      <div className="reel-fade-t pointer-events-none absolute inset-x-0 top-0 z-10 h-9" />
      <div className="reel-fade-b pointer-events-none absolute inset-x-0 bottom-0 z-10 h-9" />
      <div ref={streaksRef} className="reel-streaks-v pointer-events-none absolute inset-0 z-10 opacity-0" />
      {/* lock flash — gold, rare pulls only (≤10% odds) */}
      {locked && flashOnLock && (
        <div
          className="anim-lock-flash pointer-events-none absolute inset-0 z-30"
          style={{ background: GOLD_FLASH_BG }}
          aria-hidden="true"
        />
      )}
      {/* winner name + price pops under the skin at lock */}
      {locked && <WinnerChip skinId={target} style={{ top: `calc(50% + ${battleDims().itemH / 2 + 6}px)` }} />}

      <div
        ref={stripRef}
        className="absolute inset-x-0 top-0 flex flex-col will-change-transform"
        style={{ gap: `${battleDims().gap}px` }}
      >
        {strip.map((cell) => {
          const isWin = locked && cell.isWinner;
          return (
            <SkinTile
              key={cell.key}
              skinId={cell.skinId}
              showValue={false}
              compact
              className={cn(
                "w-full shrink-0 rounded-lg",
                isWin && !jp && "anim-glow-pulse",
                isWin && jp && "anim-jackpot-glow"
              )}
              artClassName="h-12 sm:h-14"
              style={{
                height: battleDims().itemH,
                ...(isWin ? { borderColor: "#f0b90b", boxShadow: "0 0 26px rgba(240,185,11,0.55)" } : {}),
              }}
            />
          );
        })}
      </div>
    </div>
  );
}

/* ===== per-box score table — live during the battle, full totals at the end ===== */
function BattleScore({
  draws,
  pItems,
  bItems,
  totals = false,
}: {
  draws: RoundDraw[];
  pItems: string[];
  bItems: string[];
  totals?: boolean;
}) {
  if (!draws.length) return null;
  const rows = draws.map((d, i) => ({
    p: i < pItems.length ? (SKINS[d.playerSkinId]?.value ?? 0) : null,
    b: i < bItems.length ? (SKINS[d.botSkinId]?.value ?? 0) : null,
  }));
  if (!rows.some((r) => r.p !== null || r.b !== null)) return null;
  const pTotal = rows.reduce((s, r) => s + (r.p ?? 0), 0);
  const bTotal = rows.reduce((s, r) => s + (r.b ?? 0), 0);

  return (
    <div className="mx-auto mt-4 w-full max-w-md overflow-hidden rounded-xl border border-white/10 bg-black/30">
      <div className="grid grid-cols-[1fr_2.5rem_1fr] items-center bg-white/[0.04] px-3 py-1.5 text-[10px] font-black uppercase tracking-wider">
        <span className="text-left text-violet-300">You</span>
        <span className="text-center text-white/40">Box</span>
        <span className="text-right text-rose-300">Bot</span>
      </div>
      {rows.map((r, i) => (
        <div
          key={i}
          className="grid grid-cols-[1fr_2.5rem_1fr] items-center border-t border-white/5 px-3 py-1 text-xs font-bold"
        >
          <span
            className={cn(
              "text-left",
              r.p === null ? "text-white/20" : r.b !== null && (r.p ?? 0) < r.b ? "text-white/55" : "text-emerald-300"
            )}
          >
            {r.p === null ? "..." : <><Coin />{formatCoins(r.p)}</>}
          </span>
          <span className="text-center text-[10px] font-black text-white/35">#{i + 1}</span>
          <span
            className={cn(
              "text-right",
              r.b === null ? "text-white/20" : r.p !== null && (r.b ?? 0) < r.p ? "text-white/55" : "text-rose-300"
            )}
          >
            {r.b === null ? "..." : <><Coin />{formatCoins(r.b)}</>}
          </span>
        </div>
      ))}
      {totals && (
        <div className="grid grid-cols-[1fr_2.5rem_1fr] items-center border-t border-white/15 bg-white/[0.06] px-3 py-2">
          <span className="font-display text-left text-sm font-black text-violet-200">
            <Coin />{formatCoins(pTotal)}
          </span>
          <span className="text-center text-[9px] font-black uppercase tracking-wider text-white/40">Total</span>
          <span className="font-display text-right text-sm font-black text-rose-200">
            <Coin />{formatCoins(bTotal)}
          </span>
        </div>
      )}
    </div>
  );
}
