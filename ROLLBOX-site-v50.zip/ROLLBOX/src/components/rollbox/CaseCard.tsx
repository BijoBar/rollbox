"use client";

import { useRef, useState } from "react";
import Link from "next/link";
import { Lock, ChevronRight, Gift } from "lucide-react";
import { type CaseDef, formatCoins } from "@/lib/cases";
import { useSession } from "@/lib/session";
import { CaseImage } from "./CaseImage";
import { Coin } from "./Coin";
import { sfx } from "@/lib/sound";

export function CaseCard({ caseDef, index }: { caseDef: CaseDef; index: number }) {
  const ref = useRef<HTMLAnchorElement>(null);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0 });
  const [mx, setMx] = useState(50);
  const [my, setMy] = useState(50);
  // USER SPEC (Task 183): a player who owns FREE boxes of THIS case sees a
  // FREE ×N chip right next to the case name; no free boxes → plain name.
  const { player } = useSession();
  const freeCount = player?.freeCases?.[caseDef.id] ?? 0;

  const handleMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    setTilt({ rx: (0.5 - py) * 9, ry: (px - 0.5) * 9 });
    setMx(px * 100);
    setMy(py * 100);
  };

  return (
    <Link
      ref={ref}
      href={`/case/${caseDef.id}`}
      onMouseMove={handleMove}
      onMouseLeave={() => setTilt({ rx: 0, ry: 0 })}
      onClick={() => sfx.click()}
      aria-label={`${caseDef.name} (${caseDef.code}) — open case page`}
      className="group relative block min-w-0 [perspective:900px]"
      style={{ animationDelay: `${index * 0.08}s` }}
    >
      <div
        className="relative flex flex-col overflow-hidden rounded-2xl border bg-[#120c20]/90 transition-[border-color,box-shadow] duration-300"
        style={{
          borderColor: caseDef.tierColor + "44",
          transform: `rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`,
          transition: "transform 0.15s ease-out, box-shadow 0.3s ease",
          boxShadow: `0 10px 40px -12px ${caseDef.tierColor}35`,
        }}
      >
        {/* cursor glow */}
        <div
          className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{
            background: `radial-gradient(circle 220px at ${mx}% ${my}%, ${caseDef.tierColor}26, transparent 70%)`,
          }}
          aria-hidden="true"
        />
        {/* top gradient line */}
        <div
          className="h-1 w-full"
          style={{ background: `linear-gradient(90deg, ${caseDef.tierColor}, ${caseDef.tierColor2})` }}
          aria-hidden="true"
        />

        <div className="relative flex flex-col items-center px-5 pb-5 pt-7">
          {/* id + tier chips */}
          <span className="absolute left-4 top-4 rounded-md border border-white/15 bg-black/40 px-2 py-1 font-mono text-[10px] font-black tracking-widest text-white/60 transition-colors group-hover:border-white/30 group-hover:text-white/85">
            {caseDef.code}
          </span>
          <span
            className="absolute right-4 top-4 rounded-full border px-2.5 py-1 text-[10px] font-black tracking-wide"
            style={{
              borderColor: caseDef.tierColor + "55",
              color: caseDef.tierColor,
              background: caseDef.tierColor + "14",
            }}
          >
            {caseDef.tierLabel}
          </span>

          <div className="relative w-44 transition-transform duration-300 group-hover:scale-110 md:w-48">
            <div
              className="absolute inset-0 -z-10 blur-2xl"
              style={{ background: `radial-gradient(circle at 50% 60%, ${caseDef.tierColor}30, transparent 65%)` }}
              aria-hidden="true"
            />
            <CaseImage
              caseId={caseDef.id}
              alt={caseDef.name}
              color={caseDef.tierColor}
              color2={caseDef.tierColor2}
              communityDesign={caseDef.communityDesign}
              className="w-full"
              sizes="(max-width: 768px) 45vw, 192px"
            />
          </div>

          <h3 className="mt-3 flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-2xl font-black text-white">
            {caseDef.name}
            {freeCount > 0 && (
              <span
                data-freechip="1"
                title={`${freeCount} free ${caseDef.name} box${freeCount === 1 ? "" : "es"} in your account — they open at no charge`}
                className="flex items-center gap-1 rounded-md border border-emerald-400/50 bg-emerald-500/15 px-1.5 py-0.5 align-middle text-[11px] font-black uppercase tracking-wider text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.35)]"
              >
                <Gift className="h-3 w-3" />
                FREE ×{freeCount}
              </span>
            )}
          </h3>

          {/* USER SPEC (Task 88): the per-case description and the "top drops"
              skin preview are gone — the card is now name + art + price only. */}

          {/* open page button */}
          <span
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl py-3.5 text-base font-black text-white transition-all group-hover:brightness-110"
            style={{
              background: `linear-gradient(94deg, ${caseDef.tierColor2}, ${caseDef.tierColor})`,
              boxShadow: `0 0 22px ${caseDef.tierColor}55, inset 0 1px 0 rgba(255,255,255,0.3)`,
            }}
          >
            <Lock className="h-4.5 w-4.5" />
            Open Case • <Coin />{formatCoins(caseDef.price)}
            <ChevronRight className="h-4.5 w-4.5 transition-transform group-hover:translate-x-1" />
          </span>
          {/* USER SPEC (Task 177): the "Completely fair odds — Provably Fair"
              caption under the case cards is DELETED from the home screen. */}
        </div>
      </div>
    </Link>
  );
}
