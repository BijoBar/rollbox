"use client";

import { RARITY_META, SKINS, formatCoins, type Rarity } from "@/lib/cases";
import { displayWearLabel, wearColorOf, wearShortOf } from "@/lib/wear";
import { SkinImage } from "./SkinImage";
import { Coin } from "./Coin";
import { RarityBackdrop } from "./RarityBackdrop";
import { cn } from "@/lib/utils";

/** Reusable skin tile: rarity glow bg + weapon art + name strip.
 *  Task 72: `wear` (full label) overrides the registry wear for wear-specific
 *  case items; `valueOverride` shows the wear-adjusted price.
 *  Task 97 (USER SPEC): `bare` strips ALL box chrome (border / background /
 *  rarity panel / wear badge) — the roulette tile becomes a TRANSPARENT
 *  square: only the eclipse + weapon art float on the reel. The square still
 *  reserves its area (layout only) so the winner details text can sit on it
 *  via `children`.
 *  PERF (Task 100): `artShadow=false` drops the per-tile CSS drop-shadow
 *  filter — 400+ filtered images re-rasterizing every spin frame were a top
 *  jank source. The WINNER tile keeps its shadow (it sits still on screen). */
export function SkinTile({
  skinId,
  className,
  artClassName,
  showValue = true,
  compact = false,
  style,
  wear,
  valueOverride,
  bare = false,
  artShadow = true,
  children,
}: {
  skinId: string;
  className?: string;
  artClassName?: string;
  showValue?: boolean;
  compact?: boolean;
  style?: React.CSSProperties;
  wear?: string;
  valueOverride?: number;
  bare?: boolean;
  artShadow?: boolean;
  children?: React.ReactNode;
}) {
  const skin = SKINS[skinId];
  if (!skin) return null;
  const rarity = RARITY_META[skin.rarity];
  // R43 USER SPEC: a skin NEVER shows without its exterior — no pinned wear
  // (tile or registry) means the default one (Field-Tested), in ITS color.
  const wearLabel = displayWearLabel(wear ?? skin.wear);

  return (
    <div
      className={cn(
        "relative flex flex-col overflow-hidden rounded-lg",
        !bare && "border bg-[#161028]",
        className
      )}
      style={
        bare
          ? style
          : {
              borderColor: rarity.color + "66",
              boxShadow: `0 0 14px ${rarity.color}30, inset 0 -18px 26px -14px ${rarity.color}55`,
              ...style,
            }
      }
    >
      {/* USER SPEC (Task 89/89b): the rarity glow is now the user's ECLIPSE
          artwork — one moon per rarity, behind the weapon art.
          USER SPEC (Task 132): the emblem sat too HIGH in the regular case
          opening (reel + case grid) — the backdrop box is pushed down by
          exactly 12% of the tile height (top 0% -> top 12%, height kept at
          72%). Battles keep their own centered boxes (BattleReel/BattleRoom
          untouched); tune the 12% number to adjust. */}
      <RarityBackdrop rarity={skin.rarity} className="inset-x-0 top-[12%] h-[72%]" />
      {!bare && wearLabel && (
        <span
          className="absolute left-1 top-1 z-10 rounded bg-black/65 px-1 py-px text-[7px] font-black uppercase tracking-wider backdrop-blur-sm"
          style={{ color: wearColorOf(wearLabel) }}
          title={`Exterior: ${wearLabel}`}
        >
          {wearShortOf(wearLabel)}
        </span>
      )}
      {skin.rarity === "contraband" && (
        <span
          className="absolute right-1 top-1 z-10 grid h-4 w-4 place-items-center rounded bg-gradient-to-br from-amber-200 via-amber-400 to-yellow-600 text-[9px] leading-none text-yellow-950 shadow-[0_0_10px_rgba(240,185,11,0.85)]"
          title="★ Rare Special Item"
          aria-label="Rare Special Item"
        >
          ★
        </span>
      )}
      <div className="relative flex flex-1 items-center justify-center px-1.5 pt-2">
        <SkinImage
          skinId={skinId}
          kind={skin.weapon}
          colors={skin.colors}
          alt={skin.name}
          className={cn("w-full max-w-[92%]", artShadow && "drop-shadow-lg", artClassName)}
        />
      </div>
      {!compact && (
        <div
          className="relative mt-auto w-full px-1.5 pb-1 pt-2 text-center"
          style={{ background: `linear-gradient(180deg, transparent, ${rarity.color}22 60%, ${rarity.color}30)` }}
        >
          <p className="truncate text-[10px] font-semibold leading-tight text-white/90">
            {skin.name}
          </p>
          {showValue && (
            <p className="font-display text-[10px] font-bold leading-tight" style={{ color: "#f0b90b" }}>
              {/* Task 76: formatCoins — cent values render exactly (8.85), no float noise */}
              <Coin /> {formatCoins(valueOverride ?? skin.value)}
            </p>
          )}
        </div>
      )}
      {/* Task 97: overlay slot — the winner details render ON the bare square */}
      {children}
    </div>
  );
}

/** Small chip used in live-drops ticker. USER SPEC (Task 32): enlarged ~35%
 *  (h-14→h-19, w-40→w-54, art h-7→h-9.5) so the skin art is clearly readable.
 *  USER SPEC (R44): the exterior reads as the FULL condition name
 *  ("Minimal Wear"), not the short code — LiveDrops is the only consumer. */
export function DropChip({
  skinId,
  user,
  wear,
}: {
  skinId: string;
  user: string;
  wear?: string;
}) {
  const skin = SKINS[skinId];
  if (!skin) return null;
  const rarity = RARITY_META[skin.rarity];
  const wearLabel = displayWearLabel(wear); // R43: always carries an exterior
  return (
    <div
      className="flex h-19 w-54 shrink-0 items-center gap-2.5 rounded-lg border bg-[#161028]/90 px-2.5"
      style={{ borderColor: rarity.color + "55", boxShadow: `0 0 12px ${rarity.color}25` }}
    >
      <SkinImage skinId={skinId} kind={skin.weapon} colors={skin.colors} className="h-9.5 w-19 shrink-0" alt={skin.name} />
      <div className="min-w-0 flex-1">
        <p className="truncate text-[11px] font-semibold text-white/85">{user}</p>
        <p className="truncate text-[10px] leading-tight" style={{ color: rarity.color }}>
          {skin.name}
        </p>
        <p
          className="truncate text-[9px] font-black leading-tight tracking-wide"
          style={{ color: wearColorOf(wearLabel) }}
          title={`Exterior: ${wearLabel}`}
        >
          {wearLabel}
        </p>
      </div>
    </div>
  );
}

export const rarityColor = (r: Rarity) => RARITY_META[r].color;
