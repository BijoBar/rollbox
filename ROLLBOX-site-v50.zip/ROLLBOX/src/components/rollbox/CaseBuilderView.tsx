"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Check, CheckCircle2, Layers, LogIn, Minus, Plus, Search, Sparkles, Trash2, Wand2, X } from "lucide-react";
import { SKINS, caseItemValue, formatCoins, RARITY_META, type Rarity } from "@/lib/cases";
import { displayWearLabel, wearColorOf } from "@/lib/wear";
import { COMMUNITY_HOUSE_EDGE, COMMUNITY_MAX_ITEMS } from "@/lib/community-designs";
import { builderComplete, totalWeightOf, useCaseBuilder } from "@/lib/case-builder";
import { useSession } from "@/lib/session";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { SkinImage } from "./SkinImage";
import { Coin } from "./Coin";

/**
 * USER SPEC (Task 142) — CASE BUILDER, step 1/2.
 * The player picks up to 10 skins for his case; every skin gets a drop
 * chance and the chances MUST total exactly 100% before NEXT unlocks. The
 * site prices the case automatically (EV of the contents / 0.85 → 15% house
 * edge) and the price preview updates live.
 */

const SEARCH_LIMIT = 48;

export function CaseBuilderView() {
  const mounted = useMounted();
  const { player: me } = useSession();
  const { toast } = useToast();
  const router = useRouter();

  const items = useCaseBuilder((s) => s.items);
  const addItem = useCaseBuilder((s) => s.addItem);
  const removeItem = useCaseBuilder((s) => s.removeItem);
  const setWeight = useCaseBuilder((s) => s.setWeight);
  const bumpWeight = useCaseBuilder((s) => s.bumpWeight);
  const splitEvenly = useCaseBuilder((s) => s.splitEvenly);

  const [query, setQuery] = useState("");

  const allSkins = useMemo(() => Object.values(SKINS).sort((a, b) => b.value - a.value), []);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q ? allSkins.filter((s) => s.name.toLowerCase().includes(q)) : allSkins;
    return list.slice(0, SEARCH_LIMIT);
  }, [allSkins, query]);

  const selected = useMemo(() => {
    const map = new Map(items.map((i) => [i.skinId, i.weight]));
    return allSkins.filter((s) => map.has(s.id)).map((s) => ({ skin: s, weight: map.get(s.id)! }));
  }, [allSkins, items]);

  const total = totalWeightOf(items);
  const complete = builderComplete(items);
  // the automatic site price — the same math the server re-runs on publish
  const price = useMemo(() => {
    const ev = items.reduce((sum, i) => sum + (i.weight / 100) * caseItemValue({ skinId: i.skinId, weight: i.weight }), 0);
    return Math.max(0.5, Math.ceil((ev / COMMUNITY_HOUSE_EDGE) * 100) / 100);
  }, [items]);

  if (!mounted) return null;

  if (!me) {
    return (
      <section className="mx-auto max-w-xl px-4 py-20 text-center">
        <Sparkles className="mx-auto mb-4 h-10 w-10 text-violet-300" />
        <h1 className="font-display text-2xl font-black text-white">CREATE YOUR OWN CASE</h1>
        <p className="mx-auto mt-3 max-w-sm text-sm font-semibold leading-relaxed text-white/55">
          Sign in with Steam to build a case from your favorite skins, set the drop chances and
          publish it for the whole site to open.
        </p>
        <Link
          href="/login"
          className="neon-btn mt-6 inline-flex items-center gap-2 rounded-xl px-6 py-2.5 text-sm font-black text-white"
          onClick={() => sfx.click()}
        >
          <LogIn className="h-4 w-4" />
          Sign In
        </Link>
      </section>
    );
  }

  const pick = (skinId: string) => {
    if (items.some((i) => i.skinId === skinId)) {
      removeItem(skinId);
      sfx.click();
      return;
    }
    if (!addItem(skinId)) {
      toast({ title: `A case holds at most ${COMMUNITY_MAX_ITEMS} skins` });
      return;
    }
    sfx.click();
  };

  return (
    <section className="mx-auto max-w-7xl px-4 py-10" aria-label="Create your own case — pick skins">
      {/* heading */}
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="text-center">
        <h1 className="text-3xl font-black text-white md:text-4xl">
          Create <span className="text-gradient-neon">your own case</span>
        </h1>
        <p className="mt-2 text-xs font-semibold tracking-wide text-white/45">
          STEP 1 OF 2 — PICK UP TO {COMMUNITY_MAX_ITEMS} SKINS AND SET THE DROP CHANCES (MUST TOTAL 100%)
        </p>
      </motion.div>

      <div className="mt-8 grid gap-5 lg:grid-cols-[1fr_340px]">
        {/* ===== the catalog ===== */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
          <div className="flex h-11 items-center gap-2 rounded-xl border border-white/15 bg-black/40 px-3">
            <Search className="h-4 w-4 shrink-0 text-white/35" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              dir="ltr"
              placeholder="Search the skin catalog…"
              aria-label="Search skins"
              className="w-full bg-transparent text-sm font-bold text-white placeholder:text-white/30 focus:outline-none"
            />
            {query && (
              <button type="button" onClick={() => setQuery("")} aria-label="Clear search">
                <X className="h-4 w-4 text-white/40 hover:text-white" />
              </button>
            )}
          </div>
          <p className="mt-2 text-[10px] font-bold uppercase tracking-widest text-white/30">
            {filtered.length} shown{query ? "" : " — tap a skin to add or remove it"} • catalog holds {allSkins.length} skins
          </p>
          <div className="mt-3 grid max-h-[560px] grid-cols-2 content-start gap-2 overflow-y-auto pr-1 sm:grid-cols-3 xl:grid-cols-4">
            {filtered.map((s) => {
              const picked = items.some((i) => i.skinId === s.id);
              const rar = RARITY_META[s.rarity as Rarity];
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => pick(s.id)}
                  aria-label={picked ? `Remove ${s.name}` : `Add ${s.name}`}
                  className={
                    "group relative flex flex-col items-center gap-1 rounded-xl border p-2 text-center transition-all hover:bg-white/[0.06] " +
                    (picked ? "border-emerald-400/70 bg-emerald-400/10" : "border-white/10 bg-black/30")
                  }
                >
                  {picked && (
                    <span className="absolute right-1.5 top-1.5 grid h-4.5 w-4.5 place-items-center rounded-full bg-emerald-500 text-black">
                      <Check className="h-3 w-3" strokeWidth={3.5} />
                    </span>
                  )}
                  <SkinImage skinId={s.id} kind={s.weapon} colors={s.colors} className="h-12 w-full object-contain" alt={s.name} />
                  <span className="w-full truncate text-[10px] font-bold text-white/85" dir="ltr" title={s.name}>
                    {s.name}
                  </span>
                  {/* R43 USER SPEC: every skin lists its exterior — in its color */}
                  <span
                    className="w-full truncate text-[9px] font-black uppercase tracking-wider"
                    dir="ltr"
                    style={{ color: wearColorOf(s.wear) }}
                    title={`Exterior: ${displayWearLabel(s.wear)}`}
                  >
                    {displayWearLabel(s.wear)}
                  </span>
                  <span className="font-display flex items-center gap-0.5 text-[11px] font-black" style={{ color: rar?.color ?? "#8882a8" }}>
                    <Coin className="h-3 w-3" /> {formatCoins(s.value)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* ===== the draft ===== */}
        <aside className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/[0.02] p-4" data-testid="builder-draft">
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-white/60">
              <Layers className="h-4 w-4 text-violet-300" />
              Your skins
            </p>
            <span className={"rounded-full px-2 py-0.5 text-[11px] font-black " + (items.length >= COMMUNITY_MAX_ITEMS ? "bg-amber-400/20 text-amber-300" : "bg-violet-500/20 text-violet-200")}>
              {items.length}/{COMMUNITY_MAX_ITEMS}
            </span>
          </div>

          {selected.length === 0 ? (
            <div className="grid place-items-center gap-2 rounded-xl border border-dashed border-white/12 py-10 text-center">
              <p className="text-sm font-bold text-white/50">No skins yet</p>
              <p className="max-w-52 text-xs font-semibold leading-relaxed text-white/35">
                Tap skins from the catalog to drop them into your case.
              </p>
            </div>
          ) : (
            <div className="flex max-h-[420px] flex-col gap-2 overflow-y-auto pr-1">
              {selected.map(({ skin, weight }) => {
                const rar = RARITY_META[skin.rarity as Rarity];
                return (
                  <div key={skin.id} className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/30 p-2">
                    <SkinImage skinId={skin.id} kind={skin.weapon} colors={skin.colors} className="h-9 w-10 shrink-0 object-contain" alt={skin.name} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[11px] font-bold text-white/85" dir="ltr" title={skin.name}>
                        {skin.name}
                      </p>
                      {/* R43 USER SPEC: the drafted skin's exterior — in its color */}
                      <p
                        className="truncate text-[9px] font-black uppercase tracking-wider"
                        dir="ltr"
                        style={{ color: wearColorOf(skin.wear) }}
                        title={`Exterior: ${displayWearLabel(skin.wear)}`}
                      >
                        {displayWearLabel(skin.wear)}
                      </p>
                      <p className="font-display flex items-center gap-0.5 text-[10px] font-black" style={{ color: rar?.color ?? "#8882a8" }}>
                        <Coin className="h-2.5 w-2.5" /> {formatCoins(caseItemValue({ skinId: skin.id, weight }))}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1" dir="ltr">
                      <button
                        type="button"
                        onClick={() => {
                          bumpWeight(skin.id, -1);
                          sfx.click();
                        }}
                        aria-label={`Decrease ${skin.name} chance`}
                        className="grid h-6 w-6 place-items-center rounded-md border border-white/15 bg-white/5 text-white/70 hover:bg-white/15"
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <input
                        value={String(weight)}
                        onChange={(e) => setWeight(skin.id, Number(e.target.value.replace(/[^0-9.]/g, "")) || 0)}
                        dir="ltr"
                        inputMode="decimal"
                        aria-label={`${skin.name} drop chance percent`}
                        className="h-6 w-12 rounded-md border border-white/15 bg-black/50 text-center text-[11px] font-black text-amber-300 tabular-nums focus:border-amber-400/60 focus:outline-none"
                      />
                      <span className="text-[9px] font-black text-white/40">%</span>
                      <button
                        type="button"
                        onClick={() => {
                          bumpWeight(skin.id, 1);
                          sfx.click();
                        }}
                        aria-label={`Increase ${skin.name} chance`}
                        className="grid h-6 w-6 place-items-center rounded-md border border-white/15 bg-white/5 text-white/70 hover:bg-white/15"
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        removeItem(skin.id);
                        sfx.click();
                      }}
                      aria-label={`Remove ${skin.name}`}
                      className="shrink-0 rounded-md border border-red-400/30 bg-red-500/10 p-1 text-red-300 hover:bg-red-500/25"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {selected.length > 0 && (
            <button
              type="button"
              onClick={() => {
                splitEvenly();
                sfx.click();
              }}
              className="flex items-center justify-center gap-1.5 rounded-lg border border-white/15 bg-white/5 py-1.5 text-[10px] font-black uppercase tracking-widest text-white/70 hover:bg-white/15 hover:text-white"
            >
              <Wand2 className="h-3.5 w-3.5" />
              Split evenly
            </button>
          )}

          {/* live total + price */}
          <div className="mt-auto flex flex-col gap-2 rounded-xl border border-white/10 bg-black/40 p-3">
            <p className="flex items-center justify-between text-xs font-bold text-white/55">
              <span>Total drop chances</span>
              <span
                className={
                  "font-display flex items-center gap-1 text-sm font-black tabular-nums " +
                  (complete ? "text-emerald-300" : "text-amber-300")
                }
              >
                {complete && <CheckCircle2 className="h-4 w-4" />}
                {total.toFixed(2)}%
              </span>
            </p>
            <p className="flex items-center justify-between text-xs font-bold text-white/55">
              <span>Automatic case price</span>
              <span className="font-display flex items-center gap-1 text-sm font-black text-amber-300" title="Expected payout of the contents ÷ 0.85 — a 15% house edge for the site">
                <Coin className="h-3.5 w-3.5" /> {formatCoins(price)}
              </span>
            </p>
            <p className="text-[9px] font-semibold leading-relaxed text-white/30" dir="ltr">
              Priced by the site: expected payout / {COMMUNITY_HOUSE_EDGE} (15% house edge).
            </p>
          </div>
        </aside>
      </div>

      {/* ===== bottom bar — NEXT bottom-right (USER SPEC) ===== */}
      <div className="mt-6 flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.02] px-4 py-3">
        <p className={"text-xs font-bold " + (complete ? "text-emerald-300" : "text-white/45")}>
          {items.length === 0
            ? "Pick at least one skin to continue."
            : complete
              ? "Perfect — exactly 100%. Continue to the design."
              : `Set the chances to total exactly 100% to continue (now ${total.toFixed(2)}%).`}
        </p>
        <button
          type="button"
          disabled={!complete}
          onClick={() => {
            sfx.click();
            router.push("/case-builder/design");
          }}
          className="gold-btn flex h-11 shrink-0 items-center gap-2 rounded-xl px-6 text-sm font-black text-black disabled:cursor-not-allowed disabled:opacity-40"
          aria-label="Next — choose the design"
          data-testid="builder-next"
        >
          NEXT
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </section>
  );
}
