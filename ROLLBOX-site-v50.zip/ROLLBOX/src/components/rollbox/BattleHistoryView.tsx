"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Coins, RotateCcw, Swords, Zap } from "lucide-react";
import { CASES, formatCoins, type CaseDef } from "@/lib/cases";
import { useSession } from "@/lib/session";
import { sfx } from "@/lib/sound";
import { CaseDropsDialog } from "./CaseDropsDialog";
import { CaseImage } from "./CaseImage";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";
import { useMounted } from "@/hooks/use-mounted";

/* ===== USER SPEC (Task 81): the dedicated BATTLE HISTORY page =====
   Moved OFF the main profile (the header button that replaced SIGN OUT
   lands here). Every finished battle renders its W/L, the join code, the
   pot setup, the ACTUAL CASE ARTWORK of the battle (up to the first 7
   crates) and — on the crates' right side — a RECREATE button that re-stacks
   the very same battle on the create-battle screen (never auto-started: the
   player can add cases or change any setting before creating). */

/** One finished battle as the history page renders it (server shape). */
interface BattleHistoryRow {
  id: string;
  code: string;
  type: string;
  mode: string;
  potRule: string;
  result: "W" | "L";
  entry: number;
  take: number;
  net: number;
  caseCount: number;
  caseIds: string[];
  players: { name: string; avatar: string | null; isBot: boolean; team: number; winner: boolean }[];
  finishedAt: number;
}

interface BattleStatsData {
  totals: { battles: number; wins: number; losses: number; winRate: number };
  history: BattleHistoryRow[];
}

/** The neon W/L chip — W = NEON GREEN, L = NEON RED (same language as the profile). */
function ResultBadge({ result }: { result: "W" | "L" }) {
  const win = result === "W";
  return (
    <span
      className={`font-display grid h-9 w-9 shrink-0 place-items-center rounded-lg border font-black ${
        win
          ? "border-emerald-400/70 bg-emerald-500/15 text-emerald-300 shadow-[0_0_14px_rgba(52,211,153,0.6),inset_0_0_8px_rgba(52,211,153,0.25)]"
          : "border-rose-500/70 bg-rose-500/15 text-rose-300 shadow-[0_0_14px_rgba(244,63,94,0.6),inset_0_0_8px_rgba(244,63,94,0.25)]"
      }`}
      title={win ? "Won" : "Lost"}
      dir="ltr"
    >
      {result}
    </span>
  );
}

/** One crate of the battle — the REAL case artwork (up to 7 per battle).
 *  USER SPEC (Task 82): the crate ITSELF is the button — click opens the
 *  case's full skin pool (VIEW DROPS without the text — just the box). */
function HistoryCaseTile({ caseId, onOpen }: { caseId: string; onOpen: (cs: CaseDef) => void }) {
  const cs = CASES.find((c) => c.id === caseId);
  if (!cs) return null;
  return (
    <button
      type="button"
      onClick={() => {
        sfx.click();
        onOpen(cs);
      }}
      className="w-14 shrink-0 cursor-pointer rounded-lg border border-white/10 bg-black/30 p-1 transition-all hover:scale-105 hover:border-amber-300/60 hover:bg-amber-400/10 sm:w-16"
      title={`View the skins inside ${cs.name}`}
      aria-label={`View the drops of ${cs.name}`}
    >
      <CaseImage caseId={cs.id} alt={cs.name} color={cs.tierColor} color2={cs.tierColor2} communityDesign={cs.communityDesign} sizes="64px" />
    </button>
  );
}

export function BattleHistoryView() {
  const mounted = useMounted();
  const { player: me } = useSession();
  const [data, setData] = useState<BattleStatsData | null>(null);
  // USER SPEC (Task 82): clicking a crate opens its contents right here
  const [dropsCase, setDropsCase] = useState<CaseDef | null>(null);

  // server truth first — the browser mirror (rb_battle_history_v1, written by
  // the profile) paints the list instantly while the fetch is in flight
  useEffect(() => {
    if (!me) return;
    let alive = true;
    // the mirror paint is deferred one tick — off the effect's sync body
    const mirrorTimer = window.setTimeout(() => {
      if (!alive) return;
      try {
        const raw = localStorage.getItem("rb_battle_history_v1");
        if (!raw) return;
        const history = JSON.parse(raw) as BattleHistoryRow[];
        if (!Array.isArray(history) || !history.length) return;
        setData((prev) => {
          if (prev) return prev;
          const wins = history.filter((h) => h.result === "W").length;
          return {
            totals: {
              battles: history.length,
              wins,
              losses: history.length - wins,
              winRate: Math.round((wins / history.length) * 1000) / 10,
            },
            history,
          };
        });
      } catch {
        /* corrupted mirror — the server response replaces it */
      }
    }, 0);
    void (async () => {
      try {
        const r = await fetch("/api/profile/battles", { cache: "no-store" });
        if (!r.ok) return;
        const fresh = (await r.json()) as BattleStatsData;
        if (alive) setData(fresh);
      } catch {
        /* the mirror above keeps the page alive offline */
      }
    })();
    return () => {
      alive = false;
      window.clearTimeout(mirrorTimer);
    };
  }, [me]);

  const history = mounted ? (data?.history ?? []) : [];

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-8" aria-label="Battle history">
        <div className="relative mx-auto max-w-5xl px-4">
          {/* header */}
          <div className="flex items-center gap-3">
            <Link
              href="/profile"
              onClick={() => sfx.click()}
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
              aria-label="Back to the profile"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <div>
              <h1 className="font-display text-2xl font-black tracking-wide text-white sm:text-3xl">
                BATTLE <span className="text-gradient-neon">HISTORY</span>
              </h1>
              <p className="text-xs font-semibold text-white/45">
                Every battle you played — the crates that were opened and one-tap recreate.
              </p>
            </div>
          </div>

          {/* totals strip */}
          {data && data.totals.battles > 0 && (
            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { label: "Battles Played", value: data.totals.battles.toLocaleString(), color: "text-sky-300" },
                { label: "Battles Won", value: data.totals.wins.toLocaleString(), color: "text-emerald-300" },
                { label: "Battles Lost", value: data.totals.losses.toLocaleString(), color: "text-rose-300" },
                { label: "Win Rate", value: `${data.totals.winRate.toLocaleString()}%`, color: "text-amber-300" },
              ].map((s) => (
                <div key={s.label} className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3 text-center">
                  <p className={`font-display text-xl font-black ${s.color}`}>{s.value}</p>
                  <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wide text-white/45">{s.label}</p>
                </div>
              ))}
            </div>
          )}

          {/* the list */}
          {!mounted || history.length === 0 ? (
            <div className="mt-6 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-12 text-center">
              <Swords className="mx-auto mb-3 h-10 w-10 text-white/25" />
              <p className="text-sm font-bold text-white/60">No battles in the history yet</p>
              <p className="mt-1 text-xs text-white/40">
                Create your first battle in the lobby — results, pot rules and payouts will be recorded here.
              </p>
              <Link
                href="/battles"
                className="neon-btn mt-4 inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-black text-white"
              >
                <Zap className="h-3.5 w-3.5" fill="currentColor" />
                Go to Battles
              </Link>
            </div>
          ) : (
            <motion.ul
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="mt-6 overflow-hidden rounded-2xl border border-white/10"
              aria-label="Finished battles"
            >
              {history.map((h) => {
                const shown = h.caseIds.slice(0, 7);
                const extra = h.caseCount - shown.length;
                return (
                  <li
                    key={h.id}
                    className="flex flex-col gap-3 border-t border-white/5 bg-white/[0.015] px-4 py-4 first:border-t-0 lg:flex-row lg:items-center"
                  >
                    {/* W/L + code + setup */}
                    <div className="flex min-w-0 items-start gap-3 lg:w-[300px] lg:shrink-0">
                      <ResultBadge result={h.result} />
                      <div className="min-w-0">
                        <p className="font-display truncate text-sm font-black text-white" dir="ltr">
                          {h.code}
                        </p>
                        <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wide text-white/45" dir="ltr">
                          {h.type} • {h.mode} • {h.potRule}
                        </p>
                        <p className="mt-0.5 text-[10px] text-white/35" dir="ltr">
                          {new Date(h.finishedAt).toLocaleString("en-US", {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: false,
                          })}
                        </p>
                        <p
                          className={`font-display mt-1 text-xs font-black ${h.net >= 0 ? "text-emerald-300" : "text-rose-300"}`}
                          dir="ltr"
                        >
                          {h.net >= 0 ? "+" : "-"}
                          <Coin /> {formatCoins(Math.abs(h.net))}
                          <span className="ml-1 text-[10px] font-bold text-white/35">
                            (entry {formatCoins(h.entry)} • took {formatCoins(h.take)})
                          </span>
                        </p>
                      </div>
                    </div>

                    {/* the crates that were opened + RECREATE on their right */}
                    <div className="flex min-w-0 flex-1 items-center gap-3">
                      <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5" dir="ltr">
                        {shown.map((cid, i) => (
                          <HistoryCaseTile key={`${cid}-${i}`} caseId={cid} onOpen={setDropsCase} />
                        ))}
                        {extra > 0 && (
                          <span
                            className="font-display grid h-10 w-10 shrink-0 place-items-center rounded-lg border border-white/10 bg-white/[0.04] text-[10px] font-black text-white/55"
                            title={`${extra} more case${extra !== 1 ? "s" : ""} in this battle`}
                            dir="ltr"
                          >
                            +{extra}
                          </span>
                        )}
                      </div>
                      {/* USER SPEC (Task 81): RECREATE — same battle, same crates,
                          straight onto the create screen (NEVER auto-started):
                          add cases or change any setting, then create it */}
                      <Link
                        href={`/battles/new?recreate=${h.id}`}
                        onClick={() => sfx.click()}
                        aria-label={`Recreate battle ${h.code}`}
                        className="gold-btn flex shrink-0 items-center gap-1.5 rounded-lg px-3.5 py-2.5 text-[11px] font-black text-black transition-transform hover:scale-[1.03]"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        RECREATE
                      </Link>
                    </div>
                  </li>
                );
              })}
            </motion.ul>
          )}

          {/* USER SPEC (Task 82): the crates' contents overlay — the same
              VIEW DROPS dialog the battle room uses, opened by a bare click */}
          <CaseDropsDialog
            caseDef={dropsCase}
            open={!!dropsCase}
            onOpenChange={(v) => {
              if (!v) setDropsCase(null);
            }}
          />

          {/* the mirror note — the history also lives in this browser */}
          <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[11px] text-white/35">
            <Coins className="h-3 w-3" aria-hidden="true" />
            Kept on the server AND mirrored to this browser, so it survives refreshes and revisits.
          </p>
        </div>
      </main>
    </SiteShell>
  );
}
