"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { SKINS, skinWithWear, formatCoins, type CaseDef, type WearId } from "@/lib/cases";
import { displayWearLabel, wearColorOf } from "@/lib/wear";
import { ROLLDROP_MARKER } from "@/lib/rolldrop";
import { sfx } from "@/lib/sound";
import { edgingClock, edgingGlidePx, edgingPhases, edgingRoll } from "@/lib/utils";
import { mulberry32, rngFrom, type Rng } from "@/lib/seeded";
import { SkinImage } from "./SkinImage";
import { RolldropTile } from "./RolldropTile";
import { RarityBackdrop } from "./RarityBackdrop";
import { GOLD_FLASH_BG } from "./CaseOpener";

/* ===== battle reel — the room's cinematic roulette, REBUILT (Task 80) =====
   Extracted into its own component for the battle room (local + global).
   USER SPEC (Task 57): the reel FILLS the seat's square — the room passes
   `className="h-full rounded-none border-0"` and the default fixed-height
   box styling yields.
   USER SPEC (Task 80 + hotfix): the viewport is the seat's SQUARE, but the
   scrolling SKIN CELL is WIDE (2:1 — 50% of the viewport height) and fully
   TRANSPARENT. The old full-square cell was exactly as tall as the viewport,
   so a single (short, wide) skin art floated in a sea of background — a huge
   empty band at the bottom of the square, worst in 1v1 where the seat is
   widest. The 2:1 cell keeps ~2 skins in the viewport at all times (a skin
   ALWAYS crosses the bottom edge — no background gap) AND, once locked,
   leaves the neighbours' skins peeking a quarter-cell in above and below the
   winner (USER SPEC: critical for the tension effect). No tile frame — the
   skin floats on the room — and the winner caption sits right on it, NO
   backdrop:
     weapon type  — small but readable (dark white, not gray)
     skin name    — big and clear (glowing white)
     exterior     — small but readable (gray)
     price        — big and clear (NEON green)
   A ROLLDROP pull stops ON the raredrop art (the marker tile replaces the
   winning skin — the rare round opens on the same reel).
   USER SPEC (Task 81/82 + CRITICAL fix — EDGING): the reel plays the
   boundary-rule drama: it CRAWLS its last tiles (power-6 ease) past the
   PREVIOUS skin — fully — crosses the boundary INTO the winner's zone
   (sometimes barely over it: "it just made it onto the next skin!"), holds
   a short still beat there, then SNAPS fast — mostly FORWARD (centering
   the skin it just entered), rarely a short settle-back from a touch past
   the center. The stop is ALWAYS inside the winner's own tile (hard
   clamp): the NEXT skin can never arrive at the line, so the reel can
   never be seen "hitting the next skin and rolling back" — that fake
   read is gone for good. Only THEN it locks: caption + neighbour dimming
   appear on the centered winner. No extra screen effects — pure motion.
   Pure scroll — the result is the server's, the detour is cosmetic. */

const REEL_LEN = 44;
const REEL_WINNER = 36;
const CELL_GAP = 10;

// USER SPEC (Task 177): battles adopt the CASE REEL SYSTEM AS-IS — the exact
// CaseOpener ending (Task 176): the crawl keeps moving, visibly and audibly,
// almost all the way to the settle snap (power-4 ease) instead of the shared
// power-6 that sat visually frozen for the last ~2.4s.
const CRAWL_POW = 4;

const randFrom = (pool: string[], rng: Rng = Math.random) => rngFrom(pool, rng);

/** Live cell stride measured off the strip — cells are aspect-square, so the
 *  cell height follows the seat's width and must be read from the DOM. */
function liveStride(strip: HTMLDivElement | null) {
  const t0 = strip?.children[0] as HTMLElement | undefined;
  const t1 = strip?.children[1] as HTMLElement | undefined;
  if (!t0 || !t1) return { cell: 260, gap: CELL_GAP };
  const r0 = t0.getBoundingClientRect();
  const r1 = t1.getBoundingClientRect();
  return { cell: Math.max(1, Math.round(r0.height)), gap: Math.max(0, Math.round(r1.top - r0.bottom)) };
}

/** USER SPEC (Task 80): the winner caption — weapon type (small, dark white),
 *  skin name (big, glowing white), exterior (small, gray), price (big NEON
 *  green). Sits directly ON the winner cell: the cell is centered after the
 *  lock, so a centered overlay lands exactly on it. NO backdrop box (Task 80
 *  hotfix) — a dark text-shadow keeps the four lines readable over any art.
 *  Task 141: also reused by the room's SettledSquare (a finished battle
 *  re-entered fresh renders the same four-line caption on its last drop). */
export function WinnerPlate({ skinId, wearId }: { skinId: string; wearId?: WearId }) {
  if (!SKINS[skinId]) return null; // ROLLDROP marker tiles have no skin
  const ws = skinWithWear(skinId, wearId);
  const sep = ws.name.indexOf(" | ");
  const weapon = sep > 0 ? ws.name.slice(0, sep) : ws.name;
  const skinName = sep > 0 ? ws.name.slice(sep + 3) : ws.name;
  return (
    <div
      className="anim-pop-in pointer-events-none absolute inset-x-0 top-1/2 z-30 flex -translate-y-1/2 flex-col items-center px-2"
      aria-label={`${ws.name} won — ${formatCoins(ws.value)}`}
    >
      {/* USER SPEC (Task 80 hotfix): NO backdrop box — the text floats straight
          on the winning skin; a dark text-shadow keeps every line readable */}
      <div className="flex max-w-full flex-col items-center gap-0.5 sm:gap-1">
        <span
          className="max-w-full truncate text-[10px] font-bold tracking-wide text-white/90 sm:text-xs"
          title={weapon}
          style={{ textShadow: "0 1px 6px rgba(0,0,0,0.95), 0 0 12px rgba(255,255,255,0.35)" }}
        >
          {weapon}
        </span>
        <span
          className="max-w-full truncate text-base font-black leading-tight text-white sm:text-xl"
          title={skinName}
          style={{ textShadow: "0 2px 10px rgba(0,0,0,0.9), 0 0 16px rgba(255,255,255,0.75), 0 0 40px rgba(255,255,255,0.35)" }}
        >
          {skinName}
        </span>
        {(() => {
          // R43 USER SPEC: the exterior is ALWAYS listed on the winner plate —
          // no pinned wear means the default one — and always in ITS color.
          const wl = displayWearLabel(wearId);
          return (
            <span
              className="text-[9px] font-semibold sm:text-[11px]"
              title={`Exterior: ${wl}`}
              style={{ color: wearColorOf(wl), textShadow: "0 1px 6px rgba(0,0,0,0.95)" }}
            >
              {wl}
            </span>
          );
        })()}
        <span
          className="font-display text-lg font-black leading-none text-emerald-400 sm:text-2xl"
          style={{ textShadow: "0 2px 10px rgba(0,0,0,0.9), 0 0 16px rgba(16,185,129,0.9), 0 0 44px rgba(16,185,129,0.45)" }}
        >
          {formatCoins(ws.value)}
        </span>
      </div>
    </div>
  );
}

interface ReelCell {
  key: number;
  skinId: string;
  isWinner?: boolean;
  wearId?: WearId;
}

export function BattleReel({
  caseDef,
  target,
  targetWear,
  duration,
  onDone,
  className,
  flashOnLock = true,
  rdDecoy = true,
  seed,
  startAtMs,
}: {
  caseDef: CaseDef;
  /** the winning skin id — or ROLLDROP_MARKER when this pull is a rare hit */
  target: string;
  /** Task 72: exterior of the winning item (badge + wear price on the chip) */
  targetWear?: WearId;
  duration: number;
  onDone: () => void;
  /** overrides the default fixed-height box (the room fills its square) */
  className?: string;
  flashOnLock?: boolean;
  /** Task 79: weave a ROLLDROP marker tile into the run-up (off for the RD
   *  bonus payoff reel — that reel is the prize, not a fresh chance) */
  rdDecoy?: boolean;
  /** USER SPEC (Task 31): SYNCHRONIZED REELS — a shared seed (battle id +
   *  seat + round + the pull) makes every viewer build the EXACT same strip:
   *  same filler skins, same ROLLDROP decoy position, same edging stop.
   *  Absent (solo/local one-viewer reels) → per-client Math.random as before. */
  seed?: number;
  /** USER SPEC (Task 172 — SERVER-TIME REELS): the ABSOLUTE local wall-clock
   *  (Date.now domain) moment this spin starts on the shared schedule —
   *  battle start + slot.startMs + poll offset. When present, the reel's
   *  position is a PURE FUNCTION of wall time instead of time-since-mount:
   *  a tab that slept (ALT-TAB / phone screen off) freezes its rAF, but the
   *  FIRST frame back lands EXACTLY on the server-true position — mid-spin
   *  keeps spinning from there, a fully-elapsed spin locks instantly. The
   *  reel can never "reset" or replay from zero on a wake. */
  startAtMs?: number;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const stripRef = useRef<HTMLDivElement>(null);
  const streaksRef = useRef<HTMLDivElement>(null);
  // Task 172b: boot state derives from the WALL CLOCK during the FIRST render
  // (pure computation, no effect): a reel mounted already past its lock instant
  // (frozen keepReel at a round flip, wake remount, mid-battle reload of an
  // elapsed spin) renders LOCKED from the very first paint — the old code
  // initialized false and only flipped it in the first rAF frame, flashing the
  // strip head for a frame. Legacy mount-relative reels boot unlocked as before.
  const [locked, setLocked] = useState(() => {
    if (startAtMs === undefined) return false;
    const el = Math.max(0, Date.now() - startAtMs);
    const { holdMs, settleMs } = edgingPhases(duration);
    return edgingClock(el, duration, holdMs, settleMs, CRAWL_POW).phase === "done";
  });
  const [tension, setTension] = useState(() => {
    if (startAtMs === undefined) return false;
    const el = Math.max(0, Date.now() - startAtMs);
    const { holdMs, settleMs } = edgingPhases(duration);
    return edgingClock(el, duration, holdMs, settleMs, CRAWL_POW).p > 0.84;
  });
  const tensionRef = useRef(false);
  // Task 172b: set by the pre-paint boot-seek below — the rAF loop must not
  // double-fire the lock sound + onDone when the mount was already past done.
  const preLockedRef = useRef(false);
  const onDoneRef = useRef(onDone);
  useEffect(() => {
    onDoneRef.current = onDone;
  }, [onDone]);

  // USER SPEC (Task 81/82-fix — EDGING): this reel's SIGNED stop offset,
  // drawn once per mount (the room remounts the reel every round) — a
  // fraction of the winner cell's own half-width: negative = stopped INSIDE
  // the winner's zone after crossing the boundary from the previous skin
  // (the snap continues FORWARD into the center), positive = a touch past
  // center (short snap back). Clamped to the tile — see edgingGlidePx.
  // Task 31: with a shared seed the stop offset is identical for every viewer.
  const [rng] = useState<Rng>(() => (seed !== undefined ? mulberry32(seed) : Math.random));
  const [edging] = useState(() => edgingRoll(rng));

  const pool = caseDef.items.map((i) => i.skinId);
  const isRd = target === ROLLDROP_MARKER;

  // USER SPEC (Task 79): the raredrop art ALWAYS rides EVERY battle reel —
  // a non-hit pull weaves ONE marker tile into the final run-up before the
  // stop, so the whole room watches it pass the center line among the skins
  // even when nobody wins it. Pure decoration: the reel never stops on it
  // (rdIdx < REEL_WINNER), the pull result is decided by the server and the
  // decoy is skipped when the pull itself IS the raredrop.
  const rdLo = Math.max(1, REEL_WINNER - 10);
  const rdHi = REEL_WINNER - 3;
  const rdIdx = isRd || !rdDecoy || rdHi < rdLo ? -1 : rdLo + Math.floor(rng() * (rdHi - rdLo + 1));

  // strip is built once at mount — the reel is remounted per round via key
  const [strip] = useState<ReelCell[]>(() =>
    Array.from({ length: REEL_LEN }, (_, i) => ({
      key: i,
      skinId:
        i === REEL_WINNER
          ? target
          : i === rdIdx
            ? ROLLDROP_MARKER
            : randFrom(pool, rng),
      isWinner: i === REEL_WINNER,
      wearId: i === REEL_WINNER ? targetWear : undefined,
    }))
  );

  // USER SPEC (Task 172b — TRUE FIRST PAINT): the rAF loop writes the strip's
  // transform only from its FIRST FRAME — a reel mounted already deep into its
  // schedule (a mid-round reload, a wake remount, the frozen keepReel at a
  // round flip) painted ONE frame at the strip's head before the first rAF
  // snapped it to the server-true position: a visible flash for players, and
  // a fresh keepReel read as "unlocked past its schedule" in E2E. `locked`/
  // `tension` already boot wall-clock-true (state initializers above); this
  // layout effect runs BEFORE the browser paints and seeks the strip itself.
  // When the schedule is already past done it fires the lock sound + onDone
  // exactly once (the loop's done-path is guarded by preLockedRef). Legacy
  // mount-relative reels (no startAtMs) are untouched. Deps mirror the rAF
  // effect: the reel is remounted per round via key, so this runs once.
  useLayoutEffect(() => {
    if (startAtMs === undefined) return;
    const el = Math.max(0, Date.now() - startAtMs);
    const { holdMs, settleMs } = edgingPhases(duration);
    const c = edgingClock(el, duration, holdMs, settleMs, CRAWL_POW);
    if (c.aCrawl === 0 && c.phase !== "done") return; // not started — the head IS the correct first paint
    const { cell, gap } = liveStride(stripRef.current);
    const containerH = wrapRef.current?.clientHeight ?? 300;
    const baseY = REEL_WINNER * (cell + gap) + cell / 2 - containerH / 2;
    const edgePx = edgingGlidePx(edging, cell);
    const totalY = baseY + edgePx;
    const pos = c.aCrawl * totalY - c.aSettle * edgePx;
    if (stripRef.current) stripRef.current.style.transform = `translate3d(0, ${-pos}px, 0)`;
    if (c.phase === "done") {
      if (streaksRef.current) streaksRef.current.style.opacity = "0";
      preLockedRef.current = true;
      sfx.lock();
      onDoneRef.current();
    }
  }, [duration, target, startAtMs]);

  useEffect(() => {
    // USER SPEC (Task 82-fix): the dramatic-stop timeline — a power-6 CRAWL
    // into the glide point INSIDE the winner's cell, a short still BEAT,
    // then the FAST SNAP that carries the winner to the center line. Lock +
    // caption wait for the winner to ARRIVE.
    const { holdMs, settleMs } = edgingPhases(duration);
    const t0 = performance.now();
    let raf = 0;
    let lastTick = -1;
    let lastTickAt = 0;
    let lastPos = 0;
    let lastT = 0;

    const step = (t: number) => {
      // USER SPEC (Task 172): with startAtMs the elapsed time comes from the
      // WALL CLOCK (Date.now flows normally across tab switches — rAF just
      // stops firing while hidden), so the wake frame computes the exact
      // server-true position. Clamp ≥0: a slightly-early mount idles at the
      // strip's head until the scheduled start arrives. Legacy callers (local
      // battles, spectate replay) keep mount-relative timing.
      const el = startAtMs !== undefined ? Math.max(0, Date.now() - startAtMs) : t - t0;
      // cells follow the seat width — re-measure the stride + the viewport
      // EVERY frame so a resize (or a late style resolution between mount
      // and spin) can never knock the winner off center
      const { cell, gap } = liveStride(stripRef.current);
      const containerH = wrapRef.current?.clientHeight ?? 300;
      // EDGING geometry: base = the winner dead-center; edgePx = the SIGNED
      // glide clamped to the winner's own half-width (BOUNDARY RULE — the
      // center line can never reach the next cell)
      const baseY = REEL_WINNER * (cell + gap) + cell / 2 - containerH / 2;
      const edgePx = edgingGlidePx(edging, cell);
      const totalY = baseY + edgePx;
      const c = edgingClock(el, duration, holdMs, settleMs, CRAWL_POW);
      const pos = c.aCrawl * totalY - c.aSettle * edgePx;

      // numeric velocity (px/s) → streaks + tick loudness; silent on the beat.
      // Task 177: the normalizer follows the crawl power (v0 = pow·totalY/t)
      // so streaks/ticks scale with the TRUE initial velocity, exactly like
      // the case opener's post-Task-176 normalizers.
      const dt = lastT ? Math.max(1, t - lastT) : 16;
      const vNorm = Math.min(1, Math.abs(pos - lastPos) / dt / ((CRAWL_POW * totalY) / (duration / 1000)));
      lastPos = pos;
      lastT = t;

      // vertical spin: rAF writes Y-only translate3d (no CSS translate conflicts)
      if (stripRef.current) {
        stripRef.current.style.transform = `translate3d(0, ${-pos}px, 0)`;
      }
      if (streaksRef.current) streaksRef.current.style.opacity = (vNorm * 0.75).toFixed(2);

      const now = performance.now();
      if (c.phase === "spin") {
        // ratchet ticks — one per cell passing the marker, FORWARD spin only
        // (the short snap glides silently into the lock — no backward ticks)
        const idx = Math.floor(pos / (cell + gap));
        if (idx !== lastTick && now - lastTickAt > 18) {
          lastTick = idx;
          lastTickAt = now;
          sfx.tick(vNorm);
        }
        // final-stretch tension (single state flip, guarded by ref)
        if (c.p > 0.84 && !tensionRef.current) {
          tensionRef.current = true;
          setTension(true);
        }
      }

      if (c.phase === "done") {
        // the winner has SNAPPED onto the center line — now it locks
        if (streaksRef.current) streaksRef.current.style.opacity = "0";
        setLocked(true);
        // Task 172b: a pre-paint boot-seek (layout effect below) already
        // fired the lock sound + onDone before the FIRST paint — never double.
        if (!preLockedRef.current) {
          sfx.lock();
          onDoneRef.current();
        }
        return;
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [duration, target, startAtMs]);

  const jp = locked && !isRd && SKINS[target]?.rarity === "contraband";

  /* USER SPEC (Task 80 hotfix): the room fills the seat's square with
     className="h-full ..." — but tailwind-merge can NOT cancel the default
     RESPONSIVE height (sm:h-56 survives alongside h-full, and the sm variant
     wins the cascade ≥640px). The reel then rendered 224px tall inside a
     ~376px square, leaving the seat's bare background as a dead band at the
     bottom — the BIGGER the seat (1v1), the BIGGER the band. When the caller
     brings its own h-full, the default heights yield COMPLETELY. */
  const boxBase = className?.includes("h-full")
    ? "relative overflow-hidden rounded-xl border border-white/10"
    : "relative h-44 overflow-hidden rounded-xl border border-white/10 sm:h-56";

  return (
    <div
      ref={wrapRef}
      className={cn(
        boxBase,
        "bg-[radial-gradient(ellipse_at_center,#160f2b_0%,#0b0716_72%)]",
        locked && "ring-1 ring-amber-300/40",
        className
      )}
      dir="ltr"
    >
      {/* center marker — horizontal LINE only. USER SPEC (Task 135): the
          pulsing diamond is GONE from battle reels too (was Task 134 case-only). */}
      <div className="absolute inset-x-0 top-1/2 z-20 h-0" aria-hidden="true">
        <div
          className={cn(
            "absolute inset-x-0 top-0 h-[2px] -translate-y-1/2 bg-gradient-to-r from-transparent via-amber-300 to-transparent transition-shadow",
            tension && "shadow-[0_0_22px_rgba(240,185,11,1)]"
          )}
        />
      </div>
      {/* edge fades + speed streaks — kept SHORT (h-8): the neighbours' skins
          peeking above/below the locked winner must stay visible (tension) */}
      <div className="reel-fade-t pointer-events-none absolute inset-x-0 top-0 z-10 h-8" />
      <div className="reel-fade-b pointer-events-none absolute inset-x-0 bottom-0 z-10 h-8" />
      <div ref={streaksRef} className="reel-streaks-v pointer-events-none absolute inset-0 z-10 opacity-0" />
      {/* lock flash — gold, rare pulls only (≤10% odds) */}
      {locked && flashOnLock && (
        <div
          className="anim-lock-flash pointer-events-none absolute inset-0 z-30"
          style={{ background: GOLD_FLASH_BG }}
          aria-hidden="true"
        />
      )}
      {/* USER SPEC (Task 80): the four-line winner caption sits ON the square cell */}
      {locked && !isRd && <WinnerPlate skinId={target} wearId={targetWear} />}

      <div
        ref={stripRef}
        className="absolute inset-x-0 top-0 flex flex-col will-change-transform"
        style={{ gap: `${CELL_GAP}px` }}
      >
        {strip.map((cell) => {
          const isWin = locked && cell.isWinner;
          if (cell.skinId === ROLLDROP_MARKER) {
            return (
              <RolldropTile
                key={cell.key}
                glow={isWin}
                /* USER SPEC (Task 145): the locked winner marker goes BARE —
                   no golden border/glow beat before the cutscene video pops
                   over this reel. Scrolling decoy markers stay framed. */
                frame={!isWin}
                className={cn("aspect-[2/1] w-full min-h-0 shrink-0", locked && !isWin && "opacity-50")}
                /* absolute centering: same auto-min cycle guard as the skin cells */
                artClassName="absolute inset-0 m-auto h-1/2 w-auto max-w-[72%]"
              />
            );
          }
          const sk = SKINS[cell.skinId];
          return (
            /* USER SPEC (Task 80 hotfix): WIDE 2:1 + TRANSPARENT cell — no
               frame, no fill; ~2 cells fill the viewport so a skin ALWAYS
               crosses the bottom edge (no background gap) and, once locked,
               the neighbours peek a quarter-cell in above/below the winner
               (tension). min-h-0 is CRITICAL: these are flex-column children
               and the auto min-height let a tall skin img GROW the cell past
               its aspect ratio (bigger seat → bigger art → bigger gap — the
               exact "empty band at the bottom" the user reported, worst 1v1). */
            <div
              key={cell.key}
              className={cn(
                "relative grid aspect-[2/1] w-full min-h-0 shrink-0 place-items-center transition-opacity",
                locked && !isWin && "opacity-50"
              )}
              aria-hidden={!isWin && locked}
            >
              {/* USER SPEC (Task 89/89b): the rarity halo is now the eclipse
                  (falls back to the gold glow for unknown skins).
                  USER SPEC (Task 95): the eclipse runs BIGGER behind the skin —
                  inset 8% → 2% (the 2:1 cell height-constrains the square art
                  via background-size:contain, so a tighter inset = bigger art). */}
              <RarityBackdrop rarity={sk?.rarity} fallbackColor="#f0b90b" className="inset-[2%]" />
              <SkinImage
                skinId={cell.skinId}
                kind={sk?.weapon}
                colors={sk?.colors}
                alt={sk?.name ?? cell.skinId}
                className={cn(
                  /* absolute + inset-0 + m-auto: fits & centers inside the
                     definite 2:1 cell — in-flow imgs re-enter the flex/grid
                     auto-min cycle and overflow the cell (Task 80 hotfix) */
                  "absolute inset-0 m-auto max-h-[88%] max-w-[92%] object-contain transition-all duration-300",
                  isWin
                    ? jp
                      ? "scale-110 drop-shadow-[0_0_34px_rgba(240,185,11,0.95)]"
                      : "scale-110 drop-shadow-[0_0_28px_rgba(240,185,11,0.8)]"
                    : "drop-shadow-md"
                )}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}
