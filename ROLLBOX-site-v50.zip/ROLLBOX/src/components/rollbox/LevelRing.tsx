import type { ReactNode } from "react";
import { levelTier } from "@/lib/progress";
import { cn } from "@/lib/utils";

/**
 * The player's picture wrapped in the GLOWING LEVEL ring — the circle's color
 * is the player's level tier (1-10 green, 11-19 turquoise, 20-29 blue,
 * 30-39 purple, 40-49 pink, 50-59 red, 60-69 orange, 70-79 yellow, 80+ gold),
 * glowing in the same hue, with the LVL chip riding the BOTTOM of the ring.
 * USER SPEC (Task 33): extracted from ProfileView so the HEADER avatar (and
 * any other surface) carries the EXACT same level presentation site-wide —
 * the level sits ON the picture, never as a separate chip beside it.
 * `size="lg"` = the profile picture (96px), `size="sm"` = the header chip.
 */
export function LevelRing({
  level,
  children,
  size = "lg",
}: {
  level: number;
  children: ReactNode;
  size?: "sm" | "lg";
}) {
  const tier = levelTier(level);
  const outer = size === "sm" ? "h-12 w-12" : "h-24 w-24";
  const inner = size === "sm" ? "h-[42px] w-[42px]" : "h-[86px] w-[86px]";
  return (
    <span
      className={cn("relative grid shrink-0 place-items-center rounded-full", outer)}
      style={{
        background: `conic-gradient(from 210deg, ${tier.hex}, ${tier.hex2}, ${tier.hex})`,
        boxShadow: `0 0 24px ${tier.glow}, 0 0 56px ${tier.glow}`,
      }}
      title={`Level ${level} — ${tier.name} ring`}
    >
      <span
        className={cn(
          "grid place-items-center overflow-hidden rounded-full border border-black/60 bg-[#0d0a18] p-[3px]",
          inner,
        )}
      >
        {children}
      </span>
      <span
        className={cn(
          "font-display absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full border bg-black/85 font-black uppercase tracking-widest",
          size === "sm" ? "px-1.5 py-px text-[7px]" : "px-2 py-0.5 text-[9px]",
        )}
        style={{ color: tier.hex2, borderColor: `${tier.hex}77` }}
        dir="ltr"
      >
        LVL {level}
      </span>
    </span>
  );
}
