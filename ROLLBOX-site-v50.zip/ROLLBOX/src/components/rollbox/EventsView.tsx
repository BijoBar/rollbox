"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Crown, Eye, Info, Medal, Sparkles, Swords, Timer, Trophy } from "lucide-react";
import { EVENT_CASE, formatCoins } from "@/lib/cases";
import { EVENT_NAME, EVENT_PRIZES, eventActive, eventMsLeft } from "@/lib/event";
import { sfx } from "@/lib/sound";
import { CaseDropsDialog } from "./CaseDropsDialog";
import { CaseImage } from "./CaseImage";
import { Coin } from "./Coin";
import { useMounted } from "@/hooks/use-mounted";

// ============ EVENTS — the EMERALD DROP page (USER SPEC) ============
// The special events page: the uploaded event artwork as the page background
// (half-transparent so the content stays readable), the limited event case
// with its REGULAR catalog rewards, and the wager-race leaderboard with the
// 5-prize ladder — place 5 wins a $10 skin, place 4 $20, ... place 1 $50.
// NO season pass (explicitly declined — maybe later).

interface BoardRow {
  rank: number;
  playerId: string;
  name: string;
  avatar: string | null;
  wagered: number;
  opened: number;
}

interface EventWinner {
  place: number;
  playerId: string;
  name: string;
  prize: number;
}

interface EventData {
  active: boolean;
  endsAt: number;
  prizes: number[];
  prizesAwarded: boolean;
  winners: EventWinner[] | null;
  leaderboard: BoardRow[];
  me: { wagered: number; opened: number; rank: number } | null;
}

const MEDALS = ["text-amber-300", "text-slate-300", "text-orange-400", "text-sky-300", "text-emerald-300"];

function pad(n: number): string {
  return String(n).padStart(2, "0");
}

export function EventsView() {
  const mounted = useMounted();
  const [data, setData] = useState<EventData | null>(null);
  // ticking starts CLIENT-side only — a Date.now() initializer would make the
  // SSR countdown disagree with the client's first paint (hydration mismatch)
  const [now, setNow] = useState(0);
  const [dropsOpen, setDropsOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/event", { cache: "no-store" });
      if (!r.ok) return;
      setData((await r.json()) as EventData);
    } catch {
      /* the next poll retries */
    }
  }, []);

  useEffect(() => {
    const t0 = window.setTimeout(() => void load(), 0);
    const poll = window.setInterval(() => void load(), 20_000);
    const tick = window.setInterval(() => setNow(Date.now()), 1000);
    return () => {
      window.clearTimeout(t0);
      window.clearInterval(poll);
      window.clearInterval(tick);
    };
  }, [load]);

  const active = mounted ? eventActive(now || Date.now()) : true;
  const msLeft = mounted ? eventMsLeft(now || Date.now()) : 0;
  const d = Math.floor(msLeft / 86_400_000);
  const h = Math.floor((msLeft % 86_400_000) / 3_600_000);
  const m = Math.floor((msLeft % 3_600_000) / 60_000);
  const s = Math.floor((msLeft % 60_000) / 1000);

  const rows = data?.leaderboard ?? [];
  const winners = data?.winners ?? null;
  const me = data?.me ?? null;

  return (
    <main className="relative min-h-[calc(100vh-4rem)] overflow-x-clip pb-20 pt-8" aria-label="Emerald Drop event">
      {/* USER SPEC: the uploaded event artwork IS the page background — kept at
          half visibility (50% opacity, i.e. at least half transparent) under a
          dark gradient so every text block stays readable on top of it */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <img src="/event-bg.jpg" alt="" draggable={false} className="h-full w-full select-none object-cover opacity-50" data-testid="event-bg" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0b0714]/75 via-[#0b0714]/45 to-[#0b0714]" />
        <div className="absolute inset-0 bg-[radial-gradient(70%_45%_at_50%_0%,rgba(16,185,129,0.16),transparent_70%)]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-4">
        {/* ===== hero ===== */}
        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-400/10 px-4 py-1.5 text-[11px] font-black uppercase tracking-[0.3em] text-emerald-300">
            <Sparkles className="h-3.5 w-3.5" />
            Limited event
          </span>
          <h1 className="font-display mt-4 text-4xl font-black tracking-wide text-white md:text-6xl">
            {EVENT_NAME.split(" ")[0]}{" "}
            <span className="bg-gradient-to-r from-emerald-300 via-emerald-400 to-amber-300 bg-clip-text text-transparent">
              {EVENT_NAME.split(" ").slice(1).join(" ")}
            </span>
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-sm font-semibold leading-relaxed text-white/55">
            The green-glow vault is open — every {EVENT_CASE.name} opening counts toward the board. Top 5 split the prize pool.
          </p>

          {/* countdown / verdict — ticks only after mount (hydration-safe) */}
          {active ? (
            <div className="mx-auto mt-6 inline-flex items-center gap-3 rounded-2xl border border-emerald-400/25 bg-black/45 px-6 py-3" data-testid="event-countdown">
              <Timer className="h-4 w-4 text-emerald-300" />
              <span className="text-[10px] font-black uppercase tracking-[0.25em] text-white/40">Ends in</span>
              <span className="font-display text-xl font-black tabular-nums text-white" dir="ltr">
                {mounted && now > 0 ? `${d}d ${pad(h)}h ${pad(m)}m ${pad(s)}s` : "—d —h —m —s"}
              </span>
            </div>
          ) : (
            <div className="mx-auto mt-6 inline-flex items-center gap-3 rounded-2xl border border-white/15 bg-black/45 px-6 py-3">
              <Trophy className="h-4 w-4 text-amber-300" />
              <span className="font-display text-sm font-black uppercase tracking-[0.25em] text-white/70">The event has ended</span>
            </div>
          )}
        </motion.div>

        {/* ===== winners banner (after the settle) ===== */}
        {winners && winners.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="mt-8 rounded-2xl border border-amber-400/30 bg-amber-400/[0.06] p-5">
            <div className="flex items-center gap-2">
              <Crown className="h-5 w-5 text-amber-300" />
              <h2 className="font-display text-sm font-black uppercase tracking-[0.25em] text-amber-200">Final winners — prizes credited</h2>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {winners.map((w) => (
                <span key={w.playerId} className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-xs font-bold text-white/80">
                  <span className="text-white/40">#{w.place}</span>
                  {w.name}
                  <span className="flex items-center gap-1 text-amber-300">
                    <Coin className="h-3 w-3" /> {formatCoins(w.prize)}
                  </span>
                </span>
              ))}
            </div>
          </motion.div>
        )}

        {/* ===== case showcase + prize ladder ===== */}
        <div className="mt-10 grid gap-5 lg:grid-cols-2">
          {/* the event case */}
          <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, delay: 0.08 }} className="relative overflow-hidden rounded-3xl border border-emerald-400/25 bg-[#0d0819]/80 p-6" aria-label="The event case">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_20%,rgba(16,185,129,0.14),transparent_70%)]" aria-hidden="true" />
            <div className="relative flex flex-col items-center text-center">
              <span className="rounded-md border border-emerald-400/40 bg-emerald-400/10 px-2 py-0.5 font-mono text-[9px] font-black tracking-widest text-emerald-300">
                EVENT CASE
              </span>
              <div className="mt-3 w-56">
                <CaseImage caseId={EVENT_CASE.id} alt={EVENT_CASE.name} color={EVENT_CASE.tierColor} color2={EVENT_CASE.tierColor2} communityDesign={EVENT_CASE.communityDesign} sizes="224px" />
              </div>
              <h2 className="font-display mt-3 text-2xl font-black text-white">{EVENT_CASE.name}</h2>
              <p className="mt-1 max-w-xs text-xs font-semibold leading-relaxed text-white/45">{EVENT_CASE.subtitle}</p>
              <p className="mt-2 flex items-center gap-1.5 text-sm font-black text-amber-300">
                <Coin /> {formatCoins(EVENT_CASE.price)} <span className="text-[10px] font-bold uppercase tracking-widest text-white/35">per opening</span>
              </p>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                {active ? (
                  <Link
                    href={`/case/${EVENT_CASE.id}`}
                    onClick={() => sfx.click()}
                    className="gold-btn flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-black shadow-[0_0_18px_rgba(16,185,129,0.35)]"
                    data-testid="event-open-case"
                  >
                    <Swords className="h-4 w-4" />
                    Open the case
                  </Link>
                ) : (
                  <span className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-6 py-3 text-sm font-black text-white/35">
                    The case has left the site
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => {
                    sfx.click();
                    setDropsOpen(true);
                  }}
                  className="flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-bold text-white/70 transition-colors hover:bg-white/10 hover:text-white"
                >
                  <Eye className="h-4 w-4" />
                  View drops
                </button>
              </div>
              <p className="mt-3 text-[11px] font-semibold text-white/35">
                Regular catalog skins only — from fade stickers to the golden Karambit.
              </p>
            </div>
          </motion.section>

          {/* the prize ladder */}
          <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, delay: 0.16 }} className="rounded-3xl border border-white/10 bg-[#0d0819]/80 p-6" aria-label="The prize ladder">
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-display text-sm font-black uppercase tracking-[0.25em] text-white/70">Prize ladder</h2>
              <span className="flex items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-[11px] font-black text-amber-300">
                <Trophy className="h-3.5 w-3.5" />
                <Coin className="h-3 w-3" /> {formatCoins(EVENT_PRIZES.reduce((a, b) => a + b, 0))} pool
              </span>
            </div>
            <ol className="mt-4 space-y-2">
              {EVENT_PRIZES.map((prize, i) => (
                <li key={i} className="flex items-center gap-3 rounded-xl border border-white/10 bg-black/35 px-4 py-3">
                  <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-white/10 bg-white/5 ${MEDALS[i]}`}>
                    {i === 0 ? <Crown className="h-4 w-4" /> : <Medal className="h-4 w-4" />}
                  </span>
                  <span className="font-display text-sm font-black uppercase tracking-wider text-white/80">
                    {["1st", "2nd", "3rd", "4th", "5th"][i]} place
                  </span>
                  <span className="ml-auto flex items-center gap-1.5 text-base font-black text-amber-300">
                    <Coin className="h-4 w-4" /> {formatCoins(prize)}
                  </span>
                </li>
              ))}
            </ol>
            <p className="mt-3 flex items-start gap-2 text-[11px] font-semibold leading-relaxed text-white/40">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              A skin worth the shown value — credited to the winner&apos;s balance the moment the event closes.
            </p>
          </motion.section>
        </div>

        {/* ===== the board ===== */}
        <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, delay: 0.24 }} className="mt-8 rounded-3xl border border-white/10 bg-[#0d0819]/80 p-6" aria-label="Event leaderboard">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-display text-sm font-black uppercase tracking-[0.25em] text-white/70">Event leaderboard</h2>
            <span className="text-[10px] font-bold uppercase tracking-widest text-white/35">Live · refreshes every 20s</span>
          </div>

          {rows.length === 0 ? (
            <div className="mt-4 grid place-items-center rounded-2xl border border-dashed border-white/12 py-12 text-center">
              <Trophy className="h-8 w-8 text-white/25" />
              <p className="mt-2 text-sm font-bold text-white/55">The board is empty — be the first to open the event case</p>
              <p className="mt-1 max-w-sm text-xs font-semibold leading-relaxed text-white/35">
                Every coin you spend on {EVENT_CASE.name} moves you up. The race ends when the countdown hits zero.
              </p>
            </div>
          ) : (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[560px] text-left" data-testid="event-board">
                <thead>
                  <tr className="text-[10px] font-black uppercase tracking-[0.2em] text-white/35">
                    <th className="px-3 py-2">Place</th>
                    <th className="px-3 py-2">Player</th>
                    <th className="px-3 py-2 text-right">Wagered</th>
                    <th className="px-3 py-2 text-right">Opens</th>
                    <th className="px-3 py-2 text-right">Prize</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const inPrizes = r.rank <= EVENT_PRIZES.length;
                    return (
                      <tr
                        key={r.playerId}
                        className={
                          "border-t border-white/[0.06] " +
                          (inPrizes ? "bg-emerald-400/[0.04]" : "") +
                          (r.rank === me?.rank ? " ring-1 ring-inset ring-amber-300/40" : "")
                        }
                      >
                        <td className="px-3 py-2.5">
                          <span className={`font-display text-sm font-black ${inPrizes ? MEDALS[r.rank - 1] : "text-white/45"}`}>#{r.rank}</span>
                        </td>
                        <td className="px-3 py-2.5">
                          <span className="flex items-center gap-2">
                            {r.avatar ? (
                              <img src={r.avatar} alt="" className="h-7 w-7 rounded-lg object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <span className="grid h-7 w-7 place-items-center rounded-lg bg-white/10 text-[10px] font-black text-white/60">
                                {r.name.slice(0, 1).toUpperCase()}
                              </span>
                            )}
                            <span className="max-w-[180px] truncate text-sm font-bold text-white/85" dir="ltr">
                              {r.name}
                            </span>
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-right">
                          <span className="flex items-center justify-end gap-1 text-sm font-black text-amber-300">
                            <Coin className="h-3.5 w-3.5" /> {formatCoins(r.wagered)}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-right text-sm font-bold text-white/60">{r.opened}</td>
                        <td className="px-3 py-2.5 text-right">
                          {inPrizes ? (
                            <span className="flex items-center justify-end gap-1 rounded-lg border border-amber-400/30 bg-amber-400/10 px-2 py-1 text-xs font-black text-amber-300">
                              <Coin className="h-3 w-3" /> {formatCoins(EVENT_PRIZES[r.rank - 1])}
                            </span>
                          ) : (
                            <span className="text-xs font-bold text-white/25">—</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* your own row when it lives outside the visible top 10 */}
          {me && me.rank > rows.length && (
            <div className="mt-3 flex items-center justify-between rounded-xl border border-amber-300/40 bg-amber-300/[0.06] px-4 py-2.5" data-testid="event-me-row">
              <span className="flex items-center gap-2 text-sm font-black text-amber-200">
                <span className="font-display">#{me.rank}</span>
                <span className="text-white/70">your position</span>
              </span>
              <span className="flex items-center gap-4 text-sm font-bold">
                <span className="flex items-center gap-1 text-amber-300">
                  <Coin className="h-3.5 w-3.5" /> {formatCoins(me.wagered)}
                </span>
                <span className="text-white/50">{me.opened} opens</span>
              </span>
            </div>
          )}
        </motion.section>

        {/* ===== how it works ===== */}
        <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, delay: 0.32 }} className="mt-8 grid gap-3 md:grid-cols-3" aria-label="How the event works">
          {[
            {
              t: "Open the event case",
              d: `Every ${EVENT_CASE.name} opening — solo or inside a battle — adds its FULL price to your event total. More opens, higher climb.`,
            },
            {
              t: "Climb the board",
              d: "The board ranks by total wagered on the event case. The top 5 when the countdown ends take the prizes — $50 for 1st down to $10 for 5th.",
            },
            {
              t: "When it ends",
              d: "The event case leaves the site, the board freezes and the prizes credit to the winners' balances automatically — exactly once.",
            },
          ].map((c) => (
            <div key={c.t} className="rounded-2xl border border-white/10 bg-black/35 p-5">
              <h3 className="font-display text-xs font-black uppercase tracking-[0.2em] text-emerald-300">{c.t}</h3>
              <p className="mt-2 text-xs font-semibold leading-relaxed text-white/50">{c.d}</p>
            </div>
          ))}
        </motion.section>
      </div>

      <CaseDropsDialog caseDef={EVENT_CASE} open={dropsOpen} onOpenChange={setDropsOpen} />
    </main>
  );
}
