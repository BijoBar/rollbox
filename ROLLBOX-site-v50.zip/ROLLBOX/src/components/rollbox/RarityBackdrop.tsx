import { RARITY_DICE, RARITY_META, type Rarity } from "@/lib/cases";
import { cn } from "@/lib/utils";

/**
 * USER SPEC (Task 129) — backdrops are BACK: the user supplied a new ROLLBOX
 * emblem artwork set (metallic star + logo over a smoky rarity-color
 * backdrop, 1080x1350 RGBA), installed under /public/rarity/ with the user's
 * own filenames and mapped per rarity in RARITY_DICE (lib/cases.ts).
 * Rendered behind the weapon art with background-size:cover at all 6 call
 * sites (SkinTile, CaseDropsDialog, InventoryDrawer, ExchangeView, BattleReel,
 * BattleRoomView) — USER SPEC (Task 131): the user asked for BIGGER backdrops
 * ("הסקינים מסתירים אותם") — cover scales the emblem up to fill each box
 * (instead of contain's fit-inside which left it small behind the weapon
 * art); the 1080x1350 art's dark margins absorb the vertical crop safely.
 */
const BACKDROPS_ENABLED = true;

export function RarityBackdrop({
  rarity,
  className,
  fallbackColor,
}: {
  rarity?: Rarity;
  className?: string;
  /** glow color for rarities without artwork (defaults to the rarity color) */
  fallbackColor?: string;
}) {
  if (!BACKDROPS_ENABLED) return null;
  const art = rarity ? RARITY_DICE[rarity] : undefined;
  if (art) {
    return (
      <div
        aria-hidden="true"
        className={cn("pointer-events-none absolute inset-0 bg-no-repeat", className)}
        style={{
          backgroundImage: `url(${art})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
    );
  }
  const color =
    (rarity && RARITY_META[rarity]?.color) || fallbackColor || "#8882a8";
  return (
    <div
      aria-hidden="true"
      className={cn("pointer-events-none absolute inset-0", className)}
      style={{
        background: `radial-gradient(ellipse 70% 60% at 50% 22%, ${color}33, transparent 70%)`,
      }}
    />
  );
}
