"use client";

import { useEffect } from "react";
import { sfx } from "@/lib/sound";

/**
 * USER SPEC (Task 45): the ROLLDROP hit — the whole screen flashes WHITE for
 * about a second with the raredrop.png art popping in the center, and the
 * extra rare round's reel is already spinning underneath the white.
 * Pure CSS animation (compositor-run), unmounts itself when done.
 */
export function RolldropFlash({ onDone }: { onDone?: () => void }) {
  useEffect(() => {
    sfx.win(true);
    const t = window.setTimeout(() => onDone?.(), 1350);
    return () => window.clearTimeout(t);
  }, [onDone]);

  return (
    <div className="rd-flash pointer-events-none fixed inset-0 z-[65]" aria-hidden="true">
      <img
        src="/raredrop.png"
        alt=""
        className="rd-flash-art pointer-events-none absolute left-1/2 top-1/2 w-[min(52vw,26rem)] -translate-x-1/2 -translate-y-1/2 object-contain"
        draggable={false}
      />
    </div>
  );
}
