"use client";

// QOL (Task 167): the admin panel's TOOLS tab — the site-wide broadcast
// banner editor + the CASE STATS dashboard (opens per case, 24h / 7d / all).
import { useCallback, useEffect, useState } from "react";
import { BarChart3, Megaphone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";

interface CaseStat {
  caseId: string;
  name: string;
  price: number | null;
  opens24: number;
  opens7: number;
  opensAll: number;
}

const TONES = ["gold", "info", "alert"] as const;
type Tone = (typeof TONES)[number];

export function AdminToolsTab() {
  const { toast } = useToast();
  const [on, setOn] = useState(false);
  const [text, setText] = useState("");
  const [tone, setTone] = useState<Tone>("gold");
  const [busy, setBusy] = useState(false);
  const [stats, setStats] = useState<CaseStat[]>([]);

  const loadBanner = useCallback(async () => {
    try {
      const r = await fetch("/api/banner", { cache: "no-store" });
      if (r.ok) {
        const d = (await r.json()) as { on: boolean; text: string; tone: string };
        setOn(d.on);
        setText(d.text);
        setTone((TONES.includes(d.tone as Tone) ? d.tone : "gold") as Tone);
      }
    } catch {
      /* cosmetic */
    }
  }, []);

  const loadStats = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/case-stats", { cache: "no-store" });
      if (r.ok) {
        const d = (await r.json()) as { rows: CaseStat[] };
        setStats(d.rows ?? []);
      }
    } catch {
      /* cosmetic */
    }
  }, []);

  useEffect(() => {
    void loadBanner();
    void loadStats();
    const t = window.setInterval(() => void loadStats(), 30000);
    return () => window.clearInterval(t);
  }, [loadBanner, loadStats]);

  const save = async () => {
    setBusy(true);
    try {
      const r = await fetch("/api/admin/banner", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ on, text, tone }),
      });
      const d = (await r.json()) as { ok?: boolean; error?: string };
      if (!r.ok || !d.ok) throw new Error(d.error ?? "Failed");
      sfx.coins();
      toast({ title: on ? "Banner is LIVE on every page" : "Banner hidden" });
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-5 space-y-4">
      {/* broadcast banner */}
      <div className="rounded-2xl border border-white/10 bg-black/40 p-4">
        <div className="flex items-center gap-2">
          <Megaphone className="h-5 w-5 text-amber-300" />
          <h3 className="font-display text-sm font-black uppercase tracking-widest text-white">Broadcast banner</h3>
          <button
            type="button"
            onClick={() => setOn((v) => !v)}
            aria-pressed={on}
            aria-label="Toggle the banner on or off"
            className={cn(
              "ml-auto flex h-6 w-11 items-center rounded-full border px-0.5 transition-colors",
              on ? "border-amber-400/60 bg-amber-500/30" : "border-white/15 bg-white/5",
            )}
          >
            <span className={cn("h-4.5 w-4.5 h-5 w-5 rounded-full bg-white transition-transform", on ? "translate-x-5" : "translate-x-0")} />
          </button>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, 200))}
          rows={2}
          placeholder="Message for every page — e.g. FRIDAY GIVEAWAY is live at /giveaways — 20:00"
          className="mt-3 w-full resize-none rounded-lg border border-white/15 bg-black/50 px-3 py-2 text-xs text-white placeholder:text-white/30 focus:border-amber-400/60 focus:outline-none"
        />
        <div className="mt-2 flex flex-wrap items-center gap-2">
          {TONES.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTone(t)}
              className={cn(
                "rounded-lg border px-3 py-1.5 text-[10px] font-black uppercase tracking-widest transition-colors",
                tone === t ? "border-white/40 bg-white/15 text-white" : "border-white/10 text-white/40 hover:text-white",
              )}
            >
              {t}
            </button>
          ))}
          <button
            type="button"
            disabled={busy}
            onClick={() => void save()}
            className="ml-auto rounded-lg border border-amber-400/50 bg-amber-500/20 px-5 py-2 text-[11px] font-black uppercase tracking-widest text-amber-200 transition-colors hover:bg-amber-500/30 disabled:opacity-40"
          >
            Save banner
          </button>
        </div>
      </div>

      {/* case stats */}
      <div className="rounded-2xl border border-white/10 bg-black/40 p-4">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-sky-300" />
          <h3 className="font-display text-sm font-black uppercase tracking-widest text-white">Case stats</h3>
          <span className="ml-auto text-[10px] font-black uppercase tracking-widest text-white/35">30s poll</span>
        </div>
        {stats.length === 0 ? (
          <p className="mt-3 text-xs text-white/40">No opens recorded yet.</p>
        ) : (
          <div className="mt-3 overflow-x-auto">
            <table className="w-full min-w-[430px] text-left text-xs">
              <thead>
                <tr className="text-[10px] font-black uppercase tracking-widest text-white/35">
                  <th className="pb-2 pr-2">Case</th>
                  <th className="pb-2 pr-2 text-right">24h</th>
                  <th className="pb-2 pr-2 text-right">7d</th>
                  <th className="pb-2 pr-2 text-right">All</th>
                  <th className="pb-2 text-right">~$ in (all)</th>
                </tr>
              </thead>
              <tbody>
                {stats.map((s) => (
                  <tr key={s.caseId} className="border-t border-white/5">
                    <td className="py-1.5 pr-2 font-bold text-white/80">{s.name}</td>
                    <td className="py-1.5 pr-2 text-right font-mono text-white/70">{s.opens24}</td>
                    <td className="py-1.5 pr-2 text-right font-mono text-white/70">{s.opens7}</td>
                    <td className="py-1.5 pr-2 text-right font-mono text-white/70">{s.opensAll}</td>
                    <td className="py-1.5 text-right font-mono text-amber-300/90">
                      {s.price == null ? "—" : (s.price * s.opensAll).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
