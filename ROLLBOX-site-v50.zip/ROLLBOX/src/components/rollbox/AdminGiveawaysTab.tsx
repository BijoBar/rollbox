"use client";

// QOL (Task 167): the admin panel's GIVEAWAYS tab — create a prize pot,
// watch entries pile up, DRAW the winners (crypto-random, paid in
// transactions) or cancel. Winners also happen automatically at endsAt.
import { useCallback, useEffect, useState } from "react";
import { Gift, Square, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { sfx } from "@/lib/sound";
import { Coin } from "./Coin";
import { cn } from "@/lib/utils";

interface AdminGiveaway {
  id: string;
  title: string;
  prizeCoins: number;
  prizeLabel: string | null;
  winnerCount: number;
  status: string;
  endsAt: number;
  createdAt: number;
  entries: number;
  winners: { playerId: string; name: string }[];
}

const fmtIn = (ms: number) => {
  const left = ms - Date.now();
  if (left <= 0) return "ended";
  const h = Math.floor(left / 3600_000);
  const m = Math.floor((left % 3600_000) / 60_000);
  return h > 24 ? `${Math.floor(h / 24)}d ${h % 24}h` : h > 0 ? `${h}h ${m}m` : `${m}m`;
};

export function AdminGiveawaysTab() {
  const { toast } = useToast();
  const [rows, setRows] = useState<AdminGiveaway[]>([]);
  const [title, setTitle] = useState("");
  const [prize, setPrize] = useState("");
  const [label, setLabel] = useState("");
  const [winners, setWinners] = useState("1");
  const [ends, setEnds] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/giveaways", { cache: "no-store" });
      if (r.ok) {
        const d = (await r.json()) as { rows: AdminGiveaway[] };
        setRows(d.rows ?? []);
      }
    } catch {
      /* cosmetic */
    }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(() => void load(), 15000);
    return () => window.clearInterval(t);
  }, [load]);

  const create = async () => {
    setBusy(true);
    try {
      const r = await fetch("/api/admin/giveaways", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          prizeCoins: Number(prize),
          prizeLabel: label,
          winnerCount: Number(winners),
          endsAt: ends ? new Date(ends).getTime() : 0,
        }),
      });
      const d = (await r.json()) as { ok?: boolean; error?: string; id?: string };
      if (!r.ok || !d.ok) throw new Error(d.error ?? "Failed");
      sfx.coins();
      toast({ title: "Giveaway is live — players can join now" });
      setTitle("");
      setPrize("");
      setLabel("");
      setWinners("1");
      setEnds("");
      void load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed to create" });
    } finally {
      setBusy(false);
    }
  };

  const act = async (id: string, action: "draw" | "cancel") => {
    setBusy(true);
    try {
      const r = await fetch(`/api/admin/giveaways/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const d = (await r.json()) as { ok?: boolean; error?: string; winners?: { name: string }[] };
      if (!r.ok || !d.ok) throw new Error(d.error ?? "Failed");
      sfx.coins();
      toast({
        title: action === "draw" ? `Winners: ${d.winners?.map((w) => w.name).join(", ") || "none"}` : "Giveaway cancelled",
      });
      void load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed" });
    } finally {
      setBusy(false);
    }
  };

  const valid = title.trim().length >= 3 && Number(prize) > 0 && Number(winners) >= 1 && ends !== "";

  return (
    <div className="mt-5 space-y-4">
      {/* create */}
      <div className="rounded-2xl border border-white/10 bg-black/40 p-4">
        <div className="flex items-center gap-2">
          <Gift className="h-5 w-5 text-fuchsia-300" />
          <h3 className="font-display text-sm font-black uppercase tracking-widest text-white">New giveaway</h3>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title — e.g. Friday Blood Drop"
            className="rounded-lg border border-white/15 bg-black/50 px-3 py-2 text-xs text-white placeholder:text-white/30 focus:border-fuchsia-400/60 focus:outline-none sm:col-span-2"
          />
          <div className="flex items-center gap-1 rounded-lg border border-white/15 bg-black/50 px-3 py-2 focus-within:border-fuchsia-400/60">
            <Coin className="h-3.5 w-3.5 shrink-0" />
            <input
              value={prize}
              onChange={(e) => setPrize(e.target.value.replace(/[^\d.]/g, ""))}
              dir="ltr"
              placeholder="Prize in coins"
              inputMode="decimal"
              className="w-full bg-transparent text-xs text-white placeholder:text-white/30 focus:outline-none"
            />
          </div>
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Prize label (optional) — e.g. Butterfly Knife"
            className="rounded-lg border border-white/15 bg-black/50 px-3 py-2 text-xs text-white placeholder:text-white/30 focus:border-fuchsia-400/60 focus:outline-none"
          />
          <select
            value={winners}
            onChange={(e) => setWinners(e.target.value)}
            aria-label="Number of winners"
            className="rounded-lg border border-white/15 bg-black/50 px-3 py-2 text-xs text-white focus:border-fuchsia-400/60 focus:outline-none"
          >
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
              <option key={n} value={n} className="bg-[#16151a]">
                {n} winner{n > 1 ? "s" : ""} — split
              </option>
            ))}
          </select>
          <input
            type="datetime-local"
            value={ends}
            onChange={(e) => setEnds(e.target.value)}
            aria-label="Giveaway end time"
            className="rounded-lg border border-white/15 bg-black/50 px-3 py-2 text-xs text-white [color-scheme:dark] focus:border-fuchsia-400/60 focus:outline-none"
          />
        </div>
        <button
          type="button"
          disabled={busy || !valid}
          onClick={() => void create()}
          className="mt-3 w-full rounded-lg border border-fuchsia-400/50 bg-fuchsia-500/20 py-2.5 text-xs font-black uppercase tracking-widest text-fuchsia-100 transition-colors hover:bg-fuchsia-500/30 disabled:opacity-40"
        >
          Post the giveaway
        </button>
        <p className="mt-2 text-[10px] leading-relaxed text-white/35">
          Winners are paid at DRAW time (each in its own transaction + ledger row). One entry per player.
        </p>
      </div>

      {/* list */}
      {rows.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-10 text-center">
          <Gift className="mx-auto mb-2 h-8 w-8 text-white/25" />
          <p className="text-sm font-bold text-white/60">No giveaways yet</p>
        </div>
      ) : (
        <ul className="space-y-2" aria-label="Giveaways">
          {rows.map((g) => (
            <li key={g.id} className="rounded-xl border border-white/10 bg-black/40 p-3.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-black text-white">{g.title}</span>
                <span
                  className={cn(
                    "rounded-full px-2 py-0.5 text-[10px] font-black uppercase tracking-wider",
                    g.status === "active" && "bg-emerald-500/20 text-emerald-300",
                    g.status === "drawn" && "bg-white/10 text-white/60",
                    g.status === "cancelled" && "bg-red-500/20 text-red-300",
                  )}
                >
                  {g.status}
                </span>
                <span className="ml-auto flex items-center gap-1 text-xs font-black text-amber-300">
                  <Coin className="h-3.5 w-3.5" /> {g.prizeCoins}
                </span>
              </div>
              <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-white/45">
                {g.prizeLabel && <span className="text-white/60">{g.prizeLabel}</span>}
                <span className="flex items-center gap-1">
                  <Users className="h-3 w-3" /> {g.entries} joined
                </span>
                <span>
                  {g.winnerCount} winner{g.winnerCount > 1 ? "s" : ""} · {g.status === "active" ? `ends in ${fmtIn(g.endsAt)}` : "settled"}
                </span>
              </div>
              {g.status === "drawn" && g.winners.length > 0 && (
                <p className="mt-1.5 text-[11px] font-bold text-amber-300/90">
                  Won: {g.winners.map((w) => w.name).join(", ")}
                </p>
              )}
              {g.status === "active" && (
                <div className="mt-2.5 flex gap-2">
                  <button
                    type="button"
                    disabled={busy || g.entries === 0}
                    onClick={() => void act(g.id, "draw")}
                    className="flex-1 rounded-lg border border-amber-400/50 bg-amber-500/15 py-2 text-[11px] font-black uppercase tracking-widest text-amber-200 transition-colors hover:bg-amber-500/25 disabled:opacity-40"
                  >
                    Draw now
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void act(g.id, "cancel")}
                    className="flex items-center gap-1.5 rounded-lg border border-white/15 px-3 py-2 text-[11px] font-black uppercase tracking-widest text-white/50 transition-colors hover:text-white disabled:opacity-40"
                  >
                    <Square className="h-3 w-3" />
                    Cancel
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
