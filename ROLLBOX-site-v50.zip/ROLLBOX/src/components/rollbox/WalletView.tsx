"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowLeft,
  BadgeCheck,
  Clock,
  Copy,
  ExternalLink,
  ShieldCheck,
  Wallet as WalletIcon,
  X,
} from "lucide-react";
import { useSession } from "@/lib/session";
import { formatCoins } from "@/lib/cases";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";

/* ===== C7 PHASE 1: the WALLET — REAL crypto deposits & withdrawals =====
   Manual by design: deposits are USDT (TRC-20) sent to the site wallet, the
   player pastes the txid, and the ADMIN verifies the transaction on the
   explorer and approves. Withdrawals LOCK the coins instantly, the admin
   sends the USDT manually and marks the request paid (or rejects = refund).
   The jurisdiction declaration is mandatory on both flows. */

interface WalletMethod {
  id: string;
  label: string;
  network: string;
  addressHint: string;
  address: string | null;
}

interface DepositRow {
  id: string;
  method: string;
  amountUsd: number;
  txid: string;
  status: string;
  adminNote: string | null;
  createdAt: string;
}

interface WithdrawRow {
  id: string;
  method: string;
  amountCoins: number;
  address: string;
  status: string;
  adminNote: string | null;
  payoutTxid: string | null;
  createdAt: string;
}

interface WalletData {
  enabled: boolean;
  declaration: string;
  onBreak: boolean;
  methods: WalletMethod[];
  minDeposit: number;
  maxDeposit: number;
  minWithdraw: number;
  maxWithdraw: number;
  deposits: DepositRow[];
  withdrawals: WithdrawRow[];
}

const DEPOSIT_PRESETS = [25, 50, 100, 250];

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { cls: string; label: string }> = {
    pending: { cls: "border-amber-400/40 bg-amber-500/10 text-amber-300", label: "PENDING" },
    approved: { cls: "border-emerald-400/40 bg-emerald-500/10 text-emerald-300", label: "APPROVED" },
    paid: { cls: "border-emerald-400/40 bg-emerald-500/10 text-emerald-300", label: "PAID" },
    rejected: { cls: "border-red-400/40 bg-red-500/10 text-red-300", label: "REJECTED" },
  };
  const s = map[status] ?? { cls: "border-white/20 bg-white/5 text-white/50", label: status.toUpperCase() };
  return <span className={cn("rounded border px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wide", s.cls)}>{s.label}</span>;
}

const fmtWhen = (iso: string): string =>
  new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });

export function WalletView() {
  const { player: me } = useSession();
  const { toast } = useToast();

  const [data, setData] = useState<WalletData | null>(null);
  const [loading, setLoading] = useState(true);

  // deposit form
  const [depAmount, setDepAmount] = useState("");
  const [txid, setTxid] = useState("");
  const [depDeclared, setDepDeclared] = useState(false);
  const [depBusy, setDepBusy] = useState(false);

  // withdraw form
  const [wdAmount, setWdAmount] = useState("");
  const [wdAddress, setWdAddress] = useState("");
  const [wdDeclared, setWdDeclared] = useState(false);
  const [wdBusy, setWdBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/wallet", { cache: "no-store" });
      const d = (await r.json()) as WalletData & { error?: string };
      if (!r.ok) throw new Error(d.error ?? "Could not load the wallet");
      setData(d);
    } catch {
      setData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const copy = async (text: string, what: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: `${what} copied` });
    } catch {
      toast({ title: "Copy failed — select the text manually" });
    }
  };

  const depValue = Number(depAmount);
  const depValid = data && Number.isFinite(depValue) && depValue >= data.minDeposit && depValue <= data.maxDeposit;
  const txidValid = /^[0-9a-fA-F]{64}$/.test(txid.trim());
  const method = data?.methods.find((m) => m.address);

  const submitDeposit = async () => {
    if (depBusy || !data || !depValid || !txidValid || !depDeclared) return;
    setDepBusy(true);
    try {
      const r = await fetch("/api/wallet/deposit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amountUsd: Math.round(depValue * 100) / 100, txid: txid.trim(), declared: true }),
      });
      const d = (await r.json()) as { error?: string };
      if (!r.ok) throw new Error(d.error ?? "Could not submit the deposit");
      sfx.coins();
      toast({ title: "Deposit submitted — PENDING review", description: "The team verifies your transaction and credits your balance shortly." });
      setDepAmount("");
      setTxid("");
      setDepDeclared(false);
      void load();
    } catch (e) {
      sfx.error();
      toast({ title: e instanceof Error ? e.message : "Could not submit the deposit", variant: "destructive" });
    } finally {
      setDepBusy(false);
    }
  };

  const wdValue = Number(wdAmount);
  const wdValid =
    data && Number.isFinite(wdValue) && wdValue >= data.minWithdraw && wdValue <= data.maxWithdraw && (me ? wdValue <= me.balance : false);
  const wdAddressValid = /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(wdAddress.trim());

  const submitWithdraw = async () => {
    if (wdBusy || !data || !wdValid || !wdAddressValid || !wdDeclared) return;
    setWdBusy(true);
    try {
      const r = await fetch("/api/wallet/withdraw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amountCoins: Math.round(wdValue * 100) / 100, address: wdAddress.trim(), declared: true }),
      });
      const d = (await r.json()) as { error?: string; balance?: number };
      if (!r.ok) throw new Error(d.error ?? "Could not submit the withdrawal");
      sfx.click();
      toast({ title: "Withdrawal requested — coins locked", description: "The team reviews and sends your USDT shortly." });
      setWdAmount("");
      setWdAddress("");
      setWdDeclared(false);
      void load();
    } catch (e) {
      sfx.error();
      toast({ title: e instanceof Error ? e.message : "Could not submit the withdrawal", variant: "destructive" });
    } finally {
      setWdBusy(false);
    }
  };

  // ---------- guests ----------
  if (!me) {
    return (
      <main className="relative flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 pb-20 pt-10" aria-label="Guest wallet">
        <div className="w-full max-w-md rounded-2xl border border-amber-400/20 bg-[#100a1e]/90 p-8 text-center">
          <WalletIcon className="mx-auto mb-4 h-10 w-10 text-amber-300/70" />
          <h1 className="font-display text-2xl font-black text-white">The wallet belongs to players</h1>
          <p className="mt-2 text-sm leading-relaxed text-white/55">Sign in with STEAM to deposit or withdraw real funds.</p>
          <Link href="/login" onClick={() => sfx.click()} className="gold-btn mt-6 inline-flex items-center rounded-xl px-6 py-3 text-sm font-black text-black">
            Sign In with Steam
          </Link>
        </div>
      </main>
    );
  }

  // ---------- signed in ----------
  return (
    <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-8" aria-label="Wallet">
      <div className="relative mx-auto max-w-3xl px-4">
        {/* header */}
        <div className="flex items-center gap-3">
          <Link
            href="/profile"
            onClick={() => sfx.click()}
            className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
            aria-label="Back to the profile"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <h1 className="font-display text-2xl font-black tracking-wide text-white sm:text-3xl">
              WA<span className="text-gradient-neon">LLET</span>
            </h1>
            <p className="text-xs font-semibold text-white/45">
              Real deposits &amp; payouts — USDT (TRC-20), reviewed by the team. 1 USDT = $1.
            </p>
          </div>
        </div>

        {loading ? (
          <div className="mt-8 rounded-2xl border border-white/10 bg-white/[0.02] px-6 py-12 text-center text-sm font-bold text-white/40">
            Loading the wallet…
          </div>
        ) : !data ? (
          <div className="mt-8 rounded-2xl border border-red-400/20 bg-red-500/[0.05] px-6 py-12 text-center text-sm font-bold text-white/60">
            The wallet could not be loaded — refresh the page.
          </div>
        ) : data.onBreak ? (
          <div className="mt-8 rounded-2xl border border-red-400/25 bg-red-500/[0.06] px-6 py-10 text-center">
            <ShieldCheck className="mx-auto mb-3 h-8 w-8 text-red-300/80" />
            <p className="text-sm font-black text-white/80">You are on a TAKE A BREAK self-block.</p>
            <p className="mt-1 text-xs text-white/45">Deposits and withdrawals unlock automatically when the break ends.</p>
          </div>
        ) : !data.enabled ? (
          <div className="mt-8 rounded-2xl border border-white/10 bg-white/[0.02] px-6 py-12 text-center">
            <Clock className="mx-auto mb-3 h-8 w-8 text-white/30" />
            <p className="text-sm font-black text-white/70">Deposits &amp; withdrawals are temporarily closed.</p>
            <p className="mt-1 text-xs text-white/40">The feature is switched off by the team — check back later.</p>
          </div>
        ) : (
          <>
            {/* ===== DEPOSIT ===== */}
            <motion.section
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="mt-6 rounded-2xl border border-emerald-400/20 bg-[#0d0a18]/90 p-5 sm:p-6"
              aria-label="Deposit"
            >
              <div className="flex items-center gap-2">
                <ArrowDownToLine className="h-4 w-4 text-emerald-300" />
                <h2 className="font-display text-lg font-black text-white">DEPOSIT</h2>
                <span className="rounded border border-emerald-400/30 bg-emerald-500/10 px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wide text-emerald-300">
                  {method ? `${method.label} · ${method.network}` : "closed"}
                </span>
              </div>

              {!method ? (
                <p className="mt-4 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-xs font-bold text-white/45">
                  No deposit address is configured yet — the team will open deposits soon.
                </p>
              ) : (
                <>
                  <ol className="mt-4 space-y-1.5 text-[11px] font-semibold leading-relaxed text-white/50">
                    <li>1. Send exactly <b className="text-white/80">{depValid ? depValue : "X"} USDT</b> (TRC-20) to the address below.</li>
                    <li>2. Copy the transaction hash (txid) from your wallet or the explorer.</li>
                    <li>3. Paste it here — the team verifies the transaction and credits your balance.</li>
                  </ol>

                  {/* the deposit address + copy */}
                  <div className="mt-3 rounded-xl border border-emerald-400/25 bg-emerald-500/[0.05] p-3">
                    <p className="text-[9px] font-black uppercase tracking-widest text-emerald-300">Deposit address — {method.network}</p>
                    <div className="mt-1.5 flex items-center gap-2">
                      <code className="min-w-0 flex-1 truncate font-mono text-xs text-emerald-100" dir="ltr">{method.address}</code>
                      <button
                        type="button"
                        onClick={() => void copy(method.address as string, "The address")}
                        className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-white/15 bg-white/5 text-white/60 transition-colors hover:bg-white/10 hover:text-white"
                        aria-label="Copy the deposit address"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <a
                      href={`https://tronscan.org/#/address/${method.address}`}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="mt-1.5 inline-flex items-center gap-1 text-[10px] font-bold text-emerald-300/80 hover:text-emerald-200"
                      dir="ltr"
                    >
                      <ExternalLink className="h-3 w-3" />
                      view on Tronscan
                    </a>
                  </div>

                  {/* amount */}
                  <div className="mt-3 flex h-11 items-center gap-2 rounded-xl border border-white/15 bg-black/40 px-3">
                    <span className="text-[10px] font-black uppercase tracking-widest text-white/35">Amount</span>
                    <input
                      value={depAmount}
                      onChange={(e) => setDepAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                      dir="ltr"
                      inputMode="decimal"
                      placeholder={`${data.minDeposit}-${data.maxDeposit}`}
                      aria-label="Deposit amount in USDT"
                      className="font-display w-full bg-transparent text-right text-base font-black text-amber-300 tabular-nums focus:outline-none"
                    />
                    <span className="shrink-0 text-[10px] font-bold text-white/35">USDT</span>
                  </div>
                  <div className="mt-2 grid grid-cols-4 gap-1.5">
                    {DEPOSIT_PRESETS.map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => {
                          sfx.click();
                          setDepAmount(String(p));
                        }}
                        className="h-8 rounded-lg border border-white/10 bg-white/[0.04] text-[11px] font-black text-white/60 transition-colors hover:bg-white/10 hover:text-white"
                      >
                        {p}
                      </button>
                    ))}
                  </div>

                  {/* txid */}
                  <div className="mt-3">
                    <input
                      value={txid}
                      onChange={(e) => setTxid(e.target.value.trim())}
                      dir="ltr"
                      spellCheck={false}
                      maxLength={64}
                      placeholder="Transaction hash (txid) — 64 characters"
                      aria-label="Transaction hash"
                      className="h-11 w-full rounded-xl border border-white/15 bg-black/40 px-3 font-mono text-xs text-white placeholder:text-white/25 focus:border-emerald-400/60 focus:outline-none"
                    />
                    {txid.length > 0 && !txidValid && (
                      <p className="mt-1 text-[10px] font-bold text-red-300">The txid must be exactly 64 hex characters.</p>
                    )}
                  </div>

                  {/* the jurisdiction declaration */}
                  <label className="mt-3 flex cursor-pointer items-start gap-2.5 rounded-xl border border-white/10 bg-white/[0.02] p-3">
                    <input
                      type="checkbox"
                      checked={depDeclared}
                      onChange={(e) => setDepDeclared(e.target.checked)}
                      className="mt-0.5 h-4 w-4 shrink-0 accent-emerald-400"
                      aria-label="Eligibility declaration"
                    />
                    <span className="text-[10px] font-semibold leading-relaxed text-white/55">{data.declaration}</span>
                  </label>

                  <button
                    type="button"
                    disabled={depBusy || !depValid || !txidValid || !depDeclared}
                    onClick={() => void submitDeposit()}
                    className="gold-btn mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-xl text-sm font-black text-black disabled:opacity-50"
                  >
                    <BadgeCheck className="h-4 w-4" />
                    {depBusy ? "SUBMITTING…" : "SUBMIT DEPOSIT"}
                  </button>
                  <p className="mt-2 text-center text-[10px] font-semibold text-white/30">
                    Deposits are reviewed manually — usually within minutes. Send TRC-20 ONLY; other networks are lost.
                  </p>
                </>
              )}
            </motion.section>

            {/* ===== WITHDRAW ===== */}
            <motion.section
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.05 }}
              className="mt-5 rounded-2xl border border-amber-400/20 bg-[#0d0a18]/90 p-5 sm:p-6"
              aria-label="Withdraw"
            >
              <div className="flex items-center gap-2">
                <ArrowUpFromLine className="h-4 w-4 text-amber-300" />
                <h2 className="font-display text-lg font-black text-white">WITHDRAW</h2>
                <span className="rounded border border-amber-400/30 bg-amber-500/10 px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wide text-amber-300">
                  USDT · TRC-20
                </span>
              </div>
              <p className="mt-3 text-[11px] font-semibold leading-relaxed text-white/50">
                The coins are locked the moment you request a payout and return instantly if the team rejects it.
              </p>

              {!method ? (
                <p className="mt-4 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-xs font-bold text-white/45">
                  Withdrawals are not open yet — the team will enable them soon.
                </p>
              ) : (
                <>
                  <div className="mt-3 grid gap-2 sm:grid-cols-2">
                    <div className="flex h-11 items-center gap-2 rounded-xl border border-white/15 bg-black/40 px-3">
                      <Coin className="h-4 w-4 shrink-0" />
                      <input
                        value={wdAmount}
                        onChange={(e) => setWdAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                        dir="ltr"
                        inputMode="decimal"
                        placeholder={`${data.minWithdraw}-${data.maxWithdraw}`}
                        aria-label="Withdrawal amount in coins"
                        className="font-display w-full bg-transparent text-sm font-black text-amber-300 tabular-nums focus:outline-none"
                      />
                    </div>
                    <div className="flex h-11 items-center gap-2 rounded-xl border border-white/15 bg-black/40 px-3">
                      <input
                        value={wdAddress}
                        onChange={(e) => setWdAddress(e.target.value.trim())}
                        dir="ltr"
                        spellCheck={false}
                        maxLength={34}
                        placeholder="Your TRC-20 address (T…)"
                        aria-label="Payout address"
                        className="w-full bg-transparent font-mono text-xs text-white placeholder:text-white/25 focus:outline-none"
                      />
                    </div>
                  </div>
                  {wdAddress.length > 0 && !wdAddressValid && (
                    <p className="mt-1 text-[10px] font-bold text-red-300">A TRC-20 address starts with T and has exactly 34 characters.</p>
                  )}

                  <label className="mt-3 flex cursor-pointer items-start gap-2.5 rounded-xl border border-white/10 bg-white/[0.02] p-3">
                    <input
                      type="checkbox"
                      checked={wdDeclared}
                      onChange={(e) => setWdDeclared(e.target.checked)}
                      className="mt-0.5 h-4 w-4 shrink-0 accent-amber-400"
                      aria-label="Eligibility declaration"
                    />
                    <span className="text-[10px] font-semibold leading-relaxed text-white/55">{data.declaration}</span>
                  </label>

                  <button
                    type="button"
                    disabled={wdBusy || !wdValid || !wdAddressValid || !wdDeclared}
                    onClick={() => void submitWithdraw()}
                    className="gold-btn mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-xl text-sm font-black text-black disabled:opacity-50"
                  >
                    <ArrowUpFromLine className="h-4 w-4" />
                    {wdBusy ? "SUBMITTING…" : "REQUEST WITHDRAWAL"}
                  </button>
                  <p className="mt-2 text-center text-[10px] font-semibold text-white/30">
                    Min {data.minWithdraw} · Max {data.maxWithdraw} USDT · one pending request at a time.
                  </p>
                </>
              )}
            </motion.section>

            {/* ===== my requests ===== */}
            {(data.deposits.length > 0 || data.withdrawals.length > 0) && (
              <section className="mt-5 rounded-2xl border border-white/10 bg-[#0d0a18]/90 p-5 sm:p-6" aria-label="My wallet history">
                <h2 className="text-sm font-black text-white">MY REQUESTS</h2>
                <ul className="mt-3 space-y-2">
                  {data.deposits.map((d) => (
                    <li key={d.id} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2.5">
                      <ArrowDownToLine className={cn("h-4 w-4 shrink-0", d.status === "approved" ? "text-emerald-300" : "text-white/35")} />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="font-display flex items-center gap-1 text-xs font-black text-white/90" dir="ltr">
                            <Coin className="h-3 w-3" /> {formatCoins(d.amountUsd)}
                          </span>
                          <StatusBadge status={d.status} />
                        </span>
                        <span className="block truncate font-mono text-[9px] text-white/35" dir="ltr">
                          {fmtWhen(d.createdAt)} · {d.txid.slice(0, 18)}…
                        </span>
                        {d.adminNote && <span className="block text-[10px] font-bold text-red-300/90">{d.adminNote}</span>}
                      </span>
                      <button
                        type="button"
                        onClick={() => void copy(d.txid, "The txid")}
                        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-white/10 bg-white/5 text-white/50 hover:text-white"
                        aria-label="Copy the txid"
                      >
                        <Copy className="h-3 w-3" />
                      </button>
                    </li>
                  ))}
                  {data.withdrawals.map((w) => (
                    <li key={w.id} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2.5">
                      <ArrowUpFromLine className={cn("h-4 w-4 shrink-0", w.status === "paid" ? "text-emerald-300" : w.status === "rejected" ? "text-red-300/80" : "text-amber-300")} />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="font-display flex items-center gap-1 text-xs font-black text-white/90" dir="ltr">
                            <Coin className="h-3 w-3" /> -{formatCoins(w.amountCoins)}
                          </span>
                          <StatusBadge status={w.status} />
                        </span>
                        <span className="block truncate font-mono text-[9px] text-white/35" dir="ltr">
                          {fmtWhen(w.createdAt)} · {w.address}
                        </span>
                        {w.payoutTxid && (
                          <span className="block truncate font-mono text-[9px] text-emerald-300/70" dir="ltr">
                            payout: {w.payoutTxid.slice(0, 18)}…
                          </span>
                        )}
                        {w.adminNote && <span className="block text-[10px] font-bold text-red-300/90">{w.adminNote}</span>}
                      </span>
                    </li>
                  ))}
                </ul>
              </section>
            )}

            <p className="mt-4 flex items-start gap-1.5 text-[10px] font-semibold leading-relaxed text-white/30">
              <X className="mt-0.5 h-3 w-3 shrink-0 text-red-300/60" />
              Restricted jurisdiction: the wallet is not available in Israel or any other jurisdiction where real-money gaming is prohibited — see the
              <Link href="/tos" className="mx-1 text-white/50 underline hover:text-white/80">Terms of Service</Link>
              (Eligibility).
            </p>
          </>
        )}
      </div>
    </main>
  );
}
