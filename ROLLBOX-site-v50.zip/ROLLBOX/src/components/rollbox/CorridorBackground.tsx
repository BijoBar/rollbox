"use client";

import { useEffect, useRef } from "react";
import { CASE_IMAGE_SLUGS, caseImagePath } from "@/lib/case-images";
import { CASES } from "@/lib/cases";

/**
 * USER SPEC (Task 84 + 85) — THE SITE BACKGROUND IS AN INFINITE NEON CORRIDOR,
 * restyled after the user's cyberpunk reference image:
 *
 * - One-point-perspective cyberpunk tunnel (canvas, 60fps): dark tech panels,
 *   vertical neon trim strips on the walls (cyan/magenta/violet, gold every
 *   6th), long light rails, glowing orange ceiling panels, fog + light core
 *   at the vanishing point and a light cyber-rain.
 * - Task 170: the floor ROLLBOX wordmark and the wall logo signs are GONE
 *   (user request) — pages now dress the corridor with their own 50%-opacity
 *   photo backdrops (PageBackdrop.tsx) instead of baked-in branding.
 * - SCROLLING = WALKING: scroll depth drives the camera forward — the further
 *   down the page, the deeper into the corridor; scroll up and you walk back.
 *   A slow idle crawl keeps it alive between scrolls.
 * - THE SITE'S CASES FLOAT inside the tunnel at every depth and SWAP RANDOMLY
 *   as you scroll (every respawn/shuffle picks a random crate artwork), with
 *   a tier-colored neon halo behind each crate.
 * - WARP BOOST (light-speed TopBar navigation): the WarpProvider fires
 *   rb-warp-start / rb-warp-done window events; the tunnel accelerates to
 *   ~light speed with motion streaks, then re-bases onto the new page's
 *   scroll position so it never flies backwards.
 *
 * Pure <canvas>, fixed behind everything (-z-10), pointer-events none,
 * DPR-capped, pauses when the tab is hidden, respects reduced-motion.
 */

const SEG = 300; // z-length of one corridor segment
const FAR = 5200; // far clip (z units past the camera)
const NEAR = 26; // near clip (camera plane)
const HALF_W = 560; // tunnel half-width (world units)
const HALF_H = 360; // tunnel half-height
const SCROLL_GAIN = 1.15; // corridor depth units per scrolled pixel
const IDLE_SPEED = 9; // permanent slow crawl (world units / s)
const WARP_SPEED = 9500; // extra depth per second at full light-speed
// USER SPEC (Task 87): fewer crates + enforced spacing — the tunnel should
// feel airy, not busy. 12 crates, and a new spawn never parks closer than
// SPRITE_GAP (normalized tunnel units) to a crate it would share the view with.
const SPRITE_COUNT = 12; // floating crates in the tunnel
const SPRITE_GAP = 0.45; // min normalized distance between co-visible crates
const SPRITE_Z_WIN = 1500; // |Δz| below which two crates compete for the same view
const SHUFFLE_EVERY = 480; // scrolled world-units between random crate swaps

// ---- Task 85 (reference-image styling) -------------------------------------
const RAIN_COUNT = 62; // subtle cyber-rain drops

// neon palette — matches the site (chart-1/3/4 + accent) and the reference
const TRIM_COLORS = ["34,211,238", "217,70,239", "139,92,246"]; // cyan / magenta / violet
const RING_COLORS = TRIM_COLORS; // warp streak palette (kept name)
const GOLD = "240,185,11";
const ORANGE = "251,146,60";

type Sprite = {
  x: number; // world x of the crate center
  y: number; // world y
  z: number; // absolute world z (camera sits at `depth`)
  w: number; // world width of the crate art
  img: number; // index into IMAGES
  phase: number; // bobbing phase
  rot: number; // static tilt
  pulse: number; // 1..0 pop effect after a random swap
};

/** Crate artwork pool + tier glow colors (same order, aligned). */
const IMAGES: { src: string; el: HTMLImageElement | null; glow: string }[] = [
  ...CASE_IMAGE_SLUGS,
].map((slug) => {
  const def = CASES.find((c) => c.id === slug);
  return { src: caseImagePath(slug), el: null, glow: def?.tierColor ?? "#8b5cf6" };
});

// crates float AROUND the content, never on it: lanes keep the central
// content column clear (a donut distribution — near crates hug walls/floor).
// Task 87: the ring is pushed a touch further OUT (0.30..0.68 / 0.28..0.60)
// so crates hug the walls/floor/ceiling and the middle stays even airier.
function randX() {
  const m = 0.3 + Math.random() * 0.38; // 0.30..0.68 of HALF_W from center
  return (Math.random() < 0.5 ? -1 : 1) * HALF_W * m;
}
function randY() {
  const m = 0.28 + Math.random() * 0.32; // 0.28..0.60 of HALF_H from center
  return (Math.random() < 0.5 ? -1 : 1) * HALF_H * m + 18;
}

/** Task 87 — anti-clump spawn: rejection-sample donut spots until the new
 *  crate keeps SPRITE_GAP (normalized) away from every crate within the
 *  |Δz| visibility window (crates far apart in z never share the frame, so
 *  they are exempt). Falls back to the best candidate found. */
function spreadSpot(sprites: Sprite[], z: number, skip = -1): { x: number; y: number } {
  let bx = randX();
  let by = randY();
  let bd = -1;
  for (let a = 0; a < 14; a++) {
    const x = randX();
    const y = randY();
    let d = Infinity;
    for (let j = 0; j < sprites.length; j++) {
      const o = sprites[j];
      if (j === skip || Math.abs(o.z - z) > SPRITE_Z_WIN) continue;
      const dx = (x - o.x) / HALF_W;
      const dy = (y - o.y) / HALF_H;
      d = Math.min(d, Math.hypot(dx, dy));
    }
    if (d > bd) {
      bd = d;
      bx = x;
      by = y;
    }
    if (d >= SPRITE_GAP) break;
  }
  return { x: bx, y: by };
}

/** hex (#rgb/#rrggbb) → rgba() string */
function hexA(hex: string, a: number): string {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((x) => x + x).join("") : h;
  const n = parseInt(full, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

/** soft radial glow blob TINTED with a case tier color (cached per color) */
const haloCache = new Map<string, HTMLCanvasElement>();
function haloFor(color: string): HTMLCanvasElement {
  let c = haloCache.get(color);
  if (!c) {
    c = document.createElement("canvas");
    c.width = c.height = 128;
    const g = c.getContext("2d");
    if (g) {
      const grad = g.createRadialGradient(64, 64, 4, 64, 64, 64);
      grad.addColorStop(0, hexA(color, 0.5));
      grad.addColorStop(0.45, hexA(color, 0.16));
      grad.addColorStop(1, hexA(color, 0));
      g.fillStyle = grad;
      g.fillRect(0, 0, 128, 128);
    }
    haloCache.set(color, c);
  }
  return c;
}

export function CorridorBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // ---- preload the crate artwork ----------------------------------------
    for (const it of IMAGES) {
      const img = new Image();
      img.src = it.src;
      img.decoding = "async";
      it.el = img;
    }

    // ---- soft white halo blob (generic additive glow) --------------------
    const halo = document.createElement("canvas");
    halo.width = halo.height = 128;
    {
      const hctx = halo.getContext("2d");
      if (hctx) {
        const g = hctx.createRadialGradient(64, 64, 4, 64, 64, 64);
        g.addColorStop(0, "rgba(255,255,255,0.7)");
        g.addColorStop(0.45, "rgba(255,255,255,0.2)");
        g.addColorStop(1, "rgba(255,255,255,0)");
        hctx.fillStyle = g;
        hctx.fillRect(0, 0, 128, 128);
      }
    }

    // ---- the floating crates (Task 87: spaced, not packed) -----------------
    // Task 188: with an EMPTY artwork pool (artwork removed pending the
    // user-supplied replacements) spawn nothing — sprites indexing IMAGES[0]
    // would crash the draw loop with `undefined.el`.
    const sprites: Sprite[] = [];
    for (let i = 0; IMAGES.length > 0 && i < SPRITE_COUNT; i++) {
      const z = NEAR + 140 + ((FAR - NEAR - 260) / SPRITE_COUNT) * i + Math.random() * 90;
      const spot = spreadSpot(sprites, z);
      sprites.push({
        x: spot.x,
        y: spot.y,
        z,
        w: 230 + Math.random() * 110,
        img: Math.floor(Math.random() * IMAGES.length),
        phase: Math.random() * Math.PI * 2,
        rot: (Math.random() * 2 - 1) * 0.12,
        pulse: 0,
      });
    }

    // ---- warp streak field --------------------------------------------------
    const streaks = Array.from({ length: 90 }, () => ({
      x: (Math.random() * 2 - 1) * HALF_W * 0.95,
      y: (Math.random() * 2 - 1) * HALF_H * 0.95,
      z: NEAR + 20 + Math.random() * (FAR - NEAR) * 0.8,
      gold: Math.random() < 0.16,
    }));

    // ---- cyber-rain (screen space, very subtle) -----------------------------
    const rain = Array.from({ length: RAIN_COUNT }, () => ({
      x: Math.random(),
      y: Math.random(),
      len: 12 + Math.random() * 18,
      spd: 620 + Math.random() * 520,
      a: 0.03 + Math.random() * 0.06,
    }));

    // ---- state --------------------------------------------------------------
    let w = 0;
    let h = 0;
    let f = 0; // focal length
    let depth = (window.scrollY || 0) * SCROLL_GAIN;
    let base = depth; // warp re-base offset: target = base + scrollY*GAIN
    let boost = 0;
    let warping = false;
    let warpT = 0;
    let shuffled = 0; // accumulated |Δdepth| since last random crate swap
    let swapCount = 0; // E2E probe: total random crate image changes
    let last = performance.now();
    let running = true;
    // PERF (Task 101): size-static gradients are built ONCE per resize —
    // createLinearGradient per frame allocated + re-rasterized 60×/s for nothing
    let grads: {
      bg: CanvasGradient;
      fl: CanvasGradient;
      wl: CanvasGradient;
      wr: CanvasGradient;
      ce: CanvasGradient;
      vig: CanvasGradient;
    } | null = null;
    // PERF (Task 101): while a case spin is live the corridor drops to 30fps —
    // the reels own the frame budget; dt-based motion keeps speed identical
    let spinCount = 0;
    let lastSpinEvt = 0;
    let lastCorrDraw = 0;
    // PERF (Task 100): scroll-driven redraws were THE site-wide stutter — the
    // canvas repainted 60×/s forever, even with zero user input. New policy:
    //   0-1.8s after last input  → full 60fps (scrolling feels 1:1)
    //   1.8-5s after last input  → 30fps idle crawl (half the cost, still alive)
    //   >5s after last input     → full SLEEP (rAF loop stops; zero GPU/CPU cost)
    // Any scroll / wheel / touch / warp / spin / resize / tab-visible event
    // wakes it instantly, and dt clamping keeps the resume smooth.
    let lastInput = performance.now();
    let dormant = false;
    const CORRIDOR_ACTIVE_MS = 1800;
    const CORRIDOR_SLEEP_MS = 5000;
    const wake = () => {
      lastInput = performance.now();
      if (dormant) {
        dormant = false;
        last = performance.now();
        requestAnimationFrame(draw);
      }
    };
    window.addEventListener("scroll", wake, { passive: true });
    window.addEventListener("wheel", wake, { passive: true });
    window.addEventListener("touchmove", wake, { passive: true });

    const buildGrads = () => {
      const gpx = w / 2;
      const gpy = h * 0.44;
      const gsFar = f / (FAR * 0.9);
      const ghhF = HALF_H * gsFar;
      const bg = ctx.createLinearGradient(0, 0, 0, h);
      bg.addColorStop(0, "#070413");
      bg.addColorStop(0.55, "#0a0618");
      bg.addColorStop(1, "#050310");
      const fl = ctx.createLinearGradient(0, gpy + ghhF, 0, h);
      fl.addColorStop(0, "rgba(19,12,48,0)");
      fl.addColorStop(1, "rgba(23,14,58,0.9)");
      const wl = ctx.createLinearGradient(0, 0, gpx, 0);
      wl.addColorStop(0, "rgba(17,10,42,0.8)");
      wl.addColorStop(1, "rgba(17,10,42,0)");
      const wr = ctx.createLinearGradient(w, 0, gpx, 0);
      wr.addColorStop(0, "rgba(17,10,42,0.8)");
      wr.addColorStop(1, "rgba(17,10,42,0)");
      const ce = ctx.createLinearGradient(0, 0, 0, gpy);
      ce.addColorStop(0, "rgba(9,5,24,0.92)");
      ce.addColorStop(1, "rgba(9,5,24,0)");
      const vig = ctx.createRadialGradient(gpx, gpy, h * 0.3, gpx, gpy, h * 0.9);
      vig.addColorStop(0, "rgba(4,2,12,0)");
      vig.addColorStop(1, "rgba(4,2,12,0.72)");
      grads = { bg, fl, wl, wr, ce, vig };
    };

    const resize = () => {
      wake(); // PERF (Task 100): repaint immediately after a resize
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      f = h * 0.95;
      buildGrads();
    };
    resize();
    window.addEventListener("resize", resize);

    // ---- warp hook (fired by WarpProvider) ----------------------------------
    const onWarpStart = () => {
      warping = true;
      warpT = 0;
      wake(); // PERF (Task 100): a warp must never start into a sleeping canvas
    };
    const onWarpDone = () => {
      warping = false;
      // re-base so the new page's scroll position (0) keeps the camera exactly
      // where the light-speed dash left it — no backward whoosh on arrival
      base = depth - (window.scrollY || 0) * SCROLL_GAIN;
    };
    window.addEventListener("rb-warp-start", onWarpStart);
    window.addEventListener("rb-warp-done", onWarpDone);

    // PERF (Task 101): CaseOpener spins throttle the corridor to 30fps while
    // they run (rb-spin-active / rb-spin-done pair; rb-spin-reset = unmount safety)
    const onSpinActive = () => {
      spinCount++;
      lastSpinEvt = performance.now();
      wake(); // PERF (Task 100): spins keep the corridor alive at 30fps
    };
    const onSpinDone = () => {
      spinCount = Math.max(0, spinCount - 1);
      lastSpinEvt = performance.now();
    };
    const onSpinReset = () => {
      spinCount = 0;
    };
    window.addEventListener("rb-spin-active", onSpinActive);
    window.addEventListener("rb-spin-done", onSpinDone);
    window.addEventListener("rb-spin-reset", onSpinReset);

    // E2E probe (harmless): lets QA assert scroll→depth + warp coupling
    (window as unknown as { __rbCorridor?: unknown }).__rbCorridor = {
      get depth() {
        return depth;
      },
      get boost() {
        return boost;
      },
      get sprites() {
        return sprites.length;
      },
      get swaps() {
        return swapCount;
      },
    };

    // ---- projection ----------------------------------------------------------
    const cx = () => w / 2;
    // the camera is pitched slightly down (reference shot): horizon at 44%
    const cy = () => h * 0.44;

    const draw = (now: number) => {
      if (!running) return;
      // PERF (Task 101): spin-active → draw at ~30fps. Skipped frames fold
      // into the next dt, so the tunnel's speed stays exactly the same.
      if (spinCount > 0) {
        if (now - lastSpinEvt > 12000) {
          spinCount = 0; // watchdog: no live spin event for 12s — never stay throttled
        } else if (now - lastCorrDraw < 33) {
          requestAnimationFrame(draw);
          return;
        }
        lastCorrDraw = now;
      } else if (!warping) {
        // PERF (Task 100): input-driven frame policy — 60fps right after
        // scrolling, 30fps idle crawl, then a full sleep (see constants above).
        const sinceInput = now - lastInput;
        if (sinceInput > CORRIDOR_SLEEP_MS) {
          dormant = true; // wake() reschedules on the next user input
          return;
        }
        if (sinceInput > CORRIDOR_ACTIVE_MS && now - lastCorrDraw < 33) {
          requestAnimationFrame(draw);
          return;
        }
        lastCorrDraw = now;
      }
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const t = now / 1000;

      // ---- camera motion ----
      const sy = window.scrollY || 0;
      const target = base + sy * SCROLL_GAIN;
      depth += (target - depth) * (1 - Math.exp(-dt * 6.5));
      if (!reduced) depth += IDLE_SPEED * dt;

      if (warping) {
        warpT += dt;
        boost = Math.min(1, boost + dt * 3.2);
      } else {
        boost *= Math.exp(-dt * 2.6);
        if (boost < 0.004) boost = 0;
      }
      const prevDepth = depth;
      depth += boost * WARP_SPEED * dt;
      const dDepth = depth - prevDepth;

      // ---- random crate swaps while scrolling (down OR up) ----
      shuffled += Math.abs(dDepth);
      while (shuffled > SHUFFLE_EVERY) {
        shuffled -= SHUFFLE_EVERY;
        for (let k = 0; sprites.length > 0 && k < 3; k++) { // Task 188: empty-pool guard
          const s = sprites[Math.floor(Math.random() * sprites.length)];
          s.img = Math.floor(Math.random() * IMAGES.length);
          s.pulse = 1;
          swapCount++;
        }
      }

      // ---- paint (gradients prebuilt per resize — PERF Task 101) ----
      if (!grads) buildGrads();
      ctx.fillStyle = grads!.bg;
      ctx.fillRect(0, 0, w, h);

      const px = cx();
      const py = cy();
      const zN = NEAR + 4;

      // ---- corridor surfaces (floor / walls / ceiling trapezoids) ----
      {
        const sNear = f / zN;
        const sFar = f / (FAR * 0.9);
        const hwN = HALF_W * sNear;
        const hhN = HALF_H * sNear;
        const hwF = HALF_W * sFar;
        const hhF = HALF_H * sFar;
        // floor: dark glossy blue-purple, brighter near the camera
        ctx.fillStyle = grads!.fl;
        ctx.beginPath();
        ctx.moveTo(px - hwN, py + hhN);
        ctx.lineTo(px + hwN, py + hhN);
        ctx.lineTo(px + hwF, py + hhF);
        ctx.lineTo(px - hwF, py + hhF);
        ctx.closePath();
        ctx.fill();
        // walls: dark tech panels
        ctx.fillStyle = grads!.wl;
        ctx.beginPath();
        ctx.moveTo(px - hwN, py - hhN);
        ctx.lineTo(px - hwN, py + hhN);
        ctx.lineTo(px - hwF, py + hhF);
        ctx.lineTo(px - hwF, py - hhF);
        ctx.closePath();
        ctx.fill();
        const wr = grads!.wr;
        ctx.fillStyle = wr;
        ctx.beginPath();
        ctx.moveTo(px + hwN, py - hhN);
        ctx.lineTo(px + hwN, py + hhN);
        ctx.lineTo(px + hwF, py + hhF);
        ctx.lineTo(px + hwF, py - hhF);
        ctx.closePath();
        ctx.fill();
        // ceiling: darkest
        ctx.fillStyle = grads!.ce;
        ctx.beginPath();
        ctx.moveTo(px - hwN, py - hhN);
        ctx.lineTo(px + hwN, py - hhN);
        ctx.lineTo(px + hwF, py - hhF);
        ctx.lineTo(px - hwF, py - hhF);
        ctx.closePath();
        ctx.fill();
      }

      // vanishing-point light core (pulsing)
      const coreR = h * (0.15 + Math.sin(t * 1.6) * 0.02);
      const core = ctx.createRadialGradient(px, py, 2, px, py, coreR);
      core.addColorStop(0, "rgba(190,247,255,0.34)");
      core.addColorStop(0.25, "rgba(103,232,249,0.14)");
      core.addColorStop(0.6, "rgba(139,92,246,0.06)");
      core.addColorStop(1, "rgba(139,92,246,0)");
      ctx.fillStyle = core;
      ctx.fillRect(px - coreR, py - coreR, coreR * 2, coreR * 2);

      // ---- corridor segments: seams, neon trims, ceiling accents ----
      ctx.lineCap = "round";
      const firstK = Math.floor(depth / SEG) + 1;
      for (let k = firstK; ; k++) {
        const z = k * SEG - depth; // segment near boundary
        const z1 = z + SEG; // segment far boundary
        if (z1 < NEAR) continue;
        if (z > FAR) break;
        const sN = f / Math.max(z, NEAR);
        const fog = Math.pow(Math.max(0, 1 - (z + SEG / 2) / FAR), 1.6);
        const hwN = HALF_W * sN;
        const hhN = HALF_H * sN;

        // panel seams at the boundary (walls + floor + ceiling)
        if (z > NEAR) {
          ctx.strokeStyle = `rgba(148,120,255,${0.13 * fog})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(px - hwN, py - hhN);
          ctx.lineTo(px - hwN, py + hhN);
          ctx.moveTo(px + hwN, py - hhN);
          ctx.lineTo(px + hwN, py + hhN);
          ctx.moveTo(px - hwN, py + hhN);
          ctx.lineTo(px + hwN, py + hhN);
          ctx.moveTo(px - hwN, py - hhN);
          ctx.lineTo(px + hwN, py - hhN);
          ctx.stroke();
        }

        // vertical neon trim columns on both walls (reference's wall strips)
        const col = k % 6 === 0 ? GOLD : TRIM_COLORS[k % TRIM_COLORS.length];
        const barH = hhN * 0.44;
        ctx.strokeStyle = `rgba(${col},${0.6 * fog})`;
        ctx.lineWidth = Math.min(4, Math.max(0.8, 2.2 * sN * 24));
        ctx.beginPath();
        ctx.moveTo(px - hwN, py - barH);
        ctx.lineTo(px - hwN, py + barH);
        ctx.moveTo(px + hwN, py - barH);
        ctx.lineTo(px + hwN, py + barH);
        ctx.stroke();
        // soft glow pass over the same path
        ctx.strokeStyle = `rgba(${col},${0.12 * fog})`;
        ctx.lineWidth = Math.min(9, Math.max(2, 6 * sN * 24));
        ctx.stroke();

        // glowing orange ceiling panel every 6th segment (reference accent)
        if (k % 6 === 0) {
          const cz0 = Math.max(z + 40, NEAR);
          const cz1 = z1 - 40;
          if (cz1 > cz0) {
            const a0 = f / cz0;
            const a1 = f / cz1;
            ctx.save();
            ctx.globalCompositeOperation = "lighter";
            ctx.fillStyle = `rgba(${ORANGE},${(0.1 + 0.05 * Math.sin(t * 2 + k)) * fog})`;
            ctx.beginPath();
            ctx.moveTo(px - 230 * a0, py - HALF_H * a0);
            ctx.lineTo(px + 230 * a0, py - HALF_H * a0);
            ctx.lineTo(px + 230 * a1, py - HALF_H * a1);
            ctx.lineTo(px - 230 * a1, py - HALF_H * a1);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
          }
        }

      }

      // ---- longitudinal rails (floor / ceiling / wall mids) ----
      const zF2 = FAR * 0.86;
      const rails: [number, number][] = [
        [-HALF_W, HALF_H],
        [-HALF_W / 2, HALF_H],
        [HALF_W / 2, HALF_H],
        [HALF_W, HALF_H],
        [-HALF_W, -HALF_H],
        [0, -HALF_H],
        [HALF_W, -HALF_H],
        [-HALF_W, 0],
        [HALF_W, 0],
      ];
      ctx.lineWidth = 1;
      for (const [rx, ry] of rails) {
        const sN2 = f / zN;
        const sF2 = f / zF2;
        const isFloor = ry === HALF_H;
        ctx.strokeStyle = `rgba(${TRIM_COLORS[0]},${isFloor ? 0.11 : 0.055})`;
        ctx.beginPath();
        ctx.moveTo(px + rx * sN2, py + ry * sN2);
        ctx.lineTo(px + rx * sF2, py + ry * sF2);
        ctx.stroke();
      }

      // ---- floating crates (far → near) ----
      const order = sprites
        .map((s, i) => ({ i, z: s.z - depth }))
        .sort((a, b) => b.z - a.z);
      for (const { i, z: zRel0 } of order) {
        const s = sprites[i];
        let zRel = zRel0;
        // recycling: passed behind the camera → reborn deep ahead (random crate);
        // scrolled back past the far clip → reborn near (random crate too)
        if (zRel < NEAR + 60) {
          s.z += FAR - NEAR;
          const spot = spreadSpot(sprites, s.z, i);
          s.x = spot.x;
          s.y = spot.y;
          s.img = Math.floor(Math.random() * IMAGES.length);
          s.pulse = 0.6;
          swapCount++;
          continue;
        }
        if (zRel > FAR + 240) {
          s.z -= FAR - NEAR;
          const spot = spreadSpot(sprites, s.z, i);
          s.x = spot.x;
          s.y = spot.y;
          s.img = Math.floor(Math.random() * IMAGES.length);
          s.pulse = 0.6;
          swapCount++;
          continue;
        }
        const art = IMAGES[s.img].el;
        if (!art || !art.complete || art.naturalWidth === 0) continue;
        const fog = Math.pow(Math.max(0, 1 - zRel / FAR), 1.25);
        // near fade — crates dissolve just before they fill the screen
        const nearFade = Math.min(1, Math.max(0, (zRel - NEAR - 90) / 220));
        const alpha = fog * nearFade;
        if (alpha < 0.04) continue;
        const sc = f / zRel;
        s.pulse *= Math.exp(-dt * 3);
        const bobA = reduced ? 0 : Math.sin(t * 0.7 + s.phase) * 16;
        const bobB = reduced ? 0 : Math.cos(t * 0.53 + s.phase * 1.7) * 10;
        const sx = px + (s.x + bobA) * sc;
        const sy2 = py + (s.y + bobB) * sc;
        // never let a near crate dominate the frame
        const maxCw = Math.min(w, h) * 0.34;
        const cw0 = s.w * (1 + s.pulse * 0.22) * sc;
        const cw = Math.min(cw0, maxCw);
        const ch = cw * (615 / 800);
        if (cw < 6 || sx < -cw || sx > w + cw || sy2 < -ch || sy2 > h + ch) continue;

        // tier-colored halo (additive) behind the crate
        const glow = IMAGES[s.img].glow;
        const hr = cw * 0.95;
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = alpha * 0.34;
        ctx.drawImage(haloFor(glow), sx - hr, sy2 - hr, hr * 2, hr * 2);
        ctx.globalAlpha = alpha * 0.12;
        ctx.drawImage(halo, sx - hr, sy2 - hr, hr * 2, hr * 2);
        ctx.restore();

        // the crate itself
        ctx.save();
        ctx.globalAlpha = Math.min(0.92, alpha);
        ctx.translate(sx, sy2);
        ctx.rotate(s.rot + (reduced ? 0 : Math.sin(t * 0.4 + s.phase) * 0.045));
        ctx.drawImage(art, -cw / 2, -ch / 2, cw, ch);
        ctx.restore();
      }

      // ---- light-speed streaks ----
      if (boost > 0.02 && !reduced) {
        ctx.lineCap = "round";
        for (const st of streaks) {
          const zRel = ((st.z - depth) % (FAR - NEAR) + FAR - NEAR) % (FAR - NEAR) + NEAR;
          const len = (60 + boost * 2400) * (0.35 + zRel / 1600);
          const sN3 = f / zRel;
          const sFar = f / Math.min(FAR, zRel + len);
          const fog = Math.max(0, 1 - zRel / (FAR * 0.8));
          if (fog <= 0.02) continue;
          const col = st.gold ? GOLD : RING_COLORS[Math.floor(st.x + st.y) % 2 === 0 ? 0 : 2];
          ctx.strokeStyle = `rgba(${col},${Math.min(0.85, boost * fog * 0.9)})`;
          ctx.lineWidth = st.gold ? 2.4 : 1.5;
          ctx.beginPath();
          ctx.moveTo(px + st.x * sN3, py + st.y * sN3);
          ctx.lineTo(px + st.x * sFar, py + st.y * sFar);
          ctx.stroke();
        }
      }

      // ---- cyber-rain (reference mood, extremely subtle) ----
      if (!reduced) {
        ctx.lineWidth = 1;
        for (const r of rain) {
          r.y += (r.spd * dt) / h;
          r.x -= (r.spd * 0.05 * dt) / w;
          if (r.y > 1.08) {
            r.y = -0.08;
            r.x = Math.random() * 1.15;
          }
          if (r.x < -0.05) r.x += 1.1;
          const rx = r.x * w;
          const ry = r.y * h;
          ctx.strokeStyle = `rgba(190,235,255,${r.a})`;
          ctx.beginPath();
          ctx.moveTo(rx, ry);
          ctx.lineTo(rx - r.len * 0.08, ry + r.len);
          ctx.stroke();
        }
      }

      // ---- vignette ----
      ctx.fillStyle = grads!.vig;
      ctx.fillRect(0, 0, w, h);

      requestAnimationFrame(draw);
    };

    requestAnimationFrame(draw);

    const onVis = () => {
      if (document.hidden) {
        running = false;
      } else if (!running) {
        running = true;
        last = performance.now();
        requestAnimationFrame(draw);
      }
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      running = false;
      window.removeEventListener("resize", resize);
      window.removeEventListener("scroll", wake);
      window.removeEventListener("wheel", wake);
      window.removeEventListener("touchmove", wake);
      window.removeEventListener("rb-warp-start", onWarpStart);
      window.removeEventListener("rb-warp-done", onWarpDone);
      window.removeEventListener("rb-spin-active", onSpinActive);
      window.removeEventListener("rb-spin-done", onSpinDone);
      window.removeEventListener("rb-spin-reset", onSpinReset);
      document.removeEventListener("visibilitychange", onVis);
      delete (window as unknown as { __rbCorridor?: unknown }).__rbCorridor;
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 h-full w-full"
    />
  );
}
