"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Target,
  Mail,
  Swords,
  TrendingUp,
  ShieldCheck,
  Crown,
  Cloud,
  Gem,
  Tractor,
  TerminalSquare,
  Heart,
  CheckCircle2,
  Clock,
  Circle,
  Gift,
  Sparkles,
} from "lucide-react";
import { MISSIONS, MISSION_PRIZE_LABEL, type Mission } from "@/lib/missions";
import { missionDoneCount, stepProgress, type MissionCounters } from "@/lib/missions-progress";
import { DISCORD_INVITE } from "@/lib/site";
import { useSession } from "@/lib/session";
import { useMounted } from "@/hooks/use-mounted";
import { useToast } from "@/hooks/use-toast";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";

/* ===== MISSIONS board (Task 31 board + Task 32 LIVE progress — USER SPEC) =====
   The owner: mission progress lives IN THE DB, on the player's own row
   (Player.missions). This board fetches /api/missions once per load and
   renders each step's lifetime progress (counter → bar) with the shared
   mapping in src/lib/missions-progress.ts — server and UI always agree.
   USER SPEC (Task 183): every prize is ONE FREE RB-106 box — the server
   grants it the moment all live steps are done (the read that claims), and
   the card's Reward chip flips to a green CLAIMED. */

const ICONS: Record<string, typeof Mail> = {
  m1: Mail,
  m2: Swords,
  m3: TrendingUp,
  m4: ShieldCheck,
  m5: Crown,
  m6: Cloud,
  m7: Gem,
  m8: Tractor,
  m9: TerminalSquare,
  m10: Heart,
};

const ACCENTS: Record<string, string> = {
  m1: "#38bdf8",
  m2: "#f0b90b",
  m3: "#34d399",
  m4: "#a78bfa",
  m5: "#fbbf24",
  m6: "#7dd3fc",
  m7: "#f472b6",
  m8: "#84cc16",
  m9: "#fb923c",
  m10: "#c084fc",
};

/** deposit steps show their goal in dollars */
const DOLLAR_STEPS = new Set(["m4s1", "m6s2", "m7s1"]);

function ProgressChip({ stepId, c }: { stepId: string; c: MissionCounters }) {
  const p = stepProgress(stepId, c);
  if (!p) return null;
  const pct = Math.min(100, Math.round((p.cur / p.goal) * 100));
  const dollar = DOLLAR_STEPS.has(stepId);
  return (
    <span className="ml-auto flex shrink-0 items-center gap-1.5" dir="ltr">
      <span className="h-1 w-10 overflow-hidden rounded-full bg-white/10 sm:w-14" aria-hidden="true">
        <span
          className={cn("block h-full rounded-full transition-all", p.done ? "bg-emerald-400" : "bg-amber-400")}
          style={{ width: `${pct}%` }}
        />
      </span>
      <span
        className={cn("text-[10px] font-black tabular-nums", p.done ? "text-emerald-300" : "text-white/45")}
        aria-label={`Progress ${p.cur} of ${p.goal}`}
      >
        {dollar ? "$" : ""}
        {p.cur}/{dollar ? "$" : ""}
        {p.goal}
      </span>
    </span>
  );
}

function MissionCard({
  mission,
  index,
  c,
  claimed,
}: {
  mission: Mission;
  index: number;
  c: MissionCounters | null;
  claimed: boolean;
}) {
  const Icon = ICONS[mission.id] ?? Target;
  const accent = ACCENTS[mission.id] ?? "#f0b90b";
  const soonSteps = mission.steps.filter((s) => !s.live).length;
  const liveSteps = mission.steps.length - soonSteps;
  const doneSteps = c ? missionDoneCount(mission.steps, c) : 0;
  const allDone = liveSteps > 0 && doneSteps >= liveSteps;
  return (
    <article
      className="relative overflow-hidden rounded-2xl border bg-[#0d1220]/85 p-5"
      style={{ borderColor: `${accent}44`, boxShadow: `0 0 22px ${accent}14` }}
    >
      {/* index watermark */}
      <span
        className="font-display pointer-events-none absolute -right-1 -top-3 select-none text-6xl font-black opacity-[0.07]"
        aria-hidden="true"
      >
        {String(index + 1).padStart(2, "0")}
      </span>

      <header className="flex items-center gap-3">
        <span
          className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border"
          style={{ borderColor: `${accent}55`, background: `${accent}18`, color: accent }}
        >
          <Icon className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <p className="text-[10px] font-black uppercase tracking-[0.25em] text-white/40">
            Mission {index + 1}
          </p>
          <h2 className="font-display truncate text-lg font-black text-white" title={mission.name}>
            {mission.name}
          </h2>
        </div>
        {c && liveSteps > 0 && (
          <span
            className={cn(
              "font-display ml-auto shrink-0 rounded-lg border px-2 py-1 text-[11px] font-black tabular-nums",
              allDone
                ? "border-emerald-400/50 bg-emerald-500/15 text-emerald-300"
                : "border-white/10 bg-white/[0.04] text-white/55",
            )}
            aria-label={`${doneSteps} of ${liveSteps} steps completed`}
          >
            {doneSteps}/{liveSteps}
          </span>
        )}
      </header>

      <ol className="mt-4 space-y-2.5">
        {mission.steps.map((step, si) => {
          const p = c ? stepProgress(step.id, c) : null;
          const done = !!p?.done;
          return (
            <li key={step.id} className="flex items-center gap-2.5">
              {done ? (
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" aria-label="Step completed" />
              ) : step.live ? (
                <Circle className="h-4 w-4 shrink-0 text-white/25" aria-label="Step in progress" />
              ) : (
                <Clock className="h-4 w-4 shrink-0 text-sky-300/70" aria-label="Step coming soon" />
              )}
              <span
                className={cn(
                  "text-sm font-semibold leading-snug",
                  done ? "text-emerald-200/90" : "text-white/80",
                )}
              >
                {step.label}
              </span>
              {!step.live && (
                <span
                  className="ml-auto shrink-0 rounded bg-sky-400/15 px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wider text-sky-300"
                  title="This step unlocks together with the email / Discord / newsletter systems"
                >
                  Soon
                </span>
              )}
              {c && step.live && !done && <ProgressChip stepId={step.id} c={c} />}
              <span className="sr-only">{`Step ${si + 1}`}</span>
            </li>
          );
        })}
      </ol>

      <footer className="mt-4 flex items-center justify-between border-t border-white/[0.07] pt-3">
        <span className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-widest text-white/45">
          <Gift className="h-3.5 w-3.5" />
          Reward
        </span>
        {claimed ? (
          <span
            className="font-display flex items-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-2.5 py-1 text-xs font-black tracking-widest text-emerald-300"
            aria-label="Prize granted — a free RB-106 box is in your account"
          >
            <CheckCircle2 className="h-3.5 w-3.5" />
            {MISSION_PRIZE_LABEL} — CLAIMED
          </span>
        ) : (
          <span className="font-display rounded-lg border border-amber-400/30 bg-amber-400/10 px-2.5 py-1 text-xs font-black tracking-widest text-amber-300">
            {mission.prize}
          </span>
        )}
      </footer>

      {soonSteps > 0 && (
        <p className="mt-2 text-[10px] font-semibold leading-relaxed text-white/35">
          {soonSteps} step{soonSteps > 1 ? "s" : ""} unlock{soonSteps > 1 ? "" : "s"} with the upcoming email / Discord / newsletter systems.
        </p>
      )}
    </article>
  );
}

export function MissionsBoard() {
  const mounted = useMounted();
  const { player: me } = useSession();
  const { toast } = useToast();
  const [fetched, setFetched] = useState<MissionCounters | null>(null);
  // USER SPEC (Task 183): mission ids whose FREE Doppler Realm Case was already granted
  const [claimedIds, setClaimedIds] = useState<Set<string>>(new Set());
  // guests render without personal progress — the fetch state is simply ignored
  const counters = me ? fetched : null;

  // the DB is the source of truth — one fetch per load carries the whole state
  useEffect(() => {
    if (!me) return;
    let alive = true;
    fetch("/api/missions", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d: { state?: { c?: MissionCounters; g?: string[] } | null; granted?: string[] } | null) => {
        if (!alive) return;
        setFetched(d?.state?.c ?? {});
        setClaimedIds(new Set(d?.state?.g ?? []));
        // the read just PAID a mission — celebrate the free RB-106 landing
        const fresh = d?.granted ?? [];
        if (fresh.length) {
          sfx.coins();
          const names = fresh
            .map((id) => MISSIONS.find((m) => m.id === id)?.name)
            .filter(Boolean)
            .join(", ");
          toast({
            title: `Mission complete — ${MISSION_PRIZE_LABEL} added!`,
            description: names ? `Prize claimed for: ${names}. Find the FREE chip on the case cards.` : undefined,
          });
        }
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [me, toast]);

  const totalLive = MISSIONS.reduce((n, m) => n + m.steps.filter((s) => s.live).length, 0);
  const totalDone = counters ? MISSIONS.reduce((n, m) => n + missionDoneCount(m.steps, counters), 0) : 0;

  return (
    <main className="relative min-h-screen pb-20">
      {/* header */}
      <section className="relative mx-auto max-w-[1100px] px-4 pt-10 text-center">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-fuchsia-400/30 bg-fuchsia-500/10 px-3 py-1 text-[10px] font-black uppercase tracking-[0.3em] text-fuchsia-300">
          <Sparkles className="h-3 w-3" />
          Missions
        </span>
        <h1 className="font-display mt-4 text-4xl font-black text-white sm:text-5xl">
          Missions
        </h1>
        <p className="mx-auto mt-3 max-w-[620px] text-sm font-semibold leading-relaxed text-white/55">
          Ten challenges, ten prizes. Play battles, ride the upgrader, farm the FARM
          cases and climb the board — every completed mission pays a
          {" "}<span className="font-black text-amber-300">FREE Doppler Realm Case</span>, waiting on your case cards with the FREE chip.
        </p>

        {mounted && me ? (
          <p className="mt-4 inline-flex items-center gap-2 rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-2 text-xs font-black text-emerald-200" dir="ltr">
            <Target className="h-3.5 w-3.5" />
            YOUR PROGRESS — {totalDone}/{totalLive} STEPS DONE
          </p>
        ) : (
          <Link
            href="/login"
            className="neon-btn mt-4 inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-black text-white"
          >
            Sign in to track your progress
          </Link>
        )}

        <div className="mt-3">
          <a
            href={DISCORD_INVITE}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-xl border border-indigo-400/40 bg-indigo-500/15 px-4 py-2 text-xs font-black uppercase tracking-widest text-indigo-200 transition-colors hover:bg-indigo-500/25 hover:text-white"
          >
            <Heart className="h-4 w-4" />
            Join the Discord
          </a>
        </div>
      </section>

      {/* the board */}
      <section
        className="mx-auto mt-8 grid max-w-[1100px] grid-cols-1 gap-4 px-4 md:grid-cols-2"
        aria-label="Mission board"
      >
        {MISSIONS.map((m, i) => (
          <MissionCard key={m.id} mission={m} index={i} c={counters} claimed={claimedIds.has(m.id)} />
        ))}
      </section>

      {/* footnote */}
      <p className="mx-auto mt-8 max-w-[720px] px-4 text-center text-[11px] font-semibold leading-relaxed text-white/35">
        Email verification, Discord account linking and the automatic newsletter are
        being built right now — the steps marked SOON start counting the moment they land.
      </p>
    </main>
  );
}
