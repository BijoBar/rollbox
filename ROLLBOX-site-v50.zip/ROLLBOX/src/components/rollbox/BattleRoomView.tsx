"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Bot,
  Eye,
  Flame,
  Lock,
  RotateCcw,
  ShieldCheck,
  Swords,
  Trophy,
  UserX,
  Users,
  Zap,
} from "lucide-react";
import { CASES, RARITY_META, SKINS, formatCoins, rollCase, type CaseDef } from "@/lib/cases";
import { wearIdFromLabel, displayWearLabel, wearColorOf, wearShortOf } from "@/lib/wear";
import {
  BATTLE_MODES,
  BATTLE_TYPES,
  TEAM_META,
  battleCases,
  battleEntry,
  computeOutcome,
  drawJackpotWinner,
  dropTotal,
  emptySeats,
  jackpotPct,
  jackpotTeamPct,
  jackpotTeamWeights,
  jackpotWeights,
  playerColor,
  potRuleOf,
  sharedSplit,
  shortSkinName,
  sideOf,
  splitTeamPot,
  takePerPlayer,
  type Battle,
  type BattlePlayer,
  type BattlePull,
  type BattleResult,
} from "@/lib/battles";
import { useBattleTraffic, viewersFor } from "@/lib/battles-ui";
import { useCaseStore } from "@/lib/store";
import { maybeRollDrop, rareCaseOf, rolldropChanceOf, ROLLDROP_MARKER } from "@/lib/rolldrop";
import { emitWinFx } from "@/lib/win-fx";
import { sfx } from "@/lib/sound";
import { xpForCase } from "@/lib/progress";
import { CaseImage } from "./CaseImage";
import { CaseDropsDialog } from "./CaseDropsDialog";
import { SkinImage } from "./SkinImage";
import { RarityBackdrop } from "./RarityBackdrop";
import { Coin } from "./Coin";
import { BattleReel, WinnerPlate } from "./BattleReel";
import { TieBreakerReel, type TieParticipant } from "./TieBreakerReel";
import { JackpotReel, type JackpotParticipant } from "./JackpotReel";
import { PlayerAvatar } from "./BattleBits";
import { hashSeed } from "@/lib/seeded";
import { SiteShell } from "./SiteShell";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// USER SPEC (Task 59): the reel lengths live in gbattle-shared (ONE source of
// truth — the SERVER builds the shared-clock schedule from the same numbers so
// a round can never flip before every seat's reel landed; that mismatch was
// the "round skips before the other players' drops show" bug).
import { REEL_YOU_MS, REEL_OTHER_MS, REEL_STAGGER_MS, RD_BEAT_MS } from "@/lib/gbattle-shared";
const ROUND_GAP_MS = 900;
/** Anti-freeze backstop for the lock-wait flip gate (never a pacing tool —
 *  the shared clock + the reels own the pacing; this only fires if a pull
 *  somehow never arrives). */
const REVEAL_BACKSTOP_MS = 3000;

/** One seat's reel length — the case-style cinematic spin. USER SPEC (R40):
 *  FAST MODE is DELETED — every battle plays the normal pacing, always. */
function seatReelMs(isYou: boolean, pi: number): number {
  if (isYou) return REEL_YOU_MS;
  return REEL_OTHER_MS + Math.max(0, pi - 1) * REEL_STAGGER_MS;
}

/** The longest reel an n-seat room can play (the last seat as a non-"you"
 *  viewer) — mirrors the server's maxReelMs schedule math. */
function roomMaxReelMs(n: number): number {
  return seatReelMs(false, Math.max(0, n - 1));
}

/** MULTIPLAYER: the server-side room actions the original view calls instead
 *  of the local store flows when the battle lives on the server (global). */
export interface ServerRoomActions {
  callBots: () => void;
  /** USER SPEC (Task 67): CHOOSE BOT — seat a SPECIFIC [RBbot] in an empty seat */
  chooseBot: (bot: string, team: 0 | 1 | null, side?: 0 | 1) => void;
  leave: () => void;
  join: () => void;
  runItBack: () => void;
  busy: boolean;
}

/** The room's client clock: waiting → countdown → fighting → verdict. */
type RoomPhase = "waiting" | "countdown" | "playing" | "tiebreak" | "jackpot" | "done";

export function BattleRoomView({ battleId, serverActions, extraCases }: { battleId: string; serverActions?: ServerRoomActions; extraCases?: CaseDef[] }) {
  const router = useRouter();
  const { toast } = useToast();

  const battle = useCaseStore((s) => s.battles.find((b) => b.id === battleId));
  const historyBattle = useCaseStore((s) => s.battleHistory.find((b) => b.id === battleId));
  const balance = useCaseStore((s) => s.balance);

  // simulated traffic keeps LOCAL bot battles alive while the room is open —
  // server battles (global mirror) are fully server-driven, traffic hands off
  useBattleTraffic(!battle?.global);

  // USER SPEC (battles × COMMUNITY/EVENT): rounds may reference cases outside
  // the static catalog (player-built cc_* crates) — the room's resolved defs
  // merge over CASES everywhere the room renders or mirrors case data.
  const caseById = (id: string) => CASES.find((c) => c.id === id) ?? extraCases?.find((c) => c.id === id);

  const [phase, setPhase] = useState<RoomPhase>("waiting");
  const [countdown, setCountdown] = useState(3);
  const [round, setRound] = useState(-1); // current round index
  const [revealed, setRevealed] = useState<Record<string, number>>({}); // playerId -> rounds locked
  // USER SPEC (Task 66): synchronous mirror of `revealed` — the server-paced
  // round clock reads it to hold a flip while any seat's reel is still spinning.
  const revealedRef = useRef<Record<string, number>>({});
  const [drawn, setDrawn] = useState<Map<string, BattleResult>>(new Map()); // pre-drawn pulls per player
  const [results, setResults] = useState<BattleResult[]>([]);
  const [winnerIds, setWinnerIds] = useState<string[]>([]);
  const [shares, setShares] = useState<Record<string, number> | null>(null);
  const [decidedByTie, setDecidedByTie] = useState(false);
  const [decidedByJackpot, setDecidedByJackpot] = useState(false);
  const [tie, setTie] = useState<{ participants: TieParticipant[]; winnerKey: string } | null>(null);
  // USER SPEC (Task 42): the JACKPOT draw reel state
  const [jackpot, setJackpot] = useState<{ participants: JackpotParticipant[]; winnerKey: string } | null>(null);
  // USER SPEC (Task 177): the CHOOSE BOT picker is DELETED — the hand-picked
  // opponent flow (per-seat bot selection dialog) is gone for good; "Call
  // Bots" remains the one way to fill the empty seats.

  // live viewers badge — refreshes with the viewer-count bucket (players only, never bots)
  const [, setViewerTick] = useState(0);
  useEffect(() => {
    const t = window.setInterval(() => setViewerTick((v) => v + 1), 4000);
    return () => window.clearInterval(t);
  }, []);

  const timersRef = useRef<number[]>([]);
  const startedRef = useRef(false);
  // BUGFIX (Task 169): the highest round the clock has advanced to — stale
  // backstop timers from a previous pass (a tab-wake resync restarts the
  // chain) must never drag the round BACKWARD
  const curRoundRef = useRef(-1);
  // BUGFIX (Task 169): each startServerClock pass gets a run id — a stale
  // advance() timer from a superseded pass (tab-wake resync) is filtered out
  const clockRunRef = useRef(0);
  // BUGFIX (Task 169): mirror of `phase` for the tab-wake resync handler
  const phaseRef = useRef<RoomPhase>("waiting");
  phaseRef.current = phase;
  // spectator replay guard — a watched battle is animated exactly once per mount
  const spectateStartedRef = useRef(false);
  // bounded case strip — auto-scrolls to the round in play (user spec)
  const stripRef = useRef<HTMLDivElement>(null);
  // USER SPEC (Task 80): VIEW DROPS on every case tile of the battle strip —
  // opens the case's full contents (skins + odds + values) right in the room
  const [dropsCase, setDropsCase] = useState<CaseDef | null>(null);

  useEffect(() => {
    if (round < 0) return;
    const box = stripRef.current;
    const el = box?.querySelector<HTMLElement>(`[data-round="${round}"]`);
    if (!box || !el) return;
    box.scrollTo({ left: el.offsetLeft - box.clientWidth / 2 + el.clientWidth / 2, behavior: "smooth" });
  }, [round, phase]);

  const later = useCallback((fn: () => void, ms: number) => {
    const id = window.setTimeout(fn, ms);
    timersRef.current.push(id);
    return id;
  }, []);

  const clearTimers = useCallback(() => {
    for (const id of timersRef.current) window.clearTimeout(id);
    timersRef.current = [];
  }, []);

  useEffect(() => clearTimers, [clearTimers]);

  // live total value of every skin dropped so far (all players) — the payout.
  // Hooks must run on every render, so this lives above any early return.
  const liveDrops = useMemo(
    () =>
      [...drawn.values()].reduce(
        (s, d) => s + d.pulls.slice(0, revealed[d.playerId] ?? 0).reduce((a, x) => a + x.value, 0),
        0
      ),
    [drawn, revealed]
  );

  // spectator view — a bot-only battle (no "you" seat) the visitor is watching
  const spectateBattle = battle && !battle.players.some((p) => p.isYou) ? battle : null;
  const spectateHistory =
    !battle && historyBattle && !historyBattle.players.some((p) => p.isYou) ? historyBattle : null;
  const spectating =
    !!(battle ?? historyBattle) && !(battle ?? historyBattle)!.players.some((p) => p.isYou);
  // payout is a stable callback — it reads the spectator flag through a ref
  const spectatingRef = useRef(false);
  spectatingRef.current = spectating;

  /* ---------- finish: totals, decider on tie, payout ---------- */

  const payout = useCallback((b: Battle, settled: BattleResult[], winnerIds: string[], fromTie: boolean) => {
    const st = useCaseStore.getState();
    // MULTIPLAYER: the server already paid the DB balances — the client only
    // presents the verdict; the per-player takes come from the server itself.
    const serverTake = b.global ? st.battles.find((x) => x.id === b.id)?.take ?? undefined : undefined;
    // PAYOUT = the total value of every skin that actually dropped in this
    // battle (all players, all rounds) — NOT the entries/prize pool.
    const drops = dropTotal(settled);
    let shares: Record<string, number>;
    if (serverTake) {
      shares = serverTake;
    } else if (potRuleOf(b) === "shared") {
      // USER SPEC (Task 42): SHARED — every player walks away with an equal
      // cut of the whole pot; there are no losers to transfer skins from
      shares = sharedSplit(drops, b.players);
    } else if (b.teamMode) {
      // the winning squad splits the dropped value equally; an odd remainder
      // goes to the stronger player (the one who unboxed more this battle)
      const winners = b.players.filter((p) => winnerIds.includes(p.id));
      shares = splitTeamPot(drops, b.players, winners, settled);
    } else {
      shares = { [winnerIds[0]]: drops };
    }
    setShares(shares);
    setDecidedByTie(fromTie);

    const you = b.players.find((p) => p.isYou);
    const myShare = you ? shares[you.id] ?? 0 : 0;
    if (myShare > 0) {
      if (!b.global) st.creditWin(myShare); // the server already credited DB balances
      emitWinFx(myShare);
      sfx.win(true);
    } else if (!spectatingRef.current) {
      sfx.error();
    }

    setWinnerIds(winnerIds);
    setPhase("done");
    // FIX: LOCAL battles only — the finished record moves to battleHistory.
    // GLOBAL (server) battles must KEEP their mirror in `s.battles`: the
    // server already settled/paid, and RECREATE reads the room config from
    // the live mirror — finishBattle here used to yank it away (the poll had
    // already stopped), leaving the RECREATE BATTLE click dead after the
    // JACKPOT draw and the decider reel (winner/shared paths never did this).
    if (!b.global) st.finishBattle(b.id, settled, winnerIds);
  }, []);

  const settle = useCallback(
    (id: string, drawnMap: BattleResult[]) => {
      const st = useCaseStore.getState();
      const b = st.battles.find((x) => x.id === id);
      if (!b) return;
      const settled = b.players
        .map((p) => drawnMap.find((d) => d.playerId === p.id))
        .filter(Boolean) as BattleResult[];
      setResults(settled);

      const rule = potRuleOf(b);
      if (rule === "jackpot") {
        // USER SPEC (Task 42): the JACKPOT draw — the winner is drawn right
        // here by weight (bigger haul = better odds; CRAZY flips it), then the
        // dedicated reel above the battle lands on that exact winner.
        // USER SPEC (Task 43): in 2v2 the wheel spins per TEAM — segments are
        // sized by each team's COMBINED spend, and the team it lands on wins.
        const crazy = b.mode === "crazy";
        if (b.teamMode) {
          const teamWeights = jackpotTeamWeights(b.players, settled, crazy);
          const teamPcts = jackpotTeamPct(b.players, settled, crazy);
          const participants: JackpotParticipant[] = ([0, 1] as const).map((t) => ({
            key: `t${t}`,
            name: `Team ${TEAM_META[t].name}`,
            color: TEAM_META[t].color,
            img: TEAM_META[t].img,
            tag: "2v2",
            pct: teamPcts[`t${t}` as "t0" | "t1"],
          }));
          setJackpot({ participants, winnerKey: drawJackpotWinner(teamWeights) });
          setPhase("jackpot");
          sfx.caseOpen();
          return;
        }
        const drawnId = drawJackpotWinner(jackpotWeights(b.players, settled, crazy));
        const pctMap = jackpotPct(b.players, settled, crazy);
        const participants: JackpotParticipant[] = b.players.map((p) => ({
          key: p.id,
          name: p.isYou ? "You" : p.name,
          color: playerColor(p),
          tag: p.isYou ? "YOU" : undefined,
          pct: pctMap[p.id] ?? 0,
        }));
        setJackpot({ participants, winnerKey: drawnId });
        setPhase("jackpot");
        sfx.caseOpen();
        return;
      }
      const outcome = computeOutcome(b.players, settled, b.mode, b.teamMode, rule);
      if (outcome.tieIds) {
        // TIE → a decider battle opens above the fight: one square reel of the
        // tied participants (players in their colors, CT/T art in team mode)
        const participants: TieParticipant[] = b.teamMode
          ? ([0, 1] as const).map((t) => ({
              key: `t${t}`,
              name: TEAM_META[t].name,
              color: TEAM_META[t].color,
              img: TEAM_META[t].img,
            }))
          : outcome.tieIds.map((pid) => {
              const p = b.players.find((pl) => pl.id === pid)!;
              return {
                key: pid,
                name: p.isYou ? "You" : p.name,
                color: playerColor(p),
                tag: p.isYou ? "YOU" : undefined,
              };
            });
        const winnerKey = outcome.tieIds[Math.floor(Math.random() * outcome.tieIds.length)];
        setTie({ participants, winnerKey });
        setPhase("tiebreak");
        sfx.caseOpen();
      } else {
        payout(b, settled, outcome.winnerIds, false);
      }
    },
    [payout]
  );

  const onTieDone = useCallback(() => {
    const st = useCaseStore.getState();
    const b = st.battles.find((x) => x.id === battleId);
    if (!b || !tie) return;
    const settled = results;
    const winnerIds =
      tie.winnerKey === "t0" || tie.winnerKey === "t1"
        ? b.players.filter((p) => p.team === (tie.winnerKey === "t0" ? 0 : 1)).map((p) => p.id)
        : [tie.winnerKey];
    setTie(null);
    payout(b, settled, winnerIds, true);
  }, [battleId, payout, results, tie]);

  // USER SPEC (Task 42): the jackpot reel landed — pay the drawn winner (his
  // whole team in 2v2). USER SPEC (Task 43): the 2v2 wheel lands on a TEAM
  // ("t0"/"t1") — that whole team wins. Spectators just watch the reveal.
  const onJackpotDone = useCallback(() => {
    const st = useCaseStore.getState();
    const b = st.battles.find((x) => x.id === battleId);
    setJackpot(null);
    if (!b || !jackpot) return;
    if (spectating) {
      setPhase("done");
      sfx.win(true);
      return;
    }
    let winnerIds: string[];
    if (jackpot.winnerKey === "t0" || jackpot.winnerKey === "t1") {
      winnerIds = b.players
        .filter((p) => p.team === (jackpot.winnerKey === "t0" ? 0 : 1))
        .map((p) => p.id);
    } else {
      const drawnPlayer = b.players.find((p) => p.id === jackpot.winnerKey);
      winnerIds =
        b.teamMode && drawnPlayer
          ? b.players.filter((p) => p.team === drawnPlayer.team).map((p) => p.id)
          : [jackpot.winnerKey];
    }
    setDecidedByJackpot(true);
    payout(b, results, winnerIds, false);
  }, [battleId, jackpot, payout, results, spectating]);

  /* ---------- idempotent reveal bookkeeping (one reel per player per round) ----------
     Declared BEFORE the round-clock below — the Task-140 catch-up marks the
     already-ended rounds revealed the moment a mid-battle viewer lands. */

  const markRevealed = useCallback((playerId: string, throughRound: number) => {
    revealedRef.current = { ...revealedRef.current, [playerId]: Math.max(revealedRef.current[playerId] ?? 0, throughRound) };
    setRevealed((prev) => ({ ...prev, [playerId]: Math.max(prev[playerId] ?? 0, throughRound) }));
  }, []);

  /* ---------- MULTIPLAYER: the server-paced round clock ----------
   * The server rolled every pull the moment the room filled and publishes
   * them gated by the shared-clock schedule. The client only ANIMATES: rounds
   * advance on the server's schedule, each reel lands the moment its gated
   * pull arrives (until then the column shows its "Rolling..." state). */
  const startServerClock = useCallback(
    (b: Battle, opts?: { resync?: boolean }) => {
      // USER SPEC (Task 172): RESYNC mode (tab wake) — rebuild the flip chain
      // against the shared schedule but NEVER wipe the animation state:
      // revealed locks, the round counter and the mounted reels stay; the
      // reels themselves are wall-clock seekable (startAtMs), so the first
      // rAF frame back lands on the exact server-true position. Only a FRESH
      // start (battle flip / mid-battle first join) resets the room.
      const resync = !!opts?.resync;
      if (!resync) {
        setResults([]);
        setWinnerIds([]);
        setShares(null);
        setDecidedByTie(false);
        setDecidedByJackpot(false);
        setJackpot(null);
        setRevealed({});
        revealedRef.current = {};
        setRound(-1);
        setPhase("playing");
        sfx.caseOpen();
      }
      curRoundRef.current = -1;
      // BUGFIX (Task 169): kill any pending timers from a previous pass (the
      // check/backstop chains of a pre-wake clock) and stamp this pass
      clearTimers();
      const runId = ++clockRunRef.current;
      const sched = b.schedule ?? [];
      const startedAt = b.startedAtMs ?? Date.now();
      // BUGFIX (Task 169): a missing/NaN clockOffset would poison EVERY math
      // below (Math.max(0, NaN) = NaN, "endMs <= NaN" = false, timeouts fire
      // at 0ms) — the clock would silently fast-forward the whole fight. Pin
      // a non-finite offset to 0 (skew itself is cancelled by the offset math).
      const rawOffset = b.clockOffset;
      const offset = typeof rawOffset === "number" && Number.isFinite(rawOffset) ? rawOffset : 0;
      const elapsed = () => Math.max(0, Date.now() - offset - startedAt);
      // USER SPEC (Task 140): a viewer who JOINED (or rejoined) mid-battle must
      // NEVER replay from round 0 — the shared clock decides where they land.
      // Every round that already ENDED is history: its pulls are already in the
      // mirror (the server gates them by the same clock), so mark them revealed
      // and let the per-player columns show the missed drops INSTANTLY. The
      // first round still worth playing is the one in flight (its reels mount
      // and land live) — everything after it stays on the shared schedule.
      // BUGFIX (Task 169 — the "READY + drops, no spin" bug): a viewer landing
      // in the LAST beat of the schedule (the friend who LEFT and RE-ENTERED a
      // battle that was about to settle — a 1v1v1 plays only ~16s) computed
      // startIdx = rounds.length, ONE PAST the last round. advance() then set
      // round out of range, roundCase went undefined and the grid froze on the
      // "Get ready" squares with every drop revealed instantly — no reel ever
      // mounted. Clamp to the LAST round: the catch-up now replays the final
      // round's reel once, and the verdict (the room's own poll settles the
      // server within ~a beat) lands right after it locks.
      const lastIdx = Math.max(0, b.rounds.length - 1);
      const now0 = elapsed();
      const endedThrough = sched.reduce((acc, slot, i) => (slot.endMs <= now0 ? i : acc), -1);
      if (endedThrough >= 0) {
        for (const p of b.players) markRevealed(p.id, Math.min(endedThrough + 1, b.rounds.length));
      }
      const startIdx = Math.min(Math.max(0, endedThrough + 1), lastIdx);
      const advance = (idx: number) => {
        if (runId !== clockRunRef.current) return; // superseded by a newer clock pass
        const clamped = Math.min(idx, lastIdx); // BUGFIX (Task 169): never past the last round
        if (clamped <= curRoundRef.current) return; // this pass already owns a later beat
        curRoundRef.current = clamped;
        setRound(clamped);
        if (idx + 1 < b.rounds.length) {
          const nextStart = sched[idx + 1]?.startMs ?? (idx + 1) * 6000;
          const wait = Math.max(600, nextStart - elapsed());
          // USER SPEC (Task 66, "the server must WAIT for every participant"):
          // the shared clock sets the EARLIEST flip — but the round NEVER
          // flips while any seat's reel is still spinning. A reel mounts only
          // when its pull reaches this viewer (the publish heartbeat + fetch
          // delay that), so a bare timer cut late mounts mid-air ("players 3
          // and 4 almost land and the round continues"). Hold the flip until
          // EVERY seat's pull has ARRIVED and LOCKED; the backstop only fires
          // if a pull never arrives (the room must never freeze).
          let gone = false;
          const go = () => {
            if (gone) return;
            gone = true;
            // USER SPEC (R40): FAST MODE is DELETED — the round hands over to
            // the next reel exactly like the normal pacing always did.
            advance(idx + 1);
          };
          const need = idx + 1;
          const check = () => {
            if (gone) return;
            if (b.players.every((p) => (revealedRef.current[p.id] ?? 0) >= need)) go();
            else later(check, 120);
          };
          later(check, wait);
          later(go, wait + REVEAL_BACKSTOP_MS);
        }
        // the last round hands over to the server-settle effect below — it
        // waits for every reel to lock AND for the server to publish the
        // outcome, then plays the exact original verdict (decider/jackpot).
      };
      // fresh start: wait for round 0; a mid-battle join: the in-flight round
      // (or the beat gap after it) starts immediately. RESYNC: the chain
      // rebuilds instantly — the in-flight round's reels are already mounted
      // (wall-clock seek keeps them server-true), only the NEXT flip needs
      // scheduling, and if the tab slept past whole rounds the catch-up above
      // jumps the counter forward and their drops show instantly.
      const firstIn = Math.max(resync ? 0 : 500, (sched[startIdx]?.startMs ?? sched[0]?.startMs ?? 0) - elapsed());
      later(() => advance(startIdx), firstIn);
    },
    [later, markRevealed, clearTimers]
  );

  /* ---------- start the battle (all seats full) ---------- */

  const beginBattle = useCallback(() => {
    const st = useCaseStore.getState();
    const b = useCaseStore.getState().battles.find((x) => x.id === battleId);
    if (!b) return;
    // USER SPEC: the entry was already taken from the balance the moment the
    // battle was opened/joined — nothing is charged here at start time.
    // XP grant only — no reward, no level-up toast (level is DB state).
    st.grantXp(b.rounds.reduce((s, cid) => {
      const cs = caseById(cid);
      return s + (cs ? xpForCase(cs.price) : 0);
    }, 0));

    // MULTIPLAYER: nothing is drawn here — the server rolled and holds every
    // pull; the client only animates them on the shared clock.
    if (b.global) {
      startServerClock(b);
      return;
    }

    // pre-draw every round: your rolls are provably fair, the rest use house RNG
    const bCases = battleCases(b, extraCases);
    const drawnMap: BattleResult[] = b.players.map((p) => {
      const pulls = b.rounds.map((cid, ri) => {
        const cs = bCases[ri % bCases.length];
        const skin = p.isYou ? st.drawCase(cs).skin : rollCase(cs);
        return { round: ri, skinId: skin.id, wear: wearIdFromLabel(skin.wear), value: skin.value };
      });
      return { playerId: p.id, total: pulls.reduce((s, x) => s + x.value, 0), pulls };
    });
    const drawnById = new Map(drawnMap.map((d) => [d.playerId, d]));
    setDrawn(drawnById);

    // USER SPEC (fix): a ROLLDROP hit REPLACES that round's skin — the pull
    // becomes a rare-pool draw flagged `rd` (the reel stops ON the raredrop
    // art, waits a second, then the rare round opens on the SAME reel). The
    // original skin is discarded — the round is worth ONLY its rare draw.
    const durOf = (pi: number) => seatReelMs(b.players[pi].isYou, pi);
    const rdRoundExtra = new Map<number, number>();
    for (const d of drawnMap) {
      const pi = b.players.findIndex((pl) => pl.id === d.playerId);
      const p = b.players[pi];
      for (let ri = b.rounds.length - 1; ri >= 0; ri--) {
        if (!maybeRollDrop(rolldropChanceOf(bCases[ri % bCases.length]))) continue;
        const rare = rareCaseOf(bCases[ri % bCases.length]);
        const skin = p.isYou ? st.drawCase(rare).skin : rollCase(rare);
        const idx = d.pulls.findIndex((x) => x.round === ri);
        const old = d.pulls[idx];
        d.pulls[idx] = { round: ri, skinId: skin.id, wear: wearIdFromLabel(skin.wear), value: skin.value, rd: true };
        d.total += skin.value - old.value;
        // the sequence holds the whole room: reel stops on the raredrop →
        // marker beat (Task 149: the cutscene video is GONE — RD_BEAT_MS on
        // the frameless image) → the rare reel opens (spin + 1s)
        rdRoundExtra.set(ri, Math.max(rdRoundExtra.get(ri) ?? 0, 2 * durOf(pi) + 2230));
      }
    }

    st.markBattlePlaying(b.id);
    setResults([]);
    setWinnerIds([]);
    setShares(null);
    setDecidedByTie(false);
    setDecidedByJackpot(false);
    setJackpot(null);
    setRevealed({});
    setRound(-1);
    setPhase("playing");
    sfx.caseOpen();

    const maxDur = roomMaxReelMs(b.players.length);

    const nextRound = (idx: number) => {
      setRound(idx);
      // USER SPEC (Task 45): a round with a ROLLDROP runs LONGER — the hitting
      // player's reel stops, goes white, then the extra rare reel spins
      const need = Math.max(maxDur, rdRoundExtra.get(idx) ?? 0) + 250;
      later(() => {
        if (idx + 1 < b.rounds.length) {
          later(() => nextRound(idx + 1), ROUND_GAP_MS);
        } else {
          later(() => settle(b.id, drawnMap), 700);
        }
      }, need);
    };
    nextRound(0);
  }, [battleId, later, settle, toast, startServerClock]);

  /* ---------- WATCH: replay a bot-only battle live for a spectator ----------
   * The moment a spectator opens a full bot battle it is resolved into the
   * store once (one source of truth for the history record), then the room
   * animates those exact results round by round — same reels, same pacing. */

  const startSpectate = useCallback(
    (rec: Battle) => {
      // no guard here — the spectate effect owns the once-per-mount ref
      const drawnMap = rec.results ?? [];
      const drawnById = new Map(drawnMap.map((d) => [d.playerId, d]));
      setDrawn(drawnById);
      setRevealed({});
      setRound(-1);
      setPhase("playing");
      sfx.caseOpen();
      const maxDur = roomMaxReelMs(rec.players.length);
      const nextRound = (idx: number) => {
        setRound(idx);
        later(() => {
          if (idx + 1 < rec.rounds.length) {
            later(() => nextRound(idx + 1), ROUND_GAP_MS);
          } else {
            later(() => {
              setResults(drawnMap);
              setWinnerIds(rec.winnerIds ?? []);
              setDecidedByTie(false);
              // USER SPEC (Task 42): spectators see the JACKPOT draw too —
              // the same weighted reel, landing on the stored winner.
              // Task 43: in 2v2 the reel spins per TEAM — convert the stored
              // winning player id to his team key.
              if (potRuleOf(rec) === "jackpot" && (rec.winnerIds?.length ?? 0) > 0 && drawnMap.length > 0) {
                const crazy = rec.mode === "crazy";
                if (rec.teamMode) {
                  const teamPcts = jackpotTeamPct(rec.players, drawnMap, crazy);
                  const participants: JackpotParticipant[] = ([0, 1] as const).map((t) => ({
                    key: `t${t}`,
                    name: `Team ${TEAM_META[t].name}`,
                    color: TEAM_META[t].color,
                    img: TEAM_META[t].img,
                    tag: "2v2",
                    pct: teamPcts[`t${t}` as "t0" | "t1"],
                  }));
                  const winTeam = rec.players.find((p) => p.id === rec.winnerIds![0])?.team ?? 0;
                  setJackpot({ participants, winnerKey: `t${winTeam}` });
                } else {
                  const pctMap = jackpotPct(rec.players, drawnMap, crazy);
                  const participants: JackpotParticipant[] = rec.players.map((p) => ({
                    key: p.id,
                    name: p.isYou ? "You" : p.name,
                    color: playerColor(p),
                    tag: p.isYou ? "YOU" : undefined,
                    pct: pctMap[p.id] ?? 0,
                  }));
                  setJackpot({ participants, winnerKey: rec.winnerIds![0] });
                }
                setPhase("jackpot");
                sfx.caseOpen();
              } else {
                setPhase("done");
                sfx.win(true);
              }
            }, 700);
          }
        }, maxDur + 250);
      };
      later(() => nextRound(0), 900);
    },
    [later]
  );

  useEffect(() => {
    if (spectateStartedRef.current) return;
    // MULTIPLAYER spectate: the server is the single source of truth — a
    // waiting room just waits (the poll brings players/bots); a playing room
    // joins the shared clock live; a finished one replays the published pulls.
    if (spectateBattle?.global) {
      if (spectateBattle.status === "playing") {
        spectateStartedRef.current = true;
        startServerClock(spectateBattle);
      } else if (spectateBattle.status === "finished") {
        spectateStartedRef.current = true;
        window.setTimeout(() => startSpectate(spectateBattle), 0);
      }
      return;
    }
    // a full bot-only battle is resolved NOW and then replayed live
    if (spectateBattle && spectateBattle.status === "waiting" && emptySeats(spectateBattle) === 0) {
      const done = useCaseStore.getState().resolveBattleHeadless(spectateBattle.id);
      if (done) {
        spectateStartedRef.current = true;
        // no cleanup on purpose: the resolve flips the deps (battle → history)
        // which would cancel a pending timeout before it ever fires
        window.setTimeout(() => startSpectate(done), 0);
      }
      return;
    }
    // already finished (traffic tick resolved it, or an old link) → replay it
    if (spectateHistory && spectateHistory.status === "finished") {
      spectateStartedRef.current = true;
      window.setTimeout(() => startSpectate(spectateHistory), 0);
    }
  }, [spectateBattle, spectateHistory, startSpectate, startServerClock]);

  /* ---------- MULTIPLAYER: merge the server's gated pulls into the animation
   * state as they unlock. Rounds are only ever ADDED — a reel that already
   * spun keeps its target, one waiting for its gate shows "Rolling..." until
   * the next poll delivers the pull. ---------- */
  useEffect(() => {
    if (!battle?.global || !battle.results) return;
    setDrawn((prev) => {
      let changed = false;
      const next = new Map(prev);
      for (const res of battle.results!) {
        const existing = next.get(res.playerId);
        const mergedPulls = existing ? [...existing.pulls] : [];
        for (const pull of res.pulls) {
          if (!mergedPulls.some((x) => x.round === pull.round)) mergedPulls.push(pull);
        }
        mergedPulls.sort((a, b) => a.round - b.round);
        if (!existing || existing.pulls.length !== mergedPulls.length) {
          changed = true;
          next.set(res.playerId, {
            playerId: res.playerId,
            total: mergedPulls.reduce((s, x) => s + x.value, 0),
            pulls: mergedPulls,
          });
        }
      }
      return changed ? next : prev;
    });
  }, [battle]);

  /* ---------- MULTIPLAYER: the server settles the fight (credits the DB
   * balances and publishes winners/takes) — the client replays the ORIGINAL
   * verdict: decider/jackpot reels land on the server's winner, then the
   * VICTORY banner + final columns carry the server's exact takes. ---------- */
  useEffect(() => {
    const gb = battle;
    if (!gb?.global || phase !== "playing") return;
    const allLocked = gb.players.every((p) => (revealed[p.id] ?? 0) >= gb.rounds.length);
    if (!allLocked) return;
    if (gb.status !== "finished" || !gb.winnerIds || gb.winnerIds.length === 0) return;
    const settled = (gb.results ?? []).map((r) => ({
      playerId: r.playerId,
      total: r.pulls.reduce((s, x) => s + x.value, 0),
      pulls: r.pulls,
    }));
    setResults(settled);
    setWinnerIds(gb.winnerIds);
    const rule = potRuleOf(gb);
    if (rule === "jackpot" && settled.length > 0) {
      const crazy = gb.mode === "crazy";
      if (gb.teamMode) {
        const teamPcts = jackpotTeamPct(gb.players, settled, crazy);
        const participants: JackpotParticipant[] = ([0, 1] as const).map((t) => ({
          key: `t${t}`,
          name: `Team ${TEAM_META[t].name}`,
          color: TEAM_META[t].color,
          img: TEAM_META[t].img,
          tag: "2v2",
          pct: teamPcts[`t${t}` as "t0" | "t1"],
        }));
        const winTeam = gb.players.find((p) => p.id === gb.winnerIds![0])?.team ?? 0;
        setJackpot({ participants, winnerKey: `t${winTeam}` });
      } else {
        const pctMap = jackpotPct(gb.players, settled, crazy);
        const participants: JackpotParticipant[] = gb.players.map((p) => ({
          key: p.id,
          name: p.isYou ? "You" : p.name,
          color: playerColor(p),
          tag: p.isYou ? "YOU" : undefined,
          pct: pctMap[p.id] ?? 0,
        }));
        setJackpot({ participants, winnerKey: gb.winnerIds![0] });
      }
      setPhase("jackpot");
      sfx.caseOpen();
      return;
    }
    if (rule === "winner" && (gb.tieIds?.length ?? 0) > 1) {
      // tie → the decider reel opens at the TOP of the room, landing on the
      // winner the server already picked among the tied players
      const participants: TieParticipant[] = gb.teamMode
        ? ([0, 1] as const).map((t) => ({
            key: `t${t}`,
            name: TEAM_META[t].name,
            color: TEAM_META[t].color,
            img: TEAM_META[t].img,
          }))
        : gb.tieIds!.map((pid) => {
            const p = gb.players.find((pl) => pl.id === pid)!;
            return {
              key: pid,
              name: p.isYou ? "You" : p.name,
              color: playerColor(p),
              tag: p.isYou ? "YOU" : undefined,
            };
          });
      const winnerKey = gb.teamMode
        ? `t${gb.players.find((p) => p.id === gb.winnerIds![0])?.team ?? 0}`
        : gb.winnerIds![0];
      setTie({ participants, winnerKey });
      setPhase("tiebreak");
      sfx.caseOpen();
      return;
    }
    // plain win / shared split — straight to the original verdict
    setDecidedByTie(false);
    const dropsTotal = settled.reduce((s, r) => s + r.total, 0);
    setShares(
      gb.take ??
        (rule === "shared"
          ? sharedSplit(dropsTotal, gb.players)
          : gb.teamMode
            ? splitTeamPot(dropsTotal, gb.players, gb.players.filter((p) => gb.winnerIds!.includes(p.id)), settled)
            : { [gb.winnerIds[0]]: dropsTotal })
    );
    setPhase("done");
    const you = gb.players.find((p) => p.isYou);
    const myTake = you ? gb.take?.[you.id] ?? 0 : 0;
    if (!you || myTake > 0) sfx.win(true);
    else sfx.error();
  }, [battle, phase, revealed]);

  /* ---------- MULTIPLAYER: opened (or reloaded) straight into a live server
   * battle — join the shared clock mid-flight; earlier rounds are already
   * revealed through the poll's gated pulls. ---------- */
  useEffect(() => {
    if (!battle?.global || phase !== "waiting" || startedRef.current) return;
    if (battle.status !== "playing") return;
    startedRef.current = true;
    startServerClock(battle);
  }, [battle, phase, startServerClock]);

  /* ---------- UPGRADED (Task 172): TAB-WAKE RESYNC — a backgrounded tab
   * (ALT-TAB, phone screen off, switched app) gets its timers throttled and
   * its rAF frozen. The OLD handler re-ran the full clock which WIPED the
   * reveal state and remounted the in-flight reel from zero — the visible
   * "the reel reset itself" the user reported. Now the wake runs the RESYNC
   * pass: no state wipe, only the flip chain re-derives from the schedule;
   * the reels are wall-clock seekable (startAtMs), so they land on the exact
   * server-true frame the moment rAF resumes — mid-spin keeps spinning from
   * that frame, elapsed spins lock instantly, missed rounds show their drops.
   * Stale advance() timers are filtered by runId so nothing drags the round
   * backward. ---------- */
  useEffect(() => {
    const onWake = () => {
      if (document.visibilityState !== "visible") return;
      if (phaseRef.current !== "playing") return;
      const gb = useCaseStore.getState().battles.find((b) => b.id === battleId);
      if (!gb?.global) return;
      if (gb.status !== "playing" && gb.status !== "finished") return;
      startServerClock(gb, { resync: true });
    };
    document.addEventListener("visibilitychange", onWake);
    return () => document.removeEventListener("visibilitychange", onWake);
  }, [battleId, startServerClock]);

  /* ---------- auto-start countdown when the room fills ---------- */

  const battleFull =
    !!battle &&
    battle.status === "waiting" &&
    emptySeats(battle) === 0 &&
    battle.players.some((p) => p.isYou);

  useEffect(() => {
    // keyed on fullness only — a phase flip must never cancel the countdown timers
    if (!battleFull || startedRef.current) return;
    startedRef.current = true;
    // state flips happen inside the timer callbacks (never synchronously in the effect body)
    const t0 = window.setTimeout(() => {
      setPhase("countdown");
      setCountdown(3);
    }, 0);
    const t1 = window.setTimeout(() => setCountdown(2), 800);
    const t2 = window.setTimeout(() => setCountdown(1), 1600);
    const t3 = window.setTimeout(() => {
      beginBattle();
    }, 2400);
    return () => {
      window.clearTimeout(t0);
      window.clearTimeout(t1);
      window.clearTimeout(t2);
      window.clearTimeout(t3);
    };
  }, [battleFull, beginBattle]);

  // reopening a finished battle straight from history (fresh visit / reload):
  // hydrate the final result card from the stored record — TAKE column included.
  // Spectator battles are skipped here — the WATCH effect replays them live.
  const hydratedRef = useRef(false);
  useEffect(() => {
    if (battle || hydratedRef.current) return;
    const h = historyBattle;
    if (!h || h.status !== "finished") return;
    if (!h.players.some((p) => p.isYou)) return; // spectator → live replay instead
    hydratedRef.current = true;
    // state flips happen inside a timer callback (never synchronously in the effect body)
    const t = window.setTimeout(() => {
      setResults(h.results ?? []);
      setWinnerIds(h.winnerIds ?? []);
      setPhase("done");
    }, 0);
    return () => window.clearTimeout(t);
  }, [battle, historyBattle]);

  // MULTIPLAYER: reopening a finished SERVER battle (fresh visit / reload) —
  // the verdict + exact takes come from the server; your own battles hydrate
  // straight to the final columns, spectators replay via the WATCH effect.
  // FIX (Task 63): hydrate ONLY a fresh visit — phase still "waiting". A
  // live-watched fight ends through the verdict effect above; jumping to
  // "done" here the moment the server published the finish used to SKIP the
  // JACKPOT draw (and the decider reel) entirely.
  useEffect(() => {
    if (hydratedRef.current) return;
    if (phase !== "waiting") return;
    const gb = battle;
    if (!gb?.global || gb.status !== "finished") return;
    if (!gb.players.some((p) => p.isYou)) return; // spectator → live replay instead
    hydratedRef.current = true;
    const t = window.setTimeout(() => {
      setResults(gb.results ?? []);
      setWinnerIds(gb.winnerIds ?? []);
      setShares(gb.take ?? null);
      setPhase("done");
    }, 0);
    return () => window.clearTimeout(t);
  }, [battle, phase]);

  /* ---------- leave / actions ---------- */

  const leave = () => {
    clearTimers();
    sfx.click();
    // MULTIPLAYER: the server refunds the entry (or nothing, for spectators)
    if (battle?.global) {
      serverActions?.leave();
      return;
    }
    // spectators just walk out — nothing to leave, nothing to refund
    if (spectating) {
      router.push("/battles");
      return;
    }
    const st = useCaseStore.getState();
    const b = st.battles.find((x) => x.id === battleId);
    // USER SPEC: leaving a battle that has not started refunds the entry
    if (b && b.status === "waiting" && b.players.some((p) => p.isYou)) {
      toast({
        title: (
          <>
            Left the battle — <Coin /> {formatCoins(battleEntry(b))} refunded
          </>
        ),
      });
    }
    st.leaveBattle(battleId);
    router.push("/battles");
  };

  // join straight from the WATCH view while the battle still has open seats
  const joinFromWatch = () => {
    // MULTIPLAYER: the server charges the DB entry, then the poll seats you
    if (view?.global) {
      serverActions?.join();
      return;
    }
    const ok = useCaseStore.getState().joinBattle(battleId);
    if (ok) {
      sfx.click();
      toast({ title: "You joined the battle — good luck!" });
    } else {
      sfx.error();
      toast({ title: "Could not join — the room just filled up", variant: "destructive" });
    }
  };

  const callBots = () => {
    // MULTIPLAYER: one POST — the server fills the seats and rolls the fight
    if (view?.global) {
      serverActions?.callBots();
      return;
    }
    const outcome = useCaseStore.getState().callBots(view.id);
    if (outcome === "filled") {
      sfx.click();
      toast({ title: "Bots joined — battle starting" });
    } else if (outcome === "called") {
      sfx.click();
      toast({
        title: "PLAY WITH BOTS",
        description: "Every player must press Call Bots before the empty seats fill.",
      });
    } else if (outcome === "full") {
      toast({ title: "The room is already full" });
    }
  };

  // USER SPEC (2v2): pick your exact seat while the battle waits — the team
  // AND the LEFT/RIGHT slot inside it (one player per seat)
  const handlePickSeat = (team: 0 | 1, side: 0 | 1) => {
    const ok = useCaseStore.getState().pickSeat(battleId, team, side);
    if (ok) {
      sfx.click();
      toast({
        title: `Team ${TEAM_META[team].name} — ${side === 0 ? "left" : "right"} seat`,
        description: "You picked your seat — the battle starts when the room is full.",
      });
    } else {
      sfx.error();
    }
  };

  // USER SPEC (Task 177): pickBot (CHOOSE BOT) is DELETED — bots join only
  // through the shared "Call Bots" vote.

  // USER SPEC (Task 43): KICK a bot out of the room before the battle starts —
  // the seat opens again. The room stops being full, so any pending auto-start
  // countdown must be torn down (the effect cleanup clears its timers when
  // battleFull flips false; startedRef resets so it can fire again later).
  const kickBot = (playerId: string) => {
    const ok = useCaseStore.getState().kickBot(battleId, playerId);
    if (ok) {
      sfx.click();
      startedRef.current = false;
      setPhase((ph) => (ph === "countdown" || ph === "waiting" ? "waiting" : ph));
      toast({ title: "Bot kicked — the seat is open again" });
    } else {
      sfx.error();
    }
  };

  const runItBack = () => {
    // MULTIPLAYER: recreate the same fight on the server (same config)
    if (view?.global) {
      serverActions?.runItBack();
      return;
    }
    const st = useCaseStore.getState();
    const b = historyBattle ?? battle;
    if (!b) return;
    if (st.balance < battleEntry(b)) {
      sfx.error();
      toast({
        title: "Not enough funds",
        description: (
          <>
            Recreating the battle costs <Coin /> {formatCoins(battleEntry(b))}.
          </>
        ),
        variant: "destructive",
      });
      return;
    }
    const id = st.createBattle(b.type, b.rounds, b.mode, potRuleOf(b));
    sfx.click();
    router.push(`/battles/${id}`);
  };

  /* ---------- not found ---------- */
  if (!battle && !historyBattle) {
    return (
      <SiteShell>
        <main className="relative grid min-h-[calc(100vh-4rem)] place-items-center px-4 pb-20 pt-10">
          <div className="text-center">
            <Swords className="mx-auto h-10 w-10 text-white/20" />
            <h1 className="font-display mt-4 text-2xl font-black text-white/70">This battle has ended</h1>
            <p className="mt-2 text-sm font-semibold text-white/40">
              The room was closed or never existed — the lobby always has new ones.
            </p>
            <button
              onClick={() => router.push("/battles")}
              className="neon-btn mx-auto mt-6 flex items-center gap-2 rounded-xl px-7 py-3 text-sm font-black text-white"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to battles
            </button>
          </div>
        </main>
      </SiteShell>
    );
  }

  // live battle data falls back to the stored history copy after it finishes
  const view = battle ?? historyBattle!;
  const viewSpec = BATTLE_TYPES[view.type];
  const cases = battleCases(view, extraCases);
  const entry = battleEntry(view);
  const crazy = view.mode === "crazy";

  // settled DONE-phase values — the header verdict (the big VICTORY at the far
  // right of the battle details) and the Task-141 victory overlays on the
  // battle grid read the same source.
  const rule = potRuleOf(view);
  const isShared = rule === "shared";
  const youId = view.players.find((p) => p.isYou)?.id ?? "";
  const youWon = view.players.some((p) => p.isYou && winnerIds.includes(p.id));
  const drops = dropTotal(results);
  const takeMap: Record<string, number> = shares ?? takePerPlayer(view, results, winnerIds);

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-28 pt-8" aria-label="Battle room">
        {/* Task 149: the impact clip preloader is GONE with the cutscene itself */}
        <div className="relative mx-auto max-w-6xl px-4">
          {/* header */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                onClick={leave}
                className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
                aria-label="Leave the battle"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
              <div>
                <h1 className="font-display flex flex-wrap items-center gap-2 text-xl font-black tracking-wide text-white sm:text-2xl">
                  {viewSpec.label}
                  {/* USER SPEC (Task 67): the PRIVATE badge + the invite code —
                      the code is how friends reach an invisible room */}
                  {view.isPrivate && (
                    <span
                      className="flex items-center gap-1 rounded-lg bg-gradient-to-r from-amber-500 to-amber-300 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-black"
                      title="PRIVATE — hidden from the lobby; only players with this code/link can join or watch"
                    >
                      <Lock className="h-3 w-3" />
                      Private
                    </span>
                  )}
                  {view.isPrivate && (
                    <button
                      type="button"
                      onClick={() => {
                        if (!view.code) return;
                        navigator.clipboard?.writeText(view.code).catch(() => null);
                        sfx.click();
                        toast({ title: `Room code ${view.code} copied — send it to your friends` });
                      }}
                      className="rounded-lg border border-amber-400/40 bg-amber-400/10 px-2 py-0.5 font-mono text-[11px] font-black tracking-widest text-amber-300 transition-colors hover:bg-amber-400/20"
                      title="Copy the room code"
                    >
                      {view.code}
                    </button>
                  )}
                  {crazy && (
                    <span className="flex items-center gap-1 rounded-lg bg-gradient-to-r from-rose-500 to-orange-500 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-white">
                      <Flame className="h-3 w-3" />
                      Crazy — lowest wins
                    </span>
                  )}
                  {/* USER SPEC (Task 42): the new pot-rule badges */}
                  {rule === "jackpot" && (
                    <span className="rounded-lg bg-gradient-to-r from-violet-500 to-fuchsia-500 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-white">
                      Jackpot
                    </span>
                  )}
                  {rule === "shared" && (
                    <span className="rounded-lg bg-gradient-to-r from-teal-500 to-emerald-500 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-white">
                      Shared — equal split
                    </span>
                  )}
                  {spectating && (
                    <span className="flex items-center gap-1 rounded-lg border border-sky-400/50 bg-sky-500/15 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-sky-300">
                      <Eye className="h-3 w-3" />
                      Watching
                    </span>
                  )}
                  {/* USER SPEC: live viewer count in every battle — players only */}
                  <span
                    className="flex items-center gap-1 rounded-lg border border-sky-400/40 bg-sky-500/10 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-sky-300"
                    title="Players watching this battle right now — never bots"
                  >
                    <Eye className="h-3 w-3" />
                    {viewersFor(view.id)} watching
                  </span>
                </h1>
                <p className="text-sm font-semibold text-white/45">
                  {view.rounds.length} round{view.rounds.length > 1 ? "s" : ""} • entry <Coin />{formatCoins(entry)} •{" "}
                  {isShared ? (
                    <span className="font-black text-teal-300">the pot splits equally</span>
                  ) : rule === "jackpot" ? (
                    <span className="font-black text-violet-300">the wheel draws the winner</span>
                  ) : (
                    <>
                      winner takes <span className="font-black text-amber-300">every drop</span>
                    </>
                  )}
                  {(phase === "playing" || phase === "tiebreak" || phase === "jackpot") && (
                    <>
                      {" "}• dropped so far{" "}
                      <span className="font-display font-black text-amber-300">
                        <Coin /> {formatCoins(liveDrops)}
                      </span>
                    </>
                  )}
                </p>
              </div>
            </div>

            {/* USER SPEC: the big verdict lives at the FAR RIGHT of the battle
                details row — right of the viewers count — and the old big
                win/loss banner at the bottom of the screen is GONE.
                RECREATE BATTLE + BACK TO LOBBY sit right under the verdict.
                Task 141: the battle grid itself NEVER swaps away — the VICTORY
                overlays sit right ON the winning player / winning team. */}
            {phase === "done" && results.length > 0 && (
              <div className="ms-auto flex flex-col items-end gap-2.5">
                <div className="text-right">
                  <p
                    className={cn(
                      "font-display flex flex-wrap items-center justify-end gap-x-2.5 text-3xl font-black tracking-wide md:text-4xl",
                      youWon || spectating
                        ? "text-amber-300 drop-shadow-[0_0_26px_rgba(240,185,11,0.45)]"
                        : "text-red-400 drop-shadow-[0_0_26px_rgba(239,68,68,0.35)]"
                    )}
                  >
                    {youWon || spectating ? (
                      <Trophy className="h-7 w-7 md:h-9 md:w-9" />
                    ) : (
                      <Swords className="h-7 w-7 md:h-9 md:w-9" />
                    )}
                    {youWon || spectating ? (isShared && !spectating ? "POT SPLIT!" : "VICTORY!") : "BATTLE LOST!"}
                    {(youWon || spectating) && (
                      <span
                        className="text-xl text-white/85 md:text-2xl"
                        title={isShared && !spectating ? "Your equal share of every skin that dropped" : "The total value of every skin that dropped"}
                      >
                        <Coin /> {formatCoins(isShared && !spectating ? takeMap[youId] ?? 0 : drops)}
                      </span>
                    )}
                  </p>
                  {decidedByTie && (
                    <p className="font-display mt-1.5 inline-flex items-center gap-1 rounded-lg bg-amber-400/15 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-amber-300">
                      ⚡ Decided by the decider battle
                    </p>
                  )}
                  {decidedByJackpot && (
                    <p className="font-display mt-1.5 inline-flex items-center gap-1 rounded-lg bg-violet-400/15 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-violet-300">
                      ⚡ Decided by the jackpot draw
                    </p>
                  )}
                </div>
                <div className="flex flex-wrap items-center justify-end gap-2">
                  <button
                    onClick={runItBack}
                    className="neon-btn flex items-center gap-1.5 rounded-xl px-5 py-2.5 text-sm font-black text-white"
                  >
                    <RotateCcw className="h-4 w-4" />
                    Recreate battle • <Coin /> {formatCoins(entry)}
                  </button>
                  <button
                    onClick={() => {
                      sfx.click();
                      router.push("/battles");
                    }}
                    className="rounded-xl border border-white/20 bg-white/5 px-5 py-2.5 text-sm font-bold text-white/80 transition-colors hover:bg-white/10 hover:text-white"
                  >
                    Back to lobby
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* USER SPEC: the case strip lives ABOVE the battle details itself and
              runs the full width of the screen (left → right) — bigger tiles,
              and every box carries its NAME right under it. With many rounds the
              strip stays bounded (clipped + scrollable, no page bleed) and the
              auto-scroll effect keeps the round in play centered. */}
          <div dir="ltr" className="relative mt-4">
            <div
              ref={stripRef}
              className="relative flex items-start gap-2 overflow-x-auto rounded-xl border border-white/10 bg-black/30 px-3 py-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
            >
              {view.rounds.map((cid, i) => {
                const cs = caseById(cid);
                if (!cs) return null;
                // R38 (USER SPEC): the ROUND NUMBER stands above every box —
                // the strip now tells WHICH round is opening (the amber chip
                // reads "Round X/Y") and how many boxes are still ahead.
                const isActive = phase === "playing" && i === round;
                const isPast = phase === "playing" && i < round;
                return (
                  <span
                    key={`${cid}-${i}`}
                    data-round={i}
                    className={cn(
                      "flex w-[112px] shrink-0 flex-col items-center gap-1 rounded-lg p-1.5",
                      isActive && "bg-amber-300/10 ring-2 ring-amber-300/70",
                      isPast && "opacity-40"
                    )}
                  >
                    <span
                      data-roundchip={i + 1}
                      data-roundchip-active={isActive ? "1" : "0"}
                      className={cn(
                        "font-display flex h-5 w-full items-center justify-center rounded-md text-[9px] font-black uppercase tracking-[0.14em] tabular-nums",
                        isActive
                          ? "bg-amber-300 text-black shadow-[0_0_14px_rgba(240,185,11,0.55)]"
                          : "bg-white/[0.07] text-white/55",
                        isPast && !isActive && "text-white/30",
                      )}
                    >
                      {isActive ? `Round ${i + 1}/${view.rounds.length}` : i + 1}
                    </span>
                    {/* USER SPEC (Task 80): the case art itself opens the drops.
                        USER SPEC (Task 82): the "VIEW DROPS" text button is GONE —
                        a bare click on the crate opens its skin pool */}
                    <button
                      type="button"
                      onClick={() => {
                        sfx.click();
                        setDropsCase(cs);
                      }}
                      className="block w-full cursor-pointer transition-transform hover:scale-105"
                      aria-label={`View the drops of ${cs.name}`}
                      title={`View the skins inside ${cs.name}`}
                    >
                      <CaseImage caseId={cs.id} alt={cs.name} color={cs.tierColor} color2={cs.tierColor2} communityDesign={cs.communityDesign} sizes="104px" />
                    </button>
                    <span
                      className="w-full truncate text-center text-[10px] font-bold leading-tight text-white/70"
                      title={cs.name}
                    >
                      {cs.name}
                    </span>
                    {/* USER SPEC (Task 80): the case's price — live on its tile */}
                    <span
                      className="font-display flex items-center gap-1 text-[11px] font-black leading-none text-amber-300"
                      title={`${cs.name} costs $${formatCoins(cs.price)} per opening`}
                    >
                      <Coin className="h-3 w-3" /> {formatCoins(cs.price)}
                    </span>
                  </span>
                );
              })}
            </div>
            <span className="pointer-events-none absolute inset-y-0 left-0 w-8 rounded-l-xl bg-gradient-to-r from-[#0b0714] to-transparent" aria-hidden="true" />
            <span className="pointer-events-none absolute inset-y-0 right-0 w-8 rounded-r-xl bg-gradient-to-l from-[#0b0714] to-transparent" aria-hidden="true" />
          </div>

          {/* USER SPEC (Task 80): the battle's own VIEW DROPS dialog — every case
              tile above opens its full skin pool (values + exact odds) in-room */}
          <CaseDropsDialog
            caseDef={dropsCase}
            open={!!dropsCase}
            onOpenChange={(v) => {
              if (!v) setDropsCase(null);
            }}
          />

          {/* USER SPEC: the DECIDER BATTLE lives at the TOP of the room — right
              below the case strip — so the original battle drops lower while
              the tiebreaker reel plays above it. */}
          {phase === "tiebreak" && tie && (
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              className="mx-auto mt-6 max-w-3xl"
              role="status"
            >
              <div className="mb-3 text-center">
                <p className="font-display flex items-center justify-center gap-2 text-sm font-black uppercase tracking-[0.3em] text-amber-300">
                  <Zap className="h-4 w-4 animate-pulse" fill="currentColor" />
                  It&apos;s a tie — decider battle
                </p>
                <p className="mt-1 text-xs font-semibold text-white/50">
                  {view.teamMode
                    ? "CT vs T — one spin decides who takes all the drops."
                    : "One spin — whoever the marker lands on takes all the drops."}
                </p>
              </div>
              <TieBreakerReel
                key={`tie-${view.id}`}
                participants={tie.participants}
                winnerKey={tie.winnerKey}
                duration={4200}
                onDone={onTieDone}
                /* Task 31: shared seed — every viewer watches the same decider strip */
                seed={hashSeed(
                  `${view.id}|tie|${tie.winnerKey}|${tie.participants.map((x) => x.key).join(",")}`
                )}
              />
            </motion.div>
          )}

          {/* USER SPEC (Task 42): the JACKPOT draw — like the decider, it opens
              at the TOP of the room right below the case strip: every player
              rides with his picture + win range, the wheel lands on the winner */}
          {phase === "jackpot" && jackpot && (
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              className="mx-auto mt-6 max-w-3xl"
              role="status"
            >
              <div className="mb-3 text-center">
                <p className="font-display flex items-center justify-center gap-2 text-sm font-black uppercase tracking-[0.3em] text-violet-300">
                  <Zap className="h-4 w-4 animate-pulse" fill="currentColor" />
                  Jackpot draw
                </p>
                <p className="mt-1 text-xs font-semibold text-white/50">
                  {view.teamMode
                    ? crazy
                      ? "Crazy odds per team — the team with the lowest combined haul draws with the best chance."
                      : "Odds by each team's COMBINED haul — the richer team holds a bigger slice of the wheel."
                    : crazy
                      ? "Crazy odds — the lowest haul draws with the best chance."
                      : "Odds by unboxed value — the bigger your haul, the bigger your slice of the wheel."}{" "}
                  {view.teamMode ? "The team the wheel hits takes all the drops." : "One draw takes all the drops."}
                </p>
              </div>
              <JackpotReel
                key={`jp-${view.id}`}
                participants={jackpot.participants}
                winnerKey={jackpot.winnerKey}
                duration={4200}
                onDone={onJackpotDone}
              />
            </motion.div>
          )}

          {/* ============ the status slot — WAITING heading vs LIVE round pills ============
              USER SPEC (Task 57): one FIXED-HEIGHT slot serves both states, so
              the battle grid below sits at the exact same Y while waiting and
              while fighting — nothing on screen moves when the battle starts. */}
          <div className="mt-6 flex min-h-[44px] flex-col justify-center">
            {view.status === "waiting" && (phase === "waiting" || phase === "countdown") ? (
              <div className="text-center">
                <p className="font-display flex items-center justify-center gap-2 text-sm font-black uppercase tracking-[0.3em] text-fuchsia-300">
                  <Zap className="h-4 w-4 animate-pulse" fill="currentColor" />
                  {spectating ? "Watching — waiting for players" : "Waiting for players"}
                </p>
                <p className="mt-1 text-xs font-semibold text-white/45">
                  {spectating
                    ? "This room fills up live — join it now or keep watching until it starts."
                    : "The battle starts the moment every seat is full — call bots to fill the rest."}
                </p>
              </div>
            ) : (phase === "playing" || phase === "tiebreak" || phase === "jackpot") ? (
              // USER SPEC (Task 80): the round COUNTER is GONE — no number chips,
              // no "Round X / Y" caption. The case strip above is the only
              // scroller; this slim row keeps just the mode badges.
              <div className="flex flex-wrap items-center justify-center gap-2">
                {crazy && (
                  <span className="flex shrink-0 items-center gap-1 rounded-lg bg-rose-500/15 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-rose-300">
                    <Flame className="h-3 w-3" />
                    lowest total wins
                  </span>
                )}
                {/* USER SPEC (R40): the FAST MODE marker is DELETED with the feature */}
                {rule === "jackpot" && (
                  <span className="shrink-0 rounded-lg bg-violet-500/15 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-violet-300">
                    Jackpot draw after the last round
                  </span>
                )}
                {isShared && (
                  <span className="shrink-0 rounded-lg bg-teal-500/15 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-teal-300">
                    pot splits equally at the end
                  </span>
                )}
              </div>
            ) : null}
          </div>

          {/* ============ THE BATTLE AREA (USER SPEC Task 57) ============
              ONE grid carries the room from WAITING straight into the FIGHT —
              the screen no longer swaps when the battle starts: every seat
              keeps its column (the SQUARE reel box on top, the SMALL plate
              with the player's picture and their name under it) and the
              squares simply become the live reels; dropped skins pile up
              under the plates. During the JACKPOT draw the fight dims under
              the wheel, exactly like before. */}
          {/* USER SPEC (Task 141): the battle screen STAYS at the end — the grid
              keeps its seat columns (frozen reels + every player's drops) and
              the VICTORY overlays sit ON the winner (solo) / winning team (2v2).
              No more swapping to a separate final-columns layout. */}
          {(phase === "waiting" || phase === "countdown" || phase === "playing" || phase === "tiebreak" || phase === "jackpot" || phase === "done") && (
            <div className={cn(phase === "jackpot" && "opacity-60 transition-opacity")}>
              <BattleArea
                view={view}
                phase={phase}
                round={round}
                drawn={drawn}
                revealed={revealed}
                extraCases={extraCases}
                onLock={markRevealed}
                onPickSeat={view.teamMode && !spectating && !view.global && phase !== "countdown" ? handlePickSeat : undefined}
                // USER SPEC (Task 177): onPickBot is GONE — no hand-picked bots
                onKickBot={!spectating && !view.global && phase !== "countdown" && phase !== "done" ? kickBot : undefined}
                settled={
                  phase === "done" && results.length > 0
                    ? { winnerIds, takeMap, drops, results, isShared }
                    : null
                }
              />
            </div>
          )}

          {/* waiting-only controls — BELOW the grid so nothing above it moves when the fight starts */}
          {view.status === "waiting" && (phase === "waiting" || phase === "countdown") &&
            (spectating ? (
              <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
                {emptySeats(view) > 0 && (
                  <button
                    onClick={joinFromWatch}
                    className="gold-btn flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-black shadow-[0_0_16px_rgba(240,185,11,0.4)]"
                  >
                    <Users className="h-4 w-4" />
                    Join this battle — <Coin /> {formatCoins(entry)}
                  </button>
                )}
                <button
                  onClick={leave}
                  className="rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-white/70 transition-colors hover:bg-white/10 hover:text-white"
                >
                  Back to lobby
                </button>
              </div>
            ) : (
              <div className="mt-5">
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <button
                    onClick={callBots}
                    disabled={
                      emptySeats(view) === 0 ||
                      !!view.botCalls[view.players.find((p) => p.isYou)?.id ?? ""] ||
                      phase === "countdown" /* USER SPEC (Task 44): locked during the countdown */ ||
                      (view.global && serverActions?.busy) /* MULTIPLAYER: one POST in flight */
                    }
                    className="flex items-center gap-2 rounded-xl border border-emerald-400/40 bg-emerald-500/10 px-6 py-3 text-sm font-black text-emerald-300 transition-all hover:bg-emerald-500/20 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <Users className="h-4 w-4" />
                    Call Bots
                  </button>
                  <button
                    onClick={leave}
                    disabled={phase === "countdown" /* USER SPEC (Task 44): locked during the countdown */}
                    className="rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-white/70 transition-colors hover:bg-white/10 hover:text-white disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-white/5"
                  >
                    Leave battle
                  </button>
                </div>
                {/* USER SPEC (Task 196): the "Play with bots — every player
                    must press Call Bots" caption is DELETED completely — the
                    Call Bots button speaks for itself. */}
              </div>
            ))}
          {view.status === "waiting" && (phase === "waiting" || phase === "countdown") && (
            <div className="mx-auto mt-4 flex max-w-3xl items-start gap-2 rounded-xl border border-emerald-500/25 bg-emerald-500/5 px-4 py-3">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
              <p className="text-xs leading-relaxed text-white/60">
                <span className="font-bold text-emerald-300">Provably fair:</span> your rolls come from the HMAC seed
                commitment and land in your roll history. Everyone opens the same case each round —{" "}
                {isShared ? (
                  <span className="font-bold text-teal-300">the total drop value splits equally between every player</span>
                ) : rule === "jackpot" ? (
                  <span className="font-bold text-violet-300">
                    the pot is drawn by weight — bigger haul, better odds{crazy ? " (CRAZY: inverted)" : ""}
                  </span>
                ) : (
                  <span className={cn("font-bold", crazy && "text-rose-300")}>
                    {crazy ? "LOWEST total takes all the drops" : "highest total takes all the drops"}
                  </span>
                )}
                {view.teamMode && rule !== "shared" ? " (split equally between the winning team)" : ""}.
                {rule === "winner" ? " Ties go to a decider battle." : ""}
              </p>
            </div>
          )}

          {/* countdown overlay */}
          <AnimatePresence>
            {phase === "countdown" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="pointer-events-none fixed inset-0 z-50 grid place-items-center bg-black/60"
              >
                <motion.p
                  key={countdown}
                  initial={{ scale: 2.2, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="font-display text-8xl font-black text-amber-300 drop-shadow-[0_0_30px_rgba(240,185,11,0.6)]"
                >
                  {countdown}
                </motion.p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ================= DONE (Task 141) =================
              The fight grid above STAYS on screen — the seat columns freeze with
              every player's drops and the VICTORY overlays sit right ON the
              winning player (solo) / the winning team (2v2). The old separate
              final-columns layout that REPLACED the battle screen is GONE. */}
        </div>
      </main>

    </SiteShell>
  );
}

/* ===== THE BATTLE AREA (USER SPEC Task 57) =====
   ONE grid carries the room from WAITING straight into the FIGHT: every seat
   is a column — the SQUARE reel box on top and the SMALL rectangle under it
   (the player's picture with their name under it). Waiting: empty squares
   read "WAITING FOR PLAYER" (caps) and filled squares hold the dimmed case
   art with the future-reel hint. The moment the battle starts the SAME
   columns stay exactly in place — each square becomes the live reel and the
   dropped skins pile up under the plates. The plate is COMPACT (USER SPEC):
   a smaller picture, the bot icon inline, and NO "PLAYER" caption under the
   name; during the WAITING there are NO reaction buttons at all — more
   space, cleaner look. */

function BattleArea({
  view,
  phase,
  round,
  drawn,
  revealed,
  extraCases,
  onLock,
  onPickSeat,
  onKickBot,
  settled,
}: {
  view: Battle;
  phase: RoomPhase;
  round: number;
  drawn: Map<string, BattleResult>;
  revealed: Record<string, number>;
  /** USER SPEC (battles × COMMUNITY/EVENT): resolved defs for round cases
   *  that live outside the static catalog (player-built cc_* crates). */
  extraCases?: CaseDef[];
  onLock: (playerId: string, throughRound: number) => void;
  /** USER SPEC (2v2): pick your team AND the left/right seat inside it */
  onPickSeat?: (team: 0 | 1, side: 0 | 1) => void;
  /** USER SPEC (Task 43): kick this bot out of the room (seat reopens) */
  onKickBot?: (playerId: string) => void;
  /** USER SPEC (Task 141): the settled verdict — present ONLY at the done
   *  phase. The grid KEEPS rendering (the screen STAYS) and the VICTORY
   *  overlays sit on the winning player (solo) / the winning team (2v2). */
  settled?: {
    winnerIds: string[];
    takeMap: Record<string, number>;
    drops: number;
    results: BattleResult[];
    isShared: boolean;
  } | null;
}) {
  // USER SPEC (Task 67): LIVE JACKPOT odds — after every drop, next to each
  // player's dropped-so-far money, their current chance to draw the pot (%).
  // Same math as the final jackpot wheel (unboxed value, CRAZY inverts),
  // computed from the VISIBLE pulls only — it converges to the real draw.
  // (Hook BEFORE the early return — rules of hooks.)
  const jackpotLive = useMemo(() => {
    if (potRuleOf(view) !== "jackpot" || phase !== "playing") return null;
    const visible: BattleResult[] = view.players.map((p) => ({
      playerId: p.id,
      total: drawn.get(p.id)?.pulls.slice(0, revealed[p.id] ?? 0).reduce((a, x) => a + x.value, 0) ?? 0,
      pulls: [],
    }));
    const crazy = view.mode === "crazy";
    if (view.teamMode) {
      const t = jackpotTeamPct(view.players, visible, crazy);
      return { team: t as { t0: number; t1: number }, per: null as Record<string, number> | null };
    }
    return { team: null, per: jackpotPct(view.players, visible, crazy) as Record<string, number> };
  }, [view, phase, drawn, revealed]);
  const jackpotPctOf = useCallback(
    (p: BattlePlayer): number | undefined => {
      if (!jackpotLive) return undefined;
      if (jackpotLive.per) return Math.round((jackpotLive.per[p.id] ?? 0) * 10) / 10;
      return Math.round((jackpotLive.team?.[`t${p.team}` as "t0" | "t1"] ?? 0) * 10) / 10;
    },
    [jackpotLive]
  );

  // USER SPEC (Task 141): done KEEPS the grid up — the screen the player watched
  // the fight on stays exactly where it is; the overlays land on the winner.
  const done = !!settled;
  // true when this BattleArea instance mounted BEFORE the verdict (it rode the
  // fight) — its last reels stay frozen mid-square; a grid that mounted AT the
  // verdict (reload / re-entry) renders the settled squares instead. The lazy
  // initializer runs ONCE (first mount) — exactly the snapshot we need.
  // (Hooks BEFORE the early return — rules of hooks.)
  const [rodeFight] = useState(() => phase !== "done");
  const winnerSet = useMemo(() => new Set(settled?.winnerIds ?? []), [settled]);
  // USER SPEC (Task 177): every LOSER's pulls — at the verdict they transfer
  // to the winner's column (winner takes all, displayed on his side).
  const transferredPulls = useMemo(
    () =>
      done && settled && !settled.isShared
        ? settled.results.filter((r) => !winnerSet.has(r.playerId)).flatMap((r) => r.pulls)
        : [],
    [done, settled, winnerSet]
  );

  const waitingUI = view.status === "waiting" && (phase === "waiting" || phase === "countdown");
  // the fight itself — the countdown may still be running while the server
  // already flipped the room to "playing"; that window shows the live grid too
  const live =
    phase === "playing" ||
    phase === "tiebreak" ||
    phase === "jackpot" ||
    (phase === "countdown" && view.status !== "waiting");
  if (!waitingUI && !live && !done) return null; // transitional frames render nothing, like before
  const areaCaseById = (id: string) => CASES.find((c) => c.id === id) ?? extraCases?.find((c) => c.id === id);
  const firstCase = areaCaseById(view.rounds[0]);
  const cases = battleCases(view, extraCases);
  const roundCase = (live || done) && round >= 0 ? cases[round % cases.length] : undefined;
  // Task 141 verdict helpers — the winning team (the victory display sits on it)
  const winTeam = done ? view.players.find((p) => winnerSet.has(p.id))?.team ?? null : null;

  /* ---- THE SMALL RECTANGLE (USER SPEC Task 57) ----
     The player's picture with their name under it — IDENTICAL between
     waiting and fighting so the columns never jump: smaller picture, the
     robot icon inline next to bots, NO "PLAYER" caption under the name. */
  const plate = (
    p: BattlePlayer,
    opts: {
      called?: boolean;
      liveTotal?: number;
      jackpotPct?: number;
      /** USER SPEC (Task 142): the amber winner plate glow (solo winners) */
      winner?: boolean;
      /** SHARED battles only: the "Pot split" chip stays on every plate.
       *  (The solo/2v2 VICTORY display moved ABOVE the last opened box.) */
      win?: { label: string; amount: number };
    } = {}
  ) => {
    const color = playerColor(p);
    return (
      <div
        className="flex flex-col items-center gap-1 rounded-xl border bg-white/[0.04] px-3 py-2.5"
        style={{
          borderColor: opts.winner ? "rgba(240,185,11,0.65)" : `${color}80`,
          boxShadow: opts.winner
            ? "0 0 18px rgba(240,185,11,0.16), inset 0 0 14px rgba(240,185,11,0.08)"
            : `inset 0 0 14px ${color}0d`,
        }}
      >
        <PlayerAvatar player={p} className="h-11 w-11 text-sm" />
        <span className="flex max-w-full items-center gap-1">
          <span className="min-w-0 truncate text-center text-sm font-black text-white/90" title={p.name}>
            {p.isYou ? "You" : p.name}
          </span>
          {p.isBot && <Bot className="h-3.5 w-3.5 shrink-0 text-amber-300" aria-label="Site bot" />}
        </span>
        {typeof opts.liveTotal === "number" && (
          <span
            className="font-display text-sm font-black leading-none text-amber-300"
            title={done ? "The total value this player dropped in this battle" : "Value this player dropped so far"}
          >
            <Coin /> {formatCoins(opts.liveTotal)}
          </span>
        )}
        {/* USER SPEC (Task 67): this player's LIVE chance to win the JACKPOT,
            right next to the money they dropped so far (in 2v2 the TEAM's odds) */}
        {typeof opts.jackpotPct === "number" && (
          <span
            className="font-display rounded bg-violet-500/20 px-1.5 py-0.5 text-[11px] font-black leading-none text-violet-300"
            title={view.teamMode ? `Team odds to draw the JACKPOT right now` : "This player's odds to draw the JACKPOT right now"}
          >
            {opts.jackpotPct}% JACKPOT
          </span>
        )}
        {/* SHARED battles (Task 141): the "Pot split" chip stays on every
            plate — Task 142 moved the solo/2v2 VICTORY display up onto the
            last opened box, so no winner chips render here anymore. */}
        {opts.win && (
          <span
            data-victory="split"
            className="font-display anim-pop-in flex items-center gap-1 rounded-lg border border-amber-400/60 bg-amber-400/15 px-2 py-0.5 text-[11px] font-black uppercase leading-none tracking-widest text-amber-300"
            title="What this player took from this battle"
          >
            {opts.win.label}
            <span className="flex items-center gap-0.5">
              <Coin className="h-3 w-3" /> {formatCoins(opts.win.amount)}
            </span>
          </span>
        )}
        {opts.called && (
          <span className="anim-glow-pulse rounded bg-emerald-500/20 px-1.5 py-0.5 text-[8px] font-black uppercase tracking-widest text-emerald-300">
            Play with bots
          </span>
        )}
        {p.isBot && onKickBot && !done && (
          <button
            type="button"
            onClick={() => onKickBot(p.id)}
            className="mt-0.5 flex items-center gap-1 rounded-lg border border-red-400/40 bg-red-500/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-red-300 transition-all hover:bg-red-500/25"
            aria-label={`Kick ${p.name} out of the battle`}
          >
            <UserX className="h-3 w-3" />
            Kick
          </button>
        )}
      </div>
    );
  };

  /* --- USER SPEC (Task 177): THE VICTORY HEADLINE MOVED INTO THE SQUARE ---
     The old above-the-reel victory slot is DELETED. At the verdict the
     winner's square itself stops showing the winning skin: in its place the
     winner's picture fills the reel square with WINNER in green on it and
     WON : $x right under it (WinnerSquareCard). In 2v2 the winning team's
     two squares become ONE team card — the CT/T image + WINNER + WON : $x
     + how much each player took (TeamWinnerCard). --- */

  /* --- a FILLED seat while WAITING: square (future reel) + plate --- */
  const waitingColumn = (p: BattlePlayer) => {
    const color = playerColor(p);
    const called = !!view.botCalls[p.id] && !p.isBot;
    return (
      <div key={p.id} className="relative flex flex-col gap-2">
        {/* THE SQUARE — this exact box becomes the live reel when the room fills */}
        <div
          className="relative grid aspect-square place-items-center overflow-hidden rounded-2xl border"
          style={{
            borderColor: `${color}55`,
            background: `radial-gradient(ellipse at 50% 68%, ${color}16, transparent 72%), #120c20`,
          }}
        >
          {firstCase && (
            <CaseImage
              caseId={firstCase.id}
              alt={firstCase.name}
              color={firstCase.tierColor}
              color2={firstCase.tierColor2}
              communityDesign={firstCase.communityDesign}
              className="h-[58%] w-auto opacity-40"
              sizes="180px"
            />
          )}
          {/* R38 (USER SPEC): the "Reel — starts when full" caption is DELETED —
              the waiting square shows just the crate art. */}
        </div>
        {plate(p, { called })}
      </div>
    );
  };

  /* --- a seat in the FIGHT — and, USER SPEC (Task 141/177), the SAME seat at
     the verdict: the square freezes on the last reel it showed (a grid that
     mounted straight at the verdict renders the settled square instead).
     Task 177: the WINNER's square is REPLACED by the winner card — the skin
     is deleted entirely and the winner's picture stands on the reel with
     WINNER + WON : $x — and every loser's skins TRANSFER to the winner's
     column (the loser's own stack is emptied). --- */
  const playingColumn = (p: BattlePlayer, pi: number) => {
    const color = playerColor(p);
    const d = drawn.get(p.id);
    const pull = round >= 0 ? d?.pulls.find((x) => x.round === round) : undefined;
    const res = settled?.results.find((r) => r.playerId === p.id);
    const donePulls = res?.pulls ?? [];
    const revealedPulls = done ? donePulls : d ? d.pulls.slice(0, revealed[p.id] ?? 0) : [];
    const finalTotal = res?.total ?? 0;
    const duration = seatReelMs(p.isYou, pi);
    // USER SPEC (Task 172 — SERVER-TIME REELS): the ABSOLUTE wall-clock moment
    // this round's spin begins on the shared schedule (battle start + slot
    // start + poll offset). Passed to the reel so its position is a pure
    // function of server time: waking from a hidden tab lands the strip on
    // the EXACT server-true frame — never a reset, never a replay from zero.
    const slot = view.schedule?.[round];
    const roundStartAtMs =
      view.global && view.startedAtMs && slot && round >= 0
        ? view.startedAtMs + slot.startMs + (view.clockOffset ?? 0)
        : undefined;
    const isWinner = done && winnerSet.has(p.id);
    // Task 177: the winner card REPLACES the reel square at the verdict
    // (solo only — in 2v2 the winning team renders the team card instead)
    const showWinnerCard = !!isWinner && !settled?.isShared && !view.teamMode;
    // Task 177: winner takes ALL — the loser's skins render under the
    // winner's plate, merged into one chronological stack with his own.
    const winnerTakesAll =
      done && isWinner && !settled?.isShared
        ? [...(res?.pulls ?? []), ...transferredPulls].sort((a, b) => a.round - b.round)
        : null;
    // SHARED battles keep their "Pot split" plate chips.
    // the frozen reel stays ONLY for a grid that rode the fight; a grid that
    // mounted at the verdict shows the settled square (last drop, static)
    const keepReel = done && rodeFight && !!pull && !!roundCase;
    return (
      <div key={p.id} className="relative flex flex-col gap-2">
        {/* THE SQUARE — the live reel box, the exact box the waiting square used */}
        <div
          className="relative aspect-square overflow-hidden rounded-2xl border transition-shadow"
          style={{
            borderColor: isWinner && !settled?.isShared ? "rgba(240,185,11,0.7)" : `${color}55`,
            background: `radial-gradient(ellipse at 50% 68%, ${color}16, transparent 72%), #120c20`,
            boxShadow: isWinner && !settled?.isShared ? "0 0 26px rgba(240,185,11,0.20)" : undefined,
          }}
        >
          {showWinnerCard ? (
            /* USER SPEC (Task 177): the winning skin is GONE from the reel —
               the winner's picture stands on the square with WINNER + WON */
            <WinnerSquareCard player={p} take={settled?.takeMap[p.id] ?? settled?.drops ?? 0} />
          ) : keepReel ? (
            /* Task 141: the SAME reel this seat just landed — frozen exactly
               where it stopped (same key, same props: no remount, no re-spin) */
            <RoundReel
              key={`reel-${round}-${p.id}`}
              playerId={p.id}
              roundIndex={round}
              roundCase={roundCase!}
              pull={pull!}
              duration={duration}
              onLock={onLock}
              startAtMs={roundStartAtMs}
              seed={hashSeed(
                `${view.id}|${p.id}|${round}|${pull!.skinId}|${pull!.wear ?? ""}|${pull!.value}|${pull!.rd ? 1 : 0}`
              )}
            />
          ) : done ? (
            <SettledSquare pull={donePulls[donePulls.length - 1]} caseDef={firstCase} />
          ) : round < 0 || !roundCase ? (
            <div className="grid h-full place-items-center">
              <span className="font-display flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.3em] text-fuchsia-300">
                <Zap className="h-4 w-4 animate-pulse" fill="currentColor" />
                Get ready
              </span>
            </div>
          ) : pull ? (
            // USER SPEC (Task 57): the reel mounts INSIDE the seat's square —
            // the column itself never remounts, so nothing jumps between rounds
            <RoundReel
              key={`reel-${round}-${p.id}`}
              playerId={p.id}
              roundIndex={round}
              roundCase={roundCase}
              pull={pull}
              duration={duration}
              onLock={onLock}
              startAtMs={roundStartAtMs}
              /* USER SPEC (Task 31): SYNCHRONIZED REELS — the seed derives from
                 data EVERY viewer already shares (battle id + seat + round + the
                 pull itself), so all screens build the identical strip: same
                 skins in the same order, same ROLLDROP decoy, same stop. */
              seed={hashSeed(
                `${view.id}|${p.id}|${round}|${pull.skinId}|${pull.wear ?? ""}|${pull.value}|${pull.rd ? 1 : 0}`
              )}
            />
          ) : (
            <div className="grid h-full place-items-center">
              <p className="text-[11px] font-bold uppercase tracking-widest text-white/30">Rolling...</p>
            </div>
          )}
        </div>
        {plate(p, {
          liveTotal: done ? finalTotal : revealedPulls.reduce((s, x) => s + x.value, 0),
          jackpotPct: jackpotPctOf(p),
          winner: isWinner && !settled?.isShared,
          ...(done && settled?.isShared ? { win: { label: "Pot split", amount: settled.takeMap[p.id] ?? 0 } } : {}),
        })}
        {/* USER SPEC (Task 177): the verdict stacks — the winner's column
            holds EVERY skin (his own + the losers', transferred); a loser's
            column shows the transfer note instead of his old stack. SHARED
            battles keep each player's own drops. */}
        {winnerTakesAll ? (
          <div className="grid grid-cols-2 gap-2" aria-label="All the skins — winner takes all">
            {winnerTakesAll.map((pl, i) => (
              <DropTile key={`${pl.round}-${pl.skinId}-${i}`} pull={pl} />
            ))}
          </div>
        ) : done && !settled?.isShared ? (
          <p
            className="flex items-center justify-center gap-1.5 rounded-xl border border-amber-400/25 bg-amber-400/[0.06] px-3 py-2.5 text-center text-[10px] font-black uppercase tracking-widest text-amber-300/80"
            aria-label="All skins transferred to the winner"
          >
            <ArrowRight className="h-3.5 w-3.5 shrink-0" />
            All skins transferred to the winner
          </p>
        ) : revealedPulls.length > 0 && (
          <div className="grid grid-cols-2 gap-2" aria-label={done ? "Final skins" : "Skins dropped so far"}>
            {revealedPulls.map((pl, i) => (
              <DropTile key={`${pl.round}-${pl.skinId}-${i}`} pull={pl} />
            ))}
          </div>
        )}
      </div>
    );
  };

  /* --- an EMPTY seat (waiting only): "WAITING FOR PLAYER" square + join / pick-bot rectangle --- */
  const emptyColumn = (team: 0 | 1 | null, side?: 0 | 1, key?: string) => {
    const solo = team === null || side === undefined;
    const you = view.players.find((p) => p.isYou);
    const youTeam = you?.team ?? null;
    const youSide = you ? (you.side ?? 0) : null;
    const ownTeam = !solo && youTeam === team;
    const mySeat = ownTeam && youSide === side;
    const canJoin = !!onPickSeat && !solo && youTeam !== null && !mySeat;
    return (
      <div key={key} className="flex flex-col gap-2">
        {/* USER SPEC (Task 177): the reserved victory slot is GONE — the verdict
            lives INSIDE the winner's square now, so empty seats align with the
            plain squares above them */}
        {/* the SQUARE — the reel spot that is still up for grabs */}
        <div className="grid aspect-square place-items-center rounded-2xl border border-dashed border-white/10 bg-white/[0.015]">
          <span className="font-display px-3 text-center text-[11px] font-black uppercase leading-relaxed tracking-[0.22em] text-white/30">
            WAITING FOR PLAYER
          </span>
        </div>
        {solo ? (
          // solo battles: the seat is display-only — joining happens from the lobby.
          // USER SPEC (Task 177): the CHOOSE BOT chip is DELETED.
          <div className="flex flex-col items-center gap-1 rounded-xl border border-dashed border-white/12 bg-white/[0.02] px-2 py-2">
            <span className="text-[10px] font-black uppercase tracking-widest text-white/30">Empty seat</span>
          </div>
        ) : (
          // USER SPEC (2v2): every empty seat is a pickable LEFT/RIGHT spot — on the
          // other team (switch squads) or on your own team (move to the free side).
          // Task 177: the hand-picked-bot chip is GONE.
          <div
            className={cn(
              "flex flex-col items-center gap-1 rounded-xl p-2",
              canJoin ? "border-2 border-dashed" : "border border-dashed border-white/12 bg-white/[0.02]"
            )}
            style={canJoin ? { borderColor: `${TEAM_META[team].color}88` } : undefined}
          >
            <button
              type="button"
              disabled={!canJoin}
              onClick={() => {
                if (canJoin) onPickSeat?.(team, side);
              }}
              className={cn(
                "flex flex-col items-center gap-0.5 rounded-lg",
                canJoin && "transition-colors hover:bg-white/[0.06]"
              )}
              aria-label={
                canJoin
                  ? ownTeam
                    ? `Move to the ${side === 0 ? "left" : "right"} seat of team ${TEAM_META[team].name}`
                    : `Join team ${TEAM_META[team].name} — ${side === 0 ? "left" : "right"} seat`
                  : undefined
              }
            >
              <span className={cn("text-[10px] font-black uppercase tracking-widest", canJoin ? "text-white/70" : "text-white/30")}>
                {canJoin ? (ownTeam ? "Move to this seat" : "Tap to join") : "Empty seat"}
              </span>
              <span
                className="text-[9px] font-black uppercase tracking-widest"
                style={canJoin ? { color: TEAM_META[team].color } : undefined}
              >
                {side === 0 ? "Left" : "Right"} • Team {TEAM_META[team].name}
              </span>
            </button>
          </div>
        )}
      </div>
    );
  };

  // USER SPEC (2v2): columns sit in the seat the player picked — LEFT then RIGHT
  const teamMember = (team: 0 | 1, side: 0 | 1) => {
    const ms = view.players.filter((pl) => pl.team === team);
    return ms.find((pl, i) => sideOf(pl, i) === side);
  };

  if (view.teamMode) {
    return (
      <div className="mt-5 grid items-start gap-4 lg:grid-cols-2" data-room-grid="teams">
        {([0, 1] as const).map((team) => {
          const members = view.players.filter((p) => p.team === team);
          // during the fight the CT/T header carries the team's running total —
          // what both of its players dropped together so far (at the verdict it
          // reads the settled results — a re-entered grid has no live clock)
          const teamTotal = done
            ? members.reduce((sum, p) => sum + (settled?.results.find((r) => r.playerId === p.id)?.total ?? 0), 0)
            : members.reduce(
                (sum, p) =>
                  sum + (drawn.get(p.id)?.pulls.slice(0, revealed[p.id] ?? 0).reduce((a, x) => a + x.value, 0) ?? 0),
                0
              );
          // USER SPEC (Task 141 + 142): VICTORY sits ON THE WINNING TEAM — the
          // team box glows amber and the bouncing CT/T image + the green
          // VICTORY + each player's TAKE row hover directly ABOVE the team's
          // last opened boxes (see teamVictoryBlock below).
          const teamWon = done && winTeam === team;
          return (
            <div
              key={team}
              data-victory={teamWon ? "team" : undefined}
              className={cn("rounded-2xl border p-4", teamWon && "anim-pop-in")}
              style={
                teamWon
                  ? {
                      borderColor: "rgba(240,185,11,0.6)",
                      background: "rgba(240,185,11,0.06)",
                      boxShadow: "0 0 30px rgba(240,185,11,0.14)",
                    }
                  : { borderColor: `${TEAM_META[team].color}4d`, background: `${TEAM_META[team].color}0a` }
              }
            >
              <p
                className="font-display mb-2 flex items-center justify-between gap-2 px-1 text-center text-sm font-black uppercase tracking-[0.25em]"
                style={{ color: teamWon ? "#f0b90b" : TEAM_META[team].color }}
              >
                <span className="flex items-center gap-2">
                  <img src={TEAM_META[team].img} alt="" className="h-8 w-auto object-contain" draggable={false} />
                  {TEAM_META[team].name}
                </span>
                {waitingUI ? (
                  <span className="text-[11px] tracking-widest text-white/40">{members.length}/2</span>
                ) : (
                  <span
                    className="font-display shrink-0 text-sm font-black text-amber-300"
                    title={done ? "What both players of this team dropped together" : "What both players of this team dropped together so far"}
                  >
                    <Coin /> {formatCoins(teamTotal)}
                  </span>
                )}
              </p>
              {/* USER SPEC (Task 177): the team VICTORY display moved INTO the
                  reel squares — the winning team's two squares are REPLACED by
                  ONE spanning team card: the CT/T image, WINNER in green,
                  WON : $x and how much each player took. The losing team keeps
                  its frozen squares (with the transfer note under the plates). */}
              {done && teamWon && !settled?.isShared ? (
                <TeamWinnerCard team={team} members={members} takeMap={settled?.takeMap ?? {}} total={teamTotal} />
              ) : (
                <div className="grid grid-cols-2 gap-4">
                  {([0, 1] as const).map((side) => {
                    const member = teamMember(team, side);
                    if (member) {
                      return live || done ? playingColumn(member, view.players.indexOf(member)) : waitingColumn(member);
                    }
                    return emptyColumn(team, side, `slot-${team}-${side}`);
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  }
  return (
    <div
      data-room-grid="solo"
      className={cn(
        "mx-auto mt-5 grid gap-4",
        view.maxPlayers === 2 ? "max-w-3xl grid-cols-2" : view.maxPlayers === 3 ? "max-w-4xl grid-cols-3" : "max-w-6xl grid-cols-2 sm:grid-cols-4"
      )}
    >
      {Array.from({ length: view.maxPlayers }, (_, seat) => {
        const p = view.players[seat];
        if (p) return live || done ? playingColumn(p, seat) : waitingColumn(p);
        return emptyColumn(null, undefined, `solo-${seat}`);
      })}
    </div>
  );
}

/* ===== one round's reel inside a seat's square (mounted fresh per round) =====
   Carries the ROLLDROP two-stage flow: the reel stops ON the raredrop art and
   sits on it for the marker beat (Task 149: the IMPACT CUTSCENE VIDEO IS
   DELETED — no rolldrop.mp4, the frameless image IS the beat), then the rare
   round opens on the SAME reel. USER SPEC (Task 57): the reel FILLS the seat's
   square (h-full) instead of the old fixed-height box. */
function RoundReel({
  playerId,
  roundIndex,
  roundCase,
  pull,
  duration,
  onLock,
  seed,
  startAtMs,
}: {
  playerId: string;
  roundIndex: number;
  roundCase: NonNullable<ReturnType<typeof battleCases>[number]>;
  pull: BattlePull;
  duration: number;
  onLock: (playerId: string, throughRound: number) => void;
  /** USER SPEC (Task 31): the shared reel seed — every viewer builds the SAME strip */
  seed: number;
  /** USER SPEC (Task 172): the shared-clock wall-clock start of THIS round's
   *  main spin (server schedule) — makes every reel seekable/ALT-TAB-proof. */
  startAtMs?: number;
}) {
  const isRolldrop = !!pull.rd;
  const [bonus, setBonus] = useState(false);
  // Task 149: the cutscene state is GONE — the marker beat (RD_BEAT_MS on the
  // frameless raredrop image) separates the main reel from the bonus reel.
  const beatRef = useRef<number | undefined>(undefined);
  useEffect(() => () => window.clearTimeout(beatRef.current), []);
  // USER SPEC (Task 172): the bonus reel's own wall-clock start — main spin
  // + the marker beat. When the viewer wakes mid-chain (or joined mid-round),
  // the remaining beat shrinks to what's left and the bonus reel SEEKS to
  // the server-true position instead of replaying from zero.
  const bonusStartAt = startAtMs !== undefined ? startAtMs + duration + RD_BEAT_MS : undefined;
  const mainDone = () => {
    if (!isRolldrop) {
      onLock(playerId, roundIndex + 1);
      return;
    }
    const wait = bonusStartAt !== undefined ? Math.max(0, bonusStartAt - Date.now()) : RD_BEAT_MS;
    beatRef.current = window.setTimeout(() => setBonus(true), wait);
  };
  return (
    <div className="relative h-full" data-start-at={startAtMs !== undefined ? String(startAtMs) : undefined} data-testid="round-reel">
      {bonus ? (
        // USER SPEC (Task 61 fix): key="bonus" FORCES a fresh mount — without a
        // key React kept the SAME BattleReel instance (same type, same slot) and
        // its useState strip still held the ROLLDROP marker in the winner cell,
        // so the rare reel landed on the raredrop art AGAIN while the real skin
        // was silently credited. A fresh mount rebuilds the strip from the real
        // pull target (the rare skin) — and from the case's RARE pool, exactly
        // like the solo opener's bonus spin.
        <BattleReel
          key="bonus"
          caseDef={isRolldrop ? rareCaseOf(roundCase) : roundCase}
          target={pull.skinId}
          targetWear={pull.wear}
          duration={duration + 1000}
          onDone={() => onLock(playerId, roundIndex + 1)}
          /* Task 79: the bonus reel is the ROLLDROP payoff itself — no decoy marker rides it */
          rdDecoy={false}
          /* Task 31: a DIFFERENT stream off the same shared seed — the bonus strip
             would look cloned if it reused the main reel's exact sequence */
          seed={seed ^ 0x9e3779b9}
          startAtMs={bonusStartAt}
          className="h-full rounded-none border-0"
        />
      ) : (
        <BattleReel
          key="main"
          caseDef={roundCase}
          target={isRolldrop ? ROLLDROP_MARKER : pull.skinId}
          targetWear={isRolldrop ? undefined : pull.wear}
          duration={duration}
          onDone={mainDone}
          seed={seed}
          startAtMs={startAtMs}
          /* USER SPEC (Task 66): NO gold flash on the ROLLDROP marker lock —
             the flash overlapped the white cover and read as glitchy. Normal
             locks keep it; the rare bonus reel keeps its rare-pull flash. */
          flashOnLock={!isRolldrop}
          className="h-full rounded-none border-0"
        />
      )}
      {/* Task 149 (USER SPEC): the cutscene overlay is DELETED — the marker
          beat happens on the frameless raredrop image itself; the bonus reel
          mounts when the beat timer fires (mainDone). */}
    </div>
  );
}

/* ===== one dropped skin — a SQUARE tile with the name and price below the
   image (USER SPEC: bigger, square, caption under the picture; the category
   prefix is dropped from the caption — "Sticker | Polar Bears (Foil)" shows
   as "Polar Bears (Foil)". USER SPEC: the hover tooltip is GONE — no native
   title bubble on the dropped skins anymore). Task 141: the drops STAY in
   their own player's column at the verdict — no transfer badges anymore. ===== */
function DropTile({ pull }: { pull: BattlePull }) {
  const skin = SKINS[pull.skinId];
  if (!skin) return null;
  const rc = RARITY_META[skin.rarity].color;
  return (
    <span
      className="relative mx-auto block w-full max-w-[190px] rounded-xl border bg-black/35 p-2.5"
      style={{ borderColor: `${rc}66` }}
    >
      <span
        className="relative grid aspect-square place-items-center overflow-hidden rounded-lg"
      >
        {/* USER SPEC (Task 89/89b): eclipse artwork instead of the rarity glow.
            USER SPEC (Task 95): the backdrop is absolute → it painted OVER the
            un-positioned skin img below the battle. `relative z-10` promotes
            the img into the positioned paint group — the eclipse now sits
            BEHIND the skin (same fix pattern as SkinTile's relative wrapper). */}
        <RarityBackdrop rarity={skin.rarity} />
        <SkinImage skinId={pull.skinId} kind={skin.weapon} colors={skin.colors} className="relative z-10 max-h-[80%] max-w-[90%]" alt={skin.name} />
      </span>
      <span className="mt-1.5 block truncate text-center text-xs font-semibold text-white/75">
        {shortSkinName(skin.name)}
      </span>
      <span className="mt-0.5 flex items-center justify-between">
        <span className="flex items-center gap-1">
          <span className="text-[10px] font-black uppercase tracking-wider text-white/30">R{pull.round + 1}</span>
          {/* R43 USER SPEC: the exterior is ALWAYS on the drop tile — default
              Field-Tested when this pull carries none — in its own color */}
          {(() => {
            const wl = displayWearLabel(pull.wear);
            return (
              <span
                className="rounded bg-black/60 px-1 text-[9px] font-black uppercase tracking-wider"
                style={{ color: wearColorOf(wl) }}
                title={`Exterior: ${wl}`}
              >
                {wearShortOf(wl)}
              </span>
            );
          })()}
        </span>
        <span className="font-display text-sm font-black text-amber-300">
          <Coin /> {formatCoins(pull.value)}
        </span>
      </span>
    </span>
  );
}

/* ===== USER SPEC (Task 141): the settled square — for a grid that mounted
   straight AT the verdict (reload / re-entry into a finished battle) there is
   no reel to freeze, so the seat's square shows its last drop as a static
   "stopped reel" frame: the skin centered on its rarity eclipse + the same
   four-line caption the live reel locks with. ===== */
function SettledSquare({ pull, caseDef }: { pull?: BattlePull; caseDef?: CaseDef }) {
  const skin = pull ? SKINS[pull.skinId] : undefined;
  return (
    <div className="relative grid h-full w-full place-items-center overflow-hidden" dir="ltr">
      {pull && skin ? (
        <>
          <RarityBackdrop rarity={skin.rarity} fallbackColor="#f0b90b" className="inset-[8%]" />
          <SkinImage
            skinId={pull.skinId}
            kind={skin.weapon}
            colors={skin.colors}
            alt={skin.name}
            className="absolute inset-0 m-auto max-h-[70%] max-w-[84%] object-contain drop-shadow-[0_0_26px_rgba(240,185,11,0.45)]"
          />
          <WinnerPlate skinId={pull.skinId} wearId={pull.wear} />
        </>
      ) : caseDef ? (
        <CaseImage
          caseId={caseDef.id}
          alt={caseDef.name}
          color={caseDef.tierColor}
          color2={caseDef.tierColor2}
          communityDesign={caseDef.communityDesign}
          className="h-[58%] w-auto opacity-40"
          sizes="180px"
        />
      ) : null}
    </div>
  );
}

/* ===== USER SPEC (Task 177): THE WINNER CARD — the verdict lives INSIDE the
   winner's reel square. The winning skin is deleted entirely from the square:
   in its place stands the winner's picture with WINNER in green on it and
   WON : $x right under it. (The old VICTORY banner ABOVE the reel is gone.) ===== */
function WinnerSquareCard({ player, take }: { player: BattlePlayer; take: number }) {
  return (
    <div
      className="relative grid h-full w-full place-items-center overflow-hidden"
      dir="ltr"
      data-testid="battle-winner-card"
      aria-label={`${player.isYou ? "You" : player.name} won the battle`}
    >
      {/* golden reactor glow behind the winner */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{ background: "radial-gradient(circle at 50% 40%, rgba(240,185,11,0.26), transparent 72%)" }}
      />
      <div className="anim-pop-in relative z-10 flex flex-col items-center gap-1.5 px-3 text-center">
        <PlayerAvatar player={player} className="anim-victory-bounce h-20 w-20 text-2xl" />
        <span
          className="font-display text-2xl font-black uppercase leading-none tracking-[0.3em] text-green-400"
          style={{ textShadow: "0 0 18px rgba(52,211,153,0.65), 0 2px 10px rgba(0,0,0,0.85)" }}
        >
          WINNER
        </span>
        <span
          className="font-display flex items-center gap-1 text-base font-black text-emerald-300"
          style={{ textShadow: "0 0 14px rgba(16,185,129,0.55), 0 2px 8px rgba(0,0,0,0.85)" }}
          title="What the winner took from this battle"
        >
          WON : <Coin className="h-4 w-4" /> {formatCoins(take)}
        </span>
      </div>
    </div>
  );
}

/* ===== USER SPEC (Task 177): THE TEAM WINNER CARD — in 2v2 the winning
   team's two reel squares collapse into ONE spanning card: the CT/T team
   picture (instead of the players' pictures), WINNER in green, WON : $x for
   the whole pot, and HOW MUCH EACH PLAYER TOOK on individual chips. ===== */
function TeamWinnerCard({
  team,
  members,
  takeMap,
  total,
}: {
  team: 0 | 1;
  members: BattlePlayer[];
  takeMap: Record<string, number>;
  total: number;
}) {
  return (
    <div
      className="anim-pop-in relative grid place-items-center gap-3 overflow-hidden rounded-2xl border p-6 lg:col-span-2"
      style={{
        borderColor: "rgba(240,185,11,0.6)",
        background:
          "radial-gradient(circle at 50% 32%, rgba(240,185,11,0.16), transparent 72%), rgba(240,185,11,0.05)",
        boxShadow: "0 0 30px rgba(240,185,11,0.16)",
      }}
      data-testid="battle-winner-card"
      aria-label={`Team ${TEAM_META[team].name} won the battle`}
    >
      <img
        src={TEAM_META[team].img}
        alt=""
        draggable={false}
        className="anim-victory-bounce h-20 w-auto object-contain drop-shadow-[0_0_26px_rgba(240,185,11,0.55)]"
      />
      <div className="flex flex-col items-center gap-1.5">
        <span
          className="font-display text-3xl font-black uppercase leading-none tracking-[0.3em] text-green-400"
          style={{ textShadow: "0 0 18px rgba(52,211,153,0.65), 0 2px 10px rgba(0,0,0,0.85)" }}
        >
          WINNER
        </span>
        <span
          className="font-display flex items-center gap-1 text-lg font-black text-emerald-300"
          style={{ textShadow: "0 0 14px rgba(16,185,129,0.55), 0 2px 8px rgba(0,0,0,0.85)" }}
          title="What the winning team took from this battle"
        >
          WON : <Coin className="h-4.5 w-4.5" /> {formatCoins(total)}
        </span>
      </div>
      {/* how much EACH player took */}
      <div className="flex w-full flex-wrap items-center justify-center gap-2">
        {members.map((m) => (
          <span
            key={m.id}
            data-victory="share"
            className="flex items-center gap-1.5 rounded-lg border border-emerald-400/45 bg-emerald-400/10 px-2.5 py-1.5 text-[11px] font-black uppercase leading-none tracking-widest text-emerald-300"
            title={`What ${m.isYou ? "you" : m.name} took from this battle`}
          >
            <PlayerAvatar player={m} className="h-5 w-5 text-[7px]" />
            <span className="max-w-28 truncate">{m.isYou ? "You" : m.name}</span>
            <span className="flex items-center gap-0.5">
              <Coin className="h-3 w-3" /> {formatCoins(takeMap[m.id] ?? 0)}
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}

