"use client";

import { SpecialForYou } from "./SpecialForYou";
import { CommunityCases } from "./CommunityCases";

/**
 * USER SPEC (Task 32): the Provably Fair / Terms of Service cards are GONE —
 * both moved to the top row of the header as the T.O.S and P.F shortcut
 * buttons. This section now carries only "Special for you".
 * USER SPEC (Task 142): the COMMUNITY CASES category sits right BELOW
 * "Special for you".
 */
export function PromoSection() {
  return (
    <section
      id="news"
      className="relative mx-auto max-w-7xl scroll-mt-28 px-4 py-14"
      aria-label="Community and updates"
    >
      {/* ===== USER SPEC: the "JOIN OUR DISCORD SERVER" banner is GONE =====
          Its slot is now the free daily LEVEL cases category — "Special for
          you". The Discord icon itself stays ONLY in the TopBar. */}
      <SpecialForYou />
      <CommunityCases />
    </section>
  );
}
