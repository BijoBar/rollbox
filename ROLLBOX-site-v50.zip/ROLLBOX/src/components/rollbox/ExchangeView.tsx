"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Search, ShoppingCart, Star } from "lucide-react";
import { RARITY_META, formatCoins, type Rarity, type WeaponKind } from "@/lib/cases";
import { displayWearLabel, wearColorOf } from "@/lib/wear";
import { expandImg } from "@/lib/skin-img";
import { GUEST_FAVS_KEY, useAuthStore } from "@/lib/auth";
import { useCaseStore, type InvItem } from "@/lib/store";
import { useSession } from "@/lib/session";
import { SiteShell } from "./SiteShell";
import { WeaponArt } from "./WeaponArt";
import { RarityBackdrop } from "./RarityBackdrop";
import { InventoryDrawer } from "./InventoryDrawer";
import { Coin } from "./Coin";
import { WeaponLabel } from "./WeaponLabel";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { sfx } from "@/lib/sound";

/* ===== COIN EXCHANGE — LIVE STEAM STOCK with a 5-MINUTE SYNC (Task 24) =====
   USER SPEC: the exchange lists EXACTLY the skins in the site's Steam
   inventory (steamcommunity.com/id/bijobarmain/inventory#730), one tile per
   ASSET — every wear of a skin is its own item, and each tile shows its wear
   label ABOVE the rarity line. USER SPEC (Task 24): buying a skin does NOT
   remove it from the list anymore — a SYNC every 5 minutes (server timer +
   this page's own poll) checks which skins exist in the Steam account and
   that sync alone adds/removes tiles. USER SPEC (Task 25): a tile a player
   has ALREADY taken into his inventory shows an "IN CART" mark — visible to
   HIM alone (the server returns each caller's own takes; guests mark theirs
   locally), never to the other players. Prices come from the SERVER
   (/api/steam-exchange — same catalog math as the whole economy); the buy
   still moves coins through the DATABASE for signed-in players and the local
   wallet for guests. The exchange is final — sells go back through the
   inventory drawer. The old wear PICKER is gone: an inventory asset IS a
   specific wear. Pagination (Task 91) stays. */

interface CatalogEntry {
  id: string; // "steam:<assetid>" — one physical asset from the live stock
  n: string; // base display name ("StatTrak™ AK-47 | Slate")
  name: string; // full market name incl. wear ("AK-47 | Slate (Field-Tested)")
  w: string; // weapon/label display name ("AK-47" / "Agent" / …)
  r: Rarity;
  p: number; // real USD price (server-resolved)
  v: number; // site coin value — THE price (server-resolved)
  img: string | null;
  est?: 1; // price estimated (no market data)
  t?: "sticker" | "charm" | "agent" | "patch"; // item type (undefined = weapon skin)
  cat?: string; // category key (knives/gloves/rifles/pistols/smgs/heavy/agents/stickers/charms/patches)
  a?: string; // SVG fallback art kind
  wearLabel?: string | null; // FIXED exterior of this asset — shown above the rarity
}

/** USER SPEC (Task 24): the automatic SYNC cadence — this page re-reads the
 *  persisted catalog every 5 minutes, in step with the server's own timer. */
const SYNC_POLL_MS = 5 * 60_000;

const PAGE_SIZE = 60;

type CatKey =
  | "all"
  | "knives"
  | "gloves"
  | "rifles"
  | "pistols"
  | "smgs"
  | "heavy"
  | "zeus"
  | "agents"
  | "stickers"
  | "charms"
  | "patches";

/** Catalog categories exactly per user spec. */
const CATEGORY_OPTIONS: { value: CatKey; label: string }[] = [
  { value: "all", label: "All Items" },
  { value: "knives", label: "Knives" },
  { value: "gloves", label: "Gloves" },
  { value: "rifles", label: "Rifles" },
  { value: "pistols", label: "Pistols" },
  { value: "smgs", label: "SMGs" },
  { value: "heavy", label: "Heavy" },
  { value: "zeus", label: "Zeus" },
  { value: "agents", label: "Agents" },
  { value: "stickers", label: "Stickers" },
  { value: "charms", label: "Charms" },
  { value: "patches", label: "Patches" },
];

/** User-specified weapon classes: per-category weapon sub-filters. */
const WEAPON_CLASS: Partial<
  Record<CatKey, { label: string; items: { value: string; label: string }[] }>
> = {
  rifles: {
    label: "Rifles",
    items: ["AK-47", "AUG", "AWP", "FAMAS", "G3SG1", "Galil AR", "M4A1-S", "M4A4", "SCAR-20", "SG 553", "SSG 08"].map(
      (w) => ({ value: w, label: w })
    ),
  },
  pistols: {
    label: "Pistols",
    items: ["CZ75-Auto", "Desert Eagle", "Dual Berettas", "Five-Seven", "Glock-18", "P2000", "P250", "R8 Revolver", "Tec-9", "USP-S"].map(
      (w) => ({ value: w === "Five-Seven" ? "Five-SeveN" : w, label: w })
    ),
  },
  smgs: {
    label: "SMGs",
    items: ["MAC-10", "MP5-SD", "MP7", "MP9", "P90", "PP-Bizon", "UMP-45"].map((w) => ({ value: w, label: w })),
  },
  heavy: {
    label: "Heavy",
    items: ["M249", "MAG-7", "Negev", "Nova", "Sawed-Off", "XM1014"].map((w) => ({ value: w, label: w })),
  },
};

const WEAPON_CATS = new Set<string>(["rifles", "pistols", "smgs", "heavy"]);

const RARITY_OPTIONS: { value: string; label: string }[] = [
  { value: "all", label: "All Rarities" },
  ...(Object.entries(RARITY_META) as [Rarity, { label: string; color: string }][]).map(
    ([value, m]) => ({ value, label: m.label })
  ),
];

const RARITY_ORDER: Record<string, number> = {
  contraband: 0,
  covert: 1,
  classified: 2,
  restricted: 3,
  milspec: 4,
  consumer: 5,
};

/* ===== pagination (Task 91 USER SPEC): the exchange browses by PAGES — a
   numbered bar at the bottom of the page (1 2 3 4 5 … last) replaces the
   old LOAD MORE button. ===== */

/** The page numbers shown in the bar: first, last, and a ±1 window around
 *  the current page (widened near the edges); gaps collapse to "…". */
function pageWindow(total: number, current: number): (number | "gap")[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const keep = new Set<number>([1, total]);
  for (const p of [current - 1, current, current + 1]) if (p >= 2 && p <= total - 1) keep.add(p);
  if (current <= 4) for (const p of [2, 3, 4]) keep.add(p); // no 1-page gap at the start
  if (current >= total - 3) for (const p of [total - 3, total - 2, total - 1]) keep.add(p); // …nor at the end
  const sorted = [...keep].sort((a, b) => a - b);
  const out: (number | "gap")[] = [];
  let prev = 0;
  for (const p of sorted) {
    if (p - prev > 1) out.push("gap");
    out.push(p);
    prev = p;
  }
  return out;
}

/** One square chip in the bottom page bar — the active page gets the gold
 *  gradient, the rest stay dim until hovered. */
function PageButton({
  onClick,
  disabled,
  active,
  ariaLabel,
  children,
}: {
  onClick: () => void;
  disabled?: boolean;
  active?: boolean;
  ariaLabel: string;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      aria-current={active ? "page" : undefined}
      className={cn(
        "font-display grid h-9 min-w-9 place-items-center rounded-md border px-2 text-xs font-black transition-all",
        active
          ? "border-amber-300/70 bg-gradient-to-r from-amber-500 to-orange-500 text-black shadow-[0_0_16px_rgba(240,140,11,0.45)]"
          : disabled
            ? "cursor-default border-white/5 bg-black/30 text-white/20"
            : "border-white/10 bg-black/40 text-white/65 hover:border-amber-300/40 hover:text-amber-200"
      )}
    >
      {children}
    </button>
  );
}

/** Catalog tile image: uses the entry's own CDN URL, SVG art as fallback. */
function CatalogArt({ entry }: { entry: CatalogEntry }) {
  const [failed, setFailed] = useState(false);
  const kind = (entry.a ?? "ak") as WeaponKind;
  if (!entry.img || failed) {
    const tint = RARITY_META[entry.r]?.color ?? "#8882a8";
    return (
      <WeaponArt
        kind={kind}
        colors={[tint, "#1a1426"]}
        className="max-h-24 w-full object-contain opacity-70"
      />
    );
  }
  return (
    <img
      src={expandImg(entry.img) ?? undefined}
      alt={entry.n}
      loading="lazy"
      draggable={false}
      onError={() => setFailed(true)}
      className="max-h-24 w-full select-none object-contain drop-shadow-lg"
    />
  );
}

/** One exchange tile — one PHYSICAL asset from the Steam stock. No wear
 *  picker: the asset IS a specific exterior, shown as a line above the
 *  rarity (USER SPEC). The cart button buys THIS asset for its
 *  server-resolved price. USER SPEC (Task 25): `inCart` tiles carry an
 *  "IN CART" mark that ONLY its taker sees. */
function ExchangeTile({
  entry,
  balance,
  busy,
  isFav,
  inCart,
  onToggleFav,
  onExchange,
}: {
  entry: CatalogEntry;
  balance: number;
  busy: boolean;
  isFav: boolean;
  inCart: boolean;
  onToggleFav: (id: string) => void;
  onExchange: (entry: CatalogEntry) => void;
}) {
  const rm = RARITY_META[entry.r] ?? { label: entry.r, color: "#8882a8" };
  const price = entry.v;
  const affordable = balance >= price;

  return (
    <div
      className="group relative flex flex-col overflow-hidden rounded-xl border bg-[#130d22] transition-transform duration-200 hover:-translate-y-1"
      style={{ borderColor: isFav ? "rgba(240,185,11,0.55)" : rm.color + "40" }}
    >
      {/* USER SPEC (Task 89/89b): eclipse artwork instead of the rarity glow */}
      <RarityBackdrop rarity={entry.r} className="inset-x-0 top-0 h-2/3" />
      {/* USER SPEC (Task 25): IN CART — the mark that THIS player already
          took the skin into his inventory. Rendered only for the taker's own
          session; other players browse the tile without it. */}
      {inCart && (
        <span
          title="This skin is in your inventory"
          className="font-display absolute left-1.5 top-1.5 z-10 rounded-md border border-emerald-300/60 bg-emerald-500/25 px-1.5 py-1 text-[9px] font-black tracking-widest text-emerald-200 backdrop-blur-sm"
        >
          IN CART
        </span>
      )}
      <button
        onClick={() => onToggleFav(entry.id)}
        aria-pressed={isFav}
        aria-label={isFav ? `Remove ${entry.name} from favorites` : `Add ${entry.name} to favorites`}
        title={isFav ? "Remove from favorites" : "Add to favorites"}
        className={cn(
          "absolute right-1.5 top-1.5 z-10 grid h-7 w-7 place-items-center rounded-md border backdrop-blur-sm transition-all",
          isFav
            ? "border-amber-300/70 bg-amber-400/25 text-amber-300 shadow-[0_0_12px_rgba(240,185,11,0.55)]"
            : "border-white/15 bg-black/50 text-white/50 hover:border-amber-300/50 hover:text-amber-200"
        )}
      >
        <Star className="h-3.5 w-3.5" fill={isFav ? "currentColor" : "none"} />
      </button>
      {/* USER SPEC (Task 29): the buy action is a FULL-WIDTH BUY button at
          the bottom of the tile — the old tiny cart icon in the corner was
          too subtle; the price got bigger to match. */}
      <div className="relative flex h-28 items-center justify-center px-2 pt-2">
        <CatalogArt entry={entry} />
      </div>
      <div className="relative mt-auto border-t border-white/5 px-2 pb-2 pt-1.5">
        <p className="truncate text-[10px] font-bold text-white/45" dir="ltr">
          {/* USER SPEC (Task 26): the word "Souvenir" renders YELLOW */}
          <WeaponLabel text={entry.w} />
        </p>
        <p className="truncate text-[11px] font-bold text-white/90" dir="ltr" title={entry.name}>
          {entry.n.includes("|") ? entry.n.split("|")[1].trim() : entry.n}
        </p>
        {/* USER SPEC: the wear of THIS asset — listed ABOVE the rarity.
            R43: always in the exterior's own color; a weapon skin without a
            resolved wear still lists the default one (Field-Tested) so a skin
            never shows without its condition. Non-skins (stickers/charms/
            agents/patches) keep no condition line. */}
        {(!entry.t || entry.wearLabel) && (
          <p
            className="mt-0.5 truncate text-[10px] font-black uppercase tracking-wider"
            dir="ltr"
            style={{ color: wearColorOf(entry.wearLabel) }}
            title={`Exterior: ${displayWearLabel(entry.wearLabel)}`}
          >
            {displayWearLabel(entry.wearLabel)}
          </p>
        )}
        <div className="mt-1 flex items-end justify-between gap-1">
          <span className="font-display text-[11px] font-black" style={{ color: rm.color }}>
            {rm.label}
          </span>
          {/* USER SPEC (Task 29): the price is the hero of the tile — BIG */}
          <span
            className="font-display flex items-center gap-1 text-lg font-black leading-none text-white sm:text-xl"
            dir="ltr"
            title={`≈ $${entry.p.toFixed(2)}${entry.est ? " (estimated)" : ""}`}
          >
            {entry.est ? "~" : ""}
            <Coin className="h-4.5 w-4.5" /> {formatCoins(price)}
          </span>
        </div>
        {/* USER SPEC (Task 29): a clear, full-width BUY button — green when
            the balance covers it, dimmed "NOT ENOUGH FUNDS" when not */}
        <button
          onClick={() => onExchange(entry)}
          disabled={busy}
          aria-label={`Buy ${entry.name} for $${formatCoins(price)}`}
          title={affordable ? "Buy this skin now" : "Not enough funds"}
          className={cn(
            "font-display mt-1.5 flex w-full items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-black uppercase tracking-widest transition-all",
            affordable
              ? "bg-emerald-500 text-white shadow-[0_0_16px_rgba(16,185,129,0.35)] hover:bg-emerald-400 hover:shadow-[0_0_20px_rgba(16,185,129,0.55)]"
              : "border border-white/10 bg-white/[0.04] text-[10px] text-white/45 hover:text-white/75",
            busy && "animate-pulse",
          )}
        >
          <ShoppingCart className="h-4 w-4" />
          {affordable ? "Buy" : "Not enough funds"}
        </button>
      </div>
    </div>
  );
}

// USER SPEC (Task 26): expandImg moved to the shared lib/skin-img module —
// the INVENTORY drawer, the profile grid and the upgrader must expand the
// same shorthands the exchange does (steam-bought skins store "~1<hash>").
export { expandImg } from "@/lib/skin-img";

export function ExchangeView() {
  const { toast } = useToast();
  const { player: me } = useSession();
  const [all, setAll] = useState<CatalogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [stockError, setStockError] = useState<string | null>(null);
  const [fetchedAt, setFetchedAt] = useState<number | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<CatKey>("all");
  const [weapon, setWeapon] = useState("all");
  const [rarity, setRarity] = useState("all");
  const [sort, setSort] = useState("price-asc");
  const [page, setPage] = useState(1);
  const countRef = useRef<HTMLParagraphElement | null>(null); // pagination scroll anchor
  const [favsOnly, setFavsOnly] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  // the wallet: signed-in players run on the DATABASE balance
  const localBalance = useCaseStore((s) => s.balance);
  const inventory = useCaseStore((s) => s.inventory);
  const exchangeItem = useCaseStore((s) => s.exchangeItem);
  const setServerInventory = useCaseStore((s) => s.setServerInventory);
  const balance = me ? me.balance : localBalance;

  // USER SPEC (Task 25): IN CART marks — the assetids THIS caller already
  // took. The server answers with the signed-in player's OWN takes (`owned`
  // in /api/steam-exchange — nobody else's); the local inventory store is the
  // live mirror the TopBar keeps synced (buys prepend, sells remove, realtime
  // pushes reconcile other devices). Merge: a take shows while the player
  // actually HOLDS the skin — selling it back drops the mark at once, and a
  // just-bought skin is marked instantly even before the next poll.
  const [serverOwned, setServerOwned] = useState<Set<string>>(() => new Set());
  const ownedIds = useMemo(() => {
    const localSteam = new Set<string>();
    for (const it of inventory) {
      const id = String((it as { id?: string }).id ?? "");
      if (id.startsWith("steam:")) localSteam.add(id);
    }
    const out = new Set<string>();
    if (me) {
      // server-known takes MINUS anything already sold back (absent from the
      // local mirror = the row is gone — the mark must not outlive the skin)
      for (const id of serverOwned) if (localSteam.has(id)) out.add(id);
    }
    for (const id of localSteam) out.add(id); // guests + fresh buys
    return out;
  }, [serverOwned, inventory, me]);

  // favorites (persisted per profile / guest bucket)
  const favsMap = useAuthStore((s) => s.favs);
  const currentUser = useAuthStore((s) => s.current);
  const toggleFav = useAuthStore((s) => s.toggleFav);
  const favKey = currentUser?.toLowerCase() ?? GUEST_FAVS_KEY;
  const myFavs = useMemo(() => new Set(favsMap[favKey] ?? []), [favsMap, favKey]);

  const onToggleFav = useCallback(
    (id: string) => {
      toggleFav(id);
      sfx.click();
    },
    [toggleFav]
  );

  // any filter change jumps back to the first page
  const applyFilter = useCallback(
    (setter: (v: string) => void) => (v: string) => {
      setter(v);
      setPage(1);
    },
    []
  );
  const onQuery = useCallback((v: string) => {
    setQuery(v);
    setPage(1);
  }, []);
  const onCategory = useCallback((v: string) => {
    setCat(v as CatKey);
    setWeapon("all"); // switching category resets the weapon sub-filter
    setPage(1);
  }, []);

  // ---- LIVE STEAM STOCK feed + 5-MINUTE SYNC (USER SPEC): the page reads
  // the persisted catalog (/api/steam-exchange) and re-reads it every 5
  // minutes, in step with the server's own sync timer. `sync=1` asks the
  // server for an EXTRA sync pass right now (the SYNC NOW button) — a plain
  // read never blocks on Steam. A failed sync keeps the last catalog. ----
  const loadStock = useCallback(async (mode: "initial" | "poll" | "force" = "initial") => {
    if (mode === "initial") setLoading(true);
    else setSyncing(true);
    try {
      const r = await fetch(mode === "force" ? "/api/steam-exchange?sync=1" : "/api/steam-exchange", { cache: "no-store" });
      const data = (await r.json().catch(() => ({}))) as {
        ok?: boolean;
        error?: string;
        syncedAt?: number;
        fetchedAt?: number;
        owned?: string[];
        items?: CatalogEntry[];
      };
      if (r.ok && data.ok && Array.isArray(data.items)) {
        setAll(data.items);
        setFetchedAt(data.syncedAt ?? data.fetchedAt ?? Date.now());
        if (data.owned) setServerOwned(new Set(data.owned)); // THIS caller's takes
        setStockError(null);
      } else {
        setStockError(data.error ?? "The Steam inventory is unreachable right now");
      }
    } catch {
      setStockError("The Steam inventory is unreachable right now");
    } finally {
      setLoading(false);
      setSyncing(false);
    }
  }, []);

  useEffect(() => {
    void loadStock("initial");
  }, [loadStock]);

  // USER SPEC (Task 24): the 5-minute SYNC — this open page refreshes its
  // list on the same cadence as the server timer.
  useEffect(() => {
    const t = setInterval(() => void loadStock("poll"), SYNC_POLL_MS);
    return () => clearInterval(t);
  }, [loadStock]);

  // ticks the "synced X ago" label
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(t);
  }, []);

  const syncedLabel = fetchedAt
    ? now - fetchedAt < 90_000
      ? "just now"
      : `${Math.max(1, Math.floor((now - fetchedAt) / 60_000))} min ago`
    : null;

  const counts = useMemo(() => {
    const c: Record<string, number> = {
      all: all.length,
      knives: 0,
      gloves: 0,
      rifles: 0,
      pistols: 0,
      smgs: 0,
      heavy: 0,
      zeus: 0,
      agents: 0,
      stickers: 0,
      charms: 0,
      patches: 0,
    };
    for (const s of all) if (s.cat && c[s.cat] !== undefined) c[s.cat]++;
    return c;
  }, [all]);

  const weaponOptions = WEAPON_CLASS[cat]?.items ?? [];
  const weaponClassLabel = WEAPON_CLASS[cat]?.label ?? "";

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = all;
    if (favsOnly) list = list.filter((s) => myFavs.has(s.id));
    if (cat !== "all") list = list.filter((s) => s.cat === cat);
    if (q) list = list.filter((s) => s.n.toLowerCase().includes(q));
    if (weapon !== "all" && WEAPON_CATS.has(cat)) list = list.filter((s) => s.w === weapon);
    if (rarity !== "all") list = list.filter((s) => s.r === rarity);
    list = [...list];
    switch (sort) {
      case "price-desc":
        list.sort((a, b) => b.v - a.v);
        break;
      case "name":
        list.sort((a, b) => a.n.localeCompare(b.n));
        break;
      case "rarity":
        list.sort((a, b) => (RARITY_ORDER[a.r] ?? 9) - (RARITY_ORDER[b.r] ?? 9) || b.v - a.v);
        break;
      default:
        list.sort((a, b) => a.v - b.v); // price-asc — cheapest grabs first
    }
    return list;
  }, [all, query, cat, weapon, rarity, sort, favsOnly, myFavs]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages); // filters can shrink the book
  const goToPage = useCallback(
    (p: number) => {
      const next = Math.min(Math.max(1, p), totalPages);
      if (next === currentPage) return;
      setPage(next);
      sfx.click();
      requestAnimationFrame(() => countRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }));
    },
    [currentPage, totalPages]
  );

  /** THE exchange — DB coins for signed-in players, local wallet for guests.
   *  LIVE STOCK: the client picks an ASSET ("steam:<assetid>"), never a price
   *  — the server resolves the price for that exact item and stamps it sold. */
  const onExchange = useCallback(
    async (entry: CatalogEntry) => {
      if (busyId) return;
      setBusyId(entry.id);
      sfx.click();
      // the price the toast + shortfall checks show — the SERVER still decides
      const shownV = entry.v;
      try {
        if (me) {
          // SERVER economy: the client picks an ITEM, never a price — the
          // server charges its own resolution and stores the skin in the DB.
          const r = await fetch("/api/inventory", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ entryId: entry.id }),
          });
          const data = (await r.json().catch(() => ({}))) as {
            balance?: number;
            item?: InvItem;
            error?: string;
          };
          if (!r.ok || typeof data.balance !== "number" || !data.item) {
            toast({
              title: r.status === 410 ? "This item just left the stock" : "Not enough funds",
              description:
                r.status === 410 ? (
                  "Someone exchanged it a moment ago — refresh the stock."
                ) : (
                  <>
                    You are <Coin /> {formatCoins(Math.max(1, shownV - me.balance))} short
                  </>
                ),
              variant: "destructive",
            });
            sfx.error();
            return;
          }
          // uid = the DB row id — sells send it back and the server validates it
          setServerInventory([data.item as InvItem, ...useCaseStore.getState().inventory]);
          toast({
            title: `${entry.name} is yours!`,
            description: (
              <>
                Exchanged for <Coin /> {formatCoins(shownV)} — delivered to your INVENTORY
              </>
            ),
          });
          sfx.win();
          // USER SPEC (Task 24): the tile STAYS on the shelf — only the
          // 5-minute SYNC decides what the list holds.
        } else {
          // local wallet — same flow, no database behind it
          const ok = exchangeItem({
            id: entry.id,
            n: entry.name,
            w: entry.w,
            r: entry.r,
            p: entry.p,
            v: shownV,
            img: expandImg(entry.img),
            ...(entry.est ? { est: 1 } : {}),
            ...(entry.t ? { t: entry.t } : {}),
            ...(entry.cat ? { cat: entry.cat } : {}),
            ...(entry.a ? { a: entry.a } : {}),
            ...(entry.wearLabel ? { wear: entry.wearLabel } : {}),
          } as Omit<InvItem, "uid" | "at">);
          if (!ok) {
            toast({
              title: "Not enough funds",
              description: (
                <>
                  You are <Coin /> {formatCoins(Math.max(1, shownV - balance))} short
                </>
              ),
              variant: "destructive",
            });
            sfx.error();
            return;
          }
          toast({
            title: `${entry.name} is yours!`,
            description: (
              <>
                Exchanged for <Coin /> {formatCoins(shownV)} — delivered to your INVENTORY
              </>
            ),
          });
          sfx.win();
          // USER SPEC (Task 24): the tile STAYS on the shelf — only the
          // 5-minute SYNC decides what the list holds.
        }
      } catch {
        toast({ title: "The exchange failed", description: "Check your connection and try again.", variant: "destructive" });
        sfx.error();
      } finally {
        setBusyId(null);
      }
    },
    [busyId, me, balance, exchangeItem, setServerInventory, toast]
  );

  return (
    <SiteShell>
      <main className="relative min-h-screen pb-20" aria-label="Skin Exchange">
        <InventoryDrawer />

        <div className="relative mx-auto max-w-7xl px-4 pt-10">
          {/* hero — USER SPEC (Task 90): icon art + description paragraph are
              GONE, the title stands alone */}
          <div className="text-center">
            <h1 className="font-display text-4xl font-black tracking-wide text-white md:text-5xl">
              SKIN <span className="text-gradient-neon">EXCHANGE</span>
            </h1>
            {/* LIVE STEAM STOCK strip — what this page lists and how fresh it is */}
            <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
              <span
                className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/25 bg-emerald-400/10 px-3 py-1 text-[11px] font-bold tracking-wide text-emerald-200"
                role="status"
              >
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-300 opacity-60" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                LIVE STEAM STOCK
                {!loading && all.length > 0 && ` · ${all.length.toLocaleString()} items`}
                {syncedLabel && ` · synced ${syncedLabel}`}
                {/* USER SPEC (Task 24): the automatic 5-minute SYNC badge */}
                <span className="ml-1 rounded-full bg-emerald-400/15 px-2 py-px text-[10px] font-black tracking-widest text-emerald-300">
                  AUTO SYNC · 5 MIN
                </span>
              </span>
              <button
                onClick={() => void loadStock("force")}
                disabled={syncing}
                aria-label="Sync with the Steam inventory now"
                className={cn(
                  "font-display rounded-full border px-3 py-1 text-[11px] font-black tracking-wide transition-all",
                  syncing
                    ? "cursor-default border-white/10 bg-black/40 text-white/30"
                    : "border-white/15 bg-black/40 text-white/60 hover:border-emerald-300/40 hover:text-emerald-200"
                )}
              >
                {syncing ? "SYNCING…" : "SYNC NOW"}
              </button>
            </div>
          </div>

          {/* stock outage strip — the last good list stays browsable */}
          {stockError && !loading && (
            <div
              className="mx-auto mt-4 flex max-w-2xl flex-wrap items-center justify-between gap-2 rounded-xl border border-red-400/30 bg-red-500/10 px-4 py-2.5"
              role="alert"
            >
              <p className="text-xs font-bold text-red-200">Steam stock error: {stockError} — showing the last synced list.</p>
              <button
                onClick={() => void loadStock("force")}
                disabled={syncing}
                className="font-display rounded-md border border-red-300/40 bg-red-500/20 px-2.5 py-1 text-[11px] font-black text-red-100 transition-colors hover:bg-red-500/35"
              >
                RETRY
              </button>
            </div>
          )}

          {/* controls */}
          <div className="mx-auto mt-8 flex max-w-5xl flex-col gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 md:flex-row md:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/35" />
              <Input
                value={query}
                onChange={(e) => onQuery(e.target.value)}
                placeholder={`Search ${all.length.toLocaleString()} items in stock — try “Asiimov”, “Fade”…`}
                className="border-white/10 bg-black/40 pl-9 text-sm text-white/85 placeholder:text-white/30"
                aria-label="Search items"
              />
            </div>
            <div className="grid grid-cols-2 gap-3 md:flex">
              <button
                onClick={() => {
                  setFavsOnly((v) => !v);
                  setPage(1);
                  sfx.click();
                }}
                aria-pressed={favsOnly}
                className={cn(
                  "flex items-center justify-center gap-1.5 rounded-md border px-3 text-xs font-bold transition-all",
                  favsOnly
                    ? "border-amber-300/60 bg-amber-400/20 text-amber-200 shadow-[0_0_14px_rgba(240,185,11,0.35)]"
                    : "border-white/10 bg-black/40 text-white/70 hover:bg-white/5 hover:text-white"
                )}
              >
                <Star className="h-3.5 w-3.5" fill={favsOnly ? "currentColor" : "none"} />
                Favorites ({myFavs.size})
              </button>
              <Select value={cat} onValueChange={onCategory}>
                <SelectTrigger className="border-white/10 bg-black/40 text-xs text-white/85 md:w-40" aria-label="Filter by category">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent className="max-h-80 border-white/10 bg-[#150e26]">
                  {CATEGORY_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                      {o.value !== "all" && (
                        <span className="ml-1 text-white/40">{counts[o.value]}</span>
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {WEAPON_CATS.has(cat) && (
                <Select value={weapon} onValueChange={applyFilter(setWeapon)}>
                  <SelectTrigger className="border-white/10 bg-black/40 text-xs text-white/85 md:w-40" aria-label="Filter by weapon">
                    <SelectValue placeholder="Weapon" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72 border-white/10 bg-[#150e26]">
                    <SelectItem value="all">All {weaponClassLabel}</SelectItem>
                    {weaponOptions.map((w) => (
                      <SelectItem key={w.value} value={w.value}>
                        {w.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Select value={rarity} onValueChange={applyFilter(setRarity)}>
                <SelectTrigger className="border-white/10 bg-black/40 text-xs text-white/85 md:w-36" aria-label="Filter by rarity">
                  <SelectValue placeholder="Rarity" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#150e26]">
                  {RARITY_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={sort} onValueChange={applyFilter(setSort)}>
                <SelectTrigger className="border-white/10 bg-black/40 text-xs text-white/85 md:w-40" aria-label="Sort skins">
                  <SelectValue placeholder="Sort" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#150e26]">
                  <SelectItem value="price-asc">Price: low → high</SelectItem>
                  <SelectItem value="price-desc">Price: high → low</SelectItem>
                  <SelectItem value="rarity">Rarity</SelectItem>
                  <SelectItem value="name">Name A–Z</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* result count — shows which page of the catalog is on screen */}
          <p
            ref={countRef}
            className="mt-4 scroll-mt-24 text-center text-xs font-bold tracking-wide text-white/40"
          >
            {loading
              ? "Syncing the Steam inventory…"
              : `${filtered.length.toLocaleString()} items${query || cat !== "all" || weapon !== "all" || rarity !== "all" ? " found" : " in stock"} · Page ${currentPage} of ${totalPages}`}
          </p>

          {/* grid — one PAGE of results (Task 91: paginated, no load-more) */}
          {!loading && filtered.length === 0 ? (
            <div className="mt-5 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-14 text-center">
              {favsOnly ? <Star className="mx-auto mb-3 h-10 w-10 text-white/25" /> : <Search className="mx-auto mb-3 h-10 w-10 text-white/25" />}
              <p className="text-sm font-bold text-white/60">
                {favsOnly
                  ? "No favorites yet"
                  : all.length === 0
                    ? "The Steam inventory is currently empty"
                    : "No items match your filters"}
              </p>
              <p className="mt-1 text-xs text-white/40">
                {favsOnly
                  ? "Tap the ★ on any item below to pin it here — favorites are saved to your profile."
                  : all.length === 0
                    ? "The stock syncs with the Steam inventory automatically every 5 minutes."
                    : "Try a different search, category or rarity."}
              </p>
            </div>
          ) : (
            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
              {filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE).map((s) => (
                <ExchangeTile
                  key={s.id}
                  entry={s}
                  balance={balance}
                  busy={busyId === s.id}
                  isFav={myFavs.has(s.id)}
                  inCart={ownedIds.has(s.id)}
                  onToggleFav={onToggleFav}
                  onExchange={(e) => void onExchange(e)}
                />
              ))}
            </div>
          )}

          {/* pagination — USER SPEC (Task 91): numbered page bar (1 2 3 4 5 …)
              at the bottom of the site instead of the old LOAD MORE */}
          {!loading && totalPages > 1 && (
            <nav className="mt-8 flex flex-wrap items-center justify-center gap-1.5" aria-label="Exchange pages">
              <PageButton ariaLabel="First page" onClick={() => goToPage(1)} disabled={currentPage === 1}>
                <ChevronsLeft className="h-4 w-4" />
              </PageButton>
              <PageButton ariaLabel="Previous page" onClick={() => goToPage(currentPage - 1)} disabled={currentPage === 1}>
                <ChevronLeft className="h-4 w-4" />
              </PageButton>
              {pageWindow(totalPages, currentPage).map((it, i) =>
                it === "gap" ? (
                  <span key={`gap-${i}`} className="grid h-9 w-6 place-items-center text-xs font-black text-white/30" aria-hidden>
                    …
                  </span>
                ) : (
                  <PageButton key={it} ariaLabel={`Page ${it}`} active={it === currentPage} onClick={() => goToPage(it)}>
                    {it}
                  </PageButton>
                )
              )}
              <PageButton ariaLabel="Next page" onClick={() => goToPage(currentPage + 1)} disabled={currentPage === totalPages}>
                <ChevronRight className="h-4 w-4" />
              </PageButton>
              <PageButton ariaLabel="Last page" onClick={() => goToPage(totalPages)} disabled={currentPage === totalPages}>
                <ChevronsRight className="h-4 w-4" />
              </PageButton>
            </nav>
          )}

          {/* back */}
          <div className="mt-12 text-center">
            <Link
              href="/#cases"
              className="inline-flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-bold text-white/50 transition-colors hover:text-white"
            >
              <ChevronLeft className="h-4 w-4" />
              Back to Cases
            </Link>
          </div>
        </div>
      </main>
    </SiteShell>
  );
}
