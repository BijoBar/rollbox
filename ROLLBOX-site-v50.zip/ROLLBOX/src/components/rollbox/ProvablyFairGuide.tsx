"use client";

import Link from "next/link";
import {
  ArrowRight,
  BadgeCheck,
  Copy,
  Dices,
  FileQuestion,
  Hash,
  KeyRound,
  Lock,
  ShieldCheck,
  Swords,
  Terminal,
  TrendingUp,
  TriangleAlert,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ===== USER SPEC (Task 177): the "HOW TO USE" page =====
   The PROVABLY FAIR screen gained a link that lands here — a detailed,
   anyone-can-follow walkthrough of HOW to actually verify your drops: which
   values exist, where each one lives on the site, what exactly to copy and
   paste WHERE, and how to double-check the site from the outside. ===== */

const STEPS = [
  {
    n: 1,
    icon: KeyRound,
    title: "Save your proof BEFORE you play",
    body: [
      "Open the PROVABLY FAIR page and switch to the SEED SETTINGS tab. Two values live here and they are YOUR proof anchor: the PUBLIC HASH and the CLIENT SEED.",
      "Press the copy button next to the PUBLIC HASH and save it anywhere (notes, chat, email). Do the same for the CLIENT SEED. The Public Hash is the site's commitment: it is a SHA-256 fingerprint of the hidden Server Seed + a secret Salt, generated BEFORE any of your rolls — the site cannot change the seed later without the hash stop matching.",
      "Want extra control? Press CHANGE SEED and type your own Client Seed (any text you like). Every roll then mixes YOUR string into the outcome — neither side alone can pick the result.",
    ],
  },
  {
    n: 2,
    icon: Dices,
    title: "Play — every roll burns a numbered nonce",
    body: [
      "Open cases, battles or the upgrader as usual. Each opening is decided by the formula Roll = HMAC-SHA256(Server Seed, Client Seed:Nonce) — the Nonce is a counter that grows by 1 with every roll, so every single opening gets its own unique, reproducible outcome.",
      "The SERVER ROLLS tab lists your real-money rolls with their verification data: the case, the nonce that decided it and the float. Battles use one nonce pair per seat (a ROLLDROP gate + the weighted draw), the upgrader wins when float < chance.",
      "Nothing here needs trust — the exact numbers that decided your drop are written down for you while the round happens.",
    ],
  },
  {
    n: 3,
    icon: Lock,
    title: "Reveal the hidden seed",
    body: [
      "When you want to verify, go back to SEED SETTINGS and press ROTATE & REVEAL. The old Server Seed and its secret Salt become visible in the REVEALED SEEDS list, and a fresh seed pair takes over for your future rolls.",
      "This is the commit–reveal moment: the seed you are now seeing was locked by the Public Hash you saved in step 1 the whole time. The site could never swap it — the hash would break.",
    ],
  },
  {
    n: 4,
    icon: BadgeCheck,
    title: "Recompute your drop in CHECK ROLL",
    body: [
      "Open the CHECK ROLL tab. Copy each value into its exact field:",
    ],
    checklist: [
      { what: "The revealed SERVER SEED (from REVEALED SEEDS, step 3)", where: "SERVER SEED field" },
      { what: "The SECRET SALT shown under it", where: "SECRET SALT field" },
      { what: "Your CLIENT SEED (the one active when you rolled, step 1)", where: "CLIENT SEED field" },
      { what: "The roll's NONCE from its history row (step 2)", where: "NONCE field" },
      { what: "The same CASE the roll opened", where: "the case picker" },
    ],
    body2: [
      "Press CHECK. The page recomputes HMAC-SHA256(Server Seed, Client Seed:Nonce), derives the float and maps it onto the case's published drop table — the resulting skin and float must match the history row EXACTLY, to the last character.",
    ],
  },
  {
    n: 5,
    icon: Terminal,
    title: "Verify outside the site (optional, bulletproof)",
    body: [
      "You don't even need our page to be honest. Paste this into any terminal (replace the CAPS with your own values) — the first line must print exactly the Public Hash you saved:",
    ],
    code: `# 1) the commitment — must equal the Public Hash from step 1
printf '%s' 'SERVER_SEEDSALT_HERE' | sha256sum

# 2) the roll — take the first 8 hex chars of the output
printf '%s' 'CLIENT_SEED:NONCE' \\
  | openssl dgst -SHA256 -mac HMAC -macopt hexkey:$(echo -n 'SERVER_SEED' | xxd -p -c 64)`,
    body2: [
      "Take the first 8 hex characters of the HMAC output, convert them from hexadecimal to a decimal number and divide by 4,294,967,296 (2^32) — that number in [0,1) is the float. Multiply it by the case's total weight and walk the published drop table, subtracting each item's weight: the item where the counter hits zero is EXACTLY the skin you received.",
    ],
  },
];

export function ProvablyFairGuide() {
  return (
    <main className="relative min-h-screen pb-20" aria-label="Provably Fair — how to use">
      <div className="relative mx-auto max-w-4xl px-4 pt-10">
        {/* ===== hero ===== */}
        <div className="text-center">
          <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl border border-emerald-400/30 bg-emerald-400/10 shadow-[0_0_36px_rgba(52,211,153,0.25)]">
            <ShieldCheck className="h-9 w-9 text-emerald-400" />
          </span>
          <h1 className="font-display text-4xl font-black tracking-wide text-white md:text-5xl">
            HOW TO <span className="text-gradient-neon">USE</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-white/60 md:text-base">
            A complete, step-by-step guide to verifying your own drops: what each value means,
            where it lives on ROLLBOX, what exactly to copy and paste where — and how to check
            the math from the outside, so anyone can prove every result to themselves.
          </p>
          <Link
            href="/provably-fair"
            className="mt-5 inline-flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-black uppercase tracking-widest text-white/70 transition-colors hover:bg-white/10 hover:text-white"
          >
            Back to the Provably Fair tools
          </Link>
        </div>

        {/* ===== the four ingredients ===== */}
        <div className="mt-10 grid gap-3 sm:grid-cols-2">
          {[
            {
              icon: Hash,
              name: "PUBLIC HASH",
              what: "SHA-256(Server Seed + Secret Salt), shown BEFORE any roll. The site's unbreakable promise that the seed exists and never changes.",
            },
            {
              icon: KeyRound,
              name: "CLIENT SEED",
              what: "YOUR string. You can set it to anything — every roll mixes it in, so the outcome is decided together, not by the server alone.",
            },
            {
              icon: Dices,
              name: "NONCE",
              what: "A counter that grows with every roll (1, 2, 3…). Each opening gets a unique Client Seed:Nonce pair — a unique, reproducible outcome.",
            },
            {
              icon: Lock,
              name: "SERVER SEED + SALT",
              what: "The hidden pair locked by the Public Hash. Revealed the moment you press ROTATE & REVEAL — then everything becomes checkable.",
            },
          ].map((c) => (
            <div key={c.name} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
              <p className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-emerald-300">
                <c.icon className="h-4 w-4" />
                {c.name}
              </p>
              <p className="mt-2 text-[13px] leading-relaxed text-white/60">{c.what}</p>
            </div>
          ))}
        </div>

        {/* ===== the steps ===== */}
        <div className="mt-10 space-y-5">
          {STEPS.map((s) => (
            <section
              key={s.n}
              className="overflow-hidden rounded-2xl border border-white/10 bg-[#0b0716]/90"
              aria-label={`Step ${s.n}: ${s.title}`}
            >
              <div className="flex items-center gap-3 border-b border-white/10 bg-white/[0.03] px-5 py-3.5">
                <span className="font-display grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-emerald-400/15 text-base font-black text-emerald-300">
                  {s.n}
                </span>
                <h2 className="font-display flex items-center gap-2 text-base font-black tracking-wide text-white sm:text-lg">
                  <s.icon className="h-4.5 w-4.5 shrink-0 text-emerald-400" />
                  {s.title}
                </h2>
              </div>
              <div className="space-y-2.5 px-5 py-4">
                {(s.body ?? []).map((p, i) => (
                  <p key={i} className="text-[13px] leading-relaxed text-white/65">
                    {p}
                  </p>
                ))}
                {s.checklist && (
                  <ul className="my-3 space-y-1.5 rounded-xl border border-white/10 bg-black/30 p-3">
                    {s.checklist.map((c) => (
                      <li key={c.what} className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[12.5px] leading-relaxed">
                        <Copy className="h-3 w-3 shrink-0 text-amber-300/80" />
                        <span className="text-white/75">{c.what}</span>
                        <ArrowRight className="h-3 w-3 shrink-0 text-white/30" />
                        <span className="font-black text-emerald-300">{c.where}</span>
                      </li>
                    ))}
                  </ul>
                )}
                {(s.body2 ?? []).map((p, i) => (
                  <p key={i} className="text-[13px] leading-relaxed text-white/65">
                    {p}
                  </p>
                ))}
                {s.code && (
                  <pre
                    className="mt-2 overflow-x-auto rounded-xl border border-white/10 bg-black/50 p-3.5 font-mono text-[11.5px] leading-relaxed text-emerald-100/85"
                    dir="ltr"
                  >
                    {s.code}
                  </pre>
                )}
              </div>
            </section>
          ))}
        </div>

        {/* ===== the exact math ===== */}
        <div className="mt-10 overflow-x-auto rounded-2xl border border-white/10 bg-[#0b0716] p-5" dir="ltr">
          <p className="font-display text-xs font-black uppercase tracking-widest text-white/50">The exact algorithm</p>
          <pre className="mt-3 font-mono text-[12px] leading-relaxed text-white/70 md:text-[13px]">
{`PublicHash = SHA-256(ServerSeed + SecretSalt)          // committed BEFORE any roll
Roll       = HMAC-SHA256(ServerSeed, ClientSeed + ":" + Nonce)
Float      = first 32 bits of Roll / 2^32               // a number in [0, 1)
Outcome    = walk the case's published drop table:      // the ONE canonical mapping
             acc = Float x totalWeight
             item where (acc - weight) first hits <= 0`}
          </pre>
          <p className="mt-3 text-[11px] leading-relaxed text-white/40">
            Battles: seat s of round r uses nonce pair 2·(r·seats+s) for the ROLLDROP gate and
            2·(r·seats+s)+1 for the weighted draw. Upgrader: the spin wins when Float &lt;
            0.95 / multiplier, and the prize is the catalog skin closest to stake × multiplier.
          </p>
        </div>

        {/* ===== FAQ ===== */}
        <div className="mt-10 grid gap-3 sm:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-white/70">
              <FileQuestion className="h-4 w-4 text-amber-300" />
              What does a match prove?
            </p>
            <p className="mt-2 text-[13px] leading-relaxed text-white/60">
              That the drop you received is the one the commitment predicted: the seed was fixed
              before you pressed the button (hash matches), the nonce is the one history shows,
              and the mapping follows the published odds — nothing was re-rolled or tilted.
            </p>
          </div>
          <div className="rounded-2xl border border-red-500/20 bg-red-500/[0.04] p-4">
            <p className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-red-300">
              <TriangleAlert className="h-4 w-4" />
              What if something does NOT match?
            </p>
            <p className="mt-2 text-[13px] leading-relaxed text-white/60">
              Double-check you copied the FULL server seed and salt (not the short display form)
              and the right nonce. Still off? Screenshot the CHECK ROLL result and open the
              support chat — the "?" button bottom-right — our agents will re-run it with you.
            </p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-white/70">
              <Swords className="h-4 w-4 text-amber-300" />
              Can I verify battles too?
            </p>
            <p className="mt-2 text-[13px] leading-relaxed text-white/60">
              Yes — every seat's pull in a battle is rolled through the same seed chain with its
              own nonce pair, and the roll history rows carry everything needed to recompute them.
            </p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-white/70">
              <TrendingUp className="h-4 w-4 text-amber-300" />
              And upgrader spins?
            </p>
            <p className="mt-2 text-[13px] leading-relaxed text-white/60">
              The upgrader's win rule is pure math on the same float: win if Float &lt; 0.95 ÷
              multiplier. The history row shows the stake, multiplier and the granted skin — all
              recomputable in CHECK ROLL once the seed is revealed.
            </p>
          </div>
        </div>

        <div className={cn("mt-10 text-center")}>
          <Link
            href="/provably-fair"
            className="neon-btn inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-white"
          >
            <ShieldCheck className="h-4 w-4" />
            Open the verification tools
          </Link>
        </div>
      </div>
    </main>
  );
}
