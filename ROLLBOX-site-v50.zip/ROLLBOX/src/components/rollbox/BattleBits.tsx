"use client";

import { Bot, User } from "lucide-react";
import { playerColor, type BattlePlayer } from "@/lib/battles";
import { SKINS } from "@/lib/cases";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";

const shortSkinName = (name: string) => {
  const cut = name.includes("|") ? name.split("|")[1].trim() : name;
  return cut.length > 18 ? cut.slice(0, 17) + "…" : cut;
};

/** Compact drop chip used in battle summaries — gold ring on ROLLDROP pulls. */
export function SkinChip({ skinId, value, rd = false }: { skinId: string; value: number; rd?: boolean }) {
  const skin = SKINS[skinId];
  return (
    <span
      className={cn(
        "flex items-center gap-1.5 rounded-lg border px-2 py-1",
        rd ? "border-amber-300/60 bg-amber-300/[0.08]" : "border-white/10 bg-black/30"
      )}
      title={skin ? `${skin.name}${rd ? " — ROLLDROP rare draw" : ""}` : skinId}
    >
      {skin && (
        <span
          className="h-5 w-9 shrink-0 rounded"
          style={{
            background: `linear-gradient(135deg, ${skin.colors[0]}33, ${skin.colors[1]}22)`,
            border: `1px solid ${skin.colors[0]}55`,
          }}
          aria-hidden="true"
        />
      )}
      <span className="max-w-[120px] truncate text-[10px] font-bold text-white/70">
        {skin ? shortSkinName(skin.name) : skinId}
      </span>
      <span className={cn("text-[10px] font-black", rd ? "text-amber-300" : "text-white/45")}>
        <Coin /> {value}
      </span>
    </span>
  );
}

/** Round avatar chip used in battle seats and lobby cards — ring + fill in the player's battle color. */
export function PlayerAvatar({
  player,
  size = "md",
  className,
}: {
  player: BattlePlayer;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const dim = size === "sm" ? "h-7 w-7 text-[10px]" : size === "lg" ? "h-12 w-12 text-sm" : "h-9 w-9 text-xs";
  const initials = player.name.replace(/[^a-zA-Z0-9]/g, "").slice(0, 2).toUpperCase() || "PL";
  const color = playerColor(player);
  // USER SPEC (Task 55/56): a real profile picture (Steam) renders as
  // the avatar itself — the initials disc stays as the fallback for players
  // without one (bots + local legacy players)
  if (player.avatar) {
    return (
      <span
        className={cn("block shrink-0 overflow-hidden rounded-full border-2", dim, className)}
        style={{ borderColor: color, boxShadow: `0 0 10px ${color}33` }}
        title={player.name}
      >
        <img src={player.avatar} alt={player.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
      </span>
    );
  }
  return (
    <span
      className={cn(
        "font-display grid shrink-0 place-items-center rounded-full border-2 font-black",
        dim,
        className
      )}
      style={{
        borderColor: color,
        background: `linear-gradient(145deg, ${color}38, ${color}14)`,
        color: "#fff",
        boxShadow: `0 0 10px ${color}33`,
      }}
      title={player.name}
    >
      {player.isBot ? <Bot className={size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4"} /> : initials}
    </span>
  );
}

/** Empty seat placeholder. */
export function EmptySeat({ label, size = "md" }: { label: string; size?: "sm" | "md" | "lg" }) {
  const dim = size === "lg" ? "h-12 w-12" : size === "sm" ? "h-7 w-7" : "h-9 w-9";
  return (
    <span className={cn("grid shrink-0 place-items-center rounded-full border border-dashed border-white/20 bg-white/[0.03] text-white/30", dim)}>
      <User className={size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4"} />
      <span className="sr-only">{label}</span>
    </span>
  );
}
