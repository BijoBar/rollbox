"use client";

import { cn } from "@/lib/utils";

/**
 * Stylized glowing crate art per case tier.
 * Open lid + light beam + neon edges + sparkles. ViewBox 200x170.
 *
 * lidState:
 *  - "open"    (default) — classic art, lid tilted back + light beam (Hero/cards/case page hero)
 *  - "closed"  — lid drawn shut on top of the crate, no beam (on-deck reel showcase)
 *  - "opening" — the shut lid collapses at the hinge and swings open, beam bursts out
 */
export function CaseArt({
  color,
  color2,
  className,
  lidState = "open",
}: {
  color: string;
  color2: string;
  className?: string;
  lidState?: "open" | "closed" | "opening";
}) {
  const opening = lidState === "opening";
  const shut = lidState === "closed";
  return (
    <svg
      viewBox="0 0 200 170"
      className={cn(className, opening && "ca-lid-anim")}
      role="img"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`ca-front-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2a2044" />
          <stop offset="100%" stopColor="#120c22" />
        </linearGradient>
        <linearGradient id={`ca-lid-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3a2d5e" />
          <stop offset="100%" stopColor="#1d1436" />
        </linearGradient>
        <linearGradient id={`ca-beam-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.85" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
        <linearGradient id={`ca-edge-${color.replace("#", "")}`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={color} />
          <stop offset="100%" stopColor={color2} />
        </linearGradient>
      </defs>

      {/* light beam from open lid — hidden while the crate is shut, bursts out on opening */}
      <polygon
        className="ca-beam"
        points="70,52 130,52 152,10 48,10"
        fill={`url(#ca-beam-${color.replace("#", "")})`}
        opacity={shut ? 0 : 0.5}
      />

      {/* shut lid — flat slab resting on the crate mouth; collapses into the hinge on opening */}
      {(shut || opening) && (
        <g className="ca-lid-slab">
          <path d="M48 54 L152 54 L156 44 L44 44 Z" fill={`url(#ca-lid-${color.replace("#", "")})`} stroke={color} strokeWidth="1.6" />
          <path d="M44 44 L156 44 L157 40 L43 40 Z" fill={color2} opacity="0.65" />
        </g>
      )}

      {/* open lid (tilted back) — static in the classic art; swings up from the hinge on opening */}
      {(lidState === "open" || opening) && (
        <g className="ca-lid-back">
          <path d="M52 54 L148 54 L158 30 L62 30 Z" fill={`url(#ca-lid-${color.replace("#", "")})`} stroke={color} strokeWidth="1.6" />
          <path d="M62 30 L158 30 L160 24 L64 24 Z" fill={color2} opacity="0.65" />
        </g>
      )}

      {/* body */}
      <g>
        <rect x="48" y="54" width="104" height="86" rx="7" fill={`url(#ca-front-${color.replace("#", "")})`} stroke={color} strokeWidth="2" />
        {/* inner neon frame */}
        <rect x="58" y="64" width="84" height="66" rx="5" fill="none" stroke={color} strokeWidth="1" opacity="0.5" />
        {/* side vents */}
        <g stroke={color2} strokeWidth="2" opacity="0.55">
          <line x1="58" y1="128" x2="66" y2="128" />
          <line x1="58" y1="122" x2="68" y2="122" />
        </g>
        {/* lock */}
        <circle cx="100" cy="97" r="13" fill="#0d0819" stroke={color} strokeWidth="2" />
        <circle cx="100" cy="97" r="5.5" fill="none" stroke={color2} strokeWidth="2" />
        <line x1="100" y1="97" x2="100" y2="105" stroke={color2} strokeWidth="2" strokeLinecap="round" />
        {/* corner rivets */}
        <g fill={color} opacity="0.8">
          <circle cx="52" cy="58" r="2" />
          <circle cx="148" cy="58" r="2" />
          <circle cx="52" cy="136" r="2" />
          <circle cx="148" cy="136" r="2" />
        </g>
        {/* bottom edge glow */}
        <rect x="48" y="136" width="104" height="4" rx="2" fill={`url(#ca-edge-${color.replace("#", "")})`} opacity="0.9" />
      </g>

      {/* sparkles */}
      <g fill="#fff">
        <path d="M40 40 l1.6 4 4 1.6 -4 1.6 -1.6 4 -1.6 -4 -4 -1.6 4 -1.6 Z" opacity="0.9">
          <animate attributeName="opacity" values="0.9;0.2;0.9" dur="2.4s" repeatCount="indefinite" />
        </path>
        <path d="M164 70 l1.2 3 3 1.2 -3 1.2 -1.2 3 -1.2 -3 -3 -1.2 3 -1.2 Z" opacity="0.7">
          <animate attributeName="opacity" values="0.2;0.9;0.2" dur="3s" repeatCount="indefinite" />
        </path>
        <path d="M158 122 l1.2 3 3 1.2 -3 1.2 -1.2 3 -1.2 -3 -3 -1.2 3 -1.2 Z" opacity="0.6">
          <animate attributeName="opacity" values="0.6;0.15;0.6" dur="2.7s" repeatCount="indefinite" />
        </path>
        <path d="M34 96 l1.2 3 3 1.2 -3 1.2 -1.2 3 -1.2 -3 -3 -1.2 3 -1.2 Z" opacity="0.5">
          <animate attributeName="opacity" values="0.5;0.1;0.5" dur="3.3s" repeatCount="indefinite" />
        </path>
      </g>
    </svg>
  );
}
