"use client";

import { Fragment, useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, Check, ChevronRight, RotateCcw, Store, TerminalSquare } from "lucide-react";
import { formatCoins, RARITY_META, SKINS, type WeaponKind } from "@/lib/cases";
import { wearColorOf, wearShortOf } from "@/lib/wear";
import { TERMINALS, DEALER_LINES, type TerminalDef } from "@/lib/terminals";
import { useSession } from "@/lib/session";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";
import { SkinImage } from "./SkinImage";

/* ===== USER SPEC (Task 24 + 25 + 26 + 27): the TERMINAL page redesign =====
   · this page ALONE gets a DARK-GRAY screen #1f1f1f (LiveDrops + footer
     hidden, body painted while mounted); NO page header — the device IS the
     page, sized to fill most of the viewport
   · dealer selection happens ON the terminal device image (terminal.webp);
     the device's top bar carries a CHANGE DEALER button (back arrow)
   · inside the device screen: the chosen dealer's photo on the RIGHT,
     bottom-LEFT a numbers-only input clamped to HIS min/max deal
     (1/10/30/70/300 — 50/100/500/1000/5000) and a GREEN PAY NOW button
   · Task 27 flow: the dealer WRITES the sales pitch FIRST (its own chat
     bubble, typed out char by char) and only then puts the product on the
     table — ACCEPT takes the skin, REFUSE brings the next pitch (up to 5;
     refused offers + pitches STAY in the chat history). An early ACCEPT
     makes the dealer reveal the offers the player never saw (MISSED cards +
     THE BIG ONE highlight) and a verdict line — did he take the best? The
     LAST offer closes ITSELF: no buttons, it auto-approves into the
     inventory. After a settled deal the pay row becomes ANOTHER DEAL.
   · server engine unchanged: 5 distinct offers, one atomic claim */

interface Offer {
  id: string;
  n: string;
  w: string;
  r: string;
  v: number;
  img?: string | null; // Task 29: baked Steam render (inventory snapshots carry it)
  wear?: string; // R43: exterior shown on the offer card (absent -> default FT)
}

type Phase = "select" | "deal";
/* Task 27 chat machine: dots (dealer thinks) → pitch (typewriter) → skin
   (product on the table) → after an early ACCEPT: reveal → done */
type Stage = "idle" | "dots" | "pitch" | "skin" | "reveal" | "done";

/* the dark screen rect inside terminal.webp, measured off the source PNG
   (2400x1759 -> screen x 334..2096, y 270..1384; inset a hair for bezels) */
const SCREEN = { left: "13.95%", top: "15.55%", width: "73.1%", height: "62.9%" };
const GRAY = "#1f1f1f";
/* terminal.webp is 1280x938 — device width from the viewport height so the
   tablet fills most of the screen without scrolling (no page header since
   Task 26, so only the top bar + chips reserve) */
const DEVICE_RATIO = 1280 / 938;
const DEVICE_MAX = `min(96rem, calc((100dvh - 10rem) * ${DEVICE_RATIO.toFixed(4)}))`;
const PCT_CHIPS = [25, 50, 75, 100];

/* the dealer's sales pitch — Task 27: typed as its OWN bubble BEFORE the
   product shows (first the line, then the goods) */
const PITCHES = [
  "Clean copy, low float — this one moves fast.",
  "Just came in this morning. Someone's already asking about it.",
  "Look at that finish. Photos don't do it justice.",
  "Good piece for a quick flip. You won't regret it.",
  "Straight from a solid collection. Trust me on this one.",
  "Fair price, clean history. Deals like this don't wait.",
  "Letting it go cheap — I need the shelf space.",
  "That pattern right there? Rare. Take a good look.",
  "My supplier gave me a one-time price on this.",
  "You walked in lucky today. This is the sign.",
  "It's clean, it's hot, and it's yours for the taking.",
  "I don't show this to everyone. Consider it a favor.",
];
const FINAL_PITCH = "Last one. After this I'm closing the terminal.";
const pickPitch = (playId: string, i: number) =>
  PITCHES[(playId.charCodeAt(2) + playId.charCodeAt(5) + i * 13) % PITCHES.length];
const pitchText = (playId: string, i: number, isFinal: boolean) =>
  isFinal ? FINAL_PITCH : pickPitch(playId, i);

export function TerminalView() {
  const mounted = useMounted();
  const { player: me, refresh } = useSession();
  const { toast } = useToast();

  const [phase, setPhase] = useState<Phase>("select");
  const [dealer, setDealer] = useState<TerminalDef | null>(null);
  const [amount, setAmount] = useState("");
  const [playing, setPlaying] = useState(false);

  // one play = pitch FIRST, then the product (Task 27 machine)
  const [play, setPlay] = useState<{ playId: string; dealerName: string; amount: number; offers: Offer[] } | null>(null);
  const [stage, setStage] = useState<Stage>("idle");
  const [pitchIdx, setPitchIdx] = useState(0); // pitch bubbles started
  const [typed, setTyped] = useState(0); // chars typed in the current pitch
  const [skinCount, setSkinCount] = useState(0); // sequential cards on the table
  const [missedCount, setMissedCount] = useState(0); // post-accept reveals
  const [refused, setRefused] = useState<number[]>([]);
  const [chosen, setChosen] = useState<number | null>(null);
  const [claiming, setClaiming] = useState(false);
  const [autoFailed, setAutoFailed] = useState(false); // final auto-claim needs a manual retry
  const [verdict, setVerdict] = useState<{ took: number; best: number } | null>(null);
  const [showPool, setShowPool] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);
  const timersRef = useRef<number[]>([]);

  // the GRAY SCREEN — paint the body gray for as long as this page lives
  useEffect(() => {
    const prev = document.body.style.backgroundColor;
    document.body.style.backgroundColor = GRAY;
    return () => {
      document.body.style.backgroundColor = prev;
    };
  }, []);

  useEffect(
    () => () => {
      timersRef.current.forEach((t) => window.clearTimeout(t));
    },
    [],
  );

  // keep the newest chat message in view inside the device screen
  useEffect(() => {
    chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight });
  }, [play, stage, pitchIdx, typed, skinCount, missedCount, verdict]);

  const resetDealChat = useCallback(() => {
    setStage("idle");
    setPitchIdx(0);
    setTyped(0);
    setSkinCount(0);
    setMissedCount(0);
    setRefused([]);
    setChosen(null);
    setClaiming(false);
    setAutoFailed(false);
    setVerdict(null);
  }, []);

  // Task 27: claim an offer (atomic server-side). index === last → the deal
  // is done; an EARLY claim flips to "reveal" so the dealer shows the offers
  // the player never saw. auto = the last offer closing itself (a failure
  // leaves the ACCEPT button on the final card for a manual retry).
  const doClaim = useCallback(
    async (index: number, auto: boolean) => {
      if (!play || chosen !== null || claiming) return;
      setClaiming(true);
      try {
        const r = await fetch("/api/terminal/claim", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ playId: play.playId, index }),
        });
        const d = (await r.json()) as { ok?: boolean; item?: Offer & { uid: string }; error?: string };
        if (!r.ok || !d.ok) throw new Error(d.error ?? "The deal fell through");
        setChosen(index);
        sfx.coins();
        toast({ title: `${d.item?.n ?? "Skin"} is yours` });
        if (index < play.offers.length - 1) {
          setMissedCount(0);
          setStage("reveal");
        } else {
          setAutoFailed(false);
          setStage("done");
        }
      } catch (e) {
        if (auto) setAutoFailed(true);
        toast({ title: e instanceof Error ? e.message : "Could not approve the offer" });
      } finally {
        setClaiming(false);
      }
    },
    [play, chosen, claiming, toast],
  );

  // Task 27 machine · stage "dots": the dealer thinks, then the pitch bubble starts
  useEffect(() => {
    if (stage !== "dots") return;
    const t = window.setTimeout(() => {
      setPitchIdx((n) => n + 1);
      setTyped(0);
      setStage("pitch");
    }, pitchIdx === 0 && skinCount === 0 ? 600 : 500);
    timersRef.current.push(t);
    return () => window.clearTimeout(t);
  }, [stage, pitchIdx, skinCount]);

  // Task 27 machine · stage "pitch": the sales pitch types out char by char —
  // ONLY when the line is finished does the product land on the table
  useEffect(() => {
    if (stage !== "pitch" || !play || pitchIdx === 0) return;
    const text = pitchText(play.playId, pitchIdx - 1, pitchIdx - 1 === play.offers.length - 1);
    if (typed < text.length) {
      const t = window.setTimeout(() => setTyped((n) => n + 1), 20);
      timersRef.current.push(t);
      return () => window.clearTimeout(t);
    }
    const t = window.setTimeout(() => {
      setSkinCount((n) => n + 1);
      setStage("skin");
      sfx.click();
    }, 450);
    timersRef.current.push(t);
    return () => window.clearTimeout(t);
  }, [stage, play, pitchIdx, typed]);

  // Task 27: the LAST offer closes ITSELF — no buttons; the skin auto-approves
  // into the inventory a beat after the card lands
  useEffect(() => {
    if (stage !== "skin" || !play || chosen !== null || claiming || autoFailed) return;
    if (skinCount !== play.offers.length) return;
    const t = window.setTimeout(() => void doClaim(play.offers.length - 1, true), 1300);
    timersRef.current.push(t);
    return () => window.clearTimeout(t);
  }, [stage, play, skinCount, chosen, claiming, autoFailed, doClaim]);

  // Task 27 machine · stage "reveal": staggered reveal of the unseen offers,
  // then the verdict bubble (did the player take the best of the five?)
  useEffect(() => {
    if (stage !== "reveal" || !play) return;
    const unseen = play.offers.length - skinCount;
    if (missedCount < unseen) {
      const t = window.setTimeout(() => {
        setMissedCount((n) => n + 1);
        sfx.click();
      }, 500);
      timersRef.current.push(t);
      return () => window.clearTimeout(t);
    }
    const t = window.setTimeout(() => {
      const best = play.offers.reduce((bi, o, i, a) => (o.v > a[bi].v ? i : bi), 0);
      setVerdict({ took: chosen ?? 0, best });
      setStage("done");
    }, 450);
    timersRef.current.push(t);
    return () => window.clearTimeout(t);
  }, [stage, play, skinCount, missedCount, chosen]);

  const startPlay = useCallback(async () => {
    if (!dealer || playing) return;
    const min = dealer.min ?? 1;
    const value = Number(amount);
    if (!Number.isFinite(value) || value < min) {
      toast({ title: `${dealer.name}'s minimum deal is ${formatCoins(min)}` });
      return;
    }
    if (value > dealer.max) {
      toast({ title: `${dealer.name}'s max deal is ${formatCoins(dealer.max)}` });
      return;
    }
    setPlaying(true);
    try {
      const r = await fetch("/api/terminal/play", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dealerId: dealer.id, amount: value }),
      });
      const d = (await r.json()) as { playId?: string; offers?: Offer[]; amount?: number; dealerName?: string; error?: string };
      if (!r.ok || !d.playId || !d.offers) throw new Error(d.error ?? "The dealer walked away — try again");
      setPlay({ playId: d.playId, dealerName: d.dealerName ?? dealer.name, amount: d.amount ?? value, offers: d.offers });
      resetDealChat();
      setStage("dots"); // the dealer starts talking: dots → pitch → skin
      setShowPool(false);
      sfx.click();
      void refresh();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Could not reach the dealer" });
    } finally {
      setPlaying(false);
    }
  }, [dealer, amount, playing, toast, refresh, resetDealChat]);

  const clampAmount = (d: TerminalDef) => {
    const min = d.min ?? 1;
    const v = Number(amount);
    const clamped = !Number.isFinite(v) ? min : Math.min(d.max, Math.max(min, v));
    setAmount(String(Math.round(clamped * 100) / 100));
  };

  // Task 27: REFUSE keeps the offer + its pitch in the chat and brings the
  // dealer's NEXT pitch (the 5th carries no refuse — it closes itself)
  const refuse = () => {
    if (!play || stage !== "skin" || chosen !== null || claiming) return;
    if (skinCount === 0 || skinCount >= play.offers.length) return;
    sfx.click();
    setRefused((r) => [...r, skinCount - 1]);
    setStage("dots");
  };

  const accept = (index: number) => void doClaim(index, false);

  const openDealer = (d: TerminalDef) => {
    sfx.click();
    setDealer(d);
    setAmount(String(d.min ?? 1));
    setPlay(null);
    resetDealChat();
    setPhase("deal");
  };

  const backToDealers = () => {
    sfx.click();
    setPhase("select");
    setDealer(null);
    setPlay(null);
    resetDealChat();
    setShowPool(false);
  };

  const newDeal = () => {
    sfx.click();
    setPlay(null);
    resetDealChat();
  };

  // ---------- gates (gray, minimal) ----------
  if (!mounted) {
    return (
      <SiteShell plain>
        <div className="min-h-[calc(100vh-4rem)] bg-[#1f1f1f]">
          <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center" aria-label="Terminal">
            <div className="h-10 w-10 animate-spin rounded-full border-2 border-white/20 border-t-emerald-300" />
          </main>
        </div>
      </SiteShell>
    );
  }

  if (!me) {
    return (
      <SiteShell plain>
        <div className="min-h-[calc(100vh-4rem)] bg-[#1f1f1f]">
          <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4" aria-label="Terminal">
            <div className="w-full max-w-md rounded-2xl border border-white/10 bg-[#101418]/90 p-8 text-center shadow-[0_25px_50px_rgba(0,0,0,0.35)]">
              <TerminalSquare className="mx-auto mb-3 h-10 w-10 text-emerald-400/70" />
              <h1 className="font-display text-xl font-black text-white">The Terminal</h1>
              <p className="mt-2 text-sm text-white/55">Sign in with Steam to trade with the dealers.</p>
              <Link href="/login" className="neon-btn mt-5 inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-white">
                Sign In
              </Link>
            </div>
          </main>
        </div>
      </SiteShell>
    );
  }

  const introLine = dealer ? (DEALER_LINES[dealer.id] ?? DEALER_LINES.danny) : [];
  const intro = introLine.length ? introLine[Math.floor(play ? (play.playId.charCodeAt(2) + play.playId.charCodeAt(5)) % introLine.length : 0)] : "";

  return (
    <SiteShell plain>
      <div className="min-h-[calc(100vh-4rem)] bg-[#1f1f1f] pb-4" aria-label="Terminal">
        {/* USER SPEC Task 26: NO page header — the terminal IS the page */}
        <div className="relative mx-auto max-w-[1600px] px-2 pt-3 sm:px-4 sm:pt-4">
          {/* ===== THE TERMINAL DEVICE (persistent through both steps) —
               sized to fill most of the viewport ===== */}
          <div className="relative mx-auto mt-3 w-full sm:mt-4" style={{ maxWidth: DEVICE_MAX }}>
            <img
              src="/terminal/terminal.webp"
              alt="Terminal"
              draggable={false}
              className="w-full select-none drop-shadow-[0_25px_45px_rgba(0,0,0,0.6)]"
            />

            {/* ---- the screen ---- */}
            <div className="absolute" style={SCREEN}>
              <div className="flex h-full w-full flex-col overflow-hidden rounded-[5px] bg-[#0b0e12] p-[1.5%] text-white shadow-[inset_0_0_45px_rgba(0,0,0,0.9)] sm:rounded-[10px]">
                {/* top status bar */}
                <div className="flex shrink-0 items-center justify-between gap-2 border-b border-white/10 px-[2%] pb-[1.4%]">
                  {phase === "select" ? (
                    <span className="font-display truncate text-[9px] font-black tracking-widest text-emerald-300 sm:text-xs md:text-sm" dir="ltr">
                      ROLLBOX TERMINAL v2.4
                    </span>
                  ) : (
                    <span className="flex min-w-0 items-center gap-1.5 sm:gap-2">
                      {/* USER SPEC Task 26: CHANGE DEALER (back arrow) lives ON the terminal */}
                      <button
                        type="button"
                        onClick={backToDealers}
                        className="flex shrink-0 items-center gap-1 rounded border border-white/15 bg-white/[0.06] px-1.5 py-0.5 text-white/70 transition-colors hover:border-emerald-400/50 hover:text-emerald-300 sm:rounded-md sm:px-2 sm:py-1"
                        aria-label="Change dealer"
                        dir="ltr"
                      >
                        <ArrowLeft className="h-2.5 w-2.5 sm:h-3 sm:w-3" />
                        <span className="font-display text-[6.5px] font-black uppercase tracking-widest sm:text-[8px] md:text-[9px]">Change dealer</span>
                      </button>
                      <span className="relative flex h-1.5 w-1.5 shrink-0 sm:h-2 sm:w-2">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400 sm:h-2 sm:w-2" />
                      </span>
                      <span className="font-display truncate text-[9px] font-black tracking-widest text-emerald-300 sm:text-xs" dir="ltr">
                        {dealer?.name} — ONLINE
                      </span>
                    </span>
                  )}
                  <span className="font-display flex shrink-0 items-center gap-1 text-[8px] font-black text-amber-300 tabular-nums sm:text-[11px] md:text-[13px]" dir="ltr">
                    {play && dealer ? (
                      <>
                        DEAL <Coin className="h-2.5 w-2.5 sm:h-3 sm:w-3" /> {formatCoins(play.amount)}
                      </>
                    ) : (
                      <>
                        <Coin className="h-2.5 w-2.5 sm:h-3 sm:w-3" /> {formatCoins(me.balance)}
                      </>
                    )}
                  </span>
                </div>

                {/* ===== step 1: SELECT YOUR DEALER (on the device) ===== */}
                {phase === "select" && (
                  <div className="flex min-h-0 flex-1 flex-col px-[2%] pt-[1.5%]">
                    <p className="font-display shrink-0 text-center text-[7px] font-black uppercase tracking-[0.2em] text-white/45 sm:text-[10px] md:text-[12px]" dir="ltr">
                      Select your dealer
                    </p>
                    <div className="mt-[1%] min-h-0 flex-1 space-y-[1.4%] overflow-y-auto pr-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:space-y-[1.8%]">
                      {TERMINALS.map((d) => (
                        <button
                          key={d.id}
                          type="button"
                          onClick={() => openDealer(d)}
                          className="group flex w-full items-center gap-1.5 rounded border border-white/10 bg-white/[0.04] px-[2.5%] py-[1.1%] text-left transition-colors hover:border-emerald-400/50 hover:bg-emerald-500/10 sm:gap-3 sm:rounded-lg sm:px-[3%] sm:py-[1.7%]"
                        >
                          <span className="h-4 w-4 shrink-0 overflow-hidden rounded-full border border-white/15 bg-black/50 sm:h-7 sm:w-7">
                            {d.img ? (
                              <img src={d.img} alt="" className="h-full w-full object-cover object-top" loading="lazy" />
                            ) : (
                              <span className="font-display grid h-full w-full place-items-center text-[8px] font-black text-emerald-300 sm:text-[10px]" dir="ltr">
                                {d.name.charAt(0)}
                              </span>
                            )}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="font-display block truncate text-[9px] font-black text-white sm:text-[13px] md:text-[16px]" dir="ltr">
                              {d.name}
                            </span>
                            <span className="hidden truncate text-[9px] font-semibold text-white/40 md:block md:text-[11px]" dir="ltr">
                              {d.subtitle ?? ""}
                            </span>
                          </span>
                          <span className="flex shrink-0 items-center gap-0.5 rounded border border-amber-300/40 bg-amber-400/10 px-1 py-0.5 text-[7px] font-black text-amber-300 tabular-nums sm:gap-1 sm:px-1.5 sm:text-[10px] md:text-[12px]" dir="ltr">
                            <Coin className="h-1.5 w-1.5 sm:h-2.5 sm:w-2.5 md:h-3 md:w-3" /> MIN {formatCoins(d.min)}
                          </span>
                          <ChevronRight className="h-2.5 w-2.5 shrink-0 text-white/30 transition-colors group-hover:text-emerald-300 sm:h-4 sm:w-4 md:h-5 md:w-5" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* ===== step 2: THE DEAL — photo right / chat + pay left ===== */}
                {phase === "deal" && dealer && (
                  <div className="flex min-h-0 flex-1 gap-[2.5%] px-[2%] pt-[2%]">
                    {/* left column: chat + pay row */}
                    <div className="flex min-w-0 flex-1 flex-col">
                      {/* chat */}
                      <div ref={chatRef} className="min-h-0 flex-1 space-y-[3%] overflow-y-auto pr-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                        <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="max-w-[92%] rounded-md rounded-bl-sm border border-emerald-500/25 bg-emerald-500/10 px-[3.5%] py-[2%] sm:rounded-lg">
                          <p className="text-[7.5px] font-semibold leading-relaxed text-emerald-100/90 sm:text-[10px] md:text-[13px]" dir="ltr">
                            {intro || `Welcome. I'm ${dealer.name}.`}
                          </p>
                        </motion.div>

                        {!play && (
                          <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.35 }} className="max-w-[92%] rounded-md rounded-bl-sm border border-white/10 bg-white/[0.04] px-[3.5%] py-[2%] sm:rounded-lg">
                            <p className="text-[7.5px] font-semibold leading-relaxed text-white/60 sm:text-[10px] md:text-[13px]" dir="ltr">
                              MIN <span className="font-black text-amber-300">{formatCoins(dealer.min)}</span> — MAX <span className="font-black text-amber-300">{formatCoins(dealer.max)}</span>. Type your deal and hit PAY NOW. I&apos;ll pitch you 5 skins, one at a time — ACCEPT when it feels right, or REFUSE. The last one closes the deal on its own.
                            </p>
                          </motion.div>
                        )}

                        {/* ===== Task 27 chat machine =====
                            per offer: PITCH bubble first (typewriter on the
                            newest one), then the product card. Refused cards
                            keep their pitch in the history forever. */}
                        {play &&
                          play.offers.slice(0, pitchIdx).map((o, i) => {
                            const rar = RARITY_META[o.r as keyof typeof RARITY_META];
                            const isChosen = chosen === i;
                            const isRefused = refused.includes(i);
                            const isCurrent = chosen === null && !isRefused && stage === "skin" && i === skinCount - 1;
                            const isFinal = i === play.offers.length - 1;
                            const onTable = i < skinCount;
                            const isTyping = stage === "pitch" && i === pitchIdx - 1;
                            const isBigOne = verdict !== null && verdict.best === i && verdict.took !== verdict.best;
                            return (
                              <Fragment key={`${play.playId}-${i}`}>
                                {/* the pitch comes FIRST — the dealer writes the
                                    line, and only then puts the product down */}
                                <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="max-w-[92%] rounded-md rounded-bl-sm border border-emerald-500/25 bg-emerald-500/10 px-[3.5%] py-[2%] sm:rounded-lg">
                                  <p className="text-[7.5px] italic leading-relaxed text-emerald-100/85 sm:text-[10px] md:text-[13px]" dir="ltr">
                                    {isFinal && <span className="font-black uppercase not-italic tracking-widest text-amber-300">Final offer — </span>}
                                    {isTyping ? (
                                      <>
                                        {pitchText(play.playId, i, isFinal).slice(0, typed)}
                                        <span className="ml-0.5 inline-block h-[0.85em] w-[0.45em] animate-pulse bg-emerald-300/80 align-middle" aria-hidden="true" />
                                      </>
                                    ) : (
                                      pitchText(play.playId, i, isFinal)
                                    )}
                                  </p>
                                </motion.div>

                                {onTable && (
                                  <motion.div
                                    initial={{ opacity: 0, y: 6 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className={cn(
                                      "rounded-md rounded-bl-sm border px-[3%] py-[2%] transition-colors sm:rounded-lg",
                                      isChosen
                                        ? "border-emerald-400/70 bg-emerald-500/15 shadow-[0_0_16px_rgba(52,211,153,0.3)]"
                                        : isBigOne
                                          ? "border-amber-300/60 bg-amber-400/10"
                                          : isRefused
                                            ? "border-white/10 bg-white/[0.02] opacity-40"
                                            : "border-white/15 bg-white/[0.05]",
                                    )}
                                  >
                                    <div className="flex items-center gap-1.5 sm:gap-2">
                                      <span
                                        className="h-7 w-9 shrink-0 overflow-hidden rounded border border-white/10 sm:h-10 sm:w-14 sm:rounded-md md:h-14 md:w-20"
                                        style={{ background: `radial-gradient(ellipse at 50% 120%, ${(rar?.color ?? "#8882a8") + "55"}, #0b0813 70%)` }}
                                      >
                                        <SkinImage skinId={o.id} kind={o.w as WeaponKind} colors={[(rar?.color ?? "#8882a8"), "#14101f"]} className="h-full w-full object-contain" />
                                      </span>
                                      <span className="min-w-0 flex-1">
                                        <span className="block truncate text-[7.5px] font-black text-white/90 sm:text-[10px] md:text-[13px]" dir="ltr">
                                          {o.n}
                                        </span>
                                        {/* R43 USER SPEC: the offer's exterior — ALWAYS listed, in its color.
                                            The dealers' pool is base-priced, so skins without a pinned
                                            exterior read as the default one (Field-Tested). */}
                                        <span
                                          className="block text-[7px] font-black uppercase tracking-wider sm:text-[9px] md:text-[10px]"
                                          dir="ltr"
                                          style={{ color: wearColorOf(o.wear) }}
                                          title={`Exterior: ${o.wear ?? "Field-Tested"}`}
                                        >
                                          {o.wear ?? "Field-Tested"}
                                        </span>
                                        <span className="block text-[7px] font-bold text-white/45 sm:text-[9px] md:text-[11px]" dir="ltr">
                                          value{" "}
                                          <span className="font-black text-amber-300">
                                            <Coin className="mr-0.5 inline h-2 w-2 sm:h-2.5 sm:w-2.5" />
                                            {formatCoins(o.v)}
                                          </span>
                                        </span>
                                      </span>
                                      {isChosen ? (
                                        <span className="flex shrink-0 items-center gap-0.5 rounded border border-emerald-400/60 bg-emerald-500/20 px-1.5 py-1 text-[7px] font-black uppercase tracking-widest text-emerald-200 sm:px-2 sm:text-[8px] md:text-[10px]" dir="ltr">
                                          <Check className="h-2.5 w-2.5 sm:h-3 sm:w-3 md:h-4 md:w-4" /> deal
                                        </span>
                                      ) : isBigOne ? (
                                        <span className="shrink-0 rounded border border-amber-300/60 bg-amber-400/15 px-1.5 py-1 text-[7px] font-black uppercase tracking-widest text-amber-200 sm:px-2 sm:text-[8px] md:text-[10px]" dir="ltr">
                                          the big one
                                        </span>
                                      ) : isRefused ? (
                                        <span className="shrink-0 rounded border border-white/10 px-1.5 py-1 text-[7px] font-black uppercase tracking-widest text-white/30 sm:px-2 sm:text-[8px] md:text-[10px]" dir="ltr">
                                          refused
                                        </span>
                                      ) : isCurrent ? (
                                        isFinal ? (
                                          // the last offer closes ITSELF — no
                                          // buttons, just the countdown chip
                                          <span className="shrink-0 animate-pulse rounded border border-amber-300/50 bg-amber-400/10 px-1.5 py-1 text-[7px] font-black uppercase tracking-widest text-amber-200 sm:px-2 sm:text-[8px] md:text-[10px]" dir="ltr">
                                            {claiming ? "…" : "closing"}
                                          </span>
                                        ) : (
                                          <span className="flex shrink-0 flex-col items-stretch gap-0.5">
                                            <button
                                              type="button"
                                              disabled={claiming}
                                              onClick={() => accept(i)}
                                              className="rounded border border-emerald-400/50 bg-emerald-500/15 px-2 py-1 text-[7px] font-black uppercase tracking-widest text-emerald-200 transition-colors hover:bg-emerald-500/30 disabled:opacity-40 sm:px-2.5 sm:text-[8px] md:px-3 md:text-[10px]"
                                              dir="ltr"
                                            >
                                              {claiming ? "…" : "accept"}
                                            </button>
                                            <button
                                              type="button"
                                              disabled={claiming}
                                              onClick={refuse}
                                              className="rounded border border-white/15 bg-white/[0.04] px-2 py-1 text-[7px] font-black uppercase tracking-widest text-white/55 transition-colors hover:border-red-400/50 hover:text-red-300 disabled:opacity-40 sm:px-2.5 sm:text-[8px] md:px-3 md:text-[10px]"
                                              dir="ltr"
                                            >
                                              refuse
                                            </button>
                                          </span>
                                        )
                                      ) : null}
                                    </div>
                                  </motion.div>
                                )}
                              </Fragment>
                            );
                          })}

                        {/* the dealer is thinking about his next line */}
                        {play && stage === "dots" && (
                          <div className="flex items-center gap-1 px-1 text-emerald-300/60" aria-hidden="true">
                            <span className="h-1 w-1 animate-bounce rounded-full bg-current [animation-delay:0ms]" />
                            <span className="h-1 w-1 animate-bounce rounded-full bg-current [animation-delay:150ms]" />
                            <span className="h-1 w-1 animate-bounce rounded-full bg-current [animation-delay:300ms]" />
                          </div>
                        )}

                        {/* Task 27: after an EARLY accept the dealer lifts the
                            counter and reveals the offers the player never saw */}
                        {play && chosen !== null && chosen < play.offers.length - 1 && (stage === "reveal" || stage === "done") && (
                          <>
                            <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="max-w-[92%] rounded-md rounded-bl-sm border border-emerald-500/25 bg-emerald-500/10 px-[3.5%] py-[2%] sm:rounded-lg">
                              <p className="text-[7.5px] font-semibold leading-relaxed text-emerald-100/90 sm:text-[10px] md:text-[13px]" dir="ltr">
                                For the record — here&apos;s what I still had behind the counter:
                              </p>
                            </motion.div>
                            {play.offers.slice(skinCount, skinCount + missedCount).map((o, k) => {
                              const idx = skinCount + k;
                              const rar = RARITY_META[o.r as keyof typeof RARITY_META];
                              const isBigOne = verdict !== null && verdict.best === idx && verdict.took !== verdict.best;
                              return (
                                <motion.div
                                  key={`${play.playId}-m${idx}`}
                                  initial={{ opacity: 0, y: 6 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  className={cn(
                                    "rounded-md rounded-bl-sm border px-[3%] py-[2%] sm:rounded-lg",
                                    isBigOne ? "border-amber-300/60 bg-amber-400/10" : "border-white/10 bg-white/[0.03] opacity-75",
                                  )}
                                >
                                  <div className="flex items-center gap-1.5 sm:gap-2">
                                    <span
                                      className="h-7 w-9 shrink-0 overflow-hidden rounded border border-white/10 sm:h-10 sm:w-14 sm:rounded-md md:h-14 md:w-20"
                                      style={{ background: `radial-gradient(ellipse at 50% 120%, ${(rar?.color ?? "#8882a8") + "55"}, #0b0813 70%)` }}
                                    >
                                      <SkinImage skinId={o.id} kind={o.w as WeaponKind} colors={[(rar?.color ?? "#8882a8"), "#14101f"]} className="h-full w-full object-contain" />
                                    </span>
                                    <span className="min-w-0 flex-1">
                                      <span className="block truncate text-[7.5px] font-black text-white/90 sm:text-[10px] md:text-[13px]" dir="ltr">
                                        {o.n}
                                      </span>
                                      {/* R43 USER SPEC: the missed offer's exterior — in its color */}
                                      <span
                                        className="block text-[7px] font-black uppercase tracking-wider sm:text-[9px] md:text-[10px]"
                                        dir="ltr"
                                        style={{ color: wearColorOf(o.wear) }}
                                        title={`Exterior: ${o.wear ?? "Field-Tested"}`}
                                      >
                                        {o.wear ?? "Field-Tested"}
                                      </span>
                                      <span className="block text-[7px] font-bold text-white/45 sm:text-[9px] md:text-[11px]" dir="ltr">
                                        value{" "}
                                        <span className="font-black text-amber-300">
                                          <Coin className="mr-0.5 inline h-2 w-2 sm:h-2.5 sm:w-2.5" />
                                          {formatCoins(o.v)}
                                        </span>
                                      </span>
                                    </span>
                                    {isBigOne ? (
                                      <span className="shrink-0 rounded border border-amber-300/60 bg-amber-400/15 px-1.5 py-1 text-[7px] font-black uppercase tracking-widest text-amber-200 sm:px-2 sm:text-[8px] md:text-[10px]" dir="ltr">
                                        the big one
                                      </span>
                                    ) : (
                                      <span className="shrink-0 rounded border border-white/10 px-1.5 py-1 text-[7px] font-black uppercase tracking-widest text-white/35 sm:px-2 sm:text-[8px] md:text-[10px]" dir="ltr">
                                        missed
                                      </span>
                                    )}
                                  </div>
                                </motion.div>
                              );
                            })}
                          </>
                        )}

                        {/* Task 27: the verdict — did the player take the best? */}
                        {play && stage === "done" && verdict && (
                          <motion.div
                            initial={{ opacity: 0, x: -8 }}
                            animate={{ opacity: 1, x: 0 }}
                            className={cn(
                              "max-w-[92%] rounded-md rounded-bl-sm border px-[3.5%] py-[2%] sm:rounded-lg",
                              verdict.took === verdict.best ? "border-emerald-400/50 bg-emerald-500/10" : "border-amber-400/30 bg-amber-400/10",
                            )}
                          >
                            <p className="text-[7.5px] font-semibold leading-relaxed sm:text-[10px] md:text-[13px]" dir="ltr">
                              {verdict.took === verdict.best ? (
                                <span className="text-emerald-100">
                                  Best one of the five — you called it right. That skin was worth{" "}
                                  <Coin className="inline h-2 w-2" /> {formatCoins(play.offers[verdict.best].v)}.
                                </span>
                              ) : verdict.best > verdict.took ? (
                                <span className="text-amber-100">
                                  The {play.offers[verdict.best].n} was still behind the counter —{" "}
                                  <Coin className="inline h-2 w-2" /> {formatCoins(play.offers[verdict.best].v)} versus your {formatCoins(play.offers[verdict.took].v)}.
                                </span>
                              ) : (
                                <span className="text-amber-100">
                                  You passed on the {play.offers[verdict.best].n} — that was the big one at{" "}
                                  <Coin className="inline h-2 w-2" /> {formatCoins(play.offers[verdict.best].v)}.
                                </span>
                              )}
                            </p>
                          </motion.div>
                        )}

                        {/* Task 27: the last offer closed itself — dealer signs off */}
                        {play && stage === "done" && !verdict && chosen !== null && (
                          <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="max-w-[92%] rounded-md rounded-bl-sm border border-emerald-500/25 bg-emerald-500/10 px-[3.5%] py-[2%] sm:rounded-lg">
                            <p className="text-[7.5px] font-semibold leading-relaxed text-emerald-100/90 sm:text-[10px] md:text-[13px]" dir="ltr">
                              Closed — the last one goes straight to your inventory. Pleasure doing business.
                            </p>
                          </motion.div>
                        )}
                      </div>

                      {/* bottom-LEFT: the pay row (numbers only, min..max) */}
                      <div className="shrink-0 pt-[3%]">
                        <AnimatePresence mode="wait">
                          {!play ? (
                            <motion.div key="pay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-1 sm:gap-1.5">
                              <span className="flex h-6 min-w-0 flex-1 items-center gap-1 rounded border border-white/15 bg-black/50 px-1.5 focus-within:border-emerald-400/60 sm:h-8 sm:rounded-md sm:px-2">
                                <Coin className="h-2.5 w-2.5 shrink-0 sm:h-3.5 sm:w-3.5" />
                                <input
                                  value={amount}
                                  onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1"))}
                                  onBlur={() => clampAmount(dealer)}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") void startPlay();
                                  }}
                                  dir="ltr"
                                  inputMode="decimal"
                                  aria-label="Deal amount"
                                  placeholder={`${dealer.min}–${dealer.max}`}
                                  className="font-display w-full min-w-0 bg-transparent text-[9px] font-black text-amber-300 tabular-nums placeholder:text-white/25 focus:outline-none sm:text-[12px] md:text-[15px]"
                                />
                                <span className="hidden shrink-0 text-[7px] font-bold text-white/30 sm:block" dir="ltr">
                                  {dealer.min}–{dealer.max}
                                </span>
                              </span>
                              {/* USER SPEC Task 25: green like the offers' APPROVE button */}
                              <button
                                type="button"
                                disabled={playing}
                                onClick={() => void startPlay()}
                                className="shrink-0 rounded-md border border-emerald-400/50 bg-emerald-500/15 px-2.5 py-1.5 text-[8px] font-black uppercase tracking-widest text-emerald-200 transition-colors hover:bg-emerald-500/30 disabled:opacity-40 sm:rounded-lg sm:px-4 sm:py-2 sm:text-[12px] md:px-5"
                                dir="ltr"
                              >
                                {playing ? "…" : "PAY NOW"}
                              </button>
                            </motion.div>
                          ) : stage !== "done" ? (
                            <motion.p
                              key="pick"
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className={cn(
                                "text-center text-[7.5px] font-black uppercase tracking-widest sm:text-[9px] md:text-[11px]",
                                stage === "skin" ? "text-amber-300/90" : "animate-pulse text-white/45",
                              )}
                              dir="ltr"
                            >
                              {stage === "dots"
                                ? "The dealer is typing…"
                                : stage === "pitch"
                                  ? "The dealer is talking…"
                                  : stage === "reveal"
                                    ? "Revealing what you missed…"
                                    : skinCount === play.offers.length
                                      ? "Last offer — closing the deal…"
                                      : `Offer ${skinCount} of ${play.offers.length} — accept it or refuse it`}
                            </motion.p>
                          ) : (
                            <motion.div key="done" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex justify-center">
                              {/* USER SPEC Task 26: ANOTHER DEAL replaces the "skin acquired" text */}
                              <button
                                type="button"
                                onClick={newDeal}
                                className="neon-btn flex items-center gap-1.5 rounded-lg px-4 py-1.5 text-[9px] font-black uppercase tracking-widest text-white sm:px-5 sm:text-[11px]"
                                dir="ltr"
                              >
                                <RotateCcw className="h-3 w-3 md:h-3.5 md:w-3.5" />
                                Another deal
                              </button>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </div>

                    {/* RIGHT: the chosen dealer's photo */}
                    <div className="relative w-[32%] shrink-0 overflow-hidden rounded-[4px] border border-white/10 sm:rounded-lg">
                      {dealer.img ? (
                        <img src={dealer.img} alt={dealer.name} className="absolute inset-0 h-full w-full object-cover object-top" />
                      ) : (
                        <span className="font-display grid h-full w-full place-items-center bg-gradient-to-br from-emerald-500/25 to-cyan-500/15 text-lg font-black text-emerald-200" dir="ltr">
                          {dealer.name.charAt(0)}
                        </span>
                      )}
                      <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent px-[6%] pb-[5%] pt-[12%]">
                        <span className="font-display block truncate text-[7.5px] font-black text-white sm:text-[10px] md:text-[13px]" dir="ltr">
                          {dealer.name}
                        </span>
                        <span className="block text-[6.5px] font-bold text-amber-300/90 sm:text-[8px] md:text-[10px]" dir="ltr">
                          MIN <Coin className="inline h-1.5 w-1.5 sm:h-2 sm:w-2" /> {formatCoins(dealer.min)} · MAX <Coin className="inline h-1.5 w-1.5 sm:h-2 sm:w-2" /> {formatCoins(dealer.max)}
                        </span>
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ===== helpers under the device (on the gray) ===== */}
          {phase === "deal" && dealer && !play && (
            <div className="mx-auto mt-4 flex max-w-4xl flex-wrap items-center justify-center gap-2">
              {PCT_CHIPS.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    sfx.click();
                    const v = Math.max(dealer.min ?? 1, Math.round(((dealer.max * p) / 100) * 100) / 100);
                    setAmount(String(v));
                  }}
                  className="h-8 rounded-lg border border-white/10 bg-white/[0.06] px-3 text-[11px] font-black text-white/80 transition-colors hover:bg-white/[0.14] hover:text-white"
                >
                  {p === 100 ? "MAX" : `${p}%`}
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  sfx.click();
                  setShowPool((v) => !v);
                }}
                className="flex h-8 items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.06] px-3 text-[10px] font-black uppercase tracking-widest text-emerald-200 transition-colors hover:bg-white/[0.14] hover:text-emerald-100"
              >
                <Store className="h-3.5 w-3.5" />
                {showPool ? "Hide" : "View"} skin pool
              </button>
            </div>
          )}

          {phase === "deal" && dealer && showPool && !play && (
            <div className="mx-auto mt-3 max-w-4xl rounded-2xl border border-white/10 bg-white/[0.04] p-3 shadow-[0_15px_30px_rgba(0,0,0,0.35)]">
              <div className="grid gap-1.5 sm:grid-cols-2">
                {dealer.skins.map((s, i) => (
                  <div key={`${s.id}-${i}`} className="flex items-center gap-2 rounded-lg border border-white/10 bg-black/30 px-2 py-1.5">
                    <span className="grid h-7 w-10 shrink-0 place-items-center overflow-hidden rounded-md bg-black/40">
                      <SkinImage skinId={s.id ?? "custom"} kind={(SKINS[s.id ?? ""]?.weapon ?? "ak") as WeaponKind} colors={[RARITY_META.milspec.color, "#14101f"]} className="h-6 w-8 object-contain" />
                    </span>
                    <span className="min-w-0 flex-1 truncate text-[11px] font-bold text-white/85" dir="ltr">
                      {s.n}
                    </span>
                    {/* R43 USER SPEC: the pool skin's exterior code — in its color */}
                    <span
                      className="shrink-0 text-[9px] font-black uppercase"
                      dir="ltr"
                      style={{ color: wearColorOf(null) }}
                      title="Exterior: Field-Tested"
                    >
                      {wearShortOf(null)}
                    </span>
                    <span className="shrink-0 text-[10px] font-black text-amber-300 tabular-nums" dir="ltr">
                      <Coin className="mr-0.5 inline h-2.5 w-2.5" />
                      {formatCoins(s.v)}
                    </span>
                    <span className="w-14 shrink-0 text-right text-[10px] font-black text-sky-300 tabular-nums" dir="ltr">
                      {s.p}%
                    </span>
                  </div>
                ))}
              </div>
              <p className="mt-2 text-[9px] font-semibold text-white/40">
                Pool prices are {dealer.name}&apos;s MAX deal — your offers scale with the amount you pay (MIN {formatCoins(dealer.min)}).
              </p>
            </div>
          )}

          {/* USER SPEC Task 26: the external ANOTHER DEAL / CHANGE DEALER row is
              gone — ANOTHER DEAL lives in the pay row, CHANGE DEALER in the
              device's top bar */}
        </div>
      </div>
    </SiteShell>
  );
}
