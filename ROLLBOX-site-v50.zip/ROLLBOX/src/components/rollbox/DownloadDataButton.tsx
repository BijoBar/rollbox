"use client";

// USER SPEC (Task 180): the one-click ZIP link becomes DOWNLOAD DATA — a
// password prompt stands before the package download. The owner's password
// unlocks a one-shot programmatic download of the same static package file;
// everything else about the delivery (identical md5 x3 copies, the layout
// anchor) is untouched. The prompt is a UI gate for the running site, not a
// secret: the package itself stays a public static asset.

import { useEffect, useRef, useState } from "react";
import { Lock } from "lucide-react";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";

const DOWNLOAD_PASSWORD = "1965560";

export function DownloadDataButton({ zipHref }: { zipHref: string }) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("");
  const [wrong, setWrong] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    window.addEventListener("keydown", onKey);
    const t = window.setTimeout(() => inputRef.current?.focus(), 60);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const close = () => {
    setOpen(false);
    setValue("");
    setWrong(false);
  };

  const submit = () => {
    if (value.trim() === DOWNLOAD_PASSWORD) {
      sfx.click();
      // fire the download exactly like the old direct link did
      const a = document.createElement("a");
      a.href = zipHref;
      a.download = "";
      document.body.appendChild(a);
      a.click();
      a.remove();
      close();
    } else {
      setWrong(true);
      sfx.error?.();
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => {
          sfx.click();
          setOpen(true);
        }}
        className="pointer-events-auto text-white/40 hover:text-white/80 underline underline-offset-2"
        title="Download the latest ROLLBOX site package"
      >
        DOWNLOAD DATA
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[9998] flex items-center justify-center bg-black/70 px-4 backdrop-blur-sm"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) close();
          }}
          role="dialog"
          aria-label="Download data — password required"
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
            className={cn(
              "w-full max-w-xs rounded-2xl border border-violet-500/30 bg-[#100a1e]/95 p-6 shadow-[0_0_50px_rgba(124,58,237,0.25)]",
              wrong && "upg-glitch",
            )}
          >
            <div className="mb-4 flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl border border-violet-400/40 bg-violet-500/10">
                <Lock className="h-4 w-4 text-violet-300" />
              </span>
              <div>
                <h2 className="font-display text-base font-black tracking-wide text-white">DOWNLOAD DATA</h2>
                <p className="text-[10px] font-semibold text-white/45">ROLLBOX site package (.zip)</p>
              </div>
            </div>

            <p className="mb-3 text-xs leading-relaxed text-white/55">
              Enter the download password to get the latest package.
            </p>

            <input
              ref={inputRef}
              type="password"
              inputMode="numeric"
              autoComplete="off"
              value={value}
              onChange={(e) => {
                setValue(e.target.value);
                setWrong(false);
              }}
              placeholder="Password"
              aria-label="Download password"
              className={cn(
                "h-11 w-full rounded-xl border bg-black/40 px-3.5 font-mono text-sm tracking-[0.3em] text-white placeholder:tracking-normal placeholder:text-white/25",
                "border-violet-500/30 outline-none transition-colors focus:border-violet-400/70",
                wrong && "border-red-500/60",
              )}
              dir="ltr"
            />

            {wrong && (
              <p role="alert" className="mt-2 text-[11px] font-bold text-red-300">
                Wrong password — try again.
              </p>
            )}

            <div className="mt-5 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  sfx.click();
                  close();
                }}
                className="h-10 rounded-xl border border-white/15 bg-white/5 text-xs font-black uppercase tracking-wider text-white/70 transition-colors hover:bg-white/10 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="h-10 rounded-xl border border-violet-400/40 bg-gradient-to-r from-violet-600/80 to-fuchsia-600/80 text-xs font-black uppercase tracking-wider text-white transition-all hover:shadow-[0_0_24px_rgba(168,85,247,0.45)]"
              >
                Download
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
