"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  HeartPulse,
  ImageUp,
  Languages,
  Link2,
  Mail,
  RotateCcw,
  Settings2,
  TriangleAlert,
  User,
  UserCog,
  Volume2,
  Zap,
} from "lucide-react";
import { useSession } from "@/lib/session";
import { useCaseStore } from "@/lib/store";
import { sfx, setMasterVolume } from "@/lib/sound";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { coinsToUsd, USD_TO_COINS } from "@/lib/wear";

/* ===== USER SPEC (Task 83): the dedicated SETTINGS page =====
   Every setting the account has, organized in one place — email, language,
   sound and the SELF CARE tools at the bottom. The SIGN OUT button is DELETED
   completely from the settings (this page is NOT a second profile — it holds
   settings only; the trade link stays on the profile, under the avatar). */

/** The SELF CARE half of /api/settings. */
interface SelfcareState {
  deposit: { limit: number; days: number; startedAt: number; expiresAt: number; spent: number } | null;
  breakUntil: string | null;
  onBreak: boolean;
}

/** Coins -> "$12.50" — via the site-wide dollar rate (Task 27: was a
 *  hardcoded ÷10). Built with toLocaleString — no dollar LITERAL here
 *  (Task 68 currency-scan stays green). */
const fmtDollars = (coins: number): string =>
  coinsToUsd(coins).toLocaleString("en-US", { style: "currency", currency: "USD" });

/** A duration like "2d 4h" / "5h 12m" / "12m". */
const fmtRemaining = (ms: number): string => {
  if (ms <= 0) return "0m";
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  return d > 0 ? `${d}d ${h}h` : h > 0 ? `${h}h ${m}m` : `${m}m`;
};

/** The 1/2/3-day radio circles — USER SPEC: mark the duration with a CIRCLE.
 *  (Static Tailwind classes only — the JIT compiler can't see template names.) */
function DayPicker({
  value,
  onChange,
  tone = "emerald",
}: {
  value: number;
  onChange: (d: 1 | 2 | 3) => void;
  tone?: "emerald" | "rose";
}) {
  const emerald = tone === "emerald";
  return (
    <div className="flex flex-wrap gap-2">
      {[1, 2, 3].map((d) => {
        const active = value === d;
        return (
          <button
            key={d}
            type="button"
            onClick={() => {
              sfx.click();
              onChange(d as 1 | 2 | 3);
            }}
            aria-pressed={active}
            className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-[11px] font-black uppercase tracking-wide transition-colors ${
              active
                ? emerald
                  ? "border-emerald-400/60 bg-emerald-500/10 text-emerald-300"
                  : "border-rose-400/60 bg-rose-500/10 text-rose-300"
                : "border-white/15 bg-white/[0.03] text-white/50 hover:bg-white/[0.07] hover:text-white/80"
            }`}
          >
            <span className={`grid h-4 w-4 place-items-center rounded-full border ${active ? (emerald ? "border-emerald-400" : "border-rose-400") : "border-white/30"}`}>
              {active && (
                <span className={emerald ? "h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]" : "h-2 w-2 rounded-full bg-rose-400 shadow-[0_0_8px_rgba(244,63,94,0.9)]"} />
              )}
            </span>
            {d} DAY{d > 1 ? "S" : ""}
          </button>
        );
      })}
    </div>
  );
}

/** The second confirmation — USER SPEC: press the button, THEN confirm again. */
function SelfCareConfirm({
  kind,
  busy,
  amount,
  days,
  onCancel,
  onConfirm,
}: {
  kind: "deposit" | "break";
  busy: boolean;
  amount: string;
  days: number;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 px-4 backdrop-blur-sm" role="alertdialog" aria-modal="true" aria-label="Confirm self care">
      <motion.div
        initial={{ opacity: 0, scale: 0.94 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.18 }}
        className="w-full max-w-sm rounded-2xl border border-rose-500/35 bg-[#150d1d] p-6 text-center shadow-[0_0_60px_rgba(244,63,94,0.22)]"
      >
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl border border-rose-400/40 bg-rose-500/10">
          <TriangleAlert className="h-6 w-6 text-rose-300" />
        </span>
        <h3 className="font-display mt-3 text-xl font-black text-white">Are you absolutely sure?</h3>
        <p className="mt-2 text-sm leading-relaxed text-white/60">
          {kind === "deposit" ? (
            <>
              Your deposits will be capped at{" "}
              <span className="font-black text-amber-300" dir="ltr">
                {amount}
              </span>{" "}
              for{" "}
              <span className="font-black text-amber-300">
                {days} day{days > 1 ? "s" : ""}
              </span>
              . While it runs, ROLLBOX refuses any move that pushes you past the cap.
            </>
          ) : (
            <>
              The ENTIRE site will be locked for you for{" "}
              <span className="font-black text-rose-300">
                {days} day{days > 1 ? "s" : ""}
              </span>{" "}
              — every page, every device, no exceptions.
            </>
          )}
        </p>
        <p className="mt-3 rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-[11px] font-black uppercase tracking-wide text-rose-300">
          This cannot be cancelled or shortened
        </p>
        <div className="mt-5 flex gap-2">
          <Button
            variant="outline"
            onClick={onCancel}
            className="flex-1 border-white/20 bg-white/5 font-bold text-white/80 hover:bg-white/10 hover:text-white"
          >
            Cancel
          </Button>
          <Button onClick={onConfirm} disabled={busy} className="flex-1 bg-rose-500 font-black text-white hover:bg-rose-400 disabled:opacity-50">
            {busy ? "Working..." : kind === "deposit" ? "YES — LIMIT IT" : "YES — LOCK IT"}
          </Button>
        </div>
      </motion.div>
    </div>
  );
}

export function SettingsView() {
  const mounted = useMounted();
  const { toast } = useToast();
  const { player: me, patch } = useSession();

  const [selfcare, setSelfcare] = useState<SelfcareState | null>(null);
  const [email, setEmail] = useState("");
  const [savingMail, setSavingMail] = useState(false);
  // C12: the display-identity editor (custom nickname + avatar URL).
  const [nameInput, setNameInput] = useState("");
  const [avatarInput, setAvatarInput] = useState("");
  const [savingIdentity, setSavingIdentity] = useState(false);
  const [limitInput, setLimitInput] = useState(""); // free text, DOLLARS ("0.00$" default)
  const [limitDays, setLimitDays] = useState(0);
  const [breakDays, setBreakDays] = useState(0);
  const [confirming, setConfirming] = useState<null | "deposit" | "break">(null);
  const [busySelfcare, setBusySelfcare] = useState(false);
  const [lang, setLang] = useState("en");
  const [, setTick] = useState(0);
  const soundVolume = useCaseStore((s) => s.soundVolume);
  const setSoundVolume = useCaseStore((s) => s.setSoundVolume);

  const loadSettings = async () => {
    try {
      const r = await fetch("/api/settings", { cache: "no-store" });
      if (!r.ok) return;
      const data = (await r.json()) as { settings: { email: string }; selfcare: SelfcareState };
      setSelfcare(data.selfcare);
      setEmail(data.settings.email);
    } catch {
      /* retried on the next visit */
    }
  };

  // keep the self-care countdowns honest
  useEffect(() => {
    const t = window.setInterval(() => setTick((k) => k + 1), 30000);
    return () => window.clearInterval(t);
  }, []);

  const meId = me?.id ?? null;
  // settings + self care load right after sign-in; the stored language rides along
  useEffect(() => {
    if (!meId) return;
    void loadSettings();
    try {
      setLang(localStorage.getItem("rb_lang") ?? "en");
    } catch {
      /* no storage — English stays */
    }
  }, [meId]);

  // C12: keep the identity inputs in sync with the server truth.
  const meName = me?.name ?? "";
  const meAvatar = me?.avatar ?? "";
  const meNameCustom = me?.nameCustom ?? false;
  const meAvatarCustom = me?.avatarCustom ?? false;
  useEffect(() => {
    setNameInput(meName);
    setAvatarInput(meAvatar);
  }, [meName, meAvatar]);

  // C12: save the custom identity — only fields the user actually changed
  // ride the request (the same partial-update contract as /api/settings).
  const saveIdentity = async () => {
    setSavingIdentity(true);
    try {
      const name = nameInput.trim();
      const avatar = avatarInput.trim();
      if (name === meName && avatar === meAvatar) {
        toast({ title: "Nothing to save", description: "Change the name or the avatar link first." });
        return;
      }
      if (name !== meName && (name.length < 2 || name.length > 24)) {
        toast({ title: "Name rejected", description: "Use 2-24 characters.", variant: "destructive" });
        sfx.error();
        return;
      }
      if (avatar !== meAvatar && avatar && !avatar.startsWith("https://")) {
        toast({ title: "Avatar rejected", description: "The picture link must start with https://", variant: "destructive" });
        sfx.error();
        return;
      }
      const body: Record<string, string> = {};
      if (name !== meName) body.name = name;
      if (avatar !== meAvatar) body.avatar = avatar;
      const r = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await r.json().catch(() => ({}))) as {
        player?: { name: string; avatar: string | null };
        identity?: { nameCustom: boolean; avatarCustom: boolean };
        error?: string;
      };
      if (!r.ok || !data.player) {
        toast({ title: "Could not save", description: data.error ?? "Try again in a moment.", variant: "destructive" });
        sfx.error();
        return;
      }
      patch({
        name: data.player.name,
        avatar: data.player.avatar,
        nameCustom: data.identity?.nameCustom ?? meNameCustom,
        avatarCustom: data.identity?.avatarCustom ?? meAvatarCustom,
      });
      sfx.coins();
      toast({
        title: "Identity saved",
        description: "Your name and avatar are live everywhere — and they survive Steam re-logins.",
      });
    } finally {
      setSavingIdentity(false);
    }
  };

  // C12: restore the snapshotted Steam persona (name + avatar).
  const resetIdentity = async () => {
    setSavingIdentity(true);
    try {
      const r = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reset: "both" }),
      });
      const data = (await r.json().catch(() => ({}))) as {
        player?: { name: string; avatar: string | null };
        identity?: { nameCustom: boolean; avatarCustom: boolean };
        error?: string;
      };
      if (!r.ok || !data.player) {
        toast({ title: "Could not reset", description: data.error ?? "Try again in a moment.", variant: "destructive" });
        sfx.error();
        return;
      }
      patch({
        name: data.player.name,
        avatar: data.player.avatar,
        nameCustom: data.identity?.nameCustom ?? false,
        avatarCustom: data.identity?.avatarCustom ?? false,
      });
      sfx.click();
      toast({
        title: "Back to your Steam identity",
        description: "Future Steam logins keep syncing it until you customize again.",
      });
    } finally {
      setSavingIdentity(false);
    }
  };

  const saveEmail = async () => {
    setSavingMail(true);
    try {
      // PARTIAL update (Task 83): the settings page touches ONLY the email —
      // the trade link on the profile can never be clobbered from here.
      const r = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = (await r.json().catch(() => ({}))) as {
        settings?: { email: string };
        error?: string;
      };
      if (!r.ok || !data.settings) {
        toast({
          title: "Email rejected",
          description: data.error ?? "Try again in a moment.",
          variant: "destructive",
        });
        sfx.error();
        return;
      }
      setEmail(data.settings.email);
      patch({ email: data.settings.email || null });
      sfx.coins();
      toast({
        title: "Settings saved",
        description: "Updates and push notifications will use this email.",
      });
    } finally {
      setSavingMail(false);
    }
  };

  const pickLang = (v: string) => {
    sfx.click();
    setLang(v);
    try {
      localStorage.setItem("rb_lang", v);
    } catch {
      /* no storage — the pick lives for this visit */
    }
  };

  const onVolume = (v: number) => {
    setSoundVolume(v / 100);
    setMasterVolume(v / 100); // the whole soundscape scales LIVE while dragging
  };

  // the parsed deposit-limit input: free text -> dollars -> balance (1$ = 1)
  const limitDollars = parseFloat(limitInput.replace(",", "."));
  const limitValid = Number.isFinite(limitDollars) && limitDollars > 0;

  // USER SPEC (Task 75): the CONFIRMED self-care action (the modal is the
  // second confirmation; the server refuses anything without confirm:true).
  const runSelfcare = async (kind: "deposit" | "break") => {
    setBusySelfcare(true);
    try {
      const body =
        kind === "deposit"
          ? { action: kind, days: limitDays, amount: Math.round(limitDollars * USD_TO_COINS), confirm: true }
          : { action: kind, days: breakDays, confirm: true };
      const r = await fetch("/api/settings/selfcare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await r.json().catch(() => ({}))) as { selfcare?: SelfcareState; error?: string };
      if (!r.ok || !data.selfcare) {
        toast({ title: "Self care failed", description: data.error ?? "Try again in a moment.", variant: "destructive" });
        sfx.error();
        return;
      }
      setSelfcare(data.selfcare);
      const d = data.selfcare.deposit;
      patch({
        depositLimit: d ? d.limit : null,
        depositLimitDays: d ? d.days : null,
        depositLimitStart: d ? new Date(d.startedAt).toISOString() : null,
        breakUntil: data.selfcare.breakUntil,
      });
      sfx.click();
      if (kind === "deposit" && d) {
        setLimitInput("");
        setLimitDays(0);
        toast({
          title: "Deposit limit is now ACTIVE",
          description: `${fmtDollars(d.limit)} per ${d.days} day${d.days > 1 ? "s" : ""} — it cannot be cancelled before it expires.`,
        });
      } else if (kind === "break") {
        setBreakDays(0);
        toast({
          title: "Break started — take care of yourself",
          description: "The whole site is locked for you until the break ends.",
        });
      }
    } finally {
      setBusySelfcare(false);
      setConfirming(null);
    }
  };

  const now = Date.now();

  if (!mounted) {
    return (
      <main className="flex min-h-[60vh] items-center justify-center" aria-label="Settings">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-violet-500/30 border-t-violet-400" />
      </main>
    );
  }

  // ---------- guest ----------
  if (!me) {
    return (
      <main className="relative flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 pb-20 pt-10" aria-label="Guest settings">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative w-full max-w-md rounded-2xl border border-violet-500/25 bg-[#100a1e]/90 p-8 text-center shadow-[0_0_50px_rgba(124,58,237,0.2)]"
        >
          <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full border border-white/10 bg-white/5">
            <Settings2 className="h-8 w-8 text-white/50" />
          </span>
          <h1 className="font-display text-2xl font-black text-white">Settings belong to players</h1>
          <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-white/55">
            Sign in with STEAM — the only way in — and your email, language, sound and self-care tools live here, on every device you use.
          </p>
          <div className="mt-6 flex flex-col gap-2">
            <Link
              href="/login"
              onClick={() => sfx.click()}
              className="neon-btn flex items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-white"
            >
              <Zap className="h-4 w-4" fill="currentColor" />
              Sign In with Steam
            </Link>
            <Link
              href="/#cases"
              className="rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-white/75 transition-colors hover:bg-white/10 hover:text-white"
            >
              Browse Cases Instead
            </Link>
          </div>
        </motion.div>
      </main>
    );
  }

  // ---------- signed in ----------
  return (
    <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-8" aria-label="Settings">

      <div className="relative mx-auto max-w-3xl px-4">
        {/* header — back to the profile, then the page title */}
        <div className="flex items-center gap-3">
          <Link
            href="/profile"
            onClick={() => sfx.click()}
            className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
            aria-label="Back to the profile"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <h1 className="font-display text-2xl font-black tracking-wide text-white sm:text-3xl">
              SET<span className="text-gradient-neon">TINGS</span>
            </h1>
            <p className="text-xs font-semibold text-white/45">
              Every account setting, organized in one place — preferences on top, self care at the bottom.
            </p>
          </div>
        </div>

        {/* ===== MAIN SETTINGS ===== */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.03 }}
          className="mt-6 rounded-2xl border border-white/12 bg-[#0d0a18]/90 p-6 shadow-[0_0_40px_rgba(124,58,237,0.08)]"
          aria-label="Main settings"
        >
          <p className="text-[10px] font-black uppercase tracking-widest text-white/40">Main settings</p>

          {/* C12: profile identity — custom nickname + avatar */}
          <div className="mt-3 rounded-xl border border-white/10 bg-white/[0.02] p-4">
            <div className="flex flex-wrap items-center gap-2">
              <UserCog className="h-4 w-4 text-violet-300" />
              <h3 className="text-sm font-black text-white">Profile name &amp; avatar</h3>
              {meNameCustom && (
                <span className="rounded-full border border-violet-400/40 bg-violet-500/10 px-2 py-0.5 text-[9px] font-black uppercase tracking-wide text-violet-300">
                  custom name
                </span>
              )}
              {meAvatarCustom && (
                <span className="rounded-full border border-violet-400/40 bg-violet-500/10 px-2 py-0.5 text-[9px] font-black uppercase tracking-wide text-violet-300">
                  custom avatar
                </span>
              )}
            </div>
            <p className="mt-1 text-xs leading-relaxed text-white/45">
              Show a nickname instead of your Steam name — it appears in the top bar, live drops, battles and the
              leaderboard, and SURVIVES Steam re-logins. Reset brings your Steam identity back anytime.
            </p>
            <div className="mt-3 flex items-center gap-3">
              {meAvatar ? (
                <img
                  src={meAvatar}
                  alt="Your current avatar"
                  className="h-11 w-11 shrink-0 rounded-full border border-white/15 object-cover"
                />
              ) : (
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-white/15 bg-white/5 text-sm font-black text-white/50">
                  {meName.slice(0, 1).toUpperCase() || "?"}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-white/90" dir="ltr">
                  {meName}
                </p>
                <p className="text-[11px] text-white/40">This is what other players see right now.</p>
              </div>
            </div>
            <div className="mt-3 grid gap-2">
              <div className="relative">
                <User className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/30" />
                <input
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  maxLength={24}
                  dir="ltr"
                  placeholder="Display name (2-24 characters)"
                  aria-label="Display name"
                  className="h-10 w-full rounded-lg border border-white/15 bg-black/40 pl-9 pr-14 text-sm text-white placeholder:text-white/25 focus:border-violet-400/60 focus:outline-none"
                />
                <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-white/30" dir="ltr">
                  {nameInput.trim().length}/24
                </span>
              </div>
              <div className="relative">
                <ImageUp className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/30" />
                <input
                  value={avatarInput}
                  onChange={(e) => setAvatarInput(e.target.value)}
                  dir="ltr"
                  inputMode="url"
                  placeholder="Avatar picture link (https://… — empty = Steam's)"
                  aria-label="Avatar picture link"
                  className="h-10 w-full rounded-lg border border-white/15 bg-black/40 pl-9 pr-3 text-sm text-white placeholder:text-white/25 focus:border-violet-400/60 focus:outline-none"
                />
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button
                onClick={() => void saveIdentity()}
                disabled={savingIdentity}
                className="neon-btn h-10 rounded-lg px-5 text-xs font-black text-white disabled:opacity-50"
              >
                {savingIdentity ? "Saving..." : "Save identity"}
              </Button>
              <Button
                onClick={() => void resetIdentity()}
                disabled={savingIdentity || (!meNameCustom && !meAvatarCustom)}
                variant="outline"
                className="h-10 rounded-lg border-white/20 bg-white/5 px-4 text-xs font-black text-white/75 hover:bg-white/10 hover:text-white disabled:opacity-40"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Reset to Steam
              </Button>
            </div>
          </div>

          {/* email */}
          <div className="mt-3 rounded-xl border border-white/10 bg-white/[0.02] p-4">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-sky-300" />
              <h3 className="text-sm font-black text-white">Email</h3>
              {me.email && (
                <span className="rounded-full border border-sky-400/40 bg-sky-500/10 px-2 py-0.5 text-[9px] font-black uppercase tracking-wide text-sky-300">
                  saved
                </span>
              )}
            </div>
            <p className="mt-1 text-xs leading-relaxed text-white/45">
              For account updates and push notifications — big wins, battle reminders and site news.
            </p>
            <div className="mt-3 flex flex-col gap-2 sm:flex-row">
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                dir="ltr"
                placeholder="you@example.com"
                className="h-10 flex-1 rounded-lg border border-white/15 bg-black/40 px-3 text-sm text-white placeholder:text-white/25 focus:border-sky-400/60 focus:outline-none"
                aria-label="Email for updates and push notifications"
              />
              <Button
                onClick={() => void saveEmail()}
                disabled={savingMail}
                className="neon-btn h-10 rounded-lg px-5 text-xs font-black text-white disabled:opacity-50"
              >
                {savingMail ? "Saving..." : "Save email"}
              </Button>
            </div>
          </div>

          {/* language + sound volume */}
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
              <div className="flex items-center gap-2">
                <Languages className="h-4 w-4 text-amber-300" />
                <h3 className="text-sm font-black text-white">Site language</h3>
              </div>
              <p className="mt-1 text-xs text-white/45">ROLLBOX speaks English today — more languages are on the way.</p>
              <select
                value={lang}
                onChange={(e) => pickLang(e.target.value)}
                className="mt-3 h-10 w-full rounded-lg border border-white/15 bg-black/40 px-3 text-sm font-bold text-white focus:outline-none"
                aria-label="Site language"
              >
                <option value="en">English</option>
                <option value="he" disabled>
                  עברית — coming soon
                </option>
              </select>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4 text-fuchsia-300" />
                  <h3 className="text-sm font-black text-white">Sound volume</h3>
                </div>
                <span className="font-display text-sm font-black text-fuchsia-300" dir="ltr">
                  {Math.round(soundVolume * 100)}%
                </span>
              </div>
              <p className="mt-1 text-xs text-white/45">Drives every click, reel and reveal. The speaker toggle in the top bar mutes everything.</p>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(soundVolume * 100)}
                onChange={(e) => onVolume(Number(e.target.value))}
                onMouseUp={() => sfx.click()}
                onTouchEnd={() => sfx.click()}
                className="mt-4 w-full accent-fuchsia-500"
                aria-label="Sound volume percent"
              />
            </div>
          </div>

          {/* the trade link pointer — USER SPEC (Task 83): the link itself stays
              on the profile under the avatar; the settings page only points there */}
          <Link
            href="/profile"
            onClick={() => sfx.click()}
            className="mt-3 flex items-center justify-between gap-3 rounded-xl border border-emerald-400/25 bg-emerald-500/[0.05] p-4 transition-colors hover:bg-emerald-500/10"
            aria-label="Open the profile to edit the Steam trade link"
          >
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-emerald-400/40 bg-emerald-500/10">
                <Link2 className="h-4 w-4 text-emerald-300" />
              </span>
              <div>
                <h3 className="text-sm font-black text-white">Steam trade link</h3>
                <p className="mt-0.5 text-xs text-white/45">
                  Lives on your profile, right under the avatar {me.tradeLink ? "— saved and ready for withdrawals." : "— not saved yet."}
                </p>
              </div>
            </div>
            <span className="hidden shrink-0 rounded-lg border border-emerald-400/40 bg-emerald-500/10 px-3 py-1.5 text-[10px] font-black uppercase tracking-wide text-emerald-300 sm:block">
              Open profile
            </span>
          </Link>
        </motion.div>

        {/* ===== SELF CARE — at the bottom (USER SPEC) ===== */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.05 }}
          className="mt-6 rounded-2xl border border-rose-500/25 bg-[#160b12]/90 p-6 shadow-[0_0_40px_rgba(244,63,94,0.08)]"
          aria-label="Self care"
        >
          <div className="flex flex-wrap items-center gap-2">
            <HeartPulse className="h-5 w-5 text-rose-300" />
            <h2 className="font-display text-lg font-black text-white">SELF CARE</h2>
            <span className="rounded-full border border-rose-400/40 bg-rose-500/10 px-2 py-0.5 text-[9px] font-black uppercase tracking-wide text-rose-300">
              cannot be undone early
            </span>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-white/50">
            Tools that protect you from yourself. A limit or a break starts the second you confirm it and CANNOT be
            cancelled or shortened — it expires on its own. The SERVER enforces both, on every device you sign into.
          </p>

          {/* deposit limit */}
          <div className="mt-4 rounded-lg border border-white/10 bg-black/25 p-4">
            <h4 className="text-sm font-black text-white">Deposit limit</h4>
            <p className="mt-0.5 text-[11px] leading-relaxed text-white/45">
              Cap what you can put into play — case openings, battle entries and exchange buys — for the window you pick.
            </p>
            {selfcare?.deposit ? (
              <div className="mt-3 rounded-lg border border-amber-400/40 bg-amber-500/10 px-3 py-3">
                <p className="text-xs font-black uppercase tracking-wide text-amber-300">Limit active</p>
                <p className="font-display mt-1 text-lg font-black text-white" dir="ltr">
                  {fmtDollars(selfcare.deposit.limit)}{" "}
                  <span className="text-xs font-bold text-white/50">per {selfcare.deposit.days} day{selfcare.deposit.days > 1 ? "s" : ""}</span>
                </p>
                <p className="mt-1 text-[11px] text-white/55" dir="ltr">
                  spent {fmtDollars(Math.min(selfcare.deposit.spent, selfcare.deposit.limit))} • {fmtRemaining(selfcare.deposit.expiresAt - now)} left •
                  ends {new Date(selfcare.deposit.expiresAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false })}
                </p>
              </div>
            ) : (
              <>
                <div className="mt-3 flex flex-col gap-3 lg:flex-row lg:items-center">
                  <input
                    value={limitInput}
                    onChange={(e) => setLimitInput(e.target.value.replace(/[^0-9.,]/g, ""))}
                    inputMode="decimal"
                    dir="ltr"
                    placeholder="0.00$"
                    aria-label="Deposit limit amount in dollars"
                    className="h-10 w-full rounded-lg border border-white/15 bg-black/40 px-3 text-sm text-white placeholder:text-white/25 focus:border-amber-400/60 focus:outline-none lg:w-40"
                  />
                  <DayPicker value={limitDays} onChange={setLimitDays} tone="emerald" />
                </div>
                {limitValid && (
                  <p className="mt-2 text-[11px] font-bold text-amber-300/90" dir="ltr">
                    ≈ ${Math.round(limitDollars * USD_TO_COINS).toLocaleString()} for {limitDays || "…"} day{limitDays === 1 ? "" : "s"}
                  </p>
                )}
                <Button
                  onClick={() => setConfirming("deposit")}
                  disabled={!limitValid || limitDays === 0}
                  className="gold-btn mt-3 h-10 rounded-lg px-5 text-xs font-black text-black disabled:opacity-40"
                >
                  LIMIT DEPOSIT
                </Button>
              </>
            )}
          </div>

          {/* take a break */}
          <div className="mt-4 rounded-lg border border-white/10 bg-black/25 p-4">
            <h4 className="text-sm font-black text-white">Take a break</h4>
            <p className="mt-0.5 text-[11px] leading-relaxed text-white/45">
              Lock the ENTIRE site for yourself — every page, every device — for the window you pick.
            </p>
            {selfcare?.breakUntil ? (
              <div className="mt-3 rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-3">
                <p className="text-xs font-black uppercase tracking-wide text-rose-300">Break active — the site is locked</p>
                <p className="font-display mt-1 text-lg font-black text-white" dir="ltr">
                  {fmtRemaining(new Date(selfcare.breakUntil).getTime() - now)}
                  <span className="ml-2 text-xs font-bold text-white/50">
                    until {new Date(selfcare.breakUntil).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false })}
                  </span>
                </p>
              </div>
            ) : (
              <>
                <div className="mt-3">
                  <DayPicker value={breakDays} onChange={setBreakDays} tone="rose" />
                </div>
                <Button
                  onClick={() => setConfirming("break")}
                  disabled={breakDays === 0}
                  className="mt-3 h-10 rounded-lg border border-rose-400/50 bg-rose-500/15 px-5 text-xs font-black text-rose-200 hover:bg-rose-500/25 disabled:opacity-40"
                  variant="outline"
                >
                  TAKE A BREAK
                </Button>
              </>
            )}
          </div>
        </motion.div>

        {/* the guest note — no account tools here on purpose */}
        <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[11px] text-white/35">
          <User className="h-3 w-3" aria-hidden="true" />
          Account tools like signing out live with the avatar chip in the top bar — this page holds your settings only.
        </p>
      </div>

      {/* the second confirmation — USER SPEC: button, THEN "are you sure?" */}
      {confirming && (
        <SelfCareConfirm
          kind={confirming}
          busy={busySelfcare}
          amount={fmtDollars(Math.round(limitDollars * USD_TO_COINS))}
          days={confirming === "deposit" ? limitDays : breakDays}
          onCancel={() => setConfirming(null)}
          onConfirm={() => {
            if (confirming) void runSelfcare(confirming);
          }}
        />
      )}
    </main>
  );
}
