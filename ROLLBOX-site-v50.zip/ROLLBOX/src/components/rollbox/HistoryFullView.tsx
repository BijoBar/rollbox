"use client";

// QOL (Task 167): the player's FULL personal history — three tabs (opens /
// battles / money) with 25-row pages, the deep version of the profile's
// battle history. Server-truth only: every tab reads /api/history.
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Coins, PackageOpen, Swords } from "lucide-react";
import { useMounted } from "@/hooks/use-mounted";
import { useSession } from "@/lib/session";
import { sfx } from "@/lib/sound";
import { wearColorOf, wearShortOf } from "@/lib/wear";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";

type Tab = "opens" | "battles" | "money";

interface OpenRow {
  id: number;
  caseName: string;
  skinName: string;
  value: number;
  wear: string | null;
  isRd: boolean;
  source: string;
  createdAt: string;
}
interface BattleRow {
  id: string;
  code: string;
  entry: number;
  status: string;
  potTotal: number | null;
  won: boolean;
  rounds: string[];
  players: string[];
  createdAt: string;
}
interface MoneyRow {
  id: number;
  kind: string;
  amount: number;
  balanceAfter: number;
  ref: string | null;
  createdAt: string;
}

const TABS: { key: Tab; label: string; icon: typeof Coins }[] = [
  { key: "opens", label: "Case opens", icon: PackageOpen },
  { key: "battles", label: "Battles", icon: Swords },
  { key: "money", label: "Money", icon: Coins },
];

const fmt = (iso: string) =>
  new Date(iso).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });

const KIND_COLOR = (kind: string) => {
  if (/win|prize|giveaway|deposit|bonus|gift|comp|signup|daily|levelup|refund|sell|topup/.test(kind)) return "text-emerald-300";
  if (/entry|lock|buy|loss/.test(kind)) return "text-rose-300";
  return "text-white/70";
};

export function HistoryFullView() {
  const mounted = useMounted();
  const { player: me } = useSession();
  const [tab, setTab] = useState<Tab>("opens");
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [rows, setRows] = useState<(OpenRow | BattleRow | MoneyRow)[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (t: Tab, p: number) => {
    setLoading(true);
    try {
      const r = await fetch(`/api/history?tab=${t}&page=${p}`, { cache: "no-store" });
      if (r.ok) {
        const d = (await r.json()) as { rows: (OpenRow | BattleRow | MoneyRow)[]; page: number; pages: number };
        setRows(d.rows ?? []);
        setPage(d.page);
        setPages(d.pages);
      }
    } catch {
      /* keep old rows */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!mounted || !me?.id) return;
    void load(tab, page);
  }, [mounted, me?.id, tab, page, load]);

  if (mounted && !me) {
    return (
      <SiteShell>
        <main className="min-h-[calc(100vh-4rem)] pt-24 pb-20 text-center">
          <p className="text-sm font-bold text-white/60">Sign in to see your full history.</p>
          <Link href="/login" className="mt-3 inline-block text-xs font-black uppercase tracking-widest text-amber-300 hover:underline">
            Sign in with Steam
          </Link>
        </main>
      </SiteShell>
    );
  }

  const isOpen = (r: OpenRow | BattleRow | MoneyRow): r is OpenRow => "skinName" in r;
  const isBattle = (r: OpenRow | BattleRow | MoneyRow): r is BattleRow => "code" in r;

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-10" aria-label="Full personal history">
        <div className="mx-auto max-w-3xl px-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h1 className="font-display text-3xl font-black tracking-wide text-white sm:text-4xl">
                MY <span className="text-gradient-neon">HISTORY</span>
              </h1>
              <p className="mt-1 text-xs font-semibold text-white/45">Every drop, battle and coin — the complete record.</p>
            </div>
            <Link
              href="/profile"
              onClick={() => sfx.click()}
              className="flex shrink-0 items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-[11px] font-black uppercase tracking-widest text-white/60 transition-colors hover:text-white"
            >
              <ChevronLeft className="h-3.5 w-3.5" /> Profile
            </Link>
          </div>

          <div className="mt-5 grid grid-cols-3 gap-1.5 rounded-2xl border border-white/10 bg-black/40 p-1.5" role="tablist" aria-label="History sections">
            {TABS.map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                type="button"
                role="tab"
                aria-selected={tab === key}
                onClick={() => {
                  sfx.click();
                  setTab(key);
                  setPage(1);
                }}
                className={cn(
                  "flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-black uppercase tracking-wider transition-colors",
                  tab === key
                    ? "border-amber-400/40 bg-amber-500/15 text-white"
                    : "border-transparent text-white/45 hover:text-white",
                )}
              >
                <Icon className="h-4 w-4" />
                {label}
              </button>
            ))}
          </div>

          {loading ? (
            <p className="mt-8 text-center text-xs font-black uppercase tracking-widest text-white/35">Loading…</p>
          ) : rows.length === 0 ? (
            <div className="mt-8 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-14 text-center">
              <p className="text-sm font-bold text-white/60">Nothing here yet</p>
              <p className="mt-1 text-xs text-white/35">Open a case or join a battle — the record starts with the first move.</p>
            </div>
          ) : (
            <ul className="mt-5 space-y-1.5" aria-label="History rows">
              {rows.map((r) =>
                isOpen(r) ? (
                  <li key={`o${r.id}`} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-white/5 bg-white/[0.03] px-3.5 py-2.5 text-xs">
                    <span className="font-bold text-white/85">{r.skinName}</span>
                    {/* R43 USER SPEC: the exterior is ALWAYS listed on a drop —
                        legacy rows without one read as Field-Tested — in its color */}
                    <span
                      className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[9px] font-black"
                      style={{ color: wearColorOf(r.wear) }}
                      title={`Exterior: ${r.wear ?? "Field-Tested"}`}
                    >
                      {wearShortOf(r.wear)}
                    </span>
                    {r.isRd && <span className="rounded bg-amber-400/20 px-1.5 py-0.5 text-[9px] font-black uppercase text-amber-300">ROLLDROP</span>}
                    <span className="text-white/40">from {r.caseName}</span>
                    <span className="ml-auto flex items-center gap-1 font-black text-amber-300/90">
                      <Coin className="h-3 w-3" /> {r.value.toFixed(2)}
                    </span>
                    <span className="w-full font-mono text-[10px] text-white/30">{fmt(r.createdAt)}</span>
                  </li>
                ) : isBattle(r) ? (
                  <li key={r.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-white/5 bg-white/[0.03] px-3.5 py-2.5 text-xs">
                    <span className="font-mono font-black text-white/85">{r.code}</span>
                    <span
                      className={cn(
                        "rounded px-1.5 py-0.5 text-[9px] font-black uppercase",
                        r.won ? "bg-emerald-500/20 text-emerald-300" : r.status === "finished" ? "bg-white/10 text-white/50" : "bg-sky-500/15 text-sky-300",
                      )}
                    >
                      {r.won ? "WIN" : r.status}
                    </span>
                    <span className="text-white/40">{r.rounds.length} case{r.rounds.length === 1 ? "" : "s"} · {r.players.length}p</span>
                    <span className="ml-auto flex items-center gap-1 font-black text-white/70">
                      <Coin className="h-3 w-3" /> {r.entry}
                    </span>
                    <span className="w-full font-mono text-[10px] text-white/30">{fmt(r.createdAt)}</span>
                  </li>
                ) : (
                  <li key={`m${r.id}`} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-white/5 bg-white/[0.03] px-3.5 py-2.5 text-xs">
                    <span className="font-mono text-[10px] font-black uppercase tracking-wider text-white/60">{r.kind}</span>
                    {r.ref && <span className="max-w-[240px] truncate text-white/40">{r.ref}</span>}
                    <span className={cn("ml-auto flex items-center gap-1 font-black", KIND_COLOR(r.kind))}>
                      {r.amount >= 0 ? "+" : ""}
                      <Coin className="h-3 w-3" /> {r.amount.toFixed(2)}
                    </span>
                    <span className="text-white/35">→ {r.balanceAfter.toFixed(2)}</span>
                    <span className="w-full font-mono text-[10px] text-white/30">{fmt(r.createdAt)}</span>
                  </li>
                ),
              )}
            </ul>
          )}

          {pages > 1 && (
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                type="button"
                disabled={page <= 1 || loading}
                onClick={() => {
                  sfx.click();
                  setPage((p) => p - 1);
                }}
                className="grid h-9 w-9 place-items-center rounded-lg border border-white/15 text-white/60 hover:text-white disabled:opacity-30"
                aria-label="Newer rows"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="text-[10px] font-black uppercase tracking-widest text-white/40">page {page}/{pages}</span>
              <button
                type="button"
                disabled={page >= pages || loading}
                onClick={() => {
                  sfx.click();
                  setPage((p) => p + 1);
                }}
                className="grid h-9 w-9 place-items-center rounded-lg border border-white/15 text-white/60 hover:text-white disabled:opacity-30"
                aria-label="Older rows"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </main>
    </SiteShell>
  );
}
