"use client";

// USER SPEC (Task 75): TAKE A BREAK — when a player blocks himself in SELF
// CARE, this full-screen shield covers the WHOLE site on every device he is
// signed into. It appears instantly (the server pushes the break to all
// sessions) and unlocks itself the moment the break expires. The server also
// refuses every spending route while the break runs — the overlay is the
// visible face of the same server-enforced block.

import { useEffect, useState } from "react";
import { LogOut, MoonStar } from "lucide-react";
import { useSession } from "@/lib/session";
import { Button } from "@/components/ui/button";

export function BreakGuard() {
  const { player: me, refresh } = useSession();
  const [, setTick] = useState(0);

  // keep the countdown alive
  useEffect(() => {
    const t = window.setInterval(() => setTick((k) => k + 1), 30000);
    return () => window.clearInterval(t);
  }, []);

  const until = me?.breakUntil ? new Date(me.breakUntil) : null;
  const remaining = until ? until.getTime() - Date.now() : 0;
  if (!until || remaining <= 0) return null;

  const days = Math.floor(remaining / 86400000);
  const hours = Math.floor((remaining % 86400000) / 3600000);
  const mins = Math.floor((remaining % 3600000) / 60000);
  const left = days > 0 ? `${days}d ${hours}h` : hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;

  const handleSignOut = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    await refresh();
    window.location.href = "/";
  };

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#08050f]/[0.985] px-4 backdrop-blur-md"
      role="alertdialog"
      aria-label="Take a break — the site is locked"
    >

      <div className="relative w-full max-w-md rounded-2xl border border-rose-500/30 bg-[#120b18]/95 p-8 text-center shadow-[0_0_70px_rgba(244,63,94,0.15)]">
        <span className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-2xl border border-rose-400/40 bg-rose-500/10 shadow-[0_0_24px_rgba(244,63,94,0.3)]">
          <MoonStar className="h-8 w-8 text-rose-300" />
        </span>
        <h1 className="font-display text-3xl font-black text-white">
          TAKE A <span className="text-rose-400">BREAK</span>
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-white/60">
          You locked yourself out of ROLLBOX from the SELF CARE settings. The whole site stays
          hidden until the break ends — this is what you asked for, and it cannot be undone early.
        </p>
        <div className="mt-6 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-4">
          <p className="text-[10px] font-black uppercase tracking-widest text-white/40">Time left</p>
          <p className="font-display mt-1 text-3xl font-black text-rose-300">{left}</p>
          <p className="mt-1 text-xs text-white/45" dir="ltr">
            unlocks {until.toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false })}
          </p>
        </div>
        <p className="mt-4 text-xs leading-relaxed text-white/40">
          The block lives on the SERVER — clearing the browser, switching devices or re-logging
          will not lift it. Take care.
        </p>
        <Button
          variant="outline"
          onClick={handleSignOut}
          className="mt-6 w-full border-white/20 bg-white/5 font-bold text-white/80 hover:bg-white/10 hover:text-white"
        >
          <LogOut className="h-4 w-4" />
          Sign Out
        </Button>
      </div>
    </div>
  );
}
