"use client";

import { cn } from "@/lib/utils";

/**
 * USER SPEC (ROLLDROP fix): the ROLLDROP REPLACES the skin that came out —
 * the reel's winning tile IS the raredrop.png art (never a skin). The reel
 * stops on it, then the extra rare round opens on the same reel.
 * Used by the solo opener strip and the battle reel strip.
 *
 * USER SPEC (Task 145): `frame={false}` renders the marker as a BARE
 * transparent square — no golden border, no plate, no glow. The winner tile
 * goes frameless the moment the reel locks. Scrolling (non-winner) markers
 * keep the framed look — it is the strip's design language.
 *
 * USER SPEC (Task 149): the cutscene video is DELETED — the marker IS just
 * the raredrop image now, and the image carries NO golden glow of its own:
 * the old amber drop-shadow on the <img> is removed, so a stopped rolldrop
 * shows the pure art on the reel with no golden frame or halo anywhere.
 */
export function RolldropTile({
  className,
  artClassName,
  style,
  glow = false,
  frame = true,
  winner = false,
}: {
  className?: string;
  artClassName?: string;
  style?: React.CSSProperties;
  /** gold pulse while the reel sits on the tile (framed mode only) */
  glow?: boolean;
  /** Task 145: bare transparent square — the cutscene replaces the frame */
  frame?: boolean;
  /** Task 145: tags the stopped winner tile (data-rd-win) so the opener can
   *  measure its exact box and play the cutscene INSIDE it */
  winner?: boolean;
}) {
  return (
    <div
      data-rd-win={winner ? "1" : undefined}
      className={cn(
        "relative grid select-none place-items-center overflow-hidden",
        frame &&
          "rounded-lg border-2 border-amber-300/70 bg-[radial-gradient(ellipse_at_center,#241631_0%,#0b0716_75%)]",
        frame && glow && "anim-glow-pulse",
        className
      )}
      style={frame ? { boxShadow: "0 0 26px rgba(240,185,11,0.55)", ...style } : style}
      aria-label="ROLLDROP"
    >
      <img
        src="/raredrop.png"
        alt="ROLLDROP"
        draggable={false}
        className={cn("object-contain", artClassName)}
      />
    </div>
  );
}
