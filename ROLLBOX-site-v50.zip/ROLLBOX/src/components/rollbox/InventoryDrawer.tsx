"use client";

import { create } from "zustand";
import { useMemo, useState } from "react";
import Link from "next/link";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PackageOpen, Coins, Trophy, ArrowLeftRight, Search } from "lucide-react";
import { useCaseStore, type InvItem } from "@/lib/store";
import { useSession } from "@/lib/session";
import { RARITY_META, formatCoins, type Rarity, type WeaponKind } from "@/lib/cases";
import { displayWearLabel, isWearableKind, wearColorOf, wearShortOf } from "@/lib/wear";
import { expandImg } from "@/lib/skin-img";
import { WeaponArt } from "./WeaponArt";
import { Coin } from "./Coin";
import { RarityBackdrop } from "./RarityBackdrop";
import { WeaponLabel } from "./WeaponLabel";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";

/**
 * Shared open state — the TopBar backpack button and the EXCHANGE page both
 * open the same inventory from anywhere on the site.
 * USER SPEC (Task 142): the inventory now opens CENTERED as a modal dialog
 * (was a right-side drawer).
 */
export const useInvDrawer = create<{ open: boolean; setOpen: (v: boolean) => void }>((set) => ({
  open: false,
  setOpen: (open) => set({ open }),
}));

/** Catalog render with SVG-art fallback (items are snapshots, not SKINS-map entries).
 *  USER SPEC (Task 26): the img may be the compact "~1…" Steam shorthand —
 *  expandImg resolves it to the real CDN URL, otherwise steam-bought skins
 *  silently lose their picture and fall back to the generic SVG art. */
function InvArt({ item }: { item: InvItem }) {
  const [failed, setFailed] = useState(false);
  const tint = RARITY_META[item.r]?.color ?? "#8882a8";
  const url = expandImg(item.img);
  if (!url || failed) {
    return (
      <WeaponArt
        kind={(item.a ?? "ak") as WeaponKind}
        colors={[tint, "#1a1426"]}
        className="max-h-24 w-full object-contain opacity-75"
      />
    );
  }
  return (
    <img
      src={url}
      alt={item.n}
      loading="lazy"
      draggable={false}
      onError={() => setFailed(true)}
      className="max-h-24 w-full select-none object-contain drop-shadow-lg"
    />
  );
}

/** C11: the inventory toolbar's sort orders. "newest" keeps the store's
 *  natural order (newest first) — exactly what the drawer showed before. */
type InvSort = "newest" | "value-desc" | "value-asc" | "name";
const INV_SORTS: { key: InvSort; label: string }[] = [
  { key: "newest", label: "Newest" },
  { key: "value-desc", label: "Value ↓" },
  { key: "value-asc", label: "Value ↑" },
  { key: "name", label: "A-Z" },
];

export function InventoryDrawer() {
  const open = useInvDrawer((s) => s.open);
  const setOpen = useInvDrawer((s) => s.setOpen);
  const inventory = useCaseStore((s) => s.inventory);
  const sell = useCaseStore((s) => s.sell);
  const sellAll = useCaseStore((s) => s.sellAll);
  const takeItem = useCaseStore((s) => s.takeItem);
  const { player: me, patch } = useSession();
  const { toast } = useToast();
  const mounted = useMounted();
  // C11: search + sort + rarity filter — display only, the sell actions stay
  // exactly as they were (Sell all always sells the WHOLE inventory).
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<InvSort>("newest");
  const [rarityFilter, setRarityFilter] = useState<string>("all");

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    const out = inventory.filter((i) => {
      if (rarityFilter !== "all" && i.r !== rarityFilter) return false;
      if (!q) return true;
      return i.n.toLowerCase().includes(q) || i.w.toLowerCase().includes(q);
    });
    if (sort === "value-desc") out.sort((a, b) => b.v - a.v);
    else if (sort === "value-asc") out.sort((a, b) => a.v - b.v);
    else if (sort === "name") out.sort((a, b) => a.n.localeCompare(b.n));
    return out;
  }, [inventory, query, sort, rarityFilter]);

  if (!mounted) return null;

  const totalValue = inventory.reduce((s, i) => s + i.v, 0);
  const best = inventory.reduce((b, i) => Math.max(b, i.v), 0);

  /** Signed-in: the SERVER validates ownership + value, credits the DB
   *  balance and deletes the rows (Task 64) — the client only names uids. */
  const sellOnServer = async (uids: string[]) => {
    try {
      const r = await fetch("/api/inventory/sell", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uids }),
      });
      const data = (await r.json()) as { balance?: number; credit?: number; error?: string };
      if (!r.ok) return false;
      if (typeof data.balance === "number") patch({ balance: data.balance });
      uids.forEach((uid) => takeItem(uid));
      return true;
    } catch {
      return false;
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent
        aria-describedby={undefined}
        className="max-h-[85vh] w-full max-w-md gap-0 overflow-hidden border-white/10 bg-[#100a1e] p-0 sm:max-w-md"
      >
        <DialogHeader className="border-b border-white/10 px-5 py-4 pr-12">
          <DialogTitle className="flex items-center gap-2 text-lg font-black text-white">
            <PackageOpen className="h-5 w-5 text-violet-300" />
            My Inventory
            <span className="rounded-full bg-violet-500/20 px-2 py-0.5 text-xs font-bold text-violet-200">
              {shown.length === inventory.length
                ? `${inventory.length} items`
                : `${shown.length} of ${inventory.length}`}
            </span>
          </DialogTitle>
          <div className="mt-2 flex flex-wrap items-center gap-3 text-sm">
            <span className="flex items-center gap-1.5 font-bold text-amber-300">
              <Coins className="h-4 w-4" fill="currentColor" />
              <Coin /> {formatCoins(totalValue)}
            </span>
            {best > 0 && (
              <span className="flex items-center gap-1 text-xs text-white/50">
                <Trophy className="h-3.5 w-3.5 text-amber-400" />
                <Coin /> {formatCoins(best)}
              </span>
            )}
          </div>
        </DialogHeader>

        <div className="flex max-h-[calc(85vh-110px)] min-h-0 flex-col">
          {inventory.length === 0 ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center">
              <div className="grid h-20 w-20 place-items-center rounded-full border border-dashed border-white/15 bg-white/[0.03]">
                <PackageOpen className="h-9 w-9 text-white/25" />
              </div>
              <p className="text-lg font-bold text-white/70">Inventory empty</p>
              <p className="max-w-60 text-sm leading-relaxed text-white/40">
                Wins pay out in coins — take your coins to the EXCHANGE and trade them for any
                skin in the game. Every skin you grab lands here.
              </p>
              <Link
                href="/skins"
                onClick={() => {
                  sfx.click();
                  setOpen(false);
                }}
                className="mt-1 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-300 px-5 py-2.5 text-xs font-black text-black shadow-[0_0_18px_rgba(240,185,11,0.35)] transition-all hover:brightness-110"
              >
                <ArrowLeftRight className="h-4 w-4" />
                Open the Exchange
              </Link>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between border-b border-white/5 px-4 py-2.5">
                <p className="text-[11px] font-bold uppercase tracking-wide text-white/40">
                  Exchange your items back for coins anytime
                </p>
                <button
                  onClick={() => {
                    if (me) {
                      void sellOnServer(
                        inventory.map((i) => i.uid)
                      ).then((ok) => {
                        if (ok) {
                          sfx.coins();
                          toast({
                            title: `Sold ${inventory.length} item${inventory.length === 1 ? "" : "s"}`,
                            description: (<>+<Coin /> {formatCoins(totalValue)} credited to your database balance</>),
                          });
                        } else {
                          sfx.error();
                          toast({ title: "Could not reach the server", variant: "destructive" });
                        }
                      });
                      return;
                    }
                    const total = sellAll();
                    sfx.coins();
                    toast({
                      title: `Sold ${inventory.length} item${inventory.length === 1 ? "" : "s"}`,
                      description: (<>+<Coin /> {formatCoins(total)} credited to your balance</>),
                    });
                  }}
                  className="shrink-0 rounded-lg border border-amber-400/40 bg-amber-400/10 px-3 py-1.5 text-[11px] font-black text-amber-300 transition-all hover:bg-amber-400/20"
                >
                  Sell all • <Coin /> {formatCoins(totalValue)}
                </button>
              </div>
              {/* C11: search + sort + rarity filter — display only */}
              <div className="border-b border-white/5 px-4 py-2.5">
                <div className="flex items-center gap-2">
                  <div className="relative min-w-0 flex-1">
                    <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/30" />
                    <input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      dir="ltr"
                      placeholder="Search your items…"
                      aria-label="Search inventory items"
                      className="h-9 w-full rounded-lg border border-white/15 bg-black/40 pl-8 pr-3 text-xs font-bold text-white placeholder:text-white/25 focus:border-violet-400/60 focus:outline-none"
                    />
                  </div>
                  <select
                    value={sort}
                    onChange={(e) => setSort(e.target.value as InvSort)}
                    aria-label="Sort inventory"
                    className="h-9 shrink-0 rounded-lg border border-white/15 bg-black/40 px-2 text-[11px] font-black text-white focus:outline-none"
                  >
                    {INV_SORTS.map((s) => (
                      <option key={s.key} value={s.key}>
                        {s.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <button
                    onClick={() => setRarityFilter("all")}
                    aria-pressed={rarityFilter === "all"}
                    className={`rounded-full border px-2 py-0.5 text-[9px] font-black uppercase tracking-wide transition-colors ${
                      rarityFilter === "all"
                        ? "border-white/50 bg-white/15 text-white"
                        : "border-white/15 bg-white/[0.03] text-white/45 hover:text-white/80"
                    }`}
                  >
                    All
                  </button>
                  {(Object.entries(RARITY_META) as [Rarity, { label: string; color: string; order: number }][])
                    .sort((a, b) => a[1].order - b[1].order)
                    .map(([key, meta]) => {
                      const active = rarityFilter === key;
                      return (
                        <button
                          key={key}
                          onClick={() => setRarityFilter(active ? "all" : key)}
                          aria-pressed={active}
                          className="flex items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] font-black uppercase tracking-wide transition-colors"
                          style={{
                            borderColor: active ? meta.color : meta.color + "40",
                            backgroundColor: active ? meta.color + "2e" : "transparent",
                            color: active ? meta.color : "rgba(255,255,255,0.45)",
                          }}
                        >
                          <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: meta.color }} />
                          {meta.label}
                        </button>
                      );
                    })}
                </div>
              </div>
              <div className="grid min-h-0 flex-1 auto-rows-[calc((min(100vw,28rem)-2.625rem)/2)] grid-cols-2 content-start gap-2.5 overflow-y-auto p-4">
                {shown.map((item) => {
                  const rar = RARITY_META[item.r];
                  const shortName = item.n.includes("|") ? item.n.split("|")[1].trim() : item.n;
                  return (
                    <div
                      key={item.uid}
                      className="relative overflow-hidden rounded-xl border bg-[#130d22]"
                      style={{ borderColor: (rar?.color ?? "#8882a8") + "55" }}
                      title={item.n}
                    >
                      {/* USER SPEC (Task 89/89b): eclipse artwork backdrop per rarity.
                          InvItem.r is a loose string (legacy rows) — the cast
                          is safe: RarityBackdrop guards every lookup. */}
                      <RarityBackdrop rarity={item.r as Rarity} className="inset-x-0 top-0 h-1/2 rounded-t-xl" />
                      <div className="absolute inset-0 flex flex-col p-2.5">
                        <div className="flex min-h-0 flex-1 items-center justify-center px-1">
                          <InvArt item={item} />
                        </div>
                        <p className="truncate text-[9px] font-bold text-white/45" dir="ltr">
                          {/* USER SPEC (Task 26): "Souvenir" in yellow */}
                          <WeaponLabel text={item.w} />
                        </p>
                        <p className="truncate text-[11px] font-bold text-white/90" dir="ltr">
                          {shortName}
                        </p>
                        {/* R43 USER SPEC: the item's exterior — ALWAYS listed on a skin,
                            in its own color (short code; the full label rides the tooltip) */}
                        {isWearableKind(item.w) && (
                          <p
                            className="truncate text-[9px] font-black uppercase tracking-wider"
                            dir="ltr"
                            style={{ color: wearColorOf(item.wear) }}
                            title={`Exterior: ${displayWearLabel(item.wear, item.n)}`}
                          >
                            {wearShortOf(displayWearLabel(item.wear, item.n))}
                          </p>
                        )}
                        <div className="mt-1 flex items-center justify-between gap-1 pt-1">
                          <span
                            className="font-display truncate text-[10px] font-black"
                            style={{ color: rar?.color ?? "#8882a8" }}
                          >
                            {rar?.label ?? item.r}
                          </span>
                          <button
                            onClick={() => {
                              if (me) {
                                void sellOnServer([item.uid]).then((ok) => {
                                  if (ok) {
                                    sfx.coins();
                                    toast({
                                      title: `Sold: ${shortName}`,
                                      description: (<>+<Coin /> {formatCoins(item.v)} credited to your database balance</>),
                                    });
                                  } else {
                                    sfx.error();
                                    toast({ title: "Could not reach the server", variant: "destructive" });
                                  }
                                });
                                return;
                              }
                              sell(item.uid);
                              sfx.coins();
                              toast({
                                title: `Sold: ${shortName}`,
                                description: (<>+<Coin /> {formatCoins(item.v)} credited to your balance</>),
                              });
                            }}
                            className="shrink-0 rounded-md border border-amber-400/35 bg-amber-400/10 px-1.5 py-0.5 font-display text-[10px] font-black text-amber-300 transition-all hover:bg-amber-400/25"
                            aria-label={`Sell ${shortName} for ${item.v} coins`}
                          >
                            Sell ${formatCoins(item.v)}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
                {shown.length === 0 && (
                  <div className="col-span-2 flex flex-col items-center justify-center gap-2 py-10 text-center">
                    <Search className="h-7 w-7 text-white/20" />
                    <p className="text-sm font-bold text-white/55">No items match</p>
                    <p className="text-xs text-white/35">Try another search, rarity or sort — nothing was sold.</p>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
