"use client";

/**
 * USER SPEC: the hero badge text ("The CS2-style case opening site — demo
 * with virtual coins") is GONE — the hero keeps only the sr-only h1 for
 * semantics; the visual is the global corridor background alone.
 */
export function Hero() {
  return (
    <section className="relative overflow-hidden" aria-label="Hero">
      <div className="relative mx-auto max-w-4xl px-4 pb-2 pt-2">
        <h1 className="sr-only">Open cases. Win legendary skins.</h1>
      </div>
    </section>
  );
}
