"use client";

import Image from "next/image";
import { CASE_IMAGE_SLUGS, CASE_IMAGE_SIZE, caseImagePath } from "@/lib/case-images";
import { DESIGN_ART } from "@/lib/community-designs";
import { cn } from "@/lib/utils";
import { CaseArt } from "./CaseArt";

/**
 * Case artwork renderer — prefers the designed crate image for the case
 * (public/cases/<slug>.webp) and transparently falls back to the procedural
 * SVG art (CaseArt) for cases that have no image yet (currently the 10
 * Farm cases). Sizing matches the old SVG usage: width-driven (w-full),
 * height scales by the shared 800x615 canvas aspect ratio.
 */
export function CaseImage({
  caseId,
  alt,
  color,
  color2,
  className,
  sizes = "(max-width: 768px) 45vw, 320px",
  priority = false,
  communityDesign,
}: {
  caseId: string;
  alt: string;
  color: string;
  color2: string;
  className?: string;
  sizes?: string;
  priority?: boolean;
  /** USER SPEC (Task 142): player-built cases render their chosen crate
   *  artwork (communitycasered/white/yellow.png) instead of the SVG art. */
  communityDesign?: "red" | "white" | "yellow";
}) {
  // USER SPEC (Task 142): community cases carry their uploaded artwork
  if (communityDesign) {
    return (
       
      <img
        src={DESIGN_ART[communityDesign]}
        alt={alt}
        draggable={false}
        className={cn("h-auto w-full select-none object-contain", className)}
      />
    );
  }

  if (!CASE_IMAGE_SLUGS.has(caseId)) {
    return <CaseArt color={color} color2={color2} className={className} />;
  }

  return (
    <Image
      src={caseImagePath(caseId)}
      alt={alt}
      width={CASE_IMAGE_SIZE.width}
      height={CASE_IMAGE_SIZE.height}
      sizes={sizes}
      priority={priority}
      draggable={false}
      className={cn("h-auto w-full select-none", className)}
    />
  );
}
