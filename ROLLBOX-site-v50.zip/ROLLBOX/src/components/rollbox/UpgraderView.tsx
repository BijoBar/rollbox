"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, PackageOpen, RotateCw, ShieldCheck, TrendingUp, Zap } from "lucide-react";
import { RARITY_META, formatCoins, type Rarity, type WeaponKind } from "@/lib/cases";
import { displayWearLabel, isWearableKind, wearColorOf, wearShortOf } from "@/lib/wear";
import { useSession } from "@/lib/session";
import { useCaseStore, type InvItem } from "@/lib/store";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { cn } from "@/lib/utils";
import { expandImg } from "@/lib/skin-img";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";
import { WeaponArt } from "./WeaponArt";

/* ===== USER SPEC (Task 174 — FULL VISUAL REBUILD) =====
   Same provably-fair ITEM game (Task 28): stake INVENTORY skins, pick a
   target multiplier, spin. chance = 0.95/multiplier (clamped 1.5–92%),
   a win lands the catalog skin closest to stake x multiplier. The roll is
   100% server-side; this UI only animates the verdict.

   The redesign turns the old flat two-color gauge into a REACTOR CORE:
   layered counter-rotating tick rings, a gradient glow chance-arc that
   morphs when the multiplier changes, shockwave rings + a prize card with
   a shine sweep, a glitch sting on loss, and animated numbers everywhere.
   (R37: the canvas spark/confetti layer is DELETED per user spec.) The aim
   math, timings, hold semantics and sounds contract are the old game's. */

// USER SPEC (Task 31/142): the target multipliers — 1.05 is the near-sure
// grind step (90.5% win), the maximum is 10X.
const MULTIPLIERS = [1.05, 1.5, 2, 3, 5, 10];

/** USER SPEC (R38): the maximum total skin value one spin may stake —
 *  raised from the Task-177 $350 to $1000. The server enforces the same cap. */
const STAKE_CAP = 1000;

/** same formula the server enforces */
const chanceOf = (mult: number) => Math.min(0.92, Math.max(0.015, 0.95 / mult));

/** risk ramp — the accent color of each charge cell (emerald = safe, rose = greedy) */
const RISK: Record<number, string> = {
  1.05: "#34d399",
  1.5: "#a3e635",
  2: "#facc15",
  3: "#fb923c",
  5: "#f87171",
  10: "#f43f5e",
};

/** the spin choreography length — transition + verdict timeout share it.
 *  USER SPEC (Task 177): 12 SECONDS of spin — roughly constant speed for the
 *  first ~6 seconds, then a LONG, SLOW deceleration for the last ~6 so the
 *  outcome hangs in the air and the tension builds. */
const SPIN_MS = 12000;
/** the matching easing: fast start, holds the pace to ~half, eases to a full
 *  stop (control points tuned so ~75% of the turn happens in the first 6s). */
const SPIN_EASE = "cubic-bezier(0.3, 0.5, 0.2, 1)";

interface GrantedSkin {
  id: string;
  n: string;
  w: string;
  r: string;
  v: number;
  img: string | null;
}

interface SpinResult {
  win: boolean;
  stake: number;
  target: number;
  mult: number;
  removed: number;
  granted: GrantedSkin | null;
}

/** Catalog render with SVG-art fallback (inventory snapshots, not SKINS-map entries). */
function StakeArt({ item, className }: { item: InvItem; className?: string }) {
  const [failed, setFailed] = useState(false);
  const url = expandImg(item.img);
  if (!url || failed) {
    return (
      <WeaponArt
        kind={(item.a ?? "ak") as WeaponKind}
        colors={[RARITY_META[item.r]?.color ?? "#8882a8", "#1a1426"]}
        className={cn("object-contain", className)}
      />
    );
  }
  return (
    <img
      src={url}
      alt={item.n}
      loading="lazy"
      draggable={false}
      onError={() => setFailed(true)}
      className={cn("select-none object-contain", className)}
    />
  );
}

/** tiny rAF number tween — every displayed figure glides to its target */
function useSpringy(target: number, ms = 450) {
  const [v, setV] = useState(target);
  const curRef = useRef(target);
  useEffect(() => {
    const from = curRef.current;
    if (from === target) return;
    const t0 = performance.now();
    let raf = 0;
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / ms);
      const eased = 1 - Math.pow(1 - p, 3);
      const cur = from + (target - from) * eased;
      curRef.current = cur;
      setV(cur);
      if (p < 1) raf = requestAnimationFrame(step);
      else curRef.current = target;
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

/* ================================================================ */

export function UpgraderView() {
  const mounted = useMounted();
  const { player: me, refresh } = useSession();
  const { toast } = useToast();

  const inventory = useCaseStore((s) => s.inventory);
  const takeItem = useCaseStore((s) => s.takeItem);
  const setInvHold = useCaseStore((s) => s.setInvHold);

  const [selected, setSelected] = useState<string[]>([]);
  const [mult, setMult] = useState(2);
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [result, setResult] = useState<SpinResult | null>(null);
  const [history, setHistory] = useState<SpinResult[]>([]);
  // FX state: the short-lived hub flash (win rings / loss glitch) and a spin
  // counter for the charge bar. (R37: the canvas confetti burst is DELETED.)
  const [flash, setFlash] = useState<"win" | "loss" | null>(null);
  const [spinCount, setSpinCount] = useState(0);
  const flashTimer = useRef(0);
  // USER SPEC (Task 177): the big RESULT DISPLAY — the skin that CAN come out
  // (stake × multiplier), resolved by the SAME server lookup the spin uses.
  const [preview, setPreview] = useState<GrantedSkin | null>(null);
  // USER SPEC (R37): the YOUR STAKE display freezes the round's staked skins
  // from spin start to end of game — even though the picker itself is cleared
  // the moment the stake commits — and on a WIN it becomes the won skin.
  // USER SPEC (R38): on a LOSS the frozen skins dissolve in SMOKE (the
  // smoking flag below drives the dissolve; the timer empties the display).
  const [roundStake, setRoundStake] = useState<InvItem[] | null>(null);
  const [smoking, setSmoking] = useState(false);
  const smokeTimer = useRef(0);
  // USER SPEC (R38): a WIN auto-stakes the won skin — the granted prize is
  // remembered here until the inventory push lands it, then it becomes the
  // picker's selection ("Your stake" carries into the next round).
  const autoStakeRef = useRef<{ id: string; v: number } | null>(null);
  // the uids the picker held BEFORE the spin — the won row is the NEW uid
  // that was not in this set (row ids are random hex, so "newest first" is
  // not orderable; the snapshot makes the match exact even when the player
  // already owns the same skin)
  const preSpinUidsRef = useRef<Set<string> | null>(null);

  const selItems = inventory.filter((i) => selected.includes(i.uid));
  const stake = selItems.reduce((s, i) => s + i.v, 0);
  // the YOUR STAKE panel's source: the frozen round stake while a round (or
  // its verdict) is on the table, the live selection otherwise
  const stakeShown = roundStake ?? selItems;
  const shownStake = stakeShown.reduce((s, i) => s + i.v, 0);
  const chance = chanceOf(mult);
  const accent = RISK[mult] ?? "#34d399";

  // animated numbers — chance, stake and the potential prize all glide
  const chanceAnim = useSpringy(chance);
  const stakeAnim = useSpringy(stake);
  const shownStakeAnim = useSpringy(shownStake);
  const potentialAnim = useSpringy(stake > 0 ? stake * mult : 0);

  useEffect(
    () => () => {
      setInvHold(false); // unmount mid-spin: release
      window.clearTimeout(flashTimer.current);
      window.clearTimeout(smokeTimer.current);
    },
    [setInvHold],
  );

  /** USER SPEC: the prize must not land in the picker while the wheel still
   *  spins — inventory pushes are HELD until the wheel stops (Task 29). */
  const syncInventory = useCallback(async () => {
    try {
      const r = await fetch("/api/inventory", { cache: "no-store" });
      if (!r.ok) return;
      const data = (await r.json()) as { items?: unknown[] };
      useCaseStore.getState().setServerInventory((data.items ?? []) as never[]);
    } catch {
      /* the next push reconciles */
    }
  }, []);

  const toggle = useCallback(
    (uid: string) => {
      if (spinning) return;
      const item = inventory.find((i) => i.uid === uid);
      if (!item) return;
      // USER SPEC (R38): the stake is CAPPED at $1000 per spin — adding a
      // skin that would cross the line is refused with a clear message.
      if (!selected.includes(uid)) {
        const cur = selected.reduce((s, u) => s + (inventory.find((i) => i.uid === u)?.v ?? 0), 0);
        if (cur + item.v > STAKE_CAP) {
          sfx.error();
          toast({
            title: `Stake cap — up to $${STAKE_CAP} per spin`,
            description: "Deselect a skin or pick a cheaper one to stay under the cap.",
          });
          return;
        }
      }
      sfx.click();
      // USER SPEC (R37): picking a skin opens a FRESH round — the previous
      // verdict leaves the "Potential upgrade" display (nothing shows there
      // until the new pick's preview resolves) and the YOUR STAKE panel
      // returns to the live selection.
      setRoundStake(null);
      setResult(null);
      // R38: a fresh pick also cancels a running smoke dissolve
      window.clearTimeout(smokeTimer.current);
      setSmoking(false);
      setSelected((sel) => (sel.includes(uid) ? sel.filter((u) => u !== uid) : sel.length < 200 ? [...sel, uid] : sel));
    },
    [spinning, inventory, selected, toast],
  );

  // USER SPEC (Task 177): the potential prize preview — the catalog skin
  // CLOSEST to stake × multiplier, resolved by the server's own catalogNearest
  // (the exact lookup a win uses), debounced and aborted on change.
  // USER SPEC (R38): the SPINNING guard comes FIRST — when the wheel runs,
  // the "Potential upgrade" image HOLDS untouched until the verdict (the
  // old order cleared it the instant the committed stake emptied the picker,
  // so the promise vanished for the whole spin).
  useEffect(() => {
    if (spinning) return; // R38: the promised prize stays on the table all spin long
    if (stake <= 0) {
      setPreview(null);
      return;
    }
    const target = Math.round(stake * mult * 100) / 100;
    const ctrl = new AbortController();
    const t = window.setTimeout(() => {
      void (async () => {
        try {
          const r = await fetch(`/api/upgrader/preview?target=${target}`, { signal: ctrl.signal });
          if (!r.ok) return;
          const d = (await r.json()) as { prize: GrantedSkin | null };
          setPreview(d.prize ?? null);
        } catch {
          /* aborted or offline — the display just keeps the last promise */
        }
      })();
    }, 220);
    return () => {
      ctrl.abort();
      window.clearTimeout(t);
    };
  }, [stake, mult, spinning]);

  // USER SPEC (R38): the WON skin is AUTO-STAKED — the moment the inventory
  // push lands the granted prize (uid = the DB row id), it becomes the
  // picker's selection. This bypasses toggle() ON PURPOSE: the R37
  // fresh-round reset must NOT fire — the verdict stays on the table and the
  // stake display keeps showing the won skin, now as the live selection.
  useEffect(() => {
    if (spinning) return;
    const pend = autoStakeRef.current;
    if (!pend) return;
    const snap = preSpinUidsRef.current;
    const item = inventory.find(
      (i) => i.id === pend.id && Math.abs(i.v - pend.v) < 0.005 && (!snap || !snap.has(i.uid)),
    );
    if (!item) return; // the push has not landed yet — a later change retries
    autoStakeRef.current = null;
    preSpinUidsRef.current = null;
    setSelected((sel) => (sel.includes(item.uid) ? sel : [item.uid]));
  }, [inventory, spinning]);

  const spin = useCallback(async () => {
    if (spinning || !me) return;
    if (!selected.length) {
      toast({ title: "Pick at least one skin to upgrade" });
      return;
    }
    setSpinning(true);
    setResult(null);
    setFlash(null);
    // R38: a fresh round never starts inside a smoke dissolve
    window.clearTimeout(smokeTimer.current);
    setSmoking(false);
    // USER SPEC (R37): the YOUR STAKE display freezes with exactly the skins
    // the player staked — the picker itself empties below at commit time.
    setRoundStake(selItems.length ? selItems : null);
    setInvHold(true); // freeze the inventory until the wheel stops
    // R38: snapshot the pre-spin uids — the auto-stake matches the won skin
    // by "the NEW row the push lands" (exact even with duplicate skins)
    preSpinUidsRef.current = new Set(useCaseStore.getState().inventory.map((i) => i.uid));
    try {
      const r = await fetch("/api/upgrader", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uids: selected, multiplier: mult }),
      });
      const d = (await r.json()) as {
        win?: boolean;
        chance?: number;
        stake?: number;
        target?: number;
        removed?: number;
        granted?: GrantedSkin | null;
        error?: string;
      };
      if (!r.ok || typeof d.win !== "boolean") throw new Error(d.error ?? "The wheel jammed — try again");
      const win = d.win === true;

      // the stake is COMMITTED server-side — drop the items from the local
      // store at once (the "inventory" push lands the winner / reconciles)
      selected.forEach((uid) => takeItem(uid));
      setSelected([]);

      // USER SPEC (R37): a round-long SPIN SOUND is back — the whoosh layer
      // starts with the wheel, rides the 12-second energy curve (a full burn
      // for the first ~6s, then a slow decay that mirrors the wheel's own
      // deceleration) and ENDS exactly when the final result lands (spinEnd
      // in the verdict timeout below; the catch path ends it too — no leak,
      // the Task 175 lesson).
      setSpinCount((c) => c + 1);
      sfx.spinStart();
      sfx.spinEnergy(0.85);
      window.setTimeout(() => sfx.spinEnergy(0.8), 2600);
      window.setTimeout(() => sfx.spinEnergy(0.62), 6000);
      window.setTimeout(() => sfx.spinEnergy(0.44), 8200);
      window.setTimeout(() => sfx.spinEnergy(0.26), 10200);
      window.setTimeout(() => sfx.spinEnergy(0.14), 11400);

      // aim the pointer — the green arc STARTS at the pointer (12 o'clock)
      // and sweeps clockwise, so the arc-angle phi that ends under the tip is
      // exactly phi ∈ [0, arcDeg] green / (arcDeg, 360] dark. WIN aims 25-75%
      // INTO the green, LOSS 15-85% into the dark — provably inside for every
      // arc from 5.4° (1.5% chance) to 331.2° (92%).
      const arcDeg = (d.chance ?? chanceOf(mult)) * 360;
      const phi = win
        ? arcDeg * (0.25 + Math.random() * 0.5)
        : arcDeg + (360 - arcDeg) * (0.15 + Math.random() * 0.7);
      setRotation((prev) => {
        const base = ((360 - phi - (prev % 360)) % 360 + 360) % 360;
        // Task 177: 6 full turns across the 12-second spin — the first ~6s
        // burns ~75% of the distance, the last ~6s decays slowly into the aim
        return prev + 6 * 360 + base;
      });
      window.setTimeout(
        () => {
          const res: SpinResult = {
            win,
            stake: d.stake ?? 0,
            target: d.target ?? 0,
            mult,
            removed: d.removed ?? selected.length,
            granted: d.granted ?? null,
          };
          setResult(res);
          setHistory((h) => [res, ...h].slice(0, 10));
          // the round sound ends EXACTLY at the final result (USER SPEC R37)
          sfx.spinEnd();
          // verdict FX — hub flash + sting sounds (R37: canvas burst deleted)
          setFlash(win ? "win" : "loss");
          // USER SPEC (R37): on a WIN the YOUR STAKE display flips to the won
          // skin; USER SPEC (R38): on a LOSS the staked skins DISSOLVE IN
          // SMOKE — a beat of rising gray puffs, then the display empties.
          if (win && res.granted) {
            setRoundStake([
              {
                uid: `upg-won-${res.granted.id}`,
                id: res.granted.id,
                n: res.granted.n,
                w: res.granted.w,
                r: res.granted.r,
                p: 0,
                v: res.granted.v,
                img: res.granted.img,
                at: Date.now(),
              },
            ]);
            // USER SPEC (R38): the won skin is AUTO-STAKED — the moment the
            // inventory push lands it, it becomes the picker's selection and
            // "Your stake" carries straight into the next round.
            autoStakeRef.current = { id: res.granted.id, v: res.granted.v };
          } else if (!win) {
            setSmoking(true);
            window.clearTimeout(smokeTimer.current);
            smokeTimer.current = window.setTimeout(() => {
              setSmoking(false);
              setRoundStake(null);
            }, 1750);
          }
          window.clearTimeout(flashTimer.current);
          flashTimer.current = window.setTimeout(() => setFlash(null), 1200);
          if (win) {
            sfx.coins();
            sfx.win(mult >= 5);
            if (res.granted) sfx.revealSting(res.granted.r as Rarity);
          } else {
            sfx.error();
          }
          void refresh();
          setSpinning(false);
          // the wheel has STOPPED and the verdict is on the table — only now
          // release the inventory hold so the prize lands in the picker
          setInvHold(false);
          void syncInventory();
        },
        SPIN_MS + 150,
      );
    } catch (e) {
      sfx.spinEnd(); // defensive — a started round sound never outlives the round
      setInvHold(false);
      setSpinning(false);
      toast({ title: e instanceof Error ? e.message : "Could not spin" });
    }
  }, [spinning, me, selected, mult, toast, refresh, takeItem, setInvHold, syncInventory]);

  // ---------- gates ----------
  if (!mounted) {
    return (
      <SiteShell>
        <main className="flex min-h-[60vh] items-center justify-center" aria-label="Upgrader">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-emerald-500/30 border-t-emerald-400" />
        </main>
      </SiteShell>
    );
  }

  if (!me) {
    return (
      <SiteShell>
        <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4" aria-label="Upgrader">
          <div className="w-full max-w-md rounded-2xl border border-emerald-500/25 bg-[#0c1420]/90 p-8 text-center">
            <TrendingUp className="mx-auto mb-3 h-10 w-10 text-emerald-400/70" />
            <h1 className="font-display text-xl font-black text-white">The Upgrader</h1>
            <p className="mt-2 text-sm text-white/55">Sign in with Steam to upgrade your skins into bigger ones.</p>
            <Link href="/login" className="neon-btn mt-5 inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-white">
              Sign In
            </Link>
          </div>
        </main>
      </SiteShell>
    );
  }

  const arcDeg = chance * 360;
  const R = 132;
  const C = 2 * Math.PI * R;
  const rarColor = (r: string) => RARITY_META[r as Rarity]?.color ?? "#34d399";

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] overflow-x-hidden pb-20 pt-8" aria-label="Upgrader">
        <div className="relative mx-auto max-w-6xl px-4">
          {/* header */}
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mx-auto inline-flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/5 px-3.5 py-1 text-[9px] font-black uppercase tracking-[0.28em] text-emerald-300/70"
            >
              <ShieldCheck className="h-3 w-3" />
              Server-side · Provably fair
            </motion.div>
            <h1 className="font-display mt-2 flex items-center justify-center gap-2 text-2xl font-black tracking-wide text-white sm:text-3xl">
              <TrendingUp className="h-6 w-6 text-emerald-400 drop-shadow-[0_0_10px_rgba(52,211,153,0.9)]" />
              UPGR<span className="text-gradient-neon">ADER</span>
            </h1>
            <motion.span
              aria-hidden="true"
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="mx-auto mt-2 block h-px w-44 origin-center bg-gradient-to-r from-transparent via-emerald-400/70 to-transparent"
            />
            <p className="mt-2 text-xs font-semibold text-white/45">
              Stake skins from your inventory, pick a multiplier, charge the core — a win pays a skin worth stake × multiplier.
            </p>
          </div>

          <div className="mt-6 grid items-start gap-5 lg:grid-cols-[1fr_auto_1fr]">
            {/* ===== LEFT: the big STAKE display on top, the inventory below —
                USER SPEC (Task 177): "Your inventory" moved DOWN and a BIG
                DISPLAY of the selected skin stands above it ===== */}
            <div className="flex flex-col gap-4">
              <div
                data-testid="upgrader-stake-display"
                className="rounded-2xl border border-emerald-500/25 bg-[#0c1420]/80 p-4 shadow-[0_0_40px_rgba(0,0,0,0.35)] backdrop-blur-sm"
              >
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[11px] font-black uppercase tracking-widest text-white/50">Your stake</p>
                  {/* USER SPEC (R37): while the round's verdict is a win, the
                     stake display IS the won skin — say so on the chip. */}
                  {result?.win && !spinning && (
                    <span className="rounded-md border border-emerald-400/40 bg-emerald-400/10 px-2 py-0.5 text-[10px] font-black uppercase text-emerald-300">
                      won
                    </span>
                  )}
                  {stakeShown.length > 0 && (
                    <span className="rounded-md border border-emerald-400/30 bg-emerald-400/10 px-2 py-0.5 text-[10px] font-black text-emerald-300">
                      {stakeShown.length} skin{stakeShown.length === 1 ? "" : "s"}
                    </span>
                  )}
                </div>
                {stakeShown.length === 0 ? (
                  <div className="mt-3 grid h-28 place-items-center rounded-xl border border-dashed border-white/12 bg-white/[0.02] px-4 text-center">
                    <p className="text-[11px] font-bold leading-relaxed text-white/35">
                      Pick a skin from the inventory — it shows up here BIG
                    </p>
                  </div>
                ) : (
                  <div className="mt-3 flex flex-col items-center gap-1.5">
                    <div
                      className="relative flex h-24 items-center justify-center gap-2"
                      data-smoke={smoking ? "1" : "0"}
                    >
                      {stakeShown.slice(0, 3).map((item) => (
                        <StakeArt
                          key={item.uid}
                          item={item}
                          className={cn(
                            "max-h-24 w-auto max-w-32 drop-shadow-[0_0_18px_rgba(52,211,153,0.4)]",
                            smoking && "upg-smoke-item",
                          )}
                        />
                      ))}
                      {stakeShown.length > 3 && (
                        <span className="font-display grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/10 text-[11px] font-black text-white/80">
                          +{stakeShown.length - 3}
                        </span>
                      )}
                      {/* USER SPEC (R38): the LOSS dissolve — gray smoke puffs
                          rise while the staked skins blur away. Pure CSS,
                          compositor-run; the timer empties the display after. */}
                      {smoking && (
                        <>
                          {[-14, 0, 14].map((x, i) => (
                            <span
                              key={x}
                              aria-hidden="true"
                              className="upg-smoke-puff pointer-events-none absolute bottom-2 h-10 w-10 rounded-full bg-slate-300/25 blur-md"
                              style={{ left: `calc(50% + ${x}px - 20px)`, animationDelay: `${i * 0.18}s` }}
                            />
                          ))}
                          {[-7, 7].map((x, i) => (
                            <span
                              key={`b${x}`}
                              aria-hidden="true"
                              className="upg-smoke-puff pointer-events-none absolute bottom-6 h-7 w-7 rounded-full bg-slate-400/20 blur-sm"
                              style={{ left: `calc(50% + ${x}px - 14px)`, animationDelay: `${0.3 + i * 0.22}s` }}
                            />
                          ))}
                        </>
                      )}
                    </div>
                    <p className="max-w-full truncate text-xs font-bold text-white/80" dir="ltr" title={stakeShown.length === 1 ? stakeShown[0].n : undefined}>
                      {stakeShown.length === 1 ? stakeShown[0].n : `${stakeShown.length} skins staked`}
                    </p>
                    {/* R43 USER SPEC: the staked skin's exterior — in its color */}
                    {stakeShown.length === 1 && isWearableKind(stakeShown[0].w) && (
                      <p
                        className="text-[10px] font-black uppercase tracking-wider"
                        dir="ltr"
                        style={{ color: wearColorOf(stakeShown[0].wear) }}
                        title={`Exterior: ${displayWearLabel(stakeShown[0].wear, stakeShown[0].n)}`}
                      >
                        {displayWearLabel(stakeShown[0].wear, stakeShown[0].n)}
                      </p>
                    )}
                    <p className="font-display flex items-center gap-1 text-xl font-black text-amber-300 tabular-nums" dir="ltr">
                      <Coin className="h-4 w-4" />
                      {formatCoins(Math.round(shownStakeAnim * 100) / 100)}
                    </p>
                  </div>
                )}
              </div>

              {/* ===== inventory picker — moved BELOW the big display ===== */}
              <div className="rounded-2xl border border-emerald-500/25 bg-[#0c1420]/80 p-5 shadow-[0_0_40px_rgba(0,0,0,0.35)] backdrop-blur-sm">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[11px] font-black uppercase tracking-widest text-white/50">
                  {/* USER SPEC (Task 177): "Your inventory" → "Inventory" */}
                  Inventory — pick your stake
                </p>
                {selected.length > 0 && (
                  <button
                    type="button"
                    disabled={spinning}
                    onClick={() => {
                      sfx.click();
                      setSelected([]);
                      // USER SPEC (R37): an explicit clear opens a fresh round
                      setRoundStake(null);
                      setResult(null);
                      // R38: clearing also cancels a running smoke dissolve
                      window.clearTimeout(smokeTimer.current);
                      setSmoking(false);
                    }}
                    className="rounded-md border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[10px] font-black text-white/50 transition-colors hover:bg-white/10 hover:text-white disabled:opacity-50"
                  >
                    CLEAR ({selected.length})
                  </button>
                )}
              </div>

              {inventory.length === 0 ? (
                <div className="flex flex-col items-center gap-3 py-10 text-center">
                  <div className="grid h-16 w-16 place-items-center rounded-full border border-dashed border-white/15 bg-white/[0.03]">
                    <PackageOpen className="h-7 w-7 text-white/25" />
                  </div>
                  <p className="text-sm font-bold text-white/70">Your inventory is empty</p>
                  <p className="max-w-64 text-xs leading-relaxed text-white/40">
                    Win skins in cases and battles, or trade coins for any skin on the EXCHANGE — then bring
                    them here and roll them into something bigger.
                  </p>
                  <Link
                    href="/skins"
                    onClick={() => sfx.click()}
                    className="mt-1 inline-flex items-center gap-2 rounded-xl border border-amber-400/40 bg-amber-400/10 px-4 py-2 text-xs font-black text-amber-300 transition-all hover:bg-amber-400/20"
                  >
                    Open the Exchange
                  </Link>
                </div>
              ) : (
                <>
                  <div className="mt-3 grid max-h-105 grid-cols-2 content-start gap-2 overflow-y-auto pr-1 sm:grid-cols-3">
                    {inventory.map((item, idx) => {
                      const active = selected.includes(item.uid);
                      const rar = RARITY_META[item.r]?.color ?? "#8882a8";
                      const shortName = item.n.includes("|") ? item.n.split("|")[1].trim() : item.n;
                      return (
                        <motion.button
                          key={item.uid}
                          type="button"
                          disabled={spinning}
                          aria-pressed={active}
                          aria-label={`Stake ${item.n} (${item.v} coins)`}
                          onClick={() => toggle(item.uid)}
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: Math.min(idx * 0.02, 0.35), duration: 0.25 }}
                          className={cn(
                            "group relative overflow-hidden rounded-xl border bg-[#130d22] p-2 pl-2.5 text-left transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_22px_-8px_var(--rar)] disabled:cursor-not-allowed disabled:opacity-60",
                            active
                              ? "border-emerald-400 shadow-[0_0_16px_rgba(52,211,153,0.4)]"
                              : "hover:border-white/30",
                          )}
                          style={{ "--rar": rar, borderColor: active ? undefined : `${rar}55` } as React.CSSProperties}
                        >
                          {/* rarity strip */}
                          <span aria-hidden="true" className="absolute inset-y-1 left-0 w-[3px] rounded-full" style={{ background: rar, opacity: 0.7 }} />
                          {/* selected marker */}
                          {active && (
                            <motion.span
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ type: "spring", stiffness: 500, damping: 22 }}
                              className="absolute right-1.5 top-1.5 z-10 grid h-4.5 w-4.5 place-items-center rounded-full bg-emerald-400 text-[9px] font-black text-black shadow-[0_0_10px_rgba(52,211,153,0.8)]"
                            >
                              ✓
                            </motion.span>
                          )}
                          <div className="flex h-12 items-center justify-center">
                            <StakeArt item={item} className="max-h-12 w-full" />
                          </div>
                          <p className="mt-1 truncate text-[10px] font-bold text-white/85" dir="ltr" title={item.n}>
                            {shortName}
                          </p>
                          {/* R43 USER SPEC: the exterior is ALWAYS listed — in its color */}
                          {isWearableKind(item.w) && (
                            <p
                              className="truncate text-[9px] font-black uppercase tracking-wider"
                              dir="ltr"
                              style={{ color: wearColorOf(item.wear) }}
                              title={`Exterior: ${displayWearLabel(item.wear, item.n)}`}
                            >
                              {displayWearLabel(item.wear, item.n)}
                            </p>
                          )}
                          <p className="flex items-center gap-1 text-[10px] font-black text-amber-300">
                            <Coin className="h-2.5 w-2.5" />
                            {formatCoins(item.v)}
                          </p>
                        </motion.button>
                      );
                    })}
                  </div>
                  <div className="mt-3 flex items-center justify-between rounded-xl border border-white/10 bg-black/30 px-3 py-2">
                    <span className="text-[11px] font-bold text-white/50" dir="ltr">
                      {selected.length === 0 ? "Nothing staked yet" : `${selected.length} skin${selected.length === 1 ? "" : "s"} staked`}
                    </span>
                    <motion.span
                      key={stake}
                      initial={{ scale: 1.18 }}
                      animate={{ scale: 1 }}
                      className="font-display flex items-center gap-1 text-sm font-black text-emerald-300 tabular-nums"
                      dir="ltr"
                    >
                      <Coin className="h-3.5 w-3.5" />
                      {formatCoins(Math.round(stakeAnim * 100) / 100)}
                    </motion.span>
                  </div>
                  {/* USER SPEC (Task 177): the per-spin stake cap, visible on the panel */}
                  <p className="mt-1.5 text-center text-[10px] font-black uppercase tracking-widest text-white/30" dir="ltr">
                    Max stake ${STAKE_CAP} per spin
                  </p>
                </>
              )}
              </div>
            </div>

            {/* ===== the reactor core ===== */}
            <div className="relative mx-auto w-full max-w-[340px]" data-testid="upgrader-wheel">
              {/* breathing aura — intensity follows the odds */}
              <div
                aria-hidden="true"
                className="upg-aura pointer-events-none absolute -inset-9 rounded-full blur-2xl"
                style={{ background: `radial-gradient(circle, ${accent}2e 0%, transparent 65%)`, opacity: 0.35 + chance * 0.55 }}
              />

              <motion.div
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.35 }}
                className={cn("relative grid place-items-center", flash === "loss" && "upg-glitch")}
              >
                <svg viewBox="0 0 340 340" className="h-auto w-full max-w-[340px]">
                  <defs>
                    <linearGradient id="upgArc" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#34d399" />
                      <stop offset="100%" stopColor={accent} />
                    </linearGradient>
                    <filter id="upgGlow" x="-40%" y="-40%" width="180%" height="180%">
                      <feGaussianBlur stdDeviation="4" result="b" />
                      <feMerge>
                        <feMergeNode in="b" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                  </defs>

                  {/* ambient counter-rotating tick ring — spins fast while charging */}
                  <g style={{ animation: `upg-spin ${spinning ? 2.6 : 26}s linear infinite`, transformOrigin: "170px 170px" }}>
                    {Array.from({ length: 48 }).map((_, i) => (
                      <line
                        key={i}
                        x1="170"
                        y1="8"
                        x2="170"
                        y2={i % 4 === 0 ? 18 : 13}
                        stroke={i % 4 === 0 ? "#ffffff26" : "#ffffff12"}
                        strokeWidth={i % 4 === 0 ? 2 : 1.4}
                        transform={`rotate(${i * 7.5} 170 170)`}
                      />
                    ))}
                  </g>
                  <circle
                    cx="170"
                    cy="170"
                    r="146"
                    fill="none"
                    stroke="#1b2740"
                    strokeWidth="1"
                    strokeDasharray="3 9"
                    style={{ animation: "upg-spin-rev 40s linear infinite", transformOrigin: "170px 170px" }}
                  />

                  {/* track + aim group */}
                  <circle cx="170" cy="170" r={R} fill="none" stroke="#0e1622" strokeWidth="24" />
                  <g
                    style={{
                      transform: `rotate(${rotation}deg)`,
                      transformOrigin: "170px 170px",
                      transition: spinning ? `transform ${SPIN_MS}ms ${SPIN_EASE}` : "none",
                    }}
                  >
                    <circle cx="170" cy="170" r={R} fill="none" stroke="#241219" strokeWidth="24" />
                    {/* the arc STARTS at the pointer (12 o'clock): SVG dashes
                        begin at 3 o'clock, so rotate -90° — the aim math then
                        lands arc-angle phi exactly under the tip */}
                    <circle
                      cx="170"
                      cy="170"
                      r={R}
                      fill="none"
                      stroke="url(#upgArc)"
                      strokeWidth="24"
                      strokeLinecap="round"
                      strokeDasharray={`${(C * arcDeg) / 360} ${C}`}
                      transform="rotate(-90 170 170)"
                      filter="url(#upgGlow)"
                      className="transition-all duration-500"
                    />
                    <circle
                      cx="170"
                      cy="170"
                      r="117"
                      fill="none"
                      stroke={accent}
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      opacity="0.3"
                      strokeDasharray={`${(C * arcDeg) / 360 * 0.92} ${C}`}
                      transform="rotate(-90 170 170)"
                      className="transition-all duration-500"
                    />
                  </g>

                  {/* hub */}
                  <circle cx="170" cy="170" r="86" fill="#0a0f16" stroke="#1d2940" strokeWidth="2" />
                  <circle
                    cx="170"
                    cy="170"
                    r="76"
                    fill="none"
                    stroke={accent}
                    strokeOpacity="0.25"
                    strokeWidth="1.5"
                    strokeDasharray="2 6"
                    style={{ animation: "upg-spin-rev 34s linear infinite", transformOrigin: "170px 170px" }}
                  />
                </svg>

                {/* the pointer */}
                <div className="absolute left-1/2 top-0 z-30 -translate-x-1/2 -translate-y-1.5" aria-hidden="true">
                  <div className="h-0 w-0 border-x-[10px] border-t-[17px] border-x-transparent border-t-amber-300 drop-shadow-[0_0_10px_rgba(240,185,11,0.9)]" />
                </div>

                {/* the hub readout */}
                <div className="pointer-events-none absolute inset-0 grid place-items-center">
                  <div className="text-center" dir="ltr">
                    <p className="text-[9px] font-black uppercase tracking-[0.35em] text-white/35">Target</p>
                    <motion.p
                      key={mult}
                      initial={{ scale: 0.55, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ type: "spring", stiffness: 320, damping: 18 }}
                      className="font-display text-5xl font-black leading-none tabular-nums"
                      style={{ color: accent, textShadow: `0 0 22px ${accent}66` }}
                    >
                      {mult}×
                    </motion.p>
                    <p className="mt-1.5 text-[11px] font-black uppercase tracking-widest text-white/50 tabular-nums" data-testid="upgrader-chance">
                      {(chanceAnim * 100).toFixed(1)}% win
                    </p>
                    <div className="mx-auto mt-2 h-px w-16 bg-white/10" />
                    <p className="font-display mt-1.5 flex items-center justify-center gap-1 text-sm font-black text-amber-300 tabular-nums">
                      <Coin className="h-3 w-3" />
                      {formatCoins(Math.round(shownStakeAnim * 100) / 100)}
                    </p>
                    <p className="text-[8px] font-black uppercase tracking-[0.3em] text-white/30">stake</p>
                  </div>
                </div>
              </motion.div>

              {/* verdict FX overlays */}
              <AnimatePresence>
                {flash === "win" && (
                  <motion.div
                    key="wflash"
                    aria-hidden="true"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0, 0.55, 0] }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.9, times: [0, 0.25, 1] }}
                    className="pointer-events-none absolute -inset-8 rounded-full"
                    style={{ background: "radial-gradient(circle, rgba(52,211,153,0.4) 0%, transparent 65%)" }}
                  />
                )}
                {flash === "loss" && (
                  <motion.div
                    key="lflash"
                    aria-hidden="true"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0, 0.4, 0] }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.8, times: [0, 0.3, 1] }}
                    className="pointer-events-none absolute -inset-8 rounded-full"
                    style={{ background: "radial-gradient(circle, rgba(239,68,68,0.38) 0%, transparent 65%)" }}
                  />
                )}
              </AnimatePresence>
              {flash === "win" && (
                <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-10">
                  {[0, 0.16, 0.32].map((d) => (
                    <span key={d} className="upg-ring" style={{ animationDelay: `${d}s` }} />
                  ))}
                </div>
              )}

              {/* R37: the canvas spark/confetti layer is DELETED per user spec */}

              {/* result banner */}
              <div className="relative z-30 mt-5 flex min-h-24 items-start justify-center" data-testid="upgrader-result">
                <AnimatePresence mode="wait">
                  {result && !spinning && (
                    <motion.div
                      key={`res-${spinCount}`}
                      initial={{ opacity: 0, y: 18, scale: 0.9 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -10, scale: 0.96 }}
                      transition={{ type: "spring", stiffness: 260, damping: 20 }}
                      className="w-full"
                    >
                      {result.win && result.granted ? (
                        <div
                          className="relative w-full overflow-hidden rounded-2xl border px-4 py-3"
                          style={{
                            borderColor: `${rarColor(result.granted.r)}66`,
                            background: `linear-gradient(135deg, ${rarColor(result.granted.r)}1f, rgba(12,20,32,0.92))`,
                          }}
                        >
                          <span
                            aria-hidden="true"
                            className="pointer-events-none absolute inset-y-0 w-1/3 bg-gradient-to-r from-transparent via-white/15 to-transparent"
                            style={{ animation: "upg-shine 1.7s ease-in-out 0.25s 2 both" }}
                          />
                          <div className="flex items-center gap-3">
                            {result.granted.img ? (
                              <img
                                src={result.granted.img}
                                alt={result.granted.n}
                                className="h-14 w-14 shrink-0 object-contain drop-shadow-[0_0_12px_rgba(52,211,153,0.35)]"
                                draggable={false}
                              />
                            ) : (
                              <ArrowUpRight className="h-6 w-6 shrink-0 text-emerald-300" />
                            )}
                            <div className="min-w-0 flex-1" dir="ltr">
                              <p className="font-display text-sm font-black text-emerald-200">UPGRADED!</p>
                              <p className="truncate text-[11px] font-bold text-white/75" title={result.granted.n}>
                                {result.granted.n}
                              </p>
                              {/* R43 USER SPEC: the prize's exterior — in its color (catalog base -> Field-Tested) */}
                              <p
                                className="text-[9px] font-black uppercase tracking-wider"
                                style={{ color: wearColorOf(null) }}
                                title="Exterior: Field-Tested"
                              >
                                Field-Tested
                              </p>
                              <p className="font-display flex items-center gap-1 text-[11px] font-black text-amber-300">
                                <Coin className="h-2.5 w-2.5" />
                                {formatCoins(result.granted.v)}
                              </p>
                            </div>
                            <span
                              className="font-display shrink-0 -rotate-6 rounded-md border px-1.5 py-0.5 text-[9px] font-black uppercase tracking-widest"
                              style={{ borderColor: rarColor(result.granted.r), color: rarColor(result.granted.r) }}
                            >
                              new
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="upg-glitch mx-auto flex w-fit items-center gap-2.5 rounded-2xl border border-red-500/40 bg-red-500/10 px-4 py-3">
                          <span className="font-display grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-red-500/20 text-xs font-black text-red-300">
                            L
                          </span>
                          <span className="font-display text-sm font-black text-red-300" dir="ltr">
                            FAILED — {result.removed} skin{result.removed === 1 ? "" : "s"} (
                            {formatCoins(result.stake)}) gone
                          </span>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* ===== RIGHT: the big RESULT display on top, PICK UPGRADE below —
                USER SPEC (Task 177): the Target multiplier moved DOWN on the
                same line as Inventory, and the skin that CAN come out stands
                BIG in the result display above it ===== */}
            <div className="flex flex-col gap-4">
              <div
                data-testid="upgrader-outcome-display"
                className="rounded-2xl border bg-[#0c1420]/80 p-4 shadow-[0_0_40px_rgba(0,0,0,0.35)] backdrop-blur-sm transition-colors"
                style={{
                  borderColor: result
                    ? result.win
                      ? `${rarColor(result.granted?.r ?? "covert")}66`
                      : "rgba(239,68,68,0.45)"
                    : preview
                      ? `${rarColor(preview.r)}55`
                      : "rgba(52,211,153,0.25)",
                }}
              >
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[11px] font-black uppercase tracking-widest text-white/50">
                    {result ? (result.win ? "Result — upgraded!" : "Result — failed") : "Potential upgrade"}
                  </p>
                  {!result && preview && (
                    <span
                      className="rounded-md border px-2 py-0.5 text-[10px] font-black"
                      style={{ borderColor: `${rarColor(preview.r)}88`, color: rarColor(preview.r) }}
                      dir="ltr"
                    >
                      at {mult}×
                    </span>
                  )}
                </div>

                {result && !result.win ? (
                  /* the verdict — a loss, big and honest */
                  <div className="mt-3 flex h-28 flex-col items-center justify-center gap-1 rounded-xl border border-red-500/30 bg-red-500/[0.07] px-4">
                    <span className="font-display grid h-12 w-12 place-items-center rounded-xl bg-red-500/20 text-xl font-black text-red-300">
                      L
                    </span>
                    <p className="text-xs font-black uppercase tracking-widest text-red-300" dir="ltr">
                      FAILED — {result.removed} skin{result.removed === 1 ? "" : "s"} ({formatCoins(result.stake)}) gone
                    </p>
                  </div>
                ) : result?.win && result.granted ? (
                  /* the verdict — the landed prize, big and shining */
                  <div className="mt-3 flex flex-col items-center gap-1.5">
                    <div className="flex h-24 items-center justify-center">
                      {result.granted.img ? (
                        <img
                          src={result.granted.img}
                          alt={result.granted.n}
                          className="max-h-24 w-auto max-w-44 object-contain drop-shadow-[0_0_26px_rgba(52,211,153,0.55)]"
                          draggable={false}
                        />
                      ) : (
                        <ArrowUpRight className="h-10 w-10 text-emerald-300" />
                      )}
                    </div>
                    <p className="max-w-full truncate text-xs font-bold text-white/85" dir="ltr" title={result.granted.n}>
                      {result.granted.n}
                    </p>
                    {/* R43 USER SPEC: the prize's exterior — in its color */}
                    <p className="text-[10px] font-black uppercase tracking-wider" style={{ color: wearColorOf(null) }} title="Exterior: Field-Tested">
                      Field-Tested
                    </p>
                    <p className="font-display flex items-center gap-1 text-xl font-black text-emerald-300 tabular-nums" dir="ltr">
                      <Coin className="h-4 w-4" />
                      {formatCoins(result.granted.v)}
                    </p>
                  </div>
                ) : preview ? (
                  /* the promise — what CAN come out at stake × multiplier */
                  <div className="mt-3 flex flex-col items-center gap-1.5">
                    <div className="flex h-24 items-center justify-center">
                      {preview.img ? (
                        <img
                          src={preview.img}
                          alt={preview.n}
                          className="max-h-24 w-auto max-w-44 object-contain drop-shadow-[0_0_22px_rgba(240,185,11,0.35)]"
                          draggable={false}
                        />
                      ) : (
                        <ArrowUpRight className="h-10 w-10 text-emerald-300/70" />
                      )}
                    </div>
                    <p className="max-w-full truncate text-xs font-bold text-white/85" dir="ltr" title={preview.n}>
                      {preview.n}
                    </p>
                    {/* R43 USER SPEC: the promised prize's exterior — in its color */}
                    <p className="text-[10px] font-black uppercase tracking-wider" style={{ color: wearColorOf(null) }} title="Exterior: Field-Tested">
                      Field-Tested
                    </p>
                    <p className="font-display flex items-center gap-1 text-xl font-black text-amber-300 tabular-nums" dir="ltr">
                      <Coin className="h-4 w-4" />
                      {formatCoins(preview.v)}
                    </p>
                  </div>
                ) : (
                  <div className="mt-3 grid h-28 place-items-center rounded-xl border border-dashed border-white/12 bg-white/[0.02] px-4 text-center">
                    <p className="text-[11px] font-bold leading-relaxed text-white/35">
                      Pick skins to preview the prize you can win
                    </p>
                  </div>
                )}
              </div>

            <div className="space-y-5">
              <div className="rounded-2xl border border-emerald-500/25 bg-[#0c1420]/80 p-5 shadow-[0_0_40px_rgba(0,0,0,0.35)] backdrop-blur-sm">
                {/* USER SPEC (Task 177): "TARGET MULTIPLIER" → "PICK UPGRADE" */}
                <p className="text-[11px] font-black uppercase tracking-widest text-white/50">Pick upgrade</p>
                <div className="mt-2.5 grid grid-cols-3 gap-2">
                  {MULTIPLIERS.map((m) => {
                    const active = mult === m;
                    const c = RISK[m] ?? "#34d399";
                    return (
                      <button
                        key={m}
                        type="button"
                        disabled={spinning}
                        aria-pressed={active}
                        onClick={() => {
                          sfx.click();
                          setMult(m);
                        }}
                        className={cn(
                          "relative overflow-hidden rounded-xl border px-1 py-2 text-center transition-all disabled:cursor-not-allowed disabled:opacity-50",
                          active
                            ? "shadow-[0_0_18px_-2px_var(--acc)]"
                            : "border-white/10 bg-white/[0.04] hover:border-white/25 hover:bg-white/10",
                        )}
                        style={active ? ({ "--acc": c, borderColor: `${c}88`, background: `${c}14` } as React.CSSProperties) : undefined}
                      >
                        <span className="font-display block text-base font-black leading-none" style={active ? { color: c } : undefined} dir="ltr">
                          {m}×
                        </span>
                        <span className="mt-0.5 block text-[9px] font-bold tabular-nums text-white/50" dir="ltr">
                          {(chanceOf(m) * 100).toFixed(1)}%
                        </span>
                        {/* live chance meter */}
                        <span
                          aria-hidden="true"
                          className="absolute inset-x-0 bottom-0 h-[3px] transition-opacity duration-300"
                          style={{ background: `linear-gradient(90deg, ${c}, ${c}44)`, width: `${chanceOf(m) * 100}%`, opacity: active ? 0.9 : 0.25 }}
                        />
                      </button>
                    );
                  })}
                </div>

                <div className="mt-4 space-y-1.5 rounded-xl border border-white/10 bg-black/30 px-3 py-2.5" dir="ltr">
                  <p className="flex items-center justify-between text-xs font-bold text-white/60">
                    <span>Win chance</span>
                    <span className="font-display font-black tabular-nums" style={{ color: accent }} data-testid="upgrader-chance-panel">
                      {(chanceAnim * 100).toFixed(2)}%
                    </span>
                  </p>
                  <p className="flex items-center justify-between text-xs font-bold text-white/60">
                    <span>Potential skin value</span>
                    <span className="font-display font-black tabular-nums text-amber-300">
                      {stake > 0 ? (
                        <>
                          <Coin className="mr-1 inline h-3 w-3" />
                          {formatCoins(Math.round(potentialAnim * 100) / 100)}
                        </>
                      ) : (
                        "—"
                      )}
                    </span>
                  </p>
                  <p className="flex items-center justify-between text-xs font-bold text-white/60">
                    <span>Stake</span>
                    <span className="font-display font-black tabular-nums text-emerald-300">
                      {selected.length > 0 ? (
                        <>
                          <Coin className="mr-1 inline h-3 w-3" />
                          {formatCoins(Math.round(stakeAnim * 100) / 100)} · {selected.length} skin{selected.length === 1 ? "" : "s"}
                        </>
                      ) : (
                        "—"
                      )}
                    </span>
                  </p>
                </div>

                <button
                  type="button"
                  data-testid="upgrader-spin"
                  disabled={spinning || selected.length === 0 || stake > STAKE_CAP}
                  onClick={() => void spin()}
                  className={cn(
                    "relative mt-4 h-14 w-full overflow-hidden rounded-2xl text-sm font-black transition-all disabled:cursor-not-allowed",
                    spinning || selected.length === 0
                      ? "border border-white/10 bg-white/[0.04] text-white/35"
                      : "bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400 text-[#052018] shadow-[0_0_28px_-4px_rgba(52,211,153,0.55)] hover:brightness-110 active:scale-[0.99]",
                  )}
                >
                  {selected.length > 0 && !spinning && (
                    <span
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-y-0 w-1/4 bg-white/25 blur-md"
                      style={{ animation: "upg-shine 2.6s ease-in-out infinite" }}
                    />
                  )}
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    {spinning ? (
                      <>
                        <RotateCw className="h-4 w-4 animate-spin" />
                        UPGRADING…
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4" />
                        {selected.length === 0
                          ? "PICK SKINS TO UPGRADE"
                          : `UPGRADE ${selected.length} SKIN${selected.length === 1 ? "" : "S"}`}
                      </>
                    )}
                  </span>
                  {/* USER SPEC (Task 184): the spin progress bar is DELETED —
                      the button shows UPGRADING… while the core resolves, no
                      loading fill underneath anymore. */}
                </button>

                <Link
                  href="/provably-fair"
                  onClick={() => sfx.click()}
                  className="mt-3 flex items-center justify-center gap-1.5 text-[10px] font-bold text-white/35 transition-colors hover:text-emerald-300/80"
                >
                  <ShieldCheck className="h-3 w-3" />
                  Provably fair — every spin is verifiable
                </Link>
              </div>

              {/* history */}
              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                <p className="text-[11px] font-black uppercase tracking-widest text-white/50">Last 10 upgrades</p>
                {history.length === 0 ? (
                  <p className="mt-3 text-xs font-semibold text-white/35">No spins yet — the core is warm.</p>
                ) : (
                  <ul className="mt-3 space-y-1.5">
                    {history.map((h, i) => (
                      <motion.li
                        key={`${history.length}-${i}`}
                        initial={{ opacity: 0, x: 14 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.04 }}
                        className="flex items-center gap-2 rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5"
                      >
                        <span
                          className={cn(
                            "grid h-6 w-6 shrink-0 place-items-center rounded-md text-[10px] font-black",
                            h.win ? "bg-emerald-500/20 text-emerald-300" : "bg-red-500/15 text-red-300",
                          )}
                        >
                          {h.win ? "W" : "L"}
                        </span>
                        <span className="flex-1 truncate text-[11px] font-bold text-white/70" dir="ltr">
                          {h.mult}× @ {formatCoins(h.stake)}
                          {h.win && h.granted ? ` → ${h.granted.n}` : ""}
                        </span>
                        {/* R43 USER SPEC: the granted skin's exterior code — in its color */}
                        {h.win && h.granted && (
                          <span
                            className="shrink-0 text-[9px] font-black uppercase"
                            style={{ color: wearColorOf(null) }}
                            title="Exterior: Field-Tested"
                          >
                            {wearShortOf(null)}
                          </span>
                        )}
                        <span
                          className={cn(
                            "font-display shrink-0 text-[11px] font-black tabular-nums",
                            h.win ? "text-emerald-300" : "text-red-300",
                          )}
                          dir="ltr"
                        >
                          {h.win && h.granted ? (
                            <>
                              +<Coin className="mx-0.5 inline h-2.5 w-2.5" />
                              {formatCoins(h.granted.v)}
                            </>
                          ) : (
                            <>
                              −<Coin className="mx-0.5 inline h-2.5 w-2.5" />
                              {formatCoins(h.stake)}
                            </>
                          )}
                        </span>
                      </motion.li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
            </div>
          </div>
        </div>
      </main>
    </SiteShell>
  );
}
