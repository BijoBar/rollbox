"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { LifeBuoy, Send, ShieldCheck, X } from "lucide-react";
import { useSession } from "@/lib/session";
import { useRealtimeEvent } from "@/lib/realtime";
import { useMounted } from "@/hooks/use-mounted";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";
import { SUPPORT_FAQ } from "@/lib/support-faq";

/* ===== USER SPEC (Task 136): the SUPPORT CHAT widget =====
   A floating "?" button at the bottom-right of EVERY page. Clicking it opens
   the support chat:
     • the ROLLBOX AI answers COMMON questions instantly (canned answers from
       src/lib/support-faq.ts — quick chips + free-text keyword matching),
     • "Request human support" opens a SUPPORT CASE — the red alert pops on
       the admins' screens and a human agent replies right in this chat,
     • replies arrive live (realtime push + a slow poll as the fallback).
   USER SPEC (Task 142): ADMINS see the widget TOO — everyone gets the "?";
   admins additionally work from the ADMIN PANEL inbox. */

interface SupportMessageRow {
  id: string;
  role: "player" | "ai" | "admin";
  body: string;
  at: string;
}

/** USER SPEC (Task 138): AI answers may embed an IN-SITE link written as
 * [text](/path) — e.g. the refund answer links the word "Exchange" to the
 * EXCHANGE page. Everything else renders as plain text; player/agent
 * messages are never parsed. Clicking a link navigates and closes the panel. */
function AiAnswerBody({ body, onNavigate }: { body: string; onNavigate: () => void }) {
  const parts = body.split(/(\[[^\]]+\]\(\/[a-z0-9/-]*\))/g);
  return (
    <>
      {parts.map((part, i) => {
        const m = part.match(/^\[([^\]]+)\]\(\/([a-z0-9/-]*)\)$/);
        if (!m) return <span key={i}>{part}</span>;
        return (
          <Link
            key={i}
            href={`/${m[2]}`}
            onClick={onNavigate}
            className="font-bold text-violet-300 underline decoration-violet-400/60 underline-offset-2 transition-colors hover:text-violet-200"
          >
            {m[1]}
          </Link>
        );
      })}
    </>
  );
}

export function SupportChatWidget() {
  const mounted = useMounted();
  const { player } = useSession();

  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<SupportMessageRow[]>([]);
  const [caseStatus, setCaseStatus] = useState<string | null>(null);
  const [unread, setUnread] = useState(0);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [requesting, setRequesting] = useState(false);
  const listRef = useRef<HTMLDivElement | null>(null);
  // USER SPEC (Task 177): live chat — every INCOMING (agent/AI) message plays
  // the ping sound. Seen-message ids guard against double pings; the first
  // load of the conversation is the backlog and stays silent.
  const seenIdsRef = useRef<Set<string>>(new Set());
  const backlogRef = useRef(true);
  const lastUnreadRef = useRef(0);
  const unreadArmedRef = useRef(false);

  /** Load the whole conversation (also marks the AI/agent messages read).
   *  Task 177: new incoming messages ping — the chat is LIVE, no refresh. */
  const loadMessages = useCallback(async () => {
    try {
      const r = await fetch("/api/support/messages", { cache: "no-store" });
      if (!r.ok) return;
      const d = (await r.json()) as { messages: SupportMessageRow[]; caseStatus: string | null };
      const rows = d.messages ?? [];
      const incoming = rows.filter((m) => m.role !== "player" && !seenIdsRef.current.has(m.id));
      for (const m of rows) seenIdsRef.current.add(m.id);
      setMessages(rows);
      setCaseStatus(d.caseStatus ?? null);
      setUnread(0);
      lastUnreadRef.current = 0;
      if (!backlogRef.current && incoming.length > 0) sfx.notify();
      backlogRef.current = false;
    } catch {
      /* keep the current view */
    }
  }, []);

  /** Cheap badge poll — never marks anything read. Task 177: a rising badge
   *  pings too, so the player hears a new reply even with the panel closed. */
  const loadUnread = useCallback(async () => {
    try {
      const r = await fetch("/api/support/unread", { cache: "no-store" });
      if (!r.ok) return;
      const d = (await r.json()) as { count: number };
      const count = d.count ?? 0;
      setUnread(count);
      if (unreadArmedRef.current && count > lastUnreadRef.current) sfx.notify();
      lastUnreadRef.current = count;
      unreadArmedRef.current = true;
    } catch {
      /* badge is cosmetic — ignore */
    }
  }, []);

  // badge keeps itself fresh while the panel is closed — Task 177: 8s → 5s
  useEffect(() => {
    if (!mounted || !player || open) return;
    void loadUnread();
    const t = window.setInterval(() => void loadUnread(), 5000);
    return () => window.clearInterval(t);
  }, [mounted, player, open, loadUnread]);

  // while the panel is OPEN a fast poll is the safety net under the realtime
  // push — Task 177: the chat must update LIVE, 6s → 3s
  useEffect(() => {
    if (!mounted || !player || !open) return;
    const t = window.setInterval(() => void loadMessages(), 3000);
    return () => window.clearInterval(t);
  }, [mounted, player, open, loadMessages]);

  // the agent replied / closed the case → refresh (panel open or badge).
  // Task 177: the push IS the live channel — the 3s/5s polls are the net.
  useRealtimeEvent("support_player", () => {
    if (open) void loadMessages();
    else void loadUnread();
  });

  const toggle = () => {
    sfx.click();
    setOpen((v) => {
      const next = !v;
      if (next) {
        backlogRef.current = true; // opening shows the backlog silently
        void loadMessages();
      }
      return next;
    });
  };

  const send = useCallback(
    async (text: string) => {
      const body = text.trim();
      if (!body || sending) return;
      setSending(true);
      setInput("");
      // optimistic player bubble — replaced by the server pair below
      const optimistic: SupportMessageRow = { id: `tmp_${Date.now()}`, role: "player", body, at: new Date().toISOString() };
      setMessages((prev) => [...prev, optimistic]);
      try {
        const r = await fetch("/api/support/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: body }),
        });
        if (!r.ok) throw new Error("failed");
        const d = (await r.json()) as { player: SupportMessageRow; ai: SupportMessageRow | null; caseStatus: string | null };
        // Task 177: register the server pair as seen so the 3s poll never
        // double-pings; the AI answer pings RIGHT AWAY (it is a new message)
        seenIdsRef.current.add(d.player.id);
        if (d.ai) {
          seenIdsRef.current.add(d.ai.id);
          sfx.notify();
        }
        setMessages((prev) => [...prev.filter((m) => m.id !== optimistic.id), d.player, ...(d.ai ? [d.ai] : [])]);
        setCaseStatus(d.caseStatus ?? null);
        sfx.click();
      } catch {
        setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
        setInput(body); // give the text back to the input
      } finally {
        setSending(false);
      }
    },
    [sending],
  );

  const requestHuman = async () => {
    if (requesting || caseStatus === "human_requested") return;
    setRequesting(true);
    try {
      const r = await fetch("/api/support/human", { method: "POST" });
      if (r.ok) {
        setCaseStatus("human_requested");
        await loadMessages(); // pulls the "SUPPORT CASE opened" note
        sfx.lock();
      }
    } catch {
      /* the button stays enabled — try again */
    } finally {
      setRequesting(false);
    }
  };

  // keep the newest message visible
  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, open]);

  // USER SPEC (Task 142 — CRITICAL): ADMINS see the floating SUPPORT button
  // too (was admins-only-hidden). The widget is for everyone; admins simply
  // also work from the ADMIN PANEL inbox.
  if (!mounted) return null;

  const humanRequested = caseStatus === "human_requested";

  return (
    <>
      {/* ===== the floating ? button — bottom-right, every page ===== */}
      {/* USER SPEC (Task 137): WHITE button, PURPLE "?" — was violet/fuchsia gradient */}
      <button
        type="button"
        onClick={toggle}
        aria-label={open ? "Close support chat" : "Open support chat"}
        className="fixed bottom-4 right-4 z-50 grid h-14 w-14 place-items-center rounded-full border border-black/10 bg-white text-violet-600 shadow-[0_8px_30px_rgba(0,0,0,0.55)] transition-transform hover:scale-105 active:scale-95"
      >
        {open ? (
          <X className="h-6 w-6" />
        ) : (
          <span className="font-display text-2xl font-black leading-none" aria-hidden="true">
            ?
          </span>
        )}
        {!open && unread > 0 && (
          <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full border border-black/40 bg-amber-400 px-1 text-[10px] font-black text-black">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {/* ===== the chat panel ===== */}
      {open && (
        <div
          className="fixed bottom-20 right-3 z-50 flex h-[min(600px,72vh)] w-[min(92vw,380px)] flex-col overflow-hidden rounded-2xl border border-white/15 bg-[#120c20]/95 shadow-[0_0_60px_rgba(0,0,0,0.6)] backdrop-blur-md sm:right-4"
          role="dialog"
          aria-label="Support chat"
        >
          {/* header */}
          <div className="flex items-center gap-2.5 border-b border-white/10 bg-white/[0.03] px-4 py-3">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600">
              <LifeBuoy className="h-4 w-4 text-white" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-sm font-black tracking-wide text-white">ROLLBOX SUPPORT</p>
              <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-white/45">
                <span className={cn("h-1.5 w-1.5 rounded-full", humanRequested ? "bg-red-400" : "bg-emerald-400")} />
                {humanRequested ? "human agent on the way" : "ROLLBOX AI online"}
              </p>
            </div>
            <button
              type="button"
              onClick={toggle}
              aria-label="Close support chat"
              className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 text-white/50 transition-colors hover:bg-white/10 hover:text-white"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>

          {!player ? (
            /* guests get the sign-in wall */
            <div className="flex flex-1 flex-col items-center justify-center gap-3 px-8 text-center">
              <LifeBuoy className="h-9 w-9 text-white/25" />
              <p className="text-sm font-bold text-white/70">Sign in to contact support</p>
              <p className="text-xs text-white/40">The ROLLBOX AI and our human agents are here for signed-in players.</p>
              <Link
                href="/login"
                className="neon-btn mt-2 inline-flex items-center rounded-xl px-5 py-2.5 text-xs font-black text-white"
              >
                Sign In
              </Link>
            </div>
          ) : (
            <>
              {/* SUPPORT CASE banner */}
              {humanRequested && (
                <div className="flex items-center gap-2 border-b border-red-500/25 bg-red-500/10 px-4 py-2 text-[11px] font-bold text-red-200">
                  <ShieldCheck className="h-3.5 w-3.5 shrink-0" />
                  SUPPORT CASE open — a human agent will reply here.
                </div>
              )}

              {/* conversation */}
              <div ref={listRef} className="flex-1 space-y-2.5 overflow-y-auto px-3.5 py-3" aria-label="Support conversation">
                {messages.map((m) => {
                  if (m.role === "player") {
                    return (
                      <div key={m.id} className="flex justify-end">
                        <div className="max-w-[80%] rounded-2xl rounded-br-md border border-violet-400/30 bg-gradient-to-br from-violet-500/90 to-fuchsia-600/90 px-3 py-2 text-[13px] font-medium leading-snug text-white">
                          {m.body}
                        </div>
                      </div>
                    );
                  }
                  const agent = m.role === "admin";
                  return (
                    <div key={m.id} className="flex justify-start">
                      <div className="max-w-[85%]">
                        <p className={cn("mb-0.5 text-[9px] font-black uppercase tracking-widest", agent ? "text-red-300" : "text-amber-300/90")}>
                          {agent ? "SUPPORT AGENT" : "ROLLBOX AI"}
                        </p>
                        <div
                          className={cn(
                            "rounded-2xl rounded-bl-md border px-3 py-2 text-[13px] font-medium leading-snug text-white/90",
                            agent ? "border-red-400/25 bg-red-500/[0.08]" : "border-white/10 bg-white/[0.05]",
                          )}
                        >
                          {agent ? m.body : <AiAnswerBody body={m.body} onNavigate={() => setOpen(false)} />}
                        </div>
                      </div>
                    </div>
                  );
                })}
                {sending && <div className="text-[10px] font-bold uppercase tracking-widest text-white/30">ROLLBOX AI is typing…</div>}
              </div>

              {/* quick questions — the canned FAQ chips */}
              <div className="border-t border-white/10 px-3 pt-2.5">
                <div className="flex gap-1.5 overflow-x-auto pb-1.5" aria-label="Common questions">
                  {SUPPORT_FAQ.map((f) => (
                    <button
                      key={f.question}
                      type="button"
                      onClick={() => void send(f.question)}
                      className="shrink-0 rounded-full border border-violet-400/30 bg-violet-500/10 px-3 py-1.5 text-[11px] font-bold text-violet-200 transition-colors hover:bg-violet-500/25"
                    >
                      {f.question}
                    </button>
                  ))}
                </div>

                {/* the human handoff */}
                <button
                  type="button"
                  onClick={() => void requestHuman()}
                  disabled={humanRequested || requesting}
                  className={cn(
                    "mt-1.5 flex w-full items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-[11px] font-black uppercase tracking-wider transition-colors",
                    humanRequested
                      ? "cursor-default border-red-400/30 bg-red-500/10 text-red-300/80"
                      : "border-red-500/40 bg-red-500/10 text-red-300 hover:bg-red-500/20",
                  )}
                >
                  <LifeBuoy className="h-3.5 w-3.5" />
                  {humanRequested ? "Case open — agent on the way" : "Request human support"}
                </button>
              </div>

              {/* composer */}
              <div className="flex items-center gap-2 p-3">
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      void send(input);
                    }
                  }}
                  dir="ltr"
                  maxLength={700}
                  placeholder="Type your question…"
                  aria-label="Type your question"
                  className="min-w-0 flex-1 rounded-xl border border-white/15 bg-black/40 px-3 py-2.5 text-[13px] text-white placeholder:text-white/30 focus:border-violet-400/60 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => void send(input)}
                  disabled={sending || !input.trim()}
                  aria-label="Send message"
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-white transition-transform hover:scale-105 disabled:opacity-40 disabled:hover:scale-100"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}
