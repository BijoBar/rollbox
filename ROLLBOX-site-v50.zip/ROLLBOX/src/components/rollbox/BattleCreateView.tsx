"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowDown, ArrowLeft, ArrowUp, Eye, Flame, Layers, Minus, Plus, RotateCcw, Search, Star, Swords, Trash2, Users, X } from "lucide-react";
import { BATTLE_CASES, formatCoins, type CaseDef } from "@/lib/cases";
import { TEAM_META } from "@/lib/battles";
import { caseTopPrize, communityRowToCaseDef, type CommunityCaseCard } from "@/lib/community-designs";
import { eventActive } from "@/lib/event";
import {
  BATTLE_MODES,
  BATTLE_TYPES,
  BATTLE_TYPE_ORDER,
  MAX_BATTLE_ROUNDS,
  POT_RULES,
  type BattleMode,
  type BattlePotRule,
  type BattleType,
} from "@/lib/battles";
import { useCaseStore } from "@/lib/store";
import { useSession } from "@/lib/session";
import { sfx } from "@/lib/sound";
import { CaseImage } from "./CaseImage";
import { Coin } from "./Coin";
import { CaseDropsDialog } from "./CaseDropsDialog";
import { SiteShell } from "./SiteShell";
import { useMounted } from "@/hooks/use-mounted";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

type SortKey = "price-asc" | "price-desc" | "prize-desc" | "name-asc";

/* USER SPEC (Task 68): ROLLBOXCOIN price ranges — no dollar signs */
const PRICE_FILTERS = [
  { label: "Any price", min: 0, max: Infinity },
  { label: "Under 3", min: 0, max: 3 },
  { label: "3 – 6", min: 3, max: 6 },
  { label: "6 – 12", min: 6, max: 12 },
  { label: "12+", min: 12, max: Infinity },
] as const;

export function BattleCreateView() {
  const mounted = useMounted();
  const router = useRouter();
  const { toast } = useToast();
  const { player: me, patch } = useSession();
  const localBalance = useCaseStore((s) => s.balance);
  // signed-in players fight for DATABASE coins — the balance that matters here
  const balance = me ? me.balance : localBalance;
  const [creating, setCreating] = useState(false);
  // USER SPEC (Task 195): a 2v2 battle starts with the player's SIDE — the
  // creator picks CT or T (team emblems) before the room is created.
  const [teamPickOpen, setTeamPickOpen] = useState(false);

  const [type, setType] = useState<BattleType>("1v1");
  const [mode, setMode] = useState<BattleMode>("standard");
  // USER SPEC (Task 42): the pot rule — Standard / CRAZY (winner rule), JACKPOT
  // (odds ∝ unboxed value, with an optional CRAZY-odds inversion) or SHARED
  // (equal split, never 2v2)
  const [potRule, setPotRule] = useState<BattlePotRule>("winner");
  // USER SPEC (R40): FAST MODE DELETED — every battle plays the normal
  // case-style reel pacing; the toggle is gone from the site entirely.
  // USER SPEC (Task 67): PRIVATE — hidden from the worldwide lobby, nobody can
  // watch it; only players who arrive with the room's code/link can take a seat
  const [isPrivate, setIsPrivate] = useState(false);
  // USER SPEC (Task 196): PLAY WITH BOTS — when ON, the created battle fills
  // EVERY empty seat with [RBbot] site bots the moment it opens (no waiting
  // phase — the room is full at birth, so the server rolls it immediately).
  const [withBots, setWithBots] = useState(false);
  const [rounds, setRounds] = useState<string[]>([]);
  const [pickerOpen, setPickerOpen] = useState(false);
  // USER SPEC (Task 42): the opening order of the battle's cases — as picked,
  // cheap → expensive or expensive → cheap
  const [orderSort, setOrderSort] = useState<"picked" | "asc" | "desc">("picked");
  // USER SPEC (Task 42): VIEW DROPS — the contents overlay for any case
  const [dropsCase, setDropsCase] = useState<CaseDef | null>(null);
  const [dropsOpen, setDropsOpen] = useState(false);

  // picker state
  const [category, setCategory] = useState<"official" | "favorites" | "event" | "community">("official");
  const [query, setQuery] = useState("");
  const [priceIdx, setPriceIdx] = useState(0);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  // USER SPEC (Task 43): the picker's AUTOMATIC order is expensive → cheap
  const [sort, setSort] = useState<SortKey>("price-desc");
  const favoriteCases = useCaseStore((s) => s.favoriteCases);
  const toggleFavoriteCase = useCaseStore((s) => s.toggleFavoriteCase);

  // USER SPEC (battles × COMMUNITY): the player-built crates ride the WHOLE
  // create screen — the entry math, the round groups and the picker all read
  // the same defs. Fetched once per mount; the modal receives them as props.
  const [communityCases, setCommunityCases] = useState<CaseDef[]>([]);
  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const r = await fetch("/api/community-cases", { cache: "no-store" });
        if (!r.ok) return;
        const d = (await r.json()) as { cases?: CommunityCaseCard[] };
        if (alive && Array.isArray(d.cases)) setCommunityCases(d.cases.map(communityRowToCaseDef));
      } catch {
        /* the create screen stays usable with the static catalog */
      }
    })();
    return () => {
      alive = false;
    };
  }, []);
  // the full pickable universe: static battle cases (incl. the live EVENT
  // case) + every player-built crate
  const pickableById = useCallback(
    (id: string) => BATTLE_CASES.find((c) => c.id === id) ?? communityCases.find((c) => c.id === id),
    [communityCases],
  );

  // ===== USER SPEC (Task 81): RECREATE — /battles/new?recreate=<battleId> ====
  // The battle-history page's RECREATE button lands here: the SAME battle's
  // config (type / mode / pot rule / private / rounds) is loaded onto
  // this screen so the player can add cases or change any setting — the
  // battle is NEVER created or started automatically.
  const [recreateFrom, setRecreateFrom] = useState<{ id: string; code: string } | null>(null);
  useEffect(() => {
    const rid = new URLSearchParams(window.location.search).get("recreate");
    if (!rid) return;
    let alive = true;
    void (async () => {
      try {
        const r = await fetch(`/api/gbattles/${encodeURIComponent(rid)}`, { cache: "no-store" });
        if (!r.ok) throw new Error("gone");
        const d = (await r.json()) as {
          battle?: {
            id: string;
            code: string;
            type: string;
            mode: string;
            potRule: string;
            isPrivate: boolean;
            rounds: string[];
          };
        };
        const b = d.battle;
        if (!alive || !b) return;
        const bt = b.type as BattleType;
        // SHARED can never play 2v2 — same guard as switchType
        if (BATTLE_TYPES[bt]?.teamMode && b.potRule === "shared") setPotRule("winner");
        else setPotRule(b.potRule as BattlePotRule);
        setType(bt);
        setMode(b.mode as BattleMode);
        setIsPrivate(b.isPrivate);
        setRounds(b.rounds.slice(0, MAX_BATTLE_ROUNDS));
        setRecreateFrom({ id: b.id, code: b.code });
      } catch {
        /* the original room is gone — the create screen just stays manual */
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const spec = BATTLE_TYPES[type];
  const entry = rounds.reduce((s, id) => s + (pickableById(id)?.price ?? 0), 0);
  const canCreate = rounds.length > 0 && mounted && balance >= entry;

  const openDrops = (cs: CaseDef) => {
    sfx.click();
    setDropsCase(cs);
    setDropsOpen(true);
  };

  // the play order of the rounds — as picked, or sorted by case price
  const effectiveRounds = useMemo(() => {
    if (orderSort === "picked") return rounds;
    const priceOf = (id: string) => pickableById(id)?.price ?? 0;
    return [...rounds].sort((a, b) => (orderSort === "asc" ? priceOf(a) - priceOf(b) : priceOf(b) - priceOf(a)));
  }, [rounds, orderSort, pickableById]);

  const switchType = (t: BattleType) => {
    // USER SPEC (Task 42): SHARED can never be played 2v2 — switching the type
    // falls back to the Standard rule
    if (BATTLE_TYPES[t].teamMode && potRule === "shared") {
      setPotRule("winner");
      toast({ title: "SHARED is not playable in 2v2 — back to Standard mode" });
    }
    setType(t);
    sfx.click();
  };

  const switchRule = (rule: BattlePotRule, nextMode: BattleMode) => {
    if (rule === "shared" && spec.teamMode) return; // disabled button — belt & suspenders
    setPotRule(rule);
    setMode(nextMode);
    sfx.click();
  };

  const addRound = (caseId: string) => {
    if (rounds.length >= MAX_BATTLE_ROUNDS) {
      toast({ title: `Max ${MAX_BATTLE_ROUNDS} rounds per battle` });
      return;
    }
    sfx.click();
    setRounds((r) => [...r, caseId]);
  };

  const removeRound = (caseId: string) => {
    sfx.click();
    setRounds((r) => {
      const idx = r.lastIndexOf(caseId);
      return idx === -1 ? r : [...r.slice(0, idx), ...r.slice(idx + 1)];
    });
  };

  // unique selected cases in play order (each with a +/− counter instead of one tile per round)
  const groups = useMemo(() => {
    const order: string[] = [];
    const counts: Record<string, number> = {};
    for (const id of effectiveRounds) {
      if (!counts[id]) order.push(id);
      counts[id] = (counts[id] ?? 0) + 1;
    }
    return order.map((id) => ({ id, count: counts[id] }));
  }, [effectiveRounds]);

  const create = async (team?: 0 | 1) => {
    if (!canCreate || creating) return;
    // USER SPEC (Task 195): 2v2 — the team dialog opens FIRST; the card click
    // comes back here with the pick. 1v1 keeps the one-click create.
    if (type === "2v2" && team === undefined) {
      sfx.click();
      setTeamPickOpen(true);
      return;
    }
    if (!me) {
      // the battle goes to the WORLD database — an account is required
      router.push("/login?next=%2Fbattles%2Fnew");
      return;
    }
    setCreating(true);
    try {
      const r = await fetch("/api/gbattles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type,
          mode,
          potRule,
          rounds: effectiveRounds,
          private: isPrivate,
          bots: withBots, // USER SPEC (Task 196): ON → the server auto-fills the empty seats with bots
          ...(type === "2v2" && team !== undefined ? { team } : {}),
        }),
      });
      const data = (await r.json()) as { id?: string; balance?: number; error?: string };
      if (!r.ok || !data.id) {
        sfx.error();
        toast({
          title: data.error ?? "Could not create the battle",
          description:
                  typeof data.error === "string" && data.error.includes("funds") ? (
                    <>
                      The battle price is <Coin /> {formatCoins(entry)} — your balance is <Coin />{" "}
                      {formatCoins(balance)}.
                    </>
                  ) : undefined,
          variant: "destructive",
        });
        setCreating(false);
        return;
      }
      if (typeof data.balance === "number") patch({ balance: data.balance });
      sfx.caseOpen();
      router.push(`/battles/${data.id}`);
    } catch {
      sfx.error();
      toast({ title: "Could not reach the server", variant: "destructive" });
      setCreating(false);
    }
  };

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] overflow-x-clip pb-20 pt-8" aria-label="Create a battle">

        <div className="relative mx-auto max-w-6xl px-4">
          {/* header */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                sfx.click();
                router.push("/battles");
              }}
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
              aria-label="Back to battles lobby"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div>
              <h1 className="font-display text-2xl font-black tracking-wide text-white sm:text-3xl">
                CREATE <span className="text-gradient-neon">BATTLE</span>
              </h1>
              <p className="text-xs font-semibold text-white/45">Pick the battle type, stack your cases, open the room.</p>
            </div>
          </div>

          {/* USER SPEC (Task 81): the RECREATE banner — the original battle's
              crates and settings are already stacked on this screen */}
          {recreateFrom && (
            <div
              className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-amber-400/40 bg-amber-500/10 px-4 py-2.5"
              aria-label="Recreating a past battle"
            >
              <RotateCcw className="h-4 w-4 shrink-0 text-amber-300" />
              <p className="min-w-0 flex-1 text-xs font-bold text-amber-200/90">
                Recreating battle{" "}
                <span className="font-display font-black text-amber-200" dir="ltr">
                  {recreateFrom.code}
                </span>{" "}
                — same type, cases and settings are loaded. Add cases or change anything, then create.
              </p>
              <button
                type="button"
                onClick={() => {
                  sfx.click();
                  setRecreateFrom(null);
                }}
                aria-label="Dismiss the recreate note"
                className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-black/30 text-amber-200/70 transition-colors hover:bg-black/50 hover:text-amber-100"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {/* ===== battle-type + mode bar — USER SPEC (Task 80): MODE sits in its
              own row DIRECTLY BELOW TYPE (cleaner, more aesthetic) ===== */}
          <div
            className="mt-5 flex flex-col gap-2 rounded-2xl border border-fuchsia-500/25 bg-[#100a1e]/90 p-2.5"
            role="group"
            aria-label="Battle type and mode"
          >
            {/* ---- row 1: TYPE ---- */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="flex items-center gap-1.5 px-2 text-[10px] font-black uppercase tracking-widest text-white/40">
                <Users className="h-3.5 w-3.5" />
                Type
              </span>
              {BATTLE_TYPE_ORDER.map((t) => (
                <button
                  key={t}
                  onClick={() => switchType(t)}
                  aria-pressed={type === t}
                  className={cn(
                    "font-display h-9 min-w-24 flex-1 whitespace-nowrap rounded-xl px-3 text-[11px] font-black tracking-wide transition-all sm:text-xs",
                    type === t
                      ? "gold-btn text-black shadow-[0_0_16px_rgba(240,185,11,0.5)]"
                      : "bg-white/5 text-white/55 hover:bg-white/10 hover:text-white"
                  )}
                >
                  {BATTLE_TYPES[t].label}
                </button>
              ))}
            </div>
            {/* ---- row 2: MODE (+ crazy / fast / private toggles) ---- */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="flex items-center gap-1.5 px-2 text-[10px] font-black uppercase tracking-widest text-white/40">
                <Flame className="h-3.5 w-3.5" />
                Mode
              </span>
            {/* USER SPEC (Task 177): the pot rules stay as buttons — Standard /
                JACKPOT / SHARED — while CRAZY MODE becomes a TOGGLE BUTTON like
                FAST MODE and PRIVATE (red when OFF, green when ON). */}
            {(
              [
                { rule: "winner" as BattlePotRule, m: "standard" as BattleMode, label: "Standard" },
                { rule: "jackpot" as BattlePotRule, m: mode, label: POT_RULES.jackpot.label },
                { rule: "shared" as BattlePotRule, m: "standard" as BattleMode, label: POT_RULES.shared.label },
              ]
            ).map((opt) => {
              const active = potRule === opt.rule && (opt.rule !== "winner" || mode === "standard");
              const blocked = opt.rule === "shared" && spec.teamMode;
              return (
                <button
                  key={opt.label}
                  onClick={() => switchRule(opt.rule, opt.m)}
                  disabled={blocked}
                  aria-pressed={active}
                  title={blocked ? "SHARED cannot be played in 2v2" : undefined}
                  className={cn(
                    "font-display h-9 whitespace-nowrap rounded-xl px-4 text-[11px] font-black uppercase tracking-wide transition-all sm:text-xs",
                    active
                      ? opt.rule === "jackpot"
                        ? "bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow-[0_0_18px_rgba(168,85,247,0.55)]"
                        : opt.rule === "shared"
                          ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white shadow-[0_0_18px_rgba(20,184,166,0.55)]"
                          : "gold-btn text-black shadow-[0_0_16px_rgba(240,185,11,0.5)]"
                      : blocked
                        ? "cursor-not-allowed bg-white/[0.04] text-white/25"
                        : "bg-white/5 text-white/55 hover:bg-white/10 hover:text-white"
                  )}
                >
                  {opt.label}
                </button>
              );
            })}
            {/* USER SPEC (Task 177): CRAZY MODE — a toggle button like PRIVATE.
                With the WINNER rule it flips lowest-total-wins;
                with JACKPOT it inverts the draw odds; SHARED blocks it. */}
            <button
              onClick={() => {
                setMode((m) => (m === "crazy" ? "standard" : "crazy"));
                sfx.click();
              }}
              disabled={potRule === "shared"}
              aria-pressed={mode === "crazy"}
              title={potRule === "shared" ? "CRAZY MODE does not apply to SHARED battles" : "CRAZY MODE — lowest total wins / inverted jackpot odds"}
              className={cn(
                "font-display h-9 whitespace-nowrap rounded-xl px-4 text-[11px] font-black uppercase tracking-wide transition-all sm:text-xs disabled:cursor-not-allowed disabled:opacity-40",
                mode === "crazy"
                  ? "bg-gradient-to-r from-emerald-400 to-green-600 text-black shadow-[0_0_18px_rgba(52,211,153,0.55)]"
                  : "border border-red-500/40 bg-red-500/10 text-red-300 hover:bg-red-500/20"
              )}
            >
              <Flame className="mr-1 inline h-3 w-3" />
              Crazy mode {mode === "crazy" ? "ON" : "OFF"}
            </button>
            {/* USER SPEC (R40): the FAST MODE toggle is DELETED — every battle
                plays the normal case-style reel pacing. */}
            <span className="mx-1 hidden h-6 w-px bg-white/10 sm:block" aria-hidden="true" />
            {/* USER SPEC (Task 67): PRIVATE MODE — invite-only battle.
                Task 177: RED when OFF, GREEN when ON. */}
            <button
              onClick={() => {
                setIsPrivate((p) => !p);
                sfx.click();
              }}
              aria-pressed={isPrivate}
              title="PRIVATE — hidden from the lobby; only players with the code/link can join, nobody can watch"
              className={cn(
                "font-display h-9 whitespace-nowrap rounded-xl px-4 text-[11px] font-black uppercase tracking-wide transition-all sm:text-xs",
                isPrivate
                  ? "bg-gradient-to-r from-emerald-400 to-green-600 text-black shadow-[0_0_18px_rgba(52,211,153,0.55)]"
                  : "border border-red-500/40 bg-red-500/10 text-red-300 hover:bg-red-500/20"
              )}
            >
              Private {isPrivate ? "ON" : "OFF"}
            </button>
            {/* USER SPEC (Task 196): PLAY WITH BOTS — the created battle
                auto-fills every empty seat with bots and starts at once.
                Same toggle styling as CRAZY MODE / PRIVATE: red OFF, green ON. */}
            <button
              onClick={() => {
                setWithBots((v) => !v);
                sfx.click();
              }}
              aria-pressed={withBots}
              title="PLAY WITH BOTS — the room fills every empty seat with bots the moment it is created and starts right away"
              className={cn(
                "font-display h-9 whitespace-nowrap rounded-xl px-4 text-[11px] font-black uppercase tracking-wide transition-all sm:text-xs",
                withBots
                  ? "bg-gradient-to-r from-emerald-400 to-green-600 text-black shadow-[0_0_18px_rgba(52,211,153,0.55)]"
                  : "border border-red-500/40 bg-red-500/10 text-red-300 hover:bg-red-500/20"
              )}
            >
              <Users className="mr-1 inline h-3 w-3" />
              Play with bots {withBots ? "ON" : "OFF"}
            </button>
            </div>
          </div>
          <p
            className={cn(
              "mt-2 px-1 text-[11px] font-bold",
              potRule === "jackpot" ? "text-violet-300" : potRule === "shared" ? "text-teal-300" : mode === "crazy" ? "text-rose-300" : "text-white/45"
            )}
          >
            {potRule === "winner" ? BATTLE_MODES[mode].hint : POT_RULES[potRule].hint}
            {potRule === "winner" && mode === "crazy" && " — roll as low as you dare."}
          </p>

          {/* ===== main area: cases (left) + summary (right) ===== */}
          <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1fr)_320px]">
            {/* cases area */}
            <div className="rounded-2xl border border-white/10 bg-[#100a1e]/90 p-4">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <p className="font-display text-sm font-black uppercase tracking-widest text-white/60">
                  Battle cases <span className="text-white/35">({rounds.length}/{MAX_BATTLE_ROUNDS} rounds)</span>
                </p>
                <div className="flex flex-wrap items-center gap-2">
                  {/* USER SPEC (Task 42): the opening order of the cases — as
                      picked, cheap → expensive or expensive → cheap */}
                  <Select value={orderSort} onValueChange={(v) => {
                    setOrderSort(v as typeof orderSort);
                    sfx.click();
                  }}>
                    <SelectTrigger
                      className="h-8 w-[190px] border-white/10 bg-black/40 text-[11px] text-white/85"
                      aria-label="Opening order of the battle cases"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="border-white/10 bg-[#150e26]">
                      <SelectItem value="picked">
                        <span className="flex items-center gap-1.5">Opening order: as picked</span>
                      </SelectItem>
                      <SelectItem value="asc">
                        <span className="flex items-center gap-1.5"><ArrowUp className="h-3 w-3 text-emerald-300" />Opening: cheap → expensive</span>
                      </SelectItem>
                      <SelectItem value="desc">
                        <span className="flex items-center gap-1.5"><ArrowDown className="h-3 w-3 text-rose-300" />Opening: expensive → cheap</span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  {rounds.length > 0 && (
                    <button
                      onClick={() => {
                        setRounds([]);
                        sfx.click();
                      }}
                      className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-bold text-white/55 transition-colors hover:text-red-300"
                    >
                      <Trash2 className="h-3 w-3" />
                      Clear
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4" dir="ltr">
                {groups.map(({ id, count }) => {
                  const cs = pickableById(id);
                  if (!cs) return null;
                  const atCap = rounds.length >= MAX_BATTLE_ROUNDS;
                  return (
                    <motion.div
                      key={id}
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.18 }}
                      className="relative rounded-xl border border-white/10 bg-black/30 p-2"
                    >
                      {count > 1 && (
                        <span className="font-display absolute right-1.5 top-1.5 z-10 grid h-5 min-w-5 place-items-center rounded-full bg-fuchsia-500 px-1 text-[10px] font-black text-white">
                          ×{count}
                        </span>
                      )}
                      <div className="pointer-events-none relative mx-auto w-[72%]">
                        <CaseImage caseId={cs.id} alt={cs.name} color={cs.tierColor} color2={cs.tierColor2} communityDesign={cs.communityDesign} sizes="160px" />
                      </div>
                      <p className="mt-1 truncate text-center text-[10px] font-bold text-white/70">{cs.name}</p>
                      <p className="text-center text-[10px] font-black text-amber-300">
                        <Coin /> {formatCoins(cs.price)}
                      </p>
                      {/* USER SPEC (Task 42): peek inside every case straight from
                          the battle you are composing */}
                      <button
                        onClick={() => openDrops(cs)}
                        className="font-display mt-1.5 flex w-full items-center justify-center gap-1 rounded-lg border border-white/10 bg-white/5 py-1 text-[9px] font-black uppercase tracking-widest text-white/60 transition-all hover:border-amber-400/40 hover:text-amber-300"
                        aria-label={`View the drops of ${cs.name}`}
                      >
                        <Layers className="h-3 w-3" />
                        View drops
                      </button>
                      {/* +/− per case — stack rounds without flooding the screen */}
                      <div className="mt-1.5 flex items-center justify-center gap-2">
                        <button
                          onClick={() => removeRound(cs.id)}
                          className="grid h-7 w-7 place-items-center rounded-lg border border-white/15 bg-white/5 text-white/70 transition-all hover:border-red-400/50 hover:text-red-300"
                          aria-label={`Remove one ${cs.name} from the battle`}
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="font-display min-w-6 text-center text-xs font-black text-white/85">{count}</span>
                        <button
                          onClick={() => addRound(cs.id)}
                          disabled={atCap}
                          className="grid h-7 w-7 place-items-center rounded-lg border border-white/15 bg-white/5 text-white/70 transition-all hover:border-fuchsia-400/50 hover:text-fuchsia-300 disabled:cursor-not-allowed disabled:opacity-30"
                          aria-label={`Add another ${cs.name} to the battle`}
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </motion.div>
                  );
                })}

                {/* the ADD CASE slot */}
                {rounds.length < MAX_BATTLE_ROUNDS && (
                  <button
                    onClick={() => {
                      setPickerOpen(true);
                      sfx.click();
                    }}
                    className="grid min-h-[150px] place-items-center rounded-xl border-2 border-dashed border-white/15 bg-white/[0.02] transition-colors hover:border-fuchsia-400/50 hover:bg-fuchsia-500/5"
                    aria-label="Add a case to the battle"
                  >
                    <span className="flex flex-col items-center gap-1.5">
                      <span className="grid h-11 w-11 place-items-center rounded-full border border-fuchsia-400/40 bg-fuchsia-500/10 text-fuchsia-300 transition-transform hover:scale-110">
                        <Plus className="h-6 w-6" />
                      </span>
                      <span className="font-display text-[11px] font-black uppercase tracking-widest text-white/50">
                        Add Case
                      </span>
                    </span>
                  </button>
                )}
              </div>
            </div>

            {/* summary sidebar */}
            <div className="flex flex-col gap-3 rounded-2xl border border-fuchsia-500/25 bg-[#100a1e]/90 p-4">
              <div
                className={cn(
                  "rounded-xl border px-3 py-2 text-center text-[11px] font-black uppercase tracking-widest",
                  potRule === "jackpot"
                    ? "border-violet-400/40 bg-violet-500/10 text-violet-300"
                    : potRule === "shared"
                      ? "border-teal-400/40 bg-teal-500/10 text-teal-300"
                      : mode === "crazy"
                        ? "border-rose-400/40 bg-rose-500/10 text-rose-300"
                        : "border-amber-400/30 bg-amber-400/5 text-amber-300"
                )}
              >
                {potRule === "jackpot"
                  ? `Jackpot mode — odds by unboxed value${mode === "crazy" ? " (crazy: inverted)" : ""}`
                  : potRule === "shared"
                    ? "Shared mode — the pot splits equally"
                    : `${BATTLE_MODES[mode].label} mode — ${mode === "crazy" ? "lowest total wins" : "highest total wins"}`}
              </div>
              {/* USER SPEC (Task 67): the PRIVATE note — what the room becomes */}
              {isPrivate && (
                <div
                  className={cn(
                    "rounded-xl border px-3 py-2 text-center text-[11px] font-black uppercase tracking-widest",
                    "border-amber-400/40 bg-amber-400/10 text-amber-300"
                  )}
                >
                  Private battle — invisible in the lobby; friends join with the room code, nobody can watch
                </div>
              )}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-2 py-3">
                  <p className="font-display text-lg font-black text-fuchsia-300">{spec.players}</p>
                  <p className="text-[9px] font-bold uppercase tracking-wide text-white/45">Players</p>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-2 py-3">
                  <p className="font-display text-lg font-black text-white/85">{rounds.length}</p>
                  <p className="text-[9px] font-bold uppercase tracking-wide text-white/45">Rounds</p>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-2 py-3">
                  <p className="font-display flex items-center justify-center gap-1 text-lg font-black text-teal-300">
                    <Coin className="h-4 w-4" /> {formatCoins(entry)}
                  </p>
                  <p className="text-[9px] font-bold uppercase tracking-wide text-white/45">Battle price</p>
                </div>
              </div>

              <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-xs font-semibold text-white/60">
                <div className="flex items-center justify-between">
                  <span>Battle price — </span>
                  <span className="font-display font-black text-teal-300">
                    <Coin /> {formatCoins(entry)}
                  </span>
                </div>
                <div className="mt-1 flex items-center justify-between">
                  <span>Your balance</span>
                  {/* USER SPEC (Task 177): the money is always GREEN on this screen */}
                  <span className="font-display font-black text-emerald-300">
                    <Coin /> {formatCoins(mounted ? balance : 0)}
                  </span>
                </div>
                <p className="mt-1.5 text-[11px] leading-relaxed text-white/40">
                  Leaving the battle before it starts automatically credits your balance back.
                </p>
              </div>

              <button
                onClick={() => void create()}
                disabled={!canCreate || creating}
                className="neon-btn mt-auto flex w-full items-center justify-center gap-2 rounded-xl px-6 py-4 text-base font-black text-white disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Swords className="h-5 w-5" />
                Create Battle
              </button>
              {rounds.length === 0 && (
                <p className="text-center text-[11px] font-bold text-white/40">Add at least one case to create the battle.</p>
              )}
              {mounted && rounds.length > 0 && balance < entry && (
                <p className="text-center text-[11px] font-bold text-red-400">
                  Not enough coins for this entry — remove a case or pick cheaper ones.
                </p>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* ===== case picker modal ===== */}
      <CasePickerModal
        open={pickerOpen}
        onOpenChange={setPickerOpen}
        onAdd={addRound}
        onViewDrops={openDrops}
        communityCases={communityCases}
        selectedCounts={rounds.reduce<Record<string, number>>((acc, id) => {
          acc[id] = (acc[id] ?? 0) + 1;
          return acc;
        }, {})}
        category={category}
        setCategory={setCategory}
        favoriteCases={favoriteCases}
        onToggleFavorite={toggleFavoriteCase}
        query={query}
        setQuery={setQuery}
        priceIdx={priceIdx}
        setPriceIdx={setPriceIdx}
        minPrice={minPrice}
        setMinPrice={setMinPrice}
        maxPrice={maxPrice}
        setMaxPrice={setMaxPrice}
        sort={sort}
        setSort={setSort}
      />

      {/* USER SPEC (Task 42): the VIEW DROPS overlay — the case contents open
          on the current page, no navigation */}
      <CaseDropsDialog caseDef={dropsCase} open={dropsOpen} onOpenChange={setDropsOpen} />

      {/* ===== USER SPEC (Task 195): 2v2 team pick — CHOOSE YOUR SIDE ===== */}
      <Dialog open={teamPickOpen} onOpenChange={setTeamPickOpen}>
        <DialogContent className="max-w-lg border-white/10 bg-[#0b0e1a] p-6">
          <DialogHeader className="border-b border-white/10 pb-3 text-left">
            <DialogTitle className="font-display text-xl font-black tracking-wide text-white">
              CHOOSE YOUR <span className="text-gradient-neon">TEAM</span>
            </DialogTitle>
            <DialogDescription className="text-xs font-semibold text-white/45">
              2v2 — pick the side you fight for. You can still switch to any open seat in the waiting room.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4 grid grid-cols-2 gap-4">
            {([0, 1] as const).map((t) => {
              const meta = TEAM_META[t];
              const isCt = t === 0;
              return (
                <button
                  key={t}
                  onClick={() => {
                    sfx.click();
                    setTeamPickOpen(false);
                    void create(t);
                  }}
                  className={`group flex flex-col items-center rounded-2xl border-2 bg-white/[0.03] p-5 transition-all hover:scale-[1.04] hover:bg-white/[0.06] ${
                    isCt
                      ? "border-sky-400/25 hover:border-sky-400/80 hover:shadow-[0_0_36px_rgba(77,163,255,0.35)]"
                      : "border-amber-400/25 hover:border-amber-400/80 hover:shadow-[0_0_36px_rgba(232,182,76,0.35)]"
                  }`}
                  aria-label={`Fight as ${meta.name}`}
                >
                  <img src={meta.img} alt={`${meta.name} team emblem`} className="h-28 w-28 object-contain" />
                  <span className="mt-3 font-display text-2xl font-black tracking-wider" style={{ color: meta.color }}>
                    {meta.name}
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">
                    {isCt ? "Counter-Terrorists" : "Terrorists"}
                  </span>
                </button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </SiteShell>
  );
}

/* ===== the case picker overlay ===== */
function CasePickerModal(props: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onAdd: (caseId: string) => void;
  /** USER SPEC (Task 42): open the case contents right here on the page */
  onViewDrops: (cs: CaseDef) => void;
  /** USER SPEC (battles × COMMUNITY): the player-built crates, resolved by
   *  the parent create screen — one fetch feeds the picker AND the entry math */
  communityCases: CaseDef[];
  selectedCounts: Record<string, number>;
  category: "official" | "favorites" | "event" | "community";
  setCategory: (c: "official" | "favorites" | "event" | "community") => void;
  favoriteCases: string[];
  onToggleFavorite: (caseId: string) => void;
  query: string;
  setQuery: (q: string) => void;
  priceIdx: number;
  setPriceIdx: (i: number) => void;
  minPrice: string;
  setMinPrice: (v: string) => void;
  maxPrice: string;
  setMaxPrice: (v: string) => void;
  sort: SortKey;
  setSort: (s: SortKey) => void;
}) {
  const { open, onOpenChange, onAdd, selectedCounts } = props;
  const communityDefs = props.communityCases;

  // the pickable pool per tab — OFFICIAL shows everything (its category
  // sections split the families below), FAVORITES filters the whole pool,
  // COMMUNITY is the dedicated player-built view, EVENT the limited crate.
  // BATTLE_CASES already carries the EVENT case while its window is live.
  const pool = useMemo(() => {
    if (props.category === "community") return communityDefs;
    if (props.category === "event") return BATTLE_CASES.filter((c) => c.kind === "event");
    if (props.category === "favorites") {
      return [...BATTLE_CASES, ...communityDefs].filter((c) => props.favoriteCases.includes(c.id));
    }
    return [...BATTLE_CASES, ...communityDefs];
  }, [props.category, props.favoriteCases, communityDefs]);

  const filtered = useMemo(() => {
    let list = pool;
    const min = props.minPrice !== "" ? Number(props.minPrice) : PRICE_FILTERS[props.priceIdx].min;
    const max = props.maxPrice !== "" ? Number(props.maxPrice) : PRICE_FILTERS[props.priceIdx].max;
    list = list.filter((c) => {
      if (c.price < min || c.price > max) return false;
      if (props.query.trim() && !c.name.toLowerCase().includes(props.query.trim().toLowerCase())) return false;
      return true;
    });
    switch (props.sort) {
      case "price-asc":
        list = [...list].sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list = [...list].sort((a, b) => b.price - a.price);
        break;
      case "prize-desc":
        list = [...list].sort((a, b) => caseTopPrize(b) - caseTopPrize(a));
        break;
      case "name-asc":
        list = [...list].sort((a, b) => a.name.localeCompare(b.name));
        break;
    }
    return list;
  }, [pool, props.query, props.priceIdx, props.minPrice, props.maxPrice, props.sort]);

  const customActive = props.minPrice !== "" || props.maxPrice !== "";

  // one selectable case tile (shared by both category sections + Favorites)
  const tile = (cs: CaseDef) => {
    const count = selectedCounts[cs.id] ?? 0;
    const saved = props.favoriteCases.includes(cs.id);
    return (
      <button
        key={cs.id}
        onClick={() => onAdd(cs.id)}
        className="group relative rounded-xl border border-white/10 bg-black/30 p-2.5 text-left transition-all hover:border-fuchsia-400/50 hover:bg-fuchsia-500/5"
        aria-label={`Add ${cs.name}, price $${formatCoins(cs.price)}${count ? `, selected ${count} times` : ""}`}
      >
        {count > 0 && (
          <span className="font-display absolute right-1.5 top-1.5 z-10 grid h-5 w-5 place-items-center rounded-full bg-fuchsia-500 text-[10px] font-black text-white">
            {count}
          </span>
        )}
        {/* USER SPEC: star a case to keep it in the picker's Favorites tab */}
        <span
          role="button"
          tabIndex={0}
          onClick={(e) => {
            e.stopPropagation();
            props.onToggleFavorite(cs.id);
            sfx.click();
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              e.stopPropagation();
              props.onToggleFavorite(cs.id);
              sfx.click();
            }
          }}
          aria-label={saved ? `Remove ${cs.name} from favorites` : `Save ${cs.name} to favorites`}
          aria-pressed={saved}
          className={cn(
            "absolute left-1.5 top-1.5 z-10 grid h-6 w-6 place-items-center rounded-lg transition-all",
            saved
              ? "bg-amber-400/25 text-amber-300 shadow-[0_0_10px_rgba(240,185,11,0.35)]"
              : "bg-black/45 text-white/35 hover:text-amber-300"
          )}
        >
          <Star className={cn("h-3.5 w-3.5", saved && "fill-current")} />
        </span>
        <div className="pointer-events-none mx-auto w-[76%]">
          <CaseImage caseId={cs.id} alt="" color={cs.tierColor} color2={cs.tierColor2} communityDesign={cs.communityDesign} sizes="160px" />
        </div>
        <p className="mt-1 truncate text-[11px] font-bold text-white/80">{cs.name}</p>
        <p className="text-[11px] font-black text-amber-300">
          <Coin /> {formatCoins(cs.price)}
        </p>
        {/* USER SPEC (Task 42): VIEW DROPS on the right side of every
            case — the contents open right here on the page */}
        <span
          role="button"
          tabIndex={0}
          onClick={(e) => {
            e.stopPropagation();
            props.onViewDrops(cs);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              e.stopPropagation();
              props.onViewDrops(cs);
            }
          }}
          aria-label={`View the drops of ${cs.name}`}
          className="font-display absolute bottom-1.5 right-1.5 z-10 flex items-center gap-1 rounded-lg bg-black/70 px-1.5 py-1 text-[8px] font-black uppercase tracking-widest text-amber-300 transition-all hover:bg-amber-400/25 hover:text-amber-200"
        >
          <Eye className="h-3 w-3" />
          View drops
        </span>
      </button>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-hidden border-fuchsia-500/30 bg-[#0d0819] p-0 sm:max-w-3xl">
        <DialogHeader className="border-b border-white/10 px-5 pb-3 pt-4">
          <DialogTitle className="font-display text-lg font-black tracking-wide text-white">
            CHOOSE YOUR CASES
          </DialogTitle>
          <DialogDescription className="text-xs font-semibold text-white/45">
            Every case you pick becomes one round — everyone opens the same case. Tap a case again to stack it.
          </DialogDescription>
        </DialogHeader>

        {/* categories — USER SPEC (battles × COMMUNITY/EVENT): the two SOON
            tabs are LIVE — the player-built crates and the limited event case
            are pickable here exactly like the official catalog */}
        <div className="flex flex-wrap items-center gap-2 px-5 pt-3">
          {(
            [
              { key: "official", label: "Official Cases" },
              { key: "favorites", label: "Favorites", count: props.favoriteCases.length },
              { key: "event", label: "Event Cases" },
              { key: "community", label: "Community Cases", count: communityDefs.length },
            ] as const
          ).map((cat) => (
            <button
              key={cat.key}
              onClick={() => {
                props.setCategory(cat.key);
                sfx.click();
              }}
              aria-pressed={props.category === cat.key}
              className={cn(
                "font-display flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[11px] font-black uppercase tracking-wider transition-all",
                props.category === cat.key
                  ? cat.key === "favorites"
                    ? "bg-amber-400/90 text-black shadow-[0_0_14px_rgba(240,185,11,0.4)]"
                    : cat.key === "event"
                      ? "bg-emerald-400/90 text-black shadow-[0_0_14px_rgba(16,185,129,0.4)]"
                      : cat.key === "community"
                        ? "bg-fuchsia-500/90 text-black shadow-[0_0_14px_rgba(217,70,239,0.4)]"
                        : "gold-btn text-black shadow-[0_0_14px_rgba(240,185,11,0.4)]"
                  : "bg-white/5 text-white/55 hover:bg-white/10 hover:text-white"
              )}
            >
              {cat.key === "favorites" && <Star className={cn("h-3.5 w-3.5", props.category === "favorites" && "fill-current")} />}
              {cat.label}
              {"count" in cat && cat.count > 0 && <span className="opacity-70">({cat.count})</span>}
            </button>
          ))}
        </div>

        {/* filters */}
        <div className="flex flex-wrap items-center gap-2 px-5 pt-3">
          <div className="relative min-w-[150px] flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/35" />
            <Input
              value={props.query}
              onChange={(e) => props.setQuery(e.target.value)}
              placeholder="Search cases..."
              className="h-9 border-white/10 bg-black/40 pl-8 text-xs text-white/85 placeholder:text-white/30"
              aria-label="Search cases by name"
            />
          </div>
          <Select value={String(props.sort)} onValueChange={(v) => props.setSort(v as SortKey)}>
            <SelectTrigger className="h-9 w-[150px] border-white/10 bg-black/40 text-xs text-white/85" aria-label="Sort cases">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="border-white/10 bg-[#150e26]">
              <SelectItem value="price-asc">Price: low → high</SelectItem>
              <SelectItem value="price-desc">Price: high → low</SelectItem>
              <SelectItem value="prize-desc">Top prize first</SelectItem>
              <SelectItem value="name-asc">Name A → Z</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 px-5 pt-2.5">
          {PRICE_FILTERS.map((f, i) => (
            <button
              key={f.label}
              onClick={() => {
                props.setPriceIdx(i);
                props.setMinPrice("");
                props.setMaxPrice("");
                sfx.click();
              }}
              aria-pressed={!customActive && props.priceIdx === i}
              className={cn(
                "h-7 rounded-lg px-2.5 text-[10px] font-black transition-all",
                !customActive && props.priceIdx === i
                  ? "bg-fuchsia-500/80 text-white"
                  : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"
              )}
            >
              {i > 0 ? (
                <span className="inline-flex items-center gap-0.5">
                  <Coin className="h-3 w-3" />
                  {f.label}
                </span>
              ) : (
                f.label
              )}
            </button>
          ))}
          <span className="ml-1 text-[10px] font-bold uppercase tracking-wider text-white/35">Custom:</span>
          <Input
            value={props.minPrice}
            onChange={(e) => props.setMinPrice(e.target.value.replace(/[^0-9]/g, ""))}
            placeholder="min $"
            inputMode="numeric"
            className="h-7 w-[64px] border-white/10 bg-black/40 px-2 text-[11px] text-white/85"
            aria-label="Minimum price"
          />
          <span className="text-white/35">–</span>
          <Input
            value={props.maxPrice}
            onChange={(e) => props.setMaxPrice(e.target.value.replace(/[^0-9]/g, ""))}
            placeholder="max $"
            inputMode="numeric"
            className="h-7 w-[64px] border-white/10 bg-black/40 px-2 text-[11px] text-white/85"
            aria-label="Maximum price"
          />
        </div>

        {/* grid */}
        <div className="max-h-[46vh] overflow-y-auto px-5 pb-5 pt-3" dir="ltr">
          {props.category === "event" && !eventActive() ? (
            <div className="grid place-items-center rounded-xl border border-dashed border-white/10 py-14 text-center">
              <p className="font-display text-sm font-black tracking-widest text-white/40">THE EVENT HAS ENDED</p>
              <p className="mt-1 text-xs font-semibold text-white/30">The event case left the battles — see you on the next one.</p>
            </div>
          ) : props.category === "community" && communityDefs.length === 0 ? (
            <div className="grid place-items-center rounded-xl border border-dashed border-fuchsia-400/25 py-14 text-center">
              <Users className="h-7 w-7 text-fuchsia-300/50" />
              <p className="font-display mt-2 text-sm font-black tracking-widest text-white/40">NO COMMUNITY CASES YET</p>
              <p className="mt-1 max-w-xs text-xs font-semibold leading-relaxed text-white/30">
                Player-built crates land here — build the first one in the CASE BUILDER and publish it.
              </p>
            </div>
          ) : props.category === "favorites" && filtered.length === 0 ? (
            <div className="grid place-items-center rounded-xl border border-dashed border-amber-400/25 py-14 text-center">
              <Star className="h-7 w-7 text-amber-300/50" />
              <p className="font-display mt-2 text-sm font-black tracking-widest text-white/40">NO FAVORITES YET</p>
              <p className="mt-1 max-w-xs text-xs font-semibold leading-relaxed text-white/30">
                Tap the ☆ on any case to save it here — your starred cases will wait in this tab.
              </p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="grid place-items-center rounded-xl border border-dashed border-white/10 py-14 text-center">
              <p className="font-display text-sm font-black tracking-widest text-white/40">NO CASES MATCH</p>
              <p className="mt-1 text-xs font-semibold text-white/30">Try another search or widen the price filter.</p>
            </div>
          ) : props.category === "official" ? (
            /* USER SPEC (Task 43): the Official tab shows the families under
               clear category headers — RollBox Official first, then the Farm
               cases. USER SPEC (battles × COMMUNITY/EVENT): the limited EVENT
               crate and the player-built COMMUNITY crates join the same
               default view under their OWN headers — findable with or
               without the dedicated tabs. */
            <div className="space-y-5">
              {([
                {
                  kind: "standard" as const,
                  title: "RollBox Official",
                  sub: "The themed vaults — every legend, every ceiling",
                  dot: "bg-gradient-to-r from-violet-400 to-fuchsia-400",
                  text: "text-violet-300",
                  match: (c: CaseDef) => c.kind === "standard" && !c.communityDesign,
                },
                {
                  kind: "farm" as const,
                  title: "Farm Cases",
                  sub: "Pocket-change grinding — 99.5% farm hits",
                  dot: "bg-gradient-to-r from-emerald-400 to-teal-400",
                  text: "text-emerald-300",
                  match: (c: CaseDef) => c.kind === "farm",
                },
                {
                  kind: "event" as const,
                  title: "Event Case",
                  sub: "The limited EMERALD DROP — while the event is live",
                  dot: "bg-gradient-to-r from-emerald-400 to-amber-300",
                  text: "text-emerald-300",
                  match: (c: CaseDef) => c.kind === "event",
                },
                {
                  kind: "community" as const,
                  title: "Community Cases",
                  sub: "Player-built crates — fresh from the CASE BUILDER",
                  dot: "bg-gradient-to-r from-fuchsia-400 to-pink-400",
                  text: "text-fuchsia-300",
                  match: (c: CaseDef) => !!c.communityDesign,
                },
              ]
                .map((sec) => ({ ...sec, cases: filtered.filter(sec.match) }))
                .filter((sec) => sec.cases.length > 0)
                .map((sec) => (
                  <div key={sec.kind}>
                    <div className="mb-2 flex items-center gap-2">
                      <span className={cn("h-2.5 w-2.5 rounded-full", sec.dot)} aria-hidden="true" />
                      <h4 className={cn("font-display text-[11px] font-black uppercase tracking-[0.25em]", sec.text)}>
                        {sec.title}
                      </h4>
                      <span className="text-[10px] font-bold text-white/35">{sec.cases.length}</span>
                      <span className="min-w-0 flex-1 truncate text-[10px] font-semibold text-white/25">{sec.sub}</span>
                      <span className="h-px w-8 shrink-0 bg-white/10" aria-hidden="true" />
                    </div>
                    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
                      {sec.cases.map((cs) => tile(cs))}
                    </div>
                  </div>
                ))
              )}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
              {filtered.map((cs) => tile(cs))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
