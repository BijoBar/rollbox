"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Inbox, LifeBuoy, MessageSquare, Send, ShieldCheck, UserX } from "lucide-react";
import { useRealtimeEvent } from "@/lib/realtime";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";

/* ===== USER SPEC (Task 136): the admins' SUPPORT inbox =====
   The second ADMIN PANEL tab: every player conversation on the left, the
   selected thread on the right. A red pulsing SUPPORT CASE chip marks players
   who pressed "Request human support"; replying flips the case to handled and
   the answer is PUSHED into the player's chat panel live. */

interface Thread {
  playerId: string;
  playerName: string;
  avatar: string | null;
  caseStatus: string | null;
  unread: number;
  lastRole: string;
  lastBody: string;
  lastAt: string;
}

interface Msg {
  id: string;
  role: "player" | "ai" | "admin";
  body: string;
  at: string;
}

const fmtTime = (iso: string) => {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) || d.getTime() === 0
    ? ""
    : d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
};

export function SupportInbox({ focusPlayerId }: { focusPlayerId: string | null }) {
  const [threads, setThreads] = useState<Thread[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [selCase, setSelCase] = useState<string | null>(null);
  const [selName, setSelName] = useState("");
  const [selAvatar, setSelAvatar] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [closing, setClosing] = useState(false);
  const listRef = useRef<HTMLDivElement | null>(null);
  // USER SPEC (Task 177): the admin side is LIVE too — new player messages and
  // newly-opened SUPPORT CASES ping instantly (site-wide alert included), and
  // the inbox polls fast as the safety net under the realtime push.
  const seenMsgRef = useRef<Set<string>>(new Set());
  const threadBacklogRef = useRef(false);
  const lastUnreadByThread = useRef<Record<string, number>>({});
  const threadsArmedRef = useRef(false);

  const loadThreads = useCallback(async () => {
    try {
      const r = await fetch("/api/support/admin/threads", { cache: "no-store" });
      if (!r.ok) return;
      const d = (await r.json()) as { threads: Thread[] };
      const rows = d.threads ?? [];
      // ping on a rising unread count or a brand-new conversation
      if (threadsArmedRef.current) {
        const pinging = rows.some((t) => {
          const before = lastUnreadByThread.current[t.playerId] ?? 0;
          return t.unread > before || !(t.playerId in lastUnreadByThread.current);
        });
        if (pinging && !threadBacklogRef.current) sfx.notify();
      }
      lastUnreadByThread.current = Object.fromEntries(rows.map((t) => [t.playerId, t.unread]));
      threadsArmedRef.current = true;
      threadBacklogRef.current = false;
      setThreads(rows);
    } catch {
      /* keep the previous list */
    } finally {
      setLoading(false);
    }
  }, []);

  const loadThread = useCallback(async (playerId: string) => {
    try {
      const r = await fetch(`/api/support/admin/messages?playerId=${encodeURIComponent(playerId)}`, { cache: "no-store" });
      if (!r.ok) return;
      const d = (await r.json()) as {
        player: { id: string; name: string; avatar: string | null };
        caseStatus: string | null;
        messages: Msg[];
      };
      const rows = d.messages ?? [];
      // Task 177: a NEW player message inside the open conversation pings
      const incoming = rows.filter((m) => m.role === "player" && !seenMsgRef.current.has(m.id));
      for (const m of rows) seenMsgRef.current.add(m.id);
      if (threadBacklogRef.current === false && incoming.length > 0) sfx.notify();
      setMsgs(rows);
      setSelCase(d.caseStatus ?? null);
      setSelName(d.player.name);
      setSelAvatar(d.player.avatar);
      setThreads((prev) => prev.map((t) => (t.playerId === playerId ? { ...t, unread: 0 } : t)));
      lastUnreadByThread.current = { ...lastUnreadByThread.current, [playerId]: 0 };
    } catch {
      /* keep the current thread */
    }
  }, []);

  useEffect(() => {
    void loadThreads();
    // Task 177: the inbox re-sorts live — 12s → 5s safety poll
    const t = window.setInterval(() => void loadThreads(), 5000);
    return () => window.clearInterval(t);
  }, [loadThreads]);

  // Task 177: the OPEN conversation reloads fast (3s) — replies land without
  // any refresh, and the realtime push below usually beats the poll
  useEffect(() => {
    if (!selectedId) return;
    void loadThread(selectedId);
    const t = window.setInterval(() => void loadThread(selectedId), 3000);
    return () => window.clearInterval(t);
  }, [selectedId, loadThread]);

  // a SUPPORT CASE alert (or any push) → refresh; the focused thread reloads.
  // Task 177: the push is the LIVE channel; polls are the safety net.
  useRealtimeEvent("support_admin", (data) => {
    void loadThreads();
    const e = data as { playerId?: string; kind?: string } | null;
    if (e?.playerId && e.playerId === selectedId) void loadThread(e.playerId);
  });

  // the side-alert OPEN button jumps the inbox straight to the case
  useEffect(() => {
    if (!focusPlayerId) return;
    setSelectedId(focusPlayerId);
    void loadThread(focusPlayerId);
  }, [focusPlayerId, loadThread]);

  const select = (t: Thread) => {
    sfx.click();
    setSelectedId(t.playerId);
    setSelName(t.playerName);
    setSelAvatar(t.avatar);
    threadBacklogRef.current = true; // switching threads shows its backlog silently
    void loadThread(t.playerId);
  };

  const reply = async () => {
    const text = input.trim();
    if (!text || !selectedId || sending) return;
    setSending(true);
    setInput("");
    try {
      const r = await fetch("/api/support/admin/reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerId: selectedId, text }),
      });
      if (r.ok) {
        const d = (await r.json()) as { message: Msg; caseStatus: string | null };
        setMsgs((prev) => [...prev, d.message]);
        setSelCase(d.caseStatus);
        void loadThreads();
        sfx.coins();
      }
    } catch {
      /* keep the input */
    } finally {
      setSending(false);
    }
  };

  const closeCase = async () => {
    if (!selectedId || closing) return;
    setClosing(true);
    try {
      const r = await fetch("/api/support/admin/close", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerId: selectedId }),
      });
      if (r.ok) {
        setSelCase("closed");
        await loadThread(selectedId);
        void loadThreads();
        sfx.lock();
      }
    } catch {
      /* keep the state */
    } finally {
      setClosing(false);
    }
  };

  // keep the newest message visible
  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs, selectedId]);

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-[280px_1fr]">
      {/* ===== thread list ===== */}
      <div className="rounded-2xl border border-white/10 bg-black/30 p-2.5" aria-label="Support conversations">
        <p className="px-1 pb-2 text-[10px] font-black uppercase tracking-widest text-white/40">
          Conversations {threads.length > 0 && <span className="text-white/25">({threads.length})</span>}
        </p>
        {loading && threads.length === 0 ? (
          <div className="space-y-2 px-1 py-2">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-12 animate-pulse rounded-xl bg-white/[0.04]" />
            ))}
          </div>
        ) : threads.length === 0 ? (
          <div className="px-3 py-8 text-center">
            <Inbox className="mx-auto mb-2 h-8 w-8 text-white/20" />
            <p className="text-xs font-bold text-white/50">No conversations yet</p>
            <p className="mt-1 text-[10px] text-white/35">Player chats land here the moment they write.</p>
          </div>
        ) : (
          <ul className="max-h-[52vh] space-y-1.5 overflow-y-auto md:max-h-[60vh]">
            {threads.map((t) => (
              <li key={t.playerId}>
                <button
                  type="button"
                  onClick={() => select(t)}
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-xl border px-2.5 py-2 text-left transition-colors",
                    selectedId === t.playerId
                      ? "border-red-400/40 bg-red-500/10"
                      : "border-white/10 bg-white/[0.02] hover:bg-white/[0.06]",
                  )}
                >
                  {t.avatar ? (
                    <img src={t.avatar} alt="" referrerPolicy="no-referrer" className="h-8 w-8 shrink-0 rounded-full border border-black/40 object-cover" />
                  ) : (
                    <span className="font-display grid h-8 w-8 shrink-0 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 text-xs font-black text-white">
                      {t.playerName.charAt(0).toUpperCase()}
                    </span>
                  )}
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-xs font-bold text-white/90">{t.playerName}</span>
                      {t.caseStatus === "human_requested" && (
                        <span className="shrink-0 animate-pulse rounded border border-red-500/50 bg-red-500/20 px-1 py-0.5 text-[8px] font-black uppercase text-red-300">
                          case
                        </span>
                      )}
                    </span>
                    <span className="block truncate text-[10px] text-white/40">
                      {t.lastRole === "player" ? "" : t.lastRole === "admin" ? "You: " : "AI: "}
                      {t.lastBody}
                    </span>
                  </span>
                  {t.unread > 0 && (
                    <span className="grid h-5 min-w-5 shrink-0 place-items-center rounded-full bg-amber-400 px-1 text-[10px] font-black text-black">
                      {t.unread > 9 ? "9+" : t.unread}
                    </span>
                  )}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* ===== the selected conversation ===== */}
      <div className="flex min-h-[420px] flex-col rounded-2xl border border-white/10 bg-black/30" aria-label="Support thread">
        {!selectedId ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-2 px-8 text-center">
            <MessageSquare className="h-9 w-9 text-white/20" />
            <p className="text-sm font-bold text-white/55">Pick a conversation</p>
            <p className="max-w-xs text-xs text-white/35">
              Open a player on the left to read their messages and answer as a human support agent.
            </p>
          </div>
        ) : (
          <>
            {/* thread header */}
            <div className="flex items-center gap-2.5 border-b border-white/10 px-4 py-3">
              {selAvatar ? (
                <img src={selAvatar} alt="" referrerPolicy="no-referrer" className="h-9 w-9 rounded-full border border-black/40 object-cover" />
              ) : (
                <span className="font-display grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 text-sm font-black text-white">
                  {selName.charAt(0).toUpperCase()}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-black text-white">{selName}</p>
                <p
                  className={cn(
                    "flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider",
                    selCase === "human_requested" ? "text-red-300" : selCase === "handled" ? "text-emerald-300/80" : "text-white/40",
                  )}
                >
                  {selCase === "human_requested" && <ShieldCheck className="h-3 w-3" />}
                  {selCase === "human_requested"
                    ? "SUPPORT CASE — waiting for an agent"
                    : selCase === "handled"
                      ? "case handled"
                      : selCase === "closed"
                        ? "case closed"
                        : "AI chat only"}
                </p>
              </div>
              {selCase && selCase !== "closed" && (
                <button
                  type="button"
                  onClick={() => void closeCase()}
                  disabled={closing}
                  className="flex shrink-0 items-center gap-1.5 rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2 text-[10px] font-black uppercase tracking-wider text-red-300 transition-colors hover:bg-red-500/20 disabled:opacity-50"
                >
                  <UserX className="h-3.5 w-3.5" />
                  Close case
                </button>
              )}
            </div>

            {/* messages */}
            <div ref={listRef} className="flex-1 space-y-2.5 overflow-y-auto px-4 py-3">
              {msgs.map((m) => {
                if (m.role === "player") {
                  return (
                    <div key={m.id} className="flex justify-start">
                      <div className="max-w-[80%]">
                        <div className="rounded-2xl rounded-bl-md border border-white/10 bg-white/[0.06] px-3 py-2 text-[13px] font-medium leading-snug text-white/90">
                          {m.body}
                        </div>
                        <p className="mt-0.5 text-[9px] font-bold text-white/25">{fmtTime(m.at)}</p>
                      </div>
                    </div>
                  );
                }
                const agent = m.role === "admin";
                return (
                  <div key={m.id} className="flex justify-end">
                    <div className="max-w-[80%]">
                      <p className={cn("mb-0.5 text-right text-[9px] font-black uppercase tracking-widest", agent ? "text-red-300" : "text-amber-300/80")}>
                        {agent ? "SUPPORT AGENT" : "ROLLBOX AI"}
                      </p>
                      <div
                        className={cn(
                          "rounded-2xl rounded-br-md px-3 py-2 text-[13px] font-medium leading-snug",
                          agent
                            ? "border border-red-400/30 bg-red-500/15 text-white"
                            : "border border-amber-400/20 bg-amber-400/[0.07] text-white/85",
                        )}
                      >
                        {m.body}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* composer */}
            <div className="flex items-center gap-2 border-t border-white/10 p-3">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    void reply();
                  }
                }}
                dir="ltr"
                maxLength={700}
                placeholder={`Reply to ${selName}…`}
                aria-label="Reply as support agent"
                className="min-w-0 flex-1 rounded-xl border border-white/15 bg-black/40 px-3 py-2.5 text-[13px] text-white placeholder:text-white/30 focus:border-red-400/60 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => void reply()}
                disabled={sending || !input.trim()}
                aria-label="Send reply"
                className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-red-500 to-red-600 text-white transition-transform hover:scale-105 disabled:opacity-40 disabled:hover:scale-100"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ===== the SUPPORT CASE side alert — pops on the admin's screen ===== */
export function SupportCaseAlert({ onOpen }: { onOpen: (playerId: string) => void }) {
  interface AlertItem {
    key: string;
    playerId: string;
    playerName: string;
  }
  const [alerts, setAlerts] = useState<AlertItem[]>([]);

  const push = useCallback((playerId: string, playerName: string) => {
    const key = `${playerId}_${Date.now()}`;
    setAlerts((prev) => [...prev.slice(-2), { key, playerId, playerName }]);
    window.setTimeout(() => setAlerts((prev) => prev.filter((a) => a.key !== key)), 14000);
  }, []);

  // already-waiting cases get ONE summary alert per browser session (the
  // admin may have missed them while offline — but the alert must not spam
  // on every page navigation now that it renders site-wide, Task 142) —
  // every live "case" event pops instantly regardless
  useEffect(() => {
    void (async () => {
      try {
        try {
          if (window.sessionStorage.getItem("rb_case_summary_shown")) return;
          window.sessionStorage.setItem("rb_case_summary_shown", "1");
        } catch {
          /* private mode — summarize as before */
        }
        const r = await fetch("/api/support/admin/threads", { cache: "no-store" });
        if (!r.ok) return;
        const d = (await r.json()) as { threads: Thread[] };
        const waiting = (d.threads ?? []).filter((t) => t.caseStatus === "human_requested");
        if (waiting.length > 0) {
          push(
            waiting[0].playerId,
            waiting.length === 1 ? waiting[0].playerName : `${waiting.length} players`,
          );
        }
      } catch {
        /* alerts are best-effort */
      }
    })();
  }, [push]);

  useRealtimeEvent("support_admin", (data) => {
    const e = data as { playerId?: string; playerName?: string; kind?: string } | null;
    if (e?.kind === "case" && e.playerId) {
      // USER SPEC (Task 177): the live SUPPORT CASE alert PINGS — the admin
      // hears it even when he is far from the admin panel
      sfx.notify();
      push(e.playerId, e.playerName ?? "A player");
    }
  });

  if (alerts.length === 0) return null;

  return (
    <div className="fixed right-4 top-20 z-[60] flex w-[min(90vw,320px)] flex-col gap-2" aria-live="polite">
      {alerts.map((a) => (
        <div
          key={a.key}
          role="alert"
          className="overflow-hidden rounded-2xl border border-red-500/50 bg-[#1a0d0d]/95 shadow-[0_0_40px_rgba(239,68,68,0.35)] backdrop-blur-md"
        >
          <div className="flex items-start gap-3 p-3.5">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-red-500/20">
              <LifeBuoy className="h-4 w-4 text-red-300" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-black uppercase tracking-widest text-red-400">SUPPORT CASE</p>
              <p className="truncate text-sm font-bold text-white">
                {a.playerName} requested human support
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              sfx.click();
              onOpen(a.playerId);
              setAlerts((prev) => prev.filter((x) => x.key !== a.key));
            }}
            className="w-full border-t border-red-500/30 bg-red-500/15 py-2.5 text-[11px] font-black uppercase tracking-widest text-red-200 transition-colors hover:bg-red-500/30"
          >
            Open conversation
          </button>
        </div>
      ))}
    </div>
  );
}
