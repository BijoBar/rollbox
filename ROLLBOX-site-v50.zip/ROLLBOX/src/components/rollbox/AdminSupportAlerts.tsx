"use client";

import { usePathname, useRouter } from "next/navigation";
import { useSession } from "@/lib/session";
import { useMounted } from "@/hooks/use-mounted";
import { SupportCaseAlert } from "./SupportInbox";

/**
 * USER SPEC (Task 142 — CRITICAL): admins get the red SUPPORT CASE alert on
 * EVERY page, not only inside the ADMIN PANEL. The SiteShell mounts this
 * site-wide wrapper for signed-in admins; clicking "Open conversation"
 * jumps to the admin panel. On /admin the panel's own alert takes over
 * (with in-panel focusing) — this wrapper steps aside there.
 */
export function AdminSupportAlerts() {
  const mounted = useMounted();
  const { player: me } = useSession();
  const router = useRouter();
  const pathname = usePathname();

  if (!mounted || !me?.isAdmin || pathname?.startsWith("/admin")) return null;

  return <SupportCaseAlert onOpen={() => router.push("/admin")} />;
}
