"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Boxes,
  Check,
  Coins,
  Copy,
  ExternalLink,
  Flame,
  Gift,
  History,
  Link2,
  LogOut,
  PackageOpen,
  ScrollText,
  Settings2,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Swords,
  Target,
  Trophy,
  User,
  Zap,
} from "lucide-react";
import { useAuthStore } from "@/lib/auth";
import { useCaseStore } from "@/lib/store";
import { formatCoins, type WeaponKind } from "@/lib/cases";
import { displayWearLabel, isWearableKind, wearColorOf } from "@/lib/wear";
import { formatCountdown, levelFromXp } from "@/lib/progress";
import { nextDailyReadyIn, readyDailyCount, unlockedDailyCases } from "@/lib/level-cases";
import { useSession } from "@/lib/session";
import { useRealtimeEvent } from "@/lib/realtime";
import { sfx } from "@/lib/sound";
import { expandImg } from "@/lib/skin-img";
import { WeaponArt } from "./WeaponArt";
import { Coin } from "./Coin";
import { LevelRing } from "./LevelRing";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";

/* ===== the profile — the DATABASE player (Steam only) =====
   Signed-in: the header carries the real Steam persona — the ROUND avatar
   wrapped in the LEVEL-color ring — plus name + provider + member since from
   the DB row. The stats mix DB truth (balance, cases opened, battles won)
   with local counters, and the inventory preview mirrors the DATABASE rows.
   USER SPEC (Task 83): the money ledger lives on /profile/balance (BALANCE
   HISTORY), the settings on /settings — the header carries the buttons
   BATTLE HISTORY / BALANCE HISTORY / SETTINGS / MISSIONS (Task 31), and SIGN
   OUT is gone from the profile entirely.
   Guests: the same page explains what signing in unlocks. */

/* The money LEDGER moved to the dedicated BALANCE HISTORY page
   (BalanceHistoryView + /profile/balance) — the profile no longer lists
   money rows. */
/* ===== USER SPEC (Task 75): battle stats + history + settings + self care ===== */

/** One finished battle as the profile panels render it (server shape). */
interface BattleHistoryRow {
  id: string;
  code: string;
  type: string;
  mode: string;
  potRule: string;
  result: "W" | "L";
  entry: number;
  take: number;
  net: number;
  myTotal: number;
  myBest: number;
  caseCount: number;
  cases: string[];
  // USER SPEC (Task 81): crate ids for the artwork strip + the full battle
  // config for the RECREATE button on the dedicated history page
  caseIds: string[];
  config: {
    type: string;
    mode: string;
    potRule: string;
    isPrivate: boolean;
    rounds: string[];
  };
  players: { name: string; avatar: string | null; isBot: boolean; team: number; winner: boolean }[];
  finishedAt: number;
}

interface BattleStatsData {
  totals: { battles: number; wins: number; losses: number; winRate: number };
  last5: ("W" | "L")[]; // newest first (the UI flips it to oldest -> newest)
  history: BattleHistoryRow[];
}

/** The neon W/L chip — USER SPEC: W = NEON GREEN, L = NEON RED. */
function ResultBadge({ result, size = "md" }: { result: "W" | "L"; size?: "md" | "lg" }) {
  const win = result === "W";
  return (
    <span
      className={`font-display grid shrink-0 place-items-center rounded-lg border font-black ${
        size === "lg" ? "h-10 w-10 text-lg" : "h-7 w-7 text-sm"
      } ${
        win
          ? "border-emerald-400/70 bg-emerald-500/15 text-emerald-300 shadow-[0_0_14px_rgba(52,211,153,0.6),inset_0_0_8px_rgba(52,211,153,0.25)]"
          : "border-rose-500/70 bg-rose-500/15 text-rose-300 shadow-[0_0_14px_rgba(244,63,94,0.6),inset_0_0_8px_rgba(244,63,94,0.25)]"
      }`}
      title={win ? "Won" : "Lost"}
      dir="ltr"
    >
      {result}
    </span>
  );
}

export function ProfileView() {
  const mounted = useMounted();
  const { toast } = useToast();
  const { player: me, patch, refresh } = useSession();

  const balance = useCaseStore((s) => s.balance);
  const inventory = useCaseStore((s) => s.inventory);
  const totalOpened = useCaseStore((s) => s.totalOpened);
  const bestValue = useCaseStore((s) => s.bestValue);
  const pfNonce = useCaseStore((s) => s.pfNonce);
  const xp = useCaseStore((s) => s.xp);
  const dailyOpens = useCaseStore((s) => s.dailyOpens);
  const sellAll = useCaseStore((s) => s.sellAll);
  const clearItems = useCaseStore((s) => s.clearItems);
  const favCount = useAuthStore((s) => s.favCount);

  const [selling, setSelling] = useState(false);
  const [, setTick] = useState(0);
  // USER SPEC (Task 83): battle stats stay on the profile; the LEDGER moved to
  // /profile/balance (BALANCE HISTORY) and the settings to /settings — the
  // only setting still edited here is the trade link, under the avatar.
  const [battleStats, setBattleStats] = useState<BattleStatsData | null>(null);
  const [tradeLink, setTradeLink] = useState("");
  const [savingLink, setSavingLink] = useState(false);
  // USER SPEC (Task 142): the friend-code claim MOVED to the DEPOSIT dialog
  // (the referral fires on the first deposit there). The profile card below
  // keeps only the player's own code + copy.

  // Battle stats + history — the SERVER truth lands here and is MIRRORED to
  // localStorage (USER SPEC: the history also lives on his own browser).
  const loadBattleStats = async () => {
    try {
      const r = await fetch("/api/profile/battles", { cache: "no-store" });
      if (!r.ok) return;
      const data = (await r.json()) as BattleStatsData;
      setBattleStats(data);
      try {
        localStorage.setItem("rb_battle_history_v1", JSON.stringify(data.history));
      } catch {
        /* private browsing etc. — the server copy still flows */
      }
    } catch {
      /* offline — the localStorage mirror below keeps the panels alive */
    }
  };

  // the trade link feeds the block under the avatar (email + self care moved
  // to the /settings page — they load there now)
  const loadTradeLink = async () => {
    try {
      const r = await fetch("/api/settings", { cache: "no-store" });
      if (!r.ok) return;
      const data = (await r.json()) as { settings: { tradeLink: string } };
      setTradeLink(data.settings.tradeLink);
    } catch {
      /* retried on the next visit */
    }
  };

  // keep the daily-bonus countdown fresh
  useEffect(() => {
    const t = window.setInterval(() => setTick((k) => k + 1), 30000);
    return () => window.clearInterval(t);
  }, []);

  const lvl = levelFromXp(xp);
  // USER SPEC (Task 104): the daily reward is a SET of free cases — every
  // daily case up to the player's level opens free once per 24h.
  const dailyUnlocked = unlockedDailyCases(lvl.level);
  const dailyReadyCount = readyDailyCount(dailyOpens, lvl.level);
  const dailyNextIn = nextDailyReadyIn(dailyOpens, lvl.level);

  // the trade link loads once the session player exists (and after sign-in)
  const meId = me?.id ?? null;
  useEffect(() => {
    if (meId) void loadTradeLink();
  }, [meId]);

  // USER SPEC (Task 75): the battle panels paint INSTANTLY from the browser
  // mirror, then the server refreshes everything (Task 83: email, language,
  // sound and self care live on the /settings page now).
  useEffect(() => {
    if (!meId) return;
    setBattleStats((prev) => {
      if (prev) return prev;
      try {
        const raw = localStorage.getItem("rb_battle_history_v1");
        if (raw) {
          const history = JSON.parse(raw) as BattleHistoryRow[];
          if (Array.isArray(history) && history.length) {
            const wins = history.filter((h) => h.result === "W").length;
            return {
              totals: {
                battles: history.length,
                wins,
                losses: history.length - wins,
                winRate: Math.round((wins / history.length) * 1000) / 10,
              },
              last5: history.slice(0, 5).map((h) => h.result),
              history,
            };
          }
        }
      } catch {
        /* corrupted mirror — the server response replaces it */
      }
      return prev;
    });
    void loadBattleStats();
  }, [meId]);

  // any battle on the planet flips (create/join/settle) — my numbers may move
  useRealtimeEvent("battle", () => {
    if (meId) void loadBattleStats();
  });

  if (!mounted) {
    return (
      <main className="flex min-h-[60vh] items-center justify-center" aria-label="Profile">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-violet-500/30 border-t-violet-400" />
      </main>
    );
  }

  // ---------- guest ----------
  if (!me) {
    return (
      <main className="relative flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 pb-20 pt-10" aria-label="Guest profile">
                <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative w-full max-w-md rounded-2xl border border-violet-500/25 bg-[#100a1e]/90 p-8 text-center shadow-[0_0_50px_rgba(124,58,237,0.2)]"
        >
          <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full border border-white/10 bg-white/5">
            <User className="h-8 w-8 text-white/50" />
          </span>
          <h1 className="font-display text-2xl font-black text-white">You&apos;re browsing as a guest</h1>
          <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-white/55">
            Sign in with STEAM — the only way in — to fight for your DATABASE bankroll in the worldwide battles,
            keep your balance, inventory and provably fair rolls under your own profile.
          </p>
          <div className="mt-6 flex flex-col gap-2">
            <Link
              href="/login"
              className="neon-btn flex items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-white"
            >
              <Zap className="h-4 w-4" fill="currentColor" />
              Sign In with Steam
            </Link>
            <Link
              href="/#cases"
              className="rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-white/75 transition-colors hover:bg-white/10 hover:text-white"
            >
              Browse Cases Instead
            </Link>
          </div>
        </motion.div>
      </main>
    );
  }

  // ---------- signed in ----------
  const invValue = inventory.reduce((sum, i) => sum + i.v, 0);

  const handleSellAll = async () => {
    if (inventory.length === 0) return;
    setSelling(true);
    try {
      const total = inventory.reduce((sum, i) => sum + i.v, 0);
      // SERVER-VALIDATED (Task 64): the client names the uids, the server
      // credits the values IT stored and deletes the DB rows.
      const r = await fetch("/api/inventory/sell", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ all: true }),
      });
      const data = (await r.json().catch(() => ({}))) as { balance?: number; credit?: number; error?: string };
      if (!r.ok || typeof data.balance !== "number") {
        toast({ title: "The sell failed", description: data.error ?? "Try again in a moment.", variant: "destructive" });
        sfx.error();
        return;
      }
      patch({ balance: data.balance });
      clearItems();
      sfx.coins();
      toast({
        title: (
          <>
            Inventory sold for <Coin /> {formatCoins(data.credit ?? total)}
          </>
        ),
        description: "Funds were added to your database balance.",
      });
      void loadTradeLink();
    } finally {
      setSelling(false);
    }
  };

  // USER SPEC (Task 81): the ID chip copies the SITE id (never the Steam id)
  // — the hover tooltip already shows it right next to the player's name.
  const copyMyId = async () => {
    sfx.click();
    try {
      await navigator.clipboard.writeText(me.id);
      toast({
        title: "ID copied",
        description: <span dir="ltr" className="font-mono font-bold">{me.id}</span>,
      });
    } catch {
      toast({
        title: "Copy failed",
        description: "The browser blocked the clipboard — the full ID shows when you hover the ID button.",
        variant: "destructive",
      });
      sfx.error();
    }
  };

  // USER SPEC (Task 75 + 83): save the trade link — the SERVER validates the
  // shape and stores it on the player row. PARTIAL update: the body carries
  // ONLY the trade link, so the email edited on /settings can never be
  // clobbered from here (and the other way around).
  const saveTradeLink = async () => {
    setSavingLink(true);
    try {
      const r = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tradeLink }),
      });
      const data = (await r.json().catch(() => ({}))) as {
        settings?: { tradeLink: string };
        error?: string;
      };
      if (!r.ok || !data.settings) {
        toast({
          title: "Trade link rejected",
          description: data.error ?? "Try again in a moment.",
          variant: "destructive",
        });
        sfx.error();
        return;
      }
      setTradeLink(data.settings.tradeLink);
      patch({ tradeLink: data.settings.tradeLink || null });
      sfx.coins();
      toast({
        title: "Settings saved",
        description: "Your Steam trade link is on file — winnings can be pulled to it.",
      });
    } finally {
      setSavingLink(false);
    }
  };

  return (
    <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-10" aria-label="User profile">

      <div className="relative mx-auto max-w-5xl px-4">
        {/* header — USER SPEC (Task 81 + 83): the TRADE LINK sits under the
            ROUND level-ringed avatar, STEAM + ID chips next to the name, and
            the right column stacks the buttons — BATTLE HISTORY /
            BALANCE HISTORY / SETTINGS / MISSIONS + SIGN OUT (Task 33: the
            sign-out moved here from the site header) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="flex flex-col items-center gap-4 rounded-2xl border border-violet-500/25 bg-[#100a1e]/90 p-6 shadow-[0_0_50px_rgba(124,58,237,0.18)] sm:flex-row sm:items-start sm:text-left"
        >
          {/* avatar column — the trade link lives right under the picture.
              USER SPEC (Task 83): the picture is ROUND and wrapped in the
              LEVEL ring — the circle's color is the player's level tier
              (1-10 green, 11-19 turquoise, 20-29 blue, 30-39 purple,
              40-49 pink, 50-59 red, 60-69 orange, 70-79 yellow, 80+ gold) */}
          <div className="flex w-full shrink-0 flex-col items-center gap-3 sm:w-64">
            <LevelRing level={lvl.level}>
              {me.avatar ? (
                <img
                  src={me.avatar}
                  alt={me.name}
                  referrerPolicy="no-referrer"
                  className="h-full w-full rounded-full object-cover"
                />
              ) : (
                <span className="font-display grid h-full w-full place-items-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 text-4xl font-black text-white">
                  {me.name.charAt(0).toUpperCase()}
                </span>
              )}
            </LevelRing>
            <div className="w-full rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <div className="flex items-center gap-1.5">
                <Link2 className="h-3.5 w-3.5 text-emerald-300" />
                <p className="text-[10px] font-black uppercase tracking-widest text-white/60">Trade link</p>
                {me.tradeLink && (
                  <span className="rounded-full border border-emerald-400/40 bg-emerald-500/10 px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wide text-emerald-300">
                    saved
                  </span>
                )}
              </div>
              <input
                value={tradeLink}
                onChange={(e) => setTradeLink(e.target.value)}
                dir="ltr"
                placeholder="https://steamcommunity.com/tradeoffer/new/?partner=..."
                className="mt-2 h-9 w-full rounded-lg border border-white/15 bg-black/40 px-2.5 text-xs text-white placeholder:text-white/25 focus:border-emerald-400/60 focus:outline-none"
                aria-label="Steam trade link"
              />
              <Button
                onClick={() => void saveTradeLink()}
                disabled={savingLink}
                className="neon-btn mt-2 h-8 w-full rounded-lg text-[11px] font-black text-white disabled:opacity-50"
              >
                {savingLink ? "Saving..." : "Save link"}
              </Button>
              {/* USER SPEC (Task 82): FIND HERE — jumps to the exact Steam page
                  where the trade URL is copied from */}
              <a
                href="https://steamcommunity.com/id/me/tradeoffers/privacy"
                target="_blank"
                rel="noreferrer"
                onClick={() => sfx.click()}
                className="mt-1.5 flex items-center justify-center gap-1 text-[10px] font-black uppercase tracking-widest text-emerald-400 transition-colors hover:text-emerald-300"
                aria-label="Open the Steam page where you find your trade link"
              >
                <ExternalLink className="h-3 w-3" />
                FIND HERE
              </a>
            </div>
          </div>
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
              <h1 className="font-display text-3xl font-black text-white">{me.name}</h1>
              {/* USER SPEC (Task 81): STEAM chip — opens the player's Steam profile
                  (it absorbed the old static provider badge — Steam is the only
                  sign-in provider, so the badge was the same word twice) */}
              {me.providerId ? (
                <a
                  href={`https://steamcommunity.com/profiles/${me.providerId}`}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => sfx.click()}
                  title="Open the Steam profile"
                  aria-label="Open the Steam profile"
                  className="grid h-7 place-items-center rounded-lg border border-sky-400/40 bg-sky-500/10 px-2.5 text-[10px] font-black tracking-wide text-sky-300 transition-colors hover:bg-sky-500/20 hover:text-sky-200"
                >
                  STEAM
                </a>
              ) : (
                <span className="rounded-full border border-emerald-400/40 bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-black tracking-wide text-emerald-300">
                  {me.provider.toUpperCase()}
                </span>
              )}
              {/* USER SPEC (Task 81): ID chip — hover shows the SITE id, click copies it */}
              <span className="group relative inline-flex">
                <button
                  type="button"
                  onClick={() => void copyMyId()}
                  aria-label="Copy your ROLLBOX ID"
                  className="grid h-7 place-items-center rounded-lg border border-white/15 bg-white/5 px-2 text-[10px] font-black tracking-wide text-white/60 transition-colors hover:bg-white/10 hover:text-white"
                >
                  ID
                </button>
                <span
                  role="tooltip"
                  className="pointer-events-none absolute left-1/2 top-full z-50 mt-1.5 -translate-x-1/2 whitespace-nowrap rounded-lg border border-white/15 bg-black/90 px-2 py-1 font-mono text-[10px] font-bold text-white/90 opacity-0 shadow-[0_0_18px_rgba(0,0,0,0.6)] transition-opacity group-hover:opacity-100 group-focus-within:opacity-100"
                  dir="ltr"
                >
                  {me.id}
                </span>
              </span>
            </div>
            <p className="mt-1 flex items-center justify-center gap-1.5 text-xs text-white/50 sm:justify-start">
              <Sparkles className="h-3.5 w-3.5 text-amber-300" />
              ROLLBOX member since{" "}
              {me.createdAt
                ? new Date(me.createdAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })
                : "today"}
            </p>

            {/* USER SPEC (Task 22 → reworked Task 142): the REFERRAL card sits
                to the RIGHT of the trade link. NO link anywhere — the invite
                travels as a CODE only. Your friend types the code into the
                DEPOSIT dialog; on his FIRST deposit he gets +5% extra coins
                and you get a flat $1.50 gift from the site. */}
            <div className="mt-4 w-full rounded-xl border border-emerald-400/25 bg-emerald-500/[0.05] p-3 text-left">
              <div className="flex items-center gap-1.5">
                <Gift className="h-3.5 w-3.5 text-emerald-300" />
                <p className="text-[10px] font-black uppercase tracking-widest text-white/60">Invite &amp; earn</p>
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <span
                  className="rounded-lg border border-emerald-400/40 bg-black/40 px-2.5 py-1.5 font-mono text-xs font-black tracking-[0.2em] text-emerald-300"
                  dir="ltr"
                >
                  {me.refCode ?? "········"}
                </span>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(me.refCode ?? "");
                      toast({ title: "Invite code copied!" });
                    } catch {
                      toast({ title: "Could not copy — select it manually" });
                    }
                  }}
                  className="flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-wide text-white/70 transition-colors hover:bg-white/10 hover:text-white"
                  aria-label="Copy your invite code"
                >
                  <Copy className="h-3 w-3" />
                  Code
                </button>
              </div>
              {me.referredBy && <p className="mt-2 text-[10px] font-bold text-emerald-300">Invite code applied ✓</p>}
              <p className="mt-2 text-[10px] font-semibold leading-relaxed text-white/45">
                Share the CODE (no links). A friend who types it into the{" "}
                <span className="text-emerald-300">DEPOSIT dialog</span> gets{" "}
                <span className="font-black text-emerald-300">+5%</span> extra on his{" "}
                <span className="text-emerald-300">first deposit</span> — and you earn a{" "}
                <span className="font-black text-emerald-300">$1.50</span> gift for inviting him.
              </p>
            </div>
          </div>
          {/* USER SPEC (Task 83 + 31): the header's buttons in this exact
              order: BATTLE HISTORY, BALANCE HISTORY, SETTINGS, MISSIONS. The
              ledger and the settings each live on their own page now. */}
          <div className="flex w-full flex-col gap-2 sm:w-44">
            <Link
              href="/profile/battles"
              onClick={() => sfx.click()}
              className="neon-btn flex items-center justify-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-black text-white"
            >
              <Swords className="h-4 w-4" />
              BATTLE HISTORY
            </Link>
            <Link
              href="/profile/balance"
              onClick={() => sfx.click()}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-emerald-400/40 bg-emerald-500/10 px-4 py-2.5 text-xs font-black text-emerald-200 transition-colors hover:bg-emerald-500/20 hover:text-emerald-100"
            >
              <History className="h-4 w-4" />
              BALANCE HISTORY
            </Link>
            {/* QOL (Task 167): the FULL record — opens / battles / money on one page */}
            <Link
              href="/profile/history"
              onClick={() => sfx.click()}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-sky-400/40 bg-sky-500/10 px-4 py-2.5 text-xs font-black text-sky-200 transition-colors hover:bg-sky-500/20 hover:text-sky-100"
            >
              <ScrollText className="h-4 w-4" />
              FULL HISTORY
            </Link>
            <Link
              href="/settings"
              onClick={() => sfx.click()}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-violet-400/40 bg-violet-500/10 px-4 py-2.5 text-xs font-black text-violet-200 transition-colors hover:bg-violet-500/20 hover:text-violet-100"
            >
              <Settings2 className="h-4 w-4" />
              SETTINGS
            </Link>
            {/* USER SPEC (Task 31): the MISSIONS button sits DIRECTLY BELOW the
                SETTINGS button — the board lives on /missions */}
            <Link
              href="/missions"
              onClick={() => sfx.click()}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-fuchsia-400/40 bg-fuchsia-500/10 px-4 py-2.5 text-xs font-black text-fuchsia-200 transition-colors hover:bg-fuchsia-500/20 hover:text-fuchsia-100"
            >
              <Target className="h-4 w-4" />
              MISSIONS
            </Link>
            {/* USER SPEC (Task 33): SIGN OUT lives HERE now — it left the site
                header with the Task 33 rework and lands at the bottom of the
                profile's button stack */}
            <button
              type="button"
              aria-label="Sign out of ROLLBOX"
              title="Sign out"
              className="flex items-center justify-center gap-1.5 rounded-xl border border-red-400/40 bg-red-500/10 px-4 py-2.5 text-xs font-black text-red-200 transition-colors hover:bg-red-500/20 hover:text-red-100"
              onClick={() => {
                sfx.click();
                void (async () => {
                  try {
                    await fetch("/api/auth/logout", { method: "POST" });
                  } catch {
                    /* the cookie clear is best-effort — sign out anyway */
                  }
                  await refresh();
                  window.location.href = "/";
                })();
              }}
            >
              <LogOut className="h-4 w-4" />
              SIGN OUT
            </button>
          </div>
        </motion.div>

        {/* stats */}
        <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
          {[
            { icon: Coins, label: "Balance", value: (<><Coin /> {formatCoins(me.balance)}</>), color: "text-amber-300" },
            { icon: PackageOpen, label: "Cases Opened", value: me.casesOpened.toLocaleString(), color: "text-violet-300" },
            { icon: Trophy, label: "Battles Won", value: me.battlesWon.toLocaleString(), color: "text-amber-400" },
            { icon: ShieldCheck, label: "Verified Rolls", value: pfNonce.toLocaleString(), color: "text-emerald-300" },
            { icon: Boxes, label: "Inventory Items", value: inventory.length.toLocaleString(), color: "text-fuchsia-300" },
            { icon: Flame, label: "Inventory Value", value: (<><Coin /> {formatCoins(invValue)}</>), color: "text-orange-300" },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
              className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-4 text-center"
            >
              <s.icon className={`mx-auto mb-1.5 h-5 w-5 ${s.color}`} />
              <p className="font-display text-lg font-black text-white">{s.value}</p>
              <p className="text-[10px] font-bold uppercase tracking-wide text-white/45">{s.label}</p>
            </motion.div>
          ))}
        </div>

        {/* USER SPEC (Task 75): battle statistics — totals + the last-5 W/L run */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.04 }}
          className="mt-6 rounded-2xl border border-sky-500/25 bg-[#0b1220]/90 p-6 shadow-[0_0_40px_rgba(56,189,248,0.08)]"
          aria-label="Battle statistics"
        >
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border border-sky-400/40 bg-sky-400/10 shadow-[0_0_18px_rgba(56,189,248,0.2)]">
              <Swords className="h-6 w-6 text-sky-300" />
            </span>
            <div>
              <h2 className="font-display text-xl font-black text-white">
                Battle <span className="text-gradient-neon">stats</span>
              </h2>
              <p className="text-xs text-white/50">
                Every finished battle the SERVER recorded for this account — the same truth the worldwide lobby runs on.
              </p>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
            {[
              { label: "Battles Played", value: (battleStats?.totals.battles ?? 0).toLocaleString(), color: "text-sky-300" },
              { label: "Battles Won", value: (battleStats?.totals.wins ?? 0).toLocaleString(), color: "text-emerald-300" },
              { label: "Battles Lost", value: (battleStats?.totals.losses ?? 0).toLocaleString(), color: "text-rose-300" },
              { label: "Win Rate", value: `${(battleStats?.totals.winRate ?? 0).toLocaleString()}%`, color: "text-amber-300" },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-4 text-center">
                <p className={`font-display text-2xl font-black ${s.color}`}>{s.value}</p>
                <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wide text-white/45">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="mt-5 rounded-xl border border-white/10 bg-white/[0.02] px-4 py-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-[10px] font-black uppercase tracking-widest text-white/45">Last 5 battles</p>
              <p className="text-[10px] font-bold text-white/30">oldest → newest</p>
            </div>
            <div className="mt-3 flex min-h-[2.5rem] items-center gap-2.5" dir="ltr">
              {battleStats && battleStats.last5.length > 0 ? (
                [...battleStats.last5].reverse().map((r, i) => <ResultBadge key={`${i}-${r}`} result={r} size="lg" />)
              ) : (
                <p className="text-sm font-bold text-white/40">
                  No battles yet — the last five results land here as W / L the moment they finish.
                </p>
              )}
            </div>
          </div>
        </motion.div>

        {/* battle pass */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.05 }}
          className="mt-6 rounded-2xl border border-fuchsia-500/25 bg-[#100a1e]/90 p-6 shadow-[0_0_40px_rgba(147,51,234,0.12)]"
          aria-label="Level progression"
        >
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              {/* USER SPEC (Task 33): the crown icon is GONE — the amber tile
                  now shows the player's LEVEL NUMBER itself */}
              <span
                className="font-display grid h-12 w-12 shrink-0 place-items-center rounded-xl border border-amber-400/40 bg-amber-400/10 shadow-[0_0_18px_rgba(240,185,11,0.25)]"
                title={`Level ${lvl.level}`}
                aria-label={`Level ${lvl.level}`}
              >
                <span className="text-2xl font-black leading-none text-amber-300" dir="ltr">
                  {lvl.level}
                </span>
              </span>
              <div>
                {/* USER SPEC (Task 33): the section is titled LEVEL PROGRESSION */}
                <h2 className="font-display text-xl font-black text-white">
                  LEVEL <span className="text-gradient-neon">PROGRESSION</span>
                </h2>
                <p className="text-xs text-white/50">
                  {lvl.intoLevel} / {lvl.needed} XP to Level {lvl.level + 1} • earn 1 XP per $10 wagered on cases
                </p>
              </div>
            </div>
            <div className="text-center sm:text-right">
              <p className="font-display text-lg font-black text-amber-300">
                {dailyUnlocked.length > 0 ? `${dailyReadyCount} / ${dailyUnlocked.length}` : "—"}
              </p>
              <p className="text-[10px] font-bold uppercase tracking-wide text-white/45">
                {dailyUnlocked.length > 0
                  ? `Daily cases ready • ${dailyReadyCount > 0 ? "open now" : `next in ${formatCountdown(dailyNextIn)}`}`
                  : "Daily cases unlock at Level 3"}
              </p>
            </div>
          </div>
          <div
            className="mt-4 h-3 overflow-hidden rounded-full bg-black/50"
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(lvl.progress * 100)}
            aria-label="Level progress"
          >
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-300 via-fuchsia-400 to-violet-500 shadow-[0_0_12px_rgba(192,38,211,0.5)] transition-all"
              style={{ width: `${Math.max(4, Math.round(lvl.progress * 100))}%` }}
            />
          </div>
          <p className="mt-3 text-xs leading-relaxed text-white/45">
            Every daily case up to your level opens FREE once every 24 hours — LEVEL 3 through
            your tier vault, each with its own timer (from Level 3). Leveling up still grants an
            instant coin reward.
          </p>
        </motion.div>

        {/* USER SPEC (Task 83): the money LEDGER moved to the BALANCE HISTORY
            page (/profile/balance) — the header's BALANCE HISTORY button lands
            there; this profile stays lean */}

        {/* inventory preview */}
        <div className="mt-8">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-xl font-black text-white">
              Exchange <span className="text-gradient-neon">inventory</span>
            </h2>
            {/* C11: the preview leads with the items worth the most */}
            {inventory.length > 0 && (
              <span className="rounded-full border border-amber-400/40 bg-amber-500/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-wide text-amber-300">
                Top 10 by value
              </span>
            )}
            <div className="flex gap-2">
              <Link
                href="/skins"
                className="neon-btn flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-black text-white"
              >
                <Zap className="h-3.5 w-3.5" fill="currentColor" />
                Exchange More Coins
              </Link>
              {inventory.length > 0 && (
                <Button
                  onClick={() => void handleSellAll()}
                  disabled={selling}
                  className="gold-btn h-9 rounded-lg px-4 text-xs font-black text-black disabled:opacity-50"
                >
                  <ShoppingCart className="h-3.5 w-3.5" />
                  {selling ? (
                    "Selling..."
                  ) : (
                    <>
                      Sell All • <Coin /> {formatCoins(invValue)}
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>

          {inventory.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-12 text-center">
              <PackageOpen className="mx-auto mb-3 h-10 w-10 text-white/25" />
              <p className="text-sm font-bold text-white/60">Your inventory is empty</p>
              <p className="mt-1 text-xs text-white/40">
                Win battles, open cases, then turn your coins into skins on the Exchange — they land here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-5">
              {/* C11: the 10 MOST VALUABLE items — not merely the first 10 */}
              {inventory
                .slice()
                .sort((a, b) => b.v - a.v)
                .slice(0, 10)
                .map((it) => (
                  <InvTile key={it.uid} item={it} />
                ))}
            </div>
          )}
          {inventory.length > 10 && (
            <p className="mt-3 text-center text-xs text-white/40">
              + {inventory.length - 10} more items — open{" "}
              <span className="font-bold text-white/60">My Inventory</span> in the top bar to see
              everything.
            </p>
          )}
        </div>

      </div>

    </main>
  );
}

/** One inventory snapshot tile — the CDN render with the SVG art fallback.
 *  USER SPEC (Task 26): expandImg resolves the compact "~1…" Steam shorthand
 *  (steam-bought skins) to the real CDN URL — a raw shorthand src is a broken
 *  relative URL and the tile used to fall back to the generic SVG art. */
function InvTile({
  item,
}: {
  item: {
    n: string;
    w?: string;
    wear?: string;
    r: string;
    v: number;
    img: string | null;
    a?: string;
  };
}) {
  const [failed, setFailed] = useState(false);
  const tint = "#8882a8";
  const url = expandImg(item.img);
  return (
    <span
      className="relative flex h-36 w-full flex-col items-center justify-center overflow-hidden rounded-xl border bg-[#130d22] p-2"
      title={`${item.n} — $${formatCoins(item.v)}`}
    >
      {url && !failed ? (
        <img
          src={url}
          alt={item.n}
          loading="lazy"
          draggable={false}
          onError={() => setFailed(true)}
          className="max-h-14 w-full select-none object-contain drop-shadow-lg"
        />
      ) : (
        <WeaponArt
          kind={(item.a ?? "ak") as WeaponKind}
          colors={[tint, "#1a1426"]}
          className="max-h-14 w-full object-contain opacity-70"
        />
      )}
      <span className="mt-1 w-full truncate text-center text-[10px] font-bold text-white/70" dir="ltr">
        {item.n.includes("|") ? item.n.split("|")[1].trim() : item.n}
      </span>
      {/* R43 USER SPEC: the item's exterior — ALWAYS listed on a skin, in its color */}
      {isWearableKind(item.w) && (
        <span
          className="w-full truncate text-center text-[9px] font-black uppercase tracking-wider"
          dir="ltr"
          style={{ color: wearColorOf(item.wear) }}
          title={`Exterior: ${displayWearLabel(item.wear, item.n)}`}
        >
          {displayWearLabel(item.wear, item.n)}
        </span>
      )}
      <span className="font-display text-[11px] font-black text-amber-300" dir="ltr">
        <Coin /> {formatCoins(item.v)}
      </span>
    </span>
  );
}
