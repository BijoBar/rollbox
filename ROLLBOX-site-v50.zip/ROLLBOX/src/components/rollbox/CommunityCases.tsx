"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Plus, Users } from "lucide-react";
import { formatCoins } from "@/lib/cases";
import { DESIGN_ART, isCommunityDesign } from "@/lib/community-designs";
import { sfx } from "@/lib/sound";
import { Coin } from "./Coin";

/**
 * USER SPEC (Task 142) — the home-page COMMUNITY CASES category.
 * Sits right below "Special for you". The CREATE YOUR OWN CASE button sits
 * right below the heading. The section always reads the 10 NEWEST player
 * -built cases from the DB (/api/community-cases) and every 30 minutes the
 * display ROTATES (offset shifts + fresh fetch) so different boxes surface.
 */

const ROTATE_MS = 30 * 60 * 1000; // USER SPEC: every 30 minutes

interface CaseCard {
  id: string;
  name: string;
  creatorName: string;
  design: string;
  price: number;
  createdAt: string;
}

export function CommunityCases() {
  const [cases, setCases] = useState<CaseCard[] | null>(null);
  const [offset, setOffset] = useState(0);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/community-cases", { cache: "no-store" });
      if (!r.ok) return;
      const d = (await r.json()) as { cases?: CaseCard[] };
      if (Array.isArray(d.cases)) setCases(d.cases);
    } catch {
      /* the next rotation retries */
    }
  }, []);

  useEffect(() => {
    // async fetch → setState lands in a microtask, not synchronously
    const t0 = window.setTimeout(() => void load(), 0);
    // every 30 minutes: re-read the 10 newest + rotate the presentation order
    const t = window.setInterval(() => {
      setOffset((o) => o + 1);
      void load();
    }, ROTATE_MS);
    return () => {
      window.clearTimeout(t0);
      window.clearInterval(t);
    };
  }, [load]);

  const list = cases ?? [];
  const rotated = list.length > 1 ? [...list.slice(offset % list.length), ...list.slice(0, offset % list.length)] : list;

  return (
    <section id="community" className="relative mx-auto mt-16 max-w-7xl scroll-mt-24" aria-label="Community cases — player-built">
      <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.5 }} className="mb-6 text-center">
        <h2 className="text-3xl font-black text-white md:text-4xl">
          Community <span className="text-gradient-neon">cases</span>
        </h2>
        <p className="mt-2 text-xs font-semibold tracking-wide text-white/45">
          Cases built by players, for players — the 10 newest from the database
        </p>
        {/* USER SPEC: the CREATE YOUR OWN CASE button sits right below the heading */}
        <Link
          href="/case-builder"
          onClick={() => sfx.click()}
          className="mt-4 inline-flex items-center gap-2 rounded-xl border border-violet-400/50 bg-gradient-to-r from-violet-600 to-fuchsia-600 px-6 py-3 text-sm font-black uppercase tracking-wider text-white shadow-[0_0_26px_rgba(139,92,246,0.4)] transition-all hover:brightness-110"
          data-testid="create-own-case"
        >
          <Plus className="h-4.5 w-4.5" strokeWidth={3} />
          Create your own case
        </Link>
      </motion.div>

      {list.length === 0 ? (
        <div className="grid place-items-center gap-2 rounded-2xl border border-dashed border-white/12 py-12 text-center">
          <Users className="h-8 w-8 text-white/25" />
          <p className="text-sm font-bold text-white/55">No community cases yet</p>
          <p className="max-w-sm text-xs font-semibold leading-relaxed text-white/35">
            Be the first creator — build a case from your favorite skins and publish it for everyone to open.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {rotated.map((c, i) => {
            const design = isCommunityDesign(c.design) ? c.design : "red";
            return (
              <motion.div
                key={c.id}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.35, delay: Math.min(i * 0.04, 0.3) }}
              >
                <Link
                  href={`/case/${c.id}`}
                  onClick={() => sfx.click()}
                  className="group relative flex flex-col items-center gap-2 overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-transparent p-3 text-center transition-all hover:border-violet-400/50 hover:shadow-[0_0_26px_rgba(139,92,246,0.25)]"
                  data-testid="community-case-card"
                >
                  <span className="absolute left-2 top-2 rounded-md border border-white/15 bg-black/50 px-1.5 py-0.5 font-mono text-[9px] font-black tracking-widest text-white/60">
                    COMMUNITY
                  </span>
                  { }
                  <img
                    src={DESIGN_ART[design]}
                    alt={c.name}
                    loading="lazy"
                    draggable={false}
                    className="mt-4 h-28 w-auto select-none object-contain transition-transform duration-300 group-hover:scale-105"
                  />
                  <span className="w-full truncate text-sm font-black text-white" dir="ltr" title={c.name}>
                    {c.name}
                  </span>
                  <span className="flex items-center gap-1 text-[10px] font-bold text-violet-300/80" dir="ltr">
                    <Users className="h-3 w-3" />
                    by {c.creatorName}
                  </span>
                  <span className="gold-btn flex h-8 w-full items-center justify-center gap-1 rounded-lg text-[11px] font-black text-black">
                    Open Case • <Coin className="h-3 w-3" /> {formatCoins(c.price)}
                  </span>
                </Link>
              </motion.div>
            );
          })}
        </div>
      )}
    </section>
  );
}
