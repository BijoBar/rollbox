"use client";

import { useMemo } from "react";
import { Layers, Coins } from "lucide-react";
import { oddsPct, RARITY_META, caseItemSkin, formatCoins, formatOdds, type CaseDef } from "@/lib/cases";
import { CaseImage } from "./CaseImage";
import { Coin } from "./Coin";
import { SkinImage } from "./SkinImage";
import { WearTag } from "./WearTag";
import { RarityBackdrop } from "./RarityBackdrop";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

/**
 * USER SPEC (Task 42): a VIEW DROPS button on every case in the battle-creator
 * opens the case's full contents right here on the page — skin art, name,
 * value and the exact drop chance, sorted from the rarest pull down.
 */
export function CaseDropsDialog({
  caseDef,
  open,
  onOpenChange,
}: {
  caseDef: CaseDef | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const items = useMemo(() => {
    if (!caseDef) return [];
    return [...caseDef.items]
      .map((it) => ({
        ...it,
        skin: caseItemSkin(it),
        pct: oddsPct(caseDef, it.skinId),
      }))
      .filter((it) => it.skin)
      .sort((a, b) => b.skin.value - a.skin.value || b.pct - a.pct);
  }, [caseDef]);

  // Task 76: the shared formatOdds — the old toFixed(1)/toFixed(2) label
  // rendered a 0.00025% item as "0.00%"; formatOdds keeps tiny odds visible
  const pctLabel = (pct: number) => formatOdds(pct) + "%";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-hidden border-amber-400/30 bg-[#0d0819] p-0 sm:max-w-3xl">
        {caseDef && (
          <>
            <DialogHeader className="border-b border-white/10 px-5 pb-3 pt-4">
              <DialogTitle className="font-display flex flex-wrap items-center gap-3 text-lg font-black tracking-wide text-white">
                <span className="h-10 w-10 shrink-0">
                  <CaseImage caseId={caseDef.id} alt="" color={caseDef.tierColor} color2={caseDef.tierColor2} communityDesign={caseDef.communityDesign} sizes="40px" />
                </span>
                <span className="min-w-0">
                  <span className="flex items-center gap-2">
                    <Layers className="h-4 w-4 shrink-0 text-amber-300" />
                    {caseDef.name} — DROPS
                  </span>
                  <span className="mt-0.5 flex items-center gap-1 text-[11px] font-bold text-white/45">
                    <Coins className="h-3 w-3" />
                    Case price <Coin /> {formatCoins(caseDef.price)} • {items.length} possible items
                  </span>
                </span>
              </DialogTitle>
              <DialogDescription className="text-xs font-semibold text-white/45">
                Every round of the battle opens this exact pool — chances are the real drop odds.
              </DialogDescription>
            </DialogHeader>

            <div className="max-h-[62vh] overflow-y-auto px-5 pb-5 pt-3" dir="ltr">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
                {items.map((it) => {
                  const rc = RARITY_META[it.skin.rarity].color;
                  return (
                    <div
                      key={it.skinId + (it.wear ?? "")}
                      className="relative flex flex-col overflow-hidden rounded-xl border bg-[#130d22]"
                      style={{ borderColor: rc + "55" }}
                      title={`${it.skin.name} — drop chance ${pctLabel(it.pct)}`}
                    >
                      {/* USER SPEC (Task 89/89b): eclipse artwork backdrop per rarity */}
                      <RarityBackdrop rarity={it.skin.rarity} className="inset-x-0 top-0 h-1/2" />
                      <span
                        className="font-display absolute right-1.5 top-1.5 z-10 rounded-md bg-black/70 px-1.5 py-0.5 text-[9px] font-black text-amber-300"
                        aria-label={`Drop chance ${pctLabel(it.pct)}`}
                      >
                        {pctLabel(it.pct)}
                      </span>
                      <span className="relative flex h-20 items-center justify-center px-2 pt-1">
                        <SkinImage
                          skinId={it.skinId}
                          kind={it.skin.weapon}
                          colors={it.skin.colors}
                          alt={it.skin.name}
                          className="max-h-[72px] w-full object-contain drop-shadow-lg"
                        />
                      </span>
                      <span className="relative truncate px-2 text-[9px] font-bold uppercase tracking-wider" style={{ color: rc }}>
                        {RARITY_META[it.skin.rarity].label}
                      </span>
                      <span className="relative truncate px-2 text-[11px] font-bold text-white/90" title={it.skin.name}>
                        {it.skin.name}
                      </span>
                      {/* R43 USER SPEC: the pool's exterior — always listed, in its color */}
                      <WearTag wear={it.wear} className="relative truncate px-2 pb-1 pt-0.5 text-[9px]" />
                      <span className={cn("relative px-2 pb-2 pt-0.5 text-[11px] font-black text-amber-300")}>
                        <Coin /> {formatCoins(it.skin.value)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
