"use client";

import { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";

/**
 * Animated count-up number — starts when scrolled into view and re-animates
 * FROM the currently shown value (so a 30s stats refresh never flashes 0).
 * Extracted from the old hero stats so the StatsLine can use it too.
 */
export function CountUp({ to, format }: { to: number; format?: (n: number) => React.ReactNode }) {
  const ref = useRef<HTMLSpanElement>(null);
  // USER SPEC (Task 32): the strip now sits at the VERY TOP of every page —
  // the old -40px margin shrank the viewport past it, so the animation never
  // fired and the numbers stayed 0. Zero margin = visible is visible.
  const inView = useInView(ref, { once: true, margin: "0px" });
  const [val, setVal] = useState(0);
  const fromRef = useRef(0);

  useEffect(() => {
    if (!inView) return;
    const from = fromRef.current;
    const dur = 1600;
    const t0 = performance.now();
    let raf = 0;
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      const v = Math.round(from + (to - from) * eased);
      fromRef.current = v;
      setVal(v);
      if (p < 1) raf = requestAnimationFrame(step);
      else fromRef.current = to;
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);

  return <span ref={ref}>{format ? format(val) : val.toLocaleString("en-US")}</span>;
}
