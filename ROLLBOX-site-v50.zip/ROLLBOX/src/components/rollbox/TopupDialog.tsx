"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { create } from "zustand";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { BadgeDollarSign, Gift, LogIn, Wallet } from "lucide-react";
import { useSession } from "@/lib/session";
import { formatCoins } from "@/lib/cases";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { Coin } from "./Coin";

/**
 * Shared open state — the TopBar WALLET button (USER SPEC Task 28: the wallet
 * symbol that replaced the volume toggle) pops this dialog from any page.
 */
export const useTopup = create<{ open: boolean; setOpen: (v: boolean) => void }>((set) => ({
  open: false,
  setOpen: (open) => set({ open }),
}));

const PRESETS = [25, 50, 100, 250, 500, 1000];
/** USER SPEC (Task 142): the deposit limit is now $10,000 (was 100,000). */
const TOPUP_MAX = 10_000;
const REF_LOCAL_KEY = "rb_ref_code"; // RefCapture parks /?ref= here

/**
 * USER SPEC (Task 28): the TOPUP dialog — type an amount (or pick a chip),
 * press BUY, the balance is credited. Money on ROLLBOX is a demo: no payment
 * processor sits behind the button, the server just credits the DB balance
 * and writes the "topup" ledger row.
 * USER SPEC (Task 142): the dialog carries a REFERRAL CODE field — entering a
 * friend's code on the player's FIRST deposit pays +5% extra coins to the
 * depositor and a flat $1.5 gift to the friend who owns the code.
 */
export function TopupDialog() {
  const open = useTopup((s) => s.open);
  const setOpen = useTopup((s) => s.setOpen);
  const { player: me, patch, refresh } = useSession();
  const { toast } = useToast();

  const [amount, setAmount] = useState("");
  const [refCode, setRefCode] = useState("");
  const [busy, setBusy] = useState(false);

  // a parked /?ref=CODE pre-fills the field (claimed at the deposit now)
  useEffect(() => {
    if (!open || !me || me.referredBy) return;
    try {
      const parked = window.localStorage.getItem(REF_LOCAL_KEY);
      if (parked && !refCode) setRefCode(parked);
    } catch {
      /* private mode */
    }
  }, [open, me, refCode]);

  const value = Number(amount);
  const valid = Number.isFinite(value) && value >= 1 && value <= TOPUP_MAX;
  const showRefField = !!me && !me.referredBy;

  const buy = async () => {
    if (busy || !me) return;
    const n = Math.round(value * 100) / 100;
    if (!Number.isFinite(n) || n < 1) {
      toast({ title: "Enter an amount of at least $1" });
      return;
    }
    setBusy(true);
    try {
      const r = await fetch("/api/topup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: n, refCode: refCode.trim().toUpperCase() || undefined }),
      });
      const d = (await r.json()) as { balance?: number; referral?: string; inviter?: string; referralBonus?: number; referralNote?: string; error?: string };
      if (!r.ok || typeof d.balance !== "number") throw new Error(d.error ?? "Could not complete the topup");
      patch({ balance: d.balance });
      if (d.referral === "applied") {
        void refresh(); // referredBy flipped — re-read the session
        try {
          window.localStorage.removeItem(REF_LOCAL_KEY);
        } catch {
          /* nothing */
        }
        sfx.coins();
        toast({
          title: "Referral applied!",
          description: (
            <>
              +<Coin /> {formatCoins(d.referralBonus ?? 0)} bonus on your first deposit — {d.inviter} got $1.50 for inviting you.
            </>
          ),
        });
      } else if (d.referralNote) {
        toast({ title: d.referralNote });
      }
      sfx.coins();
      toast({
        title: "Deposit complete",
        description: (
          <>
            +<Coin /> {formatCoins(n)} credited to your balance
          </>
        ),
      });
      setAmount("");
      setRefCode("");
      setOpen(false);
    } catch (e) {
      sfx.error();
      toast({ title: e instanceof Error ? e.message : "Could not complete the topup", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-sm border-amber-400/25 bg-[#100a1e] p-0 text-white">
        <DialogHeader className="border-b border-white/10 px-5 pb-4 pt-5">
          <DialogTitle className="font-display flex items-center gap-2 text-lg font-black tracking-wide">
            <Wallet className="h-5 w-5 text-amber-300" />
            TOP UP
          </DialogTitle>
          <DialogDescription className="text-xs font-semibold text-white/45">
            Demo balance — no real money. Pick an amount and press BUY.
          </DialogDescription>
        </DialogHeader>

        {!me ? (
          <div className="px-5 pb-6 pt-5 text-center">
            <p className="text-sm font-bold text-white/70">Sign in with Steam to top up your balance.</p>
            <Link
              href="/login"
              className="neon-btn mt-4 inline-flex items-center gap-2 rounded-xl px-6 py-2.5 text-sm font-black text-white"
              onClick={() => {
                sfx.click();
                setOpen(false);
              }}
            >
              <LogIn className="h-4 w-4" />
              Sign In
            </Link>
          </div>
        ) : (
          <div className="px-5 pb-6 pt-4">
            {/* amount input */}
            <div className="flex h-12 items-center gap-2 rounded-xl border border-amber-400/30 bg-black/40 px-3">
              <Coin className="h-4.5 w-4.5" />
              <input
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && valid) void buy();
                }}
                dir="ltr"
                inputMode="decimal"
                placeholder="0"
                aria-label="Topup amount"
                autoFocus
                className="font-display w-full bg-transparent text-lg font-black text-amber-300 tabular-nums focus:outline-none"
              />
              <span className="shrink-0 text-[10px] font-bold text-white/35" dir="ltr">
                MAX {TOPUP_MAX.toLocaleString("en-US")}
              </span>
            </div>

            {/* preset chips */}
            <div className="mt-2.5 grid grid-cols-6 gap-1.5">
              {PRESETS.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    sfx.click();
                    setAmount(String(p));
                  }}
                  className="h-8 rounded-lg border border-white/10 bg-white/[0.04] text-[11px] font-black text-white/60 transition-colors hover:bg-white/10 hover:text-white"
                >
                  {p >= 1000 ? `${p / 1000}K` : p}
                </button>
              ))}
            </div>

            {/* USER SPEC (Task 142): the REFERRAL CODE field */}
            {showRefField && (
              <div className="mt-3 rounded-xl border border-emerald-400/25 bg-emerald-500/[0.06] p-2.5">
                <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-emerald-300">
                  <Gift className="h-3.5 w-3.5" />
                  Referral code
                </p>
                <div className="mt-1.5 flex items-center gap-2">
                  <input
                    value={refCode}
                    onChange={(e) => setRefCode(e.target.value.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 8))}
                    dir="ltr"
                    inputMode="text"
                    maxLength={8}
                    placeholder="FRIEND CODE"
                    aria-label="Referral code"
                    className="h-9 w-full rounded-lg border border-white/15 bg-black/40 px-2.5 text-center font-mono text-xs font-black tracking-[0.25em] text-emerald-200 placeholder:tracking-widest placeholder:text-white/25 focus:border-emerald-400/60 focus:outline-none"
                  />
                </div>
                <p className="mt-1.5 text-[9px] font-semibold leading-relaxed text-white/35" dir="ltr">
                  First deposit only: +5% extra coins for you, a $1.50 gift for the friend who owns the code.
                </p>
              </div>
            )}

            {/* live total */}
            <p className="mt-3 flex items-center justify-between text-xs font-bold text-white/55" dir="ltr">
              <span>You will receive</span>
              <span className="font-display flex items-center gap-1 font-black text-amber-300">
                <Coin className="h-3.5 w-3.5" />
                {valid ? formatCoins(Math.round(value * 100) / 100) : "—"}
              </span>
            </p>

            <button
              type="button"
              disabled={busy || !valid}
              onClick={() => void buy()}
              className="gold-btn mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-xl text-sm font-black text-black disabled:opacity-50"
            >
              <BadgeDollarSign className="h-4 w-4" />
              {busy ? "PROCESSING…" : "BUY"}
            </button>
            <p className="mt-2.5 text-center text-[10px] font-semibold text-white/30">
              Demo deposit — the balance is virtual and carries no real value.
            </p>

            {/* C7 PHASE 1: the bridge to the REAL crypto wallet */}
            <div className="mt-4 rounded-xl border border-emerald-400/25 bg-emerald-500/[0.06] p-3 text-center">
              <p className="text-[10px] font-black uppercase tracking-widest text-emerald-300">Real money</p>
              <p className="mt-1 text-[10px] font-semibold leading-relaxed text-white/50">
                Deposit or withdraw real USDT (TRC-20) — verified by the team.
              </p>
              <Link
                href="/wallet"
                onClick={() => {
                  sfx.click();
                  setOpen(false);
                }}
                className="mt-2 inline-flex items-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-4 py-2 text-[11px] font-black uppercase tracking-wide text-emerald-200 transition-colors hover:bg-emerald-500/25"
              >
                <Wallet className="h-3.5 w-3.5" />
                Open the crypto wallet
              </Link>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
