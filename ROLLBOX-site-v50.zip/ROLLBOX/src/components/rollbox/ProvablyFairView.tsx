"use client";

import { useCallback, useEffect, useMemo, useState, useSyncExternalStore } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  ShieldCheck,
  Lock,
  Unlock,
  KeyRound,
  History,
  Dices,
  Hash,
  Copy,
  Check,
  RefreshCw,
  BadgeCheck,
  BookOpen,
  TriangleAlert,
  ArrowLeft,
  Timer,
} from "lucide-react";
import { CASES, RARITY_META, SKINS, formatCoins, type Rarity } from "@/lib/cases";
import {
  computePublicHash,
  rollFloat,
  rollCasePF,
  shortSeed,
} from "@/lib/provably-fair";
import { useCaseStore, type PFSeedRecord, type PFRollRecord } from "@/lib/store";
import { ServerFairPanel } from "./ServerFairPanel";
import { SkinTile } from "./SkinTile";
import { Coin } from "./Coin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type TabKey = "server" | "seeds" | "check";

const MASK = "•".repeat(34);

const emptySubscribe = () => () => {};

interface CheckResult {
  float: number;
  skinId: string;
  skinName: string;
  rarity: Rarity;
  hash: string | null;
  matched: boolean;
  matchActive: boolean;
}

function CopyBtn({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      aria-label="Copy to clipboard"
      className="shrink-0 rounded-md border border-white/10 bg-white/5 p-1.5 text-white/50 transition-colors hover:bg-white/10 hover:text-white"
      onClick={() => {
        navigator.clipboard?.writeText(text);
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1200);
      }}
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
    </button>
  );
}

export function ProvablyFairView() {
  const search = useSearchParams();
  const { toast } = useToast();

  const ensurePF = useCaseStore((s) => s.ensurePF);
  const pfReady = useCaseStore((s) => s.pfReady);
  const clientSeed = useCaseStore((s) => s.pfClientSeed);
  const publicHash = useCaseStore((s) => s.pfPublicHash);
  const nonce = useCaseStore((s) => s.pfNonce);
  const seedHistory = useCaseStore((s) => s.pfSeedHistory);
  const rolls = useCaseStore((s) => s.pfRolls);
  const clientHistory = useCaseStore((s) => s.pfClientHistory);
  const revealServerSeed = useCaseStore((s) => s.revealServerSeed);
  const setClientSeed = useCaseStore((s) => s.setClientSeed);

  const [tab, setTab] = useState<TabKey>(() => {
    const t = search.get("tab");
    return t === "check" ? "check" : t === "seeds" ? "seeds" : "server";
  });
  const [changeOpen, setChangeOpen] = useState(false);
  const [revealOpen, setRevealOpen] = useState(false);
  const [serverHistOpen, setServerHistOpen] = useState(false);
  const [clientHistOpen, setClientHistOpen] = useState(false);
  const [seedInput, setSeedInput] = useState("");

  // check-roll form — prefilled from query params (?tab=check&case=..&nonce=..&client=..)
  const [chkServer, setChkServer] = useState("");
  const [chkSalt, setChkSalt] = useState("");
  const [chkClient, setChkClient] = useState(() => search.get("client") ?? "");
  const [chkNonce, setChkNonce] = useState(() => {
    const n = search.get("nonce");
    return n && Number(n) >= 1 ? n : "1";
  });
  const [chkCase, setChkCase] = useState<string>(() => {
    const c = search.get("case");
    return c && CASES.some((cs) => cs.id === c) ? c : CASES[0]?.id ?? "";
  });
  const [checkResult, setCheckResult] = useState<CheckResult | null>(null);

  // hydration-safe mount flag + seed the provably-fair engine
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);

  useEffect(() => {
    ensurePF();
  }, [ensurePF]);

  const revealedByHash = useMemo(() => {
    const map = new Map<string, PFSeedRecord>();
    for (const r of seedHistory) map.set(r.publicHash, r);
    return map;
  }, [seedHistory]);

  const doReveal = useCallback(() => {
    revealServerSeed();
    setRevealOpen(false);
    toast({
      title: "Server seed revealed",
      description:
        "The old seed pair moved to Server Seed History and a fresh commitment is active.",
    });
  }, [revealServerSeed, toast]);

  const doChangeSeed = useCallback(
    (custom: string) => {
      setClientSeed(custom);
      setChangeOpen(false);
      setSeedInput("");
      toast({
        title: "Client seed changed",
        description:
          "Previous server seed was revealed into history — a new commitment is active.",
      });
    },
    [setClientSeed, toast]
  );

  const onCompute = useCallback(() => {
    const caseDef = CASES.find((c) => c.id === chkCase) ?? CASES[0];
    const n = Number(chkNonce);
    if (!chkServer.trim() || !chkClient.trim() || !Number.isInteger(n) || n < 1) {
      toast({
        title: "Missing data",
        description: "Server seed, client seed and a positive nonce are required.",
        variant: "destructive",
      });
      return;
    }
    const f = rollFloat(chkServer.trim(), chkClient.trim(), n);
    const skin = rollCasePF(caseDef, f);
    const hash = chkSalt.trim()
      ? computePublicHash(chkServer.trim(), chkSalt.trim())
      : null;
    const known = new Set<string>([publicHash, ...seedHistory.map((s) => s.publicHash)]);
    setCheckResult({
      float: f,
      skinId: skin.id,
      skinName: skin.name,
      rarity: skin.rarity,
      hash,
      matched: hash ? known.has(hash) : false,
      matchActive: hash ? hash === publicHash : false,
    });
  }, [chkServer, chkSalt, chkClient, chkNonce, chkCase, publicHash, seedHistory, toast]);

  const prefillRoll = useCallback(
    (roll: PFRollRecord) => {
      const rec = revealedByHash.get(roll.serverSeedHash);
      setChkServer(rec ? rec.serverSeed : "");
      setChkSalt(rec ? rec.salt : "");
      setChkClient(roll.clientSeed);
      setChkNonce(String(roll.nonce));
      setChkCase(roll.caseId);
      setCheckResult(null);
      setTab("check");
    },
    [revealedByHash]
  );

  if (!mounted) {
    return <div className="min-h-[60vh]" aria-hidden="true" />;
  }

  const caseById = (id: string) => CASES.find((c) => c.id === id);

  return (
    <main className="relative min-h-screen pb-20" aria-label="Provably Fair">
      {/* orbs */}

      <div className="relative mx-auto max-w-6xl px-4 pt-10">
        {/* ===== hero ===== */}
        <div className="text-center">
          <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl border border-emerald-400/30 bg-emerald-400/10 shadow-[0_0_36px_rgba(52,211,153,0.25)]">
            <ShieldCheck className="h-9 w-9 text-emerald-400" />
          </span>
          <h1 className="font-display text-4xl font-black tracking-wide text-white md:text-5xl">
            PROVABLY <span className="text-gradient-neon">FAIR</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-white/60 md:text-base">
            Provably Fair is the algorithm that proves every roll on ROLLBOX is genuinely random
            and untouchable. The outcome of each opening is locked by cryptography before you
            press the button — no one can tilt it, re-roll it or fake it, and you can verify
            every single result yourself.
          </p>
          <ul className="mx-auto mt-5 max-w-2xl space-y-2 text-left">
            {[
              "Check the full history of seed generation — hit probabilities can never be customized for particular players.",
              "Inspect your own roll history with per-roll verification data — results cannot be falsified.",
              "Reveal the server seed at any time and recompute every past roll with the built-in checker.",
            ].map((t) => (
              <li key={t} className="flex items-start gap-2 text-[13px] leading-relaxed text-white/65">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" aria-hidden="true" />
                {t}
              </li>
            ))}
          </ul>
          {/* USER SPEC (Task 177): the HOW TO USE link — anyone can follow it to
              learn exactly what to copy where and verify their own drops */}
          <Link
            href="/provably-fair/how-to-use"
            className="gold-btn mx-auto mt-6 flex w-fit items-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-black shadow-[0_0_18px_rgba(240,185,11,0.4)] transition-transform hover:scale-[1.03]"
          >
            <BookOpen className="h-4 w-4" />
            How to use — verify your drops, step by step
          </Link>
        </div>

        {/* ===== algorithm summary ===== */}
        <div className="mx-auto mt-8 max-w-3xl overflow-x-auto rounded-xl border border-white/10 bg-[#0b0716] p-5" dir="ltr">
          <pre className="font-mono text-[12px] leading-relaxed text-white/70 md:text-[13px]">
{`PublicHash = SHA-256(ServerSeed + SecretSalt)          // committed BEFORE any roll
Roll       = HMAC-SHA256(ServerSeed, ClientSeed + ":" + Nonce)
Outcome    = first 32 bits of Roll -> float in [0,1) -> weighted drop table`}
          </pre>
          <p className="mt-3 text-[11px] leading-relaxed text-white/40">
            You control the Client Seed. The Server Seed stays hidden but is locked by its public
            hash — after a reveal, SHA-256(seed + salt) must equal the hash you were shown, and
            every nonce must reproduce the item you received.
          </p>
        </div>

        {/* ===== tabs ===== */}
        <div className="mt-10 flex items-center gap-2 border-b border-white/10">
          <button
            onClick={() => setTab("server")}
            className={cn(
              "-mb-px flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-black tracking-wide transition-colors",
              tab === "server"
                ? "border-emerald-400 text-white"
                : "border-transparent text-white/40 hover:text-white/70"
            )}
          >
            <ShieldCheck className="h-4 w-4" />
            SERVER ROLLS
          </button>
          <button
            onClick={() => setTab("seeds")}
            className={cn(
              "-mb-px flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-black tracking-wide transition-colors",
              tab === "seeds"
                ? "border-emerald-400 text-white"
                : "border-transparent text-white/40 hover:text-white/70"
            )}
          >
            <KeyRound className="h-4 w-4" />
            SEED SETTINGS
          </button>
          <button
            onClick={() => setTab("check")}
            className={cn(
              "-mb-px flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-black tracking-wide transition-colors",
              tab === "check"
                ? "border-emerald-400 text-white"
                : "border-transparent text-white/40 hover:text-white/70"
            )}
          >
            <Dices className="h-4 w-4" />
            CHECK ROLL
          </button>
        </div>

        {/* ===== SERVER ROLLS tab (Task 151 — the real-money verifier) ===== */}
        {tab === "server" && <ServerFairPanel />}

        {/* ===== SEED SETTINGS tab ===== */}
        {tab === "seeds" && (
          <div className="mt-8">
            <h2 className="font-display text-xl font-black tracking-wide text-white">
              CURRENT SEEDS
            </h2>

            <div className="mt-4 overflow-hidden rounded-xl border border-white/10">
              {/* client seed row */}
              <div className="flex flex-col gap-3 border-b border-white/10 bg-white/[0.02] p-4 md:flex-row md:items-center">
                <span className="w-36 shrink-0 text-xs font-black tracking-widest text-emerald-300">
                  CLIENT SEED
                </span>
                <code className="min-w-0 flex-1 truncate rounded-md bg-black/40 px-3 py-2 font-mono text-[13px] text-white/80" dir="ltr">
                  {pfReady ? clientSeed : "…"}
                </code>
                <div className="flex shrink-0 gap-2">
                  <Button
                    size="sm"
                    onClick={() => setChangeOpen(true)}
                    className="h-9 rounded-lg bg-violet-600 px-4 text-xs font-black text-white hover:bg-violet-500"
                  >
                    CHANGE SEED
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setClientHistOpen(true)}
                    className="h-9 rounded-lg border-white/15 bg-white/5 px-4 text-xs font-black text-white/75 hover:bg-white/10 hover:text-white"
                  >
                    CLIENT SEED HISTORY
                  </Button>
                </div>
              </div>

              {/* server seed row */}
              <div className="flex flex-col gap-3 border-b border-white/10 p-4 md:flex-row md:items-center">
                <span className="w-36 shrink-0 text-xs font-black tracking-widest text-white/40">
                  SERVER SEED
                </span>
                <code className="min-w-0 flex-1 truncate rounded-md bg-black/40 px-3 py-2 font-mono text-[13px] tracking-widest text-white/35" dir="ltr">
                  {MASK}
                </code>
                <div className="flex shrink-0 gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setServerHistOpen(true)}
                    className="h-9 rounded-lg border-white/15 bg-white/5 px-4 text-xs font-black text-white/75 hover:bg-white/10 hover:text-white"
                  >
                    <History className="mr-1.5 h-3.5 w-3.5" />
                    SERVER SEED HISTORY
                  </Button>
                </div>
              </div>

              {/* secret salt row */}
              <div className="flex flex-col gap-3 border-b border-white/10 bg-white/[0.02] p-4 md:flex-row md:items-center">
                <span className="w-36 shrink-0 text-xs font-black tracking-widest text-white/40">
                  SECRET SALT
                </span>
                <code className="min-w-0 flex-1 truncate rounded-md bg-black/40 px-3 py-2 font-mono text-[13px] tracking-widest text-white/35" dir="ltr">
                  {"•".repeat(22)}
                </code>
              </div>

              {/* public hash row */}
              <div className="flex flex-col gap-3 border-b border-white/10 p-4 md:flex-row md:items-center">
                <span className="flex w-36 shrink-0 items-center gap-1.5 text-xs font-black tracking-widest text-sky-300">
                  <Hash className="h-3.5 w-3.5" />
                  PUBLIC HASH
                </span>
                <div className="flex min-w-0 flex-1 items-center gap-2">
                  <code className="min-w-0 flex-1 rounded-md bg-black/40 px-3 py-2 font-mono text-[12px] text-sky-200/90" dir="ltr">
                    {pfReady ? publicHash : "…"}
                  </code>
                  <CopyBtn text={publicHash} />
                </div>
              </div>

              {/* nonce row */}
              <div className="flex flex-col gap-3 bg-white/[0.02] p-4 md:flex-row md:items-center">
                <span className="w-36 shrink-0 text-xs font-black tracking-widest text-amber-300">
                  NONCE
                </span>
                <code className="min-w-0 flex-1 rounded-md bg-black/40 px-3 py-2 font-mono text-[13px] font-bold text-amber-200/90" dir="ltr">
                  {nonce}
                </code>
              </div>
            </div>

            {/* reveal bar */}
            <div className="mt-5 flex flex-col items-center justify-between gap-3 rounded-xl border border-emerald-500/25 bg-emerald-500/5 px-5 py-4 md:flex-row">
              <p className="text-center text-sm font-semibold text-white/60 md:text-left">
                To see the hidden data, rotate the seed — the old Server Seed and Salt become
                public in the history.
              </p>
              <Button
                onClick={() => setRevealOpen(true)}
                className="h-11 shrink-0 rounded-xl bg-emerald-500 px-7 text-sm font-black text-[#052012] shadow-[0_0_24px_rgba(52,211,153,0.4)] hover:bg-emerald-400"
              >
                <Unlock className="mr-2 h-4 w-4" />
                REVEAL SERVER SEED
              </Button>
            </div>

            {/* how verification works */}
            <h2 className="font-display mt-12 text-xl font-black tracking-wide text-white">
              HOW VERIFICATION WORKS
            </h2>
            <div className="mt-4 grid gap-4 md:grid-cols-3">
              {[
                {
                  icon: Lock,
                  title: "1. Commit",
                  text: "Before any roll, ROLLBOX generates a secret Server Seed + Salt and shows you their SHA-256 fingerprint — the Public Hash above. The hash proves the seed exists without revealing it.",
                },
                {
                  icon: Dices,
                  title: "2. Roll",
                  text: "Every opening combines the hidden seed with YOUR client seed and an incrementing nonce via HMAC-SHA256. The result maps onto the published drop table — deterministic and unalterable.",
                },
                {
                  icon: Unlock,
                  title: "3. Reveal & Verify",
                  text: "Rotate the seed to unlock the old Server Seed and Salt. Verify SHA-256(seed + salt) equals the Public Hash you were shown, then recompute any nonce in the Check Roll tab.",
                },
              ].map((s) => (
                <div key={s.title} className="rounded-xl border border-white/10 bg-white/[0.02] p-5">
                  <span className="mb-3 grid h-10 w-10 place-items-center rounded-lg border border-emerald-400/25 bg-emerald-400/10">
                    <s.icon className="h-5 w-5 text-emerald-300" />
                  </span>
                  <h3 className="text-sm font-black text-white">{s.title}</h3>
                  <p className="mt-2 text-[13px] leading-relaxed text-white/55">{s.text}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ===== CHECK ROLL tab ===== */}
        {tab === "check" && (
          <div className="mt-8">
            <h2 className="font-display text-xl font-black tracking-wide text-white">
              CHECK ROLL
            </h2>
            <p className="mt-2 max-w-2xl text-sm text-white/55">
              Paste any seed pair and nonce to recompute a roll exactly the way the roulette did.
              Add the secret salt to also verify the public hash commitment.
            </p>

            <div className="mt-5 grid gap-4 lg:grid-cols-2">
              <div className="rounded-xl border border-white/10 bg-white/[0.02] p-5">
                <label className="mb-1.5 block text-[11px] font-black tracking-widest text-white/45">
                  SERVER SEED
                </label>
                <Input
                  value={chkServer}
                  onChange={(e) => setChkServer(e.target.value)}
                  placeholder="revealed server seed (64 hex chars)"
                  dir="ltr"
                  className="border-white/10 bg-black/40 font-mono text-[12px] text-white/85"
                />
                <label className="mb-1.5 mt-4 block text-[11px] font-black tracking-widest text-white/45">
                  SECRET SALT — optional, for hash verification
                </label>
                <Input
                  value={chkSalt}
                  onChange={(e) => setChkSalt(e.target.value)}
                  placeholder="revealed salt"
                  dir="ltr"
                  className="border-white/10 bg-black/40 font-mono text-[12px] text-white/85"
                />
                <label className="mb-1.5 mt-4 block text-[11px] font-black tracking-widest text-white/45">
                  CLIENT SEED
                </label>
                <Input
                  value={chkClient}
                  onChange={(e) => setChkClient(e.target.value)}
                  placeholder="your client seed"
                  dir="ltr"
                  className="border-white/10 bg-black/40 font-mono text-[12px] text-white/85"
                />
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1.5 block text-[11px] font-black tracking-widest text-white/45">
                      NONCE
                    </label>
                    <Input
                      type="number"
                      min={1}
                      value={chkNonce}
                      onChange={(e) => setChkNonce(e.target.value)}
                      dir="ltr"
                      className="border-white/10 bg-black/40 font-mono text-[12px] text-white/85"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-[11px] font-black tracking-widest text-white/45">
                      CASE
                    </label>
                    <Select value={chkCase} onValueChange={setChkCase}>
                      <SelectTrigger className="border-white/10 bg-black/40 text-[12px] text-white/85">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="border-white/10 bg-[#150e26]">
                        {CASES.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button
                  onClick={onCompute}
                  className="mt-5 h-11 w-full rounded-xl bg-violet-600 text-sm font-black text-white hover:bg-violet-500"
                >
                  <Dices className="mr-2 h-4 w-4" />
                  COMPUTE ROLL
                </Button>
              </div>

              {/* result panel */}
              <div className="rounded-xl border border-white/10 bg-[#0b0716] p-5">
                {!checkResult ? (
                  <div className="flex h-full min-h-64 flex-col items-center justify-center gap-3 text-white/35">
                    <Dices className="h-9 w-9" />
                    <p className="text-sm font-semibold">Result appears here</p>
                  </div>
                ) : (
                  <div className="flex h-full flex-col gap-4">
                    {checkResult.hash && (
                      <div className="rounded-lg border border-white/10 bg-black/40 p-3" dir="ltr">
                        <p className="mb-1 text-[10px] font-black tracking-widest text-white/40">
                          SHA-256(ServerSeed + Salt)
                        </p>
                        <code className="block break-all font-mono text-[11px] text-sky-200/90">
                          {checkResult.hash}
                        </code>
                        <span
                          className={cn(
                            "mt-2 inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-[10px] font-black",
                            checkResult.matched
                              ? checkResult.matchActive
                                ? "border-emerald-400/40 bg-emerald-500/10 text-emerald-300"
                                : "border-sky-400/40 bg-sky-500/10 text-sky-300"
                              : "border-amber-400/40 bg-amber-500/10 text-amber-300"
                          )}
                        >
                          {checkResult.matched
                            ? checkResult.matchActive
                              ? "MATCHES ACTIVE COMMITMENT"
                              : "MATCHES RETIRED COMMITMENT"
                            : "NO MATCHING COMMITMENT"}
                        </span>
                      </div>
                    )}
                    <div className="rounded-lg border border-white/10 bg-black/40 p-3" dir="ltr">
                      <p className="mb-1 text-[10px] font-black tracking-widest text-white/40">
                        ROLL FLOAT — first 32 bits of HMAC-SHA256
                      </p>
                      <code className="font-mono text-sm font-bold text-violet-300">
                        {checkResult.float.toFixed(8)}
                      </code>
                    </div>
                    <div className="flex flex-1 items-center gap-4 rounded-lg border border-white/10 bg-black/40 p-3">
                      <SkinTile
                        skinId={checkResult.skinId}
                        className="w-28 shrink-0"
                        artClassName="h-14"
                      />
                      <div>
                        <p className="text-[10px] font-black tracking-widest text-white/40">
                          WINNING ITEM
                        </p>
                        <p className="mt-1 text-sm font-black text-white">
                          {checkResult.skinName}
                        </p>
                        <p
                          className="text-xs font-bold"
                          style={{ color: RARITY_META[checkResult.rarity].color }}
                        >
                          {RARITY_META[checkResult.rarity].label} • <Coin />
                          {" "}{formatCoins(SKINS[checkResult.skinId]?.value ?? 0)}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* recent rolls */}
            <h2 className="font-display mt-12 text-xl font-black tracking-wide text-white">
              YOUR RECENT ROLLS
            </h2>
            <p className="mt-2 text-sm text-white/55">
              Every opening you made with its verification data. Click a roll to load it into the
              checker — once its seed is revealed it can be recomputed byte-for-byte.
            </p>
            {rolls.length === 0 ? (
              <div className="mt-5 rounded-xl border border-dashed border-white/15 p-8 text-center text-sm text-white/40">
                No rolls yet — open any case to start your verifiable history.
              </div>
            ) : (
              <div className="mt-5 overflow-hidden rounded-xl border border-white/10">
                {rolls.slice(0, 12).map((roll, idx) => {
                  const rec = revealedByHash.get(roll.serverSeedHash);
                  const isActive = roll.serverSeedHash === publicHash;
                  const cdef = caseById(roll.caseId);
                  let verified: boolean | null = null;
                  if (rec && cdef) {
                    const f = rollFloat(rec.serverSeed, roll.clientSeed, roll.nonce);
                    verified = rollCasePF(cdef, f).id === roll.skinId;
                  }
                  const skinRarity = cdef
                    ? RARITY_META[rollCasePF(cdef, roll.float).rarity]
                    : null;
                  return (
                    <button
                      key={`${roll.at}-${idx}`}
                      onClick={() => prefillRoll(roll)}
                      className="flex w-full flex-wrap items-center gap-x-4 gap-y-1.5 border-b border-white/5 bg-white/[0.02] px-4 py-3 text-left transition-colors last:border-b-0 hover:bg-white/[0.05]"
                    >
                      <span className="w-16 shrink-0 font-mono text-xs font-bold text-amber-300" dir="ltr">
                        #{roll.nonce}
                      </span>
                      <span className="w-28 shrink-0 text-xs font-bold text-white/55" dir="ltr">
                        {cdef?.name ?? roll.caseId}
                      </span>
                      <span className="min-w-0 flex-1 truncate font-mono text-xs text-white/70" dir="ltr">
                        {shortSeed(roll.clientSeed)}
                      </span>
                      <span className="hidden min-w-0 flex-1 truncate font-mono text-[11px] text-white/35 sm:block" dir="ltr">
                        {shortSeed(roll.serverSeedHash)}
                      </span>
                      {verified === null ? (
                        <span className="flex shrink-0 items-center gap-1 rounded-md border border-white/15 bg-white/5 px-2 py-0.5 text-[10px] font-black text-white/45">
                          <Timer className="h-3 w-3" />
                          {isActive ? "SEED ACTIVE" : "UNKNOWN SEED"}
                        </span>
                      ) : verified ? (
                        <span className="flex shrink-0 items-center gap-1 rounded-md border border-emerald-400/40 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-black text-emerald-300">
                          <BadgeCheck className="h-3 w-3" />
                          VERIFIED
                        </span>
                      ) : (
                        <span className="flex shrink-0 items-center gap-1 rounded-md border border-red-400/40 bg-red-500/10 px-2 py-0.5 text-[10px] font-black text-red-300">
                          <TriangleAlert className="h-3 w-3" />
                          MISMATCH
                        </span>
                      )}
                      <span
                        className="hidden shrink-0 text-[10px] font-black tracking-wide md:block"
                        style={{ color: skinRarity?.color }}
                      >
                        {skinRarity?.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* back to cases */}
        <div className="mt-12 text-center">
          <Link
            href="/#cases"
            className="inline-flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-bold text-white/50 transition-colors hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Cases
          </Link>
        </div>
      </div>

      {/* ===== change seed dialog ===== */}
      <Dialog open={changeOpen} onOpenChange={setChangeOpen}>
        <DialogContent className="border-white/15 bg-[#140d24] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-black">Change Client Seed</DialogTitle>
            <DialogDescription className="text-sm text-white/55">
              Changing your client seed also rotates the server seed: the old pair is revealed in
              the history and a fresh commitment becomes active.
            </DialogDescription>
          </DialogHeader>
          <label className="mb-1.5 mt-1 block text-[11px] font-black tracking-widest text-white/45">
            CUSTOM SEED — leave empty for a random one
          </label>
          <Input
            value={seedInput}
            onChange={(e) => setSeedInput(e.target.value)}
            placeholder="e.g. my-lucky-seed-42"
            dir="ltr"
            maxLength={64}
            className="border-white/10 bg-black/40 font-mono text-[13px] text-white/85"
          />
          <div className="mt-3 flex gap-2">
            <Button
              onClick={() => doChangeSeed(seedInput)}
              className="flex-1 rounded-lg bg-violet-600 text-sm font-black text-white hover:bg-violet-500"
            >
              <RefreshCw className="mr-1.5 h-4 w-4" />
              Apply New Seed
            </Button>
            <Button
              variant="outline"
              onClick={() => setChangeOpen(false)}
              className="rounded-lg border-white/15 bg-white/5 text-sm font-bold text-white/70 hover:bg-white/10 hover:text-white"
            >
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== reveal confirm dialog ===== */}
      <Dialog open={revealOpen} onOpenChange={setRevealOpen}>
        <DialogContent className="border-white/15 bg-[#140d24] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-black">Reveal Server Seed</DialogTitle>
            <DialogDescription className="text-sm text-white/55">
              The active Server Seed and Secret Salt become public and are archived in the Server
              Seed History. A new committed pair is generated for future rolls. Revealed rolls can
              then be re-verified in the Check Roll tab.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-3 flex gap-2">
            <Button
              onClick={doReveal}
              className="flex-1 rounded-lg bg-emerald-500 text-sm font-black text-[#052012] hover:bg-emerald-400"
            >
              <Unlock className="mr-1.5 h-4 w-4" />
              Reveal &amp; Rotate
            </Button>
            <Button
              variant="outline"
              onClick={() => setRevealOpen(false)}
              className="rounded-lg border-white/15 bg-white/5 text-sm font-bold text-white/70 hover:bg-white/10 hover:text-white"
            >
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== server seed history dialog ===== */}
      <Dialog open={serverHistOpen} onOpenChange={setServerHistOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto border-white/15 bg-[#140d24] text-white sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-black">Server Seed History</DialogTitle>
            <DialogDescription className="text-sm text-white/55">
              Every retired seed pair, fully public forever. Verify each with its nonce range in
              the Check Roll tab.
            </DialogDescription>
          </DialogHeader>
          {seedHistory.length === 0 ? (
            <div className="rounded-xl border border-dashed border-white/15 p-6 text-center text-sm text-white/40">
              Nothing revealed yet — rotate the active seed to archive it here.
            </div>
          ) : (
            <div className="space-y-3">
              {seedHistory.map((rec) => (
                <div key={rec.publicHash} className="rounded-xl border border-white/10 bg-black/30 p-4" dir="ltr">
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <span className="rounded-md border border-white/15 bg-white/5 px-2 py-0.5 text-[10px] font-black tracking-wide text-white/55">
                      NONCES {rec.usedFrom}–{rec.usedTo}
                    </span>
                    <span className="font-mono text-[10px] text-white/35">
                      {new Date(rec.revealedAt).toLocaleString("en-US")}
                    </span>
                  </div>
                  {[
                    { label: "SERVER SEED", value: rec.serverSeed, color: "text-white/75" },
                    { label: "SECRET SALT", value: rec.salt, color: "text-white/75" },
                    { label: "CLIENT SEED", value: rec.clientSeed, color: "text-emerald-300/90" },
                    { label: "PUBLIC HASH", value: rec.publicHash, color: "text-sky-200/90" },
                  ].map((f) => (
                    <div key={f.label} className="mb-1.5 last:mb-0">
                      <p className="mb-0.5 text-[9px] font-black tracking-widest text-white/35">{f.label}</p>
                      <div className="flex items-center gap-2">
                        <code className={cn("min-w-0 flex-1 break-all rounded bg-black/50 px-2 py-1 font-mono text-[11px]", f.color)}>
                          {f.value}
                        </code>
                        <CopyBtn text={f.value} />
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ===== client seed history dialog ===== */}
      <Dialog open={clientHistOpen} onOpenChange={setClientHistOpen}>
        <DialogContent className="border-white/15 bg-[#140d24] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-black">Client Seed History</DialogTitle>
            <DialogDescription className="text-sm text-white/55">
              Your previous client seeds, newest first.
            </DialogDescription>
          </DialogHeader>
          {clientHistory.length === 0 ? (
            <div className="rounded-xl border border-dashed border-white/15 p-6 text-center text-sm text-white/40">
              No previous seeds yet.
            </div>
          ) : (
            <div className="space-y-1.5">
              {clientHistory.map((seed) => (
                <div key={seed} className="flex items-center gap-2" dir="ltr">
                  <code className="min-w-0 flex-1 truncate rounded bg-black/50 px-2 py-1.5 font-mono text-[12px] text-white/70">
                    {seed}
                  </code>
                  <CopyBtn text={seed} />
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </main>
  );
}
