"use client";

// ============ SERVER PROVABLY FAIR panel (Task 151) ============
// The REAL-money tab of /provably-fair: shows the player's active SERVER
// commitment (hash + clientSeed + next nonce), lets them rotate (reveal) the
// seed, and re-derives every recorded server bet from the revealed seed —
// the exact same math the server rolled with (src/lib/provably-fair.ts):
//
//   float = HMAC-SHA256(serverSeed, `${clientSeed}:${nonce}`)  ->  [0,1)
//     case open, reel i: nonce start+2i = ROLLDROP gate (float < chance),
//                        nonce start+2i+1 = weighted draw (rare pool on hit)
//     upgrader: ONE slot — win iff float < chance
//
// Battles verify against the ROOM's own seed (publicView fairSeed after the
// settle) with clientSeed = the room code — noted here, verified the same way.

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  BadgeCheck,
  TriangleAlert,
  RefreshCw,
  Hourglass,
  KeyRound,
  Dices,
  Copy,
  Check,
  Sparkles,
  LogIn,
} from "lucide-react";
import Link from "next/link";
import { CASES, formatCoins, SKINS } from "@/lib/cases";
import { wearColorOf, wearShortOf } from "@/lib/wear";
import { ROLLDROP_CHANCE, rareCaseOf, rolldropChanceOf } from "@/lib/rolldrop";
import { computePublicHash, pickWeighted, rollFloat, shortSeed } from "@/lib/provably-fair";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface FairActive {
  serverSeedHash: string;
  clientSeed: string;
  nextNonce: number;
}
interface FairRevealed {
  serverSeed: string;
  salt: string;
  serverSeedHash: string;
  clientSeed: string;
  nonceUsed: number;
  revealedAt?: number | null;
}
interface FairRollRow {
  id: number;
  game: string;
  ref: string | null;
  seedHash: string;
  clientSeed: string;
  nonce: number;
  detail: {
    caseName?: string;
    count?: number;
    reels?: { n: number; ni: number; rd: boolean; skinId: string; wear?: string; value: number }[];
    rdChance?: number;
    win?: boolean;
    chance?: number;
    stake?: number;
    target?: number;
    prizeId?: string | null;
  };
  createdAt: number;
}
interface FairData {
  active: FairActive;
  revealed: FairRevealed[];
  rolls: FairRollRow[];
}

type RollStatus = "pending" | "verified" | "mismatch";

function CopyBtn({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      aria-label="Copy"
      className={cn(
        "grid h-7 w-7 shrink-0 place-items-center rounded-md border border-white/10 text-white/50 transition-colors hover:text-white",
        copied && "border-emerald-400/40 text-emerald-300"
      )}
      onClick={() => {
        try {
          void navigator.clipboard.writeText(text);
        } catch {
          /* clipboard blocked — ignore */
        }
        setCopied(true);
        setTimeout(() => setCopied(false), 1200);
      }}
    >
      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
    </button>
  );
}

export function ServerFairPanel() {
  const { toast } = useToast();
  const [data, setData] = useState<FairData | null>(null);
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [newSeed, setNewSeed] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/fair", { cache: "no-store" });
      if (res.status === 401) {
        setAuthed(false);
        return;
      }
      setAuthed(true);
      if (res.ok) setData((await res.json()) as FairData);
    } catch {
      setAuthed(null);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const doRotate = useCallback(async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/fair/rotate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ clientSeed: newSeed.trim() || undefined }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({
          title: "Could not rotate",
          description: typeof json.error === "string" ? json.error : "Try again in a moment.",
          variant: "destructive",
        });
        return;
      }
      const revealed = (json as { revealed: FairRevealed }).revealed;
      await load();
      setNewSeed("");
      toast({
        title: "Server seed revealed",
        description: `Seed ${shortSeed(revealed.serverSeed)} is now public — every roll made on it is verifiable below.`,
      });
    } finally {
      setBusy(false);
    }
  }, [newSeed, load, toast]);

  // revealed seeds by their commitment hash — a roll verifies only once its
  // own seed has been revealed (that is the whole point of commit-reveal)
  const seedsByHash = useMemo(() => {
    const map = new Map<string, FairRevealed>();
    for (const r of data?.revealed ?? []) map.set(r.serverSeedHash, r);
    return map;
  }, [data]);

  const statusOf = useCallback(
    (roll: FairRollRow): { st: RollStatus; note: string } => {
      const seed = seedsByHash.get(roll.seedHash);
      if (!seed) return { st: "pending", note: "Seed not revealed yet" };
      // the commitment itself must reproduce — the seed was never swapped
      if (computePublicHash(seed.serverSeed, seed.salt) !== roll.seedHash) {
        return { st: "mismatch", note: "Seed does not match its hash" };
      }
      const f = (n: number) => rollFloat(seed.serverSeed, roll.clientSeed, n);
      if (roll.game === "upgrader") {
        const win = f(roll.nonce) < (roll.detail.chance ?? 0);
        return win === roll.detail.win
          ? { st: "verified", note: `float confirms ${win ? "WIN" : "LOSS"} (chance ${(100 * (roll.detail.chance ?? 0)).toFixed(1)}%)` }
          : { st: "mismatch", note: "Outcome does not reproduce" };
      }
      // game "open" — per-reel verification
      const caseDef = CASES.find((c) => c.id === roll.ref);
      const reels = roll.detail.reels ?? [];
      // the gate chance is recorded AT ROLL TIME (detail.rdChance) so later
      // chance tweaks can never break an old verification
      const gateChance = roll.detail.rdChance ?? (caseDef ? rolldropChanceOf(caseDef) : ROLLDROP_CHANCE);
      for (let i = 0; i < reels.length; i++) {
        const reel = reels[i];
        const rdHit = f(reel.n) < gateChance;
        if (!!reel.rd !== rdHit) return { st: "mismatch", note: "ROLLDROP gate does not reproduce" };
        if (caseDef) {
          const table = reel.rd ? rareCaseOf(caseDef).items : caseDef.items;
          const expected = pickWeighted(table, f(reel.ni));
          if (expected.skinId !== reel.skinId) {
            return { st: "mismatch", note: "Item does not reproduce" };
          }
        }
      }
      return {
        st: "verified",
        note: caseDef
          ? `${reels.length} reel${reels.length === 1 ? "" : "s"} reproduce exactly`
          : `${reels.length} reel${reels.length === 1 ? "" : "s"} reproduce (floats verified — table lives server-side)`,
      };
    },
    [seedsByHash]
  );

  if (authed === false) {
    return (
      <div className="mt-8 rounded-xl border border-white/10 bg-white/[0.02] p-10 text-center">
        <LogIn className="mx-auto h-8 w-8 text-emerald-300" />
        <h3 className="mt-3 font-display text-lg font-black tracking-wide text-white">
          SERVER VERIFICATION NEEDS YOUR ACCOUNT
        </h3>
        <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-white/55">
          Real-money rolls run on the server against your personal commit-reveal chain. Sign in to
          see your commitment, rotate your seed and verify every server roll you ever made. Guests
          play the client simulation — the other two tabs cover it.
        </p>
        <Button asChild className="mt-5 h-10 rounded-lg bg-emerald-500 px-6 text-xs font-black text-black hover:bg-emerald-400">
          <Link href="/login">SIGN IN &amp; PLAY</Link>
        </Button>
      </div>
    );
  }

  const active = data?.active;
  const rolls = data?.rolls ?? [];

  return (
    <div className="mt-8 space-y-8">
      {/* ===== active commitment ===== */}
      <div>
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-display text-xl font-black tracking-wide text-white">
            ACTIVE SERVER COMMITMENT
          </h2>
          <Button
            size="sm"
            variant="outline"
            onClick={() => void load()}
            className="h-8 gap-1.5 rounded-lg border-white/15 px-3 text-[11px] font-black text-white/70 hover:text-white"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            REFRESH
          </Button>
        </div>
        <div className="mt-4 overflow-hidden rounded-xl border border-white/10">
          <div className="flex flex-col gap-3 border-b border-white/10 bg-white/[0.02] p-4 md:flex-row md:items-center">
            <span className="w-40 shrink-0 text-xs font-black tracking-widest text-emerald-300">
              SERVER SEED HASH
            </span>
            <code className="min-w-0 flex-1 truncate rounded-md bg-black/40 px-3 py-2 font-mono text-[13px] text-white/80" dir="ltr">
              {active ? active.serverSeedHash : "…"}
            </code>
            {active ? <CopyBtn text={active.serverSeedHash} /> : null}
          </div>
          <div className="flex flex-col gap-3 border-b border-white/10 p-4 md:flex-row md:items-center">
            <span className="w-40 shrink-0 text-xs font-black tracking-widest text-emerald-300">
              YOUR CLIENT SEED
            </span>
            <code className="min-w-0 flex-1 truncate rounded-md bg-black/40 px-3 py-2 font-mono text-[13px] text-white/80" dir="ltr">
              {active ? active.clientSeed : "…"}
            </code>
            {active ? <CopyBtn text={active.clientSeed} /> : null}
          </div>
          <div className="flex flex-col gap-3 p-4 md:flex-row md:items-center">
            <span className="w-40 shrink-0 text-xs font-black tracking-widest text-emerald-300">
              NEXT NONCE
            </span>
            <code className="min-w-0 flex-1 rounded-md bg-black/40 px-3 py-2 font-mono text-[13px] text-white/80" dir="ltr">
              {active ? active.nextNonce : "…"}
            </code>
          </div>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-white/40">
          This hash was published BEFORE the rolls it will ever decide. The raw server seed stays on
          the server — rotate to reveal it and every roll made on it becomes verifiable below.
        </p>
      </div>

      {/* ===== rotate ===== */}
      <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/[0.04] p-5">
        <h3 className="flex items-center gap-2 font-display text-base font-black tracking-wide text-white">
          <KeyRound className="h-4 w-4 text-emerald-300" />
          ROTATE &amp; REVEAL
        </h3>
        <p className="mt-2 text-[13px] leading-relaxed text-white/55">
          Revealing the current seed proves it was never swapped: SHA-256(seed + salt) must equal the
          hash above, and the built-in checker then reproduces every roll. A fresh commitment becomes
          active immediately. Optionally set your own client seed for the next chain.
        </p>
        <div className="mt-4 flex flex-col gap-2 md:flex-row">
          <Input
            value={newSeed}
            onChange={(e) => setNewSeed(e.target.value)}
            placeholder="New client seed (optional — blank keeps it random)"
            className="h-10 flex-1 border-white/10 bg-black/40 font-mono text-[13px] text-white placeholder:text-white/25"
            dir="ltr"
            maxLength={64}
          />
          <Button
            onClick={() => void doRotate()}
            disabled={busy}
            className="h-10 rounded-lg bg-emerald-500 px-6 text-xs font-black text-black hover:bg-emerald-400 disabled:opacity-50"
          >
            {busy ? "ROTATING…" : "REVEAL & ROTATE"}
          </Button>
        </div>
      </div>

      {/* ===== revealed seeds ===== */}
      {!!data?.revealed.length && (
        <div>
          <h2 className="font-display text-lg font-black tracking-wide text-white">
            REVEALED SEEDS
          </h2>
          <div className="mt-3 space-y-2">
            {data.revealed.map((r) => {
              const ok = computePublicHash(r.serverSeed, r.salt) === r.serverSeedHash;
              return (
                <div
                  key={r.serverSeedHash + r.revealedAt}
                  className="flex flex-col gap-2 rounded-lg border border-white/10 bg-white/[0.02] p-3 md:flex-row md:items-center"
                >
                  <span
                    className={cn(
                      "grid h-7 w-7 shrink-0 place-items-center rounded-md",
                      ok ? "bg-emerald-400/10 text-emerald-300" : "bg-red-400/10 text-red-300"
                    )}
                    title={ok ? "hash matches the commitment" : "HASH MISMATCH"}
                  >
                    {ok ? <BadgeCheck className="h-4 w-4" /> : <TriangleAlert className="h-4 w-4" />}
                  </span>
                  <code className="min-w-0 flex-1 truncate font-mono text-[12px] text-white/70" dir="ltr">
                    seed {r.serverSeed} · salt {shortSeed(r.salt)} · {r.nonceUsed} rolls
                  </code>
                  <CopyBtn text={`${r.serverSeed}\n${r.salt}`} />
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ===== bet history + verification ===== */}
      <div>
        <h2 className="flex items-center gap-2 font-display text-lg font-black tracking-wide text-white">
          <Dices className="h-4 w-4 text-emerald-300" />
          YOUR SERVER ROLLS
          <span className="text-xs font-bold text-white/35">({rolls.length})</span>
        </h2>
        {!rolls.length ? (
          <p className="mt-3 rounded-lg border border-white/10 bg-white/[0.02] p-4 text-sm text-white/45">
            No server rolls yet — open a case or spin the upgrader and every bet lands here with its
            verification data.
          </p>
        ) : (
          <div className="mt-3 space-y-2">
            {rolls.map((roll) => {
              const { st, note } = statusOf(roll);
              return (
                <div key={roll.id} className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <span
                      className={cn(
                        "rounded-md px-2 py-0.5 text-[10px] font-black tracking-widest",
                        roll.game === "open"
                          ? "bg-violet-400/10 text-violet-300"
                          : "bg-amber-400/10 text-amber-300"
                      )}
                    >
                      {roll.game === "open" ? "CASE OPEN" : "UPGRADER"}
                    </span>
                    <span className="text-[13px] font-bold text-white/85">
                      {roll.game === "open" ? roll.detail.caseName ?? roll.ref : `Target ${roll.ref}`}
                    </span>
                    <span className="font-mono text-[11px] text-white/40" dir="ltr">
                      nonce {roll.nonce}
                      {roll.game === "open" && (roll.detail.count ?? 1) > 1
                        ? `..${roll.nonce + 2 * (roll.detail.count ?? 1) - 1}`
                        : ""}
                    </span>
                    {roll.game === "upgrader" ? (
                      <span className="text-[11px] text-white/40">
                        stake ${formatCoins(roll.detail.stake ?? 0)} → ${formatCoins(roll.detail.target ?? 0)}
                      </span>
                    ) : null}
                    <span
                      className={cn(
                        "ml-auto flex items-center gap-1.5 rounded-md px-2 py-0.5 text-[11px] font-black",
                        st === "verified" && "bg-emerald-400/10 text-emerald-300",
                        st === "pending" && "bg-white/5 text-white/45",
                        st === "mismatch" && "bg-red-400/10 text-red-300"
                      )}
                    >
                      {st === "verified" ? (
                        <>
                          <BadgeCheck className="h-3.5 w-3.5" /> VERIFIED
                        </>
                      ) : st === "pending" ? (
                        <>
                          <Hourglass className="h-3.5 w-3.5" /> PENDING REVEAL
                        </>
                      ) : (
                        <>
                          <TriangleAlert className="h-3.5 w-3.5" /> MISMATCH
                        </>
                      )}
                    </span>
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1">
                    {roll.game === "open" ? (
                      (roll.detail.reels ?? []).map((reel, i) => (
                        <span key={i} className="flex items-center gap-1.5 text-[11px] text-white/50">
                          <Sparkles className="h-3 w-3 text-white/30" />
                          {SKINS[reel.skinId]?.name ?? reel.skinId}
                          {/* R43 USER SPEC: the reel's exterior — in its color */}
                          <span className="font-black uppercase" style={{ color: wearColorOf(reel.wear) }} title={`Exterior: ${reel.wear ?? "Field-Tested"}`}>
                            {wearShortOf(reel.wear)}
                          </span>
                          <span className="text-emerald-300/70">${formatCoins(reel.value)}</span>
                          {reel.rd ? <span className="text-amber-300/80">· ROLLDROP</span> : null}
                        </span>
                      ))
                    ) : (
                      <span className="text-[11px] text-white/50">
                        {roll.detail.win ? "WIN" : "LOSS"} · chance {(100 * (roll.detail.chance ?? 0)).toFixed(1)}%
                      </span>
                    )}
                  </div>
                  <p className={cn("mt-1 text-[11px]", st === "mismatch" ? "text-red-300" : "text-white/35")}>
                    {note}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ===== battles note ===== */}
      <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
        <h3 className="text-[13px] font-black tracking-wide text-white/80">BATTLES</h3>
        <p className="mt-1.5 text-[12px] leading-relaxed text-white/45">
          Every battle rolls against its own committed seed — the hash is public from the moment the
          room starts (room API: <code className="font-mono text-white/60">fairHash</code>), and the
          raw seed + salt go public the moment it settles. clientSeed is the room code; pull g (round
          r, seat s → g = r·seats + s) uses nonce 2g for the ROLLDROP gate and 2g+1 for the draw —
          exactly like the solo opener above.
        </p>
      </div>
    </div>
  );
}
