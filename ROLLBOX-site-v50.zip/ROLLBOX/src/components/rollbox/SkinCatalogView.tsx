"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Search, ChevronLeft, Sparkles, Star } from "lucide-react";
import { RARITY_META, formatCoins, type Rarity, type WeaponKind } from "@/lib/cases";
import { GUEST_FAVS_KEY, useAuthStore } from "@/lib/auth";
import { SiteShell } from "./SiteShell";
import { WeaponArt } from "./WeaponArt";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { sfx } from "@/lib/sound";

interface CatalogEntry {
  id: string;
  n: string; // display name
  w: string; // weapon/label display name ("Sticker" / "Charm" / "Agent" / "Patch")
  r: Rarity;
  p: number; // real USD price
  v: number; // site coin value
  img: string | null;
  est?: 1; // price estimated (no market data)
  t?: "sticker" | "charm" | "agent" | "patch"; // item type (undefined = weapon skin)
  cat?: string; // category key (knives/gloves/rifles/pistols/smgs/heavy/agents/stickers/charms/patches)
  a?: string; // SVG fallback art kind
}

const PAGE_SIZE = 60;

type CatKey =
  | "all"
  | "knives"
  | "gloves"
  | "rifles"
  | "pistols"
  | "smgs"
  | "heavy"
  | "zeus"
  | "agents"
  | "stickers"
  | "charms"
  | "patches";

/** Catalog categories exactly per user spec. */
const CATEGORY_OPTIONS: { value: CatKey; label: string }[] = [
  { value: "all", label: "All Items" },
  { value: "knives", label: "Knives" },
  { value: "gloves", label: "Gloves" },
  { value: "rifles", label: "Rifles" },
  { value: "pistols", label: "Pistols" },
  { value: "smgs", label: "SMGs" },
  { value: "heavy", label: "Heavy" },
  { value: "zeus", label: "Zeus" },
  { value: "agents", label: "Agents" },
  { value: "stickers", label: "Stickers" },
  { value: "charms", label: "Charms" },
  { value: "patches", label: "Patches" },
];

/** User-specified weapon classes: per-category weapon sub-filters. */
const WEAPON_CLASS: Partial<
  Record<CatKey, { label: string; items: { value: string; label: string }[] }>
> = {
  rifles: {
    label: "Rifles",
    items: ["AK-47", "AUG", "AWP", "FAMAS", "G3SG1", "Galil AR", "M4A1-S", "M4A4", "SCAR-20", "SG 553", "SSG 08"].map(
      (w) => ({ value: w, label: w })
    ),
  },
  pistols: {
    label: "Pistols",
    items: ["CZ75-Auto", "Desert Eagle", "Dual Berettas", "Five-Seven", "Glock-18", "P2000", "P250", "R8 Revolver", "Tec-9", "USP-S"].map(
      (w) => ({ value: w === "Five-Seven" ? "Five-SeveN" : w, label: w })
    ),
  },
  smgs: {
    label: "SMGs",
    items: ["MAC-10", "MP5-SD", "MP7", "MP9", "P90", "PP-Bizon", "UMP-45"].map((w) => ({ value: w, label: w })),
  },
  heavy: {
    label: "Heavy",
    items: ["M249", "MAG-7", "Negev", "Nova", "Sawed-Off", "XM1014"].map((w) => ({ value: w, label: w })),
  },
};

const WEAPON_CATS = new Set<string>(["rifles", "pistols", "smgs", "heavy"]);

const RARITY_OPTIONS: { value: string; label: string }[] = [
  { value: "all", label: "All Rarities" },
  ...(Object.entries(RARITY_META) as [Rarity, { label: string; color: string }][]).map(
    ([value, m]) => ({ value, label: m.label })
  ),
];

const RARITY_ORDER: Record<string, number> = {
  contraband: 0,
  covert: 1,
  classified: 2,
  restricted: 3,
  milspec: 4,
  consumer: 5,
};

/** Catalog tile image: uses the entry's own CDN URL, SVG art as fallback. */
function CatalogArt({ entry }: { entry: CatalogEntry }) {
  const [failed, setFailed] = useState(false);
  const kind = (entry.a ?? "ak") as WeaponKind;
  if (!entry.img || failed) {
    const tint = RARITY_META[entry.r]?.color ?? "#8882a8";
    return (
      <WeaponArt
        kind={kind}
        colors={[tint, "#1a1426"]}
        className="max-h-16 w-full object-contain opacity-70"
      />
    );
  }
  return (
    <img
      src={entry.img}
      alt={entry.n}
      loading="lazy"
      draggable={false}
      onError={() => setFailed(true)}
      className="max-h-16 w-full select-none object-contain drop-shadow-lg"
    />
  );
}

export function SkinCatalogView() {
  const [all, setAll] = useState<CatalogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<CatKey>("all");
  const [weapon, setWeapon] = useState("all");
  const [rarity, setRarity] = useState("all");
  const [sort, setSort] = useState("price-desc");
  const [visible, setVisible] = useState(PAGE_SIZE);
  const [favsOnly, setFavsOnly] = useState(false);

  // favorites (persisted per profile / guest bucket)
  const favsMap = useAuthStore((s) => s.favs);
  const currentUser = useAuthStore((s) => s.current);
  const toggleFav = useAuthStore((s) => s.toggleFav);
  const favKey = currentUser?.toLowerCase() ?? GUEST_FAVS_KEY;
  const myFavs = useMemo(() => new Set(favsMap[favKey] ?? []), [favsMap, favKey]);

  const onToggleFav = useCallback(
    (id: string) => {
      toggleFav(id);
      sfx.click();
    },
    [toggleFav]
  );

  // any filter change resets pagination
  const applyFilter = useCallback(
    (setter: (v: string) => void) => (v: string) => {
      setter(v);
      setVisible(PAGE_SIZE);
    },
    []
  );
  const onQuery = useCallback((v: string) => {
    setQuery(v);
    setVisible(PAGE_SIZE);
  }, []);
  const onCategory = useCallback((v: string) => {
    setCat(v as CatKey);
    setWeapon("all"); // switching category resets the weapon sub-filter
    setVisible(PAGE_SIZE);
  }, []);

  useEffect(() => {
    fetch("/skins-catalog.json")
      .then((r) => r.json())
      .then((data: CatalogEntry[]) => setAll(data))
      .finally(() => setLoading(false));
  }, []);

  const counts = useMemo(() => {
    const c: Record<string, number> = {
      all: all.length,
      knives: 0,
      gloves: 0,
      rifles: 0,
      pistols: 0,
      smgs: 0,
      heavy: 0,
      zeus: 0,
      agents: 0,
      stickers: 0,
      charms: 0,
      patches: 0,
    };
    for (const s of all) if (s.cat && c[s.cat] !== undefined) c[s.cat]++;
    return c;
  }, [all]);

  const weaponOptions = WEAPON_CLASS[cat]?.items ?? [];
  const weaponClassLabel = WEAPON_CLASS[cat]?.label ?? "";

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = all;
    if (favsOnly) list = list.filter((s) => myFavs.has(s.id));
    if (cat !== "all") list = list.filter((s) => s.cat === cat);
    if (q) list = list.filter((s) => s.n.toLowerCase().includes(q));
    if (weapon !== "all" && WEAPON_CATS.has(cat)) list = list.filter((s) => s.w === weapon);
    if (rarity !== "all") list = list.filter((s) => s.r === rarity);
    list = [...list];
    switch (sort) {
      case "price-asc":
        list.sort((a, b) => a.p - b.p);
        break;
      case "name":
        list.sort((a, b) => a.n.localeCompare(b.n));
        break;
      case "rarity":
        list.sort((a, b) => (RARITY_ORDER[a.r] ?? 9) - (RARITY_ORDER[b.r] ?? 9) || b.p - a.p);
        break;
      default:
        list.sort((a, b) => b.p - a.p);
    }
    return list;
  }, [all, query, cat, weapon, rarity, sort, favsOnly, myFavs]);

  const onLoadMore = useCallback(() => {
    setVisible((v) => v + PAGE_SIZE);
  }, []);

  return (
    <SiteShell>
      <main className="relative min-h-screen pb-20" aria-label="Skin Catalog">
        <div className="anim-orb pointer-events-none absolute -top-24 left-[12%] h-64 w-64 rounded-full bg-sky-500/10 blur-3xl" aria-hidden="true" />
        <div className="anim-orb pointer-events-none absolute right-[8%] top-40 h-56 w-56 rounded-full bg-violet-500/10 blur-3xl" style={{ animationDelay: "-6s" }} aria-hidden="true" />

        <div className="relative mx-auto max-w-7xl px-4 pt-10">
          {/* hero */}
          <div className="text-center">
            <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl border border-sky-400/30 bg-sky-400/10 shadow-[0_0_36px_rgba(56,189,248,0.25)]">
              <Sparkles className="h-9 w-9 text-sky-400" />
            </span>
            <h1 className="font-display text-4xl font-black tracking-wide text-white md:text-5xl">
              SKIN <span className="text-gradient-neon">CATALOG</span>
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-white/60 md:text-base">
              Every CS2 item in the game — {counts.rifles + counts.pistols + counts.smgs + counts.heavy + counts.zeus} weapon skins
              across Rifles, Pistols, SMGs, Heavy &amp; Zeus, {counts.knives.toLocaleString()} knives,{" "}
              {counts.gloves.toLocaleString()} gloves, {counts.agents.toLocaleString()} agents,{" "}
              {counts.stickers.toLocaleString()} stickers, {counts.charms.toLocaleString()} charms and{" "}
              {counts.patches.toLocaleString()} patches, all with market prices, rarity tiers and official renders.
              Search, filter and find your next grail.
            </p>
          </div>

          {/* controls */}
          <div className="mx-auto mt-8 flex max-w-5xl flex-col gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 md:flex-row md:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/35" />
              <Input
                value={query}
                onChange={(e) => onQuery(e.target.value)}
                placeholder={`Search ${all.length.toLocaleString()} items — try “Asiimov”, “Katowice”, “Fade”…`}
                className="border-white/10 bg-black/40 pl-9 text-sm text-white/85 placeholder:text-white/30"
                aria-label="Search items"
              />
            </div>
            <div className="grid grid-cols-2 gap-3 md:flex">
              <button
                onClick={() => {
                  setFavsOnly((v) => !v);
                  setVisible(PAGE_SIZE);
                  sfx.click();
                }}
                aria-pressed={favsOnly}
                className={cn(
                  "flex items-center justify-center gap-1.5 rounded-md border px-3 text-xs font-bold transition-all",
                  favsOnly
                    ? "border-amber-300/60 bg-amber-400/20 text-amber-200 shadow-[0_0_14px_rgba(240,185,11,0.35)]"
                    : "border-white/10 bg-black/40 text-white/70 hover:bg-white/5 hover:text-white"
                )}
              >
                <Star className="h-3.5 w-3.5" fill={favsOnly ? "currentColor" : "none"} />
                Favorites ({myFavs.size})
              </button>
              <Select value={cat} onValueChange={onCategory}>
                <SelectTrigger className="border-white/10 bg-black/40 text-xs text-white/85 md:w-40" aria-label="Filter by category">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent className="max-h-80 border-white/10 bg-[#150e26]">
                  {CATEGORY_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                      {o.value !== "all" && (
                        <span className="ml-1 text-white/40">{counts[o.value]}</span>
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {WEAPON_CATS.has(cat) && (
                <Select value={weapon} onValueChange={applyFilter(setWeapon)}>
                  <SelectTrigger className="border-white/10 bg-black/40 text-xs text-white/85 md:w-40" aria-label="Filter by weapon">
                    <SelectValue placeholder="Weapon" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72 border-white/10 bg-[#150e26]">
                    <SelectItem value="all">All {weaponClassLabel}</SelectItem>
                    {weaponOptions.map((w) => (
                      <SelectItem key={w.value} value={w.value}>
                        {w.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Select value={rarity} onValueChange={applyFilter(setRarity)}>
                <SelectTrigger className="border-white/10 bg-black/40 text-xs text-white/85 md:w-36" aria-label="Filter by rarity">
                  <SelectValue placeholder="Rarity" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#150e26]">
                  {RARITY_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={sort} onValueChange={applyFilter(setSort)}>
                <SelectTrigger className="border-white/10 bg-black/40 text-xs text-white/85 md:w-40" aria-label="Sort skins">
                  <SelectValue placeholder="Sort" />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#150e26]">
                  <SelectItem value="price-desc">Price: high → low</SelectItem>
                  <SelectItem value="price-asc">Price: low → high</SelectItem>
                  <SelectItem value="rarity">Rarity</SelectItem>
                  <SelectItem value="name">Name A–Z</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* result count */}
          <p className="mt-4 text-center text-xs font-bold tracking-wide text-white/40">
            {loading
              ? "Loading the armory…"
              : `${filtered.length.toLocaleString()} items${query || cat !== "all" || weapon !== "all" || rarity !== "all" ? " found" : " in the game"}`}
          </p>

          {/* grid */}
          {favsOnly && !loading && filtered.length === 0 ? (
            <div className="mt-5 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-14 text-center">
              <Star className="mx-auto mb-3 h-10 w-10 text-white/25" />
              <p className="text-sm font-bold text-white/60">No favorites yet</p>
              <p className="mt-1 text-xs text-white/40">
                Tap the ★ on any item below to pin it here — favorites are saved to your profile.
              </p>
            </div>
          ) : (
            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
              {filtered.slice(0, visible).map((s) => {
                const rm = RARITY_META[s.r];
                const isFav = myFavs.has(s.id);
                return (
                  <div
                    key={s.id}
                    className="group relative flex flex-col overflow-hidden rounded-xl border bg-[#130d22] transition-transform duration-200 hover:-translate-y-1"
                    style={{ borderColor: isFav ? "rgba(240,185,11,0.55)" : rm.color + "40" }}
                  >
                    <div
                      className="pointer-events-none absolute inset-x-0 top-0 h-2/3"
                      style={{ background: `radial-gradient(ellipse 70% 55% at 50% 20%, ${rm.color}2e, transparent 70%)` }}
                    />
                    <button
                      onClick={() => onToggleFav(s.id)}
                      aria-pressed={isFav}
                      aria-label={isFav ? `Remove ${s.n} from favorites` : `Add ${s.n} to favorites`}
                      title={isFav ? "Remove from favorites" : "Add to favorites"}
                      className={cn(
                        "absolute right-1.5 top-1.5 z-10 grid h-7 w-7 place-items-center rounded-md border backdrop-blur-sm transition-all",
                        isFav
                          ? "border-amber-300/70 bg-amber-400/25 text-amber-300 shadow-[0_0_12px_rgba(240,185,11,0.55)]"
                          : "border-white/15 bg-black/50 text-white/50 hover:border-amber-300/50 hover:text-amber-200"
                      )}
                    >
                      <Star className="h-3.5 w-3.5" fill={isFav ? "currentColor" : "none"} />
                    </button>
                    <div className="relative flex h-20 items-center justify-center px-2 pt-2">
                      <CatalogArt entry={s} />
                    </div>
                    <div className="relative mt-auto border-t border-white/5 px-2 pb-2 pt-1.5">
                      <p className="truncate text-[10px] font-bold text-white/45" dir="ltr">
                        {s.w}
                      </p>
                      <p className="truncate text-[11px] font-bold text-white/90" dir="ltr" title={s.n}>
                        {s.n.includes("|") ? s.n.split("|")[1].trim() : s.n}
                      </p>
                      <div className="mt-1 flex items-center justify-between">
                        <span className="font-display text-[11px] font-black" style={{ color: rm.color }}>
                          {rm.label}
                        </span>
                        <span className="font-display text-[11px] font-black text-amber-300" dir="ltr">
                          {s.est ? "~" : ""}${s.p >= 1000 ? Math.round(s.p / 100) / 10 + "K" : s.p.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* load more */}
          {!loading && visible < filtered.length && (
            <div className="mt-8 text-center">
              <button
                onClick={onLoadMore}
                className="rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-500 px-10 py-3.5 text-sm font-black text-white shadow-[0_0_28px_rgba(192,38,211,0.35)] transition-all hover:brightness-110"
              >
                Load {Math.min(PAGE_SIZE, filtered.length - visible)} more
                <span className="ml-2 text-white/60">
                  ({visible.toLocaleString()}/{filtered.length.toLocaleString()})
                </span>
              </button>
            </div>
          )}

          {/* back */}
          <div className="mt-12 text-center">
            <Link
              href="/#cases"
              className="inline-flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-bold text-white/50 transition-colors hover:text-white"
            >
              <ChevronLeft className="h-4 w-4" />
              Back to Cases
            </Link>
          </div>
        </div>
      </main>
    </SiteShell>
  );
}
