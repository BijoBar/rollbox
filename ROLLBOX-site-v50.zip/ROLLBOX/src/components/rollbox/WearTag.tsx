"use client";

// ============ WEAPON CONDITION tag (R43 USER SPEC) ============
// Every skin on the site lists its exterior in the exterior's own color
// (Factory New green -> Battle Scarred red). One component renders it the
// same way everywhere: `wear` accepts a WearId ("FT") or a full label
// ("Field-Tested"), `name` is the market name parsed as fallback, and skins
// with NEITHER display the default exterior (Field-Tested) — a skin never
// shows without a condition anymore. `none` (non-skin kinds: stickers,
// charms, agents, patches) renders nothing.

import { displayWearLabel, isWearableKind, wearColorOf, wearShortOf } from "@/lib/wear";
import { cn } from "@/lib/utils";

export function WearTag({
  wear,
  name,
  kind,
  short = false,
  chip = false,
  className,
  title,
}: {
  wear?: string | null;
  /** market display name — its "(Field-Tested)" tail is the fallback */
  name?: string | null;
  /** the weapon/label ("Sticker" / "AK-47") — non-wearable kinds hide the tag */
  kind?: string | null;
  /** short badge code ("FT") instead of the full label */
  short?: boolean;
  /** tile-chip look (dark pill behind the code) */
  chip?: boolean;
  className?: string;
  title?: string;
}) {
  if (kind !== undefined && !isWearableKind(kind)) return null;
  const label = displayWearLabel(wear, name);
  return (
    <span
      className={cn("font-black uppercase tracking-wider", chip && "rounded bg-black/65 px-1 py-px", className)}
      style={{ color: wearColorOf(label) }}
      title={title ?? `Exterior: ${label}`}
      dir="ltr"
    >
      {short ? wearShortOf(label) : label}
    </span>
  );
}
