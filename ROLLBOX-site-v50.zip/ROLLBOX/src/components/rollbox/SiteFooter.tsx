"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { Logo } from "./Logo";
import { cn } from "@/lib/utils";

interface FooterLink {
  label: string;
  href?: string; // absent = placeholder page (coming soon)
}

interface FooterColumn {
  title: string;
  links: FooterLink[];
}

// USER SPEC: the old one-row footer links (Discord / All Skins / Provably Fair /
// TOS) are reorganized into FOUR categories next to the logo. Discord lives
// only as the TopBar icon now; All Skins = the Exchange (skin catalog).
const FOOTER_COLUMNS: FooterColumn[] = [
  {
    title: "GAMES",
    links: [
      { label: "Exchange", href: "/skins" },
      { label: "Event", href: "/event" },
      { label: "Giveaways", href: "/giveaways" },
      { label: "Missions", href: "/missions" },
      { label: "Free cases", href: "/#special" },
      { label: "Upgrade", href: "/upgrader" },
      { label: "Battles", href: "/battles" },
    ],
  },
  {
    title: "CASES",
    links: [
      { label: "Gold Rush", href: "/case/gold-rush" },
      { label: "Glove Syndicate", href: "/case/glove-syndicate" },
      { label: "Blade Barony", href: "/case/blade-barony" },
      { label: "Neon District", href: "/case/neon-district" },
      { label: "Asiimov Protocol", href: "/case/asiimov-protocol" },
    ],
  },
  {
    title: "INFORMATION",
    links: [
      { label: "Terms of Services", href: "/tos" },
      { label: "Privacy Policy" },
      { label: "Cookie Policy" },
    ],
  },
  {
    title: "HELP",
    links: [
      { label: "FAQ", href: "/faq" },
      { label: "Provably Fair", href: "/provably-fair" },
      { label: "Contact Us" },
    ],
  },
];

export function SiteFooter() {
  // USER SPEC (Task 88): SHOW MORE unfolds a placeholder section ("SOON"
  // for now) under the about text, until its real content is decided.
  const [more, setMore] = useState(false);

  return (
    <footer className="mt-auto border-t border-white/10 bg-[#0a0612]">
      <div className="mx-auto max-w-7xl px-4 py-10">
        {/* ===== USER SPEC: the big logo sits at the LEFT side of the bottom
                strip; the four light-gray categories sit right next to it ===== */}
        <div className="flex flex-col gap-10 lg:flex-row lg:items-start lg:gap-14">
          <div className="shrink-0">
            <Logo size="lg" />
          </div>

          <nav
            className="grid flex-1 grid-cols-2 gap-8 sm:grid-cols-4 lg:justify-items-end lg:gap-16"
            aria-label="Footer"
          >
            {FOOTER_COLUMNS.map((col) => (
              <div key={col.title} className="min-w-0">
                <h3 className="font-display text-xs font-black uppercase tracking-[0.25em] text-gray-300">
                  {col.title}
                </h3>
                <ul className="mt-3 space-y-2">
                  {col.links.map((l) => (
                    <li key={l.label}>
                      {l.href ? (
                        <Link
                          href={l.href}
                          className="text-sm font-semibold text-white/45 transition-colors hover:text-white"
                        >
                          {l.label}
                        </Link>
                      ) : (
                        <span className="cursor-default text-sm font-semibold text-white/25" title="Coming soon">
                          {l.label}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>

        {/* USER SPEC (Task 88): the ABOUT ROLLBOX block — one line of brand
            copy + a SHOW MORE expander that opens a placeholder below. */}
        <div className="mx-auto mt-10 max-w-2xl text-center">
          <p className="font-display text-sm font-black tracking-[0.3em] text-white/75">
            ABOUT ROLLBOX
          </p>
          <p className="mt-2 text-sm leading-relaxed text-white/50">
            RollBox is created by players for players who share a passion for CS skins.
          </p>

          <button
            type="button"
            onClick={() => setMore((v) => !v)}
            aria-expanded={more}
            className="mx-auto mt-4 flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.04] px-5 py-2 font-display text-xs font-black tracking-[0.25em] text-white/70 transition-colors hover:border-fuchsia-400/40 hover:bg-white/[0.07] hover:text-white"
          >
            {more ? "SHOW LESS" : "SHOW MORE"}
            <ChevronDown
              className={cn("h-3.5 w-3.5 transition-transform duration-300", more && "rotate-180")}
            />
          </button>

          {more && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="mt-4 rounded-xl border border-dashed border-white/15 bg-white/[0.03] px-6 py-7"
            >
              <p className="font-display text-3xl font-black tracking-[0.4em]">
                <span className="text-gradient-neon">SOON</span>
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </footer>
  );
}
