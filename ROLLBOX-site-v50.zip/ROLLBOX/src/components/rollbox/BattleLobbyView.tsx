"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Clock, Eye, Flame, Lock, Plus, SlidersHorizontal, Star, Swords, Users } from "lucide-react";
import { CASES, formatCoins } from "@/lib/cases";
import { BATTLE_MODES, BATTLE_TYPES, battleEntry, emptySeats, potRuleOf, timeAgo } from "@/lib/battles";
import type { Battle, BattlePotRule } from "@/lib/battles";
import { viewersFor } from "@/lib/battles-ui";
import { useSession } from "@/lib/session";
import { useCaseStore } from "@/lib/store";
import { useRealtimeEvent } from "@/lib/realtime";
import { sfx } from "@/lib/sound";
import { CaseImage } from "./CaseImage";
import { Coin } from "./Coin";
import { PlayerAvatar } from "./BattleBits";
import { SiteShell } from "./SiteShell";
import { useMounted } from "@/hooks/use-mounted";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// USER SPEC (Task 196): the search filters (max entry / custom budget /
// favorites-only) are DELETED — the lobby filters are now MODE (emoji chips)
// and PLAYER COUNT (2, 3, 4, 2vs2) only.

/** The four MODE chips — the emoji rides EVERY name (user spec):
 *  STANDARD ✊ · CRAZYMODE 😵‍💫 · SHARED 🤝 · JACKPOT 🎲 */
const MODE_FILTERS = [
  { key: "standard", label: "Standard", emoji: "✊" },
  { key: "crazy", label: "Crazymode", emoji: "😵‍💫" },
  { key: "shared", label: "Shared", emoji: "🤝" },
  { key: "jackpot", label: "Jackpot", emoji: "🎲" },
] as const;
type ModeFilterKey = (typeof MODE_FILTERS)[number]["key"];

/**
 * Every battle falls into EXACTLY one visible mode bucket — the same ladder
 * the row badge renders: SHARED first, then JACKPOT, then CRAZYMODE, and
 * plain winner-rule standard games are STANDARD.
 */
const modeBucketOf = (b: { potRule?: BattlePotRule; mode: string }): ModeFilterKey =>
  b.potRule === "shared" ? "shared" : b.potRule === "jackpot" ? "jackpot" : b.mode === "crazy" ? "crazy" : "standard";

/** The PLAYERS chips — 2 (1v1), 3 (1v1v1), 4 (1v1v1v1) and 2VS2 (teams). */
const PLAYER_FILTERS = [
  { key: "2", label: "2", title: "2 players — 1v1" },
  { key: "3", label: "3", title: "3 players — 1v1v1" },
  { key: "4", label: "4", title: "4 players — 1v1v1v1" },
  { key: "2vs2", label: "2VS2", title: "2 vs 2 — team battles" },
] as const;

/** 1v1 → "2" · 1v1v1 → "3" · 1v1v1v1 → "4" · 2v2 → "2vs2" */
const playerBucketOf = (b: { maxPlayers: number; teamMode: boolean }): string =>
  b.teamMode ? "2vs2" : String(b.maxPlayers);

export function BattleLobbyView() {
  const mounted = useMounted();
  const router = useRouter();
  const { toast } = useToast();
  const { player: me, patch } = useSession();
  const localBalance = useCaseStore((s) => s.balance);
  // signed-in players fight for DATABASE coins — the balance that matters here
  const balance = me ? me.balance : localBalance;
  const favoriteBattles = useCaseStore((s) => s.favoriteBattles);
  const toggleFavoriteBattle = useCaseStore((s) => s.toggleFavoriteBattle);

  // USER SPEC (Task 196): the new filter chips — an EMPTY selection means the
  // group is off (everything shows); every active chip is a keep-only match
  const [modeSel, setModeSel] = useState<ModeFilterKey[]>([]);
  const [playerSel, setPlayerSel] = useState<string[]>([]);
  const toggleChip = <T,>(list: T[], v: T): T[] => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);

  // MULTIPLAYER: the ONE shared worldwide list — every visitor sees the same
  // rooms, mapped into the original row shape so the lobby looks untouched.
  const [rooms, setRooms] = useState<Battle[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const myId = me?.id ?? "";

  const poll = useCallback(async () => {
    try {
      const r = await fetch("/api/gbattles", { cache: "no-store" });
      const data = (await r.json()) as {
        battles: {
          id: string;
          type: string;
          mode: string;
          potRule: string;
          entry: number;
          status: string;
          rounds: string[];
          seats: { key: string; name: string; avatar?: string; isBot: boolean; team: number; side?: number; color: number; joinedAt: number }[];
          maxPlayers: number;
          createdAt: number;
        }[];
      };
      const mapped: Battle[] = (data.battles ?? []).map((b) => ({
        id: b.id,
        type: b.type as Battle["type"],
        mode: b.mode as Battle["mode"],
        potRule: b.potRule as BattlePotRule,
        maxPlayers: b.maxPlayers,
        teamMode: b.maxPlayers === 4,
        rounds: b.rounds,
        status: b.status === "waiting" ? "waiting" : "playing",
        createdAt: b.createdAt,
        players: b.seats.map((s) => ({
          id: s.key,
          name: s.name,
          isYou: s.key === myId,
          isBot: s.isBot,
          team: (s.team === 1 ? 1 : 0) as 0 | 1,
          side: (s.side ?? 0) as 0 | 1,
          joinedAt: s.joinedAt,
          color: s.color,
        })),
        colorOrder: [0, 1, 2, 3],
        botCalls: {},
        fullSince: null,
        global: true,
      }));
      setRooms(mapped);
      setLoaded(true);
    } catch {
      /* stale until the next poll */
    }
  }, [myId]);

  useEffect(() => {
    if (!mounted) return;
    const timer = window.setTimeout(() => void poll(), 0);
    const iv = window.setInterval(() => void poll(), 2000);
    return () => {
      window.clearTimeout(timer);
      window.clearInterval(iv);
    };
  }, [mounted, poll]);

  // REALTIME (Task 64): the server announces every lobby change (create/join/
  // leave/start/finish) — this client refetches the SAME list at the SAME
  // moment as everyone else, instead of waiting for its own next poll.
  useRealtimeEvent("battles", () => {
    void poll();
  });

  // re-render every 5s so "time ago" labels stay fresh
  const [, setNow] = useState(0);
  useEffect(() => {
    const t = window.setInterval(() => setNow((v) => v + 1), 5000);
    return () => window.clearInterval(t);
  }, []);

  // USER SPEC (Task 67): JOIN BY CODE — private battles never appear in this
  // list; a friend's RB-XXXX code (or its link) is the ONLY way in
  const [code, setCode] = useState("");
  const [codeBusy, setCodeBusy] = useState(false);
  const joinByCode = async () => {
    const clean = code.trim().toUpperCase();
    if (!clean || codeBusy) return;
    setCodeBusy(true);
    try {
      const r = await fetch(`/api/gbattles?code=${encodeURIComponent(clean)}`, { cache: "no-store" });
      if (!r.ok) {
        sfx.error();
        toast({ title: "No battle with that code", description: "Check the code with the player who invited you.", variant: "destructive" });
        return;
      }
      const data = (await r.json()) as { battle?: { id?: string } };
      if (data.battle?.id) {
        sfx.click();
        router.push(`/battles/${data.battle.id}`);
      }
    } catch {
      sfx.error();
      toast({ title: "Could not reach the server", variant: "destructive" });
    } finally {
      setCodeBusy(false);
    }
  };

  // every live battle in the lobby — open (JOIN) and already-started (WATCH).
  // USER SPEC (Task 196): mode + player-count chips replace the old filters.
  const filtersActive = modeSel.length > 0 || playerSel.length > 0;
  const active = useMemo(
    () =>
      rooms
        .filter((b) => b.status === "waiting" || b.status === "playing")
        .filter((b) => modeSel.length === 0 || modeSel.includes(modeBucketOf(b)))
        .filter((b) => playerSel.length === 0 || playerSel.includes(playerBucketOf(b)))
        .sort(
          (a, b) =>
            Number(favoriteBattles.includes(b.id)) - Number(favoriteBattles.includes(a.id)) ||
            b.createdAt - a.createdAt
        ),
    [rooms, modeSel, playerSel, favoriteBattles]
  );

  const join = async (id: string) => {
    const b = rooms.find((x) => x.id === id);
    if (!b || busy) return;
    const entry = battleEntry(b);
    if (balance < entry) {
      sfx.error();
      return;
    }
    if (!me) {
      // the room lives on the server — an account is required to take a seat
      router.push(`/login?next=${encodeURIComponent(`/battles/${id}`)}`);
      return;
    }
    setBusy(id);
    try {
      const r = await fetch(`/api/gbattles/${id}/join`, { method: "POST" });
      const data = (await r.json()) as { balance?: number; error?: string };
      if (!r.ok) {
        sfx.error();
        toast({ title: data.error ?? "Could not join — the room just filled up", variant: "destructive" });
        setBusy(null);
        void poll();
        return;
      }
      if (typeof data.balance === "number") patch({ balance: data.balance });
      sfx.click();
      router.push(`/battles/${id}`);
    } catch {
      sfx.error();
      toast({ title: "Could not reach the server", variant: "destructive" });
      setBusy(null);
    }
  };

  const watch = (id: string) => {
    sfx.click();
    router.push(`/battles/${id}`);
  };

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-8" aria-label="Case battles lobby">

        <div className="relative mx-auto max-w-6xl px-4">
          {/* hero */}
          <div className="text-center">
            <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl border border-fuchsia-400/30 bg-fuchsia-400/10 shadow-[0_0_36px_rgba(217,70,239,0.3)]">
              <Swords className="h-9 w-9 text-fuchsia-300" />
            </span>
            <h1 className="font-display text-4xl font-black tracking-wide text-white md:text-5xl">
              CASE <span className="text-gradient-neon">BATTLES</span>
            </h1>
            {/* USER SPEC (Task 80): simple welcome copy — the mode explanations live on the create page */}
            <p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-white/60 md:text-base">
              Create, join or even watch live battles. Participate in a battle to level up or get new skins!
            </p>
            <button
              onClick={() => {
                sfx.click();
                router.push("/battles/new");
              }}
              className="neon-btn mx-auto mt-5 flex items-center gap-2 rounded-xl px-8 py-3.5 text-base font-black text-white"
            >
              <Plus className="h-5 w-5" />
              CREATE BATTLE
            </button>
            {/* USER SPEC (Task 67): the private-room door — enter a friend's code */}
            <form
              className="mx-auto mt-4 flex w-full max-w-sm items-center gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                void joinByCode();
              }}
            >
              <div className="relative flex-1">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-amber-300/70" />
                <Input
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="PRIVATE CODE — RB-XXXX"
                  aria-label="Join a private battle by its code"
                  maxLength={7}
                  className="border-amber-400/30 bg-black/40 pl-9 font-mono font-black tracking-widest text-amber-200 placeholder:font-sans placeholder:font-bold placeholder:tracking-normal placeholder:text-white/30"
                />
              </div>
              <button
                type="submit"
                disabled={codeBusy || code.trim().length < 3}
                className="rounded-xl border border-amber-400/40 bg-amber-400/10 px-4 py-2.5 text-xs font-black uppercase tracking-widest text-amber-300 transition-all hover:bg-amber-400/20 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Join
              </button>
            </form>
          </div>

          {/* ===== open battles ===== */}
          <div className="mt-9">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-sm font-black uppercase tracking-[0.25em] text-white/55">
                Open battles
              </h2>
              <span className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-300/80">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                LIVE — players join in real time
              </span>
            </div>

            {/* USER SPEC (Task 196): the NEW filters — MODE chips with the emoji
                next to every name (✊ 😵‍💫 🤝 🎲) + the players count row written
                as "Players : 2, 3, 4, 2vs2". Empty selection = group off. */}
            <div
              className="mb-3 flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-2xl border border-white/10 bg-[#100a1e]/90 px-3 py-2.5"
              role="group"
              aria-label="Filter battles by mode and players"
            >
              <span className="mr-1 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-white/40">
                <SlidersHorizontal className="h-3.5 w-3.5" />
                Mode
              </span>
              {MODE_FILTERS.map((m) => {
                const on = modeSel.includes(m.key);
                return (
                  <button
                    key={m.key}
                    onClick={() => {
                      setModeSel((sel) => toggleChip(sel, m.key));
                      sfx.click();
                    }}
                    aria-pressed={on}
                    title={`${m.label} battles${m.key === "crazy" ? " — lowest total wins / inverted jackpot odds" : ""}`}
                    className={cn(
                      "flex h-7 items-center gap-1 rounded-lg px-2.5 text-[10px] font-black uppercase tracking-wide transition-all",
                      on
                        ? "bg-fuchsia-500/80 text-white shadow-[0_0_14px_rgba(217,70,239,0.45)]"
                        : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"
                    )}
                  >
                    <span className="text-[13px] leading-none" aria-hidden="true">
                      {m.emoji}
                    </span>
                    {m.label}
                  </button>
                );
              })}
              <span className="mx-1 hidden h-5 w-px bg-white/10 sm:block" aria-hidden="true" />
              {/* the players group reads EXACTLY like the spec: Players : 2, 3, 4, 2vs2 */}
              <span className="mr-1 text-[10px] font-black uppercase tracking-widest text-white/40">Players :</span>
              {PLAYER_FILTERS.map((p) => {
                const on = playerSel.includes(p.key);
                return (
                  <button
                    key={p.key}
                    onClick={() => {
                      setPlayerSel((sel) => toggleChip(sel, p.key));
                      sfx.click();
                    }}
                    aria-pressed={on}
                    title={p.title}
                    className={cn(
                      "font-display h-7 min-w-8 rounded-lg px-2 text-[10px] font-black transition-all",
                      on
                        ? "bg-fuchsia-500/80 text-white shadow-[0_0_14px_rgba(217,70,239,0.45)]"
                        : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"
                    )}
                  >
                    {p.label}
                  </button>
                );
              })}
            </div>

            {mounted && loaded && active.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                className="grid place-items-center rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-16 text-center"
              >
                <Swords className="h-10 w-10 text-white/20" />
                <p className="font-display mt-4 text-lg font-black tracking-wide text-white/55">
                  {filtersActive
                    ? "No battles match these filters"
                    : "No battles available right now"}
                </p>
                <p className="mt-1 max-w-sm text-xs font-semibold leading-relaxed text-white/35">
                  {filtersActive
                    ? "Tap a glowing chip again to release the filter — new rooms land here in real time."
                    : "Be the first — stack a few cases, choose the format and open a room. Bots (or you) will fill the seats."}
                </p>
                <button
                  onClick={() => {
                    sfx.click();
                    router.push("/battles/new");
                  }}
                  className="neon-btn mt-5 flex items-center gap-2 rounded-xl px-7 py-3 text-sm font-black text-white"
                >
                  <Plus className="h-4 w-4" />
                  CREATE BATTLE
                </button>
              </motion.div>
            ) : (
              <div className="flex flex-col gap-2" role="list" aria-label="Open battles list">
                {mounted &&
                  active.map((b) => {
                    const spec = BATTLE_TYPES[b.type];
                    const entry = battleEntry(b);
                    const seats = emptySeats(b);
                    const mine = b.players.some((p) => p.isYou);
                    const affordable = balance >= entry;
                    const fav = favoriteBattles.includes(b.id);
                    const started = b.status === "playing";
                    return (
                      <motion.div
                        key={b.id}
                        layout
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.22 }}
                        role="listitem"
                        className={cn(
                          "relative flex flex-wrap items-center gap-x-4 gap-y-3 rounded-2xl border px-4 py-3.5 sm:px-5",
                          mine
                            ? "border-fuchsia-400/50 bg-fuchsia-500/[0.06] shadow-[0_0_26px_rgba(217,70,239,0.10)]"
                            : "border-white/10 bg-[#100a1e]/90"
                        )}
                      >
                        {/* favorite star — far left edge */}
                        <button
                          onClick={() => {
                            toggleFavoriteBattle(b.id);
                            sfx.click();
                          }}
                          aria-label={fav ? `Remove ${spec.short} battle from favorites` : `Add ${spec.short} battle to favorites`}
                          aria-pressed={fav}
                          className={cn(
                            "grid h-10 w-10 shrink-0 place-items-center rounded-xl border transition-all",
                            fav
                              ? "border-amber-400/60 bg-amber-400/15 text-amber-300 shadow-[0_0_12px_rgba(240,185,11,0.35)]"
                              : "border-white/10 bg-white/5 text-white/35 hover:border-amber-400/40 hover:text-amber-300"
                          )}
                        >
                          <Star className={cn("h-5 w-5", fav && "fill-current")} />
                        </button>

                        {/* rounds + the cases in the battle (first 5) — left side.
                            USER SPEC: every box sits in a SQUARE tile with the box
                            name right below the box itself */}
                        <span className="flex min-w-0 items-start gap-2.5" dir="ltr">
                          <span className="font-display shrink-0 rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-xs font-black tracking-widest text-white/75">
                            {b.rounds.length}
                            <br />
                            {b.rounds.length === 1 ? "ROUND" : "ROUNDS"}
                          </span>
                          <span className="flex min-w-0 items-start gap-2 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                            {b.rounds.slice(0, 5).map((cid, i) => {
                              const cs = CASES.find((c) => c.id === cid);
                              if (!cs) return null;
                              return (
                                <span key={`${cid}-${i}`} className="w-14 shrink-0 sm:w-16" title={`${cs.name} — $${formatCoins(cs.price)}`}>
                                  <span className="grid aspect-square place-items-center rounded-xl border border-white/10 bg-black/30 p-1.5">
                                    <span className="pointer-events-none block w-[82%]">
                                      <CaseImage caseId={cs.id} alt={cs.name} color={cs.tierColor} color2={cs.tierColor2} communityDesign={cs.communityDesign} sizes="64px" />
                                    </span>
                                  </span>
                                  <span className="mt-1 block w-full truncate text-center text-[9px] font-bold text-white/55">
                                    {cs.name}
                                  </span>
                                </span>
                              );
                            })}
                            {b.rounds.length > 5 && (
                              <span className="font-display shrink-0 self-center text-xs font-black text-white/40">+{b.rounds.length - 5}</span>
                            )}
                          </span>
                        </span>

                        {/* battle price — turquoise (user spec) */}
                        <span
                          className="font-display flex shrink-0 items-center gap-1 text-lg font-black text-teal-300 md:text-xl"
                          title="Battle price — what one seat costs"
                        >
                          <Coin /> {formatCoins(entry)}
                        </span>

                        {/* details — mode + participants (user spec) + live viewers.
                            Task 42: JACKPOT / SHARED badges for the new pot rules */}
                        <span className="flex min-w-0 flex-wrap items-center gap-2">
                          {potRuleOf(b) === "jackpot" ? (
                            <span className="rounded-lg bg-gradient-to-r from-violet-500 to-fuchsia-500 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-white">
                              JACKPOT
                            </span>
                          ) : potRuleOf(b) === "shared" ? (
                            <span className="rounded-lg bg-gradient-to-r from-teal-500 to-emerald-500 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-white">
                              SHARED
                            </span>
                          ) : b.mode === "crazy" ? (
                            <span className="flex items-center gap-1 rounded-lg bg-gradient-to-r from-rose-500 to-orange-500 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-white">
                              <Flame className="h-3 w-3" />
                              {BATTLE_MODES.crazy.label}
                            </span>
                          ) : (
                            <span className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-white/60">
                              {BATTLE_MODES.standard.label}
                            </span>
                          )}
                          {/* USER SPEC (R40): the ⚡️ FAST badge is DELETED with FAST MODE */}
                          <span className="rounded-lg border border-white/10 bg-black/40 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-white/60">
                            {spec.short}
                          </span>
                          <span className="flex items-center gap-1 text-xs font-bold text-white/50">
                            <Users className="h-3.5 w-3.5" />
                            {b.players.length}/{b.maxPlayers}
                          </span>
                          <span className="flex items-center gap-1" aria-label={`${viewersFor(b.id)} players watching this battle`}>
                            <Eye className="h-3.5 w-3.5 text-sky-300/80" />
                            <span className="text-xs font-black text-sky-300/90">{viewersFor(b.id)}</span>
                          </span>
                          {b.players.slice(0, 4).map((p) => (
                            <PlayerAvatar key={p.id} player={p} />
                          ))}
                          <span className="hidden items-center gap-1 text-[11px] font-bold text-white/35 md:flex">
                            <Clock className="h-3.5 w-3.5" />
                            {timeAgo(b.createdAt)}
                          </span>
                        </span>

                        {/* action — far right (user spec): JOIN when there is a seat,
                            WATCH when the battle already started */}
                        <span className="ml-auto flex shrink-0 items-center gap-2.5">
                          {started && (
                            <span className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-emerald-300">
                              <span className="relative flex h-2 w-2">
                                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
                                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                              </span>
                              Live
                            </span>
                          )}
                          {started ? (
                            <button
                              onClick={() => watch(b.id)}
                              className="font-display flex items-center gap-1.5 rounded-xl border border-sky-400/50 bg-sky-500/15 px-6 py-2.5 text-sm font-black text-sky-300 transition-all hover:bg-sky-500/25 hover:text-sky-200"
                            >
                              <Eye className="h-4 w-4" />
                              WATCH
                            </button>
                          ) : mine ? (
                            <button
                              onClick={() => watch(b.id)}
                              className="font-display rounded-xl border border-fuchsia-400/50 bg-fuchsia-500/15 px-6 py-2.5 text-sm font-black text-fuchsia-300 transition-all hover:bg-fuchsia-500/25"
                            >
                              OPEN
                            </button>
                          ) : seats > 0 ? (
                            <button
                              onClick={() => void join(b.id)}
                              disabled={!affordable || busy === b.id}
                              className={cn(
                                "font-display rounded-xl px-6 py-2.5 text-sm font-black transition-all",
                                affordable && busy !== b.id
                                  ? "gold-btn text-black shadow-[0_0_14px_rgba(240,185,11,0.4)] hover:scale-[1.03]"
                                  : "cursor-not-allowed bg-white/5 text-white/30"
                              )}
                            >
                              {busy === b.id ? "JOINING…" : affordable ? "JOIN" : "LOW BALANCE"}
                            </button>
                          ) : (
                            <button
                              onClick={() => watch(b.id)}
                              className="font-display flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-6 py-2.5 text-sm font-black text-white/60 transition-all hover:bg-white/10 hover:text-white"
                            >
                              <Eye className="h-4 w-4" />
                              WATCH
                            </button>
                          )}
                        </span>
                      </motion.div>
                    );
                  })}
              </div>
            )}
          </div>

        </div>
      </main>
    </SiteShell>
  );
}
