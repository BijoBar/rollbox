"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Zap,
  Gauge,
  ShieldCheck,
  ExternalLink,
  Sparkles,
  Lock,
  Clock,
} from "lucide-react";
import {
  RARITY_META,
  SKINS,
  formatCoins,
  oddsPct,
  skinWithWear,
  type CaseDef,
  type Skin,
  type Rarity,
  type WearId,
} from "@/lib/cases";
import { wearIdFromLabel, displayWearLabel, wearColorOf, DEFAULT_WEAR_LABEL } from "@/lib/wear";
import { shortSeed, type RollProof } from "@/lib/provably-fair";
import { useCaseStore } from "@/lib/store";
import { useSession } from "@/lib/session";
import { caseDailyNextIn, caseXp, formatCountdown, levelFromXp } from "@/lib/progress";
import { maybeRollDrop, rareCaseOf, rolldropChanceOf, ROLLDROP_MARKER } from "@/lib/rolldrop";
import { RD_BEAT_MS } from "@/lib/gbattle-shared";
import { sfx } from "@/lib/sound";
import { emitWinFx } from "@/lib/win-fx";
import { SkinTile } from "./SkinTile";
import { CaseImage } from "./CaseImage";
import { RolldropTile } from "./RolldropTile";
import { SKIN_IMAGES } from "@/lib/skin-images";
import { Coin } from "./Coin";
import { useToast } from "@/hooks/use-toast";
import { cn, edgingClock, edgingGlidePx, edgingPhases, edgingRoll } from "@/lib/utils";

type Phase = "idle" | "opening" | "filling" | "spinning" | "revealed";

// USER SPEC (Task 100c + Task 176): a long fast roulette with a lively tail —
// single reel: 36 cells @ 6.4s = 5.6 cells/s vs the old 24 @ 6.5s = 3.7, and
// since Task 176 the ending CRAWLS visibly instead of freezing. FAST mode
// below is untouched.
const SPIN_MS = 6400;
// Task 176 (user spec): "the END of the reel stays too long in place before
// the winner locks — make it close faster." Two levers, cases only: the spin
// is 20% shorter (8s → 6.4s) AND the crawl exponent drops 6 → 4 (power-6 sat
// visually frozen for the last ~2.4s; power-4 keeps a visible, ticking crawl
// almost to the snap). Battles/jackpot keep the shared default (6).
const CRAWL_POW = 4;
// USER SPEC (Task 42): FAST MODE — the spin is NEVER skipped anymore, it just
// plays at super speed (the same quartic ease-out, ~9x faster)
const FAST_SPIN_MS = 700;
// Task 100c run-up pair: winner at 36 of 44 (single reel). Longer strip = the
// faster fly-by above; the extra tiles stay cheap via content-visibility +
// the trickle mount (Task 100).
const STRIP_LEN = 44;
const WINNER_INDEX = 36;

/* ===== USER SPEC (Task 100c): x5+ spins LONGER and FASTER =====
   Winner at 28 of 34: 28 cells @ 8s = 3.5 cells/s vs the old 18 @ 6.5s =
   2.8 — +26% speed, +23% duration, same feel as the single reel. Pure
   visuals — odds, provably-fair draws and prices are derived from the case
   data, never from the strip length. */
const MULTI_STRIP_LEN = 34;
const MULTI_WINNER_INDEX = 28;

/** tiles dealt one-by-one in the visible window before the rest trickles in */
const FILL_VIS = 8;
const FILL_MS = 55; // per visible tile — the one-by-one deal the player actually watches
/** PERF (Task 100): hidden tiles mount in small batches spread across frames —
 *  x20 used to mount 320 tiles in ONE React commit (the giant pre-spin stall). */
const FILL_TRICKLE_EVERY = 16; // ms per batch (one per animation frame)
const FILL_TRICKLE_BATCH = 3; // tiles per reel per batch

/** PERF (Task 100): warm the HTTP + decoded-image caches for this round's
 *  winners while the crate lid + fill phase play — the lock frame never waits
 *  on a cold Steam-CDN decode mid-spin. Fire-and-forget; failures harmless. */
function preheatSkins(skinIds: string[]) {
  for (const id of skinIds) {
    const url = SKIN_IMAGES[id];
    if (!url) continue;
    const img = new Image();
    img.decoding = "async";
    img.src = url;
    img.decode().catch(() => {});
  }
}

interface ReelItem {
  key: number;
  skinId: string;
  isWinner?: boolean;
  /** Task 72: exterior id when the winning item pins a wear. */
  wearId?: WearId;
}

interface WinRec {
  uid: string;
  skin: Skin;
  nonce: number;
}


/** Park a reel's strip back at its start (React-compiler-safe DOM reset). */
function parkStripEls(refs: (HTMLDivElement | null)[]) {
  for (const el of refs) {
    if (el) el.style.transform = "translate3d(0,0,0)";
  }
}

function dims(vertical: boolean) {
  const mobile = typeof window !== "undefined" && window.innerWidth < 640;
  // vertical (multi-open columns): tile HEIGHT; horizontal (single reel): tile WIDTH
  // vertical tiles are tall/portrait with big skin art (user request) — purely
  // cosmetic: odds, strip build and provably-fair draws are unaffected
  return vertical
    ? { item: mobile ? 136 : 168, gap: 10 }
    : { item: mobile ? 240 : 320, gap: 8 }; // single reel: SQUARE tiles — Task 97: BIGGER roulette
}

/** Reel height scales down as more reels are stacked. */
function reelHeightClass(count: number) {
  if (count <= 1) return "h-[240px] sm:h-[320px]";
  if (count <= 3) return "h-[176px] sm:h-[208px]";
  return "h-[152px] sm:h-[176px]";
}

// Task 98 (USER SPEC): the gold OUTLINE around won skins is GONE — the win
// tile keeps its clean transparent square (no border, no box-shadow glow).
/** Solid-gold TOTAL WON payout (no transparency) + a warm gold glow. */
const GOLD = "#f0b90b";
const GLOW_GOLD = "0 0 12px rgba(240,185,11,0.55), 0 0 32px rgba(240,185,11,0.28)";

const RARITY_ORDER: Record<Rarity, number> = {
  consumer: 0,
  milspec: 1,
  restricted: 2,
  classified: 3,
  covert: 4,
  contraband: 5,
};

/** Gold radial used by the rare-pull lock flash (both opener & battles). */
export const GOLD_FLASH_BG =
  "radial-gradient(ellipse at center, rgba(240,185,11,0.95) 0%, rgba(240,185,11,0.42) 45%, transparent 75%)";

/** Name + price chip that pops under the winning skin when a reel locks. */
export function WinnerChip({
  skinId,
  wearId,
  className,
  style,
}: {
  skinId: string;
  wearId?: WearId;
  className?: string;
  style?: React.CSSProperties;
}) {
  if (!SKINS[skinId]) return null; // ROLLDROP marker tiles have no skin
  const ws = skinWithWear(skinId, wearId);
  const rm = RARITY_META[ws.rarity];
  return (
    <div
      className={cn(
        "anim-pop-in pointer-events-none absolute left-1/2 z-30 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-lg border bg-black/80 px-3 py-1.5 backdrop-blur-sm",
        className
      )}
      style={{ borderColor: rm.color + "99", boxShadow: `0 0 18px ${rm.color}55`, ...style }}
    >
      <span className="max-w-[190px] truncate text-[11px] font-black text-white sm:max-w-[280px] sm:text-xs">
        {ws.name}
      </span>
      {/* R43 USER SPEC: the exterior rides the winner chip — always, in its color */}
      <span
        className="text-[9px] font-black uppercase tracking-wider sm:text-[10px]"
        style={{ color: wearColorOf(ws.wear) }}
        title={`Exterior: ${displayWearLabel(ws.wear)}`}
      >
        {displayWearLabel(ws.wear)}
      </span>
      <span className="font-display text-[11px] font-black text-amber-400 sm:text-xs">
        <Coin /> {formatCoins(ws.value)}
      </span>
    </div>
  );
}

/* ===== Task 97 (USER SPEC) — winner details ON the roulette square =====
   The details of the skin that dropped render ON the winning tile inside the
   reel, in the battle reveal format:
   • weapon type — small but readable, DARK WHITE (not gray)
   • skin name   — big and clear, GLOWING WHITE
   • exterior    — small but readable, GRAY
   • price       — big and clear, NEON GREEN
   The tiles are transparent squares sized for every mode (1/2/3/4/5/10/15/20),
   so the whole 4-line block always fits INSIDE the skin's own square. */
const GLOW_WHITE = "0 0 12px rgba(255,255,255,0.40), 0 0 30px rgba(255,255,255,0.16)";
const NEON_GREEN = "#39FF14";
const GLOW_GREEN = "0 0 10px rgba(57,255,20,0.45), 0 0 26px rgba(57,255,20,0.20)";

/** "M4A1-S | Fade" -> weapon "M4A1-S" + title "Fade" (first " | " only —
 *  sticker/agent names keep their tail intact). */
function splitSkinName(name: string): { weapon: string; title: string } {
  const i = name.indexOf(" | ");
  return i >= 0 ? { weapon: name.slice(0, i), title: name.slice(i + 3) } : { weapon: "", title: name };
}

/** The 4-line battle-format details block, sized to sit on the winning
 *  square (gradient scrim behind it keeps every line readable). */
function WinDetails({ ws }: { ws: Skin }) {
  const { weapon, title } = splitSkinName(ws.name);
  return (
    <div className="flex w-full min-w-0 flex-col items-center gap-0.5 text-center">
      {weapon && (
        <p
          className="text-[10px] font-semibold leading-tight tracking-wide text-white/90 sm:text-xs"
          title={weapon}
        >
          {weapon}
        </p>
      )}
      <p
        className="break-words text-sm font-black leading-tight text-white sm:text-lg"
        style={{ textShadow: GLOW_WHITE }}
      >
        {title}
      </p>
      {ws.wear ? (
        <p
          className="text-[9px] font-medium leading-tight sm:text-[11px]"
          style={{ color: wearColorOf(ws.wear) }}
        >
          {ws.wear}
        </p>
      ) : (
        <p className="text-[9px] font-medium leading-tight sm:text-[11px]" style={{ color: wearColorOf(DEFAULT_WEAR_LABEL) }}>
          {DEFAULT_WEAR_LABEL}
        </p>
      )}
      <p
        className="font-display mt-0.5 flex items-center gap-1.5 text-base font-black leading-none sm:text-lg"
        style={{ color: NEON_GREEN, textShadow: GLOW_GREEN }}
      >
        <Coin /> {formatCoins(ws.value)}
      </p>
    </div>
  );
}

export function CaseOpener({ caseDef }: { caseDef: CaseDef }) {
  const pay = useCaseStore((s) => s.pay);
  const grantXp = useCaseStore((s) => s.grantXp);
  const { toast } = useToast();
  const [count, setCount] = useState(1);
  // 2+ cases open side-by-side in VERTICAL scrolling columns; a single case
  // keeps the classic horizontal reel
  const vertical = count > 1;
  const { item, gap } = dims(vertical);

  // USER SPEC (Task 133): multi-open is capped at FIVE cases (was 20 in
  // Task 67 — user request). x5 uses the MULTI strip (Task 100c: 34 tiles,
  // winner at 28 — see the constants).
  const stripLen = count >= 5 ? MULTI_STRIP_LEN : STRIP_LEN;
  const winIdx = count >= 5 ? MULTI_WINNER_INDEX : WINNER_INDEX;

  const ensurePF = useCaseStore((s) => s.ensurePF);

  // seed the provably-fair engine on mount (hydration-safe)
  useEffect(() => {
    ensurePF();
  }, [ensurePF]);

  // PERF (Task 101): if the opener unmounts mid-spin (navigation), release the
  // corridor's 30fps spin mode so the background never stays throttled
  useEffect(
    () => () => {
      window.dispatchEvent(new Event("rb-spin-reset"));
    },
    []
  );

  const [phase, setPhase] = useState<Phase>("idle");
  const [proofs, setProofs] = useState<RollProof[]>([]);
  const [strips, setStrips] = useState<ReelItem[][]>([]);

  // Task 97 (USER SPEC): the round's TOTAL payout — the sum of every reel's
  // final win (multi mode adds ALL cases together), shown in NEON GREEN when
  // the round reveals. ROLLDROP-marker slots contribute nothing until the
  // bonus round's skin replaces them.
  // USER SPEC: when ANY reel hit the ROLLDROP the TOTAL stays HIDDEN through
  // the whole bonus sequence — it appears ONCE, after the last bonus spin
  // locks, as the FULL payout (every normal skin + every rare bonus skin).
  const [rdActive, setRdActive] = useState(false);
  const bonusLeftRef = useRef(0);
  const totalWon =
    phase === "revealed" && !rdActive
      ? strips.reduce((sum, strip) => {
          const w = strip?.[winIdx];
          if (!w || !SKINS[w.skinId]) return sum;
          return sum + skinWithWear(w.skinId, w.wearId).value;
        }, 0)
      : 0;
  const [fillCount, setFillCount] = useState(0);
  const [quick, setQuick] = useState(false);
  const [lockFx, setLockFx] = useState(false);
  const [flashReels, setFlashReels] = useState<boolean[]>([]);
  const [shake, setShake] = useState(false);
  // USER SPEC (Task 45 + fix): a ROLLDROP hit REPLACES the reel's winning
  // skin — the strip's winner tile IS the raredrop art. The reel stops on it,
  // waits a second, then the extra rare round opens on the SAME reel (+1s).
  // USER SPEC (Task 67 + 145): the white FLASH cover is GONE and so is the
  // golden marker-tile beat — the bonus arms the moment the reel locks.
  const rdHitsRef = useRef<boolean[]>([]);
  // Task 149 (USER SPEC: "delete the rolldrop video, keep only the image"):
  // the impact CUTSCENE IS GONE — no rolldrop.mp4, no overlay, no preloader.
  // A hit reel sits on the frameless raredrop image for RD_BEAT_MS (the lock
  // flash covers the hand-off), then the bonus spin fires on the SAME reel.
  const rdBonusStartRef = useRef<Array<(() => void) | null>>([]);
  const rdBeatTimersRef = useRef<number[]>([]);

  const reelsWrapRef = useRef<HTMLDivElement>(null);
  const reelRefs = useRef<(HTMLDivElement | null)[]>([]);
  const streaksRef = useRef<HTMLDivElement>(null);
  const stripRefs = useRef<(HTMLDivElement | null)[]>([]);
  const rafRef = useRef(0);
  // USER SPEC (Task 81 — EDGING): one stop-offset roll per reel per round —
  // a fraction of the way from the winner's center to the NEXT tile's near
  // edge (1 = that edge lands exactly on the center line). The reel never
  // stops dead-center anymore: it always overshoots toward the next drop so
  // every round feels like a near miss / near hit. Purely cosmetic.
  const edgingRef = useRef<number[]>([]);
  const lastTickRef = useRef(-1);
  const lastTickAtRef = useRef(0);
  const fillRafRef = useRef(0);
  const spinTimeoutRef = useRef<number | undefined>(undefined);
  const openTimeoutRef = useRef<number | undefined>(undefined);
  const lastFillTickRef = useRef(-1);
  // SERVER-ROLL plumbing — signed-in players roll via /api/open; the price is
  // charged at the click but the WIN sits in an OpenPending row until the
  // reveal finishes (Task 78) — claimWin() cashes it exactly then.
  const serverRolledRef = useRef(false);
  const serverBonusRef = useRef<(RollProof | null)[]>([]);
  const pendingIdRef = useRef<string | null>(null);
  const claimFiredRef = useRef(false);
  const { player: me, patch } = useSession();
  // USER SPEC (Task 183): the player's gifted / mission-prize boxes of THIS
  // case — the OPEN button shows FREE (full or partial coverage) and the
  // server burns them before charging anything.
  const freeHave = me?.freeCases?.[caseDef.id] ?? 0;

  // ===== USER SPEC (Task 104): the free DAILY cases (LEVEL 10..100) =====
  // EVERY case up to the player's level opens FREE once per 24h — each with
  // its OWN cooldown. Signed-in players read the SERVER gate (/api/daily —
  // the truth across devices, backed by the DB battle pass); guests run the
  // same gate locally on store.dailyOpens.
  const markDailyCaseOpened = useCaseStore((s) => s.markDailyCaseOpened);
  const storeXp = useCaseStore((s) => s.xp);
  const storeDailyOpens = useCaseStore((s) => s.dailyOpens);
  const isDailyCase = caseDef.kind === "level";
  const requiredLevel = caseDef.requiredLevel ?? 0;
  const myLevel = levelFromXp(storeXp).level;
  const [serverNextIn, setServerNextIn] = useState<number | null>(null);
  const [, setDailyTick] = useState(0);
  useEffect(() => {
    if (!isDailyCase || !me) return;
    let alive = true;
    const load = async () => {
      try {
        const r = await fetch("/api/daily", { cache: "no-store" });
        if (!r.ok) return;
        const d = (await r.json()) as {
          cases?: Record<string, { ready?: boolean; nextIn?: number }>;
        };
        const next = d.cases?.[caseDef.id]?.nextIn;
        if (alive && typeof next === "number") setServerNextIn(next);
      } catch {
        /* the next round / mount retries */
      }
    };
    void load();
    return () => {
      alive = false;
    };
  }, [isDailyCase, me, caseDef.id]);
  // keep the countdown label ticking while the cooldown runs
  useEffect(() => {
    if (!isDailyCase) return;
    const t = window.setInterval(() => setDailyTick((k) => k + 1), 30000);
    return () => window.clearInterval(t);
  }, [isDailyCase]);
  const guestNextIn = caseDailyNextIn(storeDailyOpens, caseDef.id);
  const dailyNextIn = isDailyCase ? (me ? (serverNextIn ?? 0) : guestNextIn) : 0;
  const dailyUsed = isDailyCase && dailyNextIn > 0;
  const levelLocked = isDailyCase && myLevel < requiredLevel;

  // stop animation/fill, kill the whoosh layer on unmount (page navigation)
  useEffect(() => {
    return () => {
      cancelAnimationFrame(rafRef.current);
      cancelAnimationFrame(fillRafRef.current);
      window.clearTimeout(spinTimeoutRef.current);
      window.clearTimeout(openTimeoutRef.current);
      sfx.spinEnd();
      // USER SPEC (Task 140): leaving the page MID-OPEN must NOT swallow the
      // win — the roll was already decided and PAID at the click, so a still-
      // parked pending is cashed RIGHT HERE instead of waiting for the 60s
      // stale recovery. The claim endpoint is idempotent (atomic claimed flag)
      // so this can never double-credit, and keepalive lets the call survive
      // even a hard unload — not just an SPA route change.
      const pendingId = pendingIdRef.current;
      if (pendingId && !claimFiredRef.current) {
        claimFiredRef.current = true;
        void fetch("/api/open/claim", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pendingId }),
          keepalive: true,
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((d: { balance?: number } | null) => {
            if (d && typeof d.balance === "number") patch({ balance: d.balance });
          })
          .catch(() => undefined);
      }
    };
  }, [patch]);

  /** Task 78 — the money moment: the reveal finished (skin on screen, price
   *  visible; a ROLLDROP bonus spin included) — cash the parked win. Fires
   *  exactly once per round; a failed call retries once, and even a total
   *  network miss is safe (the stale-pending recovery credits on next load). */
  const claimWin = useCallback(() => {
    const pendingId = pendingIdRef.current;
    if (!pendingId || claimFiredRef.current) return;
    claimFiredRef.current = true;
    void (async () => {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const r = await fetch("/api/open/claim", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ pendingId }),
          });
          const d = (await r.json()) as { balance?: number; claimed?: boolean; error?: string };
          if (r.ok && d.claimed && typeof d.balance === "number") {
            patch({ balance: d.balance });
            return;
          }
          if (r.ok) return; // nothing was ours to claim — never block the reveal
        } catch {
          /* network hiccup — retry once, then let recovery handle it */
        }
        await new Promise((res) => setTimeout(res, 1500));
      }
      toast({
        title: "Your win is safe",
        description: "The reveal beat the connection — it lands on your balance automatically in a moment.",
      });
    })();
  }, [patch, toast]);

  const doRevealAll = useCallback(
    (results: WinRec[]) => {
      // every win is credited to the balance instantly — no inventory, no selling.
      // the ONLY win notification is the floating "+$X" pulse next to the balance
      // chip (emitWinFx → TopBar) — the small win toast was removed by request.
      const st = useCaseStore.getState();
    // USER SPEC (Task 45): the ROLLDROP extra round — a second spin of the SAME
    // reel filled only with the case's rare skins (<5% hit chance), lasting one
    // second LONGER than a normal spin to compensate the white beat. The bonus
    // value is credited on top of the normal win when the reel locks.
    const startBonusSpin = (reelIdx: number, proof: RollProof) => {
      const rare = rareCaseOf(caseDef);
      const pool = rare.items.map((i) => i.skinId);
      const strip: ReelItem[] = Array.from({ length: stripLen }, (_, i) => ({
        key: i,
        skinId: i === winIdx ? proof.skin.id : pool[Math.floor(Math.random() * pool.length)],
        isWinner: i === winIdx,
        wearId: i === winIdx ? wearIdFromLabel(proof.skin.wear) : undefined,
      }));
      setStrips((prev) => prev.map((s, i) => (i === reelIdx ? strip : s)));
      parkStripEls([stripRefs.current[reelIdx]]);
      setLockFx(false);
      setFlashReels((prev) => prev.map((f, i) => (i === reelIdx ? false : f)));
      setPhase("spinning");
      // USER SPEC (R40 — the rolldrop LOOP bug, hard guarantee): the bonus
      // reel opens with ZERO looping layers alive — anything the warp, the
      // main spin or any future path left running dies RIGHT HERE, before
      // the rare crawl plays. The bonus is carried by the ratchet ticks +
      // the lock snap (like every battle reel), never by a drone.
      sfx.killLoops();
      // USER SPEC (R38 — the rolldrop LOOP bug): the bonus reel NO LONGER
      // opens its own air-whoosh loop (sfx.spinStart). A loop started at the
      // rolldrop hit kept droning until the rare reel finished — the exact
      // bug the user reported. The bonus spin is carried by the ratchet ticks
      // + the lock snap, exactly like every battle reel (which never had a
      // whoosh). The step loop below keeps its defensive sfx.spinEnd(): if
      // ANY looping whoosh is somehow alive when the bonus crawl ends, it is
      // killed there — a loop can never outlive the rolldrop sequence.
      // PERF (Task 101): tell the corridor background to drop to 30fps —
      // the reels own the frame budget for the next few seconds
      window.dispatchEvent(new Event("rb-spin-active"));

      // USER SPEC: the extra reel runs ONE SECOND longer than a normal spin.
      // The white holds 0.75s — the bonus spin must ALWAYS outlast it, even in
      // quick mode (FAST_SPIN_MS would lock the reel while still covered).
      const spinMs = Math.max(quick ? FAST_SPIN_MS : SPIN_MS, 2500) + 1000;
      // USER SPEC (Task 81/82-fix): the bonus reel draws its own stop offset
      // (SIGNED — inside the winner's tile, see edgingGlidePx)
      const bonusEdging = edgingRoll();
      const stride = () => {
        const s = stripRefs.current[reelIdx];
        const t0 = s?.children[0] as HTMLElement | undefined;
        const t1 = s?.children[1] as HTMLElement | undefined;
        if (!t0 || !t1) return { item, gap };
        const r0 = t0.getBoundingClientRect();
        const r1 = t1.getBoundingClientRect();
        return vertical
          ? { item: Math.round(r0.height), gap: Math.round(r1.top - r0.bottom) }
          : { item: Math.round(r0.width), gap: Math.round(r1.left - r0.right) };
      };
      const targetFor = () => {
        const { item: it, gap: gp } = stride();
        if (vertical) {
          const colH = reelRefs.current[reelIdx]?.clientHeight ?? 400;
          return winIdx * (it + gp) + it / 2 - colH / 2 + bonusEdging * (it / 2 + gp);
        }
        const containerW = reelsWrapRef.current?.clientWidth ?? 700;
        return winIdx * (it + gp) + it / 2 - containerW / 2 + bonusEdging * (it / 2 + gp);
      };

      const t0 = performance.now();
      let lastTick = -1;
      let lastTickAt = 0;
      // USER SPEC (Task 82-fix + 104b): the bonus reel plays the same
      // dramatic-stop timeline — crawl into the glide INSIDE the winner's
      // tile, then ONE fast snap onto the marker (no hold beat anymore)
      const { holdMs, settleMs } = edgingPhases(spinMs, { hold: false });
      let lastPos = 0;
      let lastT = 0;
      let beatKilled = false;
      const step = (t: number) => {
        const el = t - t0;
        const total = targetFor();
        const { item: itE, gap: gpE } = stride();
        // Task 82-fix BOUNDARY RULE: the glide is clamped to the winner's own
        // half-width — the center line NEVER reaches the next tile
        const edgePx = edgingGlidePx(bonusEdging, itE);
        const c = edgingClock(el, spinMs, holdMs, settleMs, CRAWL_POW);
        const pos = c.aCrawl * total - c.aSettle * edgePx;
        const dt = lastT ? Math.max(1, t - lastT) : 16;
        const vNorm = Math.min(1, Math.abs(pos - lastPos) / dt / ((CRAWL_POW * total) / (spinMs / 1000)));
        lastPos = pos;
        lastT = t;
        const s = stripRefs.current[reelIdx];
        if (s) {
          s.style.transform = vertical
            ? `translate3d(0, ${-pos}px, 0)`
            : `translate3d(${-pos}px, 0, 0)`;
        }
        if (c.phase === "spin") {
          const { item: it, gap: gp } = stride();
          const idx = Math.floor(pos / (it + gp));
          const now = performance.now();
          if (idx !== lastTick && now - lastTickAt > 18) {
            lastTick = idx;
            lastTickAt = now;
            sfx.tick(0.75);
          }
        } else if (!beatKilled) {
          beatKilled = true;
          // R38: defensive whoosh killer — the bonus reel owns NO loop, and
          // this ends any stray looping layer the moment its crawl is done.
          sfx.spinEnd();
        }
        if (c.phase !== "done") {
          rafRef.current = requestAnimationFrame(step);
          return;
        }
        // the winner ARRIVED back at the marker — the bonus payoff locks now
        window.dispatchEvent(new Event("rb-spin-done"));
        sfx.lock();
        setLockFx(true);
        setFlashReels((prev) => prev.map((f, i) => (i === reelIdx ? true : f)));
        // the ROLLDROP round's skin is credited on top of the normal win
        if (!serverRolledRef.current) {
          const st2 = useCaseStore.getState();
          st2.creditWin(proof.skin.value);
        }
        emitWinFx(proof.skin.value);
        // the LAST finished bonus spin releases the round — TOTAL WON + the
        // full reveal flip together EXACTLY ONCE, there. Mid-sequence bonus
        // locks keep the board in "spinning" (USER SPEC Task 106: no OPEN
        // AGAIN flash, no winner details until the rolldrop sequence ends).
        bonusLeftRef.current = Math.max(0, bonusLeftRef.current - 1);
        if (bonusLeftRef.current <= 0) {
          setRdActive(false);
          setPhase("revealed");
        }
        // Task 78: the bonus spin WAS the last money moment of the round —
        // for server rolls the parked win is cashed exactly now.
        if (serverRolledRef.current) claimWin();
      };
      rafRef.current = requestAnimationFrame(step);
    };

      let total = 0;
      for (let i = 0; i < results.length; i++) {
        // USER SPEC (fix): a ROLLDROP reel wins NO skin — the raredrop replaced
        // the drawn skin; only the bonus round's rare skin will be credited
        if (rdHitsRef.current[i]) continue;
        if (!serverRolledRef.current) st.creditWin(results[i].skin.value);
        total += results[i].skin.value;
      }
      // USER SPEC (Task 106): with ANY ROLLDROP hit the board NEVER flashes
      // the reveal — the phase stays "spinning" (OPEN AGAIN hidden, the
      // "SPINNING..." status stays on, winner details suppressed) until the
      // LAST bonus spin locks — startBonusSpin flips the phase exactly once,
      // there. Without this the controls popped in for a beat and vanished.
      if (!rdHitsRef.current.some(Boolean)) setPhase("revealed");
      const normalResults = results.filter((_, i) => !rdHitsRef.current[i]);
      if (normalResults.length > 0) {
        const best = normalResults.reduce(
          (acc, r) => (RARITY_ORDER[r.skin.rarity] > RARITY_ORDER[acc] ? r.skin.rarity : acc),
          "consumer" as Rarity
        );
        sfx.revealSting(best);
      }
      if (total > 0) emitWinFx(total);
      // Task 78: for server rolls with NO ROLLDROP hit, the reveal just now was
      // the round's money moment — cash the parked win (skin on screen = paid).
      if (serverRolledRef.current && !rdHitsRef.current.some(Boolean)) claimWin();
      // USER SPEC: the hit reels STOPPED on the raredrop art — Task 149
      // (USER SPEC: the cutscene video is DELETED, image only): each hit reel
      // sits on the frameless marker for RD_BEAT_MS and then the extra
      // rare-only round opens ON THE SAME REEL (spin = normal + 1s). The
      // TOTAL WON stays hidden (rdActive) until the LAST bonus locks.
      // USER SPEC (Task 145): no golden marker-tile beat — the lock flash
      // covers the hand-off and the winner tile renders frameless
      // (RolldropTile frame=false), so no golden frame ever shows.
      bonusLeftRef.current = rdHitsRef.current.filter(Boolean).length;
      // USER SPEC (R40): the hit itself is the deadline — from THIS moment no
      // looping layer may exist (the main whoosh already died at the glide;
      // this is the unconditional guarantee the user asked for).
      sfx.killLoops();
      rdBonusStartRef.current = new Array(count).fill(null);
      for (let i = 0; i < count; i++) {
        if (!rdHitsRef.current[i]) continue;
        // server rolls carry the bonus pull in the response; locals draw it here
        const bonusProof = serverBonusRef.current[i] ?? st.drawCase(rareCaseOf(caseDef));
        // park the bonus-spin starter — the marker beat fires it (RD_BEAT_MS)
        rdBonusStartRef.current[i] = () => startBonusSpin(i, bonusProof);
        sfx.win(true);
        rdBeatTimersRef.current.push(
          window.setTimeout(() => {
            const start = rdBonusStartRef.current[i];
            rdBonusStartRef.current[i] = null;
            start?.();
          }, RD_BEAT_MS)
        );
      }
      // NO auto-reset: the board stays open on the final result — the "Open Again"
      // controls below take the next spin straight from here.
    },
    [caseDef, count, quick, vertical, item, gap, claimWin]
  );

  /** The shared spin pipeline — local and server rolls both land here.
   *  pfList/rdHits come either from the provably-fair local draw or from
   *  /api/open; for server rolls the price moved at the click while the win
   *  is parked until the reveal (claimWin) — Task 78. */
  const beginRound = useCallback(
    (pfList: RollProof[], rdHits: boolean[]) => {
    // PERF (Task 100): winners' images decode while the lid + fill phase play
    preheatSkins(pfList.map((pf) => pf.skin.id));
    // battle-pass XP for the whole purchase (USER SPEC: no reward, no
    // level-up toast — the level is DB state the TopBar reads back)
    grantXp(caseXp(caseDef) * count);

    setProofs(pfList);
    rdHitsRef.current = rdHits;
    // Task 149: a fresh round clears any pending marker-beat timers (a stale
    // beat must NEVER fire a bonus spin into the new round)
    rdBeatTimersRef.current.forEach((t) => window.clearTimeout(t));
    rdBeatTimersRef.current = [];
    // USER SPEC: a ROLLDROP round shows its TOTAL WON only after the bonus
    // sequence finishes — arm the suppression here, release it on the last spin
    setRdActive(rdHits.some(Boolean));
    // USER SPEC (Task 81/82-fix — EDGING): each reel of this round draws its
    // own SIGNED stop offset — mostly the reel crosses the boundary from the
    // PREVIOUS skin and stops inside the winner's zone (sometimes barely over
    // it), sometimes it drifts a touch past center. The snap then carries the
    // winner to the exact center — the NEXT skin is never "arrived at".
    edgingRef.current = pfList.map(() => edgingRoll());

    const pool = caseDef.items.map((i) => i.skinId);

    /** Live tile stride measured off the dealt strip — survives viewport
     *  resizes between render and spin (tiles re-render on phase flips, the
     *  spin closure would otherwise keep the stale size and miss the marker). */
    const liveStride = () => {
      const s = stripRefs.current[0];
      const t0 = s?.children[0] as HTMLElement | undefined;
      const t1 = s?.children[1] as HTMLElement | undefined;
      if (!t0 || !t1) return { item, gap };
      const r0 = t0.getBoundingClientRect();
      const r1 = t1.getBoundingClientRect();
      return vertical
        ? { item: Math.round(r0.height), gap: Math.round(r1.top - r0.bottom) }
        : { item: Math.round(r0.width), gap: Math.round(r1.left - r0.right) };
    };

    /** Winner-tile offsets for the EDGING stop (Task 81/82-fix): per reel —
     *  total = dead-center target + the reel's SIGNED glide (clamped to the
     *  winner's own tile by edgingGlidePx); edge = that glide distance alone
     *  (the snap unwinds ONLY it — negative glides unwind FORWARD). */
    const computeTargets = () => {
      const { item: it, gap: gp } = liveStride();
      const edgePx = (i: number) => edgingGlidePx(edgingRef.current[i] ?? 0, it);
      if (vertical) {
        const colH = reelRefs.current[0]?.clientHeight ?? 400;
        const totals = pfList.map((_, i) => winIdx * (it + gp) + it / 2 - colH / 2 + edgePx(i));
        return { totals, edges: pfList.map((_, i) => edgePx(i)) };
      }
      const containerW = reelsWrapRef.current?.clientWidth ?? 700;
      const totals = pfList.map((_, i) => winIdx * (it + gp) + it / 2 - containerW / 2 + edgePx(i));
      return { totals, edges: pfList.map((_, i) => edgePx(i)) };
    };

    /** Write the raw pixel offset to every strip (X on the horizontal reel, Y
     *  on vertical columns). pos = aCrawl*(center+glide) − aSettle*glide —
     *  the glide unwinds per reel, so every winner ARRIVES at its own center. */
    const applyTargets = (targets: number[], edges: number[], aCrawl: number, aSettle: number) => {
      for (let i = 0; i < targets.length; i++) {
        const el = stripRefs.current[i];
        if (!el) continue;
        const pos = aCrawl * targets[i] - aSettle * edges[i];
        el.style.transform = vertical
          ? `translate3d(0, ${-pos}px, 0)`
          : `translate3d(${-pos}px, 0, 0)`;
      }
    };

    // build strips: random fill, winner injected at winIdx (the raredrop
    // marker tile when that reel hit the ROLLDROP).
    // USER SPEC (Task 79): the raredrop art ALWAYS rides the reel — every
    // non-hit strip weaves ONE marker tile into the final run-up before the
    // stop, so the player watches it pass the center line among the skins
    // even when the round is NOT a ROLLDROP. Pure decoration: the reel never
    // stops on it (rdIdx < winIdx), odds and the provably-fair draw are
    // untouched, and a hit reel skips the decoy (its WINNER tile is the art).
    const newStrips = pfList.map((pf, fi) => {
      const rdLo = Math.max(1, winIdx - 12);
      const rdHi = winIdx - 3;
      const rdIdx =
        rdHits[fi] || rdHi < rdLo ? -1 : rdLo + Math.floor(Math.random() * (rdHi - rdLo + 1));
      return Array.from({ length: stripLen }, (_, i) => ({
        key: i,
        skinId:
          i === winIdx
            ? rdHits[fi]
              ? ROLLDROP_MARKER
              : pf.skin.id
            : i === rdIdx
              ? ROLLDROP_MARKER
              : pool[Math.floor(Math.random() * pool.length)],
        isWinner: i === winIdx,
        wearId: i === winIdx && !rdHits[fi] ? wearIdFromLabel(pf.skin.wear) : undefined,
      }));
    });
    setStrips(newStrips);
    // park the strip back at its start so a re-deal plays in view — no-op on a fresh board
    parkStripEls(stripRefs.current);
    setLockFx(false);
    setFlashReels([]);
    setShake(false);
    lastTickRef.current = -1;
    lastTickAtRef.current = 0;

    const finish = () => {
      doRevealAll(
        pfList.map((pf) => ({
          uid: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          skin: pf.skin,
          nonce: pf.nonce,
        }))
      );
    };

    // ---- the spin itself (runs after the skins are dealt onto the reel) ----
    // USER SPEC (Task 42): FAST MODE never skips the animation — the exact
    // same spin plays at super speed (short duration, same easing + FX)
    const beginSpin = (spinMs: number) => {
      sfx.spinStart();
      setPhase("spinning");
      // PERF (Task 101): tell the corridor background to drop to 30fps —
      // the reels own the frame budget for the next few seconds
      window.dispatchEvent(new Event("rb-spin-active"));

      // USER SPEC (Task 82-fix + Task 176): the dramatic-stop timeline — the
      // reel CRAWLS its last tiles (power-4 ease, Task 176: closes faster)
      // past the previous skin and into the winner's zone (the stop is always
      // INSIDE the winner's tile), then SNAPS fast (forward for under-hangs,
      // back for tiny over-hangs) so the winner ARRIVES at the marker. Lock
      // FX + reveal wait for that arrival.
      const { holdMs, settleMs } = edgingPhases(spinMs, { hold: false });
      const t0 = performance.now();
      let lastPos = 0;
      let lastT = 0;
      let beatKilled = false;
      const step = (t: number) => {
        const el = t - t0;
        // re-measure the stride + viewport every frame — a resize between render
        // and even mid-spin must never knock the winner off the marker
        const { totals, edges } = computeTargets();
        const c = edgingClock(el, spinMs, holdMs, settleMs, CRAWL_POW);
        const pos0 = c.aCrawl * totals[0] - c.aSettle * edges[0];
        // numeric velocity (px/s) → whoosh / streaks; silent on the beat
        const dt = lastT ? Math.max(1, t - lastT) : 16;
        const vNorm = Math.min(1, Math.abs(pos0 - lastPos) / dt / ((CRAWL_POW * totals[0]) / (spinMs / 1000)));
        lastPos = pos0;
        lastT = t;

        // drive every reel's transform directly — no per-frame React renders
        applyTargets(totals, edges, c.aCrawl, c.aSettle);
        if (streaksRef.current) {
          streaksRef.current.style.opacity = (vNorm * 0.9).toFixed(2);
          // PERF (Task 101): the streak layer runs ONLY while it is visible
          if (streaksRef.current.style.animationPlayState !== "running")
            streaksRef.current.style.animationPlayState = "running";
        }
        if (c.phase === "spin") sfx.spinEnergy(vNorm);
        else if (!beatKilled) {
          // the reel reached the glide point — the whoosh dies into stillness
          beatKilled = true;
          sfx.spinEnd();
        }

        const now = performance.now();
        if (c.phase === "spin") {
          // ratchet ticks — one per item passing the marker (forward spin only;
          // the short snap glides silently into the lock)
          const { item: it, gap: gp } = liveStride();
          const idx = Math.floor(pos0 / (it + gp));
          if (idx !== lastTickRef.current && now - lastTickAtRef.current > 18) {
            lastTickRef.current = idx;
            lastTickAtRef.current = now;
            sfx.tick(vNorm);
          }
        }

        if (c.phase === "done") {
          // the winner ARRIVED at the marker — now the heavy lock + reveal.
          // USER SPEC (Task 104b): the LOCKING IN stage is GONE — the spin
          // flows straight into the lock flash + the reveal, no extra beat.
          window.dispatchEvent(new Event("rb-spin-done"));
          if (streaksRef.current) {
            streaksRef.current.style.opacity = "0";
            streaksRef.current.style.animationPlayState = "paused";
          }
          sfx.lock();
          setLockFx(true);
          // gold lock flash for rare pulls (≤10% odds). Task 146 (USER SPEC):
          // ROLLDROP hits SKIP it — the impact cutscene arms 200ms later and
          // the flash read as one more golden beat around the video.
          setFlashReels(pfList.map((pf, fi) => !rdHits[fi] && oddsPct(caseDef, pf.skin.id) <= 10));
          setShake(true);
          window.setTimeout(() => setShake(false), 500);
          // one short frame-beat for the lock flash, then the reveal mounts
          window.setTimeout(finish, 200);
          return;
        }
        rafRef.current = requestAnimationFrame(step);
      };
      rafRef.current = requestAnimationFrame(step);
    };

    // ---- cinematic start: the on-deck crate flips its lid open, then skins are dealt ----
    sfx.caseOpen();
    setPhase("opening");
    openTimeoutRef.current = window.setTimeout(() => {
      setPhase("filling");
      setFillCount(0);
      lastFillTickRef.current = -1;
      const fillT0 = performance.now();
      const fillStep = (t: number) => {
        const elapsed = t - fillT0;
        // PERF (Task 100): the visible 8 tiles deal one-by-one; the hidden
        // run-up then mounts in small per-frame batches instead of one commit
        const n =
          elapsed <= FILL_VIS * FILL_MS
            ? Math.min(FILL_VIS, Math.floor(elapsed / FILL_MS) + 1)
            : Math.min(
                stripLen,
                FILL_VIS +
                  Math.floor((elapsed - FILL_VIS * FILL_MS) / FILL_TRICKLE_EVERY) *
                    FILL_TRICKLE_BATCH,
              );
        setFillCount(n);
        if (n % 2 === 0 && n <= FILL_VIS && n !== lastFillTickRef.current) {
          lastFillTickRef.current = n;
          sfx.tick(0.4);
        }
        if (n < stripLen) {
          fillRafRef.current = requestAnimationFrame(fillStep);
        } else {
          // reel fully dealt — one short beat, then the spin takes over
          // (FAST MODE: the spin duration itself is super short)
          spinTimeoutRef.current = window.setTimeout(() => beginSpin(quick ? FAST_SPIN_MS : SPIN_MS), 320);
        }
      };
      fillRafRef.current = requestAnimationFrame(fillStep);
    }, 820); // lid collapse + swing + beam burst before the deal takes over
    },
    [caseDef, count, vertical, item, gap, quick, doRevealAll, grantXp, toast]
  );

  const startSpin = useCallback(() => {
    const total = caseDef.price * count;
    // USER SPEC (Task 104): the free DAILY case gates — the level requirement
    // and the case's OWN 24h cooldown (every case up to your level opens daily).
    if (isDailyCase) {
      if (levelLocked) {
        sfx.error();
        toast({
          title: `Reach Level ${requiredLevel} first`,
          description: `This daily case unlocks at Level ${requiredLevel} — you are Level ${myLevel}.`,
          variant: "destructive",
        });
        return;
      }
      if (dailyUsed) {
        sfx.error();
        toast({
          title: "Daily case already opened",
          description: `Your next free open of LEVEL ${requiredLevel} is ready in ${formatCountdown(dailyNextIn)}.`,
          variant: "destructive",
        });
        return;
      }
    }
    // SIGNED-IN players roll on the SERVER: /api/open charges the DATABASE
    // balance and decides the roll at the click, but parks the WIN until the
    // reveal finishes (Task 78) — records every drop to the global LIVE feed
    // at claim time. One coin flow, one truth, nothing revealed early.
    if (me) {
      setPhase("opening");
      sfx.caseOpen();
      void (async () => {
        try {
          const r = await fetch("/api/open", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ caseId: caseDef.id, count }),
          });
          const data = (await r.json()) as {
            pulls?: { skinId: string; wear?: WearId; value: number; rd: boolean; f?: [number, number]; bonus?: { skinId: string; wear?: WearId; value: number } }[];
            credited?: number;
            balance?: number;
            pendingId?: string;
            error?: string;
            nextIn?: number;
            dailyNextIn?: number;
            // USER SPEC (Task 183): free-box consumption + the fresh map
            freeUsed?: number;
            freeCases?: Record<string, number>;
            fair?: { hash: string; clientSeed: string; startNonce: number };
          };
          if (!r.ok || !data.pulls) {
            sfx.error();
            setPhase("idle");
            if (data.error === "Daily case already opened") {
              setServerNextIn(data.nextIn ?? 86_400_000);
              toast({
                title: "Daily case already opened",
                description: `Your next free open is ready in ${formatCountdown(data.nextIn ?? 0)}.`,
                variant: "destructive",
              });
            } else {
              toast({
                title: data.error === "Not enough funds" ? "Not enough funds" : "Could not open the case",
                description:
                  data.error === "Not enough funds"
                    ? "Open your free daily cases every 24h — or sell items from your inventory."
                    : data.error,
                variant: "destructive",
              });
            }
            return;
          }
          // USER SPEC (Task 104): the free daily case consumed — stamp both
          // cooldowns (THIS case only) so the controls flip to the countdown
          // right after the reveal.
          if (isDailyCase) {
            markDailyCaseOpened(caseDef.id);
            setServerNextIn(data.dailyNextIn ?? 86_400_000);
          }
          // Task 78: data.balance is the CHARGED balance (price deducted, win
          // still parked) — the chip updates with the win only at the reveal,
          // when claimWin cashes the pending round.
          if (typeof data.balance === "number") patch({ balance: data.balance });
          // USER SPEC (Task 183): the server just burned the free units — the
          // session's map syncs so the FREE ×N chip drops with the reveal.
          if (data.freeCases) patch({ freeCases: data.freeCases });
          serverRolledRef.current = true;
          pendingIdRef.current = data.pendingId ?? null;
          claimFiredRef.current = false;
          // SERVER PROVABLY FAIR (Task 151): the response now carries the REAL
          // commitment + per-reel floats — the reel's proof chip shows the
          // same numbers the /provably-fair verifier re-derives after the
          // seed reveal. Legacy fallback keeps the old "server-roll" stubs.
          const fair = (data.fair ?? null) as
            | { hash: string; clientSeed: string; startNonce: number }
            | null;
          const reelProof = (p: { f?: [number, number] }, i: number) => ({
            nonce: fair ? fair.startNonce + 2 * i + 1 : i + 1,
            clientSeed: fair?.clientSeed ?? "server-roll",
            serverSeedHash: fair?.hash ?? "server-roll",
            float: p.f?.[1] ?? 0,
          });
          serverBonusRef.current = data.pulls.map((p, i) =>
            p.bonus
              ? { ...reelProof(p, i), skin: skinWithWear(p.bonus.skinId, p.bonus.wear) }
              : null
          );
          beginRound(
            data.pulls.map((p, i) => ({
              ...reelProof(p, i),
              skin: skinWithWear(p.skinId, p.wear),
            })),
            data.pulls.map((p) => p.rd)
          );
        } catch {
          sfx.error();
          setPhase("idle");
          toast({ title: "Could not reach the server", variant: "destructive" });
        }
      })();
      return;
    }
    if (!pay(total, count)) {
      sfx.error();
      toast({
        title: "Not enough funds",
        description:
          count > 1 ? (
            <>
              You need <Coin /> {formatCoins(total)} for x{count}. Open your free daily cases every 24h — or sell inventory items.
            </>
          ) : "Open your free daily cases every 24h — or sell items from your inventory.",
        variant: "destructive",
      });
      return;
    }
    sfx.click();
    // USER SPEC: guests stamp THIS case's 24h daily cooldown at the click (the
    // server does the same for signed-in players inside /api/open).
    if (isDailyCase) markDailyCaseOpened(caseDef.id);

    // provably fair draws — one nonce per reel (LOCAL rolls for signed-out visitors)
    const pfList: RollProof[] = [];
    for (let i = 0; i < count; i++) pfList.push(useCaseStore.getState().drawCase(caseDef));
    const rdHits = pfList.map(() => maybeRollDrop(rolldropChanceOf(caseDef)));
    serverRolledRef.current = false;
    serverBonusRef.current = pfList.map(() => null);
    beginRound(pfList, rdHits);
  }, [caseDef, caseDef.id, count, vertical, item, gap, pay, quick, doRevealAll, grantXp, toast, me, patch, beginRound, isDailyCase, myLevel, requiredLevel, dailyUsed, dailyNextIn, levelLocked, storeDailyOpens, markDailyCaseOpened]);

  if (!caseDef) return null;

  const firstNonce = proofs[0]?.nonce;
  const verifyHref = `/provably-fair?tab=check&case=${caseDef.id}${
    firstNonce ? `&nonce=${firstNonce}&client=${proofs[0].clientSeed}` : ""
  }`;

  return (
    <section
      className="relative mx-auto w-full max-w-[1100px] px-4 pb-6"
      aria-label={`${caseDef.name} unboxing reel`}
    >
      {/* Task 149: the impact clip preloader is GONE with the cutscene itself */}
      {/* aurora blobs — clipped so they never widen the page on phones */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        <div
          className="anim-orb absolute -left-24 -top-16 h-72 w-72 rounded-full opacity-20 blur-3xl"
          style={{ background: `radial-gradient(circle, ${caseDef.tierColor}88, transparent 70%)` }}
        />
        <div
          className="anim-orb absolute -bottom-16 -right-20 h-72 w-72 rounded-full opacity-15 blur-3xl"
          style={{
            background: `radial-gradient(circle, ${caseDef.tierColor2}88, transparent 70%)`,
            animationDelay: "-7s",
          }}
        />
      </div>

      <div className={cn("relative", shake && "anim-modal-shake")}>
        <div className="relative py-2">
          {/* ===== provably fair roll chip ===== */}
          {proofs.length > 0 && (
            <div className="mb-3 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[11px] font-semibold text-white/45">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                {count > 1 ? `Rolls #${firstNonce}–#${proofs[proofs.length - 1].nonce}` : `Roll #${firstNonce}`} •
                Client seed:
                <code className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-white/70">
                  {shortSeed(proofs[0].clientSeed)}
                </code>
              </span>
              <a
                href={verifyHref}
                className="flex items-center gap-1 text-emerald-300 transition-colors hover:text-emerald-200"
              >
                <ExternalLink className="h-3 w-3" />
                Verify this roll
              </a>
            </div>
          )}

          {/* ===== roulette — one reel per open. single = horizontal reel;
               2-5 = side-by-side VERTICAL scrolling columns (user request).
               USER SPEC (Task 133): multi-open is capped at FIVE cases (the
               old 10/15/20 rows-of-five are gone) and the reels FUSE into ONE
               seamless board — no gaps, no borders, no corner notches. ===== */}
          <div
            ref={reelsWrapRef}
            dir="ltr"
            className={cn(
              "relative",
              count > 5
                ? "grid grid-cols-2 items-start gap-0 sm:grid-cols-3 lg:grid-cols-5" // unreachable since the Task-133 cap — kept gap-free for consistency
                : vertical
                  ? "flex items-start justify-center gap-0" // Task 133: NO gap between case reels — one seamless board
                  : "space-y-2"
            )}
          >
            {Array.from({ length: count }, (_, ri) => {
              const strip = strips[ri];
              // how many tiles of this reel have been dealt with real skins
              const filled =
                phase === "filling"
                  ? Math.min(stripLen, Math.max(0, fillCount - ri * 2))
                  : phase === "idle" || phase === "opening"
                    ? 0
                    : stripLen;
              const reelBox = (
                <div
                  key={ri}
                  ref={(el) => {
                    reelRefs.current[ri] = el;
                  }}
                  className={cn(
                    "relative overflow-hidden",
                    // Task 133 (USER SPEC): multi reels lose their border +
                    // rounding so side-by-side cases read as ONE panel; the
                    // single horizontal reel keeps its framed look.
                    vertical ? "" : "rounded-2xl border border-white/10",
                    "bg-[radial-gradient(ellipse_at_center,#160f2b_0%,#0b0716_72%)]",
                    vertical
                      ? count > 5
                        ? "h-[300px] sm:h-[400px]" // rows of five — shorter boards keep all rows on screen
                        : "h-[350px] sm:h-[480px]"
                      : reelHeightClass(count),
                    // Task 149: the lock ring is the STANDARD stop beat again —
                    // the cutscene that used to suppress it is gone
                    lockFx && "ring-1 ring-amber-300/40"
                  )}
                  dir="ltr"
                >
                  {count > 1 && (
                    <span className="absolute left-2 top-1.5 z-20 rounded bg-black/60 px-1.5 py-0.5 font-display text-[9px] font-black tracking-widest text-white/55">
                      REEL {ri + 1}
                    </span>
                  )}
                  {/* center marker — LINE ONLY (hidden while the case is on deck /
                      opening). USER SPEC (Task 134): the pulsing amber diamond that
                      sat at the marker's center is GONE — the strip alone marks the
                      drop line. Battles/jackpot reels keep their own diamonds. */}
                  {phase !== "idle" && phase !== "opening" && strip && (
                    <div
                      className={cn(
                        "absolute z-20",
                        vertical ? "inset-x-0 top-1/2 h-0" : "inset-y-0 left-1/2 -translate-x-1/2"
                      )}
                      aria-hidden="true"
                    >
                      <div
                        className={cn(
                          "absolute from-transparent via-amber-300 to-transparent transition-shadow",
                          vertical
                            ? "inset-x-0 top-0 h-[2px] -translate-y-1/2 bg-gradient-to-r"
                            : "inset-y-0 w-[2px] -translate-x-1/2 bg-gradient-to-b"
                        )}
                      />
                    </div>
                  )}
                  {/* edge fades (orientation-aware) + vignette */}
                  {vertical ? (
                    <>
                      <div className="reel-fade-t pointer-events-none absolute inset-x-0 top-0 z-10 h-12" />
                      <div className="reel-fade-b pointer-events-none absolute inset-x-0 bottom-0 z-10 h-12" />
                    </>
                  ) : (
                    <>
                      <div className="reel-fade-l pointer-events-none absolute inset-y-0 left-0 z-10 w-24" />
                      <div className="reel-fade-r pointer-events-none absolute inset-y-0 right-0 z-10 w-24" />
                    </>
                  )}
                  {/* Task 133 (USER SPEC): the per-reel corner vignette is SKIPPED
                      in multi mode — stacked edge-darkening across side-by-side
                      reels painted a darker band at every seam; the seamless
                      multi board keeps only its flat base gradient. */}
                  {!vertical && (
                    <div
                      className="pointer-events-none absolute inset-0 z-10"
                      style={{
                        background:
                          "radial-gradient(ellipse 62% 130% at 50% 50%, transparent 55%, rgba(0,0,0,0.55) 100%)",
                      }}
                      aria-hidden="true"
                    />
                  )}
                  {/* PERF (Task 101): the per-reel speed-streak layers moved to
                      ONE board-level overlay below — N paint loops → 1, and it
                      only runs while the spin is fast enough to see it */}
                  {/* lock flash — gold, rare pulls only (≤10% odds) */}
                  {lockFx && flashReels[ri] && (
                    <div
                      className="anim-lock-flash pointer-events-none absolute inset-0 z-30"
                      style={{ background: GOLD_FLASH_BG }}
                      aria-hidden="true"
                    />
                  )}
                  {/* Task 149 (USER SPEC): the ROLLDROP impact cutscene is
                      DELETED — a hit reel shows ONLY the frameless raredrop
                      image for RD_BEAT_MS, then the bonus spin fires (the
                      timer lives in doRevealAll). No overlay, no video. */}
                  {/* USER SPEC (Task 67): the ROLLDROP white flash is DELETED —
                      no cover, no overlay; the glow on the raredrop tile and
                      the bonus spin carry the moment by themselves */}
                  {/* Task 96 (USER SPEC): the floating winner chip is GONE from
                      the reel — the final result now shows below the reel as a
                      battle-style reveal card (weapon / name / exterior /
                      NEON-GREEN price), with room for the whole text. */}

                  {phase === "idle" || phase === "opening" || (phase === "revealed" && !strip) ? (
                    /* the case on deck — art centered on the reel, lid flips open when OPEN lands */
                    /* keyed so React remounts (never reuses the strip node + its spin transform) */
                    <div
                      key="on-deck"
                      className="absolute inset-0 z-[5] grid place-items-center"
                      aria-hidden="true"
                    >
                      <div
                        className="anim-aura-breathe pointer-events-none absolute left-1/2 top-1/2 h-32 w-56 rounded-full blur-2xl"
                        style={{
                          background: `radial-gradient(circle, ${caseDef.tierColor}59, transparent 70%)`,
                        }}
                      />
                      <div
                        className="anim-float relative flex flex-col items-center"
                        style={{ "--rot": "3deg" } as React.CSSProperties}
                      >
                        <div
                          className={
                            vertical
                              ? "w-[72%] max-w-[170px]"
                              : count === 1
                                ? "w-40 sm:w-52"
                                : count <= 3
                                  ? "w-28 sm:w-36"
                                  : "w-24 sm:w-28"
                          }
                        >
                          <CaseImage
                            caseId={caseDef.id}
                            alt={caseDef.name}
                            color={caseDef.tierColor}
                            color2={caseDef.tierColor2}
                            /* USER SPEC (Task 177): the player-built case's chosen
                               artwork must ride the REEL too — not only the home
                               screen. Without this the on-deck art fell back to
                               the generic crate on the opening screen. */
                            communityDesign={caseDef.communityDesign}
                            className="w-full"
                            sizes="208px"
                          />
                        </div>
                        {/* USER SPEC (R37): the idle "Press open to deal the
                           loot" caption is DELETED — the line renders only
                           while the case is actually unlocking. */}
                        {phase === "opening" && (
                          <p className="font-display mt-1.5 px-2 text-center text-[9px] font-black uppercase tracking-[0.3em] text-white/35 sm:text-[10px]">
                            {vertical ? "Unlocking" : "Unlocking the goods"}
                          </p>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div
                      key="strip"
                      ref={(el) => {
                        stripRefs.current[ri] = el;
                      }}
                      className={cn(
                        "absolute flex will-change-transform",
                        vertical ? "inset-x-0 top-0 flex-col" : "top-1/2"
                      )}
                      style={{ gap: `${gap}px`, translate: vertical ? "0 0" : "0 -50%" }}
                    >
                      {(strip ?? []).map((it, ti) => {
                        // USER SPEC (Task 106): while a ROLLDROP bonus sequence
                        // runs the board stays "spinning" — winner details stay
                        // HIDDEN until the LAST bonus locks (then phase flips to
                        // revealed and EVERY reel shows its win at once). The
                        // glowing raredrop tile is the only thing allowed to
                        // light up at the main lock (the Task 45/67 hold beat).
                        const stopped =
                          phase === "revealed" ||
                          (lockFx && (!rdActive || it.skinId === ROLLDROP_MARKER));
                        const isWin = stopped && it.isWinner;
                        const isRd = it.skinId === ROLLDROP_MARKER;
                        if (!it.skinId || ti >= filled) return null;
                        // USER SPEC (fix): the ROLLDROP tile REPLACES the winning
                        // skin — the reel stops ON the raredrop art
                        if (isRd) {
                          return (
                            <RolldropTile
                              key={it.key}
                              glow={isWin}
                              /* USER SPEC (Task 145): the STOPPED winner marker is
                                  BARE — no golden border/plate/glow; the cutscene
                                  takes over the moment the reel locks. Scrolling
                                  markers keep the framed strip look. */
                              frame={!isWin}
                              winner={isWin}
                              className={cn(
                                // PERF (Task 100): off-window tiles skip layout+paint
                                "reel-tile shrink-0",
                                ti < FILL_VIS && "anim-pop-in",
                                // Task 97: SQUARE tile in every mode — fluid side
                                // (the column/cell width, capped), never a portrait
                                vertical && "mx-auto aspect-square w-full max-w-[280px]"
                              )}
                              artClassName="h-[58%]"
                              style={vertical ? undefined : { width: item, height: item }}
                            />
                          );
                        }
                        // Task 97 (USER SPEC): the tiles are TRANSPARENT squares
                        // (SkinTile bare) and the winner's details — weapon / name /
                        // exterior / NEON-GREEN price — render ON the winning square
                        // once the reel locks, with room for the whole text.
                        const winWs =
                          isWin && SKINS[it.skinId] ? skinWithWear(it.skinId, it.wearId) : null;
                        return (
                          <SkinTile
                            key={it.key}
                            skinId={it.skinId}
                            bare
                            compact
                            artShadow={isWin}
                            className={cn(
                              // PERF (Task 100): off-window tiles skip layout+paint
                              "reel-tile shrink-0",
                              // PERF (Task 100): pop-in only on the tiles the player
                              // actually watches being dealt — hundreds of simultaneous
                              // mount animations fed the pre-spin stall
                              ti < FILL_VIS && "anim-pop-in",
                              vertical && "mx-auto aspect-square w-full max-w-[280px]"
                            )}
                            artClassName={vertical ? "h-[58%]" : "h-[62%]"}
                            style={vertical ? undefined : { width: item, height: item }}
                          >
                            {winWs && (
                              <div className="absolute inset-x-0 bottom-0 z-20 px-1.5 pb-1.5">
                                <WinDetails ws={winWs} />
                              </div>
                            )}
                          </SkinTile>
                        );
                      })}
                    </div>
                  )}
                </div>
              );

              // Task 97: the winner text lives ON the square INSIDE the reel —
              // no caption block under the columns anymore
              if (vertical) {
                return (
                  <div
                    key={ri}
                    className={cn(
                      "flex min-w-0 flex-col",
                      count > 5 ? "" : "flex-1 max-w-[420px]" // grid cells size themselves in rows-of-5 mode
                    )}
                  >
                    {reelBox}
                  </div>
                );
              }
              return reelBox;
            })}

            {/* PERF (Task 101): ONE board-level streak layer (was one per reel —
                N background-position paint loops even while invisible). JS sets
                its opacity with the reel velocity; the CSS animation runs ONLY
                while the spin is fast (animationPlayState). */}
            <div
              ref={streaksRef}
              className={cn(
                "pointer-events-none absolute inset-0 z-10 opacity-0",
                vertical ? "reel-streaks-v" : "reel-streaks"
              )}
              style={{ animationPlayState: "paused" }}
              aria-hidden="true"
            />
          </div>

          {/* ===== Task 97/98 (USER SPEC): end-of-round TOTAL — how much the
               case (or all cases together in multi mode) paid out. Task 98:
               SOLID GOLD — the neon-green + dim label read as transparent. ===== */}
          {phase === "revealed" && totalWon > 0 && (
            <div className="anim-pop-in mt-4 flex flex-col items-center gap-0.5">
              <p className="text-xs font-black uppercase tracking-[0.3em]" style={{ color: GOLD }}>
                Total won
              </p>
              <p
                className="font-display flex items-center gap-2 text-2xl font-black sm:text-3xl"
                style={{ color: GOLD, textShadow: GLOW_GOLD }}
              >
                <Coin /> {formatCoins(totalWon)}
              </p>
            </div>
          )}

          {/* ===== controls — also shown AFTER the reveal so the board never resets:
               the result stays on screen and "Open Again" spins from here ===== */}
          {(phase === "idle" || phase === "revealed") && (
            <div className={cn("flex flex-col items-center gap-3", phase === "revealed" ? "mt-4" : "mt-5")}>
              {/* USER SPEC: the free DAILY cases always open ONE at a time —
                  no Multi row. Every other case keeps the full Multi picker. */}
              {!isDailyCase && (
              <div
                className="flex flex-wrap items-center justify-center gap-[5px]"
                role="group"
                aria-label="Multi-open: how many cases to open at once"
              >
                <span className="mr-1.5 text-[10px] font-black uppercase tracking-wider text-white/40">
                  Multi
                </span>
                {/* USER SPEC (Task 133): max FIVE cases per multi-open — the old
                    x10 / x15 / x20 buttons are gone (user request) */}
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    onClick={() => {
                      setCount(n);
                      sfx.click();
                    }}
                    aria-pressed={count === n}
                    className={cn(
                      "font-display h-8 min-w-10 rounded-lg border px-1.5 text-xs font-black transition-all",
                      count === n
                        ? "gold-btn border-amber-300 text-black shadow-[0_0_16px_rgba(240,185,11,0.5)]"
                        : "border-violet-400/40 bg-[#3a0f47] text-white/80 hover:border-violet-300/70 hover:bg-[#4a1460] hover:text-white"
                    )}
                  >
                    x{n}
                  </button>
                ))}
              </div>
              )}
              {isDailyCase ? (
                levelLocked ? (
                  <button
                    type="button"
                    disabled
                    className="flex cursor-not-allowed items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-12 py-4 text-lg font-black text-white/45"
                  >
                    <Lock className="h-5 w-5" />
                    Unlocks at Level {requiredLevel}
                  </button>
                ) : dailyUsed ? (
                  <button
                    type="button"
                    disabled
                    className="flex cursor-not-allowed items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-12 py-4 text-lg font-black text-white/60"
                  >
                    <Clock className="h-5 w-5 text-amber-300" />
                    Next free case in {formatCountdown(dailyNextIn)}
                  </button>
                ) : (
                  <button
                    onClick={startSpin}
                    className="neon-btn flex items-center gap-2 rounded-xl px-12 py-4 text-xl font-black text-white"
                  >
                    <Sparkles className="h-5 w-5" fill="currentColor" />
                    Open Case • FREE
                  </button>
                )
              ) : (
              <button
                onClick={startSpin}
                className="neon-btn flex items-center gap-2 rounded-xl px-12 py-4 text-xl font-black text-white"
              >
                <Sparkles className="h-5 w-5" fill="currentColor" />
                {me && freeHave > 0 ? (
                  /* USER SPEC (Task 183): free boxes cover this round */
                  freeHave >= count ? (
                    <>
                      {phase === "revealed" ? "Open Again" : count > 1 ? `Open x${count}` : "Open Case"} • FREE
                    </>
                  ) : (
                    <>
                      Open x{count} • {freeHave} FREE + <Coin /> {formatCoins(caseDef.price * (count - freeHave))}
                    </>
                  )
                ) : phase === "revealed" ? (
                  count > 1 ? (
                    <>
                      Open Again x{count} • <Coin /> {formatCoins(caseDef.price * count)}
                    </>
                  ) : (
                    <>
                      Open Again • <Coin /> {formatCoins(caseDef.price)}
                    </>
                  )
                ) : count > 1 ? (
                  <>
                    Open x{count} • <Coin /> {formatCoins(caseDef.price * count)}
                  </>
                ) : (
                  <>
                    Open Case • <Coin /> {formatCoins(caseDef.price)}
                  </>
                )}
              </button>
              )}
              {isDailyCase && !levelLocked && !dailyUsed && (
                <p className="text-xs font-semibold text-white/45">
                  One free open every 24 hours — every daily case up to your level, each with its own timer.
                </p>
              )}
              {count > 1 && (
                <p className="text-xs font-semibold text-white/45">
                  {count} cases at once — {count} independent provably-fair rolls, wins credited as coins instantly.
                </p>
              )}
              <label className="flex cursor-pointer items-center gap-2 text-sm font-semibold text-white/60 hover:text-white/80">
                <input
                  type="checkbox"
                  checked={quick}
                  onChange={(e) => setQuick(e.target.checked)}
                  className="h-4 w-4 accent-fuchsia-500"
                />
                <Gauge className="h-4 w-4" />
                Fast mode — super fast scroll
              </label>
            </div>
          )}

          {(phase === "filling" || phase === "spinning") && (
            <div className="mt-5 text-center">
              <p className="font-display flex items-center justify-center gap-2 text-sm font-black tracking-[0.3em] text-violet-300">
                <Zap className="h-4 w-4 animate-pulse" fill="currentColor" />
                {phase === "filling" ? "DEALING SKINS" : "SPINNING"}...
              </p>
              <p className="mt-1 text-xs text-white/40">
                {phase === "filling"
                  ? count > 1
                    ? `Dealing the goods onto ${count} reels...`
                    : "Dealing the goods onto the reel..."
                  : `The roulette${count > 1 ? "s are" : " is"} slowing down...`}
              </p>
            </div>
          )}

          {/* USER SPEC (Task 88): the idle "Possible contents:" skin strip is
              gone — the odds grid further down the page ("Skins in this case")
              is the one and only contents display. */}
        </div>
      </div>
    </section>
  );
}
