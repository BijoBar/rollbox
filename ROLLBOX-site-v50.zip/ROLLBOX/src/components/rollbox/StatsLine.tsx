"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { CountUp } from "./CountUp";
import { Coin } from "./Coin";
import { DiscordIcon } from "./DiscordIcon";
import { DISCORD_INVITE } from "@/lib/site";
import { sfx } from "@/lib/sound";

/**
 * USER SPEC (Task 32 + 33): the site stats strip — USERS / CASES OPENED /
 * TOTAL WINS / UPGRADES / CASES / BATTLES — sits ABOVE the main header (the
 * TopBar with all the games), the very first thing on every page, same size
 * as before, with the T.O.S / P.F / Discord buttons on its RIGHT side
 * (moved there from the header in Task 33). All numbers are 100%
 * DATABASE-truth (Task 55), refreshed every 30s; upgrades + battlesPlayed
 * are persisted Counters bumped in real time by the gameplay paths, cases is
 * the live catalog count.
 */
export function StatsLine() {
  const [stats, setStats] = useState({
    members: 0,
    casesOpened: 0,
    coinsPaid: 0,
    upgrades: 0,
    battlesPlayed: 0,
    cases: 0,
  });

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const r = await fetch("/api/stats", { cache: "no-store" });
        const d = (await r.json()) as {
          members?: number;
          casesOpened?: number;
          coinsPaid?: number;
          upgrades?: number;
          battlesPlayed?: number;
          cases?: number;
        };
        if (alive) {
          setStats({
            members: d.members ?? 0,
            casesOpened: d.casesOpened ?? 0,
            coinsPaid: d.coinsPaid ?? 0,
            upgrades: d.upgrades ?? 0,
            battlesPlayed: d.battlesPlayed ?? 0,
            cases: d.cases ?? 0,
          });
        }
      } catch {
        /* keep the last known values */
      }
    };
    void load();
    const t = window.setInterval(load, 30_000);
    return () => {
      alive = false;
      window.clearInterval(t);
    };
  }, []);

  return (
    <section aria-label="Site statistics" className="border-b border-white/10 bg-[#0d0819]/60">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-2">
        <p className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs font-semibold" dir="ltr">
          <span className="text-white/45">
            Users :{" "}
            <span className="font-display font-black text-violet-300 tabular-nums">
              <CountUp to={stats.members} />
            </span>
          </span>
          <span className="text-white/20" aria-hidden="true">
            |
          </span>
          <span className="text-white/45">
            Cases opened :{" "}
            <span className="font-display font-black text-fuchsia-300 tabular-nums">
              <CountUp to={stats.casesOpened} />
            </span>
          </span>
          <span className="text-white/20" aria-hidden="true">
            |
          </span>
          <span className="text-white/45">
            Total Wins :{" "}
            <span className="font-display inline-flex items-center font-black text-amber-300 tabular-nums">
              <Coin className="mr-1 h-3 w-3 align-[-0.08em]" />
              <CountUp to={stats.coinsPaid} />
            </span>
          </span>
          <span className="text-white/20" aria-hidden="true">
            |
          </span>
          <span className="text-white/45">
            Upgrades :{" "}
            <span className="font-display font-black text-emerald-300 tabular-nums">
              <CountUp to={stats.upgrades} />
            </span>
          </span>
          <span className="text-white/20" aria-hidden="true">
            |
          </span>
          <span className="text-white/45">
            Cases :{" "}
            <span className="font-display font-black text-sky-300 tabular-nums">
              <CountUp to={stats.cases} />
            </span>
          </span>
          <span className="text-white/20" aria-hidden="true">
            |
          </span>
          <span className="text-white/45">
            Battles :{" "}
            <span className="font-display font-black text-rose-300 tabular-nums">
              <CountUp to={stats.battlesPlayed} />
            </span>
          </span>
        </p>

        {/* USER SPEC (Task 33): T.O.S + P.F + Discord moved here from the
            header — pinned to the RIGHT side of the strip on every page */}
        <div className="flex shrink-0 items-center gap-1">
          <Link
            href="/tos"
            aria-label="Terms of Service"
            title="Terms of Service"
            className="rounded-md px-1.5 py-1 font-display text-[10px] font-black tracking-widest text-white/50 transition-colors hover:text-white sm:px-2"
            onClick={() => sfx.click()}
          >
            T.O.S
          </Link>
          <Link
            href="/provably-fair"
            aria-label="Provably Fair"
            title="Provably Fair"
            className="rounded-md px-1.5 py-1 font-display text-[10px] font-black tracking-widest text-white/50 transition-colors hover:text-white sm:px-2"
            onClick={() => sfx.click()}
          >
            P.F
          </Link>
          <a
            href={DISCORD_INVITE}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Join our Discord server"
            title="Join our Discord"
            className="grid h-7 w-7 place-items-center rounded-md text-white/70 transition-colors hover:text-[#8ea1ff]"
            onClick={() => sfx.click()}
          >
            <DiscordIcon className="h-4.5 w-4.5" />
          </a>
        </div>
      </div>
    </section>
  );
}
