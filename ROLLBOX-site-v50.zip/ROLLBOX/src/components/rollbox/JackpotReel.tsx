"use client";

import { useEffect, useRef, useState } from "react";
import { sfx } from "@/lib/sound";
import { cn, edgingClock, edgingGlidePx, edgingPhases, edgingRoll } from "@/lib/utils";

const REEL_LEN = 30;
const REEL_WINNER = 24;

/** One slot in the JACKPOT draw — a player with their win odds (%). */
export interface JackpotParticipant {
  key: string;
  name: string;
  color: string;
  img?: string;
  tag?: string;
  /** normalized win odds, 0-100 */
  pct: number;
}

function reelDims() {
  const mobile = typeof window !== "undefined" && window.innerWidth < 640;
  return { item: mobile ? 112 : 144, gap: 8 };
}

/**
 * USER SPEC (Task 42): the JACKPOT draw — like the decider battle reel, but
 * the strip is FILLED BY THE ODDS (each cell is drawn weighted by the
 * participant's win %), every cell carries the player's picture with their
 * win range printed on it, and the marker lands on the pre-drawn winner.
 * Remount per draw via `key` to build a fresh strip.
 */
export function JackpotReel({
  participants,
  winnerKey,
  duration,
  onDone,
}: {
  participants: JackpotParticipant[];
  winnerKey: string;
  duration: number;
  onDone: () => void;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const stripRef = useRef<HTMLDivElement>(null);
  const streaksRef = useRef<HTMLDivElement>(null);
  const [locked, setLocked] = useState(false);
  const [tension, setTension] = useState(false);
  const tensionRef = useRef(false);
  const onDoneRef = useRef(onDone);
  useEffect(() => {
    onDoneRef.current = onDone;
  }, [onDone]);

  // USER SPEC (Task 81/82-fix — EDGING): the jackpot draw never stops
  // dead-center — it draws its own SIGNED stop offset
  // (lib/utils.edgingRoll), clamped INSIDE the winner's tile.
  const [edging] = useState(() => edgingRoll());

  // strip is built once at mount — cells are drawn BY WEIGHT so the reel
  // itself visually breathes the odds (big-odds players fill more of it)
  const [strip] = useState<JackpotParticipant[]>(() => {
    const sum = participants.reduce((s, p) => s + Math.max(p.pct, 0.0001), 0);
    const weighted = (): JackpotParticipant => {
      let r = Math.random() * sum;
      for (const p of participants) {
        r -= Math.max(p.pct, 0.0001);
        if (r <= 0) return p;
      }
      return participants[participants.length - 1];
    };
    const winner = participants.find((p) => p.key === winnerKey) ?? participants[0];
    return Array.from({ length: REEL_LEN }, (_, i) => (i === REEL_WINNER ? winner : weighted()));
  });

  useEffect(() => {
    const { item, gap } = reelDims();
    const containerW = wrapRef.current?.clientWidth ?? 640;
    // USER SPEC (Task 81/82-fix — EDGING): the jackpot draw CRAWLS past the
    // previous tile into the winner's zone (BOUNDARY RULE — the stop is
    // always inside the winner's own tile), holds a short beat, then SNAPS
    // fast so the winner ARRIVES at the marker (lock only after the arrival)
    const edgePx = edgingGlidePx(edging, item);
    const baseX = REEL_WINNER * (item + gap) + item / 2 - containerW / 2;
    const targetX = baseX + edgePx;
    const { holdMs, settleMs } = edgingPhases(duration);
    const t0 = performance.now();
    let raf = 0;
    let holdTimer = 0;
    let lastTick = -1;
    let lastTickAt = 0;
    let lastPos = 0;
    let lastT = 0;

    const step = (t: number) => {
      const c = edgingClock(t - t0, duration, holdMs, settleMs);
      const pos = c.aCrawl * targetX - c.aSettle * edgePx;
      const dt = lastT ? Math.max(1, t - lastT) : 16;
      const vNorm = Math.min(1, Math.abs(pos - lastPos) / dt / ((6 * targetX) / (duration / 1000)));
      lastPos = pos;
      lastT = t;

      if (stripRef.current) {
        stripRef.current.style.transform = `translate3d(${-pos}px, 0, 0)`;
      }
      if (streaksRef.current) streaksRef.current.style.opacity = (vNorm * 0.75).toFixed(2);

      const now = performance.now();
      if (c.phase === "spin") {
        const idx = Math.floor(pos / (item + gap));
        if (idx !== lastTick && now - lastTickAt > 18) {
          lastTick = idx;
          lastTickAt = now;
          sfx.tick(vNorm);
        }
        if (c.p > 0.84 && !tensionRef.current) {
          tensionRef.current = true;
          setTension(true);
        }
      }

      if (c.phase === "done") {
        if (streaksRef.current) streaksRef.current.style.opacity = "0";
        sfx.lock();
        setLocked(true);
        holdTimer = window.setTimeout(() => onDoneRef.current(), 1400);
        return;
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(holdTimer);
    };
  }, [duration]);

  const { item } = reelDims();
  const winnerCell = locked && strip[REEL_WINNER];

  return (
    <div
      ref={wrapRef}
      className={cn(
        "relative overflow-hidden rounded-xl border border-white/10 py-3",
        "bg-[radial-gradient(ellipse_at_center,#1a0f2b_0%,#0b0716_72%)]",
        locked && "ring-1 ring-amber-300/40"
      )}
      dir="ltr"
    >
      {/* center marker — vertical LINE only (Task 135: diamond removed) */}
      <div className="absolute inset-y-0 left-1/2 z-20 w-0" aria-hidden="true">
        <div
          className={cn(
            "absolute inset-y-0 left-0 w-[2px] -translate-x-1/2 bg-gradient-to-b from-transparent via-amber-300 to-transparent transition-shadow",
            tension && "shadow-[0_0_22px_rgba(240,185,11,1)]"
          )}
        />
      </div>
      <div className="reel-fade-l pointer-events-none absolute inset-y-0 left-0 z-10 w-9" aria-hidden="true" />
      <div className="reel-fade-r pointer-events-none absolute inset-y-0 right-0 z-10 w-9" aria-hidden="true" />
      <div ref={streaksRef} className="reel-streaks pointer-events-none absolute inset-0 z-10 opacity-0" aria-hidden="true" />

      <div
        ref={stripRef}
        className="flex w-max will-change-transform"
        style={{ gap: `${reelDims().gap}px`, paddingLeft: 8, paddingRight: 8 }}
      >
        {strip.map((cell, i) => {
          const isWin = locked && i === REEL_WINNER;
          return (
            <div
              key={i}
              className={cn(
                "grid shrink-0 place-items-center gap-1 rounded-xl border-2 p-2 transition-shadow",
                isWin && "anim-glow-pulse"
              )}
              style={{
                width: item,
                height: item,
                borderColor: isWin ? "#f0b90b" : cell.color,
                background: `linear-gradient(160deg, ${cell.color}26, ${cell.color}0d)`,
                ...(isWin ? { boxShadow: "0 0 26px rgba(240,185,11,0.55)" } : {}),
              }}
            >
              {cell.img ? (
                <img src={cell.img} alt={cell.name} className="h-3/4 w-auto object-contain" draggable={false} />
              ) : (
                <span
                  className="font-display grid h-9 w-9 place-items-center rounded-full border-2 text-[11px] font-black text-white sm:h-11 sm:w-11 sm:text-xs"
                  style={{ borderColor: cell.color, background: `${cell.color}2e` }}
                >
                  {cell.name.replace(/[^a-zA-Z0-9]/g, "").slice(0, 2).toUpperCase()}
                </span>
              )}
              <span className="max-w-full truncate text-[10px] font-black tracking-wide text-white sm:text-[11px]" title={cell.name}>
                {cell.name}
              </span>
              {/* USER SPEC: every player rides with his win range on the reel */}
              <span
                className="font-display rounded bg-black/45 px-1 text-[8px] font-black uppercase tracking-widest text-amber-300 sm:text-[9px]"
                aria-label={`Win chance ${cell.pct.toFixed(1)} percent`}
              >
                {cell.pct >= 10 ? cell.pct.toFixed(0) : cell.pct.toFixed(1)}%
              </span>
              {cell.tag && (
                <span className="rounded bg-white/10 px-1 text-[8px] font-black uppercase tracking-widest text-white/70">
                  {cell.tag}
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* winner banner under the reel */}
      {winnerCell && (
        <div className="pointer-events-none absolute inset-x-0 bottom-1.5 text-center">
          <span className="font-display rounded-md bg-amber-400 px-2 py-0.5 text-[10px] font-black uppercase tracking-widest text-black">
            {winnerCell.name} wins the jackpot
          </span>
        </div>
      )}
    </div>
  );
}
