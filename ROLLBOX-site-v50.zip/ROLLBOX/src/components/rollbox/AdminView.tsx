"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Ban, Check, Coins, Gift, HeartHandshake, KeyRound, LifeBuoy, Lock, Megaphone, Search, Shield, ShieldOff, Users, Wallet, Zap } from "lucide-react";
import { useRealtimeEvent } from "@/lib/realtime";
import { SupportCaseAlert, SupportInbox } from "./SupportInbox";
import { AdminWalletTab } from "./AdminWalletTab";
import { AdminSecurityTab } from "./AdminSecurityTab";
import { AdminGiveawaysTab } from "./AdminGiveawaysTab";
import { AdminToolsTab } from "./AdminToolsTab";
import { CASES, formatCoins } from "@/lib/cases";
import { levelTier } from "@/lib/progress";
import { useSession } from "@/lib/session";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";

/* ===== USER SPEC (Task 22): the ADMIN PANEL =====
   A special panel ONLY for players the DATABASE marks isAdmin. The list shows
   every player — photo, name and SITE id side by side — with a search that
   matches THE SITE ID ONLY. Clicking a player opens an ON-SCREEN overlay
   (never a new page) with ALL of their details and the admin powers:
     • change the battle-pass level
     • ADD money (the server refuses any subtraction — balances can only grow)
     • grant a GIFT / COMPENSATION / BONUS
     • a PERMANENT ban button — no unban, banned means gone. */

interface AdminPlayer {
  id: string;
  name: string;
  avatar: string | null;
  balance: number;
  level: number;
  xp: number;
  casesOpened: number;
  battlesWon: number;
  isAdmin: boolean;
  bannedAt: string | null;
  createdAt: string;
  lastSeenAt: string;
  email: string | null;
  tradeLink: string | null;
  refCode: string | null;
  referredBy: string | null;
  // USER SPEC (Task 183): the player's gifted free boxes {caseId: qty}
  freeCases: Record<string, number>;
}

/** USER SPEC (Task 23): the overlay shows the player's recent battles. */
interface AdminBattle {
  code: string;
  type: string;
  mode: string;
  result: "W" | "L";
  entry: number;
  take: number;
  net: number;
  caseCount: number;
  at: number;
}

const GRANT_KINDS = [
  { id: "gift", label: "Gift", icon: Gift },
  { id: "comp", label: "Compensation", icon: HeartHandshake },
  { id: "bonus", label: "Bonus", icon: Coins },
] as const;

type GrantKind = (typeof GRANT_KINDS)[number]["id"];

// USER SPEC (Task 183): the gift-a-free-case picker — every regular case in
// the catalog (daily LEVEL cases are already free; hidden RB-TST stays off).
const GIFTABLE_CASES = CASES.filter(
  (c) => (c.kind === "standard" || c.kind === "farm" || c.kind === "event") && !c.hidden,
);

const fmtDate = (iso: string | null) =>
  iso ? new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";

/** label:value line inside the details overlay */
function Detail({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-white/10 bg-black/30 px-3 py-2">
      <p className="text-[9px] font-black uppercase tracking-widest text-white/40">{label}</p>
      <p className="mt-0.5 truncate text-xs font-bold text-white/85" dir="ltr">
        {children}
      </p>
    </div>
  );
}

export function AdminView() {
  const mounted = useMounted();
  const { player: me, refresh } = useSession();
  const { toast } = useToast();

  const [query, setQuery] = useState("");
  const [players, setPlayers] = useState<AdminPlayer[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<AdminPlayer | null>(null);
  // USER SPEC (Task 23): the selected player's recent battles (fetched when
  // the overlay opens, null = loading, [] = none yet)
  const [battles, setBattles] = useState<AdminBattle[] | null>(null);

  // overlay controls
  const [newLevel, setNewLevel] = useState("");
  const [grantAmount, setGrantAmount] = useState("");
  const [grantKind, setGrantKind] = useState<GrantKind>("gift");
  // USER SPEC (Task 183): the FREE-case gift controls
  const [giftCaseId, setGiftCaseId] = useState(GIFTABLE_CASES[0]?.id ?? "");
  const [giftQty, setGiftQty] = useState("1");
  const [banArm, setBanArm] = useState(false);
  const [busy, setBusy] = useState(false);
  const debounceRef = useRef<number | null>(null);

  // USER SPEC (Task 136): the SUPPORT tab — the admins' chat inbox with the
  // SUPPORT CASE alert. openCases drives the pulsing dot on the tab.
  // C7 PHASE 1: the WALLET tab — the real-money review desk (deposits /
  // withdrawals / config); walletPending drives its amber badge.
  // SECURITY (Task 167): GIVEAWAYS desk, TOOLS (banner + case stats) and
  // SECURITY (TOTP 2FA + audit trail).
  const [tab, setTab] = useState<"players" | "support" | "wallet" | "giveaways" | "tools" | "security">("players");

  // SECURITY (Task 167): the 2FA gate. When the admin has TOTP enabled, the
  // panel (and EVERY admin API) stays a flat 404 until a correct code mints
  // the 12h rb_2fa unlock cookie. "checking" only on the first mount.
  const [gate, setGate] = useState<"checking" | "open" | "locked">("checking");
  const [gateCode, setGateCode] = useState("");
  const [gateBusy, setGateBusy] = useState(false);
  useEffect(() => {
    if (!mounted || !me?.isAdmin) return;
    let dead = false;
    void (async () => {
      try {
        const r = await fetch("/api/admin/2fa", { cache: "no-store" });
        const d = r.ok ? ((await r.json()) as { enabled: boolean; unlocked: boolean }) : null;
        if (!dead) setGate(d?.enabled && !d.unlocked ? "locked" : "open");
      } catch {
        if (!dead) setGate("open"); // never lock the panel behind a network blip
      }
    })();
    return () => {
      dead = true;
    };
  }, [mounted, me?.isAdmin]);

  const unlockGate = async () => {
    setGateBusy(true);
    try {
      const r = await fetch("/api/admin/2fa/unlock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: gateCode }),
      });
      const d = (await r.json()) as { ok?: boolean; error?: string };
      if (!r.ok || !d.ok) throw new Error(d.error ?? "Failed");
      sfx.coins();
      setGate("open");
      setGateCode("");
      void refresh();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Wrong code" });
    } finally {
      setGateBusy(false);
    }
  };
  const [focusPlayerId, setFocusPlayerId] = useState<string | null>(null);
  const [openCases, setOpenCases] = useState(0);
  // C7: the WALLET tab badge — pending deposits + withdrawals (reported up by
  // AdminWalletTab after every load/action).
  const [walletPending, setWalletPending] = useState(0);

  const load = useCallback(async (q: string) => {
    try {
      const r = await fetch(`/api/admin/players${q ? `?q=${encodeURIComponent(q)}` : ""}`, { cache: "no-store" });
      if (r.status === 404) {
        setPlayers([]);
        setLoading(false);
        return;
      }
      const d = (await r.json()) as { players: AdminPlayer[] };
      setPlayers(d.players ?? []);
    } catch {
      /* keep the previous list */
    } finally {
      setLoading(false);
    }
  }, []);

  // the search box matches THE SITE ID ONLY — debounced so typing stays smooth
  useEffect(() => {
    if (!mounted || !me?.isAdmin) return;
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(() => void load(query.trim()), 220);
    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [mounted, me?.isAdmin, query, load]);

  const openPlayer = (p: AdminPlayer) => {
    sfx.click();
    setSelected(p);
    setNewLevel(String(p.level));
    setGrantAmount("");
    setGrantKind("gift");
    setGiftQty("1");
    setBanArm(false);
    setBattles(null);
    // the overlay's RECENT BATTLES feed — the server's finished rows
    void (async () => {
      try {
        const r = await fetch(`/api/admin/player/${p.id}/battles`, { cache: "no-store" });
        if (!r.ok) {
          setBattles([]);
          return;
        }
        const d = (await r.json()) as { battles: AdminBattle[] };
        setBattles(d.battles ?? []);
      } catch {
        setBattles([]);
      }
    })();
  };

  const patchSelected = (patch: Partial<AdminPlayer>) =>
    setSelected((prev) => (prev ? { ...prev, ...patch } : prev));

  // the live SUPPORT CASE counter for the tab badge (realtime + slow poll)
  const loadCases = useCallback(async () => {
    try {
      const r = await fetch("/api/support/admin/threads", { cache: "no-store" });
      if (!r.ok) return;
      const d = (await r.json()) as { threads: { caseStatus: string | null }[] };
      setOpenCases((d.threads ?? []).filter((t) => t.caseStatus === "human_requested").length);
    } catch {
      /* the badge is cosmetic */
    }
  }, []);

  useEffect(() => {
    if (!mounted || !me?.isAdmin) return;
    void loadCases();
    const t = window.setInterval(() => void loadCases(), 12000);
    return () => window.clearInterval(t);
  }, [mounted, me?.isAdmin, loadCases]);

  useRealtimeEvent("support_admin", () => void loadCases());

  const openCaseFromAlert = useCallback((playerId: string) => {
    setSelected(null);
    setFocusPlayerId(playerId);
    setTab("support");
  }, []);

  // ----- actions -----
  const applyLevel = async () => {
    if (!selected) return;
    const level = Number(newLevel);
    if (!Number.isFinite(level) || level < 1 || level > 200) {
      toast({ title: "Level must be 1–200" });
      return;
    }
    setBusy(true);
    try {
      const r = await fetch(`/api/admin/player/${selected.id}/level`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ level }),
      });
      const d = (await r.json()) as { ok?: boolean; error?: string };
      if (!r.ok || !d.ok) throw new Error(d.error ?? "Failed");
      patchSelected({ level, xp: undefined });
      setPlayers((list) => list.map((p) => (p.id === selected.id ? { ...p, level } : p)));
      sfx.coins();
      toast({ title: `Level set — ${selected.name} is now LVL ${level}` });
      void refresh();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed to set the level" });
    } finally {
      setBusy(false);
    }
  };

  const grantMoney = async () => {
    if (!selected) return;
    const amount = Number(grantAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      toast({ title: "Add-only — enter a positive amount" });
      return;
    }
    setBusy(true);
    try {
      const r = await fetch(`/api/admin/player/${selected.id}/money`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount, kind: grantKind }),
      });
      const d = (await r.json()) as { ok?: boolean; balance?: number; error?: string };
      if (!r.ok || !d.ok) throw new Error(d.error ?? "Failed");
      patchSelected({ balance: d.balance });
      setPlayers((list) => list.map((p) => (p.id === selected.id ? { ...p, balance: d.balance! } : p)));
      setGrantAmount("");
      sfx.coins();
      toast({ title: `+${formatCoins(amount)} granted to ${selected.name}` });
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed to grant" });
    } finally {
      setBusy(false);
    }
  };

  // USER SPEC (Task 183): gift FREE CASES — the DB keeps the exact per-case
  // quantity and the player's screens update the same instant (realtime push).
  const giftFreeCase = async () => {
    if (!selected) return;
    const qty = Math.floor(Number(giftQty));
    if (!Number.isFinite(qty) || qty <= 0) {
      toast({ title: "Quantity must be a positive number" });
      return;
    }
    setBusy(true);
    try {
      const r = await fetch(`/api/admin/player/${selected.id}/freecase`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ caseId: giftCaseId, qty }),
      });
      const d = (await r.json()) as { ok?: boolean; freeCases?: Record<string, number>; error?: string };
      if (!r.ok || !d.ok || !d.freeCases) throw new Error(d.error ?? "Failed");
      patchSelected({ freeCases: d.freeCases });
      setPlayers((list) =>
        list.map((p) => (p.id === selected.id ? { ...p, freeCases: d.freeCases! } : p)),
      );
      setGiftQty("1");
      sfx.coins();
      const c = GIFTABLE_CASES.find((x) => x.id === giftCaseId);
      toast({ title: `${qty} × FREE ${c?.name ?? giftCaseId} gifted to ${selected.name}` });
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed to gift" });
    } finally {
      setBusy(false);
    }
  };

  const banPlayer = async () => {
    if (!selected || banArm === false) {
      setBanArm(true); // first click arms — the second confirms
      return;
    }
    if (!selected) return;
    setBusy(true);
    try {
      const r = await fetch(`/api/admin/player/${selected.id}/ban`, { method: "POST" });
      const d = (await r.json()) as { ok?: boolean; error?: string; bannedAt?: string };
      if (!r.ok || !d.ok) throw new Error(d.error ?? "Failed");
      patchSelected({ bannedAt: d.bannedAt ?? new Date().toISOString() });
      setPlayers((list) =>
        list.map((p) => (p.id === selected.id ? { ...p, bannedAt: d.bannedAt ?? new Date().toISOString() } : p)),
      );
      sfx.lock();
      toast({ title: `${selected.name} is permanently banned` });
      setBanArm(false);
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Failed to ban" });
    } finally {
      setBusy(false);
    }
  };

  // ---------- gates ----------
  if (!mounted) {
    return (
      <SiteShell>
        <main className="flex min-h-[60vh] items-center justify-center" aria-label="Admin">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-red-500/30 border-t-red-400" />
        </main>
      </SiteShell>
    );
  }

  if (!me) {
    return (
      <SiteShell>
        <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4" aria-label="Admin">
          <div className="w-full max-w-md rounded-2xl border border-red-500/25 bg-[#100a1e]/90 p-8 text-center">
            <ShieldOff className="mx-auto mb-3 h-10 w-10 text-red-400/70" />
            <h1 className="font-display text-xl font-black text-white">Admin area</h1>
            <p className="mt-2 text-sm text-white/55">Sign in with Steam to continue.</p>
            <Link href="/login" className="neon-btn mt-5 inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-black text-white">
              <Zap className="h-4 w-4" fill="currentColor" />
              Sign In
            </Link>
          </div>
        </main>
      </SiteShell>
    );
  }

  // non-admins get a flat wall — the panel does not exist for them
  if (!me.isAdmin) {
    return (
      <SiteShell>
        <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4" aria-label="Admin">
          <div className="w-full max-w-md rounded-2xl border border-red-500/25 bg-[#100a1e]/90 p-8 text-center">
            <ShieldOff className="mx-auto mb-3 h-10 w-10 text-red-400/70" />
            <h1 className="font-display text-xl font-black text-white">Access denied</h1>
            <p className="mt-2 text-sm text-white/55">
              This panel is reserved for ROLLBOX administrators only.
            </p>
            <Link href="/" className="mt-5 inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-black text-white/80 transition-colors hover:bg-white/10">
              <ArrowLeft className="h-4 w-4" />
              Back to the site
            </Link>
          </div>
        </main>
      </SiteShell>
    );
  }

  // ---------- the 2FA lock screen (SECURITY, Task 167) ----------
  if (mounted && me?.isAdmin && gate !== "open") {
    return (
      <SiteShell>
        <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-16" aria-label="Admin panel locked">
          <div className="mx-auto max-w-sm px-4">
            <div className="rounded-2xl border border-white/10 bg-black/40 p-6 text-center">
              {gate === "checking" ? (
                <div className="py-8">
                  <Shield className="mx-auto h-10 w-10 animate-pulse text-red-400" />
                  <p className="mt-3 text-xs font-black uppercase tracking-widest text-white/40">Checking the lock…</p>
                </div>
              ) : (
                <>
                  <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl border border-red-400/30 bg-red-500/15">
                    <Lock className="h-7 w-7 text-red-400" />
                  </div>
                  <h2 className="font-display mt-4 text-xl font-black tracking-wide text-white">
                    ADMIN <span className="text-gradient-neon">LOCKED</span>
                  </h2>
                  <p className="mt-2 text-xs leading-relaxed text-white/50">
                    Two-factor is ON. Enter the 6-digit code from your authenticator app to unlock the panel for 12 hours.
                  </p>
                  <form
                    className="mt-4 flex justify-center gap-2"
                    onSubmit={(e) => {
                      e.preventDefault();
                      void unlockGate();
                    }}
                  >
                    <input
                      value={gateCode}
                      onChange={(e) => setGateCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                      dir="ltr"
                      inputMode="numeric"
                      autoFocus
                      placeholder="000000"
                      aria-label="Two-factor unlock code"
                      className="w-36 rounded-xl border border-white/15 bg-black/50 px-3 py-3 text-center font-mono text-lg tracking-[0.35em] text-white focus:border-red-400/60 focus:outline-none"
                    />
                    <button
                      type="submit"
                      disabled={gateBusy || gateCode.length !== 6}
                      className="rounded-xl border border-red-400/50 bg-red-500/20 px-5 text-xs font-black uppercase tracking-widest text-red-200 transition-colors hover:bg-red-500/30 disabled:opacity-40"
                    >
                      Unlock
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </main>
      </SiteShell>
    );
  }

  // ---------- the panel ----------
  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-8" aria-label="Admin panel">
        <div className="relative mx-auto max-w-3xl px-4">
          {/* header */}
          <div className="flex items-center gap-3">
            <Link
              href="/"
              onClick={() => sfx.click()}
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
              aria-label="Back to the home page"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <div>
              <h1 className="font-display flex items-center gap-2 text-2xl font-black tracking-wide text-white sm:text-3xl">
                <Shield className="h-6 w-6 text-red-400 drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
                ADMIN <span className="text-gradient-neon">PANEL</span>
              </h1>
              <p className="text-xs font-semibold text-white/45">
                {loading ? "Loading players..." : `${players.length} player${players.length === 1 ? "" : "s"} on the site`}
              </p>
            </div>
          </div>

          {/* USER SPEC (Task 136): the panel tabs — PLAYERS / SUPPORT; C7:
              the WALLET tab; Task 167: GIVEAWAYS / TOOLS / SECURITY */}
          <div className="mt-5 grid grid-cols-2 gap-1.5 rounded-2xl border border-white/10 bg-black/40 p-1.5 sm:grid-cols-3 lg:grid-cols-6" role="tablist" aria-label="Admin panel sections">
            <button
              type="button"
              role="tab"
              aria-selected={tab === "players"}
              onClick={() => {
                sfx.click();
                setTab("players");
                setSelected(null);
              }}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-black uppercase tracking-wider transition-colors",
                tab === "players"
                  ? "border-red-400/40 bg-red-500/20 text-white"
                  : "border-transparent text-white/45 hover:text-white",
              )}
            >
              <Users className="h-4 w-4" />
              Players
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={tab === "support"}
              onClick={() => {
                sfx.click();
                setTab("support");
                setSelected(null);
              }}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-black uppercase tracking-wider transition-colors",
                tab === "support"
                  ? "border-red-400/40 bg-red-500/20 text-white"
                  : "border-transparent text-white/45 hover:text-white",
              )}
            >
              <LifeBuoy className="h-4 w-4" />
              Support
              {openCases > 0 && (
                <span className="grid h-4 min-w-4 place-items-center rounded-full bg-red-500 px-1 text-[9px] font-black text-white">
                  {openCases}
                </span>
              )}
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={tab === "wallet"}
              onClick={() => {
                sfx.click();
                setTab("wallet");
                setSelected(null);
              }}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-black uppercase tracking-wider transition-colors",
                tab === "wallet"
                  ? "border-red-400/40 bg-red-500/20 text-white"
                  : "border-transparent text-white/45 hover:text-white",
              )}
            >
              <Wallet className="h-4 w-4" />
              Wallet
              {walletPending > 0 && (
                <span className="grid h-4 min-w-4 place-items-center rounded-full bg-amber-400 px-1 text-[9px] font-black text-black">
                  {walletPending}
                </span>
              )}
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={tab === "giveaways"}
              onClick={() => {
                sfx.click();
                setTab("giveaways");
                setSelected(null);
              }}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-black uppercase tracking-wider transition-colors",
                tab === "giveaways"
                  ? "border-red-400/40 bg-red-500/20 text-white"
                  : "border-transparent text-white/45 hover:text-white",
              )}
            >
              <Gift className="h-4 w-4" />
              Giveaways
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={tab === "tools"}
              onClick={() => {
                sfx.click();
                setTab("tools");
                setSelected(null);
              }}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-black uppercase tracking-wider transition-colors",
                tab === "tools"
                  ? "border-red-400/40 bg-red-500/20 text-white"
                  : "border-transparent text-white/45 hover:text-white",
              )}
            >
              <Megaphone className="h-4 w-4" />
              Tools
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={tab === "security"}
              onClick={() => {
                sfx.click();
                setTab("security");
                setSelected(null);
              }}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-black uppercase tracking-wider transition-colors",
                tab === "security"
                  ? "border-red-400/40 bg-red-500/20 text-white"
                  : "border-transparent text-white/45 hover:text-white",
              )}
            >
              <KeyRound className="h-4 w-4" />
              Security
            </button>
          </div>

          {/* search — USER SPEC: by SITE ID ONLY */}
          <div className={cn("mt-5 flex items-center gap-2 rounded-xl border border-white/15 bg-black/40 px-3 py-2.5 focus-within:border-red-400/60", tab !== "players" && "hidden")}>
            <Search className="h-4 w-4 shrink-0 text-white/40" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              dir="ltr"
              placeholder="Search by site ID (e.g. p_1a2b...)"
              aria-label="Search players by site ID"
              className="w-full bg-transparent font-mono text-xs text-white placeholder:text-white/30 focus:outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="text-[10px] font-black uppercase tracking-wide text-white/40 hover:text-white"
              >
                clear
              </button>
            )}
          </div>

          {/* the list — photo | name | site id, exactly as specced (players tab) */}
          {tab === "players" && (!loading && players.length === 0 ? (
            <div className="mt-6 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-12 text-center">
              <Search className="mx-auto mb-3 h-10 w-10 text-white/25" />
              <p className="text-sm font-bold text-white/60">No players match this ID</p>
              <p className="mt-1 text-xs text-white/40">The search matches the site ID only.</p>
            </div>
          ) : (
            <ul className="mt-5 space-y-2" aria-label="All players">
              {(loading ? [] : players).map((p) => {
                const tier = levelTier(p.level);
                return (
                  <li key={p.id}>
                    <button
                      type="button"
                      onClick={() => openPlayer(p)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors",
                        p.bannedAt
                          ? "border-red-500/30 bg-red-500/[0.06] hover:bg-red-500/10"
                          : "border-white/10 bg-white/[0.03] hover:bg-white/[0.07]",
                      )}
                    >
                      <span
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-full p-[2px]"
                        style={{ background: `linear-gradient(135deg, ${tier.hex}, ${tier.hex2})` }}
                      >
                        {p.avatar ? (
                          <img src={p.avatar} alt="" referrerPolicy="no-referrer" className="h-full w-full rounded-full border border-black/40 object-cover" />
                        ) : (
                          <span className="font-display grid h-full w-full place-items-center rounded-full border border-black/40 bg-gradient-to-br from-violet-500 to-fuchsia-600 text-sm font-black text-white">
                            {p.name.charAt(0).toUpperCase()}
                          </span>
                        )}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-1.5">
                          <span className="truncate text-sm font-bold text-white/90">{p.name}</span>
                          {p.isAdmin && (
                            <span className="rounded border border-red-400/40 bg-red-500/10 px-1 py-0.5 text-[8px] font-black uppercase text-red-300">
                              admin
                            </span>
                          )}
                          {p.bannedAt && (
                            <span className="rounded border border-red-500/50 bg-red-500/20 px-1 py-0.5 text-[8px] font-black uppercase text-red-300">
                              banned
                            </span>
                          )}
                        </span>
                        {/* USER SPEC: the SITE id sits next to the name */}
                        <span className="block truncate font-mono text-[10px] text-white/40" dir="ltr">
                          {p.id}
                        </span>
                      </span>
                      <span className="flex shrink-0 flex-col items-end">
                        <span className="font-display flex items-center gap-1 text-xs font-black text-amber-300 tabular-nums" dir="ltr">
                          <Coin className="h-3 w-3" />
                          {formatCoins(p.balance)}
                        </span>
                        <span className="text-[10px] font-bold uppercase text-white/40">LVL {p.level}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          ))}

          {/* USER SPEC (Task 136): the SUPPORT inbox — conversations + cases */}
          {tab === "support" && <SupportInbox focusPlayerId={focusPlayerId} />}
          {/* C7 PHASE 1: the real-money review desk */}
          {tab === "wallet" && <AdminWalletTab onPending={setWalletPending} />}
          {tab === "giveaways" && <AdminGiveawaysTab />}
          {tab === "tools" && <AdminToolsTab />}
          {tab === "security" && <AdminSecurityTab />}
        </div>

        {/* USER SPEC (Task 136): the SUPPORT CASE side alert — pops on every
            admin's screen when a player requests human support */}
        <SupportCaseAlert onOpen={openCaseFromAlert} />

        {/* ===== the on-screen OVERLAY (never a new page) ===== */}
        {selected && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
            role="dialog"
            aria-modal="true"
            aria-label={`Admin details — ${selected.name}`}
            onClick={(e) => {
              if (e.target === e.currentTarget) setSelected(null);
            }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-red-500/25 bg-[#100a1e] p-6 shadow-[0_0_60px_rgba(239,68,68,0.15)]"
            >
              {/* identity header */}
              <div className="flex items-center gap-3">
                {selected.avatar ? (
                  <img src={selected.avatar} alt="" referrerPolicy="no-referrer" className="h-12 w-12 rounded-full object-cover" />
                ) : (
                  <span className="font-display grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 text-lg font-black text-white">
                    {selected.name.charAt(0).toUpperCase()}
                  </span>
                )}
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-2 truncate text-lg font-black text-white">
                    {selected.name}
                    {selected.isAdmin && (
                      <span className="rounded border border-red-400/40 bg-red-500/10 px-1.5 py-0.5 text-[9px] font-black uppercase text-red-300">admin</span>
                    )}
                    {selected.bannedAt && (
                      <span className="rounded border border-red-500/50 bg-red-500/20 px-1.5 py-0.5 text-[9px] font-black uppercase text-red-300">banned forever</span>
                    )}
                  </p>
                  <p className="truncate font-mono text-[11px] text-white/45" dir="ltr">{selected.id}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSelected(null)}
                  className="grid h-9 w-9 place-items-center rounded-lg border border-white/15 bg-white/5 text-white/60 transition-colors hover:bg-white/10 hover:text-white"
                  aria-label="Close the details"
                >
                  ✕
                </button>
              </div>

              {/* ALL the details */}
              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
                <Detail label="Balance">
                  <span className="flex items-center gap-1 text-amber-300"><Coin className="h-3 w-3" />{formatCoins(selected.balance)}</span>
                </Detail>
                <Detail label="Level">LVL {selected.level}</Detail>
                <Detail label="XP">{selected.xp}</Detail>
                <Detail label="Cases opened">{selected.casesOpened}</Detail>
                <Detail label="Battles won">{selected.battlesWon}</Detail>
                <Detail label="Invite code">{selected.refCode ?? "—"}</Detail>
                <Detail label="Invited by">{selected.referredBy ?? "—"}</Detail>
                <Detail label="Email">{selected.email ?? "—"}</Detail>
                <Detail label="Joined">{fmtDate(selected.createdAt)}</Detail>
                <Detail label="Last seen">{fmtDate(selected.lastSeenAt)}</Detail>
                <div className="col-span-2 sm:col-span-3">
                  <Detail label="Trade link">{selected.tradeLink ?? "—"}</Detail>
                </div>
                {/* USER SPEC (Task 183): the player's gifted FREE boxes */}
                <div className="col-span-2 sm:col-span-3">
                  <Detail label="Free cases (gifts + mission prizes)">
                    {Object.entries(selected.freeCases).length === 0
                      ? "—"
                      : Object.entries(selected.freeCases)
                          .map(([cid, qty]) => `${CASES.find((c) => c.id === cid)?.code ?? cid} ×${qty}`)
                          .join(" · ")}
                  </Detail>
                </div>
              </div>

              {/* USER SPEC (Task 23): the player's RECENT battles — last 12
                  finished rooms, straight from the battle table */}
              <div className="mt-4 rounded-xl border border-white/10 bg-white/[0.03] p-3">
                <p className="text-[10px] font-black uppercase tracking-widest text-white/50">
                  Recent battles {battles && battles.length > 0 ? `(${battles.length})` : ""}
                </p>
                {battles === null ? (
                  <p className="mt-2 text-xs font-semibold text-white/35">Loading battles…</p>
                ) : battles.length === 0 ? (
                  <p className="mt-2 text-xs font-semibold text-white/35">No finished battles yet.</p>
                ) : (
                  <ul className="mt-2 space-y-1.5">
                    {battles.map((b, i) => (
                      <li
                        key={`${b.code}-${i}`}
                        className="flex items-center gap-2 rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5"
                      >
                        <span
                          className={cn(
                            "grid h-6 w-6 shrink-0 place-items-center rounded-md text-[10px] font-black",
                            b.result === "W" ? "bg-emerald-500/20 text-emerald-300" : "bg-red-500/15 text-red-300",
                          )}
                        >
                          {b.result}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[11px] font-bold text-white/80" dir="ltr">
                            {b.type} · {b.mode} · {b.caseCount} case{b.caseCount === 1 ? "" : "s"}
                          </span>
                          <span className="block text-[9px] font-semibold text-white/35" dir="ltr">
                            {fmtDate(new Date(b.at).toISOString())}
                          </span>
                        </span>
                        <span className="shrink-0 text-right" dir="ltr">
                          <span className="block font-display text-[11px] font-black text-amber-300 tabular-nums">
                            {formatCoins(b.entry)} → {formatCoins(b.take)}
                          </span>
                          <span
                            className={cn(
                              "block text-[9px] font-black tabular-nums",
                              b.net >= 0 ? "text-emerald-300" : "text-red-300",
                            )}
                          >
                            {b.net >= 0 ? "+" : ""}
                            {formatCoins(b.net)}
                          </span>
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* controls */}
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {/* level */}
                <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                  <p className="text-[10px] font-black uppercase tracking-widest text-white/50">Set level</p>
                  <div className="mt-2 flex gap-2">
                    <input
                      value={newLevel}
                      onChange={(e) => setNewLevel(e.target.value.replace(/[^0-9]/g, ""))}
                      dir="ltr"
                      inputMode="numeric"
                      aria-label="New level"
                      className="h-9 w-20 rounded-lg border border-white/15 bg-black/40 px-2.5 text-center font-display text-sm font-black text-white focus:border-fuchsia-400/60 focus:outline-none"
                    />
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => void applyLevel()}
                      className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg border border-fuchsia-400/40 bg-fuchsia-500/15 text-xs font-black text-fuchsia-200 transition-colors hover:bg-fuchsia-500/25 disabled:opacity-50"
                    >
                      <Check className="h-3.5 w-3.5" />
                      APPLY LEVEL
                    </button>
                  </div>
                </div>

                {/* money — ADD ONLY by design */}
                <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                  <p className="text-[10px] font-black uppercase tracking-widest text-white/50">
                    Add money <span className="text-emerald-300">(add-only — never subtract)</span>
                  </p>
                  <div className="mt-2 flex gap-2">
                    <input
                      value={grantAmount}
                      onChange={(e) => setGrantAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                      dir="ltr"
                      inputMode="decimal"
                      placeholder="0"
                      aria-label="Amount to add"
                      className="h-9 w-20 rounded-lg border border-white/15 bg-black/40 px-2.5 text-center font-display text-sm font-black text-amber-300 focus:border-amber-400/60 focus:outline-none"
                    />
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => void grantMoney()}
                      className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 text-xs font-black text-emerald-200 transition-colors hover:bg-emerald-500/25 disabled:opacity-50"
                    >
                      <Coins className="h-3.5 w-3.5" />
                      ADD
                    </button>
                  </div>
                  {/* gift / compensation / bonus */}
                  <div className="mt-2 grid grid-cols-3 gap-1.5">
                    {GRANT_KINDS.map((k) => {
                      const Icon = k.icon;
                      const active = grantKind === k.id;
                      return (
                        <button
                          key={k.id}
                          type="button"
                          onClick={() => {
                            sfx.click();
                            setGrantKind(k.id);
                          }}
                          className={cn(
                            "flex items-center justify-center gap-1 rounded-lg border px-1.5 py-1.5 text-[10px] font-black uppercase tracking-wide transition-colors",
                            active
                              ? "border-emerald-400/50 bg-emerald-500/15 text-emerald-200"
                              : "border-white/10 bg-white/[0.03] text-white/45 hover:text-white/75",
                          )}
                          aria-pressed={active}
                        >
                          <Icon className="h-3 w-3" />
                          {k.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* USER SPEC (Task 183): GIFT FREE CASES — pick the case + the
                  quantity; the DB keeps the exact per-player count and the
                  player's screens show the FREE ×N chip the same instant */}
              <div className="mt-3 rounded-xl border border-emerald-400/25 bg-emerald-500/[0.05] p-3">
                <p className="text-[10px] font-black uppercase tracking-widest text-white/50">
                  Gift free cases <span className="text-emerald-300">(lands instantly, opens at no charge)</span>
                </p>
                <div className="mt-2 flex gap-2">
                  <select
                    value={giftCaseId}
                    onChange={(e) => setGiftCaseId(e.target.value)}
                    aria-label="Case to gift"
                    className="h-9 min-w-0 flex-1 rounded-lg border border-white/15 bg-black/40 px-2 text-xs font-bold text-white focus:border-emerald-400/60 focus:outline-none"
                  >
                    {GIFTABLE_CASES.map((c) => (
                      <option key={c.id} value={c.id} className="bg-[#100a1e]">
                        {c.code} — {c.name}
                      </option>
                    ))}
                  </select>
                  <input
                    value={giftQty}
                    onChange={(e) => setGiftQty(e.target.value.replace(/[^0-9]/g, ""))}
                    dir="ltr"
                    inputMode="numeric"
                    placeholder="1"
                    aria-label="How many free boxes"
                    className="h-9 w-16 rounded-lg border border-white/15 bg-black/40 px-2.5 text-center font-display text-sm font-black text-emerald-300 focus:border-emerald-400/60 focus:outline-none"
                  />
                  <button
                    type="button"
                    disabled={busy || !giftCaseId}
                    onClick={() => void giftFreeCase()}
                    className="flex h-9 shrink-0 items-center justify-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-3 text-xs font-black text-emerald-200 transition-colors hover:bg-emerald-500/25 disabled:opacity-50"
                  >
                    <Gift className="h-3.5 w-3.5" />
                    GIFT
                  </button>
                </div>
              </div>

              {/* the PERMANENT ban — two-click confirm, no unban exists */}
              <div className="mt-3 rounded-xl border border-red-500/30 bg-red-500/[0.06] p-3">
                {selected.bannedAt ? (
                  <p className="flex items-center gap-2 text-xs font-bold text-red-300">
                    <Ban className="h-4 w-4" />
                    Permanently banned since {fmtDate(selected.bannedAt)} — this cannot be undone.
                  </p>
                ) : (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void banPlayer()}
                    className={cn(
                      "flex h-10 w-full items-center justify-center gap-2 rounded-lg border text-xs font-black uppercase tracking-widest transition-all",
                      banArm
                        ? "animate-pulse border-red-400 bg-red-500/40 text-white shadow-[0_0_20px_rgba(239,68,68,0.5)]"
                        : "border-red-500/50 bg-red-500/15 text-red-300 hover:bg-red-500/25",
                    )}
                  >
                    <Ban className="h-4 w-4" />
                    {banArm ? "Click again — PERMANENT, no undo" : "Ban permanently"}
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </main>
    </SiteShell>
  );
}
