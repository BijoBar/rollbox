"use client";

import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Swords, ArrowLeftRight, Trophy, Shield, TrendingUp, TerminalSquare, Volume2, VolumeX, Sparkles, Gamepad2, ChevronDown, Gift } from "lucide-react";
import { useCaseStore } from "@/lib/store";
import { useSession } from "@/lib/session";
import { useRealtimeEvent } from "@/lib/realtime";
import { sfx } from "@/lib/sound";
import { formatCoins } from "@/lib/cases";
import { eventActive } from "@/lib/event";
import { levelFromXp } from "@/lib/progress";
import { readyDailyCount } from "@/lib/level-cases";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { cn } from "@/lib/utils";
import { useWarp } from "./WarpProvider";
import { Coin } from "./Coin";
import { Logo } from "./Logo";
import { LevelRing } from "./LevelRing";
import { InventoryDrawer, useInvDrawer } from "./InventoryDrawer";
import { TopupDialog, useTopup } from "./TopupDialog";

/**
 * USER SPEC (Task 84): every TopBar navigation is a LIGHT-SPEED dash into
 * the next page (streak overlay + corridor at full burn), not a page swap.
 * Plain modifier/middle clicks fall through to the browser (new tab etc.).
 */
function warpClick(
  e: { preventDefault: () => void; button: number; metaKey: boolean; ctrlKey: boolean; shiftKey: boolean; altKey: boolean },
  href: string,
  warpNavigate: (href: string) => void,
) {
  if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  e.preventDefault();
  sfx.click();
  warpNavigate(href);
}

const hashStr = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h).toString(36);
};

/**
 * USER SPEC (Task 168): the top bar was CROWDED — every game held its own
 * top-level link. They now live behind ONE "GAMES" category with a dropdown,
 * in the user's exact order: Case Battles, Upgrader, Events, Terminal.
 * Every entry keeps the light-speed warp nav; EVENTS carries its live pulse
 * while the limited event window is open (a matching dot rides the button).
 */
const GAMES_MENU: { href: string; label: string; icon: typeof Swords; iconCls: string; live?: boolean }[] = [
  { href: "/battles", label: "Case Battles", icon: Swords, iconCls: "text-fuchsia-300" },
  { href: "/upgrader", label: "Upgrader", icon: TrendingUp, iconCls: "text-emerald-300" },
  { href: "/event", label: "Events", icon: Sparkles, iconCls: "text-emerald-300", live: true },
  { href: "/terminal", label: "Terminal", icon: TerminalSquare, iconCls: "text-cyan-300" },
];

// subscribed the React way — an EXTERNAL system (the CSS media query), so
// the menu only hover-opens on real fine pointers and never double-toggles
// on touch (pointerenter fires before click there)
function subscribeHoverPointer(onChange: () => void) {
  const mq = window.matchMedia("(hover: hover) and (pointer: fine)");
  mq.addEventListener("change", onChange);
  return () => mq.removeEventListener("change", onChange);
}

function GamesMenu() {
  const [open, setOpen] = useState(false);
  const canHover = useSyncExternalStore(
    subscribeHoverPointer,
    () => window.matchMedia("(hover: hover) and (pointer: fine)").matches,
    () => false, // server snapshot — handlers attach on hydration only
  );
  const menuRef = useRef<HTMLDivElement | null>(null);
  const closeTimer = useRef<number | null>(null);
  const mounted = useMounted();
  const pathname = usePathname();
  const { warpNavigate } = useWarp();

  // any navigation (warp, back-button, menu item) closes the menu — the
  // React-endorsed adjust-state-during-render pattern, no effect needed
  const [seenPath, setSeenPath] = useState(pathname);
  if (pathname !== seenPath) {
    setSeenPath(pathname);
    setOpen(false);
  }

  // outside click + Escape close
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);
  useEffect(
    () => () => {
      if (closeTimer.current) window.clearTimeout(closeTimer.current);
    },
    [],
  );

  // small grace delay so moving the pointer from the button into the panel
  // (across the mt gap) does not snap the menu shut
  const armClose = () => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
    closeTimer.current = window.setTimeout(() => setOpen(false), 150);
  };
  const disarmClose = () => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
    closeTimer.current = null;
  };
  const onEnter = canHover
    ? () => {
        disarmClose();
        setOpen(true);
      }
    : undefined;
  const onLeave = canHover ? armClose : undefined;

  const eventLive = mounted && eventActive();

  return (
    <div ref={menuRef} className="relative" onMouseEnter={onEnter} onMouseLeave={onLeave}>
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label="Games menu"
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-semibold text-white/75 transition-colors hover:bg-white/5 hover:text-white",
          open && "bg-white/5 text-white",
        )}
      >
        <span className="relative flex items-center">
          <Gamepad2 className="h-4 w-4 text-violet-300" />
          {eventLive && (
            <span className="absolute -right-1 -top-1 flex h-2 w-2" aria-hidden="true">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
          )}
        </span>
        GAMES
        <ChevronDown
          className={cn("h-3.5 w-3.5 text-white/50 transition-transform duration-200", open && "rotate-180")}
        />
      </button>

      {open && (
        <div
          role="menu"
          aria-label="All games"
          className="absolute left-0 top-full z-50 mt-1.5 w-56 origin-top animate-in fade-in slide-in-from-top-2 overflow-hidden rounded-xl border border-white/10 bg-[#150f24]/95 p-1.5 shadow-2xl shadow-black/60 backdrop-blur-md duration-150"
        >
          {GAMES_MENU.map((g) => (
            <Link
              key={g.href}
              href={g.href}
              role="menuitem"
              className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-semibold text-white/75 transition-colors hover:bg-white/5 hover:text-white"
              onClick={(e) => {
                warpClick(e, g.href, warpNavigate);
                setOpen(false);
              }}
            >
              <g.icon className={cn("h-4 w-4 shrink-0", g.iconCls)} />
              {g.label}
              {g.live && eventLive && (
                <span className="relative ml-auto flex h-2 w-2" aria-hidden="true">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
              )}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * QOL (Task 167): the admin's site-wide BROADCAST banner (TOOLS tab).
 * Shows on every page until the admin hides it; each visitor can dismiss the
 * current message for themselves (per-message localStorage key).
 */
function BannerStrip() {
  const mounted = useMounted();
  const [banner, setBanner] = useState<{ text: string; tone: string } | null>(null);
  const [off, setOff] = useState(false);
  useEffect(() => {
    let dead = false;
    void (async () => {
      try {
        const r = await fetch("/api/banner", { cache: "no-store" });
        if (!r.ok) return;
        const d = (await r.json()) as { on: boolean; text: string; tone: string };
        if (!dead && d.on && d.text) {
          setBanner({ text: d.text, tone: d.tone });
          setOff(window.localStorage.getItem(`rb_banner_off_${hashStr(d.text)}`) === "1");
        }
      } catch {
        /* cosmetic */
      }
    })();
    return () => {
      dead = true;
    };
  }, []);
  if (!mounted || !banner || off) return null;
  const toneBox =
    banner.tone === "info"
      ? "border-sky-400/30 bg-sky-500/15 text-sky-100"
      : banner.tone === "alert"
        ? "border-rose-400/30 bg-rose-500/15 text-rose-100"
        : "border-amber-400/30 bg-amber-500/15 text-amber-100";
  return (
    <div className={cn("relative border-b border-white/5 px-9 py-1.5 text-center text-[11px] font-bold tracking-wide", toneBox)} role="status">
      {banner.text}
      <button
        type="button"
        aria-label="Dismiss the announcement"
        onClick={() => {
          window.localStorage.setItem(`rb_banner_off_${hashStr(banner.text)}`, "1");
          setOff(true);
        }}
        className="absolute right-2 top-1/2 -translate-y-1/2 rounded px-1.5 text-sm font-black opacity-60 transition-opacity hover:opacity-100"
      >
        ×
      </button>
    </div>
  );
}

export function TopBar() {
  const balance = useCaseStore((s) => s.balance);
  const xp = useCaseStore((s) => s.xp);
  const dailyOpens = useCaseStore((s) => s.dailyOpens);
  const invCount = useCaseStore((s) => s.inventory.length);
  // HARDENING CLEANUP (Task 153 / B5): the store's soundOn + toggleSound were
  // wired to NO UI — this speaker button is their one switch (guests included;
  // the whole soundscape gates on soundOn inside src/lib/sound.ts).
  const soundOn = useCaseStore((s) => s.soundOn);
  const toggleSound = useCaseStore((s) => s.toggleSound);
  const setInvOpen = useInvDrawer((s) => s.setOpen);
  const setTopupOpen = useTopup((s) => s.setOpen);
  const { toast } = useToast();
  const mounted = useMounted();
  const { warpNavigate } = useWarp();
  const [, setTick] = useState(0);
  // the DATABASE session — when signed in, every coin in the header is the
  // server's truth (same number for this player on every device)
  const { player: me } = useSession();
  const shownBalance = me ? me.balance : balance;

  // floating "+$X" win pulses off the balance chip (fired via emitWinFx) —
  // the small win toast is gone, THIS is the win notification
  const [winPulses, setWinPulses] = useState<{ id: number; amount: number }[]>([]);
  const [balanceFlash, setBalanceFlash] = useState(false);

  useEffect(() => {
    const onWin = (e: Event) => {
      const amount = (e as CustomEvent<{ amount?: number }>).detail?.amount ?? 0;
      if (!(amount > 0)) return;
      const id = Date.now() + Math.random();
      setWinPulses((p) => [...p.slice(-3), { id, amount }]);
      setBalanceFlash(true);
      window.setTimeout(() => setWinPulses((p) => p.filter((q) => q.id !== id)), 2100);
      window.setTimeout(() => setBalanceFlash(false), 950);
    };
    window.addEventListener("rollbox:win", onWin);
    return () => window.removeEventListener("rollbox:win", onWin);
  }, []);

  // USER SPEC (Task 104): the daily reward is a SET of free cases — every
  // case up to the player's level, each once per 24h. The TopBar only NUDGES
  // once per browser-day when at least ONE of them is ready. Signed-in
  // players read the SERVER gate (/api/daily); guests check the local map.
  const nudgeDaily = useCallback(
    (playerXp: number, opens: Record<string, number>) => {
      const lvl = levelFromXp(playerXp).level;
      if (readyDailyCount(opens, lvl) === 0) return;
      try {
        const k = "rb-daily-nudge";
        const today = new Date().toDateString();
        if (window.localStorage.getItem(k) === today) return;
        window.localStorage.setItem(k, today);
      } catch {
        /* private mode — fall through, the nudge fires once per mount */
      }
      sfx.coins();
      toast({
        title: <>Your free daily cases are ready!</>,
        description: "Every case up to your level — waiting in Special for you on the home page.",
      });
    },
    [toast],
  );

  useEffect(() => {
    if (!mounted || !me) return;
    let alive = true;
    const check = async () => {
      try {
        const r = await fetch("/api/daily", { cache: "no-store" });
        if (!r.ok) return;
        const d = (await r.json()) as { anyReady?: boolean };
        if (alive && d.anyReady) {
          const st = useCaseStore.getState();
          nudgeDaily(st.xp, st.dailyOpens);
        }
      } catch {
        /* the next tick retries */
      }
    };
    void check();
    const t = window.setInterval(() => void check(), 60000);
    return () => {
      alive = false;
      window.clearInterval(t);
    };
  }, [mounted, me, nudgeDaily]);

  useEffect(() => {
    if (!mounted || me) return;
    const st = useCaseStore.getState();
    nudgeDaily(st.xp, st.dailyOpens);
  }, [mounted, me, nudgeDaily]);

  // keep the LVL countdown tooltip fresh
  useEffect(() => {
    const t = window.setInterval(() => setTick((k) => k + 1), 30000);
    return () => window.clearInterval(t);
  }, []);

  // DB INVENTORY SYNC (Task 64): the TopBar mounts on EVERY page, so it owns
  // the one mirror of the DATABASE inventory into the UI store. Sign in on a
  // second device — the same skins are here. Sign out — local guest mode only.
  const setServerInventory = useCaseStore((s) => s.setServerInventory);
  const clearItems = useCaseStore((s) => s.clearItems);
  useEffect(() => {
    if (!mounted) return;
    if (!me?.id) {
      clearItems(); // guests play the local wallet — no DB rows behind it
      return;
    }
    const sync = async () => {
      try {
        const r = await fetch("/api/inventory", { cache: "no-store" });
        if (!r.ok) return;
        const data = (await r.json()) as { items: unknown[] };
        setServerInventory((data.items ?? []) as never[]);
      } catch {
        /* the push / the next mount reconciles */
      }
    };
    void sync();
  }, [mounted, me?.id, setServerInventory, clearItems]);

  // the server announced an inventory change for THIS account (any device).
  // USER SPEC (Task 29): while the UPGRADER wheel spins the store is FROZEN —
  // the push is skipped here and UpgraderView syncs once the wheel stops.
  useRealtimeEvent("inventory", (data) => {
    const e = data as { playerId?: string } | null;
    if (!me?.id || e?.playerId !== me.id) return;
    if (useCaseStore.getState().invHold) return;
    void (async () => {
      try {
        const r = await fetch("/api/inventory", { cache: "no-store" });
        if (!r.ok) return;
        const data = (await r.json()) as { items: unknown[] };
        setServerInventory((data.items ?? []) as never[]);
      } catch {
        /* the next push reconciles */
      }
    })();
  });

  const lvl = levelFromXp(xp);

  return (
    <header className="glass sticky top-0 z-40 border-b border-white/10">
      {/* QOL (Task 167): the admin broadcast banner rides the sticky header */}
      <BannerStrip />
      {/* USER SPEC (Task 168): the row grew again (sm:h-[88px]) so the 2xl
          logo — enlarged in place of the removed CASES link — leads it */}
      <div className="mx-auto flex h-[72px] max-w-7xl items-center gap-1 px-2 sm:h-[88px] sm:gap-3 sm:px-4">
        {/* logo — USER SPEC (Task 168): enlarged to size 2xl; tapping it still
            warps home. The wordmark is still hidden on phones so the row fits
            360-390px */}
        <Link
          href="/"
          aria-label="ROLLBOX — home"
          className="flex items-center rounded-lg"
          onClick={(e) => warpClick(e, "/", warpNavigate)}
        >
          <Logo size="2xl" hideWordmarkOnMobile />
        </Link>

        <nav className="ml-4 hidden items-center gap-1 md:flex" aria-label="Main navigation">
          {/* USER SPEC (Task 168): ONE clean GAMES category replaces the crowded
              per-game row — hover/click opens the dropdown with every game */}
          <GamesMenu />
          <a
            href="/skins"
            className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-semibold text-white/75 transition-colors hover:bg-white/5 hover:text-white"
            onClick={(e) => warpClick(e, "/skins", warpNavigate)}
          >
            <ArrowLeftRight className="h-4 w-4 text-sky-300" />
            Exchange
          </a>
          {/* USER SPEC (Task 168): GIVEAWAYS is BACK in the header — the
              dropdown freed the room it needed next to Exchange */}
          <Link
            href="/giveaways"
            className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-semibold text-white/75 transition-colors hover:bg-white/5 hover:text-white"
            onClick={(e) => warpClick(e, "/giveaways", warpNavigate)}
          >
            <Gift className="h-4 w-4 text-amber-300" />
            Giveaways
          </Link>
          {/* USER SPEC (Task 22): the ADMIN entry sits LEFT of the leaderboard —
              a GLOWING RED shield, rendered ONLY for players the DATABASE
              marks isAdmin. Everyone else never sees it existed. */}
          {mounted && me?.isAdmin && (
            <Link
              href="/admin"
              className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-bold text-red-400/90 transition-colors hover:bg-red-500/10 hover:text-red-300"
              onClick={(e) => warpClick(e, "/admin", warpNavigate)}
            >
              <span className="relative flex items-center">
                <Shield className="h-4 w-4 drop-shadow-[0_0_6px_rgba(239,68,68,0.9)]" />
                <span className="absolute inset-0 -m-1 animate-pulse rounded-full bg-red-500/20 blur-md" aria-hidden="true" />
              </span>
              ADMIN
            </Link>
          )}
          {/* USER SPEC (Task 22): LEADERBOARD — right of CASE BATTLES; the NEW
              badge that used to hang on battles is gone for good. */}
          <Link
            href="/leaderboard"
            className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-semibold text-white/75 transition-colors hover:bg-white/5 hover:text-white"
            onClick={(e) => warpClick(e, "/leaderboard", warpNavigate)}
          >
            <Trophy className="h-4 w-4 text-amber-300" />
            Leaderboard
          </Link>
        </nav>

        <div className="flex-1" />

        {/* Task 153 (B5): the SOUND on/off switch — one click, persisted with
            the rest of the store; the icon itself shows the current state. */}
        <button
          type="button"
          aria-label={soundOn ? "Mute sounds" : "Unmute sounds"}
          title={soundOn ? "SOUND: ON — click to mute" : "SOUND: OFF — click to unmute"}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white/55 transition-colors hover:bg-white/5 hover:text-white"
          onClick={() => {
            const next = !soundOn;
            toggleSound();
            if (next) sfx.click(); // feedback only when sounds are coming back
          }}
        >
          {soundOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
        </button>

        {/* USER SPEC (Task 33): the T.O.S / P.F / Discord buttons MOVED OUT of
            the header — they now sit on the RIGHT side of the stats strip
            above this bar (StatsLine). */}

        {/* USER SPEC (Task 33): DEPOSIT + INVENTORY are now a tight side-by-side
            text pair with NO background — green / orange. Signed-in only —
            guests get NO money / inventory UI, just the SIGN IN button. */}
        {mounted && me && (
          <div className="flex shrink-0 items-center gap-3">
            <button
              type="button"
              aria-label="Deposit funds"
              title="DEPOSIT — add funds (demo)"
              className="font-display text-[10px] font-black tracking-wider text-emerald-300 transition-colors hover:text-emerald-200"
              onClick={() => {
                sfx.click();
                setTopupOpen(true);
              }}
            >
              DEPOSIT
            </button>
            <button
              type="button"
              aria-label="Open your inventory"
              title="My Inventory"
              className="relative font-display text-[10px] font-black tracking-wider text-orange-400 transition-colors hover:text-orange-300"
              onClick={() => {
                sfx.click();
                setInvOpen(true);
              }}
            >
              INVENTORY
              {invCount > 0 && (
                <span className="absolute -right-2 -top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-fuchsia-500 px-1 text-[9px] font-bold text-white shadow-[0_0_10px_rgba(217,70,239,0.7)]">
                  {invCount > 9 ? "9+" : invCount}
                </span>
              )}
            </button>
          </div>
        )}

        {/* balance — the DATABASE number for signed-in players; flashes gold
            and floats a "+$X" pulse on every win. USER SPEC (Task 32):
            guests never see it — the top bar shows them SIGN IN only. */}
        {mounted && me && (
          <div
            className={cn(
              "relative flex h-9 shrink-0 items-center gap-1.5 rounded-xl border border-amber-400/30 bg-amber-400/10 px-2 sm:h-10 sm:gap-2 sm:px-3",
              "shadow-[0_0_14px_rgba(240,185,11,0.15)]",
              balanceFlash && "anim-balance-flash"
            )}
            aria-label="Coin balance"
            title="Your database balance — same on every device"
          >
            <Coin className="h-4.5 w-4.5 sm:h-5 sm:w-5" />
            <span className="font-display text-xs font-bold text-amber-300 tabular-nums sm:text-sm">
              {formatCoins(shownBalance)}
            </span>
            {/* floating "+$<win>" replaces the old win toast */}
            <div className="pointer-events-none absolute left-1/2 top-0 z-50 select-none" aria-hidden="true">
              {winPulses.map((p) => (
                <span
                  key={p.id}
                  className="anim-win-float font-display absolute left-0 top-0 whitespace-nowrap text-sm font-black text-amber-300 sm:text-base"
                >
                  +<Coin />{formatCoins(p.amount)}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* USER SPEC (Task 33): the separate LVL chip is GONE — the level now
            lives ON the avatar itself (glowing LevelRing), exactly like the
            profile page. Guests still get the SIGN IN button only. */}

        {/* account: database player chip when signed in, sign-in button otherwise */}
        <div className="flex shrink-0 items-center">
          {!mounted || !me ? null : (
            <Link
              href="/profile"
              className="flex items-center gap-2 rounded-full py-0.5 pl-0.5 pr-1 transition-colors hover:bg-white/5 sm:pr-2"
              aria-label={`Open profile of ${me.name} — Level ${lvl.level}`}
              title="My Profile"
              onClick={() => sfx.click()}
            >
              {/* USER SPEC (Task 33): the site-wide level avatar — glowing tier
                  ring around the picture with LVL riding ON it, 1:1 with the
                  profile page. SIGN OUT moved to the profile page. */}
              <LevelRing level={lvl.level} size="sm">
                {me.avatar ? (
                  <img src={me.avatar} alt="" className="h-full w-full rounded-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <span className="grid h-full w-full place-items-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 text-sm font-black text-white">
                    {me.name.charAt(0).toUpperCase()}
                  </span>
                )}
              </LevelRing>
              <span className="hidden max-w-24 truncate text-xs font-bold text-white/85 sm:block">
                {me.name}
              </span>
            </Link>
          )}
          {mounted && !me && (
            <Link
              href="/login"
              className="flex items-center gap-1.5 rounded-lg border border-sky-400/50 bg-sky-400/15 px-3 py-2 text-xs font-black tracking-wider text-sky-200 shadow-[0_0_16px_rgba(56,189,248,0.25)] transition-colors hover:bg-sky-400/25 hover:text-sky-100 sm:text-sm"
              aria-label="Sign in with Steam"
              title="Sign in with Steam"
              onClick={() => sfx.click()}
            >
              SIGN IN
            </Link>
          )}
        </div>
      </div>
      <InventoryDrawer />
      <TopupDialog />
    </header>
  );
}
