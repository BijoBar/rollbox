"use client";

import { useState } from "react";
import { SKIN_IMAGES } from "@/lib/skin-images";
import type { WeaponKind } from "@/lib/cases";
import { WeaponArt } from "./WeaponArt";
import { cn } from "@/lib/utils";

/**
 * Renders the official CS2 skin render (hotlinked from Valve's Steam CDN).
 * Falls back to the hand-drawn SVG art if the image is missing or fails to load.
 */
export function SkinImage({
  skinId,
  kind,
  colors,
  className,
  alt,
}: {
  skinId: string;
  kind: WeaponKind;
  colors: [string, string];
  className?: string;
  alt?: string;
}) {
  const url = SKIN_IMAGES[skinId];
  const [failed, setFailed] = useState(false);

  if (!url || failed) {
    return <WeaponArt kind={kind} colors={colors} className={className} />;
  }

  return (
    <img
      src={url}
      alt={alt ?? skinId}
      loading="lazy"
      decoding="async"
      draggable={false}
      onError={() => setFailed(true)}
      className={cn("select-none object-contain", className)}
    />
  );
}
