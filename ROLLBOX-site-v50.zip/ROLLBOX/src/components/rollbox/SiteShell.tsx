"use client";

import { type ReactNode } from "react";
import { TopBar } from "./TopBar";
import { StatsLine } from "./StatsLine";
import { LiveDrops } from "./LiveDrops";
import { SiteFooter } from "./SiteFooter";
import { AdminSupportAlerts } from "./AdminSupportAlerts";

/**
 * Shared page chrome: stats strip + top bar + live drops feed + footer.
 * (The SessionProvider lives in the ROOT layout — one provider above every
 * view, so views themselves can read the session too.)
 * USER SPEC (Task 32): the USERS/CASES/WINS/UPGRADES/CASES/BATTLES strip sits
 * ABOVE the main header — the very first thing on every page.
 * `plain` (Task 24) drops the LiveDrops ticker + footer so a page like the
 * TERMINAL can own the whole viewport with its own background.
 */
export function SiteShell({ children, plain }: { children: ReactNode; plain?: boolean }) {
  return (
    <div className="flex min-h-screen flex-col">
      <StatsLine />
      <TopBar />
      {!plain && <LiveDrops />}

      <main className="flex-1">{children}</main>

      {!plain && <SiteFooter />}

      {/* USER SPEC (Task 142 — CRITICAL): the red SUPPORT CASE alert follows
          admins on EVERY page (the /admin panel keeps its own instance). */}
      <AdminSupportAlerts />
    </div>
  );
}
