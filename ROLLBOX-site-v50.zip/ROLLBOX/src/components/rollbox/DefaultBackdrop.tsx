"use client";

import { usePathname } from "next/navigation";
import { PageBackdrop } from "./PageBackdrop";

/**
 * USER SPEC (Task 171): the home artwork (rollboxbackground.jpg) is the
 * DEFAULT backdrop for EVERY page — except the pages that already dress
 * themselves: /upgrader and /battles (own uploaded artworks, Task 170) and
 * /event (own event-bg.jpg). The TERMINAL is exempt too — it owns the whole
 * viewport with its own full-screen background (plain SiteShell mode).
 * Mounted once in the root layout, right above the corridor canvas: no
 * remount flicker between routes, warp transitions stay smooth.
 */
const EXEMPT_PREFIXES = ["/upgrader", "/battles", "/event", "/terminal"];

export function DefaultBackdrop() {
  const pathname = usePathname();
  if (EXEMPT_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`))) {
    return null;
  }
  return <PageBackdrop src="/rollboxbackground.jpg" />;
}
