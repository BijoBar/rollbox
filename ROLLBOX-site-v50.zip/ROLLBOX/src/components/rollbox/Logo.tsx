import { cn } from "@/lib/utils";

/**
 * ROLLBOX brand mark — a gold crate caught mid-spin inside a fuchsia orbit
 * ring ("ROLL") with a bolt on the front face for the unboxing energy.
 * Palette mirrors the site theme: violet → fuchsia → gold
 * (.text-gradient-neon / .neon-btn). Gradient ids are document-scoped but
 * identical across instances, which is safe: browsers resolve the first
 * matching def and both instances render the same.
 */
export function RollboxMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="rbTop" x1="12" y1="10" x2="36" y2="22" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FFF3C4" />
          <stop offset="1" stopColor="#F0B90B" />
        </linearGradient>
        <linearGradient id="rbLeft" x1="12" y1="16" x2="24" y2="37" gradientUnits="userSpaceOnUse">
          <stop stopColor="#92400E" />
          <stop offset="1" stopColor="#6D330C" />
        </linearGradient>
        <linearGradient id="rbRight" x1="24" y1="22" x2="36" y2="37" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FBBF24" />
          <stop offset="1" stopColor="#D97706" />
        </linearGradient>
        <linearGradient id="rbOrbit" x1="4" y1="13" x2="44" y2="37" gradientUnits="userSpaceOnUse">
          <stop stopColor="#E879F9" />
          <stop offset="1" stopColor="#C026D3" />
        </linearGradient>
      </defs>

      {/* orbit — back half, behind the crate */}
      <path
        d="M4 25 A20 11.5 0 0 1 44 25"
        stroke="url(#rbOrbit)"
        strokeWidth="2.6"
        strokeLinecap="round"
        opacity="0.55"
      />

      {/* crate */}
      <path d="M24 10 L36 16 L24 22 L12 16 Z" fill="url(#rbTop)" />
      <path d="M12 16 L24 22 L24 37 L12 31 Z" fill="url(#rbLeft)" />
      <path d="M36 16 L24 22 L24 37 L36 31 Z" fill="url(#rbRight)" />
      {/* lid seam on the top face */}
      <path
        d="M24 12.4 L33.6 17.2 L24 22 L14.4 17.2 Z"
        stroke="rgba(255,255,255,0.4)"
        strokeWidth="0.8"
        fill="none"
      />
      {/* center seam */}
      <path d="M24 22 L24 37" stroke="rgba(124,45,18,0.4)" strokeWidth="1" />
      {/* bolt on the front-right face */}
      <path d="M30.6 21.8 L26.4 27.6 L28.9 27.6 L27.4 32.6 L32.2 26.2 L29.7 26.2 Z" fill="#FFFFFF" opacity="0.95" />

      {/* orbit — front half, wrapping in front of the crate */}
      <path
        d="M4 25 A20 11.5 0 0 0 42.9 23.4"
        stroke="url(#rbOrbit)"
        strokeWidth="2.6"
        strokeLinecap="round"
      />
      {/* orbit arrowhead */}
      <path d="M41.6 19.6 L46.2 21.8 L42.2 25.6 Z" fill="#E879F9" />

      {/* winner sparkle */}
      <path
        d="M39.5 4.5 L40.7 7.3 L43.5 8.5 L40.7 9.7 L39.5 12.5 L38.3 9.7 L35.5 8.5 L38.3 7.3 Z"
        fill="#FDE68A"
        opacity="0.95"
      />
    </svg>
  );
}

/**
 * Full logo lockup: neon chip + mark + gradient wordmark.
 * `size="sm"` for the footer, default for the top bar, `size="lg"` for the
 * USER SPEC enlarged logo (footer), `size="xl"` for the USER SPEC (Task 33)
 * top-bar logo — +50% over `lg` so the brand leads the games row,
 * `size="2xl"` for the USER SPEC (Task 168) top-bar logo — the CASES link
 * was removed to make room and the brand leads the header even harder.
 * `hideWordmarkOnMobile` collapses the lockup to the mark only below `sm`
 * (used by the top bar so the header row fits 360-390px phone viewports).
 */
export function Logo({
  size = "md",
  className,
  hideWordmarkOnMobile = false,
}: {
  size?: "sm" | "md" | "lg" | "xl" | "2xl";
  className?: string;
  hideWordmarkOnMobile?: boolean;
}) {
  const iconCls =
    size === "sm"
      ? "h-8 w-8"
      : size === "lg"
        ? "h-10 w-10 sm:h-11 sm:w-11"
        : size === "xl"
          ? "h-15 w-15 sm:h-[66px] sm:w-[66px]"
          : size === "2xl"
            ? "h-16 w-16 sm:h-[70px] sm:w-[70px]"
            : "h-9 w-9";
  const wordCls =
    size === "sm"
      ? "h-8"
      : size === "lg"
        ? "h-11 sm:h-12"
        : size === "xl"
          ? "h-16 sm:h-[72px]"
          : size === "2xl"
            ? "h-16 sm:h-[84px]"
            : "h-9 sm:h-10";
  return (
    <span className={cn("flex items-center gap-2", className)}>
      {/* USER SPEC (Task 45): the OFFICIAL logo art — the wide dice + wordmark
          (public/rollboxlogo.png); on phones the dice-only crop keeps the row
          compact when the wordmark is hidden */}
      <img
        src="/rollboxlogo-icon.png"
        alt="ROLLBOX"
        className={cn("shrink-0", iconCls, hideWordmarkOnMobile ? "sm:hidden" : "hidden")}
        draggable={false}
      />
      <img
        src="/rollboxlogo.png"
        alt="ROLLBOX"
        className={cn(
          "w-auto object-contain",
          wordCls,
          hideWordmarkOnMobile && "hidden sm:block"
        )}
        draggable={false}
      />
    </span>
  );
}
