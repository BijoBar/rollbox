"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Coins, History, PackageOpen, Zap } from "lucide-react";
import { formatCoins } from "@/lib/cases";
import { useSession } from "@/lib/session";
import { useRealtimeEvent } from "@/lib/realtime";
import { sfx } from "@/lib/sound";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";
import { useMounted } from "@/hooks/use-mounted";

/* ===== USER SPEC (Task 83): the dedicated BALANCE HISTORY page =====
   The server's money ledger — EVERY move it ever validated for this account
   (bonuses, entries, refunds, wins, trades) — with account totals on top and
   the full table under them. Moved OFF the profile: the header button lands
   here, the profile stays clean. Live: any server money-move reloads it. */

/** One row of the money ledger — the server's own audit trail. */
interface LedgerRow {
  id: number;
  kind: string;
  amount: number;
  balanceAfter: number;
  ref: string | null;
  at: number;
}

interface LedgerData {
  ledger: LedgerRow[];
  balance: number;
  totals: { credits: number; spent: number; net: number; count: number; showing: number };
}

const LEDGER_LABELS: Record<string, string> = {
  signup: "First-login bonus",
  daily: "Daily bonus",
  topup: "Wallet deposit (demo)",
  open_entry: "Case opening — entry",
  open_win: "Case opening — wins",
  trade_buy: "Exchange — bought a skin",
  trade_sell: "Exchange — sold skin(s)",
  battle_entry: "Battle entry",
  battle_refund: "Battle refund",
  battle_win: "Battle winnings",
  upgrader_win: "Upgrader — upgrade won",
  upgrader_loss: "Upgrader — stake lost",
};

export function BalanceHistoryView() {
  const mounted = useMounted();
  const { player: me } = useSession();
  const [data, setData] = useState<LedgerData | null>(null);

  const loadLedger = async () => {
    try {
      const r = await fetch("/api/ledger?take=200", { cache: "no-store" });
      if (!r.ok) return;
      setData((await r.json()) as LedgerData);
    } catch {
      /* the next balance push reloads it */
    }
  };

  // REALTIME (Task 64): whenever the server moves this player's money, the
  // page reloads — the history is always the server's latest truth.
  useRealtimeEvent("player", () => {
    if (me) void loadLedger();
  });

  const meId = me?.id ?? null;
  useEffect(() => {
    if (!meId) return;
    // deferred one tick — off the effect's sync body (react-hooks rule)
    const timer = window.setTimeout(() => void loadLedger(), 0);
    return () => window.clearTimeout(timer);
  }, [meId]);

  const rows = mounted ? (data?.ledger ?? []) : [];
  const totals = data?.totals;

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-8" aria-label="Balance history">

        <div className="relative mx-auto max-w-5xl px-4">
          {/* header */}
          <div className="flex items-center gap-3">
            <Link
              href="/profile"
              onClick={() => sfx.click()}
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
              aria-label="Back to the profile"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <div>
              <h1 className="font-display text-2xl font-black tracking-wide text-white sm:text-3xl">
                BALANCE <span className="text-gradient-neon">HISTORY</span>
              </h1>
              <p className="text-xs font-semibold text-white/45">
                Every coin move the SERVER validated for your account — bonuses, entries, refunds, wins and trades.
              </p>
            </div>
          </div>

          {/* totals strip — computed over EVERY row of the account */}
          {totals && totals.count > 0 && (
            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { label: "Total Credits", value: totals.credits, color: "text-emerald-300" },
                { label: "Total Spent", value: totals.spent, color: "text-rose-300" },
                { label: "Net Result", value: totals.net, color: totals.net >= 0 ? "text-sky-300" : "text-rose-300" },
                { label: "Current Balance", value: data?.balance ?? 0, color: "text-amber-300" },
              ].map((s) => (
                <div key={s.label} className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3 text-center">
                  <p className={`font-display flex items-center justify-center gap-1 text-xl font-black ${s.color}`} dir="ltr">
                    <Coin /> {formatCoins(s.value)}
                  </p>
                  <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wide text-white/45">{s.label}</p>
                </div>
              ))}
            </div>
          )}

          {/* the ledger */}
          {!mounted || rows.length === 0 ? (
            <div className="mt-6 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-12 text-center">
              <PackageOpen className="mx-auto mb-3 h-10 w-10 text-white/25" />
              <p className="text-sm font-bold text-white/60">No money moves yet</p>
              <p className="mt-1 text-xs text-white/40">
                Open a case or join a battle — the server records every credit and every charge here, newest first.
              </p>
              <Link
                href="/#cases"
                className="neon-btn mt-4 inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-black text-white"
              >
                <Zap className="h-3.5 w-3.5" fill="currentColor" />
                Open a Case
              </Link>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="mt-6 rounded-2xl border border-emerald-500/20 bg-[#0c1310]/90 p-4 shadow-[0_0_40px_rgba(16,185,129,0.06)] sm:p-6"
              aria-label="Money ledger"
            >
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <p className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-white/45">
                  <History className="h-3.5 w-3.5 text-emerald-300" />
                  The ledger — newest first
                </p>
                {totals && totals.count > rows.length && (
                  <p className="text-[10px] font-bold text-white/35" dir="ltr">
                    showing the latest {rows.length} of {totals.count.toLocaleString()} moves
                  </p>
                )}
              </div>
              <div className="overflow-hidden rounded-xl border border-white/10">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-white/[0.04] text-[10px] uppercase tracking-wider text-white/45">
                      <th className="px-3 py-2 font-black">Move</th>
                      <th className="px-3 py-2 font-black">Amount</th>
                      <th className="hidden px-3 py-2 font-black sm:table-cell">Balance after</th>
                      <th className="px-3 py-2 text-right font-black">When</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row) => (
                      <tr key={row.id} className="border-t border-white/5">
                        <td className="px-3 py-2 font-bold text-white/80" dir="ltr">
                          {LEDGER_LABELS[row.kind] ?? row.kind}
                          {row.ref ? <span className="ml-1 text-white/35">• {row.ref}</span> : null}
                        </td>
                        <td
                          className={`font-display px-3 py-2 font-black ${row.amount >= 0 ? "text-emerald-300" : "text-rose-300"}`}
                          dir="ltr"
                        >
                          {row.amount >= 0 ? "+" : "-"}
                          <Coin /> {formatCoins(Math.abs(row.amount))}
                        </td>
                        <td className="font-display hidden px-3 py-2 font-bold text-amber-300 sm:table-cell" dir="ltr">
                          <Coin /> {formatCoins(row.balanceAfter)}
                        </td>
                        <td className="px-3 py-2 text-right text-white/40" dir="ltr">
                          {new Date(row.at).toLocaleString("en-US", {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: false,
                          })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {/* the server note */}
          <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[11px] text-white/35">
            <Coins className="h-3 w-3" aria-hidden="true" />
            Straight from the server&apos;s audit trail — the same numbers every device and every battle runs on.
          </p>
        </div>
      </main>
    </SiteShell>
  );
}
