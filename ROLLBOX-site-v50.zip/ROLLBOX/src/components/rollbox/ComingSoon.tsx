"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, CalendarClock, CircleHelp, Construction, Target, TrendingUp, type LucideIcon } from "lucide-react";
import { sfx } from "@/lib/sound";
import { SiteShell } from "./SiteShell";

/* ===== USER SPEC (Task 29): the placeholder pages =====
   EVENT / MISSIONS / UPGRADE / FAQ are empty for now — each route renders
   this shared "COMING SOON" board until its real content is built. The icon
   travels as a NAME (server pages cannot pass a component function across
   the server/client boundary) and is resolved here. */

const ICONS: Record<string, LucideIcon> = {
  calendar: CalendarClock,
  target: Target,
  trending: TrendingUp,
  help: CircleHelp,
};

export function ComingSoon({
  title,
  icon,
  blurb,
}: {
  title: string;
  icon: keyof typeof ICONS | string;
  blurb: string;
}) {
  const Icon = ICONS[icon] ?? Construction;
  return (
    <SiteShell>
      <main
        className="relative flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 pb-20 pt-10"
        aria-label={`${title} — coming soon`}
      >
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-white/10 bg-[#130d22] px-8 py-14 text-center"
        >
          {/* soft neon glow behind the card content */}
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "radial-gradient(60% 55% at 50% 30%, rgba(217,70,239,0.16), transparent 70%), radial-gradient(45% 40% at 50% 85%, rgba(16,185,129,0.10), transparent 70%)",
            }}
            aria-hidden="true"
          />

          <div className="relative">
            <span className="mx-auto grid h-16 w-16 place-items-center rounded-2xl border border-fuchsia-400/30 bg-fuchsia-500/10 shadow-[0_0_24px_rgba(217,70,239,0.25)]">
              <Icon className="h-8 w-8 text-fuchsia-300" />
            </span>

            <h1 className="font-display mt-6 flex items-center justify-center gap-2 text-2xl font-black uppercase tracking-widest text-white sm:text-3xl">
              {title}
            </h1>

            <p className="font-display mt-4 text-3xl font-black tracking-[0.35em] sm:text-4xl">
              <span className="text-gradient-neon">COMING SOON</span>
            </p>

            <p className="mx-auto mt-4 max-w-sm text-sm font-semibold leading-relaxed text-white/50">
              {blurb}
            </p>

            <div
              className="mx-auto mt-6 flex w-fit items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-1.5 text-[11px] font-black uppercase tracking-widest text-white/45"
              aria-hidden="true"
            >
              <Construction className="h-3.5 w-3.5" />
              Under construction
            </div>

            <Link
              href="/"
              onClick={() => sfx.click()}
              className="mt-8 inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/[0.05] px-5 py-2.5 text-sm font-bold text-white/80 transition-colors hover:border-fuchsia-400/40 hover:bg-white/[0.08] hover:text-white"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to the cases
            </Link>
          </div>
        </motion.div>
      </main>
    </SiteShell>
  );
}
