"use client";

import { useMemo } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ShieldCheck, Coins, PackageOpen } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";

function SteamLogo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M11.98 2C6.53 2 2.07 6.26 1.8 11.64l5.35 2.21a2.9 2.9 0 0 1 1.7-.55h.15l2.38-3.45v-.05a3.88 3.88 0 1 1 3.88 3.88h-.1l-3.4 2.42v.12a2.92 2.92 0 1 1-5.83.14L2.3 14.6A10.2 10.2 0 0 0 11.98 22c5.65 0 10.23-4.48 10.23-10S17.63 2 11.98 2Zm-4.4 14.6.98.4a2.19 2.19 0 1 0 1.21-2.87l1.02.42a1.61 1.61 0 1 1-1.24 2.98l-1.97-.82Zm11.06-7.08a2.59 2.59 0 1 0-5.18 0 2.59 2.59 0 0 0 5.18 0Zm-4.53 0a1.95 1.95 0 1 1 3.9 0 1.95 1.95 0 0 1-3.9 0Z" />
    </svg>
  );
}

const ERRORS: Record<string, string> = {
  steam: "Steam did not confirm the sign-in — please try again.",
};

export function LoginView() {
  const params = useSearchParams();

  // everything derives straight from the URL — no effect, no state churn
  const { error, steamHref } = useMemo(() => {
    const err = params.get("error");
    const back = params.get("next");
    const qs = back ? `?next=${encodeURIComponent(back)}` : "";
    return {
      error: err ? ERRORS[err] ?? "Sign-in failed — please try again." : null,
      steamHref: `/api/auth/steam/start${qs}`,
    };
  }, [params]);

  return (
    <main className="relative flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 pb-20 pt-10" aria-label="Account sign in">

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="relative w-full max-w-md"
      >
        <div className="mb-6 text-center">
          <span className="relative mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl neon-btn">
            <ShieldCheck className="h-9 w-9 text-white" />
          </span>
          <h1 className="font-display text-3xl font-black tracking-wide text-white">
            SIGN IN <span className="text-gradient-neon">&amp; PLAY</span>
          </h1>
          <p className="mt-2 text-sm text-white/55">
            STEAM is the only way in — one account keeps your coins, battles and drops on every device, against
            players worldwide.
          </p>
        </div>

        <div className="rounded-2xl border border-violet-500/25 bg-[#100a1e]/90 p-6 shadow-[0_0_50px_rgba(124,58,237,0.2)] backdrop-blur">
          {error && (
            <p role="alert" className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs font-bold text-red-300">
              {error}
            </p>
          )}

          <div className="space-y-3">
            <a
              href={steamHref}
              onClick={() => sfx.click()}
              className={cn(
                "flex h-14 w-full items-center justify-center gap-3 rounded-xl border border-sky-400/30 bg-gradient-to-r from-[#171a21] to-[#1f2937]",
                "text-base font-black text-white transition-all hover:border-sky-300/60 hover:shadow-[0_0_24px_rgba(56,189,248,0.35)]"
              )}
              aria-label="Sign in with Steam"
            >
              <SteamLogo className="h-6 w-6 text-sky-300" />
              Sign in with STEAM
            </a>
          </div>

          <p className="mt-4 text-center text-[11px] font-semibold leading-relaxed text-white/45">
            New account? You start with an{" "}
            <span className="font-black text-amber-300">empty balance</span> — make your
            first deposit in the wallet to open cases, and watch for the
            FREE chip on gifted cases.
          </p>

          <div className="mt-5 grid grid-cols-3 gap-2 text-center">
            {[
              { icon: Coins, label: "Global coin economy" },
              { icon: PackageOpen, label: "Shared live drops" },
              { icon: ShieldCheck, label: "Server-rolled & fair" },
            ].map((f) => (
              <div key={f.label} className="rounded-lg border border-white/5 bg-white/[0.03] px-2 py-2.5">
                <f.icon className="mx-auto mb-1 h-4 w-4 text-violet-300" />
                <p className="text-[10px] font-bold leading-tight text-white/50">{f.label}</p>
              </div>
            ))}
          </div>
        </div>

        <p className="mt-4 text-center text-xs leading-relaxed text-white/40">
          Demo entertainment site — no real money, no skins change hands. By continuing you accept the{" "}
          <Link href="/tos" className="font-bold text-white/60 underline underline-offset-2 hover:text-white">
            Terms of Service
          </Link>
          .
        </p>
      </motion.div>
    </main>
  );
}
