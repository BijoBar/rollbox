"use client";

/** USER SPEC (Task 26): on every skin registered as a SOUVENIR the word
 *  "Souvenir" itself renders in YELLOW — the rest of the line keeps the
 *  surface's own styling. Steam tournament-quality stock carries the word in
 *  the weapon line ("Souvenir AK-47"); catalog drops never do, so the helper
 *  is a harmless passthrough for them. Renders inline — drop it INSIDE the
 *  existing <p>/<span> so truncation + dir stay on the parent. */
export function WeaponLabel({ text }: { text: string }) {
  const idx = text.indexOf("Souvenir");
  if (idx === -1) return <>{text}</>;
  return (
    <>
      {text.slice(0, idx)}
      <span className="text-yellow-300" title="Souvenir quality">
        Souvenir
      </span>
      {text.slice(idx + "Souvenir".length)}
    </>
  );
}
