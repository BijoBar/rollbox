"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Clock, Lock, Sparkles } from "lucide-react";
import { type CaseDef } from "@/lib/cases";
import { caseDailyNextIn, formatCountdown, levelFromXp } from "@/lib/progress";
import { useCaseStore } from "@/lib/store";
import { CaseImage } from "./CaseImage";
import { sfx } from "@/lib/sound";
import { cn } from "@/lib/utils";

/** The per-case 24h gates as reported by /api/daily (signed-in players only):
 *  Record<caseId, { ready, nextIn }>. */
export type DailyCases = Record<string, { ready: boolean; nextIn: number }> | null;

/**
 * USER SPEC (Task 104): one card of the 10 free DAILY cases in the "Special
 * for you" category. Per-player states:
 *  - LOCKED  — the required level hasn't been reached yet
 *  - WAITING — unlocked, this case's own 24h cooldown is running (countdown)
 *  - READY   — unlocked and cooled down: Open Free
 * EVERY case up to the player's level opens FREE once per 24h — not just one.
 * Each card still opens the case page (contents teaser, provably fair).
 */
export function LevelCaseCard({
  caseDef,
  index,
  serverCases,
  signedIn,
}: {
  caseDef: CaseDef;
  index: number;
  serverCases: DailyCases;
  signedIn: boolean;
}) {
  const xp = useCaseStore((s) => s.xp);
  const dailyOpens = useCaseStore((s) => s.dailyOpens);
  const lvl = levelFromXp(xp).level;
  const required = caseDef.requiredLevel ?? 0;
  const locked = lvl < required;
  const serverNext = signedIn ? (serverCases?.[caseDef.id]?.nextIn ?? null) : null;
  const nextIn = signedIn ? (serverNext ?? 0) : caseDailyNextIn(dailyOpens, caseDef.id);
  const waiting = !locked && nextIn > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.45, delay: (index % 5) * 0.06 }}
      className="min-w-0"
    >
      <Link
        href={`/case/${caseDef.id}`}
        onClick={() => sfx.click()}
        aria-label={`${caseDef.name} — free daily case, requires level ${required}`}
        className={cn("group relative block min-w-0", locked && "opacity-55 saturate-50")}
      >
        <div
          className="relative flex flex-col overflow-hidden rounded-2xl border bg-[#120c20]/90 transition-[border-color,box-shadow,transform] duration-300 group-hover:-translate-y-1"
          style={{
            borderColor: caseDef.tierColor + (!locked && !waiting ? "99" : "44"),
            boxShadow: `0 10px 40px -12px ${caseDef.tierColor}${!locked && !waiting ? "55" : "22"}`,
          }}
        >
          {/* top gradient line */}
          <div
            className="h-1 w-full"
            style={{ background: `linear-gradient(90deg, ${caseDef.tierColor}, ${caseDef.tierColor2})` }}
            aria-hidden="true"
          />

          <div className="relative flex flex-col items-center px-4 pb-4 pt-6">
            {/* code chip */}
            <span className="absolute left-3.5 top-3.5 rounded-md border border-white/15 bg-black/40 px-2 py-1 font-mono text-[10px] font-black tracking-widest text-white/60">
              {caseDef.code}
            </span>

            {/* status chip */}
            {locked ? (
              <span className="absolute right-3.5 top-3.5 flex items-center gap-1 rounded-full border border-white/20 bg-black/50 px-2 py-1 text-[10px] font-black text-white/60">
                <Lock className="h-3 w-3" />
                LVL {required}
              </span>
            ) : waiting ? (
              <span className="absolute right-3.5 top-3.5 flex items-center gap-1 rounded-full border border-amber-400/40 bg-amber-500/10 px-2 py-1 text-[10px] font-black text-amber-300">
                <Clock className="h-3 w-3" />
                COOLDOWN
              </span>
            ) : (
              <span
                className="absolute right-3.5 top-3.5 flex items-center gap-1 rounded-full border px-2 py-1 text-[10px] font-black"
                style={{
                  borderColor: caseDef.tierColor + "66",
                  color: caseDef.tierColor,
                  background: caseDef.tierColor + "1a",
                }}
              >
                <Sparkles className="h-3 w-3" />
                READY
              </span>
            )}

            {/* art */}
            <div className="relative mt-2 w-36 transition-transform duration-300 group-hover:scale-105 md:w-40">
              <div
                className="absolute inset-0 -z-10 blur-2xl"
                style={{ background: `radial-gradient(circle at 50% 60%, ${caseDef.tierColor}30, transparent 65%)` }}
                aria-hidden="true"
              />
              <CaseImage
                caseId={caseDef.id}
                alt={caseDef.name}
                color={caseDef.tierColor}
                color2={caseDef.tierColor2}
                communityDesign={caseDef.communityDesign}
                className="w-full"
                sizes="(max-width: 640px) 45vw, 176px"
              />
            </div>

            <h3 className="mt-2.5 text-xl font-black text-white">{caseDef.name}</h3>

            {/* state button */}
            {locked ? (
              <span className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 py-3 text-sm font-black text-white/45">
                <Lock className="h-4 w-4" />
                Requires Level {required}
              </span>
            ) : waiting ? (
              <span className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 py-3 text-sm font-black text-white/60">
                <Clock className="h-4 w-4 text-amber-300" />
                Ready in {formatCountdown(nextIn)}
              </span>
            ) : (
              <span
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-base font-black text-[#04121a]"
                style={{
                  background: `linear-gradient(94deg, ${caseDef.tierColor2}, ${caseDef.tierColor})`,
                  boxShadow: `0 0 22px ${caseDef.tierColor}55, inset 0 1px 0 rgba(255,255,255,0.3)`,
                }}
              >
                <Sparkles className="h-4 w-4" />
                Open Free
              </span>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
