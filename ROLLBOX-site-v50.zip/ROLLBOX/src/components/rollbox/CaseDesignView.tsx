"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowLeft, CheckCircle2, Package, PenLine, Rocket, Upload } from "lucide-react";
import { caseItemValue, formatCoins } from "@/lib/cases";
import { COMMUNITY_DESIGNS, DESIGN_ART, type CommunityDesign } from "@/lib/community-designs";
import { builderComplete, useCaseBuilder } from "@/lib/case-builder";
import { useSession } from "@/lib/session";
import { sfx } from "@/lib/sound";
import { useToast } from "@/hooks/use-toast";
import { useMounted } from "@/hooks/use-mounted";
import { Coin } from "./Coin";

/**
 * USER SPEC (Task 142) — CASE BUILDER, step 2/2.
 * The three crate artworks sit LARGE on the LEFT of the page arranged as a
 * half-circle; the middle of the screen (right of the choices) holds the free
 * text name field. Once the case has a name and the drop chances total 100%,
 * PUBLISH CASE writes it straight to the DB where every player can open it.
 */

/** The half-circle arc placement — upper semicircle, left → top → right.
 *  Percent-based so the arc survives container resizing (USER SPEC: the
 *  three artworks sit LARGE on the LEFT side of the page as a half circle). */
const ARC_POSITIONS = [
  { left: 23, top: 68 },
  { left: 50, top: 34 },
  { left: 77, top: 68 },
];
const ART_SIZE = 150;

export function CaseDesignView() {
  const mounted = useMounted();
  const router = useRouter();
  const { toast } = useToast();
  const { player: me } = useSession();

  const items = useCaseBuilder((s) => s.items);
  const name = useCaseBuilder((s) => s.name);
  const design = useCaseBuilder((s) => s.design);
  const setName = useCaseBuilder((s) => s.setName);
  const setDesign = useCaseBuilder((s) => s.setDesign);
  const reset = useCaseBuilder((s) => s.reset);

  const [busy, setBusy] = useState(false);
  // once PUBLISH succeeds the store resets (items → 0) — this ref stops the
  // empty-draft guard from hijacking the redirect to the published case
  const publishedRef = useRef(false);
  const complete = builderComplete(items);
  const nameValid = name.trim().length >= 3 && name.trim().length <= 32;
  const canPublish = complete && nameValid && !!design && !busy && !!me;

  // the draft rides over from step 1 in sessionStorage — no draft, no page
  useEffect(() => {
    if (mounted && !publishedRef.current && items.length === 0) router.replace("/case-builder");
  }, [mounted, items.length, router]);

  // the automatic site price — the same math the server re-runs on publish
  const price = useMemo(() => {
    const ev = items.reduce((sum, i) => sum + (i.weight / 100) * caseItemValue({ skinId: i.skinId, weight: i.weight }), 0);
    return Math.max(0.5, Math.ceil((ev / 0.85) * 100) / 100);
  }, [items]);

  const publish = async () => {
    if (!canPublish || !design) return;
    setBusy(true);
    try {
      const r = await fetch("/api/community-cases", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), design, items }),
      });
      const d = (await r.json()) as { id?: string; error?: string };
      if (!r.ok || !d.id) throw new Error(d.error ?? "Could not publish the case");
      sfx.coins();
      toast({
        title: "Your case is LIVE!",
        description: `“${name.trim()}” is now openable by every player on ROLLBOX.`,
      });
      publishedRef.current = true;
      reset();
      router.push(`/case/${d.id}`);
    } catch (e) {
      sfx.error();
      toast({ title: e instanceof Error ? e.message : "Could not publish the case", variant: "destructive" });
      setBusy(false);
    }
  };

  if (!mounted) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 py-10" aria-label="Create your own case — design and name">
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="text-center">
        <h1 className="text-3xl font-black text-white md:text-4xl">
          Design <span className="text-gradient-neon">your case</span>
        </h1>
        <p className="mt-2 text-xs font-semibold tracking-wide text-white/45">
          STEP 2 OF 2 — PICK THE CRATE ARTWORK, GIVE IT A NAME, THEN PUBLISH
        </p>
      </motion.div>

      <div className="mt-8 grid items-start gap-6 lg:grid-cols-[minmax(320px,440px)_1fr]">
        {/* ===== the three artworks, LARGE, arranged as a half-circle (left) ===== */}
        <div className="relative mx-auto h-[320px] w-full max-w-[440px]" data-testid="design-arc" aria-label="Pick a crate design">
          {COMMUNITY_DESIGNS.map((d: CommunityDesign, i) => {
            const pos = ARC_POSITIONS[i];
            return (
              <button
                key={d}
                type="button"
                onClick={() => {
                  setDesign(d);
                  sfx.click();
                }}
                aria-label={`Pick the ${d} crate design`}
                aria-pressed={design === d}
                className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
                style={{ left: `${pos.left}%`, top: `${pos.top}%`, zIndex: design === d ? 30 : 10 }}
                data-design={d}
                data-testid={`design-${d}`}
              >
                <span
                  className={
                    "block overflow-hidden rounded-2xl border-2 transition-all duration-300 " +
                    (design === d
                      ? "scale-110 border-emerald-400 shadow-[0_0_40px_rgba(52,211,153,0.45)]"
                      : "border-white/15 opacity-80 hover:scale-105 hover:opacity-100")
                  }
                  style={{ width: ART_SIZE, height: ART_SIZE * 0.82 }}
                >
                  { }
                  <img src={DESIGN_ART[d]} alt={`${d} crate`} className="h-full w-full select-none object-cover" draggable={false} />
                </span>
                {design === d && (
                  <span className="mx-auto mt-1.5 flex w-fit items-center gap-1 rounded-full bg-emerald-500 px-2 py-0.5 text-[9px] font-black uppercase tracking-widest text-black">
                    <CheckCircle2 className="h-3 w-3" /> Picked
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* ===== center of the screen: name + recap + PUBLISH (right of the choices) ===== */}
        <div className="flex flex-col gap-4">
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <p className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-white/60">
              <PenLine className="h-4 w-4 text-violet-300" />
              Name your case
            </p>
            <input
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, 40))}
              dir="ltr"
              maxLength={40}
              placeholder="Type any name for your case…"
              aria-label="Case name"
              data-testid="builder-name"
              className="font-display mt-3 h-12 w-full rounded-xl border border-white/15 bg-black/40 px-4 text-lg font-black text-white placeholder:font-semibold placeholder:text-white/25 focus:border-violet-400/70 focus:outline-none"
            />
            <p className={"mt-1.5 text-[10px] font-bold " + (nameValid ? "text-emerald-300" : "text-white/35")} dir="ltr">
              {nameValid ? `${name.trim().length}/32 — looks good` : "3-32 characters"}
            </p>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <p className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-white/60">
              <Package className="h-4 w-4 text-amber-300" />
              Inside your case
            </p>
            <div className="mt-3 flex max-h-40 flex-wrap gap-2 overflow-y-auto" dir="ltr">
              {items.map((i) => (
                <span key={i.skinId} className="rounded-lg border border-white/10 bg-black/40 px-2 py-1 text-[10px] font-bold text-white/75">
                  {i.skinId} • {i.weight}%
                </span>
              ))}
            </div>
            <p className="mt-3 flex items-center justify-between text-xs font-bold text-white/55">
              <span>Automatic price</span>
              <span className="font-display flex items-center gap-1 text-sm font-black text-amber-300">
                <Coin className="h-3.5 w-3.5" /> {formatCoins(price)}
              </span>
            </p>
          </div>

          {/* PUBLISH CASE — bottom right (USER SPEC) */}
          <div className="flex items-center justify-end">
            <button
              type="button"
              disabled={!canPublish}
              onClick={() => void publish()}
              data-testid="publish-case"
              className="gold-btn flex h-12 items-center gap-2 rounded-xl px-7 text-sm font-black text-black disabled:cursor-not-allowed disabled:opacity-40"
            >
              {busy ? <Upload className="h-4 w-4 animate-pulse" /> : <Rocket className="h-4 w-4" />}
              {busy ? "PUBLISHING…" : "PUBLISH CASE"}
            </button>
          </div>
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                sfx.click();
                router.push("/case-builder");
              }}
              className="flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-[10px] font-black uppercase tracking-widest text-white/60 hover:bg-white/15 hover:text-white"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to skins
            </button>
            {!complete && (
              <p className="text-[10px] font-bold text-white/35">The drop chances must total exactly 100% to publish.</p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
