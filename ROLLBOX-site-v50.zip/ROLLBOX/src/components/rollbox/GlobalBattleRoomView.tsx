"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Lock, Swords } from "lucide-react";
import type { GlobalBattle } from "@/lib/gbattle-shared";
import { adaptGlobalBattle } from "@/lib/gbattle-adapter";
import { BattleRoomView } from "./BattleRoomView";
import { useSession } from "@/lib/session";
import { useCaseStore } from "@/lib/store";
import { useRealtimeEvent } from "@/lib/realtime";
import { CASES, formatCoins, type CaseDef } from "@/lib/cases";
import { SiteShell } from "./SiteShell";
import { Coin } from "./Coin";
import { useMounted } from "@/hooks/use-mounted";

function RoomShell({ text }: { text: string }) {
  return (
    <SiteShell>
      <main className="grid min-h-[calc(100vh-4rem)] place-items-center" aria-label="Battle room">
        <p className="text-xs font-bold uppercase tracking-widest text-white/30">{text}</p>
      </main>
    </SiteShell>
  );
}

/** MULTIPLAYER: polls the server battle and feeds the ORIGINAL room view a
 *  mirror (players, gated pulls, schedule) through the store — the view runs
 *  its untouched original engine on server data. The server is the only
 *  source of truth: it charges entries, rolls every pull, settles and pays. */
function GlobalBattleRoom({ roomId }: { roomId: string }) {
  const mounted = useMounted();
  const router = useRouter();
  const { player: me, loading, refresh, patch } = useSession();
  const myId = me?.id ?? "";
  const upsertServerBattle = useCaseStore((s) => s.upsertServerBattle);

  const [mirrorReady, setMirrorReady] = useState(false);
  const [cancelled, setCancelled] = useState(false);
  const [busy, setBusy] = useState(false);
  // USER SPEC (Task 67): a redacted PRIVATE view — this viewer is not seated;
  // the poll keeps the gate's minimal facts (status + entry) for the lock UI
  const [gate, setGate] = useState<{ status: string; entry: number; type: string } | null>(null);
  const settledRef = useRef(false);
  const refreshRef = useRef(refresh);
  refreshRef.current = refresh;
  // Task 141 fix: the realtime push used to refetch BEFORE the session's first
  // load finished — the mirror was then stamped with myId="" (no isYou seat),
  // the room locked into the SPECTATOR path and a seated player re-entering a
  // finished battle watched a full replay with the wrong VICTORY semantics.
  // The loadingRef gate keeps every fetch until `me` (and myId) is known.
  const loadingRef = useRef(true);
  useEffect(() => {
    loadingRef.current = loading;
  }, [loading]);

  // the room's own refetch, reachable from BOTH the fallback poll and the push
  const tickRef = useRef<() => void>(() => {});

  // USER SPEC (battles × COMMUNITY/EVENT): rounds may reference player-built
  // cc_* cases the static catalog doesn't know — their defs are fetched ONCE
  // from /api/cases/resolve and handed to the room view so the strip and the
  // reels render them exactly like official crates.
  const [extraCases, setExtraCases] = useState<CaseDef[]>([]);
  const extraRef = useRef<CaseDef[]>([]);
  extraRef.current = extraCases;
  const ensureCaseDefs = useCallback(async (rounds: string[]) => {
    const missing = [
      ...new Set(
        rounds.filter(
          (id) => !CASES.some((c) => c.id === id) && !extraRef.current.some((c) => c.id === id),
        ),
      ),
    ];
    if (missing.length === 0) return;
    try {
      const r = await fetch(`/api/cases/resolve?ids=${encodeURIComponent(missing.join(","))}`, {
        cache: "no-store",
      });
      if (!r.ok) return;
      const d = (await r.json()) as { cases?: CaseDef[] };
      if (Array.isArray(d.cases) && d.cases.length) {
        const merged = [
          ...extraRef.current,
          ...d.cases.filter((c) => !extraRef.current.some((e) => e.id === c.id)),
        ];
        extraRef.current = merged;
        setExtraCases(merged);
      }
    } catch {
      /* the next poll retries */
    }
  }, []);

  // REALTIME (Task 64): the server pushes "battle" the instant this room's
  // state advances (a round went public / the settle landed) — every viewer
  // applies the same state at the same moment. The poll stays as a net below.
  useRealtimeEvent("battle", (data) => {
    const e = data as { id?: string } | null;
    if (e?.id === roomId && !loadingRef.current) tickRef.current();
  });

  // the ONE server poll — the mirror in the store IS the battle the original
  // view renders. Gated by the session's first load so isYou stamps right.
  useEffect(() => {
    if (!mounted || loading) return;
    let stopped = false;
    let timer = 0;
    const tick = async () => {
      try {
        const r = await fetch(`/api/gbattles/${roomId}`, { cache: "no-store" });
        if (stopped) return;
        if (!r.ok) {
          // unknown room — the original view renders its "battle has ended" shell
          setMirrorReady(true);
          window.clearInterval(timer);
          return;
        }
        const data = (await r.json()) as { battle?: GlobalBattle };
        const gb = data.battle;
        if (stopped) return;
        if (!gb) {
          setMirrorReady(true);
          window.clearInterval(timer);
          return;
        }
        if (gb.status === "cancelled") {
          setCancelled(true);
          setMirrorReady(true);
          window.clearInterval(timer);
          return;
        }
        // USER SPEC (Task 67): PRIVATE + not seated → the server sent the
        // redacted view; never upsert it into the store, show the lock gate
        if (gb.redacted) {
          setGate({ status: gb.status, entry: gb.entry, type: gb.type });
          setMirrorReady(true);
          return;
        }
        setGate(null);
        upsertServerBattle(adaptGlobalBattle(gb, myId, Date.now() - gb.serverNow));
        void ensureCaseDefs(gb.rounds);
        setMirrorReady(true);
        if (gb.status === "finished") {
          window.clearInterval(timer);
          if (!settledRef.current) {
            settledRef.current = true;
            void refreshRef.current(); // the server credited the DB — pull the balance
          }
        }
      } catch {
        /* the poll keeps trying */
      }
    };
    void tick();
    tickRef.current = () => void tick();
    timer = window.setInterval(() => void tick(), 900);
    return () => {
      stopped = true;
      window.clearInterval(timer);
    };
  }, [mounted, loading, roomId, myId, upsertServerBattle, ensureCaseDefs]);

  const callBots = useCallback(async () => {
    setBusy(true);
    try {
      const r = await fetch(`/api/gbattles/${roomId}/bots`, { method: "POST" });
      const data = (await r.json()) as { battle?: GlobalBattle };
      if (r.ok && data.battle) {
        upsertServerBattle(adaptGlobalBattle(data.battle, myId, Date.now() - data.battle.serverNow));
      }
    } catch {
      /* the poll reconciles */
    } finally {
      setBusy(false);
    }
  }, [roomId, myId, upsertServerBattle]);

  // USER SPEC (Task 67): CHOOSE BOT — summon a SPECIFIC [RBbot] into a specific
  // empty seat straight from the room (no lobby vote needed for a manual pick)
  const chooseBot = useCallback(
    async (bot: string, team: 0 | 1 | null | undefined, side?: 0 | 1) => {
      setBusy(true);
      try {
        const r = await fetch(`/api/gbattles/${roomId}/bots`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ bot, team: team ?? undefined, side }),
        });
        const data = (await r.json()) as { battle?: GlobalBattle; error?: string };
        if (r.ok && data.battle) {
          upsertServerBattle(adaptGlobalBattle(data.battle, myId, Date.now() - data.battle.serverNow));
        }
      } catch {
        /* the poll reconciles */
      } finally {
        setBusy(false);
      }
    },
    [roomId, myId, upsertServerBattle]
  );

  const leave = useCallback(async () => {
    setBusy(true);
    try {
      const r = await fetch(`/api/gbattles/${roomId}/leave`, { method: "POST" });
      const data = (await r.json()) as { balance?: number };
      if (r.ok && typeof data.balance === "number") patch({ balance: data.balance });
    } catch {
      /* nothing to reconcile — we are leaving anyway */
    }
    router.push("/battles");
  }, [roomId, patch, router]);

  const join = useCallback(async () => {
    setBusy(true);
    try {
      const r = await fetch(`/api/gbattles/${roomId}/join`, { method: "POST" });
      const data = (await r.json()) as { balance?: number; error?: string };
      if (r.ok && typeof data.balance === "number") patch({ balance: data.balance });
      // the next poll seats you; the room flips to the original flow from there
    } catch {
      /* the poll reconciles */
    } finally {
      setBusy(false);
    }
  }, [roomId, patch]);

  const runItBack = useCallback(async () => {
    const st = useCaseStore.getState();
    // the live mirror first; a finished room may also sit in battleHistory
    // (older sessions moved it there) — either copy carries the room config
    const gb =
      st.battles.find((b) => b.id === roomId) ?? st.battleHistory.find((b) => b.id === roomId);
    if (!gb) return;
    setBusy(true);
    try {
      const r = await fetch("/api/gbattles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: gb.type,
          mode: gb.mode,
          potRule: gb.potRule,
          rounds: gb.rounds,
          private: gb.isPrivate ?? false, // USER SPEC (Task 67): a private room stays private
        }),
      });
      const data = (await r.json()) as { id?: string; balance?: number };
      if (r.ok && data.id) {
        if (typeof data.balance === "number") patch({ balance: data.balance });
        router.push(`/battles/${data.id}`);
      }
    } catch {
      /* stay in the room */
    } finally {
      setBusy(false);
    }
  }, [roomId, patch, router]);

  if (!mounted || (!mirrorReady && !cancelled)) return <RoomShell text="Loading room…" />;

  // USER SPEC (Task 67): the PRIVATE lock — non-seated visitors can join a
  // waiting seat (with the code/link they came from) but never WATCH the room
  if (gate) {
    const open = gate.status === "waiting";
    return (
      <SiteShell>
        <main className="grid min-h-[calc(100vh-4rem)] place-items-center px-4 pb-20 pt-10" aria-label="Private battle">
          <div className="w-full max-w-md rounded-2xl border border-amber-400/25 bg-[#0d0819]/90 p-8 text-center">
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl border border-amber-400/40 bg-amber-400/10">
              <Lock className="h-6 w-6 text-amber-300" />
            </span>
            <h1 className="font-display mt-4 text-2xl font-black tracking-wide text-white">PRIVATE BATTLE</h1>
            <p className="mt-2 text-sm font-semibold text-white/50">
              {open
                ? me
                  ? "This room is invisible to everyone else — you are here through its code or link. Take the open seat to step in."
                  : "This room is invisible to everyone else. Sign in with Steam to take the open seat."
                : "Only the players seated in this room can watch it — the fight stays behind the lock."}
            </p>
            <div className="mt-6 flex flex-col items-center gap-2">
              {open &&
                (me ? (
                  <button
                    onClick={() => void join()}
                    disabled={busy}
                    className="gold-btn flex items-center gap-2 rounded-xl px-7 py-3 text-sm font-black text-black shadow-[0_0_16px_rgba(240,185,11,0.4)] disabled:opacity-40"
                  >
                    <Swords className="h-4 w-4" />
                    Join this battle — <Coin /> {formatCoins(gate.entry)}
                  </button>
                ) : (
                  <button
                    onClick={() => router.push(`/login?next=${encodeURIComponent(`/battles/${roomId}`)}`)}
                    className="gold-btn flex items-center gap-2 rounded-xl px-7 py-3 text-sm font-black text-black shadow-[0_0_16px_rgba(240,185,11,0.4)]"
                  >
                    Sign in with Steam
                  </button>
                ))}
              <button
                onClick={() => router.push("/battles")}
                className="flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-6 py-2.5 text-sm font-bold text-white/70 transition-colors hover:bg-white/10 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to battles
              </button>
            </div>
          </div>
        </main>
      </SiteShell>
    );
  }

  if (cancelled) {
    return (
      <SiteShell>
        <main className="grid min-h-[calc(100vh-4rem)] place-items-center px-4 pb-20 pt-10" aria-label="Battle room">
          <div className="text-center">
            <Swords className="mx-auto h-10 w-10 text-white/20" />
            <h1 className="font-display mt-4 text-2xl font-black text-white/70">The room was disbanded</h1>
            <p className="mt-2 text-sm font-semibold text-white/40">
              {me ? "Your entry was refunded to your balance." : "Nothing was charged."}
            </p>
            <button
              onClick={() => router.push("/battles")}
              className="neon-btn mx-auto mt-6 flex items-center gap-2 rounded-xl px-7 py-3 text-sm font-black text-white"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to battles
            </button>
          </div>
        </main>
      </SiteShell>
    );
  }

  return (
    <BattleRoomView
      battleId={roomId}
      extraCases={extraCases}
      serverActions={{
        callBots: () => void callBots(),
        chooseBot: (bot, team, side) => void chooseBot(bot, team, side),
        leave: () => void leave(),
        join: () => void join(),
        runItBack: () => void runItBack(),
        busy,
      }}
    />
  );
}

/** Routes /battles/[id]: a legacy LOCAL battle → the original room as-is;
 *  a server battle → the SAME original room fed by the server mirror. */
export function BattleRoomRouter({ id }: { id: string }) {
  const mounted = useMounted();
  const local = useCaseStore((s) => s.battles.find((b) => b.id === id && !b.global));
  if (!mounted) return <RoomShell text="Loading room…" />;
  if (local) return <BattleRoomView battleId={id} />;
  return <GlobalBattleRoom roomId={id} />;
}
