/**
 * USER SPEC (Task 170): per-page photo backdrops — the uploaded artwork fills
 * the viewport as a FIXED layer at HALF VISIBILITY (50% opacity), sitting
 * ABOVE the infinite corridor canvas (which paints at z-index -10) and BELOW
 * every piece of page content, so the eternal corridor scroll (idle crawl,
 * floating crates, warp) keeps breathing through the photo.
 * pointer-events-none + aria-hidden: purely decorative, never interactive.
 * Same half-visibility recipe the user approved for the event page's
 * /event-bg.jpg backdrop.
 */
export function PageBackdrop({ src }: { src: string }) {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 overflow-hidden"
      style={{ zIndex: -9 }}
    >
      <img
        src={src}
        alt=""
        draggable={false}
        className="h-full w-full select-none object-cover opacity-50"
      />
    </div>
  );
}
