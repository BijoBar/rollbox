"use client";

// USER SPEC (Task 180): a PERMANENTLY BANNED player now SIGNS IN normally —
// but the whole site is covered by this ban shield the moment the session
// reports bannedAt (instant on open tabs through the realtime "player" event,
// otherwise within one 15s me-heartbeat). It is the visible face of the same
// server-side block: every action route still refuses a banned session
// (sessionPlayer → null → 401), so the shield is honest — nothing can be
// played, deposited or withdrawn behind it.

import { Ban, LogOut } from "lucide-react";
import { useSession } from "@/lib/session";
import { Button } from "@/components/ui/button";

export function BanGuard() {
  const { player: me, refresh } = useSession();

  if (!me?.bannedAt) return null;
  const since = new Date(me.bannedAt);
  const shown = isNaN(since.getTime())
    ? null
    : since.toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });

  const handleSignOut = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    await refresh();
    window.location.href = "/";
  };

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#08050f]/[0.985] px-4 backdrop-blur-md"
      role="alertdialog"
      aria-label="Permanently banned from ROLLBOX"
    >
      <div className="relative w-full max-w-md rounded-2xl border border-red-500/30 bg-[#140a0e]/95 p-8 text-center shadow-[0_0_70px_rgba(239,68,68,0.15)]">
        <span className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-2xl border border-red-400/40 bg-red-500/10 shadow-[0_0_24px_rgba(239,68,68,0.3)]">
          <Ban className="h-8 w-8 text-red-300" />
        </span>
        <h1 className="font-display text-3xl font-black text-white">
          PERMANENTLY <span className="text-red-400">BANNED</span>
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-white/60">
          You are banned from ROLLBOX forever. Your account can no longer play, open cases, battle,
          deposit or withdraw — this decision cannot be appealed or undone.
        </p>
        {shown && (
          <div className="mt-6 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-4">
            <p className="text-[10px] font-black uppercase tracking-widest text-white/40">Banned since</p>
            <p className="font-display mt-1 text-xl font-black text-red-300" dir="ltr">
              {shown}
            </p>
          </div>
        )}
        <p className="mt-4 text-xs leading-relaxed text-white/40">
          The ban lives on the SERVER — clearing the browser, switching devices or signing in again
          will not lift it.
        </p>
        <Button
          variant="outline"
          onClick={handleSignOut}
          className="mt-6 w-full border-white/20 bg-white/5 font-bold text-white/80 hover:bg-white/10 hover:text-white"
        >
          <LogOut className="h-4 w-4" />
          Sign Out
        </Button>
      </div>
    </div>
  );
}
