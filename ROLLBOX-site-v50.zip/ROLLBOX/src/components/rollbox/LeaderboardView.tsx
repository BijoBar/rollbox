"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Box, Crown, Flame, Trophy, Users, Zap } from "lucide-react";
import { formatCoins } from "@/lib/cases";
import { levelTier } from "@/lib/progress";
import { useSession } from "@/lib/session";
import { sfx } from "@/lib/sound";
import { useMounted } from "@/hooks/use-mounted";
import { cn } from "@/lib/utils";
import { Coin } from "./Coin";
import { SiteShell } from "./SiteShell";

/* ===== USER SPEC (Task 22): the site-wide LEADERBOARD =====
   A dedicated page that ranks EVERY registered player (rank 1 → the full DB
   count) in three categories with NO weekly reset:
     • LEVEL — the database battle pass level
     • CASES OPENED — lifetime opens
     • BIGGEST WIN — the single most valuable drop ever landed
   TopBar's LEADERBOARD button lands here. */

interface LeaderRow {
  rank: number;
  id: string;
  name: string;
  avatar: string | null;
  level: number;
  value: number;
}

interface LeaderData {
  level: LeaderRow[];
  cases: LeaderRow[];
  biggest: LeaderRow[];
  total: number;
}

type TabId = "level" | "cases" | "biggest";

const TABS: { id: TabId; label: string; icon: typeof Zap }[] = [
  { id: "level", label: "Level", icon: Zap },
  { id: "cases", label: "Cases Opened", icon: Box },
  { id: "biggest", label: "Biggest Win", icon: Crown },
];

/** rank 1/2/3 get the medal chips, everyone else a plain number */
function RankBadge({ rank }: { rank: number }) {
  const style =
    rank === 1
      ? "border-amber-300/60 bg-amber-400/15 text-amber-300 shadow-[0_0_12px_rgba(251,191,36,0.45)]"
      : rank === 2
        ? "border-slate-300/50 bg-slate-300/10 text-slate-200 shadow-[0_0_10px_rgba(203,213,225,0.3)]"
        : rank === 3
          ? "border-orange-400/50 bg-orange-500/10 text-orange-300 shadow-[0_0_10px_rgba(251,146,60,0.3)]"
          : "border-white/10 bg-white/5 text-white/45";
  return (
    <span
      className={cn(
        "font-display grid h-8 w-8 shrink-0 place-items-center rounded-full border text-sm font-black",
        style,
      )}
      aria-label={`Rank ${rank}`}
    >
      {rank}
    </span>
  );
}

export function LeaderboardView() {
  const mounted = useMounted();
  const { player: me } = useSession();
  const [data, setData] = useState<LeaderData | null>(null);
  const [tab, setTab] = useState<TabId>("level");

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const r = await fetch("/api/leaderboard", { cache: "no-store" });
        if (!r.ok) return;
        const d = (await r.json()) as LeaderData;
        if (alive) setData(d);
      } catch {
        /* the next visit reloads */
      }
    };
    void load();
    // the board only moves when someone plays — a gentle refresh keeps it live
    const t = window.setInterval(() => void load(), 30000);
    return () => {
      alive = false;
      window.clearInterval(t);
    };
  }, []);

  const rows = mounted && data ? data[tab] : [];
  const valueLabel = (r: LeaderRow) =>
    tab === "level" ? `LVL ${r.value}` : tab === "cases" ? `${r.value}` : formatCoins(r.value);

  return (
    <SiteShell>
      <main className="relative min-h-[calc(100vh-4rem)] pb-20 pt-8" aria-label="Leaderboard">
        <div className="relative mx-auto max-w-3xl px-4">
          {/* header */}
          <div className="flex items-center gap-3">
            <Link
              href="/"
              onClick={() => sfx.click()}
              className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
              aria-label="Back to the home page"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <div>
              <h1 className="font-display flex items-center gap-2 text-2xl font-black tracking-wide text-white sm:text-3xl">
                <Trophy className="h-6 w-6 text-amber-300" />
                LEADER<span className="text-gradient-neon">BOARD</span>
              </h1>
              <p className="text-xs font-semibold text-white/45">
                Every registered player, ranked — {data ? `${data.total} players` : "loading..."} • no resets, the
                crown is forever.
              </p>
            </div>
          </div>

          {/* category tabs — USER SPEC: level / cases opened / biggest win */}
          <div className="mt-5 grid grid-cols-3 gap-2" role="tablist" aria-label="Leaderboard categories">
            {TABS.map((t) => {
              const Icon = t.icon;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => {
                    sfx.click();
                    setTab(t.id);
                  }}
                  className={cn(
                    "flex flex-col items-center gap-1 rounded-xl border px-2 py-2.5 text-[11px] font-black uppercase tracking-wide transition-colors sm:flex-row sm:justify-center sm:gap-1.5 sm:text-xs",
                    active
                      ? "border-amber-400/50 bg-amber-400/10 text-amber-300 shadow-[0_0_16px_rgba(251,191,36,0.25)]"
                      : "border-white/10 bg-white/[0.03] text-white/50 hover:bg-white/[0.06] hover:text-white/80",
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {t.label}
                </button>
              );
            })}
          </div>

          {/* the board */}
          {!mounted || rows.length === 0 ? (
            <div className="mt-6 rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-12 text-center">
              <Flame className="mx-auto mb-3 h-10 w-10 text-white/25" />
              <p className="text-sm font-bold text-white/60">{mounted ? "No players yet" : "Loading the ranks..."}</p>
              <p className="mt-1 text-xs text-white/40">
                The first open, battle or level sets the board on fire.
              </p>
            </div>
          ) : (
            <motion.ol
              key={tab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
              className="mt-5 space-y-2"
              aria-label={`Top players by ${tab}`}
            >
              {rows.map((r) => {
                const isMe = me?.id === r.id;
                const tier = levelTier(r.level);
                return (
                  <li key={r.id}>
                    <div
                      className={cn(
                        "flex items-center gap-3 rounded-xl border px-3 py-2.5 transition-colors",
                        isMe
                          ? "border-violet-400/50 bg-violet-500/10 shadow-[0_0_16px_rgba(139,92,246,0.25)]"
                          : "border-white/10 bg-white/[0.03] hover:bg-white/[0.06]",
                      )}
                    >
                      <RankBadge rank={r.rank} />
                      {/* avatar — ring colored by the player's level tier */}
                      <span
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-full p-[2px]"
                        style={{ background: `linear-gradient(135deg, ${tier.hex}, ${tier.hex2})` }}
                        title={`Level ${r.level} — ${tier.name}`}
                      >
                        {r.avatar ? (
                          <img
                            src={r.avatar}
                            alt=""
                            referrerPolicy="no-referrer"
                            className="h-full w-full rounded-full border border-black/40 object-cover"
                          />
                        ) : (
                          <span className="font-display grid h-full w-full place-items-center rounded-full border border-black/40 bg-gradient-to-br from-violet-500 to-fuchsia-600 text-sm font-black text-white">
                            {r.name.charAt(0).toUpperCase()}
                          </span>
                        )}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold text-white/90">
                          {r.name}
                          {isMe && (
                            <span className="ml-2 rounded-full border border-violet-400/40 bg-violet-500/15 px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wide text-violet-300">
                              you
                            </span>
                          )}
                        </p>
                        <p className="text-[10px] font-bold uppercase tracking-wide text-white/35">Level {r.level}</p>
                      </div>
                      <span
                        className={cn(
                          "font-display shrink-0 text-sm font-black tabular-nums sm:text-base",
                          tab === "level"
                            ? "text-fuchsia-300"
                            : tab === "cases"
                              ? "text-sky-300"
                              : "flex items-center gap-1 text-amber-300",
                        )}
                        dir="ltr"
                      >
                        {tab === "biggest" && <Coin className="h-3.5 w-3.5" />}
                        {valueLabel(r)}
                      </span>
                    </div>
                  </li>
                );
              })}
            </motion.ol>
          )}

          {/* footer note */}
          <p className="mt-6 flex items-center justify-center gap-1.5 text-center text-[11px] font-semibold text-white/35">
            <Users className="h-3.5 w-3.5" />
            Ranks update live from the database — every player on the site, top to bottom.
          </p>
        </div>
      </main>
    </SiteShell>
  );
}
