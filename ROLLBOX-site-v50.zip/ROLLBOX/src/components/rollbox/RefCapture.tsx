"use client";

import { useEffect } from "react";

/* ===== REFERRAL LINK CAPTURE (Task 22 → reworked in Task 142 — USER SPEC)
   Any landing on /?ref=CODE parks the code in localStorage and cleans the
   URL. The code is NO LONGER claimed on the spot — the DEPOSIT dialog picks
   it up: the player confirms it in the REFERRAL CODE field and his FIRST
   deposit pays +5% extra to him and a flat $1.5 gift to the code's owner. */

const KEY = "rb_ref_code";

export function RefCapture() {
  // 1) grab ?ref=... off the URL on any page, then scrub it — the DEPOSIT
  //    dialog reads the parked code when the player opens it.
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const ref = params.get("ref");
      if (ref && /^[A-Za-z2-9]{8}$/.test(ref.trim())) {
        window.localStorage.setItem(KEY, ref.trim().toUpperCase());
        params.delete("ref");
        const rest = params.toString();
        window.history.replaceState(
          null,
          "",
          window.location.pathname + (rest ? `?${rest}` : "") + window.location.hash,
        );
      }
    } catch {
      /* private mode — nothing to capture */
    }
  }, []);

  return null; // invisible worker
}
