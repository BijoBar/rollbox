import { cn } from "@/lib/utils";

/**
 * USER SPEC (Task 28): the site currency is now USD — the old ROLLCOIN coin
 * icon is replaced everywhere by a green dollar sign ($). Em-sized so it
 * scales with the surrounding text like a real currency symbol; drop a
 * className for margins/colors. The green is forced (last in the merge) so
 * legacy call sites that pass amber stay green per the spec.
 */
export function Coin({ className }: { className?: string }) {
  // legacy callers size the old coin <img> with h-/w- utility boxes — a text
  // glyph sizes itself off the font, so those boxes are dropped to avoid a
  // clipped/oversized symbol; every other class (margins, inline, align) stays.
  const cleaned = (className ?? "").replace(/(^|\s)(sm:|md:|lg:)?[hw]-\d+(?:\.\d+)?/g, "");
  return (
    <span
      aria-hidden="true"
      draggable={false}
      className={cn(
        "inline-block select-none align-[-0.02em] font-black leading-none tracking-normal",
        cleaned,
        "text-green-400"
      )}
    >
      $
    </span>
  );
}
