"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { usePathname, useRouter } from "next/navigation";
import { sfx } from "@/lib/sound";

/**
 * USER SPEC (Task 84) — LIGHT-SPEED NAVIGATION.
 *
 * Clicking the TopBar buttons (CASES / EXCHANGE COINS / HOW IT WORKS /
 * CASE BATTLES — and the logo) must feel like the player dashes forward at
 * the speed of light into the next page — NOT like one page closes and
 * another opens.
 *
 * Choreography:
 *   0ms     streak overlay starts ramping in + corridor gets rb-warp-start
 *           (the infinite tunnel accelerates to ~light speed behind the UI)
 *   ~380ms  router.push fires while the streaks are at full burn
 *           (push is awaited — the overlay holds until the route swaps)
 *   arrival rb-warp-done (corridor re-bases onto the new page), the overlay
 *           flashes + releases, the new page's <main> plays a fast
 *           arrive-in animation, the whoosh fades out
 *
 * Same-page anchors (e.g. Cases while already on "/") just smooth-scroll —
 * no warp for a jump inside the page you're already on.
 */

const RAMP_MS = 380; // streaks ramp before the push fires
const MIN_HOLD_MS = 420; // minimum full-burn time while the route swaps

const WarpCtx = createContext<{ warpNavigate: (href: string) => void }>({
  warpNavigate: () => {},
});

export function useWarp() {
  return useContext(WarpCtx);
}

const sleep = (ms: number) => new Promise<void>((r) => window.setTimeout(r, ms));

export function WarpProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname() ?? "/";
  const [busy, setBusy] = useState(false);
  const warpingRef = useRef(false);

  // warm the main destinations so the push itself is instant
  useEffect(() => {
    const id = window.setTimeout(() => {
      for (const href of ["/", "/skins", "/battles"]) router.prefetch(href);
    }, 1200);
    return () => window.clearTimeout(id);
  }, [router]);

  const scrollToHash = useCallback((hash: string) => {
    let tries = 0;
    const tick = () => {
      const el = document.getElementById(hash);
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
        return;
      }
      if (++tries < 25) window.setTimeout(tick, 80);
    };
    tick();
  }, []);

  const warpNavigate = useCallback(
    (href: string) => {
      if (warpingRef.current) return;

      // split href into path + hash ("/#cases" → "/" + "cases")
      const hashIdx = href.indexOf("#");
      const path = hashIdx >= 0 ? href.slice(0, hashIdx) || "/" : href;
      const hash = hashIdx >= 0 ? href.slice(hashIdx + 1) : "";

      // same page → a warp would be silly; just travel inside the page
      if (path === pathname) {
        if (hash) scrollToHash(hash);
        else window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }

      warpingRef.current = true;
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

      const finish = () => {
        window.dispatchEvent(new CustomEvent("rb-warp-done"));
        sfx.spinEnergy(0.45);
        document.body.classList.add("page-arrive");
        // the overlay's own CSS cycle carries the flash + fade-out; unmount it
        // AFTER the fade so the arrival never gets cut mid-flash
        window.setTimeout(() => setBusy(false), 300);
        window.setTimeout(() => {
          document.body.classList.remove("page-arrive");
          sfx.spinEnd();
        }, 700);
        if (hash) window.setTimeout(() => scrollToHash(hash), 240);
        warpingRef.current = false;
      };

      if (reduced) {
        void (async () => {
          await router.push(href);
          finish();
        })();
        return;
      }

      setBusy(true);
      window.dispatchEvent(new CustomEvent("rb-warp-start"));
      sfx.spinStart();
      sfx.spinEnergy(0.4);

      void (async () => {
        window.setTimeout(() => sfx.spinEnergy(1), Math.round(RAMP_MS * 0.6));
        await Promise.all([router.push(href), sleep(RAMP_MS + MIN_HOLD_MS)]);
        finish();
      })();
    },
    [pathname, router, scrollToHash],
  );

  return (
    <WarpCtx.Provider value={{ warpNavigate }}>
      {children}
      {busy && (
        <div className="warp-overlay" aria-hidden="true">
          <div className="warp-streaks" />
          <div className="warp-streaks warp-streaks-b" />
          <div className="warp-flash" />
        </div>
      )}
    </WarpCtx.Provider>
  );
}
