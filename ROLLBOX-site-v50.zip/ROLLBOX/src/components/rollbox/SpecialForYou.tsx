"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Gift } from "lucide-react";
import { CASES, LEVEL_CASES_ALL, type CaseDef } from "@/lib/cases";
import { useSession } from "@/lib/session";
import { CaseCard } from "./CaseCard";
import { LevelCaseCard, type DailyCases } from "./LevelCaseCard";

/**
 * USER SPEC (Task 104): the new home-page category that REPLACED the Discord
 * banner — "Special for you": the 10 free DAILY cases (LEVEL 10..100), every
 * case up to the player's level opens FREE once per 24h (each with its own
 * cooldown). Signed-in players poll the SERVER gate (/api/daily); guests
 * count down locally (30s tick keeps the labels fresh).
 *
 * USER SPEC (Task 184): the category now ALSO carries every GIFTED free case
 * the player owns (the admin-gifted freeCases map) — rendered as full case
 * cards with the FREE ×N chip, right above the daily grid. A player without
 * free boxes sees the section exactly as before (daily cases only).
 */
export function SpecialForYou() {
  const { player: me } = useSession();
  const [serverCases, setServerCases] = useState<DailyCases>(null);
  const [, setTick] = useState(0);

  // ---- gifted free cases (Task 184) ----
  // the canonical ids STRING keeps the effect honest: the session patches the
  // freeCases object on every balance/realtime update, but only a REAL change
  // in the owned free ids (gift landed / last box burned) re-runs the resolve.
  const freeKey = useMemo(
    () =>
      Object.entries(me?.freeCases ?? {})
        .filter(([, q]) => q > 0)
        .map(([id]) => id)
        .sort()
        .join(","),
    [me?.freeCases],
  );
  const [freeState, setFreeState] = useState<{ key: string; defs: CaseDef[] }>({
    key: "",
    defs: [],
  });

  useEffect(() => {
    if (!freeKey) return; // no free boxes → the render hides the block via the key check
    let alive = true;
    const ids = freeKey.split(",");
    // the static catalog resolves in-bundle (incl. the hidden TEST box a
    // player was gifted); player-built cc_* cases ride /api/cases/resolve
    const local = ids
      .map((id) => CASES.find((c) => c.id === id))
      .filter((c): c is CaseDef => !!c);
    const missing = ids.filter((id) => !local.some((c) => c.id === id));
    const load = async () => {
      let remote: CaseDef[] = [];
      if (missing.length) {
        try {
          const r = await fetch(`/api/cases/resolve?ids=${encodeURIComponent(missing.join(","))}`, {
            cache: "no-store",
          });
          if (r.ok) {
            const d = (await r.json()) as { cases?: CaseDef[] };
            remote = d.cases ?? [];
          }
        } catch {
          /* the next freeCases change retries */
        }
      }
      if (!alive) return;
      // player order first (static catalog), community defs appended, deduped
      const merged = [...local, ...remote].filter(
        (c, i, arr) => arr.findIndex((x) => x.id === c.id) === i,
      );
      setFreeState({ key: freeKey, defs: merged });
    };
    void load();
    return () => {
      alive = false;
    };
  }, [freeKey]);

  // keyed read: a fresh freeKey renders NOTHING until its own resolve lands —
  // stale defs from the previous map can never flash on the page
  const freeDefs = freeState.key === freeKey ? freeState.defs : [];

  useEffect(() => {
    let alive = true;
    // keeps the "Ready in 7h 12m" labels honest without a fetch storm
    const tick = window.setInterval(() => setTick((k) => k + 1), 30000);
    if (!me) {
      return () => {
        alive = false;
        window.clearInterval(tick);
      };
    }
    const load = async () => {
      try {
        const r = await fetch("/api/daily", { cache: "no-store" });
        if (!r.ok) return;
        const d = (await r.json()) as {
          cases?: Record<string, { ready: boolean; nextIn: number }>;
        };
        if (alive) setServerCases((d.cases ?? {}) as DailyCases);
      } catch {
        /* the next poll retries */
      }
    };
    void load();
    const poll = window.setInterval(() => void load(), 60000);
    return () => {
      alive = false;
      window.clearInterval(tick);
      window.clearInterval(poll);
    };
  }, [me]);

  return (
    <section
      id="special"
      className="relative mx-auto max-w-7xl scroll-mt-24"
      aria-label="Special for you — free daily cases"
    >
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.5 }}
        className="mb-10 text-center"
      >
        <h2 className="text-3xl font-black text-white md:text-4xl">
          Special <span className="text-gradient-neon">for you</span>
        </h2>
        {/* USER SPEC (Task 32): the small line right below the heading */}
        <p className="mt-2 text-xs font-semibold tracking-wide text-white/45">
          Your free &amp; Favorite Cases
        </p>
      </motion.div>

      {/* ===== USER SPEC (Task 184): the player's GIFTED free cases =====
          every case the player owns free units of, full case cards with the
          FREE ×N chip (CaseCard renders it from the session map). A player
          with no free boxes — and every guest — skips this block entirely. */}
      {freeDefs.length > 0 && (
        <div className="mb-12" data-testid="special-free-cases">
          <p className="mb-5 flex items-center justify-center gap-2 text-center text-xs font-black uppercase tracking-[0.25em] text-emerald-300/90">
            <Gift className="h-3.5 w-3.5" />
            Your free cases — open at no charge
          </p>
          <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
            {freeDefs.map((c, i) => (
              <CaseCard key={c.id} caseDef={c} index={i} />
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {LEVEL_CASES_ALL.map((c, i) => (
          <LevelCaseCard
            key={c.id}
            caseDef={c}
            index={i}
            serverCases={serverCases}
            signedIn={!!me}
          />
        ))}
      </div>
    </section>
  );
}
