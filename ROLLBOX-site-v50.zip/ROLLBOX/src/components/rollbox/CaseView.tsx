"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Boxes,
  Coins,
  ShieldCheck,
  Trophy,
} from "lucide-react";
import { RARITY_META, SKINS, caseItemSkin, caseItemValue, formatCoins, formatOdds, type CaseDef } from "@/lib/cases";
import { useSession } from "@/lib/session";
import { CaseImage } from "./CaseImage";
import { Coin } from "./Coin";
import { SkinTile } from "./SkinTile";
import { CaseOpener } from "./CaseOpener";
import { cn } from "@/lib/utils";
import { Gift } from "lucide-react";

export function CaseView({ caseDef }: { caseDef: CaseDef }) {
  const totalWeight = caseDef.items.reduce((s, i) => s + i.weight, 0);
  // Task 72: sorting + top prize use the WEAR-adjusted item values
  const sortedItems = [...caseDef.items].sort((a, b) => caseItemValue(b) - caseItemValue(a));
  const topPrize = sortedItems.length ? caseItemSkin(sortedItems[0]) : null;
  // USER SPEC (Task 183): the page header carries the same FREE ×N chip as
  // the cards — the player's gifted / mission-prize boxes of THIS case.
  const { player } = useSession();
  const freeCount = player?.freeCases?.[caseDef.id] ?? 0;

  return (
    <>
      {/* ===== case hero ===== */}
      <section className="relative overflow-hidden border-b border-white/5" aria-label={`${caseDef.name} case`}>

        <div className="relative mx-auto max-w-7xl px-4 pb-8 pt-8">
          <Link
            href="/#cases"
            className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-sm font-bold text-white/50 transition-colors hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" />
            All Cases
          </Link>

          <div className="mt-6 grid items-center gap-10 md:grid-cols-2">
            {/* art */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="relative order-2 mx-auto w-60 md:order-1 md:w-80"
            >
              <div
                className="absolute inset-0 -z-10 blur-3xl"
                style={{ background: `radial-gradient(circle at 50% 60%, ${caseDef.tierColor}40, transparent 65%)` }}
                aria-hidden="true"
              />
              <div className="anim-float" style={{ "--rot": "3deg" } as React.CSSProperties}>
                <CaseImage
                  caseId={caseDef.id}
                  alt={caseDef.name}
                  color={caseDef.tierColor}
                  color2={caseDef.tierColor2}
                  communityDesign={caseDef.communityDesign}
                  className="w-full"
                  priority
                  sizes="(max-width: 768px) 240px, 320px"
                />
              </div>
            </motion.div>

            {/* info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="order-1 text-center md:order-2 md:text-left"
            >
              <div className="flex flex-wrap items-center justify-center gap-2 md:justify-start">
                <span className="rounded-md border border-white/15 bg-black/40 px-2.5 py-1 font-mono text-xs font-black tracking-widest text-white/70">
                  ID: {caseDef.code}
                </span>
                <span
                  className="rounded-full border px-2.5 py-1 text-[10px] font-black tracking-wide"
                  style={{
                    borderColor: caseDef.tierColor + "55",
                    color: caseDef.tierColor,
                    background: caseDef.tierColor + "14",
                  }}
                >
                  {caseDef.tierLabel}
                </span>
              </div>

              <h1 className="mt-4 flex flex-wrap items-center justify-center gap-x-3 gap-y-2 text-4xl font-black text-white md:justify-start md:text-5xl">
                {caseDef.name}
                {freeCount > 0 && (
                  <span
                    data-freechip="1"
                    title={`${freeCount} free ${caseDef.name} box${freeCount === 1 ? "" : "es"} in your account — they open at no charge`}
                    className="flex items-center gap-1.5 rounded-lg border border-emerald-400/50 bg-emerald-500/15 px-2.5 py-1 text-base font-black uppercase tracking-wider text-emerald-300 shadow-[0_0_16px_rgba(16,185,129,0.35)]"
                  >
                    <Gift className="h-4 w-4" />
                    FREE ×{freeCount}
                  </span>
                )}
              </h1>

              {/* quick stats */}
              <div className="mt-6 grid grid-cols-3 gap-3">
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3">
                  <Boxes className="mx-auto mb-1 h-4.5 w-4.5 text-violet-300 md:mx-0" />
                  <p className="font-display text-lg font-black text-white">{caseDef.items.length}</p>
                  <p className="text-[10px] font-bold uppercase tracking-wide text-white/45">Items</p>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3">
                  <Trophy className="mx-auto mb-1 h-4.5 w-4.5 text-amber-300 md:mx-0" />
                  <p className="font-display text-lg font-black text-white">
                    {topPrize ? formatCoins(topPrize.value) : "—"}
                  </p>
                  <p className="text-[10px] font-bold uppercase tracking-wide text-white/45">
                    Top Prize <Coin className="h-3 w-3 align-[-0.1em]" />
                  </p>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3">
                  <Coin className="mx-auto mb-1 block text-xl md:mx-0" />
                  <p className="font-display text-lg font-black text-white">
                    {/* USER SPEC: the free daily LEVEL cases show FREE, not $0 */}
                    {caseDef.kind === "level" ? "FREE" : formatCoins(caseDef.price)}
                  </p>
                  <p className="text-[10px] font-bold uppercase tracking-wide text-white/45">
                    {caseDef.kind === "level" ? "Daily free case" : (
                      <>
                        Price <Coin className="h-3 w-3 align-[-0.1em]" />
                      </>
                    )}
                  </p>
                </div>
              </div>

              <p className="mt-6 flex items-center justify-center gap-1.5 text-xs text-white/45 md:justify-start">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                Pick Multi, hit OPEN — the reel is waiting below
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ===== live unboxing reel — lives on the page, OPEN starts the deal ===== */}
      <CaseOpener caseDef={caseDef} />

      {/* ===== contents with odds ===== */}
      <section className="mx-auto max-w-7xl px-4 py-12" aria-label="Case contents and odds">
        <div className="mb-8 text-center">
          <p className="font-display text-sm font-bold tracking-[0.3em]" style={{ color: caseDef.tierColor + "cc" }}>
            CASE CONTENTS
          </p>
          <h2 className="mt-2 text-3xl font-black text-white">
            Skins in this <span className="text-gradient-neon">case</span>
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-sm text-white/55">
            Every item and its exact drop rate — the numbers below are the real odds used by the roulette.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {sortedItems.map((it, i) => {
            const skin = caseItemSkin(it);
            const rar = RARITY_META[skin.rarity];
            const gold = skin.rarity === "contraband"; // star badge sits at top-right
            return (
              <motion.div
                key={it.skinId + (it.wear ?? "")}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-30px" }}
                transition={{ duration: 0.35, delay: Math.min(i * 0.04, 0.4) }}
                className="relative"
                style={{ ["--rc" as string]: rar.color }}
              >
                <SkinTile
                  skinId={it.skinId}
                  wear={skin.wear}
                  valueOverride={skin.value}
                  className={cn("h-44 w-full", gold && "ring-1 ring-amber-400/60")}
                  artClassName="h-20"
                />
                <span
                  className={cn(
                    "absolute top-1.5 rounded-md border bg-black/70 px-1.5 py-0.5 font-mono text-[10px] font-black backdrop-blur-sm",
                    gold ? "right-7" : "right-1.5"
                  )}
                  style={{ borderColor: rar.color + "55", color: rar.color }}
                  title={`Drop chance: ${formatOdds((it.weight / totalWeight) * 100)}%`}
                >
                  {formatOdds((it.weight / totalWeight) * 100)}%
                </span>
              </motion.div>
            );
          })}
        </div>

        <div className="mx-auto mt-10 flex max-w-2xl items-center justify-center gap-3 rounded-xl border border-emerald-500/25 bg-emerald-500/5 px-5 py-4 text-center">
          <ShieldCheck className="h-6 w-6 shrink-0 text-emerald-400" />
          <p className="text-sm leading-relaxed text-white/65">
            <span className="font-bold text-emerald-300">Provably Fair:</span>{" "}
            every opening is rolled from an HMAC-SHA256 seed commitment{" "}
            <Link href="/provably-fair" className="font-bold text-emerald-300 underline decoration-emerald-400/40 underline-offset-2 transition-colors hover:text-emerald-200">
              verify it yourself
            </Link>
            .
          </p>
        </div>
      </section>
    </>
  );
}
