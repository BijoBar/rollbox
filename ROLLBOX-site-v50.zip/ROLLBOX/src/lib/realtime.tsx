"use client";

import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

/**
 * REALTIME — the client end of the multiplayer push channel (Task 64).
 * ONE EventSource to /api/realtime/stream per tab. The server is the only
 * source of truth; this provider just routes its events to subscribers:
 *
 *   battles   — the worldwide lobby list changed      (refetch)
 *   battle    — a room's state advanced (round/settle) (refetch that room)
 *   drop      — a new live-feed drop                  (prepend)
 *   player    — { playerId, balance } (targeted)      (patch the session)
 *   inventory — { playerId } (targeted)               (refetch the inventory)
 *   stats     — site counters moved                   (refetch the hero strip)
 *
 * The classic polls stay as a safety net; the push makes every viewer see
 * every change at the SAME instant instead of on their own poll rhythm.
 */

export type RealtimeHandler = (data: unknown) => void;

interface RealtimeState {
  connected: boolean;
  subscribe: (type: string, handler: RealtimeHandler) => () => void;
}

const Ctx = createContext<RealtimeState>({ connected: false, subscribe: () => () => {} });

export function RealtimeProvider({ children }: { children: ReactNode }) {
  const [connected, setConnected] = useState(false);
  const listeners = useRef(new Map<string, Set<RealtimeHandler>>());

  useEffect(() => {
    // one shared stream — EventSource reconnects on its own if the dev server restarts
    const es = new EventSource("/api/realtime/stream");

    const dispatch = (type: string) => (ev: MessageEvent) => {
      let data: unknown = null;
      try {
        data = JSON.parse(ev.data as string);
      } catch {
        data = null;
      }
      const set = listeners.current.get(type);
      if (set) for (const h of set) h(data);
    };

    const onOpen = () => setConnected(true);
    const onError = () => setConnected(false); // es retries automatically
    const routed = [
      "battles",
      "battle",
      "drop",
      "player",
      "inventory",
      "stats",
      "hello",
      // USER SPEC (Task 136): the SUPPORT CHAT — admins' inbox/case alerts and
      // the player's chat-panel live updates
      "support_admin",
      "support_player",
    ];
    es.addEventListener("open", onOpen);
    es.addEventListener("error", onError);
    for (const t of routed) es.addEventListener(t, dispatch(t));

    return () => {
      es.close();
      setConnected(false);
    };
  }, []);

  const value = useMemo<RealtimeState>(
    () => ({
      connected,
      subscribe: (type, handler) => {
        let set = listeners.current.get(type);
        if (!set) {
          set = new Set();
          listeners.current.set(type, set);
        }
        set.add(handler);
        return () => {
          set?.delete(handler);
        };
      },
    }),
    [connected]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useRealtime = () => useContext(Ctx);

/**
 * Subscribe to one push event for this component's lifetime. The handler ref
 * stays fresh without resubscribing, so callers can pass inline callbacks.
 */
export function useRealtimeEvent(type: string, handler: (data: unknown) => void): void {
  const { subscribe } = useRealtime();
  const ref = useRef(handler);
  useEffect(() => {
    ref.current = handler; // keep the latest callback without resubscribing
  }, [handler]);
  useEffect(() => subscribe(type, (d) => ref.current(d)), [subscribe, type]);
}
