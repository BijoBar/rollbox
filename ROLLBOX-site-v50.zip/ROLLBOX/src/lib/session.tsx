"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useRealtimeEvent } from "@/lib/realtime";
import { useCaseStore } from "@/lib/store";

/** Module-level mirror of the signed-in player id — non-React code can know
 *  WHO is signed in without a hook (kept for future server pushes). */
export const sessionRef = { playerId: null as string | null };

/** The signed-in player as the server sees it (the DATABASE row). */
export interface SessionPlayer {
  id: string;
  name: string;
  avatar: string | null;
  provider: string;
  // USER SPEC (Task 81): the provider's id (Steam id64) — the profile's
  // STEAM button opens https://steamcommunity.com/profiles/<providerId>
  providerId: string | null;
  balance: number;
  casesOpened: number;
  battlesWon: number;
  // USER SPEC (Task 104): the BATTLE PASS lives in the DATABASE — the client
  // adopts the server xp whenever the local copy is behind (fresh device).
  xp: number;
  level: number;
  createdAt: string;
  // USER SPEC (Task 75): settings + SELF CARE state (server truth)
  tradeLink: string | null;
  email: string | null;
  depositLimit: number | null;
  depositLimitDays: number | null;
  depositLimitStart: string | null;
  breakUntil: string | null;
  // USER SPEC (Task 22): the admin flag drives the red ADMIN TopBar button;
  // refCode feeds the referral card on the profile.
  isAdmin: boolean;
  refCode: string | null;
  // USER SPEC (Task 23): referral is CODE-ONLY — the profile shows the friend
  // code entry only while no inviter is attached to the account yet.
  referredBy: string | null;
  // C12: identity flags — true when the player set a custom name/avatar in
  // settings (the Steam login sync never overwrites them then).
  nameCustom: boolean;
  avatarCustom: boolean;
  // USER SPEC (Task 180): set when the account is PERMANENTLY banned — the
  // BanGuard shield covers the site while every action route refuses it.
  bannedAt: string | null;
  // USER SPEC (Task 183): the player's gifted / mission-prize FREE boxes —
  // { "doppler-realm": 2 } → the case cards show a FREE ×2 chip by the name.
  // Empty map = no free boxes anywhere (names render plain, no chip).
  freeCases: Record<string, number>;
}

interface SessionState {
  player: SessionPlayer | null;
  loading: boolean;
  /** re-fetch /api/auth/me (after a server-side money move) */
  refresh: () => Promise<SessionPlayer | null>;
  /** optimistic local patch between server confirms */
  patch: (p: Partial<SessionPlayer>) => void;
}

const Ctx = createContext<SessionState>({ player: null, loading: true, refresh: async () => null, patch: () => {} });

export function SessionProvider({ children }: { children: ReactNode }) {
  const [player, setPlayer] = useState<SessionPlayer | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const r = await fetch("/api/auth/me", { cache: "no-store" });
      const data = (await r.json()) as { player: SessionPlayer | null };
      setPlayer(data.player);
      // USER SPEC: the level lives in the DATABASE, nowhere else — every
      // session sync OVERWRITES the local xp counter with the DB value (a
      // stale localStorage, an old device or guest xp never wins). ANTI-CHEAT
      // (Task 108): the server awards xp itself; the client only mirrors it.
      if (data.player) {
        sessionRef.playerId = data.player.id;
        useCaseStore.getState().adoptServerXp(data.player.xp);
      } else {
        sessionRef.playerId = null;
      }
      return data.player;
    } catch {
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const patch = useCallback((p: Partial<SessionPlayer>) => {
    setPlayer((prev) => (prev ? { ...prev, ...p } : prev));
  }, []);

  // initial load + a slow heartbeat so a second tab's money moves show up too
  useEffect(() => {
    void refresh();
    const t = window.setInterval(() => void refresh(), 15000);
    return () => window.clearInterval(t);
  }, [refresh]);

  // REALTIME (Task 64): the server pushes MY balance the moment it moves —
  // every device signed into this account updates at the same instant.
  // USER SPEC (Task 75): SELF CARE changes ride the same event — a break set
  // on one device blocks every other device within a second.
  useRealtimeEvent("player", (data) => {
    const e = data as {
      playerId?: string;
      balance?: number;
      breakUntil?: string | null;
      depositLimit?: number | null;
      depositLimitDays?: number | null;
      depositLimitStart?: string | null;
      // C12: identity changes propagate to every signed-in device.
      name?: string;
      avatar?: string | null;
      // USER SPEC (Task 180): a ban stamped on one device covers every open
      // tab of the same account the moment the admin fires it.
      bannedAt?: string | null;
      // USER SPEC (Task 183): an admin gift (or a free open) lands on every
      // open tab the same instant — the FREE ×N chips update live.
      freeCases?: Record<string, number>;
    } | null;
    if (!e || !e.playerId) return;
    setPlayer((prev) => {
      if (!prev || prev.id !== e.playerId) return prev;
      const patch: Partial<SessionPlayer> = {};
      if (typeof e.balance === "number") patch.balance = e.balance;
      if (e.breakUntil !== undefined) patch.breakUntil = e.breakUntil;
      if (e.depositLimit !== undefined) patch.depositLimit = e.depositLimit;
      if (e.depositLimitDays !== undefined) patch.depositLimitDays = e.depositLimitDays;
      if (e.depositLimitStart !== undefined) patch.depositLimitStart = e.depositLimitStart;
      if (typeof e.name === "string") patch.name = e.name;
      if (e.avatar !== undefined) patch.avatar = e.avatar;
      if (e.bannedAt !== undefined) patch.bannedAt = e.bannedAt;
      if (e.freeCases !== undefined) patch.freeCases = e.freeCases;
      return { ...prev, ...patch };
    });
  });

  const value = useMemo(() => ({ player, loading, refresh, patch }), [player, loading, refresh, patch]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useSession = () => useContext(Ctx);
