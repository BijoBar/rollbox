// ============ COMMUNITY CASES — shared client-safe bits (Task 142) ============
// The case-builder UI + the home-page section import from here; the DB-touching
// logic lives in src/lib/server/community-cases.ts (never import that from a
// client component — it pulls the Prisma engine into the bundle).

import { caseItemValue, type CaseDef, type CaseItem } from "@/lib/cases";

export const COMMUNITY_MAX_ITEMS = 10;
/** The house edge the site prices community cases with (price = EV / 0.85). */
export const COMMUNITY_HOUSE_EDGE = 0.85;

export const COMMUNITY_DESIGNS = ["red", "white", "yellow"] as const;
export type CommunityDesign = (typeof COMMUNITY_DESIGNS)[number];

/** USER SPEC: the three player-chosen crate artworks (uploaded images). */
export const DESIGN_ART: Record<CommunityDesign, string> = {
  red: "/communitycasered.png",
  white: "/communitycasewhite.png",
  yellow: "/communitycaseyellow.png",
};

export const DESIGN_COLORS: Record<CommunityDesign, { c1: string; c2: string }> = {
  red: { c1: "#ef4444", c2: "#fca5a5" },
  white: { c1: "#cbd5e1", c2: "#f8fafc" },
  yellow: { c1: "#f0b90b", c2: "#fde68a" },
};

export function isCommunityDesign(v: string): v is CommunityDesign {
  return (COMMUNITY_DESIGNS as readonly string[]).includes(v);
}

export interface CommunityCaseCard {
  id: string;
  name: string;
  creatorName: string;
  design: string;
  price: number;
  createdAt: string;
  /** EVENTS/battles picker: the parsed drop table rides along so the picker
   *  can sort by top prize and render VIEW DROPS without another fetch. */
  items?: unknown[];
}

/**
 * USER SPEC (battles × COMMUNITY): the client-side CaseDef for a community
 * row — the same projection the server's communityToCaseDef produces, minus
 * the DB import so the battle picker / room views can use it in the bundle.
 * ROLLDROP stays disabled for player-made cases (the rare pool belongs to
 * the official catalog), exactly like the server version.
 */
export function communityRowToCaseDef(row: {
  id: string;
  name: string;
  design: string;
  price: number;
  items?: unknown[];
}): CaseDef {
  const design = isCommunityDesign(row.design) ? row.design : "red";
  const colors = DESIGN_COLORS[design];
  const items = (Array.isArray(row.items) ? row.items : []) as CaseItem[];
  return {
    id: row.id,
    code: "COMMUNITY",
    name: row.name,
    subtitle: "A player-built community case.",
    kind: "standard",
    tierLabel: "COMMUNITY",
    price: row.price,
    tierColor: colors.c1,
    tierColor2: colors.c2,
    items,
    rolldropChance: 0,
    communityDesign: design,
  };
}

/** The top prize of any pickable case — the picker's "Top prize first" sort. */
export function caseTopPrize(c: CaseDef): number {
  return c.items.length ? Math.max(...c.items.map(caseItemValue)) : 0;
}
