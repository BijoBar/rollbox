// Site-wide constants
// Task 31 (USER SPEC): the owner's Discord invite — used by the TopBar icon,
// the missions board CTA and the login view.
export const DISCORD_INVITE = "https://discord.gg/FemvjfBxBa";
