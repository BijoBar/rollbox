import { create } from "zustand";
import { persist } from "zustand/middleware";
import { type CaseDef } from "./cases";
import {
  battleEntry,
  BATTLE_TYPES,
  emptySeats,
  headlessResolve,
  makeBot,
  makeBotBattle,
  makePlayer,
  newBattleId,
  openSeat,
  seatOfYou,
  shuffledColorOrder,
  teamForSeat,
  type Battle,
  type BattleMode,
  type BattlePlayer,
  type BattlePotRule,
  type BattleResult,
  type BattleType,
} from "./battles";
import {
  computePublicHash,
  drawCasePF,
  generateClientSeed,
  generateSalt,
  generateServerSeed,
  type RollProof,
} from "./provably-fair";
import { levelFromXp } from "./progress";

/** A server seed pair after it has been revealed (retired) — fully verifiable. */
export interface PFSeedRecord {
  serverSeed: string;
  salt: string;
  publicHash: string;
  clientSeed: string;
  usedFrom: number; // first nonce used with this pair
  usedTo: number; // last nonce used with this pair
  revealedAt: number;
}

/** One completed roll with everything needed to re-verify it later. */
export interface PFRollRecord {
  nonce: number;
  caseId: string;
  skinId: string;
  clientSeed: string;
  serverSeedHash: string; // matches PFSeedRecord.publicHash once revealed
  float: number;
  at: number;
}

/** Result of a grantXp call. USER SPEC: leveling up carries NO reward and NO
 *  toast anymore — the level is pure DB state the UI reads back from the
 *  server (adoptServerXp), so the result is bookkeeping data only. */
export interface XpGrant {
  xpGained: number;
  leveledUp: boolean;
  newLevel: number;
}

// ===== USER SPEC: the LEVEL lives in the DATABASE, nowhere else =====
// ANTI-CHEAT (Task 108): the client NEVER pushes xp to the server anymore —
// the old /api/xp push accepted any absolute value, so a tampered client
// could claim Level 100 with one request. XP is awarded SERVER-side when the
// server-verified action happens (an open, a battle settle); grantXp below is
// a purely LOCAL cosmetic animation between the action and the next 15s
// heartbeat, which overwrites this counter with the DATABASE truth.

/**
 * One skin sitting in your INVENTORY — a full snapshot of the catalog entry it
 * was exchanged from (the catalog is huge, so the item carries its own data).
 * USER SPEC (Task 40): game wins NEVER land here — they credit coins directly;
 * the inventory only fills through the EXCHANGE (coins -> skins).
 */
export interface InvItem {
  uid: string;
  id: string; // catalog entry id
  n: string; // full display name ("AK-47 | Redline (Field-Tested)")
  w: string; // weapon / label ("AK-47" / "Sticker" / "Hand Wraps")
  r: string; // rarity key (RARITY_META)
  p: number; // real USD market price at exchange time
  v: number; // coins PAID at the exchange — also the sell-back value
  img: string | null; // CDN render URL (may be null -> SVG art fallback)
  est?: 1; // USD price estimated
  t?: "sticker" | "charm" | "agent" | "patch";
  cat?: string; // catalog category key
  a?: string; // SVG fallback art kind
  wear?: string; // Task 72: exterior bought (full CS2 label, e.g. "Field-Tested")
  at: number; // acquired at timestamp
}

export type CallBotsOutcome = "filled" | "called" | "full" | "no-seat";

interface CaseStore {
  balance: number;
  inventory: InvItem[]; // skins obtained at the EXCHANGE (newest first)
  soundOn: boolean;
  /** USER SPEC (Task 75): master volume 0..1 — the SETTINGS slider drives it. */
  soundVolume: number;
  totalOpened: number;
  bestValue: number;
  // ---- battle pass / level state ----
  xp: number;
  /** USER SPEC (Task 104): per-case 24h cooldowns for the free DAILY cases —
   *  Record<caseId, ms-timestamp of the last free open>. Every case up to the
   *  player's level opens once per day; signed-in players are ALSO stamped on
   *  the server (Player.dailyOpens), this map keeps the guest/local countdown. */
  dailyOpens: Record<string, number>;
  // ---- provably fair state ----
  pfReady: boolean;
  pfClientSeed: string;
  pfServerSeed: string; // secret until revealed
  pfSalt: string; // secret until revealed
  pfPublicHash: string; // shown to the player in advance
  pfNonce: number; // rolls made with the current seed pair
  pfSeedHistory: PFSeedRecord[]; // retired, revealed seed pairs
  pfRolls: PFRollRecord[]; // recent rolls (newest first)
  pfClientHistory: string[]; // previous client seeds
  // ---- case battles ----
  battles: Battle[]; // active (waiting + playing)
  battleHistory: Battle[]; // finished, newest first
  favoriteBattles: string[]; // battle ids starred in the lobby
  toggleFavoriteBattle: (id: string) => void;
  favoriteCases: string[]; // case ids starred in the battle-create picker
  toggleFavoriteCase: (id: string) => void;
  /**
   * Resolve a bot-only battle right now (spectator opens the room):
   * headless-finish it into history and return the finished record.
   * Returns the history record when the battle was already resolved.
   */
  resolveBattleHeadless: (id: string) => Battle | null;
  createBattle: (type: BattleType, rounds: string[], mode?: BattleMode, potRule?: BattlePotRule) => string;
  joinBattle: (id: string) => boolean;
  leaveBattle: (id: string) => void;
  disbandBattle: (id: string) => void;
  /**
   * Seat a bot while the battle waits. Without opts a random free [RBbot]
   * lands on the first open seat; USER SPEC (Task 42): with opts the player
   * picks the EXACT bot (name) and the EXACT empty seat (team + side in 2v2).
   */
  seatBot: (id: string, opts?: { name?: string; team?: 0 | 1; side?: 0 | 1 }) => boolean;
  /**
   * USER SPEC (Task 43): KICK a bot out of a waiting battle — the seat opens
   * again. Only bots, only before the battle starts.
   */
  kickBot: (id: string, playerId: string) => boolean;
  /** USER SPEC (2v2): pick any open seat — team + the LEFT/RIGHT seat inside it — while the battle waits. */
  pickSeat: (id: string, team: 0 | 1, side: 0 | 1) => boolean;
  /** You (or any human) asks to start with bots — when every human agreed, bots fill the rest. */
  callBots: (id: string) => CallBotsOutcome;
  markBattlePlaying: (id: string) => void;
  finishBattle: (id: string, results: BattleResult[], winnerIds: string[]) => void;
  /** MULTIPLAYER: upsert the client mirror of a server battle (the server is truth). */
  upsertServerBattle: (b: Battle) => void;
  npcTrafficTick: () => void;
  addCoins: (n: number) => void;
  /** Deduct n coins; `times` counts how many cases this payment covers (for stats). */
  pay: (n: number, times?: number) => boolean;
  /** Credit a win straight to the balance (no inventory) + track the best drop. */
  creditWin: (value: number) => void;
  /**
   * USER SPEC (Task 40): the EXCHANGE — pay `item.v` coins and the skin lands
   * in your INVENTORY. Returns false when the balance can't cover the price.
   */
  exchangeItem: (item: Omit<InvItem, "uid" | "at">) => boolean;
  /** Sell one inventory item back to the site for the coins paid for it. */
  sell: (uid: string) => void;
  /** Sell the whole inventory at once; returns the total coins credited. */
  sellAll: () => number;
  /** SERVER-economy: add an inventory item with NO balance math (the DB charged). */
  grantItem: (item: Omit<InvItem, "uid" | "at">) => void;
  /** SERVER-economy: drop one inventory item with NO balance math (the DB credited). */
  takeItem: (uid: string) => void;
  /** SERVER-economy: empty the inventory with NO balance math (the DB credited). */
  clearItems: () => void;
  /** SERVER-economy (Task 64): replace the local inventory with the DATABASE
   *  inventory (uid = the DB row id) — the server owns the items now. */
  setServerInventory: (items: InvItem[]) => void;
  /** USER SPEC (Task 29): while the UPGRADER wheel spins the inventory is
   *  FROZEN — the server already settled the skins, but the prize must not
   *  land in the picker before the wheel stops and the verdict shows. */
  invHold: boolean;
  setInvHold: (v: boolean) => void;
  toggleSound: () => void;
  /** USER SPEC (Task 75): SETTINGS sound-volume slider (persisted in the browser). */
  setSoundVolume: (v: number) => void;
  // ---- battle pass actions ----
  grantXp: (amount: number) => XpGrant;
  /** USER SPEC (Task 104): the DATABASE battle pass — adopt the server's xp
   *  whenever the local copy is behind (fresh device / second browser). */
  adoptServerXp: (serverXp: number) => void;
  /** USER SPEC: the daily reward is a FREE CASE — stamps THAT case's 24h
   *  cooldown the moment the player OPENS it (guests; signed-in players are
   *  stamped on the server by /api/open, this mirrors it locally). */
  markDailyCaseOpened: (caseId: string) => void;
  // ---- provably fair actions ----
  ensurePF: () => void;
  drawCase: (caseDef: CaseDef) => RollProof;
  revealServerSeed: () => void;
  setClientSeed: (seed: string) => void;
}

/** Rotate: reveal the current pair into history, mint a fresh committed pair. */
function rotatePair(state: CaseStore, nextClientSeed?: string) {
  const record: PFSeedRecord = {
    serverSeed: state.pfServerSeed,
    salt: state.pfSalt,
    publicHash: state.pfPublicHash,
    clientSeed: state.pfClientSeed,
    usedFrom: 1,
    usedTo: state.pfNonce,
    revealedAt: Date.now(),
  };
  const serverSeed = generateServerSeed();
  const salt = generateSalt();
  // pure reveal keeps the player's client seed; only setClientSeed replaces it
  const clientSeed = nextClientSeed ?? state.pfClientSeed;
  const clientChanged =
    nextClientSeed !== undefined && nextClientSeed !== state.pfClientSeed;
  return {
    pfSeedHistory: state.pfServerSeed
      ? [record, ...state.pfSeedHistory].slice(0, 25)
      : state.pfSeedHistory,
    pfClientHistory:
      clientChanged && state.pfClientSeed
        ? [state.pfClientSeed, ...state.pfClientHistory].slice(0, 10)
        : state.pfClientHistory,
    pfServerSeed: serverSeed,
    pfSalt: salt,
    pfPublicHash: computePublicHash(serverSeed, salt),
    pfClientSeed: clientSeed,
    pfNonce: 0,
  };
}

export const useCaseStore = create<CaseStore>()(
  persist(
    (set, get) => ({
      balance: 100, // Task 30: guest starting funds on the final 1X economy scale
      inventory: [],
      soundOn: true,
      soundVolume: 0.9,
      totalOpened: 0,
      bestValue: 0,
      xp: 0,
      dailyOpens: {},
      pfReady: false,
      pfClientSeed: "",
      pfServerSeed: "",
      pfSalt: "",
      pfPublicHash: "",
      pfNonce: 0,
      pfSeedHistory: [],
      pfRolls: [],
      pfClientHistory: [],
      battles: [],
      battleHistory: [],
      favoriteBattles: [],
      toggleFavoriteBattle: (id) =>
        set((s) => ({
          favoriteBattles: s.favoriteBattles.includes(id)
            ? s.favoriteBattles.filter((x) => x !== id)
            : [...s.favoriteBattles, id].slice(0, 50),
        })),
      favoriteCases: [],
      toggleFavoriteCase: (id) =>
        set((s) => ({
          favoriteCases: s.favoriteCases.includes(id)
            ? s.favoriteCases.filter((x) => x !== id)
            : [...s.favoriteCases, id].slice(0, 60),
        })),
      resolveBattleHeadless: (id) => {
        const s = get();
        const b = s.battles.find((x) => x.id === id);
        if (b) {
          const done = headlessResolve(b);
          set((st) => ({
            battles: st.battles.filter((x) => x.id !== id),
            battleHistory: [done, ...st.battleHistory].slice(0, 20),
          }));
          return done;
        }
        return s.battleHistory.find((x) => x.id === id) ?? null;
      },
      addCoins: (n) => set((s) => ({ balance: s.balance + n })),
      pay: (n, times = 1) => {
        if (get().balance < n) return false;
        set((s) => ({ balance: s.balance - n, totalOpened: s.totalOpened + times }));
        return true;
      },
      // wins go straight to the balance — coins only, the inventory stays out of it
      creditWin: (value) =>
        set((s) => ({
          balance: s.balance + value,
          bestValue: Math.max(s.bestValue, value),
        })),

      // ---- USER SPEC: the EXCHANGE — coins -> skins, straight into the inventory ----
      exchangeItem: (item) => {
        const s = get();
        if (s.balance < item.v) return false;
        const inv: InvItem = {
          ...item,
          uid: `inv-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
          at: Date.now(),
        };
        set((st) => ({
          balance: st.balance - item.v,
          inventory: [inv, ...st.inventory].slice(0, 200),
        }));
        return true;
      },
      sell: (uid) =>
        set((s) => {
          const item = s.inventory.find((i) => i.uid === uid);
          if (!item) return {};
          return {
            balance: s.balance + item.v,
            inventory: s.inventory.filter((i) => i.uid !== uid),
          };
        }),
      sellAll: () => {
        const total = get().inventory.reduce((sum, i) => sum + i.v, 0);
        set((s) => ({ balance: s.balance + total, inventory: [] }));
        return total;
      },
      // SERVER-economy helpers — signed-in players move coins through the
      // database; these adjust ONLY the local inventory (no balance math)
      grantItem: (item) => {
        const inv: InvItem = {
          ...item,
          uid: `inv-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
          at: Date.now(),
        };
        set((st) => ({ inventory: [inv, ...st.inventory].slice(0, 200) }));
      },
      takeItem: (uid) => set((s) => ({ inventory: s.inventory.filter((i) => i.uid !== uid) })),
      clearItems: () => set({ inventory: [] }),
      setServerInventory: (items) => set({ inventory: items.slice(0, 200) }),
      invHold: false,
      setInvHold: (v) => set({ invHold: v }),
      toggleSound: () => set((s) => ({ soundOn: !s.soundOn })),
      // USER SPEC (Task 75): the settings slider — clamped 0..1, applied to the
      // WebAudio master gain live (see setMasterVolume in lib/sound.ts).
      setSoundVolume: (v) => set(() => ({ soundVolume: Math.min(1, Math.max(0, v)) })),

      // ---- battle pass ----
      grantXp: (amount) => {
        const s = get();
        const before = levelFromXp(s.xp).level;
        const xp = s.xp + Math.max(0, Math.floor(amount));
        const after = levelFromXp(xp).level;
        set({ xp });
        // ANTI-CHEAT (Task 108): cosmetic LOCAL animation only — the server
        // awarded the real xp when the action happened, and the session
        // heartbeat overwrites this counter with the DB truth. No reward, no
        // toast.
        return { xpGained: amount, leveledUp: after > before, newLevel: after };
      },
      adoptServerXp: (serverXp) => {
        // USER SPEC: DATABASE ONLY — overwrite the local counter with the DB
        // value on every session sync, even when the local copy is ahead (a
        // stale localStorage, an old device or guest xp never wins).
        if (Number.isFinite(serverXp) && serverXp >= 0) set({ xp: Math.floor(serverXp) });
      },
      markDailyCaseOpened: (caseId) => {
        set((s) => ({ dailyOpens: { ...s.dailyOpens, [caseId]: Date.now() } }));
      },

      // ---- provably fair ----
      ensurePF: () => {
        const s = get();
        if (s.pfServerSeed) {
          if (!s.pfReady) set({ pfReady: true });
          return;
        }
        const serverSeed = generateServerSeed();
        const salt = generateSalt();
        const clientSeed = s.pfClientSeed || generateClientSeed();
        set({
          pfReady: true,
          pfServerSeed: serverSeed,
          pfSalt: salt,
          pfClientSeed: clientSeed,
          pfPublicHash: computePublicHash(serverSeed, salt),
          pfNonce: 0,
        });
      },
      drawCase: (caseDef) => {
        get().ensurePF();
        const s = get();
        const nonce = s.pfNonce + 1;
        const proof = drawCasePF(
          caseDef,
          s.pfServerSeed,
          s.pfClientSeed,
          nonce,
          s.pfPublicHash
        );
        const record: PFRollRecord = {
          nonce: proof.nonce,
          caseId: caseDef.id,
          skinId: proof.skin.id,
          clientSeed: proof.clientSeed,
          serverSeedHash: proof.serverSeedHash,
          float: proof.float,
          at: Date.now(),
        };
        set({ pfNonce: nonce, pfRolls: [record, ...s.pfRolls].slice(0, 150) });
        return proof;
      },
      revealServerSeed: () => set((s) => rotatePair(s)),
      setClientSeed: (seed) =>
        set((s) =>
          rotatePair(s, seed.trim() ? seed.trim().slice(0, 64) : generateClientSeed())
        ),

      // ---- case battles ----
      createBattle: (type, rounds, mode = "standard", potRule = "winner") => {
        const spec = BATTLE_TYPES[type];
        // USER SPEC (Task 42): SHARED is a every-player split — it can never
        // exist in the 2v2 team format
        if (potRule === "shared" && spec.teamMode) return "";
        // USER SPEC: the battle price leaves your balance the moment you open
        // the battle — pressing LEAVE BATTLE in the waiting room refunds it.
        if (!get().pay(battleEntry({ rounds }), rounds.length)) return "";
        const id = newBattleId();
        const colorOrder = shuffledColorOrder();
        // USER SPEC (2v2): the battle creator takes the first seat — CT, left side
        const you = makePlayer({
          name: "You",
          isYou: true,
          team: teamForSeat(type, 0),
          side: spec.teamMode ? 0 : undefined,
          color: colorOrder[0],
        });
        const battle: Battle = {
          id,
          type,
          mode,
          potRule,
          maxPlayers: spec.players,
          teamMode: spec.teamMode,
          rounds,
          status: "waiting",
          createdAt: Date.now(),
          players: [you],
          colorOrder,
          botCalls: {},
          fullSince: null,
        };
        set((s) => ({ battles: [battle, ...s.battles].slice(0, 100) }));
        return id;
      },
      joinBattle: (id) => {
        const s = get();
        const b = s.battles.find((x) => x.id === id);
        if (!b || b.status !== "waiting" || emptySeats(b) <= 0 || seatOfYou(b)) return false;
        // USER SPEC: joining charges the entry up front — leaving refunds it.
        if (!get().pay(battleEntry(b))) return false;
        const seat = b.players.length;
        // USER SPEC (2v2): you land on the first free seat (thinner team first,
        // then the open LEFT/RIGHT slot) — and you can move to any open seat in
        // the waiting room while the battle waits.
        const open = b.teamMode ? openSeat(b.players) : null;
        const you = makePlayer({
          name: "You",
          isYou: true,
          team: open ? open.team : teamForSeat(b.type, seat),
          side: open?.side,
          color: b.colorOrder[seat % b.colorOrder.length],
        });
        const players = [...b.players, you];
        set({
          battles: s.battles.map((x) =>
            x.id === id
              ? { ...x, players, fullSince: players.length >= x.maxPlayers ? Date.now() : null }
              : x
          ),
        });
        return true;
      },
      leaveBattle: (id) => {
        const s = get();
        const b = s.battles.find((x) => x.id === id);
        if (!b) return;
        // USER SPEC: LEAVE BATTLE on a battle that has not started refunds the
        // entry that was taken when the battle was opened/joined.
        if (b.status === "waiting" && b.players.some((p) => p.isYou)) {
          const refund = battleEntry(b);
          set((st) => ({
            balance: st.balance + refund,
            totalOpened: Math.max(0, st.totalOpened - b.rounds.length),
          }));
        }
        // only real humans keep a player-created battle alive; if you leave and
        // no other real human is seated, the battle disbands (NPC seats are simulated)
        const others = b.players.filter((p) => !p.isYou && !p.isBot);
        if (others.length === 0 && !b.npcSeed) {
          set({ battles: s.battles.filter((x) => x.id !== id) });
          return;
        }
        set({
          battles: s.battles.map((x) =>
            x.id === id
              ? {
                  ...x,
                  players: x.players.filter((p) => !p.isYou),
                  botVote: null,
                  fullSince: null,
                }
              : x
          ),
        });
      },
      disbandBattle: (id) => {
        const b = get().battles.find((x) => x.id === id);
        // refund a paid, not-yet-started entry when a battle is torn down
        if (b && b.status === "waiting" && b.players.some((p) => p.isYou)) {
          set((st) => ({ balance: st.balance + battleEntry(b) }));
        }
        set((s) => ({ battles: s.battles.filter((x) => x.id !== id) }));
      },
      seatBot: (id, opts) => {
        const s = get();
        const b = s.battles.find((x) => x.id === id);
        if (!b || b.status !== "waiting" || emptySeats(b) <= 0) return false;
        const seat = b.players.length;
        const open = b.teamMode ? openSeat(b.players) : null;
        // USER SPEC (Task 42): the player can hand-pick the bot AND the seat —
        // requested team/side must actually be free; the requested name must
        // not already sit in the room
        const wantTeam = opts?.team ?? (open ? open.team : teamForSeat(b.type, seat));
        const wantSide = opts?.side ?? open?.side;
        if (
          b.teamMode &&
          b.players.some((p) => p.team === wantTeam && (p.side ?? 0) === (wantSide ?? 0))
        )
          return false;
        const taken = b.players.map((p) => p.name);
        const name =
          opts?.name && !taken.includes(opts.name)
            ? opts.name
            : makeBot(taken).name;
        const bot = makePlayer({
          name,
          isBot: true,
          team: wantTeam,
          side: wantSide,
          color: b.colorOrder[seat % b.colorOrder.length],
        });
        const players = [...b.players, bot];
        set({
          battles: s.battles.map((x) =>
            x.id === id
              ? { ...x, players, fullSince: players.length >= x.maxPlayers ? Date.now() : x.fullSince }
              : x
          ),
        });
        return true;
      },
      /**
       * USER SPEC (Task 43): kick a bot out of the room while the battle is
       * still waiting — the seat opens again (the auto-start countdown is
       * cancelled by the room when the room stops being full).
       */
      kickBot: (id, playerId) => {
        const s = get();
        const b = s.battles.find((x) => x.id === id);
        if (!b || b.status !== "waiting") return false;
        const target = b.players.find((p) => p.id === playerId);
        if (!target || !target.isBot) return false; // only bots, never players
        set({
          battles: s.battles.map((x) =>
            x.id === id
              ? {
                  ...x,
                  players: x.players.filter((p) => p.id !== playerId),
                  fullSince: null,
                  botCalls: Object.fromEntries(
                    Object.entries(x.botCalls).filter(([pid]) => pid !== playerId)
                  ),
                }
              : x
          ),
        });
        return true;
      },
      /** USER SPEC (2v2): pick any open seat — the other team, or the free
          LEFT/RIGHT slot inside your own team. Max one player per seat. */
      pickSeat: (id, team, side) => {
        const s = get();
        const b = s.battles.find((x) => x.id === id);
        if (!b || b.status !== "waiting" || !b.teamMode) return false;
        const me = b.players.find((p) => p.isYou);
        if (!me) return false;
        // already sitting exactly there → nothing to change
        if (me.team === team && (me.side ?? 0) === side) return false;
        // the seat must be free (max one player per team-side; legacy players
        // without an explicit side count on the left)
        if (b.players.some((p) => p.id !== me.id && p.team === team && (p.side ?? 0) === side)) return false;
        set({
          battles: s.battles.map((x) =>
            x.id === id
              ? { ...x, players: x.players.map((p) => (p.isYou ? { ...p, team, side } : p)) }
              : x
          ),
        });
        return true;
      },
      /** Every human must call for bots before the empty seats fill up. */
      callBots: (id) => {
        const s = get();
        const b = s.battles.find((x) => x.id === id);
        if (!b || b.status !== "waiting") return "no-seat";
        if (emptySeats(b) <= 0) return "full";
        const botCalls = { ...b.botCalls };
        for (const p of b.players) if (!p.isBot) botCalls[p.id] = true;
        const humans = b.players.filter((p) => !p.isBot);
        const allCalled = humans.every((p) => botCalls[p.id]);
        if (!allCalled) {
          // multi-human room: wait for the rest — bots drop in once everyone agreed
          set({ battles: s.battles.map((x) => (x.id === id ? { ...x, botCalls } : x)) });
          return "called";
        }
        // unanimous → bots take every empty seat (unique [RBbot] names)
        const players = [...b.players];
        let seat = players.length;
        while (players.length < b.maxPlayers) {
          const open = b.teamMode ? openSeat(players) : null;
          players.push(
            makeBot(
              players.map((p) => p.name),
              open ? open.team : teamForSeat(b.type, seat),
              b.colorOrder[seat % b.colorOrder.length],
              open?.side
            )
          );
          seat += 1;
        }
        set({
          battles: s.battles.map((x) =>
            x.id === id ? { ...x, players, botCalls, fullSince: Date.now() } : x
          ),
        });
        return "filled";
      },
      markBattlePlaying: (id) =>
        set((s) => ({
          battles: s.battles.map((x) => (x.id === id ? { ...x, status: "playing" } : x)),
        })),
      finishBattle: (id, results, winnerIds) =>
        set((s) => {
          const b = s.battles.find((x) => x.id === id);
          if (!b) return {};
          // potTotal stores the DROP VALUE the winner actually took — the sum of
          // every skin that dropped in the battle — never the entries/pool.
          const finished: Battle = {
            ...b,
            status: "finished",
            results,
            winnerIds,
            potTotal: results.reduce((acc, r) => acc + r.total, 0),
          };
          return {
            battles: s.battles.filter((x) => x.id !== id),
            battleHistory: [finished, ...s.battleHistory].slice(0, 20),
          };
        }),
      upsertServerBattle: (b) =>
        set((s) => ({
          battles: [b, ...s.battles.filter((x) => x.id !== b.id)].slice(0, 100),
        })),
      npcTrafficTick: () => {
        const s = get();
        const now = Date.now();
        let battles = [...s.battles];
        let battleHistory = s.battleHistory;
        let balanceDelta = 0;

        // USER SPEC: a battle NEVER starts and NEVER resolves while it holds
        // only bots — bot vs bot is forbidden. A bot-seeded room waits with its
        // bots until a real player joins and starts it (with bots or after the
        // room fills). The old headless auto-resolve of full bot rooms is gone.

        // 1) your own full-but-abandoned waiting battle (left the room page) → disband after a minute
        //    the entry was already taken when the battle was opened — refund it
        for (const b of battles) {
          if (
            b.status === "waiting" &&
            emptySeats(b) === 0 &&
            b.players.some((p) => p.isYou) &&
            b.fullSince &&
            now - b.fullSince > 60_000
          ) {
            battles = battles.filter((x) => x.id !== b.id);
            balanceDelta += battleEntry(b);
          }
        }
        // 3) stale NPC seeds nobody touched for 10 minutes → quietly removed
        battles = battles.filter(
          (b) => !(b.npcSeed && !b.players.some((p) => p.isYou) && now - b.createdAt > 600_000)
        );
        // 3) site bots drift into bot-seeded battles — even ones a real player
        //    is already waiting in ("waiting for more players to join").
        //    USER SPEC caps: at most 3 bots waiting per battle, and never the
        //    last seat — the room must keep a free seat so a real player can
        //    still join, and it will not start until that player arrives.
        const joinable = battles.filter((b) => {
          if (b.status !== "waiting" || !b.npcSeed || emptySeats(b) <= 0) return false;
          const bots = b.players.filter((p) => p.isBot).length;
          return bots < 3 && bots < b.maxPlayers - 1;
        });
        if (joinable.length > 0 && Math.random() < 0.45) {
          const target = joinable[Math.floor(Math.random() * joinable.length)];
          const seat = target.players.length;
          const open = target.teamMode ? openSeat(target.players) : null;
          const bot = makeBot(
            target.players.map((p) => p.name),
            open ? open.team : teamForSeat(target.type, seat),
            target.colorOrder[seat % target.colorOrder.length],
            open?.side
          );
          battles = battles.map((x) =>
            x.id === target.id
              ? {
                  ...x,
                  players: [...x.players, bot],
                  // fullSince stays null — a bot-seeded room never fills up on
                  // its own, so nothing here can ever auto-start the battle
                  fullSince: null,
                }
              : x
          );
        }
        // 4) keep the lobby alive: top up bot battles when they run dry
        //    (user spec: up to 100 open battles)
        const waitingSeeds = battles.filter((b) => b.status === "waiting" && b.npcSeed && !b.players.some((p) => p.isYou));
        if (waitingSeeds.length < 14 && battles.length < 100) {
          const add = Math.min(3, 14 - waitingSeeds.length);
          for (let i = 0; i < add; i++) {
            if (Math.random() < 0.8) battles = [...battles, makeBotBattle()];
          }
        }

        if (balanceDelta !== 0) {
          set((st) => ({ battles, battleHistory, balance: st.balance + balanceDelta }));
        } else {
          set({ battles, battleHistory });
        }
      },
    }),
    {
      partialize: (s) => ({ ...s, battles: s.battles.filter((x) => !x.global) }),
      name: "rollbox-store",
      version: 11,
      // v1: inventory removed — wins are credited straight to the balance now.
      // v2: battles system — normalize battle fields, refund mid-game reloads.
      // v3: battles rework — CRAZY mode, player colors, [RBbot]-only bots, Call Bots.
      // v4: entries are charged when a battle is opened/joined (user spec) —
      //     v3 waiting rooms were unpaid, so they are disbanded on upgrade.
      // v5: bots never fight bots — bot-seeded rooms keep ≤3 bots and always a
      //     free seat for a real player; case favorites added to the picker.
      // v6: 2v2 seat sides — every team player gets an explicit LEFT/RIGHT seat
      //     (first member of each team → left, second → right).
      // v7: USER SPEC — the inventory is BACK (fed exclusively by the EXCHANGE;
      //     game wins still credit coins directly). Catalog snapshots are kept
      //     as items, sell-back refunds the coins paid.
      // v9 (USD economy, Task 28): the site currency is USD 1:1 with market
      // value — every persisted economy number (balance, inventory values,
      // battle records) was re-denominated ÷10 on upgrade from ≤v8.
      // v10 (Task 29): the ÷10 is REVERTED — the owner ruled the pre-flip
      // numbers were already USD, so the economy returns to the original
      // scale while keeping the green-$ display. Guests upgrading from v9
      // get their numbers ×10 back; stores ≤v8 never had their numbers
      // scaled and pass through untouched.
      // v11 (Task 30): the FINAL ruling — the X10 scale is NOT good, the
      // economy goes back to 1X (every price = real market USD 1:1). Guests
      // upgrading from v10 get their numbers ÷10 (purchasing power stays
      // 1:1 — the same pattern as the DB re-denomination); other versions
      // pass through untouched.
      // v8: USER SPEC (Task 104) — the single daily-case timestamp is replaced
      //     by PER-CASE cooldowns (dailyOpens: Record<caseId, ts>); drop the
      //     legacy lastDaily field on upgrade.
      migrate: (persisted, version) => {
        const p = { ...(persisted as Record<string, unknown>) };
        delete p.lastDaily;
        if (!p.dailyOpens || typeof p.dailyOpens !== "object") p.dailyOpens = {};
        // v7: inventory returns — normalize whatever survived from older versions
        if (!Array.isArray(p.inventory)) p.inventory = [];
        p.inventory = (p.inventory as InvItem[])
          .filter((i) => i && typeof i.uid === "string" && typeof i.v === "number" && typeof i.n === "string")
          .slice(0, 200);
        // v8 (Task 75): the SETTINGS sound-volume slider — keep old saved
        // stores on the default until the player picks a volume himself
        if (typeof p.soundVolume !== "number" || !Number.isFinite(p.soundVolume)) p.soundVolume = 0.9;
        const battles = (Array.isArray(p.battles) ? p.battles : []) as Battle[];
        // a reload mid-battle forfeits nothing: the human's entry is refunded
        let refund = 0;
        const normalized = battles.filter((b) => {
          if (b && b.status === "playing" && b.players?.some((pl) => pl.isYou)) {
            refund += battleEntry(b);
            return false;
          }
          // pre-v4 waiting rooms never had their entry taken — drop them on upgrade
          if ((version ?? 4) < 4 && b && b.status === "waiting" && b.players?.some((pl) => pl.isYou)) {
            return false;
          }
          return b && b.status === "waiting";
        });
        for (const b of normalized) {
          b.mode = b.mode === "crazy" ? "crazy" : "standard";
          // Task 42: default the pot rule on anything that predates it
          b.potRule = b.potRule === "jackpot" || b.potRule === "shared" ? b.potRule : "winner";
          // SHARED can never exist in the team format — demote to winner rule
          if (b.potRule === "shared" && b.teamMode) b.potRule = "winner";
          b.colorOrder = Array.isArray(b.colorOrder) && b.colorOrder.length === 4 ? b.colorOrder : [0, 1, 2, 3];
          b.botCalls = {};
          b.fullSince = null;
          // v5 USER SPEC: bot-seeded rooms keep at most 3 bots and always a free
          // seat — evict the extra bots so no room is stuck bot-vs-bot forever
          if (b.npcSeed) {
            let excess = b.players.filter((pl) => pl.isBot).length - Math.min(3, b.maxPlayers - 1);
            if (excess > 0) {
              b.players = b.players.filter((pl) => {
                if (pl.isBot && excess > 0) {
                  excess -= 1;
                  return false;
                }
                return true;
              });
            }
          }
          b.players = (b.players ?? []).map((pl, i) => ({
            ...pl,
            color: typeof pl.color === "number" ? pl.color : i % 4,
            // every bot must wear the [RBbot] tag — re-badge legacy ones
            name: pl.isBot && !pl.name?.includes("[RBbot]") ? "[RBbot] Gabey" : pl.name,
          } as BattlePlayer));
          // v6 USER SPEC: backfill the LEFT/RIGHT seat inside each 2v2 team —
          // legacy members are seated in array order (first → left)
          if (b.teamMode) {
            const seen = { 0: 0, 1: 0 } as Record<number, number>;
            b.players = b.players.map((pl) => {
              if (pl.side !== undefined) return pl;
              const side = (seen[pl.team] ?? 0) as 0 | 1;
              seen[pl.team] = side + 1;
              return { ...pl, side };
            });
          }
        }
        if (!Array.isArray(p.favoriteCases)) p.favoriteCases = [];
        p.favoriteCases = (p.favoriteCases as string[]).filter((id) => typeof id === "string");
        p.battles = normalized;
        if (!Array.isArray(p.battleHistory)) p.battleHistory = [];
        p.battleHistory = (p.battleHistory as Battle[]).map((b) => ({
          ...b,
          mode: b.mode === "crazy" ? "crazy" : "standard",
          potRule: b.potRule === "jackpot" || b.potRule === "shared" ? b.potRule : "winner",
          botCalls: {},
        }));
        if (refund > 0 && typeof p.balance === "number") p.balance += refund;
        // v10 (Task 29): restore the Task-28 ÷10 — the numbers go back to the
        // ORIGINAL scale the owner calls dollars. Only stores that actually
        // went through the v9 ÷10 migration are scaled ×10; anything older
        // still carries the original numbers and must NOT be touched.
        if (version === 9) {
          const restore = (n: number): number =>
            Number.isFinite(n) ? Math.max(0.01, Math.round(n * 10 * 100) / 100) : n;
          if (typeof p.balance === "number" && Number.isFinite(p.balance)) p.balance = restore(p.balance);
          if (typeof p.bestValue === "number" && Number.isFinite(p.bestValue)) p.bestValue = restore(p.bestValue);
          for (const it of p.inventory as InvItem[]) it.v = restore(it.v);
          for (const b of [...normalized, ...(p.battleHistory as Battle[])]) {
            for (const r of b.results ?? []) {
              r.total = restore(r.total);
              for (const pull of r.pulls ?? []) pull.value = restore(pull.value);
            }
          }
        }
        // v11 (Task 30): FINAL denomination — the X10 scale is out, everything
        // back on the 1X scale (1$ = 1 coin). Only the stores that went through
        // the v10 ×10 restore are scaled ÷10 so purchasing power stays 1:1.
        if (version === 10) {
          const div10 = (n: number): number =>
            Number.isFinite(n) ? Math.max(0.01, Math.round((n / 10) * 100) / 100) : n;
          if (typeof p.balance === "number" && Number.isFinite(p.balance)) p.balance = div10(p.balance);
          if (typeof p.bestValue === "number" && Number.isFinite(p.bestValue)) p.bestValue = div10(p.bestValue);
          for (const it of p.inventory as InvItem[]) it.v = div10(it.v);
          for (const b of [...normalized, ...(p.battleHistory as Battle[])]) {
            for (const r of b.results ?? []) {
              r.total = div10(r.total);
              for (const pull of r.pulls ?? []) pull.value = div10(pull.value);
            }
          }
        }
        return p as unknown as CaseStore;
      },
    }
  )
);
