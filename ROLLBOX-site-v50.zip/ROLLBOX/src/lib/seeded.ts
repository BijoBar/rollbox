// ============ seeded PRNG (Task 31: synchronized battle reels) ============
// USER SPEC: in a battle every player must see THE EXACT SAME roulette roll —
// every skin on every reel identical for all viewers (the old strips were
// built with Math.random per client, so each viewer watched a different reel
// and only the final drop matched). The fix: every cosmetic reel decision is
// derived from a seed both viewers already share (battle id + seat + round +
// the pull itself), fed through a deterministic PRNG. Same input → the same
// strip on every screen. Server results stay the single source of truth —
// this only syncs the CINEMATICS.

/** FNV-1a — fast, tiny, well-distributed string hash (32-bit). */
export function hashSeed(input: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** mulberry32 — 32-bit seeded PRNG: tiny, fast, quality enough for visuals. */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export type Rng = () => number;

/** Pick a random element from a pool with the given rng (Math.random-compatible). */
export const rngFrom = <T,>(pool: readonly T[], rng: Rng): T =>
  pool[Math.floor(rng() * pool.length)];
