"use client";

import { useCaseStore } from "./store";
import type { Rarity } from "./cases";

// ============================================================================
// ROLLBOX sound engine v3 — CS2-style case-opening soundscape.
//
// Two layers:
//   1) OPTIONAL real samples — drop files into public/sounds/ and they are
//      picked up automatically (nice for actual CS2 rips you own):
//        click.(mp3|ogg|wav)   – UI button click
//        case-open.(...)       – unboxing start (case latch)
//        tick.(...)            – reel ratchet detent
//        land.(...)            – reel locks on the winner
//        reveal.(...)          – final reveal sting
//   2) Synth fallback — everything is synthesized live with WebAudio:
//   • case latch "clack" + spring rattle when the unboxing starts
//   • air "whoosh" layer whose energy follows the reel velocity
//   • mechanical ratchet detent ticks (louder + woodier as the reel slows)
//   • heavy woody "thock" when the reel locks on the winner
//   • rarity reveal stings — from a soft chime up to the full jackpot fanfare
// ============================================================================

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let noiseBuf: AudioBuffer | null = null;

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    // USER SPEC (Task 75): the master gain starts at the SETTINGS slider value
    master.gain.value = Math.min(1, Math.max(0, useCaseStore.getState().soundVolume ?? 0.9));
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  startSampleScan();
  return ctx;
}

/**
 * USER SPEC (Task 75): the SETTINGS sound-volume slider calls this on every
 * move — the whole soundscape (samples + synth) scales live with it.
 */
export function setMasterVolume(v: number): void {
  if (master) master.gain.value = Math.min(1, Math.max(0, v));
}

function out(): AudioNode {
  return master ?? (ac()?.destination as AudioNode);
}

function enabled(): boolean {
  return useCaseStore.getState().soundOn;
}

// ---- optional real samples (public/sounds/*.(mp3|ogg|wav)) ------------------

const SAMPLES = ["click", "case-open", "tick", "land", "reveal"] as const;
type SampleName = (typeof SAMPLES)[number];
const sampleBufs = new Map<SampleName, AudioBuffer>();
let scanStarted = false;

function startSampleScan() {
  if (scanStarted) return;
  scanStarted = true; // set FIRST — ac() re-enters here
  const c = ac();
  if (!c) return;
  for (const name of SAMPLES) {
    for (const ext of ["mp3", "ogg", "wav"]) {
      fetch(`/sounds/${name}.${ext}`)
        .then((r) => (r.ok ? r.arrayBuffer() : Promise.reject(new Error("no sample"))))
        .then((ab) => c.decodeAudioData(ab))
        .then((buf) => {
          if (!sampleBufs.has(name)) sampleBufs.set(name, buf);
        })
        .catch(() => {
          /* no real sample for this sfx — synth fallback stays */
        });
    }
  }
}

/** Play a real sample when present. Returns false so the caller can synth. */
function playSample(name: SampleName, vol = 1, rate = 1): boolean {
  const buf = sampleBufs.get(name);
  const c = ac();
  if (!c || !buf) return false;
  const src = c.createBufferSource();
  src.buffer = buf;
  src.playbackRate.value = rate;
  const g = c.createGain();
  g.gain.value = vol;
  src.connect(g).connect(out());
  src.start();
  return true;
}

// ---- shared buffers / nodes ------------------------------------------------

function noise(): AudioBuffer | null {
  const c = ac();
  if (!c) return null;
  if (!noiseBuf) {
    noiseBuf = c.createBuffer(1, c.sampleRate, c.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  return noiseBuf;
}

interface BurstOpts {
  dur?: number;
  freq?: number;
  q?: number;
  gain?: number;
  type?: BiquadFilterType;
  delay?: number;
}

/** Filtered noise burst — the body of clicks / ratchet detents / thumps. */
function burst({ dur = 0.03, freq = 3000, q = 6, gain = 0.1, type = "bandpass", delay = 0 }: BurstOpts) {
  const c = ac();
  const buf = noise();
  if (!c || !buf) return;
  const t0 = c.currentTime + delay;
  const src = c.createBufferSource();
  src.buffer = buf;
  src.loop = true;
  src.playbackRate.value = 0.9 + Math.random() * 0.2;
  const f = c.createBiquadFilter();
  f.type = type;
  f.frequency.setValueAtTime(freq, t0);
  f.Q.value = q;
  const g = c.createGain();
  g.gain.setValueAtTime(gain, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  src.connect(f).connect(g).connect(out());
  src.start(t0, Math.random() * 0.5);
  src.stop(t0 + dur + 0.05);
}

/** Pure/numeric tone with exponential decay. */
function tone(
  freq: number,
  dur = 0.08,
  type: OscillatorType = "triangle",
  gain = 0.06,
  delay = 0,
  freqEnd?: number
) {
  const c = ac();
  if (!c) return;
  const t0 = c.currentTime + delay;
  const osc = c.createOscillator();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (freqEnd !== undefined) osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t0 + dur);
  const g = c.createGain();
  g.gain.setValueAtTime(gain, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g).connect(out());
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

/** Metallic detent ping — two slightly detuned sines through a highpass feel. */
function ping(freq: number, dur = 0.03, gain = 0.03, delay = 0) {
  tone(freq, dur, "sine", gain, delay);
  tone(freq * 2.51, dur * 0.6, "sine", gain * 0.4, delay);
}

/** Low body thump (case slam / lock). */
function thump(delay = 0, gain = 0.16) {
  tone(150, 0.1, "sine", gain, delay, 55);
  burst({ dur: 0.05, freq: 240, q: 1.2, gain: gain * 0.7, type: "lowpass", delay });
}

/** Shimmer — bright airy sparkle used on rare stings. */
function shimmer(dur = 0.7, gain = 0.035, delay = 0) {
  burst({ dur, freq: 7200, q: 0.8, gain, type: "highpass", delay });
}

/** Warm bell-ish note — fundamental + quiet octave/fifth overtones (no saw buzz). */
function chime(freq: number, dur: number, gain: number, delay = 0) {
  tone(freq, dur, "sine", gain, delay);
  tone(freq * 2.003, dur * 0.7, "sine", gain * 0.3, delay);
  tone(freq * 2.997, dur * 0.4, "sine", gain * 0.12, delay);
}

/** Filtered-noise riser — breathy sweep used before big reveals (replaces saw risers). */
function noiseSweep(dur: number, f0: number, f1: number, gain: number, delay = 0) {
  const c = ac();
  const buf = noise();
  if (!c || !buf) return;
  const t0 = c.currentTime + delay;
  const src = c.createBufferSource();
  src.buffer = buf;
  src.loop = true;
  const f = c.createBiquadFilter();
  f.type = "bandpass";
  f.Q.value = 1.1;
  f.frequency.setValueAtTime(f0, t0);
  f.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
  const g = c.createGain();
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(gain, t0 + dur * 0.55);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  src.connect(f).connect(g).connect(out());
  src.start(t0, Math.random() * 0.5);
  src.stop(t0 + dur + 0.05);
}

// ---- whoosh loop (spin air layer) ------------------------------------------

let whoosh: { src: AudioBufferSourceNode; f: BiquadFilterNode; g: GainNode } | null = null;

// USER SPEC (R40 — the rolldrop LOOP bug, final nail): a HARD LEASH on the
// whoosh. spinStart stamps whooshFedAt; spinEnergy re-feeds it on every push
// (the case reel feeds every frame, the upgrader every ≤2.6s, the warp twice).
// A 1s watchdog kills any whoosh that has not been fed for 16s — no future
// code path, race or missed spinEnd can EVER leave the drone running again.
const WHOOSH_LEASH_MS = 16000;
let whooshFedAt = 0;
let whooshWatchdog: number | null = null;

/** Fade the whoosh out and release it — unconditionally, right now. Idempotent
 *  (a no-op when nothing loops). This is the ONE killer every path shares. */
function killWhoosh() {
  if (!whoosh || !ctx) return;
  const t = ctx.currentTime;
  whoosh.g.gain.setTargetAtTime(0.0001, t, 0.09);
  const w = whoosh;
  whoosh = null;
  window.setTimeout(() => {
    try {
      w.src.stop();
    } catch {
      /* already stopped */
    }
  }, 400);
}

function ensureWatchdog() {
  if (whooshWatchdog !== null) return;
  whooshWatchdog = window.setInterval(() => {
    if (whoosh && Date.now() - whooshFedAt > WHOOSH_LEASH_MS) killWhoosh();
  }, 1000);
}

// ---- public sfx API ---------------------------------------------------------

export const sfx = {
  /** Ratchet detent tick while the reel scrolls. v = velocity 0..1 (1 = fastest). */
  tick(v = 0.5) {
    if (!enabled()) return;
    const slow = 1 - Math.min(1, Math.max(0, v));
    if (playSample("tick", 0.5 + slow * 0.5, 0.96 + Math.random() * 0.07)) return;
    // mechanical detent: dry filtered transient + woody body knock —
    // no metallic ping; grows louder & lower as the reel slows down
    burst({
      dur: 0.011 + slow * 0.011,
      freq: 1500 + slow * 700 + Math.random() * 350,
      q: 2.4,
      gain: 0.035 + slow * 0.065,
    });
    tone(560 + Math.random() * 160, 0.03 + slow * 0.025, "triangle", 0.016 + slow * 0.036, 0.001, 300);
  },

  /** Generic UI click — soft, dry tap (no beep). */
  click() {
    if (!enabled()) return;
    if (playSample("click", 0.85)) return;
    // tiny air transient + soft low body — feels like a gentle mouse tap
    burst({ dur: 0.007, freq: 4800, q: 0.8, gain: 0.045, type: "highpass" });
    tone(185, 0.05, "sine", 0.03, 0.001, 125);
  },

  /** Coin payout sparkle. */
  coins() {
    if (!enabled()) return;
    ping(1320, 0.09, 0.05);
    ping(1760, 0.1, 0.05, 0.07);
    ping(2637, 0.14, 0.045, 0.15);
  },

  /** Legacy win jingle (kept for login / battles). */
  win(big = false) {
    if (!enabled()) return;
    tone(660, 0.1, "triangle", 0.06);
    tone(880, 0.1, "triangle", 0.06, 0.09);
    tone(1320, 0.16, "triangle", 0.07, 0.18);
    if (big) {
      thump(0.0, 0.1);
      tone(1760, 0.22, "triangle", 0.07, 0.3);
      tone(2217, 0.3, "triangle", 0.07, 0.42);
      shimmer(0.5, 0.03, 0.42);
    }
  },

  error() {
    if (!enabled()) return;
    tone(220, 0.15, "sawtooth", 0.045);
    tone(180, 0.2, "sawtooth", 0.045, 0.12);
  },

  /** USER SPEC (Task 177): the SUPPORT chat ping — a soft, friendly two-note
   *  "ding" that plays on BOTH sides (player + admin) whenever a new message
   *  or a new SUPPORT CASE lands live. Quiet by design: it can fire while the
   *  user is anywhere on the site. */
  notify() {
    if (!enabled()) return;
    ping(1174.66, 0.14, 0.05); // D6
    ping(1567.98, 0.2, 0.045, 0.09); // G6 — the answering note
    shimmer(0.18, 0.012, 0.02);
  },

  // ---- unboxing v2 ---------------------------------------------------------

  /** CS2-style case unlock: latch clicks + spring rattle + lid pop + soft slam. */
  caseOpen() {
    if (!enabled()) return;
    if (playSample("case-open", 0.9)) return;
    // latch: two dry metallic clicks
    burst({ dur: 0.016, freq: 3400, q: 3.5, gain: 0.085 });
    burst({ dur: 0.016, freq: 2500, q: 3.5, gain: 0.07, delay: 0.06 });
    // spring rattle — three fast decaying detents
    burst({ dur: 0.01, freq: 4200, q: 4, gain: 0.05, delay: 0.11 });
    burst({ dur: 0.009, freq: 4700, q: 4, gain: 0.034, delay: 0.132 });
    burst({ dur: 0.008, freq: 5200, q: 4, gain: 0.02, delay: 0.154 });
    // lid pops open: body knock + soft slam
    tone(500, 0.1, "triangle", 0.045, 0.17, 210);
    thump(0.2, 0.15);
    burst({ dur: 0.05, freq: 1500, q: 1.6, gain: 0.05, delay: 0.2 });
  },

  /** Start the air-whoosh loop (call once when the reel starts moving).
   *  R40: every start arms the leash watchdog — the loop can never outlive
   *  its feeding by more than WHOOSH_LEASH_MS, no matter what the callers do. */
  spinStart() {
    if (!enabled()) return;
    const c = ac();
    const buf = noise();
    if (!c || !buf || whoosh) return;
    const src = c.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 260;
    f.Q.value = 0.7;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, c.currentTime);
    src.connect(f).connect(g).connect(out());
    src.start();
    whoosh = { src, f, g };
    whooshFedAt = Date.now();
    ensureWatchdog();
  },

  /** Feed reel velocity (0..1) into the whoosh layer. Re-feeds the leash. */
  spinEnergy(v = 0) {
    if (!whoosh || !ctx) return;
    whooshFedAt = Date.now();
    const t = ctx.currentTime;
    const n = Math.min(1, Math.max(0, v));
    whoosh.g.gain.setTargetAtTime(0.0001 + n * 0.055, t, 0.06);
    whoosh.f.frequency.setTargetAtTime(240 + n * 1100, t, 0.08);
  },

  /** Fade the whoosh out and release it. */
  spinEnd() {
    killWhoosh();
  },

  /** USER SPEC (R40 — the rolldrop LOOP bug): kill ANY looping whoosh RIGHT
   *  NOW, unconditionally. CaseOpener calls this at the rolldrop hit and at
   *  the bonus-reel start — after a hit, NO loop may exist until the bonus
   *  reel finishes. Idempotent and safe to call from anywhere. */
  killLoops() {
    killWhoosh();
  },

  /** Final detent snap + solid woody lock when a reel lands on the winner. */
  lock() {
    if (!enabled()) return;
    if (playSample("land", 0.95)) return;
    burst({ dur: 0.012, freq: 2100, q: 3, gain: 0.09 });
    tone(760, 0.06, "triangle", 0.05, 0.004, 340);
    thump(0.018, 0.22);
    burst({ dur: 0.055, freq: 850, q: 1.3, gain: 0.05, delay: 0.03 });
  },

  /**
   * Rarity reveal sting — the "unboxing music" moment.
   * Escalates from a soft chime (low tiers) to the full jackpot fanfare.
   */
  revealSting(rarity: Rarity) {
    if (!enabled()) return;
    // one real reveal sample covers every tier — only its volume scales
    if (sampleBufs.has("reveal")) {
      const vol = (
        {
          consumer: 0.55,
          milspec: 0.65,
          restricted: 0.75,
          classified: 0.85,
          covert: 0.95,
          contraband: 1,
        } as Record<Rarity, number>
      )[rarity];
      playSample("reveal", vol);
      return;
    }
    switch (rarity) {
      case "consumer":
        chime(523.25, 0.18, 0.05);
        break;
      case "milspec":
        chime(587.33, 0.14, 0.05);
        chime(880, 0.26, 0.055, 0.1);
        break;
      case "restricted":
        chime(659.26, 0.12, 0.05);
        chime(880, 0.12, 0.055, 0.09);
        chime(1174.66, 0.3, 0.06, 0.18);
        break;
      case "classified":
        chime(587.33, 0.11, 0.05);
        chime(739.99, 0.11, 0.055, 0.08);
        chime(880, 0.11, 0.06, 0.16);
        chime(1174.66, 0.36, 0.07, 0.24);
        shimmer(0.5, 0.026, 0.26);
        break;
      case "covert":
        // breathy riser into a warm power chord
        noiseSweep(0.42, 300, 2400, 0.05);
        thump(0.3, 0.16);
        chime(440, 0.5, 0.05, 0.32);
        chime(554.37, 0.5, 0.045, 0.32);
        chime(659.26, 0.55, 0.045, 0.32);
        chime(880, 0.65, 0.075, 0.37);
        shimmer(0.8, 0.03, 0.4);
        break;
      case "contraband": {
        // full jackpot fanfare: boom → riser → chord stack → bell sparkle tail
        thump(0, 0.24);
        tone(110, 0.7, "sine", 0.09, 0, 50);
        noiseSweep(0.5, 260, 3000, 0.055, 0.05);
        shimmer(0.9, 0.03, 0.1);
        // fanfare stack (A major-ish, triumphant)
        const F = 0.45;
        chime(440, 0.55, 0.05, F);
        chime(554.37, 0.55, 0.045, F);
        chime(659.26, 0.6, 0.045, F);
        chime(880, 0.65, 0.08, F + 0.05);
        chime(1108.73, 0.7, 0.068, F + 0.16);
        chime(1318.51, 0.8, 0.075, F + 0.27);
        // high bell sparkle tail
        ping(2637, 0.5, 0.035, F + 0.42);
        ping(3520, 0.6, 0.03, F + 0.55);
        shimmer(1.1, 0.026, F + 0.45);
        break;
      }
    }
  },
};
