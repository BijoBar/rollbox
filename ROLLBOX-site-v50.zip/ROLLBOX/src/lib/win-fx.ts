/**
 * Tiny window-event bus for the balance win pulse.
 *
 * Any win source (case opener today, battles/exchange tomorrow) fires
 * `emitWinFx(amount)` and the TopBar balance chip plays the floating
 * "+$X" animation — the small win toast is gone, this is the whole
 * notification.
 */
const WIN_EVENT = "rollbox:win";

export function emitWinFx(amount: number): void {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(WIN_EVENT, { detail: { amount } }));
}
