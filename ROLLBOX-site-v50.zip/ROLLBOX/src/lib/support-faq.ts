// ============ ROLLBOX AI — the support chat knowledge base (Task 136) ============
// USER SPEC: the chat answers COMMON questions automatically ("ROLLBOX AI"
// messages). The player picks a quick question (the chips in the chat panel)
// or types free text — this file decides the answer.
//
// EDITING (the owner asked to tune this over time — "אני אשנה במידת הצורך"):
//   • add/remove/reorder entries in SUPPORT_FAQ — the chat chips follow the
//     array order, nothing else to do,
//   • `keywords` are lowercase words that trigger the answer from FREE TEXT —
//     keep them broad (the matcher scores every keyword hit),
//   • the site language is English — keep question/answer in English.
// An in-panel FAQ editor may replace this file later (schema comment, Task 136).

export interface SupportFaqEntry {
  /** The exact question shown as a quick-reply chip in the chat panel. */
  question: string;
  /** The ROLLBOX AI answer sent the moment the question is asked. */
  answer: string;
  /** Lowercase trigger words for free-text matching (comma-separated here). */
  keywords: string[];
}

export const SUPPORT_FAQ: SupportFaqEntry[] = [
  {
    question: "Can I get a refund?",
    // USER SPEC (Task 138): the word Exchange is an in-site link to the
    // EXCHANGE page (/skins) — rendered by the chat panel, markup [text](/path).
    answer:
      "No. All transactions are final and lost funds are non-refundable. However, if you currently hold deposited funds on the website, you may use the [Exchange](/skins) to trade them for skins and withdraw those skins to your Steam account.",
    keywords: ["refund", "refunded", "money back", "funds back", "chargeback", "revert", "reverse", "get my money", "recover my money"],
  },
  {
    question: "How long do withdrawals take?",
    answer:
      "Withdrawals take between 15 minutes and up to 24 hours. If an item has not arrived, or you have any further questions, please request human support and an agent will take a closer look at your case.",
    keywords: ["withdraw", "withdrawal", "payout", "cash out", "cashout", "not arrived", "not arriving", "still waiting", "trade offer", "arrive"],
  },
  {
    question: "How do I deposit funds?",
    answer: "W.I.P — depositing funds is currently a work in progress.",
    keywords: ["deposit", "deposited", "add funds", "add money", "top up", "topup", "payment", "wallet", "buy coins", "put money", "fund my"],
  },
  {
    question: "I have another question",
    answer: "Please click below to reach a human representative.",
    keywords: ["other question", "another question", "different question", "anything else", "speak to someone", "talk to someone", "real person", "live person", "human", "representative", "agent"],
  },
];

/** The chat opener the AI greets every player with (first visit). */
export const SUPPORT_WELCOME =
  "Hey! I'm the ROLLBOX AI assistant. Tap a common question below or type your own — and if I can't solve it, press Request human support and a real agent will jump in.";

/** The message sent when a SUPPORT CASE is created. */
export const SUPPORT_CASE_OPENED =
  "SUPPORT CASE opened — a human agent has been notified and will reply right here in this chat.";

/** The message an agent's close action posts into the conversation. */
export const SUPPORT_CASE_CLOSED =
  "Your support case was closed. If you need anything else, just type here — I'm always around.";

/** The AI answer when NO FAQ entry matches the free text. */
export const SUPPORT_FALLBACK =
  "I couldn't find an exact answer for that in my knowledge base. Try one of the common questions above, or press Request human support and a real agent will take it from here.";

/** The AI note instead of an auto-answer while a human case is open. */
export const SUPPORT_HUMAN_PENDING =
  "You're in the queue for a human agent — they'll reply here in this chat. No need to request again.";

// ---------------------------------------------------------------- matching ----

const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9'\s]/g, " ").replace(/\s+/g, " ").trim();

/**
 * Score one FAQ entry against free text: keyword hits weighted by keyword
 * length (longer phrases are stronger signals). Multi-word keywords must
 * appear as substrings; single words as whole words.
 */
function entryScore(entry: SupportFaqEntry, text: string): number {
  let score = 0;
  for (const kw of entry.keywords) {
    if (!kw) continue;
    if (kw.includes(" ")) {
      if (text.includes(kw)) score += kw.length * 2;
    } else if (new RegExp(`\\b${kw.replace(/[']/g, "'?")}(s|es)?\\b`).test(text)) {
      // the (s|es)? absorbs simple plurals — "withdraw" must catch
      // "withdrawals" the way a player actually types it
      score += kw.length;
    }
  }
  return score;
}

/**
 * Pick the best FAQ answer for a free-text player message.
 * Returns null below the match threshold → the caller sends SUPPORT_FALLBACK.
 */
export function matchFaq(message: string): SupportFaqEntry | null {
  const text = normalize(message);
  if (!text) return null;
  // a quick-question chip (or a retyped common question) MUST hit its own
  // entry — exact normalized question match short-circuits the scoring
  const exact = SUPPORT_FAQ.find((e) => normalize(e.question) === text);
  if (exact) return exact;
  let best: SupportFaqEntry | null = null;
  let bestScore = 0;
  for (const entry of SUPPORT_FAQ) {
    const s = entryScore(entry, text);
    if (s > bestScore) {
      best = entry;
      bestScore = s;
    }
  }
  // threshold: a single short keyword hit (e.g. "vs" = 2) is too weak;
  // require a real signal so the fallback invitation stays honest.
  return bestScore >= 5 ? best : null;
}
