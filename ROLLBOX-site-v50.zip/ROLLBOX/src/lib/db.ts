import { PrismaClient } from '@prisma/client'
import path from 'path'
import fs from 'fs'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

/**
 * WHY this exists: in the standalone production build (`bun run start`) the
 * generated Prisma schema lives in .next/standalone/node_modules/.prisma/client,
 * so a RELATIVE DATABASE_URL (the ZIP ships `file:../db/custom.db`) gets
 * resolved by Prisma against that folder — where the database does not exist —
 * and every DB-touching route returned HTTP 500. Dev (`bun run dev`) was
 * immune because there the schema sits in prisma/.
 *
 * We therefore resolve the SQLite file ourselves and pin it absolutely:
 * 1. absolute URLs pass through untouched
 * 2. relative ones are tried against cwd, cwd/prisma (Prisma's own dev
 *    semantics), then the same two shapes walking up a few parents (covers
 *    launching from inside .next/standalone as well)
 * 3. if the file does not exist anywhere yet (fresh machine before
 *    `bun run db:push`) we fall back to the spot db:push itself creates.
 */
function resolveDatabaseUrl(): string {
  const raw = process.env.DATABASE_URL || 'file:../db/custom.db'
  if (!raw.startsWith('file:')) return raw // not SQLite (e.g. postgres) — pass through
  const rel = raw.slice('file:'.length)
  if (/^([A-Za-z]:[\\/]|[/\\])/.test(rel)) return raw // already absolute
  const bases: string[] = []
  let cur: string | null = process.cwd()
  for (let hops = 0; cur && hops < 5; hops++) {
    bases.push(cur, path.join(cur, 'prisma'))
    const parent = path.dirname(cur)
    if (parent === cur) break
    cur = parent
  }
  for (const base of bases) {
    const abs = path.resolve(base, rel)
    if (fs.existsSync(abs)) return 'file:' + abs
  }
  return 'file:' + path.resolve(process.cwd(), 'prisma', rel)
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['error', 'warn'],
    datasourceUrl: resolveDatabaseUrl(),
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db