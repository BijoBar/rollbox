// ============ ROLLBOX Battle Pass / Level engine ============
// Pure math helpers for XP levels. XP state lives in the persisted case store
// and mirrors into the DATABASE (Player.xp / Player.level — Task 104).
// USER SPEC: the daily reward is a FREE CASE per level vault (level-cases.ts)
// — every case up to the player's level opens free once per 24h, from Level 10.

import { USD_TO_COINS } from "./wear";

export const DAILY_INTERVAL_MS = 24 * 60 * 60 * 1000; // 24h

/** XP needed to advance FROM this level to the next one. */
export function xpForNextLevel(level: number): number {
  return 120 + (level - 1) * 80; // L1->2: 120, L2->3: 200, L3->4: 280 ...
}

/** Total XP sitting at the FLOOR of `level` (sum of every level before it).
 *  USER SPEC (Task 22): the admin panel sets a player's level by pinning his
 *  xp here — so the server's next awardXp (which recomputes the level from
 *  xp) keeps the admin's choice instead of snapping back. */
export function xpFloorForLevel(level: number): number {
  const target = Math.max(1, Math.floor(level));
  let sum = 0;
  for (let l = 1; l < target; l++) sum += xpForNextLevel(l);
  return sum;
}

export interface LevelInfo {
  level: number;
  intoLevel: number; // xp earned inside the current level
  needed: number; // xp needed for the next level
  progress: number; // 0..1
}

/** Resolve a total XP amount into a level + progress breakdown. */
export function levelFromXp(xp: number): LevelInfo {
  let level = 1;
  let remaining = Math.max(0, Math.floor(xp));
  // each level consumes xpForNextLevel(level) xp
  while (remaining >= xpForNextLevel(level)) {
    remaining -= xpForNextLevel(level);
    level++;
  }
  const needed = xpForNextLevel(level);
  return {
    level,
    intoLevel: remaining,
    needed,
    progress: Math.min(1, remaining / needed),
  };
}

/** XP granted for opening a case (based on its price). Task 27: the divisor
 *  IS the site-wide dollar rate — XP always equals the case's USD value, so
 *  the level pacing survives the unified-economy denomination flip. */
export function xpForCase(price: number): number {
  return Math.max(1, Math.round(price / USD_TO_COINS));
}

/** XP for opening a given case — free LEVEL cases scale by tier, not price. */
export function caseXp(caseDef: { price: number; kind?: string; requiredLevel?: number }): number {
  if (caseDef.kind === "level") return Math.max(4, Math.round((caseDef.requiredLevel ?? 10) * 1.2));
  return xpForCase(caseDef.price);
}

/** Milliseconds left until a 24h cooldown that started at `last` (0 = ready). */
export function msLeftFrom(last: number): number {
  const left = last + DAILY_INTERVAL_MS - Date.now();
  return left > 0 ? left : 0;
}

// ===== USER SPEC (Task 104): PER-CASE daily cooldowns =====
// The old single "one daily case per day" gate is gone. EVERY unlocked daily
// case (requiredLevel <= the player's level) opens FREE once per 24h, so each
// case carries its OWN cooldown stamp — guests in the local store map,
// signed-in players in the DATABASE (Player.dailyOpens JSON).

/** Parse the per-case daily-open map (Player.dailyOpens JSON / store map). */
export function dailyOpensOf(json: string | null | undefined): Record<string, number> {
  if (!json) return {};
  try {
    const parsed = JSON.parse(json) as unknown;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const out: Record<string, number> = {};
    for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
      if (typeof v === "number" && Number.isFinite(v) && v > 0) out[k] = v;
    }
    return out;
  } catch {
    return {};
  }
}

/** ms left until THIS case's next free daily open (0 = ready now). */
export function caseDailyNextIn(opens: Record<string, number>, caseId: string): number {
  return msLeftFrom(opens[caseId] ?? 0);
}

/** "7h 12m" style countdown for UI. */
export function formatCountdown(ms: number): string {
  if (ms <= 0) return "ready";
  const totalMin = Math.ceil(ms / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h > 0) return `${h}h ${m.toString().padStart(2, "0")}m`;
  return `${m}m`;
}

// ===== USER SPEC: the avatar ring changes color with the player's LEVEL =====
// 1-10 green, 11-19 turquoise, 20-29 blue, 30-39 purple, 40-49 pink,
// 50-59 red, 60-69 orange, 70-79 yellow, 80+ gold. Pure data (hex strings +
// rgba glows) so components can paint it with inline styles — no dynamic
// Tailwind class names the JIT compiler could never see.

export interface LevelTier {
  name: string; // English tier label (tooltips / aria)
  hex: string; // main ring color
  hex2: string; // lighter gradient partner
  glow: string; // rgba glow for the boxShadow
}

const LEVEL_TIERS: LevelTier[] = [
  { name: "Gold", hex: "#fbbf24", hex2: "#fde68a", glow: "rgba(251,191,36,0.55)" },
  { name: "Yellow", hex: "#eab308", hex2: "#fde047", glow: "rgba(234,179,8,0.5)" },
  { name: "Orange", hex: "#f97316", hex2: "#fdba74", glow: "rgba(249,115,22,0.5)" },
  { name: "Red", hex: "#ef4444", hex2: "#fca5a5", glow: "rgba(239,68,68,0.5)" },
  { name: "Pink", hex: "#ec4899", hex2: "#f9a8d4", glow: "rgba(236,72,153,0.5)" },
  { name: "Purple", hex: "#a855f7", hex2: "#d8b4fe", glow: "rgba(168,85,247,0.5)" },
  { name: "Blue", hex: "#3b82f6", hex2: "#93c5fd", glow: "rgba(59,130,246,0.5)" },
  { name: "Turquoise", hex: "#2dd4bf", hex2: "#5eead4", glow: "rgba(45,212,191,0.5)" },
  { name: "Green", hex: "#22c55e", hex2: "#86efac", glow: "rgba(34,197,94,0.5)" },
];

/** The ring tier for a level — bands are [80+ gold, 70-79 yellow, ... 1-10 green]. */
export function levelTier(level: number): LevelTier {
  const caps = [80, 70, 60, 50, 40, 30, 20, 11, 0];
  const i = caps.findIndex((cap) => level >= cap);
  return LEVEL_TIERS[Math.max(0, i)];
}
