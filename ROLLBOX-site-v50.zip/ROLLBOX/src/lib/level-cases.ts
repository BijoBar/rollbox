// ============ LEVEL CASES — the free DAILY cases (USER SPEC) ============
// The old daily bonus (coins on login) is GONE. Instead there are 10 free
// vaults — LEVEL 3, 10, 20, ... 90 — named after the level that unlocks them.
// USER SPEC (Task 104): a player opens EVERY daily case up to their level,
// each ONE free open per 24h (a Level 40 player opens 3+10+20+30+40 daily;
// a Level 90+ player opens all ten). Below Level 3 nothing unlocks yet.
// USER SPEC (Task 33): the whole ladder dropped — the first vault unlocks at
// Level 3 and every next one 10 levels earlier than before (unlockLevelOf).
// The reward is a real CASE OPENING (the full reel experience) — not a
// passive credit.

import type { CaseDef } from "./cases";
import { caseDailyNextIn } from "./progress";

interface LevelCaseSpec {
  tier: number; // the level that unlocks the case (also its name)
  subtitle: string;
  color: string;
  color2: string;
  /** [skinId, rawWeight] — weights are normalized so the case totals 100. */
  items: [string, number][];
}

// Tier palette mirrors the avatar level-ring bands (progress.ts): the vault
// color "grows up" with the player — green (the LEVEL 3 vault) up to
// site-gold (the LEVEL 90 vault).
const SPECS: LevelCaseSpec[] = [
  {
    tier: 10,
    subtitle: "Your first daily vault — unlocked at Level 3. Refills free every 24 hours.",
    color: "#22c55e",
    color2: "#bbf7d0",
    items: [
      ["ak-47-olive-polycam", 30],
      ["awp-safari-mesh", 20],
      ["usp-s-27", 15],
      ["glock-18-oxide-blaze", 12],
      ["sawed-off-amber-fade", 9],
      ["ump-45-arctic-wolf", 6],
      ["nova-rising-sun", 5],
      ["ssg-08-acid-fade", 2.2],
      ["awp-pit-viper", 0.5],
      ["galil-ar-chromatic-aberration", 0.3],
    ],
  },
  {
    tier: 20,
    subtitle: "Level 10 daily vault — a richer free case, every 24 hours.",
    color: "#2dd4bf",
    color2: "#99f6e4",
    items: [
      ["m4a1-s-varicamo", 26],
      ["desert-eagle-calligraffiti", 18],
      ["mp7-urban-hazard", 14],
      ["ak-47-wintergreen", 11],
      ["p2000-amber-fade", 8],
      ["galil-ar-galigator", 7],
      ["usp-s-check-engine", 6],
      ["awp-arsenic-spill", 5],
      ["glock-18-moonrise", 2],
      ["ak-47-rat-rod", 2],
      ["awp-elite-build", 0.7],
      ["ak-47-point-disarray", 0.3],
    ],
  },
  {
    tier: 30,
    subtitle: "Level 20 daily vault — blue-tier drops with a neon ceiling.",
    color: "#3b82f6",
    color2: "#93c5fd",
    items: [
      ["m4a4-magnesium", 22],
      ["mac-10-carnivore", 16],
      ["mp9-broken-record", 12],
      ["cz75-auto-crimson-web", 10],
      ["mp5-sd-phosphor", 9],
      ["awp-green-energy", 8],
      ["awp-ice-coaled", 7],
      ["ak-47-nouveau-rouge", 6],
      ["sawed-off-devourer", 4],
      ["ak-47-phantom-disruptor", 3],
      ["usp-s-printstream", 1.5],
      ["ak-47-black-laminate", 1],
      ["ak-47-neon-rider", 0.5],
    ],
  },
  {
    tier: 40,
    subtitle: "Level 30 daily vault — purple loot with an Asiimov at the top.",
    color: "#a855f7",
    color2: "#d8b4fe",
    items: [
      ["galil-ar-urban-rubble", 22],
      ["galil-ar-amber-fade", 16],
      ["scar-20-palm", 12],
      ["p250-cartel", 10],
      ["xm1014-tranquility", 9],
      ["five-seven-case-hardened", 8],
      ["m4a4-hellish", 6],
      ["nova-hyper-beast", 5],
      ["p2000-imperial-dragon", 3],
      ["awp-fever-dream", 2],
      ["awp-redline", 0.5],
      ["ak-47-asiimov", 0.3],
    ],
  },
  {
    tier: 50,
    subtitle: "Level 40 daily vault — pink-tier loot, Golden Koi on top.",
    color: "#ec4899",
    color2: "#f9a8d4",
    items: [
      ["m4a4-faded-zebra", 16],
      ["m4a4-jungle-tiger", 14],
      ["zeus-x27-dragon-snore", 14],
      ["ak-47-crane-flight", 11],
      ["mp7-fade", 10],
      ["awp-the-end", 8],
      ["mac-10-amber-fade", 4],
      ["p90-tiger-pit", 3],
      ["ak-47-neon-revolution", 0.8],
      ["ak-47-bloodsport", 0.6],
      ["m4a1-s-hyper-beast", 0.5],
      ["gut-knife-doppler-7", 0.4],
      ["m4a1-s-cyrex", 0.2],
      ["desert-eagle-golden-koi", 0.1],
    ],
  },
  {
    tier: 60,
    subtitle: "Level 50 daily vault — red-tier loot and your first knife ladder.",
    color: "#ef4444",
    color2: "#fca5a5",
    items: [
      ["awp-pink-ddpat", 16],
      ["mac-10-case-hardened", 13],
      ["m4a4-full-throttle", 12],
      ["awp-chromatic-aberration", 9],
      ["ak-47-the-oligarch", 9],
      ["usp-s-the-traitor", 8],
      ["awp-hyper-beast", 7],
      ["desert-eagle-printstream", 5],
      ["awp-longdog", 3],
      ["awp-neo-noir", 1.5],
      ["m4a1-s-fade", 0.4],
      ["nomad-knife-tiger-tooth", 0.3],
      ["bowie-knife-marble-fade", 0.3],
      ["flip-knife-autotronic", 0.2],
      ["falchion-knife-gamma-doppler-4", 0.15],
    ],
  },
  {
    tier: 70,
    subtitle: "Level 60 daily vault — orange-tier loot, Fire Serpent country.",
    color: "#f97316",
    color2: "#fdba74",
    items: [
      ["awp-asiimov", 18],
      ["m4a4-bullet-rain", 14],
      ["p2000-fire-elemental", 12],
      ["m4a4-asiimov", 9],
      ["ak-47-autoexec", 9],
      ["gut-knife-slaughter", 5.5],
      ["ak-47-vulcan", 4.5],
      ["p90-emerald-dragon", 4],
      ["sport-gloves-red-racer", 2],
      ["m4a4-eye-of-horus", 1.2],
      ["huntsman-knife-gamma-doppler", 0.4],
      ["flip-knife-gamma-doppler", 0.25],
      ["ak-47-fire-serpent", 0.15],
      ["butterfly-knife-crimson-web", 0.1],
      ["karambit-tiger-tooth", 0.05],
    ],
  },
  {
    tier: 80,
    subtitle: "Level 70 daily vault — yellow-tier loot with a Medusa ceiling.",
    color: "#eab308",
    color2: "#fde047",
    items: [
      ["m4a4-x-ray", 14],
      ["awp-cmyk", 12],
      ["shadow-daggers-marble-fade", 10],
      ["gut-knife-case-hardened", 9],
      ["specialist-gloves-crimson-web", 8],
      ["moto-gloves-smoke-out", 6],
      ["glock-18-gamma-doppler", 2],
      ["desert-eagle-hypnotic", 0.5],
      ["stiletto-knife-doppler-7", 0.2],
      ["m4a1-s-icarus-fell", 0.15],
      ["karambit-crimson-web", 0.12],
      ["desert-eagle-blaze", 0.1],
      ["awp-fade", 0.08],
      ["ak-47-hydroponic", 0.06],
      ["awp-desert-hydra", 0.05],
      ["butterfly-knife-tiger-tooth", 0.04],
      ["m4a4-poseidon", 0.03],
      ["m4a1-s-hot-rod", 0.02],
      ["awp-medusa", 0.01],
    ],
  },
  {
    tier: 90,
    subtitle: "Level 80 daily vault — near-gold loot, Doppler and Fade knives.",
    color: "#f59e0b",
    color2: "#fcd34d",
    items: [
      ["m4a4-x-ray", 14],
      ["awp-cmyk", 12],
      ["shadow-daggers-marble-fade", 10],
      ["specialist-gloves-crimson-web", 8],
      ["moto-gloves-smoke-out", 6],
      ["glock-18-gamma-doppler", 2],
      ["desert-eagle-hypnotic", 0.5],
      ["awp-fade", 0.15],
      ["ak-47-hydroponic", 0.1],
      ["awp-desert-hydra", 0.08],
      ["butterfly-knife-tiger-tooth", 0.06],
      ["ak-47-gold-arabesque", 0.05],
      ["m4a4-poseidon", 0.04],
      ["m4a1-s-hot-rod", 0.03],
      ["awp-medusa", 0.02],
      ["awp-the-prince", 0.06],
      ["karambit-fade", 0.05],
      ["butterfly-knife-doppler-2", 0.045],
      ["sport-gloves-pandora-s-box", 0.04],
      ["butterfly-knife-fade", 0.035],
      ["sport-gloves-hedge-maze", 0.03],
      ["m4a1-s-knight", 0.02],
    ],
  },
  {
    tier: 100,
    subtitle: "The summit vault — Dragon Lore, Gungnir and the s1mple gold sticker.",
    color: "#f0b90b",
    color2: "#fff3c4",
    items: [
      ["m4a4-x-ray", 14],
      ["awp-cmyk", 12],
      ["shadow-daggers-marble-fade", 10],
      ["specialist-gloves-crimson-web", 8],
      ["moto-gloves-smoke-out", 6],
      ["glock-18-gamma-doppler", 2],
      ["desert-eagle-hypnotic", 0.5],
      ["awp-fade", 0.2],
      ["ak-47-hydroponic", 0.12],
      ["awp-desert-hydra", 0.1],
      ["butterfly-knife-tiger-tooth", 0.08],
      ["ak-47-gold-arabesque", 0.06],
      ["m4a4-poseidon", 0.05],
      ["m4a1-s-hot-rod", 0.04],
      ["awp-medusa", 0.025],
      ["m4a1-s-knight", 0.02],
      ["m4a4-howl", 0.05],
      ["ak-47-wild-lotus", 0.06],
      ["awp-dragon-lore", 0.04],
      ["awp-gungnir", 0.03],
      ["sticker-910-gold-budapest-2025", 0.02],
      ["sticker-s1mple-gold-krakow-2017", 0.02],
    ],
  },
];

/**
 * USER SPEC (Task 33): the vault UNLOCK level — the whole ladder moved DOWN:
 * the old Level-10 vault now opens at Level 3, and every other vault opens
 * 10 levels earlier (20→10, 30→20 … 100→90). `tier` stays the case's
 * internal identity (id `level-*` keeps the daily timers intact) while the
 * name / code / unlock all follow the NEW level.
 */
function unlockLevelOf(tier: number): number {
  return tier === 10 ? 3 : tier - 10;
}

function buildLevelCase(spec: LevelCaseSpec): CaseDef {
  const total = spec.items.reduce((s, [, w]) => s + w, 0);
  const items = spec.items.map(([skinId, weight]) => ({
    skinId,
    weight: Math.round((weight / total) * 10000) / 100, // normalize to a 100 total
  }));
  // push the rounding residual onto the heaviest item so the editor's
  // "must sum to 100" check passes to the last decimal
  const drift = Math.round((100 - items.reduce((s, i) => s + i.weight, 0)) * 100) / 100;
  if (items.length && drift !== 0) {
    const big = items.reduce((a, b) => (b.weight > a.weight ? b : a));
    big.weight = Math.round((big.weight + drift) * 100) / 100;
  }
  const unlock = unlockLevelOf(spec.tier);
  return {
    id: `level-${spec.tier}`,
    code: `LVL-${unlock}`,
    name: `LEVEL ${unlock}`,
    subtitle: spec.subtitle,
    kind: "level",
    tierLabel: "FREE",
    price: 0,
    tierColor: spec.color,
    tierColor2: spec.color2,
    requiredLevel: unlock,
    items,
  };
}

/** The 10 daily cases, lowest tier first. */
export const LEVEL_CASES: CaseDef[] = SPECS.map(buildLevelCase).sort((a, b) => a.requiredLevel! - b.requiredLevel!);

/** The player's daily-case tier (internal tier of the highest unlocked
 *  vault): null below Level 3, the first vault's tier (10) through Level 9,
 *  then the tier whose unlock equals floor(level/10)*10+10 — capped at the
 *  top vault (internal tier 100, unlocks at Level 90). */
export function dailyCaseTierOf(level: number): number | null {
  if (level < 3) return null;
  if (level < 10) return 10; // the first vault (named LEVEL 3)
  return Math.min(100, (Math.floor(level / 10) + 1) * 10);
}

// ===== USER SPEC (Task 104): the MULTI-VAULT daily system =====

/** Every daily case the level has unlocked (LEVEL 3 .. the level's own
 *  tier) — each one opens FREE once per 24h. Level 40 → 3/10/20/30/40. */
export function unlockedDailyCases(level: number): CaseDef[] {
  return LEVEL_CASES.filter((c) => (c.requiredLevel ?? 0) <= level);
}

/** How many of the player's unlocked daily cases are ready right now. */
export function readyDailyCount(opens: Record<string, number>, level: number): number {
  return unlockedDailyCases(level).filter((c) => caseDailyNextIn(opens, c.id) === 0).length;
}

/** ms until the NEXT unlocked daily case refills (0 when at least one is ready). */
export function nextDailyReadyIn(opens: Record<string, number>, level: number): number {
  const vals = unlockedDailyCases(level).map((c) => caseDailyNextIn(opens, c.id));
  return vals.length ? Math.min(...vals) : 0;
}
