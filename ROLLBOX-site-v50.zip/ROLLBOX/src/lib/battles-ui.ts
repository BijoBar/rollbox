"use client";

import { useEffect } from "react";
import { useCaseStore } from "@/lib/store";

/**
 * Simulated lobby traffic — a shared heartbeat for the battles pages:
 * - seeds a few NPC battles so the lobby is never dead
 * - NPC players drift into open battles (your battles too)
 * - full NPC-only battles resolve headlessly and drop into history
 * Runs while any battle page is mounted; the store is idempotent per tick.
 */
export function useBattleTraffic(enabled = true) {
  const npcTrafficTick = useCaseStore((s) => s.npcTrafficTick);

  useEffect(() => {
    if (!enabled) return;
    // seed immediately so the first paint of the lobby has life in it
    npcTrafficTick();
    const t = window.setInterval(npcTrafficTick, 4000);
    return () => window.clearInterval(t);
  }, [npcTrafficTick, enabled]);
}

/**
 * Simulated LIVE VIEWER COUNT for a battle — USER SPEC: real players only,
 * never bots. The count is derived from the battle id + a time bucket, so it
 * drifts every few seconds ("at any given moment") yet stays stable within a
 * bucket and is consistent across every component that reads it.
 */
export function viewersFor(battleId: string, bucketMs = 8000): number {
  const bucket = Math.floor(Date.now() / bucketMs);
  const key = `${battleId}:${bucket}`;
  let h = 2166136261;
  for (let i = 0; i < key.length; i++) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const r = (h >>> 0) / 4294967295;
  return 1 + Math.floor(r * r * 90); // 1..90 — skewed toward smaller crowds
}
