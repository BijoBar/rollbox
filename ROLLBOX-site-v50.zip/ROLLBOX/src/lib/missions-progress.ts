// ============ MISSIONS progress math (Task 32 — USER SPEC) ============
// The owner: "אני רוצה שאת כל הPROGRESS של המשימות תכניס לDB לעמודה של כל
// שחקן וההתקדמות שלו במשימות" — every player's mission progress lives in the
// DB (Player.missions) and the board renders it live.
//
// HOW IT WORKS: gameplay events bump lifetime COUNTERS stored on the player's
// row (src/lib/server/missions.ts tracks them from the battles / cases /
// upgrader / terminal / sell / topup / referral code paths). This module is
// the PURE, shared mapping counter → per-step progress — imported by the
// server (authoritative state) AND the board UI (rendering), so both sides
// always agree on what "done" means.

/** Lifetime mission counters — the keys of Player.missions.c */
export type MissionCounters = Record<string, number>;

export interface StepProgress {
  cur: number;
  goal: number;
  done: boolean;
}

/** a counter that may be missing / null / garbage → clean number ≥ 0 */
const num = (c: MissionCounters, k: string): number => {
  const v = c?.[k];
  return Number.isFinite(v) && v > 0 ? v : 0;
};

/** progress toward a "reach N" goal */
const toward = (cur: number, goal: number): StepProgress => {
  const c = Math.min(Math.max(0, cur), goal);
  return { cur: c, goal, done: c >= goal };
};

/** progress toward a "deposit at least $X (lifetime total)" goal */
const deposit = (c: MissionCounters, goal: number): StepProgress => toward(num(c, "depTotal"), goal);

/**
 * The LIVE step's progress for a player's counters. Returns null for steps
 * gated behind the upcoming systems (email / Discord-link / newsletter —
 * `live: false` in the catalog) and for unknown ids: those never render bars.
 */
export function stepProgress(stepId: string, c: MissionCounters): StepProgress | null {
  switch (stepId) {
    // ---- M2 Battle Rookie ----
    case "m2s1": return toward(num(c, "battles3"), 3); // play 3 battles of $3+
    case "m2s2": return toward(num(c, "battlesWon"), 1); // win 1 battle
    case "m2s3": return toward(num(c, "battlesBots"), 1); // play a battle with bots
    // ---- M3 To The Moon! ----
    case "m3s1": return toward(num(c, "up2"), 1); // upgrade at 2x or higher
    case "m3s2": return toward(num(c, "up10"), 1); // upgrade a $10+ skin
    case "m3s3": return toward(num(c, "upWin3"), 1); // win an upgrade at 3x
    // ---- M4 Verified Player ----
    case "m4s1": return deposit(c, 50); // deposit $50+
    case "m4s2": return toward(num(c, "cases5"), 5); // open 5 cases of $5+
    // ---- M5 Battle Pro ----
    case "m5s1": return toward(num(c, "battles4"), 3); // 3 battles of 4+ players
    case "m5s2": return toward(num(c, "battles10"), 3); // 3 battles of $10+
    case "m5s3": return toward(num(c, "botsWon"), 5); // win 5 battles vs bots
    // ---- M6 Daydreamer ----
    case "m6s1": return toward(num(c, "casesDaily"), 5); // open 5 daily cases
    case "m6s2": return deposit(c, 65); // deposit $65+
    case "m6s3": return toward(num(c, "upWin5"), 1); // win an upgrade at 5x
    // ---- M7 Highroller ----
    case "m7s1": return deposit(c, 200); // deposit $200+
    case "m7s2": return toward(num(c, "battlesWon"), 20); // win 20 battles
    case "m7s3": return toward(num(c, "upWin10"), 1); // win an upgrade at 10x
    // ---- M8 Farmer ----
    case "m8s1": return toward(num(c, "casesFarm"), 20); // open 20 FARM cases
    case "m8s2": return toward(num(c, "upStreak105"), 5); // 5 x 1.05 wins in a row
    case "m8s3": return toward(num(c, "battlesShared"), 5); // 5 SHARED battles
    // ---- M9 Contractor ----
    case "m9s1": return toward(num(c, "term5"), 3); // 3 terminal deals of $5+
    case "m9s2": return toward(num(c, "termBoss"), 1); // play THE BOSS
    case "m9s3": return toward(num(c, "sold"), 5); // sell 5 skins
    // ---- M10 Loyal Follower ----
    case "m10s3": return toward(num(c, "refInvites"), 3); // invite 3 friends
    default:
      return null; // m1s1 / m4s3 / m10s1 / m10s2 — SOON steps, no counters yet
  }
}

/** How many of a mission's LIVE steps are done (header badge, progress %). */
export function missionDoneCount(steps: { id: string; live: boolean }[], c: MissionCounters): number {
  return steps.reduce((n, s) => (s.live && stepProgress(s.id, c)?.done ? n + 1 : n), 0);
}
