// ============ ROLLBOX Case Battles data layer ============
// Types + pure helpers for the battles lobby system:
// players create battles (pick cases + battle type + mode), the battle waits
// in the lobby until every seat is full (site [RBbot] bots can be called in
// with everyone's consent), then rounds play out — STANDARD: highest total
// wins, CRAZY: lowest total wins. Ties go to a decider battle.
// PAYOUT RULE (user spec): the winner takes the total value of every skin that
// actually dropped in the battle's cases — NEVER the entries/prize pool.
// POT RULES (user spec Task 42): "winner" = classic take-all, "jackpot" = the
// winner is DRAWN with odds ∝ each player's unboxed value (CRAZY mode inverts:
// lowest haul gets the best odds) and lands via a dedicated jackpot reel,
// "shared" = every player walks away with an equal cut of the total drops
// (never playable 2v2).

import { CASES, rollCaseItem, type CaseDef, type WearId } from "./cases";
import { rareCaseOf, rolldropChanceOf } from "./rolldrop";

export type BattleType = "1v1" | "1v1v1" | "1v1v1v1" | "2v2";

export const BATTLE_TYPES: Record<
  BattleType,
  { label: string; short: string; players: number; teamMode: boolean }
> = {
  "1v1": { label: "2 Players (1v1)", short: "1v1", players: 2, teamMode: false },
  "1v1v1": { label: "3 Players (1v1v1)", short: "1v1v1", players: 3, teamMode: false },
  "1v1v1v1": { label: "4 Players (1v1v1v1)", short: "1v1v1v1", players: 4, teamMode: false },
  "2v2": { label: "2 Vs 2", short: "2v2", players: 4, teamMode: true },
};

export const BATTLE_TYPE_ORDER: BattleType[] = ["1v1", "1v1v1", "1v1v1v1", "2v2"];

export type BattleMode = "standard" | "crazy";

/** USER SPEC (Task 42): how the battle's pot is decided at the end. */
export type BattlePotRule = "winner" | "jackpot" | "shared";

export const BATTLE_MODES: Record<
  BattleMode,
  { label: string; hint: string }
> = {
  standard: { label: "Standard", hint: "Highest total value wins the drops" },
  crazy: { label: "CRAZY", hint: "CRAZY — LOWEST total value wins the drops" },
};

export const POT_RULES: Record<
  BattlePotRule,
  { label: string; hint: string }
> = {
  winner: { label: "Standard", hint: "Highest total value wins the drops" },
  jackpot: {
    label: "JACKPOT",
    hint: "JACKPOT — the pot is drawn by weight: the more value you unbox, the bigger your win odds (CRAZY flips it: lowest haul gets the best odds)",
  },
  shared: {
    label: "SHARED",
    hint: "SHARED — at the end the whole pot is split equally between every player (never playable 2v2)",
  },
};

/** Lobby/room badge info for a battle's mode+pot rule combo. */
export function potRuleOf(b: Pick<Battle, "potRule">): BattlePotRule {
  return b.potRule ?? "winner";
}

/** Hard cap — up to 50 rounds per battle (user spec). */
export const MAX_BATTLE_ROUNDS = 50;

/** Every participant gets one of these colors, at random, per battle. */
export const PLAYER_COLORS = [
  { key: "blue", hex: "#38bdf8" }, // כחול
  { key: "yellow", hex: "#facc15" }, // צהוב
  { key: "green", hex: "#4ade80" }, // ירוק
  { key: "purple", hex: "#c084fc" }, // סגול
] as const;

export const playerColor = (p: { color?: number } | undefined) =>
  PLAYER_COLORS[((p?.color ?? 0) % PLAYER_COLORS.length + PLAYER_COLORS.length) % PLAYER_COLORS.length].hex;

/** Shuffled color order for a new battle — seat i takes colorOrder[i]. */
export function shuffledColorOrder(): number[] {
  const c = [0, 1, 2, 3];
  for (let i = c.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [c[i], c[j]] = [c[j], c[i]];
  }
  return c;
}

/** The 2v2 squads are named after the CS2 sides. */
export const TEAM_META: Record<
  0 | 1,
  { name: "CT" | "T"; img: string; color: string }
> = {
  0: { name: "CT", img: "/teams/ct.webp", color: "#4da3ff" },
  1: { name: "T", img: "/teams/t.webp", color: "#e8b64c" },
};

export interface BattlePlayer {
  id: string;
  name: string;
  /** Real profile picture (Steam) — flows from the server seats; local/legacy players leave it unset (initials fallback). */
  avatar?: string;
  isYou: boolean;
  isBot: boolean;
  team: 0 | 1;
  /** USER SPEC (2v2): the seat INSIDE the team the player picked — 0 = left, 1 = right. Solo battles leave it unset. */
  side?: 0 | 1;
  joinedAt: number;
  /** index into PLAYER_COLORS (0-3) — assigned randomly per battle */
  color: number;
  /** USER SPEC (Task 66): this human pressed CALL BOTS — "PLAY WITH BOTS".
   *  Bots fill the room only when EVERY seated human has voted (server truth). */
  botsVote?: boolean;
}

/** One round pull by one player (value cached from SKINS for cheap totals). */
export interface BattlePull {
  round: number;
  skinId: string;
  /** Task 72: the exterior this pull came in (when the case item pins one). */
  wear?: WearId;
  value: number;
  /** USER SPEC: this pull IS the ROLLDROP — it replaced the round's normal
   *  skin (the reel stops on the raredrop art, then the rare round opens). */
  rd?: boolean;
}

export interface BattleResult {
  playerId: string;
  total: number;
  pulls: BattlePull[];
}

export type BattleStatus = "waiting" | "playing" | "finished";

/** One round's window on the server shared clock (multiplayer rooms only). */
export interface RoundSlot {
  startMs: number; // when the round's pulls unlock for every viewer
  mainMs: number; // the main reel spin length on the shared clock
  endMs: number; // when the round is fully over (raredrop chain included)
}

export interface Battle {
  id: string;
  type: BattleType;
  mode: BattleMode;
  /** USER SPEC (Task 42): how the pot is decided — winner (default) / jackpot draw / shared split */
  potRule?: BattlePotRule;
  /** USER SPEC (Task 67): PRIVATE — hidden from the lobby, joinable by code only */
  isPrivate?: boolean;
  /** USER SPEC (Task 67): the RB-XXXX room code (server battles) — the private invite */
  code?: string;
  maxPlayers: number;
  teamMode: boolean;
  rounds: string[]; // caseIds, one per round, in play order
  status: BattleStatus;
  createdAt: number;
  players: BattlePlayer[];
  /** shuffled PLAYER_COLORS indexes — seat i sits on colorOrder[i] */
  colorOrder: number[];
  /** which human players asked to start with bots (playerId -> true) */
  botCalls: Record<string, boolean>;
  /** timestamp when the last empty seat got filled (headless NPC resolve timer) */
  fullSince: number | null;
  results?: BattleResult[];
  winnerIds?: string[];
  potTotal?: number;
  /** true when this battle was seeded by the simulated lobby traffic */
  npcSeed?: boolean;
  /**
   * MULTIPLAYER: true when this battle LIVES on the server — the client only
   * mirrors it (players/pulls arrive from /api/gbattles/[id]). Local economy
   * (credits, bots, seat edits) is disabled for these; the server is truth.
   */
  global?: boolean;
  /** server shared-clock schedule (global battles only) */
  schedule?: RoundSlot[] | null;
  /** server-side start timestamp (global battles only) */
  startedAtMs?: number | null;
  /** local clock minus server clock in ms — corrects schedule math */
  clockOffset?: number;
  /** per-player payout published by the server (global battles, finished) */
  take?: Record<string, number> | null;
  /** the tied player ids the server had to decide between (global battles) */
  tieIds?: string[] | null;
}

/** Entry per player = sum of the round cases. */
export function battleEntry(battle: Pick<Battle, "rounds">): number {
  return battle.rounds.reduce((s, id) => s + (CASES.find((c) => c.id === id)?.price ?? 0), 0);
}

/** Sum of all seats' entries — informational only; the PAYOUT is dropTotal(). */
export function battlePot(battle: Pick<Battle, "rounds" | "maxPlayers">): number {
  return battleEntry(battle) * battle.maxPlayers;
}

/**
 * The winner's payout: the total value of every skin that actually dropped in
 * the battle (all players, all rounds) — NOT the entries/prize pool.
 * Example: a 1000-coin battle whose cases dropped 154 worth of skins pays 154.
 */
export function dropTotal(results: Pick<BattleResult, "total">[]): number {
  return results.reduce((s, r) => s + r.total, 0);
}

export function battleCases(battle: Pick<Battle, "rounds">, extra?: CaseDef[]): CaseDef[] {
  // USER SPEC (battles × COMMUNITY/EVENT): rounds can reference player-built
  // cc_* cases (or any id outside the static catalog) — the caller passes the
  // extra defs it resolved (room wire / /api/cases/resolve) and they merge in.
  return battle.rounds
    .map((id) => CASES.find((c) => c.id === id) ?? extra?.find((c) => c.id === id))
    .filter((c): c is CaseDef => Boolean(c));
}

export const emptySeats = (b: Battle) => b.maxPlayers - b.players.length;

export const seatOfYou = (b: Battle) => b.players.find((p) => p.isYou);

/** "4m ago" style label for lobby cards. */
export function timeAgo(ts: number): string {
  const s = Math.max(1, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
}

// ---- the 8 site bots — every computer player MUST wear the [RBbot] tag ----

export const RBBOT_NAMES = [
  "[RBbot] Gabey",
  "[RBbot] Alfichs",
  "[RBbot] DogSury",
  "[RBbot] EzDinner",
  "[RBbot] NULLdoll",
  "[RBbot] Agent67",
  "[RBbot] HowToBake",
  "[RBbot] I hate Agent67",
];

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

let seatSeq = 0;
export function makePlayer(opts: Partial<BattlePlayer> = {}): BattlePlayer {
  seatSeq += 1;
  return {
    id: `p${Date.now().toString(36)}${seatSeq.toString(36)}`,
    name: "Player",
    isYou: false,
    isBot: false,
    team: 0,
    joinedAt: Date.now(),
    color: 0,
    ...opts,
  };
}

/** A site bot with an unused [RBbot] name. */
export function makeBot(taken: string[] = [], team: 0 | 1 = 0, color = 0, side?: 0 | 1): BattlePlayer {
  const free = RBBOT_NAMES.filter((n) => !taken.includes(n));
  return makePlayer({ name: pick(free.length ? free : RBBOT_NAMES), isBot: true, team, side, color });
}

const BATTLE_ID_ALPHA = "abcdefghijklmnopqrstuvwxyz0123456789";
export function newBattleId(): string {
  let s = "";
  for (let i = 0; i < 10; i++) s += BATTLE_ID_ALPHA[Math.floor(Math.random() * BATTLE_ID_ALPHA.length)];
  return `b${Date.now().toString(36)}${s}`;
}

/** Team assignment for a seat index given the battle type (0 = CT, 1 = T). */
export function teamForSeat(type: BattleType, seat: number): 0 | 1 {
  if (type === "2v2") return seat < 2 ? 0 : 1;
  return 0;
}

/**
 * USER SPEC (2v2): every player picks the team AND the seat inside it — each
 * team has a LEFT and a RIGHT seat. New joiners (and bots) land on the first
 * free seat in [CT-left, CT-right, T-left, T-right] order, which keeps the
 * old balancing (thinner team first, ties → CT) — and every player can still
 * switch to any open seat in the waiting room.
 */
export function openSeat(players: BattlePlayer[]): { team: 0 | 1; side: 0 | 1 } {
  for (const team of [0, 1] as const) {
    for (const side of [0, 1] as const) {
      if (!players.some((p) => p.team === team && p.side === side)) return { team, side };
    }
  }
  // legacy players without a side: fall back to pure team counting
  const c0 = players.filter((p) => p.team === 0).length;
  const c1 = players.filter((p) => p.team === 1).length;
  return { team: c0 <= c1 ? 0 : 1, side: 0 };
}

/** The seat a legacy player occupies — explicit side, else their slot within the team (array order). */
export const sideOf = (p: BattlePlayer, idxInTeam: number): 0 | 1 => p.side ?? (idxInTeam === 0 ? 0 : 1);

/**
 * USER SPEC: battle tiles drop the "Category | " prefix from skin names —
 * long names ("Sticker | Polar Bears (Foil)") were getting swallowed inside
 * the player's row. The full name stays everywhere else (tooltips, case
 * contents, inventory).
 */
export function shortSkinName(name: string): string {
  const i = name.indexOf(" | ");
  return i >= 0 ? name.slice(i + 3) : name;
}

/**
 * Build a random bot battle for lobby seeding.
 * USER SPEC: a bot only opens battles of up to 4 players — NEVER 2v2 — and
 * at most 3 bots may wait inside. The last seat is always left open: the
 * battle cannot start (bot vs bot is forbidden) until a real player joins
 * and starts it.
 */
export function makeBotBattle(): Battle {
  const type = pick(BATTLE_TYPE_ORDER.filter((t) => t !== "2v2"));
  const spec = BATTLE_TYPES[type];
  const mode: BattleMode = Math.random() < 0.3 ? "crazy" : "standard";
  // seeded rooms also showcase the new pot rules (never 2v2 here, so SHARED is legal)
  const potRule: BattlePotRule = pick<BattlePotRule>([
    "winner",
    "winner",
    "winner",
    "jackpot",
    "shared",
  ]);
  const roundCount = 1 + Math.floor(Math.random() * 5);
  const pool = CASES.filter((c) => c.price <= 25); // lobby-friendly price range
  const rounds = Array.from({ length: roundCount }, () => pick(pool).id);
  const colorOrder = shuffledColorOrder();
  const maxBots = Math.min(3, spec.players - 1); // always leave a seat for a real player
  const botCount = 1 + Math.floor(Math.random() * maxBots);
  const players: BattlePlayer[] = [];
  for (let i = 0; i < botCount; i++) {
    players.push(makeBot(players.map((p) => p.name), teamForSeat(type, i), colorOrder[i]));
  }
  return {
    id: newBattleId(),
    type,
    mode,
    potRule,
    maxPlayers: spec.players,
    teamMode: spec.teamMode,
    rounds,
    status: "waiting",
    createdAt: Date.now() - Math.floor(Math.random() * 90_000),
    players,
    colorOrder,
    botCalls: {},
    fullSince: null,
    npcSeed: true,
  };
}

// ---- outcome math (shared by the live room and the headless resolver) ----

export interface BattleOutcome {
  winnerIds: string[];
  /** tied participant ids — player ids, or "t0"/"t1" for team battles */
  tieIds: string[] | null;
}

/**
 * JACKPOT win weight per player (USER SPEC Task 42): the share of the pot you
 * draw is proportional to the value you unboxed this battle. CRAZY mode flips
 * the scale — the LOWEST haul gets the biggest weight. Returns a weight per
 * player id (relative numbers; normalize for %).
 */
export function jackpotWeights(
  players: BattlePlayer[],
  settled: BattleResult[],
  crazy: boolean
): Record<string, number> {
  const totalOf = (id: string) => settled.find((d) => d.playerId === id)?.total ?? 0;
  const sums = settled.reduce((s, d) => s + d.total, 0);
  const weights: Record<string, number> = {};
  for (const p of players) {
    const t = totalOf(p.id);
    weights[p.id] = crazy ? Math.max(sums - t, 0) : Math.max(t, 0);
  }
  // all-zero fallback (e.g. one player unboxed everything in crazy mode) —
  // nobody's odds should flatline to zero, so everyone gets an equal slice
  const sum = Object.values(weights).reduce((s, w) => s + w, 0);
  if (sum <= 0) for (const p of players) weights[p.id] = 1;
  return weights;
}

/** Win odds (%) per player for the JACKPOT reel — normalized weights. */
export function jackpotPct(
  players: BattlePlayer[],
  settled: BattleResult[],
  crazy: boolean
): Record<string, number> {
  const w = jackpotWeights(players, settled, crazy);
  const sum = Object.values(w).reduce((s, x) => s + x, 0) || 1;
  return Object.fromEntries(Object.entries(w).map(([id, x]) => [id, (x / sum) * 100]));
}

/**
 * USER SPEC (Task 43): in 2v2 the JACKPOT wheel spins per TEAM, not per
 * player — the TEAM is the participant: its weight is its COMBINED spend
 * (CRAZY flips it at the team level — the squad with the LOWEST combined
 * haul draws with the best chance, exactly like solo players).
 */
export function jackpotTeamWeights(
  players: BattlePlayer[],
  settled: BattleResult[],
  crazy: boolean
): Record<"t0" | "t1", number> {
  const totals: Record<"t0" | "t1", number> = { t0: 0, t1: 0 };
  for (const d of settled) {
    const p = players.find((pl) => pl.id === d.playerId);
    if (p) totals[p.team === 0 ? "t0" : "t1"] += d.total;
  }
  const grand = totals.t0 + totals.t1;
  const w: Record<"t0" | "t1", number> = crazy
    ? { t0: Math.max(grand - totals.t0, 0), t1: Math.max(grand - totals.t1, 0) }
    : totals;
  // all-zero fallback — nobody's odds should flatline to zero
  const sum = w.t0 + w.t1;
  if (sum <= 0) return { t0: 1, t1: 1 };
  return w;
}

/** Team win odds (%) for the 2v2 JACKPOT reel — normalized team weights. */
export function jackpotTeamPct(
  players: BattlePlayer[],
  settled: BattleResult[],
  crazy: boolean
): { t0: number; t1: number } {
  const w = jackpotTeamWeights(players, settled, crazy);
  const sum = w.t0 + w.t1 || 1;
  return { t0: (w.t0 / sum) * 100, t1: (w.t1 / sum) * 100 };
}

/** Weighted draw — one player id by JACKPOT odds. */
export function drawJackpotWinner(weights: Record<string, number>): string {
  const entries = Object.entries(weights);
  const sum = entries.reduce((s, [, w]) => s + w, 0);
  let r = Math.random() * sum;
  for (const [id, w] of entries) {
    r -= w;
    if (r <= 0) return id;
  }
  return entries[entries.length - 1][0];
}

/**
 * SHARED split (USER SPEC Task 42): the whole pot is divided equally between
 * every player; the indivisible remainder goes one CENT at a time to the
 * earliest seats (Task 76: pots carry cent-precise values, so the split is
 * computed in integer cents and the pot always lands back exactly).
 */
export function sharedSplit(pot: number, players: BattlePlayer[]): Record<string, number> {
  const n = Math.max(1, players.length);
  const totalCents = Math.round(pot * 100);
  const base = Math.floor(totalCents / n);
  let rest = totalCents - base * n;
  const shares: Record<string, number> = {};
  for (const p of players) shares[p.id] = (base + (rest-- > 0 ? 1 : 0)) / 100;
  return shares;
}

/**
 * Decide the winners of a finished battle.
 * STANDARD: highest total wins. CRAZY: lowest total wins.
 * JACKPOT: one weighted draw — odds ∝ unboxed value (CRAZY inverts); in team
 * mode the drawn player carries his whole team across with him.
 * SHARED: there is no winner — every player is returned so the payout layer
 * can split the pot equally.
 * Ties at the winning edge (winner rule only) are returned as tieIds for the
 * decider battle.
 */
export function computeOutcome(
  players: BattlePlayer[],
  settled: BattleResult[],
  mode: BattleMode,
  teamMode: boolean,
  potRule: BattlePotRule = "winner"
): BattleOutcome {
  if (potRule === "shared") {
    return { winnerIds: players.map((p) => p.id), tieIds: null };
  }
  if (potRule === "jackpot") {
    const winnerId = drawJackpotWinner(jackpotWeights(players, settled, mode === "crazy"));
    if (teamMode) {
      const winTeam = players.find((p) => p.id === winnerId)?.team ?? 0;
      return { winnerIds: players.filter((p) => p.team === winTeam).map((p) => p.id), tieIds: null };
    }
    return { winnerIds: [winnerId], tieIds: null };
  }
  if (teamMode) {
    const teamTotal = [0, 0];
    for (const d of settled) {
      const p = players.find((pl) => pl.id === d.playerId);
      if (p) teamTotal[p.team] += d.total;
    }
    if (teamTotal[0] === teamTotal[1]) return { winnerIds: [], tieIds: ["t0", "t1"] };
    // standard: bigger team total wins — crazy: smaller team total wins
    const winTeam: 0 | 1 =
      mode === "crazy" ? (teamTotal[0] < teamTotal[1] ? 0 : 1) : teamTotal[0] > teamTotal[1] ? 0 : 1;
    return { winnerIds: players.filter((p) => p.team === winTeam).map((p) => p.id), tieIds: null };
  }
  const cmp = mode === "crazy" ? 1 : -1; // asc for crazy, desc for standard
  const sorted = [...settled].sort((a, b) => (a.total - b.total) * cmp);
  const edge = sorted[0]?.total ?? 0;
  const winners = settled.filter((d) => d.total === edge);
  if (winners.length > 1) return { winnerIds: [], tieIds: winners.map((d) => d.playerId) };
  return { winnerIds: winners.map((d) => d.playerId), tieIds: null };
}

/**
 * Split the dropped value equally between the two winners of a 2v2. If the
 * amount cannot be split in two, the stronger player of the winning team (the
 * one who unboxed more value; ties broken by the biggest single pull, then
 * seat order) takes the larger share. Task 76: computed in integer cents so a
 * cent-precise pot always lands back exactly.
 */
export function splitTeamPot(
  pot: number,
  players: BattlePlayer[],
  winners: BattlePlayer[],
  settled: BattleResult[]
): Record<string, number> {
  const totalCents = Math.round(pot * 100);
  const share = Math.floor(totalCents / 2) / 100;
  const shares: Record<string, number> = {};
  for (const w of winners) shares[w.id] = share;
  const rest = totalCents / 100 - share * winners.length;
  if (rest > 0 && winners.length === 2) {
    const totalOf = (id: string) => settled.find((d) => d.playerId === id)?.total ?? 0;
    const maxPull = (id: string) => Math.max(0, ...(settled.find((d) => d.playerId === id)?.pulls.map((x) => x.value) ?? [0]));
    const stronger = [...winners].sort(
      (a, b) => totalOf(b.id) - totalOf(a.id) || maxPull(b.id) - maxPull(a.id)
    )[0];
    shares[stronger.id] += rest;
  }
  return shares;
}

/**
 * TAKE per player for a finished battle — the money each player actually
 * walked away with: the full drop total for a solo winner, the post-split
 * share for each 2v2 winner, an equal cut for everyone in SHARED, and 0
 * (absent) for the losers.
 * Works both from the live room state and from a stored history record.
 */
export function takePerPlayer(
  battle: Pick<Battle, "teamMode" | "players" | "potRule">,
  results: BattleResult[],
  winnerIds: string[]
): Record<string, number> {
  const drops = dropTotal(results);
  if (potRuleOf(battle) === "shared") {
    return sharedSplit(drops, battle.players);
  }
  if (battle.teamMode && winnerIds.length === 2) {
    return splitTeamPot(
      drops,
      battle.players,
      battle.players.filter((p) => winnerIds.includes(p.id)),
      results
    );
  }
  return Object.fromEntries(winnerIds.map((id) => [id, drops]));
}

/** Headless resolve for full bot-only battles nobody is watching. */
export function headlessResolve(battle: Battle): Battle {
  const cases = battleCases(battle);
  const totals = battle.players.map((p) => {
    let total = 0;
    const pulls: BattlePull[] = [];
    battle.rounds.forEach((_, ri) => {
      const cs = cases[ri % cases.length];
      // Task 72: item-level draw — carries the wear + wear-adjusted value
      const { item, skin } = rollCaseItem(cs);
      total += skin.value;
      pulls.push({ round: ri, skinId: skin.id, wear: item.wear, value: skin.value });
    });
    return { playerId: p.id, total, pulls };
  });

  // USER SPEC (Task 45 + fix): a ROLLDROP hit REPLACES that round's skin —
  // the pull becomes a rare-pool draw flagged `rd` (the reel stops on the
  // raredrop art, waits a second, then the rare round opens on the same reel).
  // The original skin is discarded — the rolldrop round is worth ONLY its
  // rare-pool draw (same rules as the live room).
  for (const t of totals) {
    for (let ri = battle.rounds.length - 1; ri >= 0; ri--) {
      if (Math.random() >= rolldropChanceOf(cases[ri % cases.length])) continue;
      const { item, skin } = rollCaseItem(rareCaseOf(cases[ri % cases.length]));
      const idx = t.pulls.findIndex((x) => x.round === ri);
      const old = t.pulls[idx];
      t.pulls[idx] = { round: ri, skinId: skin.id, wear: item.wear, value: skin.value, rd: true };
      t.total += skin.value - old.value;
    }
  }

  const outcome = computeOutcome(battle.players, totals, battle.mode, battle.teamMode, battle.potRule ?? "winner");
  let winnerIds = outcome.winnerIds;
  if (outcome.tieIds) {
    // headless: break the tie with a coin flip among the tied participants
    const t = pick(outcome.tieIds);
    winnerIds =
      t === "t0" || t === "t1"
        ? battle.players.filter((p) => p.team === (t === "t0" ? 0 : 1)).map((p) => p.id)
        : [t];
  }

  return {
    ...battle,
    status: "finished",
    results: totals,
    winnerIds,
    potTotal: dropTotal(totals), // history shows what the winner actually took
    botCalls: {},
  };
}
