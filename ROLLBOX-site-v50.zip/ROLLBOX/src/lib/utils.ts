import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/* ===== USER SPEC (Task 81/82 + CRITICAL fix — EDGING): every roulette stop
   is randomized, but the BOUNDARY RULE is absolute: the center line must
   NEVER leave the winner's own tile between the stop and the lock. The reel
   still plays the drama — it crawls past the PREVIOUS skin (fully), crosses
   the boundary INTO the winner's zone (sometimes barely over it — "it just
   made it onto the next skin!"), holds a beat there, then SNAPS forward to
   center the winner. It may also drift a little past the winner's center
   (still holding the line on the winner) and snap back a short distance.
   What it can NEVER do again: glide onto the NEXT skin, fully arrive at it,
   and roll BACK to the winner — that read as fake and broke the site's
   credibility (user, critical fix). The roll is a SIGNED fraction of the
   winner tile's own HALF-WIDTH (item/2):
     negative = stop BEFORE the center (crossed the previous boundary —
                the snap continues FORWARD, centering the entered skin),
     positive = stop slightly past the center (short settle-back).
   Server-decided results untouched — cosmetic offset only. */
export function edgingRoll(rng: () => number = Math.random): number {
  const r = rng();
  if (r < 0.4) return -(0.3 + rng() * 0.4); // mid under-hang (−0.30..−0.70): stopped short, snaps in
  if (r < 0.6) return -(0.15 + rng() * 0.2); // late under-hang (−0.15..−0.35): almost centered already
  if (r < 0.82) return -(0.78 + rng() * 0.14); // EXTREME (−0.78..−0.92): barely crossed onto the winner — snaps in
  return 0.1 + rng() * 0.35; // small over-hang (+0.10..+0.45): short snap back, no skin ever passed
}

/** Task 82-fix: the glide PIXEL offset for a reel — the signed edging
 *  fraction scaled by the winner tile's own half-width, HARD-CLAMPED so the
 *  center line can never leave the winner's tile: at most 92% of the
 *  half-width before the center (barely crossed the previous boundary) and
 *  at most 45% past it (the NEXT skin can never arrive at the line —
 *  nothing is ever "fully passed" and rolled back from). */
export function edgingGlidePx(edging: number, itemPx: number): number {
  const e = Math.max(-0.92, Math.min(0.45, edging));
  return e * (itemPx / 2);
}

/** Task 82-fix timings, REWORKED (Task 104b — user spec): the case opener
 *  passes { hold: false } — its "LOCKING IN" stage is GONE: no still BEAT,
 *  the crawl hands over to one FAST settle snap that centers the winner and
 *  the lock + reveal follow immediately. Battles keep the short beat + snap
 *  (they never showed a locking stage). */
export function edgingPhases(
  duration: number,
  opts?: { hold?: boolean }
): { holdMs: number; settleMs: number } {
  if (opts?.hold === false) {
    return { holdMs: 0, settleMs: Math.max(100, Math.min(160, Math.round(duration * 0.02))) };
  }
  return {
    holdMs: Math.max(120, Math.min(220, Math.round(duration * 0.025))),
    settleMs: Math.max(140, Math.min(220, Math.round(duration * 0.035))),
  };
}

export type EdgingPhase = "spin" | "hold" | "settle" | "done";

/** Task 82: the piecewise EDGING CLOCK shared by every reel. It returns the
 *  two curve values the reels combine with THEIR OWN geometry:
 *    aCrawl  — the power-6 spin curve (0→1): the last tiles CRAWL toward the
 *              marker (the slow, dramatic approach the user asked for),
 *    aSettle — the easeOutQuart SNAP (0→1): unwinds ONLY the glide offset,
 *              fast attack, gentle arrival — carrying the winner from the
 *              glide point to the exact center line. Task 104b: the still
 *              BEAT between them is GONE (holdMs = 0) — the settle starts
 *              the instant the crawl ends.
 *  Reel position = aCrawl * (base + glide) − aSettle * glide, so:
 *    spin end  → base + glide (the stop point — INSIDE the winner's tile,
 *                before or slightly past its center), then
 *    settle end→ base — the winner ARRIVES at the center and locks.
 *  Task 176 (user spec): the crawl exponent is now a PARAMETER (default 6 —
 *  battles/jackpot/tiebreaker unchanged). The case opener passes 4: power-6
 *  covers 99.99% of the distance by 80% of the clock and then reads as FROZEN
 *  for the last ~2.4s ("it stays too long in place before the winner locks");
 *  power-4 keeps a visible, ticking crawl through the whole approach so the
 *  ending closes much sooner. */
export function edgingClock(
  elapsed: number,
  spinMs: number,
  holdMs: number,
  settleMs: number,
  crawlPow = 6
): { phase: EdgingPhase; aCrawl: number; aSettle: number; p: number } {
  if (elapsed < spinMs) {
    const p = elapsed / spinMs;
    return { phase: "spin", aCrawl: 1 - Math.pow(1 - p, crawlPow), aSettle: 0, p };
  }
  if (elapsed < spinMs + holdMs) return { phase: "hold", aCrawl: 1, aSettle: 0, p: 1 };
  const t2 = elapsed - spinMs - holdMs;
  if (t2 < settleMs) {
    const q = t2 / settleMs;
    const s = 1 - Math.pow(1 - q, 4); // easeOutQuart — the fast, decisive SNAP
    return { phase: "settle", aCrawl: 1, aSettle: s, p: 1 };
  }
  return { phase: "done", aCrawl: 1, aSettle: 1, p: 1 };
}
