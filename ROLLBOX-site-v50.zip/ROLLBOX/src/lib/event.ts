// ============ EMERALD DROP — the limited EVENTS feature (USER SPEC) ============
// Pure client-safe constants — NO imports (cases.ts consumes them, so a
// circular import here would break the whole catalog).
//
// The event is a fixed-window promotion: a dedicated EVENT case (kind
// "event") openable like any regular case while the window is live, plus a
// wager-race leaderboard: every coin spent opening the event case counts up
// the board, and when the window closes the top 5 split the prize pool
// (1st $50, 2nd $40, 3rd $30, 4th $20, 5th $10 — credited to the balance).
//
// Ending the event = flipping EVENT_ENDS_AT: the case stops opening (server
// guard), leaves the battle picker and the leaderboard freezes; prizes are
// awarded exactly once (CAS-claimed) by the /api/event read path.

/** The event case's catalog id (the CaseDef lives in cases.ts). */
export const EVENT_CASE_ID = "event-emerald-drop";

/** Display name of the event (hero + page title). */
export const EVENT_NAME = "Emerald Drop";

/** When the whole event (case + leaderboard + prizes) closes — UTC. */
export const EVENT_ENDS_AT = Date.parse("2026-10-03T21:00:00.000Z");

/** Prize per final place, index 0 = 1st place. USER SPEC: each place is
 *  worth $10 more — place 5 gets a $10 skin, place 4 $20, ... 1st $50. */
export const EVENT_PRIZES: readonly number[] = [50, 40, 30, 20, 10];

/** True while the event window is open. */
export function eventActive(now: number = Date.now()): boolean {
  return now < EVENT_ENDS_AT;
}

/** ms remaining until the event closes (0 once it has ended). */
export function eventMsLeft(now: number = Date.now()): number {
  return Math.max(0, EVENT_ENDS_AT - now);
}
