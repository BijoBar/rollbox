// Case artwork served from /public/cases/<slug>.webp (800x615, transparent).
// Case ids missing from this set automatically fall back to the procedural
// SVG art (components/rollbox/CaseArt.tsx).
//
// Task 188 (user request): the AI-designed artwork was REMOVED (all 41 webp
// files deleted — recoverable from git commit 3d1de2f). The user is preparing
// replacement images and will send them. To re-enable: drop each new webp at
// public/cases/<slug>.webp and add its slug back to this set
// (scripts/optimize-case-images.py can rebuild the list as the union of
// everything present in public/cases).

export const CASE_IMAGE_SLUGS: ReadonlySet<string> = new Set<string>([]);

export function caseImagePath(slug: string): string {
  return `/cases/${slug}.webp`;
}

/** Shared canvas size of every case image (prevents layout shift). */
export const CASE_IMAGE_SIZE = { width: 800, height: 615 } as const;
