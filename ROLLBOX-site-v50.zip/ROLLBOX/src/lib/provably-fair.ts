// ============ ROLLBOX Provably Fair engine ============
// Commit-reveal scheme (same math as skin.club):
//   1. BEFORE any roll the site commits to a secret pair:
//        Public Hash = SHA-256(serverSeed + secretSalt)
//   2. Every opening derives its outcome deterministically:
//        Roll  = HMAC-SHA256(serverSeed, `${clientSeed}:${nonce}`) -> float in [0,1)
//        Item  = float mapped onto the case's weighted drop table
//   3. When the seed pair is rotated (reveal), the old serverSeed + salt become
//      public, so anyone can verify:
//        - SHA-256(serverSeed + salt) === Public Hash  (seed was never swapped)
//        - recomputing the rolls reproduces every item exactly
//
// Neither side controls the outcome alone: the player owns the clientSeed,
// while the serverSeed stays hidden until reveal and is locked by its hash.

import { sha256 } from "js-sha256";
import { caseItemSkin, type CaseDef, type Skin } from "./cases";

const HEX = "0123456789abcdef";

/** Cryptographically random hex string of `bytes` bytes. */
export function randomHex(bytes: number): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  let out = "";
  for (const b of arr) out += HEX[b >> 4] + HEX[b & 15];
  return out;
}

export const generateServerSeed = () => randomHex(32); // 64 hex chars
export const generateSalt = () => randomHex(16); // 32 hex chars
export const generateClientSeed = () => randomHex(16); // 32 hex chars

/** Compact display form: first 8 … last 6 chars. */
export function shortSeed(seed: string): string {
  if (!seed) return "—";
  if (seed.length <= 18) return seed;
  return `${seed.slice(0, 8)}…${seed.slice(-6)}`;
}

/** Public commitment shown BEFORE any roll is made. */
export function computePublicHash(serverSeed: string, salt: string): string {
  return sha256(serverSeed + salt);
}

/**
 * Deterministic float in [0,1) for a given seed pair + nonce.
 * First 8 hex chars of the HMAC digest = uniform 32-bit integer / 2^32.
 */
export function rollFloat(
  serverSeed: string,
  clientSeed: string,
  nonce: number
): number {
  const digest = sha256.hmac(serverSeed, `${clientSeed}:${nonce}`);
  const int = parseInt(digest.slice(0, 8), 16);
  return int / 0x100000000;
}

/**
 * Map a float in [0,1) onto ANY weighted item list — the ONE canonical
 * mapping used by every roller in the codebase (Task 151: the server rolls
 * now go through this exact function, so what the verifier recomputes is
 * bit-identical to what decided the outcome). Equivalent to the old
 * per-file rollItem loops: acc = r*total, walk the list, first index where
 * the running subtraction hits <= 0, last item as the numeric-edge fallback.
 */
export function pickWeighted<T extends { weight: number }>(items: T[], r: number): T {
  const total = items.reduce((s, i) => s + i.weight, 0);
  let acc = r * total;
  for (const item of items) {
    acc -= item.weight;
    if (acc <= 0) return item;
  }
  return items[items.length - 1];
}

/**
 * Map a float in [0,1) onto the case's weighted drop table.
 * Task 72: the returned skin carries the item's WEAR (label + wear-adjusted
 * value) when the case item pins an exterior — the id stays the base skin id,
 * so verification and image lookup are unchanged.
 */
export function rollCasePF(caseDef: CaseDef, r: number): Skin {
  return caseItemSkin(pickWeighted(caseDef.items, r));
}

export interface RollProof {
  nonce: number;
  clientSeed: string;
  serverSeedHash: string; // public hash active when the roll happened
  float: number;
  skin: Skin;
}

/** Full provably-fair draw for a case (pure, no state). */
export function drawCasePF(
  caseDef: CaseDef,
  serverSeed: string,
  clientSeed: string,
  nonce: number,
  serverSeedHash: string
): RollProof {
  const float = rollFloat(serverSeed, clientSeed, nonce);
  return {
    nonce,
    clientSeed,
    serverSeedHash,
    float,
    skin: rollCasePF(caseDef, float),
  };
}
