// ============ GlobalBattle -> original Battle adapter ============
// The server's GlobalBattle was designed as "the original Battle shape,
// multiplayer-safe" — this adapter completes the mapping: stamps isYou per
// viewer, fills the local-only fields (botCalls/fullSince) with inert values
// and carries the shared-clock data (schedule/startedAt/clock offset) the
// original room needs to pace its animation.

import type { GlobalBattle } from "@/lib/gbattle-shared";
import type { Battle, BattleStatus } from "@/lib/battles";

export function adaptGlobalBattle(gb: GlobalBattle, myId: string, clockOffset: number): Battle {
  const status: BattleStatus =
    gb.status === "finished" ? "finished" : gb.status === "waiting" ? "waiting" : "playing";
  return {
    id: gb.id,
    // USER SPEC (Task 67): the room code rides through — the PRIVATE invite
    code: gb.code,
    type: gb.type,
    mode: gb.mode,
    potRule: gb.potRule,
    maxPlayers: gb.maxPlayers,
    teamMode: gb.teamMode,
    // USER SPEC (Task 67): the PRIVATE badge rides through the adapter
    isPrivate: gb.isPrivate,
    rounds: gb.rounds,
    status,
    createdAt: gb.createdAt,
    players: gb.players.map((p) => ({ ...p, isYou: p.id === myId })),
    colorOrder: gb.colorOrder,
    // USER SPEC (Task 66): the server's PLAY WITH BOTS votes feed the EXISTING
    // voting UI — the "PLAY WITH BOTS" chip next to each voter's name and the
    // disabled state of their own Call Bots button — exactly like local rooms.
    botCalls: Object.fromEntries(gb.players.filter((p) => p.botsVote).map((p) => [p.id, true])),
    fullSince: null,
    results: gb.results ?? undefined,
    winnerIds: gb.winnerIds ?? undefined,
    potTotal: gb.potTotal ?? undefined,
    tieIds: gb.tieIds ?? undefined,
    take: gb.take ?? undefined,
    global: true,
    schedule: gb.schedule,
    startedAtMs: gb.startedAt,
    clockOffset,
  };
}
