// ============ SKIN WEAR (Task 72) ============
// USER SPEC: every skin carries the five CS2 exteriors — Factory New, Minimal
// Wear, Field-Tested, Well-Worn, Battle-Scarred — each priced on its own.
// Case items pick a wear in the case editor; the Exchange lets the player buy
// a specific wear; every value in the economy is resolved through HERE.
//
// Price sources (offline, refreshed by scripts — no runtime scraping):
//   catalog entries  → entry.wp  (USD per wear, market.csgo.com bulk dump)
//   case skins       → SKIN_WEAR_PRICES (coins per skinId per wear)
// When a wear has no market listing the value falls back to a wear factor
// applied to the nearest known price — flagged as estimated ("~") in the UI.

import { SKIN_WEAR_PRICES } from "./generated-wear-prices";

export type WearId = "FN" | "MW" | "FT" | "WW" | "BS";

export interface WearMeta {
  id: WearId;
  label: string; // full CS2 exterior name
  short: string; // tile badge
  factor: number; // estimate factor relative to Field-Tested
  color: string; // USER SPEC (R43): the exterior's site-wide color
}

/** USER SPEC (R43 — WEAPON CONDITION COLORS): every skin's exterior is
 *  listed SITE-WIDE in its own color — battles, cases, upgrader, exchange,
 *  terminal, inventory, history — and a skin shown WITHOUT a condition
 *  displays the default one (Field-Tested) so every skin always carries one. */
export const WEAR_COLORS: Record<WearId, string> = {
  FN: "#48ff00", // Factory New — neon green
  MW: "#ddff00", // Minimal Wear — lime
  FT: "#ffe600", // Field-Tested — yellow
  WW: "#ff9100", // Well Worn — orange
  BS: "#ff3300", // Battle Scarred — red-orange
};

export const WEARS: WearMeta[] = [
  { id: "FN", label: "Factory New", short: "FN", factor: 1.45, color: WEAR_COLORS.FN },
  { id: "MW", label: "Minimal Wear", short: "MW", factor: 1.18, color: WEAR_COLORS.MW },
  { id: "FT", label: "Field-Tested", short: "FT", factor: 1, color: WEAR_COLORS.FT },
  { id: "WW", label: "Well-Worn", short: "WW", factor: 0.87, color: WEAR_COLORS.WW },
  { id: "BS", label: "Battle-Scarred", short: "BS", factor: 0.78, color: WEAR_COLORS.BS },
];

export const WEAR_BY_ID: Record<WearId, WearMeta> = Object.fromEntries(
  WEARS.map((w) => [w.id, w])
) as Record<WearId, WearMeta>;

export const WEAR_IDS: WearId[] = WEARS.map((w) => w.id);

export const isWearId = (v: unknown): v is WearId =>
  typeof v === "string" && (WEAR_IDS as string[]).includes(v);

/** Reverse lookup: full label -> canonical id ("Field-Tested" -> "FT"). */
export function wearIdFromLabel(label: string | undefined | null): WearId | undefined {
  if (!label) return undefined;
  return WEARS.find((w) => w.label === label)?.id;
}

/** The wear a skin should default to in pickers: FT, else the first available. */
export const DEFAULT_WEAR: WearId = "FT";

/** R43: the exterior a skin displays when none is pinned — skins NEVER show
 *  without a WEAPON CONDITION anymore. */
export const DEFAULT_WEAR_LABEL = WEAR_BY_ID[DEFAULT_WEAR].label;

/** R43: color of an exterior given a WearId ("FT"), a full label
 *  ("Field-Tested") or a short code — anything unknown falls back to the
 *  default exterior's color, so a skin's condition is always colored. */
export function wearColorOf(idOrLabel?: string | null): string {
  if (idOrLabel) {
    const direct = (WEAR_BY_ID as Record<string, WearMeta | undefined>)[idOrLabel];
    if (direct) return direct.color;
    const byLabel = WEARS.find((w) => w.label === idOrLabel || w.short === idOrLabel);
    if (byLabel) return byLabel.color;
  }
  return WEAR_COLORS[DEFAULT_WEAR];
}

/** R43: the full exterior label baked into a market name tail —
 *  "AK-47 | Slate (Field-Tested)" -> "Field-Tested". Sticker foils, fades and
 *  every other parenthetical that is NOT an exterior resolve to undefined. */
export function wearLabelFromName(name?: string | null): string | undefined {
  if (!name) return undefined;
  const m = /\(([^()]+)\)\s*$/.exec(name.trim());
  if (!m) return undefined;
  const inside = m[1].trim();
  return WEARS.some((w) => w.label === inside) ? inside : undefined;
}

/** R43: THE exterior a skin displays — explicit wear (id or label) wins,
 *  then the name's parenthetical tail, then the default (Field-Tested). */
export function displayWearLabel(wear?: string | null, name?: string | null): string {
  if (wear) {
    const byId = (WEAR_BY_ID as Record<string, WearMeta | undefined>)[wear];
    if (byId) return byId.label;
    if (WEARS.some((w) => w.label === wear)) return wear;
  }
  return wearLabelFromName(name) ?? DEFAULT_WEAR_LABEL;
}

/** R43: the short badge code of a stored wear ("FT" / "Field-Tested" -> "FT"),
 *  defaulting like displayWearLabel so the chip never comes up empty. */
export function wearShortOf(idOrLabel?: string | null): string {
  if (idOrLabel) {
    const byId = (WEAR_BY_ID as Record<string, WearMeta | undefined>)[idOrLabel];
    if (byId) return byId.short;
    const byLabel = WEARS.find((w) => w.label === idOrLabel);
    if (byLabel) return byLabel.short;
  }
  return WEAR_BY_ID[DEFAULT_WEAR].short;
}

/** R43: catalog labels that NEVER carry an exterior — the exchange's
 *  non-skin categories (and their inventory snapshots) show no condition. */
const NON_WEAR_KINDS = new Set([
  "sticker",
  "charm",
  "agent",
  "patch",
  "music kit",
  "graffiti",
  "souvenir package",
  "pin",
  "case",
  "key",
]);

/** True when this weapon/label display name belongs to a wearable SKIN. */
export function isWearableKind(kindLabel?: string | null): boolean {
  if (!kindLabel) return true;
  return !NON_WEAR_KINDS.has(kindLabel.trim().toLowerCase());
}

/** CS2 market hash name of a base skin at a wear: "AK-47 | Redline (Field-Tested)". */
export function wearHashName(baseName: string, wear: WearId): string {
  return `${baseName} (${WEAR_BY_ID[wear].label})`;
}

/** Display name of a skin at a wear (same shape as the market name). */
export function wearDisplayName(baseName: string, wear: WearId): string {
  return wearHashName(baseName, wear);
}

// ---------- catalog entries (the Exchange) ----------

/** Minimal shape of a catalog entry that carries wear prices. */
export interface WearPricedEntry {
  n: string; // base display name
  p: number; // USD price (min across wears — the legacy catalog price)
  v: number; // coin price
  wp?: Partial<Record<WearId, number>>; // USD per wear (real market data)
  wa?: WearId[]; // in-game availability (absent = all five)
  est?: 1;
}

export interface WearPriceResult {
  wear: WearId;
  usd: number;
  coins: number;
  est: boolean; // true = factor estimate, no market listing right now
}

/**
 * The USD price of a catalog entry at a specific wear. Real market price when
 * the bulk dump has one; otherwise a factor estimate scaled from the nearest
 * priced wear (or the entry's own price when nothing is priced at all).
 *
 * USER SPEC (Task 90): the exchange reads CENTS like the whole site — the
 * coin price is rounded to 0.01 (never to a whole coin), with a 0.01 floor,
 * so a $0.03 exterior shows 0.30 instead of the old buggy "0".
 *
 * Task 27/29/30 (unified economy): USD_TO_COINS is THE site-wide dollar→coin
 * rate — THE master switch of the whole denomination. Task 28 flipped it to 1,
 * Task 29 restored 10 per the owner's ruling, and Task 30 brings the FINAL
 * ruling: the X10 scale is NOT good — the whole economy runs at 1$ = 1 coin
 * (every site price = the real market USD 1:1). Every conversion goes through
 * the helpers below — no hardcoded ×10 / ÷10 anywhere else.
 */
export const USD_TO_COINS = 1;

export const usdToCoins = (usd: number): number =>
  Math.max(0.01, Math.round(usd * 100 * USD_TO_COINS) / 100);

/** Task 27: the reverse conversion (coin charge -> the USD stored in snapshots). */
export const coinsToUsd = (coins: number): number =>
  Math.max(0.01, Math.round((coins / USD_TO_COINS) * 100) / 100);

export function entryWearPrice(entry: WearPricedEntry, wear: WearId): WearPriceResult {
  const direct = entry.wp?.[wear];
  if (direct && direct > 0) return { wear, usd: direct, coins: usdToCoins(direct), est: false };
  // estimate from the nearest priced wear so every chip always shows a number
  if (entry.wp) {
    let best: { w: WearId; usd: number } | null = null;
    for (const [w, usd] of Object.entries(entry.wp) as [WearId, number][]) {
      if (!usd) continue;
      if (!best || Math.abs(WEAR_BY_ID[w].factor - WEAR_BY_ID[wear].factor) < Math.abs(WEAR_BY_ID[best.w].factor - WEAR_BY_ID[wear].factor)) {
        best = { w, usd };
      }
    }
    if (best) {
      const usd = (best.usd * WEAR_BY_ID[wear].factor) / WEAR_BY_ID[best.w].factor;
      return { wear, usd, coins: usdToCoins(usd), est: true };
    }
  }
  const usd = entry.p * WEAR_BY_ID[wear].factor;
  return { wear, usd, coins: usdToCoins(usd), est: true };
}

/** The wears a player can pick for this entry (in-game availability). */
export function entryWearIds(entry: WearPricedEntry): WearId[] {
  if (entry.wa) return entry.wa;
  return [...WEAR_IDS];
}

/** True when the skin comes in every CS2 wear (most weapon skins). */
export const hasAllWears = (entry: WearPricedEntry) => !entry.wa && entry.wp !== undefined;

// ---------- case skins (the case registry) ----------

/**
 * Coin value of a case SKIN at a wear: the generated market table first,
 * then the factor estimate applied to the skin's base value.
 */
export function skinWearValue(
  skinId: string,
  wear: WearId,
  baseValue: number
): { value: number; est: boolean } {
  const direct = SKIN_WEAR_PRICES[skinId]?.[wear];
  if (direct && direct > 0) return { value: direct, est: false };
  // scale from the nearest priced wear of the same skin when possible
  const wp = SKIN_WEAR_PRICES[skinId];
  if (wp) {
    let best: { w: WearId; v: number } | null = null;
    for (const [w, v] of Object.entries(wp) as [WearId, number][]) {
      if (!v) continue;
      if (!best || Math.abs(WEAR_BY_ID[w].factor - WEAR_BY_ID[wear].factor) < Math.abs(WEAR_BY_ID[best.w].factor - WEAR_BY_ID[wear].factor)) {
        best = { w, v };
      }
    }
    if (best) return { value: Math.max(1, Math.round((best.v * WEAR_BY_ID[wear].factor) / WEAR_BY_ID[best.w].factor)), est: true };
  }
  return { value: Math.max(1, Math.round(baseValue * WEAR_BY_ID[wear].factor)), est: true };
}
