// ============ MISSIONS — the 10-mission catalog (Task 31, USER SPEC) ============
// The owner's mission board, exactly as specified: name, steps, prize (TBA —
// the owner will fill the rewards in when the payout system lands).
//
// Step status:
//   "live" — the feature exists on the site today (battles, upgrader,
//            daily cases, deposits, terminal, farm cases, referral invites).
//   "soon" — the step is gated behind a system the owner ships NEXT
//            (email connect + verification, Discord account linking,
//            the automatic newsletter). The step still shows on the board so
//            players see the full contract; progress starts counting once the
//            system lands.
//
// Progress tracking + reward payout ride on top of this catalog in a follow-up
// task (the owner: "בהמשך נבצע מערכת אימות אימייל ואימות דיסקורד וקישור
// המשתמש דיסקורד לאתר, בנוסף לכך NEWSLETTER לאימייל (מערכת אוטומטית)").

export interface MissionStep {
  /** stable id for future progress wiring ("m2s1" = mission 2, step 1) */
  id: string;
  label: string;
  /** false = gated behind an upcoming system (email / discord-link / newsletter) */
  live: boolean;
}

export interface Mission {
  id: string;
  name: string;
  steps: MissionStep[];
  /** Task 183 (USER SPEC): every prize is ONE FREE RB-106 box. */
  prize: string;
  // Task 184 (USER SPEC): the display label says the case NAME — "FREE Doppler
  // Realm Case" — not the internal code RB-106.
}

// USER SPEC (Task 183): "אני רוצה שכל פרס במשימות תיהיה תיבה RB-106 חינם" —
// the mission payout currency is the RB-106 (Doppler Realm) case, granted as a
// FREE box into the player's freeCases map the moment ALL of a mission's live
// steps are done (server/lib/server/missions.ts claimMissionPrizes).
export const MISSION_PRIZE_CASE_ID = "doppler-realm"; // code RB-106
export const MISSION_PRIZE_QTY = 1;
// Task 184 (USER SPEC): "FREE RB-106" → "FREE Doppler Realm Case" — the
// prize reads as the case's real name everywhere on the board.
export const MISSION_PRIZE_LABEL = "FREE Doppler Realm Case ×1";

export const MISSIONS: Mission[] = [
  {
    id: "m1",
    name: "Up To Date!",
    steps: [{ id: "m1s1", label: "Connect your email address to the site", live: false }],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m2",
    name: "Battle Rookie",
    steps: [
      { id: "m2s1", label: "Play 3 battles of $3 or more", live: true },
      { id: "m2s2", label: "Win 1 battle", live: true },
      { id: "m2s3", label: "Play a battle with bots", live: true },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m3",
    name: "To The Moon!",
    steps: [
      { id: "m3s1", label: "Upgrade a skin at 2x or higher", live: true },
      { id: "m3s2", label: "Upgrade a skin worth $10 or more", live: true },
      { id: "m3s3", label: "Win an upgrade at 3x", live: true },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m4",
    name: "Verified Player",
    steps: [
      { id: "m4s1", label: "Deposit at least $50 to the site", live: true },
      { id: "m4s2", label: "Open 5 cases of $5 or more", live: true },
      { id: "m4s3", label: "Verify your account via email", live: false },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m5",
    name: "Battle Pro",
    steps: [
      { id: "m5s1", label: "Play 3 battles of 4 players or more", live: true },
      { id: "m5s2", label: "Play 3 battles of $10 or more", live: true },
      { id: "m5s3", label: "Win 5 battles against bots", live: true },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m6",
    name: "Daydreamer",
    steps: [
      { id: "m6s1", label: "Open 5 daily cases", live: true },
      { id: "m6s2", label: "Deposit at least $65", live: true },
      { id: "m6s3", label: "Win an upgrade at 5x", live: true },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m7",
    name: "Highroller",
    steps: [
      { id: "m7s1", label: "Deposit at least $200", live: true },
      { id: "m7s2", label: "Win 20 battles", live: true },
      { id: "m7s3", label: "Win an upgrade at 10x", live: true },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m8",
    name: "Farmer",
    steps: [
      { id: "m8s1", label: "Open at least 20 FARM cases", live: true },
      { id: "m8s2", label: "Win 5 upgraders in a row on 1.05x", live: true },
      { id: "m8s3", label: "Play a SHARED battle 5 times", live: true },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m9",
    name: "Contractor",
    steps: [
      { id: "m9s1", label: "Play the TERMINAL at $5 or more, 3 times", live: true },
      { id: "m9s2", label: "Play THE BOSS terminal at least once", live: true },
      { id: "m9s3", label: "Sell 5 skins", live: true },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
  {
    id: "m10",
    name: "Loyal Follower",
    steps: [
      { id: "m10s1", label: "Join the Discord server and link your Discord user to the site", live: false },
      { id: "m10s2", label: "Subscribe to the NEWSLETTER (Settings)", live: false },
      { id: "m10s3", label: "Invite 3 friends with your REFERRAL CODE", live: true },
    ],
    prize: MISSION_PRIZE_LABEL,
  },
];
