// Verified-build marker — bumped whenever the case economy or core code changes.
// Rendered as a small always-on badge on every page (root layout) so ANY running
// copy of the site (live preview or a local ZIP extraction) can be identified
// at a glance: if the badge is missing, the copy is pre-retune and must be
// replaced with the latest package.
export const BUILD_TAG = "INFINITE CORRIDOR · BUILD 2026-09-26 R47";
