import { create } from "zustand";
import { persist } from "zustand/middleware";
import { sha256 } from "js-sha256";

/**
 * Client-side demo accounts (localStorage persisted).
 * Passwords are stored as SHA-256 hashes — never in plain text.
 * This is an entertainment demo: no server, no real authentication.
 */

export interface Account {
  user: string;
  passHash: string;
  createdAt: number;
}

export interface AuthResult {
  ok: boolean;
  error?: string;
}

export const GUEST_FAVS_KEY = "__guest";

interface AuthStore {
  current: string | null; // logged-in username
  accounts: Record<string, Account>;
  /** favorited catalog item ids, bucketed per account (guests get their own bucket) */
  favs: Record<string, string[]>;
  signUp: (user: string, pass: string) => AuthResult;
  signIn: (user: string, pass: string) => AuthResult;
  signOut: () => void;
  deleteAccount: () => void;
  toggleFav: (itemId: string) => void;
  isFav: (itemId: string) => boolean;
  favCount: () => number;
}

const hash = (s: string) => sha256(`rollbox:${s}`);

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      current: null,
      accounts: {},
      favs: {},
      signUp: (user, pass) => {
        const name = user.trim();
        if (name.length < 3 || name.length > 20)
          return { ok: false, error: "Username must be 3-20 characters." };
        if (!/^[A-Za-z0-9_]+$/.test(name))
          return { ok: false, error: "Letters, numbers and underscore only." };
        if (pass.length < 4)
          return { ok: false, error: "Password must be at least 4 characters." };
        const accounts = get().accounts;
        if (accounts[name.toLowerCase()])
          return { ok: false, error: "That username is already taken." };
        const account: Account = {
          user: name,
          passHash: hash(pass),
          createdAt: Date.now(),
        };
        // migrate any guest favorites into the fresh account
        const favs = { ...get().favs };
        if (favs[GUEST_FAVS_KEY]?.length) {
          favs[name.toLowerCase()] = favs[GUEST_FAVS_KEY];
          delete favs[GUEST_FAVS_KEY];
        }
        set({
          accounts: { ...accounts, [name.toLowerCase()]: account },
          favs,
          current: name,
        });
        return { ok: true };
      },
      signIn: (user, pass) => {
        const name = user.trim();
        const account = get().accounts[name.toLowerCase()];
        if (!account) return { ok: false, error: "No account with that username." };
        if (account.passHash !== hash(pass))
          return { ok: false, error: "Wrong password. Try again." };
        set({ current: account.user });
        return { ok: true };
      },
      signOut: () => set({ current: null }),
      deleteAccount: () => {
        const current = get().current;
        if (!current) return;
        const accounts = { ...get().accounts };
        delete accounts[current.toLowerCase()];
        const favs = { ...get().favs };
        delete favs[current.toLowerCase()];
        set({ accounts, favs, current: null });
      },
      toggleFav: (itemId) => {
        const key = get().current?.toLowerCase() ?? GUEST_FAVS_KEY;
        const list = get().favs[key] ?? [];
        const next = list.includes(itemId)
          ? list.filter((id) => id !== itemId)
          : [itemId, ...list];
        set({ favs: { ...get().favs, [key]: next } });
      },
      isFav: (itemId) => {
        const key = get().current?.toLowerCase() ?? GUEST_FAVS_KEY;
        return (get().favs[key] ?? []).includes(itemId);
      },
      favCount: () => {
        const key = get().current?.toLowerCase() ?? GUEST_FAVS_KEY;
        return (get().favs[key] ?? []).length;
      },
    }),
    { name: "rollbox-auth" }
  )
);
