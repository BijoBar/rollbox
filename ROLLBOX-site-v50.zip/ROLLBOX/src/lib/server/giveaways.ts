// QOL (Task 167): giveaway drawing — the money-touching half of the
// giveaways feature. Winners are picked with crypto randomness, credited
// inside ONE $transaction (balance + "giveaway_win" ledger row each) and
// published to the live feed. Both the admin's DRAW button and the lazy
// auto-draw on the public list funnel through here, so the CAS guard
// (status updateMany where status="active") makes a double draw impossible.
import crypto from "crypto";
import { db } from "@/lib/db";
import { recordLedger, publishBalance } from "@/lib/server/ledger";
import { publish } from "@/lib/server/realtime";

export interface GiveawayWinner {
  playerId: string;
  name: string;
}

/**
 * Draw `giveawayId` (optionally early — the admin's force). Returns the
 * giveaway row after the draw, or null when the CAS lost a race / the
 * giveaway was not in a drawable state.
 */
export async function drawGiveaway(giveawayId: string, opts?: { force?: boolean }): Promise<{ id: string; status: string; winners: GiveawayWinner[] } | null> {
  const gw = await db.giveaway.findUnique({ where: { id: giveawayId } });
  if (!gw || gw.status !== "active") return null;
  if (!opts?.force && gw.endsAt.getTime() > Date.now()) return null;

  const claimed = await db.giveaway.updateMany({
    where: { id: giveawayId, status: "active" },
    data: { status: "drawn" },
  });
  if (claimed.count !== 1) return null; // another draw got there first

  const entries = await db.giveawayEntry.findMany({ where: { giveawayId } });
  const winners: GiveawayWinner[] = [];
  const pool = [...entries];
  const n = Math.min(gw.winnerCount, pool.length);
  for (let i = 0; i < n; i++) {
    const idx = crypto.randomInt(0, pool.length);
    const entry = pool.splice(idx, 1)[0];
    const player = await db.player.findUnique({ where: { id: entry.playerId }, select: { id: true, name: true, bannedAt: true } });
    if (!player || player.bannedAt) continue; // banned at draw time → prize skipped
    winners.push({ playerId: player.id, name: player.name });
  }

  for (const w of winners) {
    await db
      .$transaction(async (tx) => {
        const p = await tx.player.findUnique({ where: { id: w.playerId }, select: { id: true, balance: true } });
        if (!p) return;
        const balanceAfter = p.balance + gw.prizeCoins;
        await tx.player.update({ where: { id: w.playerId }, data: { balance: balanceAfter } });
        await recordLedger(w.playerId, "giveaway_win", gw.prizeCoins, balanceAfter, `Giveaway: ${gw.title}`, tx);
        publishBalance(w.playerId, balanceAfter);
      })
      .catch((err) => console.error("[giveaway] credit failed", giveawayId, w.playerId, err));
  }

  const updated = await db.giveaway.update({
    where: { id: giveawayId },
    data: { winners: JSON.stringify(winners) },
  });
  publish("giveaways", { at: Date.now() });
  return { id: updated.id, status: updated.status, winners };
}
