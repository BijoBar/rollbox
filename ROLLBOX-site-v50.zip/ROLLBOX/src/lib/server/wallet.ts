// ============ C7 PHASE 1 — REAL crypto deposits & withdrawals (server) ============
// Phase 1 is FULLY MANUAL BY DESIGN: the player sends USDT (TRC-20) to the
// site wallet and pastes the txid; the ADMIN verifies the transaction on a
// block explorer and approves. Nothing is automatic — no processor, no
// webhook, no third party. The admin IS the payment processor in this phase.
//
// Jurisdiction gate (USER SPEC decision): the site serves FOREIGN markets
// only — it is not available in Israel or any other restricted jurisdiction.
// The declaration checkbox in the wallet UI and the ToS eligibility section
// carry that rule; the server refuses every wallet request that arrives
// without it.

import { db } from "@/lib/db";

export const WALLET_METHOD_ID = "USDT_TRC20" as const;

/** The one Phase-1 method: USDT on Tron (TRC-20). 1 USDT = $1 = 1 coin
 *  (USD_TO_COINS, src/lib/wear.ts). Built as a table so future methods
 *  (BTC, ETH, a processor) plug in without reshaping the routes. */
export const WALLET_METHODS = [
  {
    id: WALLET_METHOD_ID,
    label: "USDT",
    network: "TRC-20 (Tron)",
    addressKey: "wallet.usdt_address",
    addressHint: "T… (34 characters, starts with T)",
  },
] as const;

export type WalletMethodId = (typeof WALLET_METHODS)[number]["id"];

// ---- config keys (SiteConfig rows; every one has a safe default) ----

export const WALLET_CONFIG_DEFAULTS = {
  "wallet.enabled": "1", // master switch — admin can freeze the whole feature
  "wallet.usdt_address": "", // EMPTY = deposits/withdrawals closed for the method
  "wallet.minDeposit": "10",
  "wallet.maxDeposit": "1000",
  "wallet.minWithdraw": "10",
  "wallet.maxWithdraw": "500",
} as const;

export type WalletConfigKey = keyof typeof WALLET_CONFIG_DEFAULTS;
export const WALLET_CONFIG_KEYS = Object.keys(WALLET_CONFIG_DEFAULTS) as WalletConfigKey[];

export interface WalletConfig {
  enabled: boolean;
  usdtAddress: string;
  minDeposit: number;
  maxDeposit: number;
  minWithdraw: number;
  maxWithdraw: number;
}

/** Read the whole wallet config (defaults merged over the DB rows). */
export async function walletConfig(): Promise<WalletConfig> {
  const rows = await db.siteConfig.findMany({ where: { key: { in: [...WALLET_CONFIG_KEYS] } } });
  const map = new Map(rows.map((r) => [r.key, r.value]));
  const num = (key: WalletConfigKey, fallback: number) => {
    const v = Number(map.get(key) ?? WALLET_CONFIG_DEFAULTS[key]);
    return Number.isFinite(v) && v > 0 ? v : fallback;
  };
  const minDeposit = num("wallet.minDeposit", 10);
  const maxDeposit = Math.max(minDeposit, num("wallet.maxDeposit", 1000));
  const minWithdraw = num("wallet.minWithdraw", 10);
  const maxWithdraw = Math.max(minWithdraw, num("wallet.maxWithdraw", 500));
  return {
    enabled: (map.get("wallet.enabled") ?? WALLET_CONFIG_DEFAULTS["wallet.enabled"]) === "1",
    usdtAddress: (map.get("wallet.usdt_address") ?? "").trim(),
    minDeposit,
    maxDeposit,
    minWithdraw,
    maxWithdraw,
  };
}

/** A TRON (TRC-20) address: T + 33 base58 chars. */
export function isTronAddress(a: string): boolean {
  return /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(a);
}

/** An on-chain transaction hash (TRON txids are 64 hex characters). */
export function isTxid(t: string): boolean {
  return /^[0-9a-fA-F]{64}$/.test(t);
}

/** Round to 2 decimals, exactly like every money route on the site. */
export const round2 = (n: number): number => Math.round(n * 100) / 100;

/** The confirmation the deposit/withdraw UI requires before it submits —
 *  the same sentence the server validates against (declared === true). */
export const JURISDICTION_DECLARATION =
  "I confirm I am at least 18 years old, that I am NOT a resident of or located in Israel or any other jurisdiction where real-money gaming is prohibited, and that online gaming is legal where I live.";
