// SECURITY (Task 167): TOTP two-factor auth (RFC 6238) for the admin panel,
// implemented directly on node:crypto — zero third-party deps (site rule:
// the money paths never grow supply-chain surface). Works with Google
// Authenticator / Authy / any RFC-compatible app: HMAC-SHA1, 6 digits, 30s
// step, ±1 step clock skew window.
import crypto from "crypto";

const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"; // RFC 4648 base32 alphabet

/** A fresh random base32 secret (160 bits = 32 chars) for authenticator apps. */
export function generateTotpSecret(bytes = 20): string {
  let bits = "";
  for (const b of crypto.randomBytes(bytes)) bits += b.toString(2).padStart(8, "0");
  let out = "";
  for (let i = 0; i + 5 <= bits.length; i += 5) out += B32[parseInt(bits.slice(i, i + 5), 2)];
  return out;
}

function b32decode(secret: string): Buffer {
  let bits = "";
  for (const ch of secret.toUpperCase().replace(/=+$/, "").replace(/\s/g, "")) {
    const idx = B32.indexOf(ch);
    if (idx >= 0) bits += idx.toString(2).padStart(5, "0");
  }
  const bytes: number[] = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}

/** The 6-digit code a generator app shows for the given 30s step. */
export function totpCode(secret: string, step: number): string {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const h = crypto.createHmac("sha1", b32decode(secret)).update(counter).digest();
  const off = h[h.length - 1] & 0xf;
  const bin = ((h[off] & 0x7f) << 24) | ((h[off + 1] & 0xff) << 16) | ((h[off + 2] & 0xff) << 8) | (h[off + 3] & 0xff);
  return String(bin % 1_000_000).padStart(6, "0");
}

/** Constant-time check of a user code against now±windowSteps (default ±1). */
export function verifyTotp(secret: string, code: string, windowSteps = 1): boolean {
  const clean = (code ?? "").replace(/\D/g, "");
  if (clean.length !== 6) return false;
  const step = Math.floor(Date.now() / 1000 / 30);
  for (let w = -windowSteps; w <= windowSteps; w++) {
    const want = totpCode(secret, step + w);
    if (crypto.timingSafeEqual(Buffer.from(want), Buffer.from(clean))) return true;
  }
  return false;
}

/** Paste into the authenticator app (manual entry) or open/copy as a URI. */
export function totpUri(secret: string): string {
  return `otpauth://totp/ROLLBOX:admin?secret=${secret}&issuer=ROLLBOX&algorithm=SHA1&digits=6&period=30`;
}
