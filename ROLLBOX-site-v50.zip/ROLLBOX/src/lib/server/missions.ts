// ============ MISSIONS server tracking (Task 32 — USER SPEC) ============
// "אני רוצה שאת כל הPROGRESS של המשימות תכניס לDB לעמודה של כל שחקן וההתקדמות
// שלו במשימות" — the progress of the mission board is stored IN THE DATABASE,
// on the player's own row: the Player.missions JSON column.
//
// SHAPE: {"v":1,"c":{"<counter>":<amount>, ...}} — v guards future migrations,
// c holds the LIFETIME counters (battles, cases, upgrader streaks, terminal
// deals, sells, deposits, referral invites). The per-step progress is derived
// from the counters by src/lib/missions-progress.ts (shared with the UI).
//
// CALLERS: the gameplay code paths bump counters via trackMissions() right
// after the server-validated action succeeds:
//   /api/open            casesDaily / casesFarm / cases5
//   gbattles settleRow   battles3/10/4, battlesBots, battlesShared, battlesWon, botsWon
//   /api/upgrader        up2 / up10 / upWin3 / upWin5 / upWin10 / upStreak105
//   playTerminal         term5 / termBoss
//   /api/inventory/sell  sold
//   /api/topup           depTotal
//   referral claim       refInvites
//
// trackMissions NEVER throws and NEVER blocks the gameplay action — a mission
// hiccup is swallowed (the counters are a display feature, not money).

import { db } from "@/lib/db";
import { MISSIONS, MISSION_PRIZE_CASE_ID, MISSION_PRIZE_QTY } from "@/lib/missions";
import { missionDoneCount } from "@/lib/missions-progress";
import { grantFreeCases } from "@/lib/server/freecases";

export interface MissionState {
  v: 1;
  c: Record<string, number>;
  /** Task 183: mission ids whose FREE RB-106 prize was already granted. */
  g?: string[];
}

const VERSION = 1 as const;
const EMPTY: MissionState = { v: VERSION, c: {} };

/** The player's stored counters (EMPTY when never tracked / garbage JSON). */
export function parseMissionState(raw: string | null | undefined): MissionState {
  if (!raw) return { ...EMPTY, c: {} };
  try {
    const parsed = JSON.parse(raw) as Partial<MissionState> | null;
    if (!parsed || typeof parsed !== "object" || typeof parsed.c !== "object" || parsed.c === null) {
      return { ...EMPTY, c: {} };
    }
    const c: Record<string, number> = {};
    for (const [k, v] of Object.entries(parsed.c)) {
      const n = typeof v === "number" ? v : Number(v);
      if (Number.isFinite(n) && n > 0) c[k] = n; // counters only ever grow ≥ 0
    }
    // Task 183: the granted-prize list rides along (deduped, catalog ids only)
    const KNOWN = new Set(MISSIONS.map((m) => m.id));
    const g = Array.isArray(parsed.g)
      ? [...new Set(parsed.g.filter((id): id is string => typeof id === "string" && KNOWN.has(id)))]
      : undefined;
    return { v: VERSION, c, ...(g && g.length ? { g } : {}) };
  } catch {
    return { ...EMPTY, c: {} };
  }
}

export async function getMissionState(playerId: string): Promise<MissionState> {
  const row = await db.player
    .findUnique({ where: { id: playerId }, select: { missions: true } })
    .catch(() => null);
  return parseMissionState(row?.missions);
}

/**
 * Bump the player's mission counters (DB column Player.missions).
 *   bumps — additive deltas ({ battlesWon: 1, battles3: 1 }); zero/negative
 *           values are harmless (a delta of 0 writes nothing for that key).
 *   sets  — absolute writes ({ upStreak105: 3 }); used by the 1.05x win
 *           STREAK which must RESET to 0 on a loss (counters alone can't).
 * Both applied in ONE read-modify-write. Fire-and-forget safe: every failure
 * is caught and logged-free silenced — the caller's gameplay flow continues.
 */
export async function trackMissions(
  playerId: string,
  bumps: Record<string, number> = {},
  sets: Record<string, number> = {},
): Promise<void> {
  try {
    const hasBump = Object.values(bumps).some((n) => Number.isFinite(n) && n !== 0);
    const hasSet = Object.keys(sets).length > 0;
    if (!hasBump && !hasSet) return;

    const current = await getMissionState(playerId);
    const c = current.c;
    for (const [k, delta] of Object.entries(bumps)) {
      if (!Number.isFinite(delta) || delta === 0) continue;
      c[k] = Math.max(0, Math.round((c[k] ?? 0) + delta));
      if (c[k] === 0) delete c[k];
    }
    for (const [k, val] of Object.entries(sets)) {
      if (!Number.isFinite(val)) continue;
      const v = Math.max(0, Math.round(val));
      if (v === 0) delete c[k];
      else c[k] = v;
    }

    await db.player
      .update({
        where: { id: playerId },
        data: {
          missions: JSON.stringify({
            v: VERSION,
            c,
            // Task 183: preserve the granted-prize list across counter writes.
            ...(current.g && current.g.length ? { g: current.g } : {}),
          }),
        },
      })
      .catch(() => {});
  } catch {
    // missions must never break a spin / open / battle
  }
}

/**
 * USER SPEC (Task 183): every mission's prize is ONE FREE RB-106 box. When
 * ALL of a mission's live steps are done and the prize was not granted yet,
 * grant it into the player's freeCases map and stamp the mission id in the
 * state's g list (idempotent — a completed mission pays exactly once).
 * Runs lazily on /api/missions reads (the same pattern as the giveaway
 * auto-draw) so no gameplay path pays the price of the check.
 * Returns the mission ids granted BY THIS CALL (empty = nothing new).
 */
export async function claimMissionPrizes(playerId: string): Promise<string[]> {
  try {
    const state = await getMissionState(playerId);
    const granted = new Set(state.g ?? []);
    const fresh: string[] = [];
    for (const m of MISSIONS) {
      if (granted.has(m.id)) continue;
      const liveSteps = m.steps.filter((s) => s.live);
      if (liveSteps.length === 0) continue; // SOON-only missions never pay
      if (missionDoneCount(m.steps, state.c) < liveSteps.length) continue;
      granted.add(m.id);
      fresh.push(m.id);
    }
    if (!fresh.length) return [];

    // the free boxes ride ONE grant per mission so a hiccup mid-way cannot
    // lose the whole batch — and the g stamp only lands after its grant did
    for (const id of fresh) {
      const ok = await grantFreeCases(playerId, MISSION_PRIZE_CASE_ID, MISSION_PRIZE_QTY);
      if (!ok) return fresh.slice(0, fresh.indexOf(id)); // stop at the failure
    }

    const all = [...granted];
    await db.player
      .update({
        where: { id: playerId },
        data: { missions: JSON.stringify({ v: VERSION, c: state.c, g: all } as MissionState) },
      })
      .catch(() => {});
    return fresh;
  } catch {
    return []; // a prize hiccup must never break the board
  }
}
