// ============ GLOBAL BATTLES — the DB-backed multiplayer engine ============
// SERVER-side module (imported only by /api/gbattles/* route handlers).
// The ORIGINAL battle system (1v1 / 1v1v1 / 1v1v1v1 / 2v2, standard / crazy,
// winner / jackpot / shared pot rules) becomes multiplayer on the DATABASE:
// rooms live in db.battle, anyone in the world sees them in the lobby, takes
// a seat (2v2 lands on the thinner team), can fill the rest with site bots,
// and the fight rolls on the shared clock.
//
// The wire format IS the original `Battle` shape (players, colorOrder, mode,
// potRule, rounds...) so every helper in battles.ts — playerColor, badges,
// takePerPlayer, computeOutcome — keeps working untouched, and the room view
// renders global rooms through the exact original components.
//
// FLOW: create (host seat 0, entry charged) → lobby listing → join (entry
// charged) / bots-fill → AUTO-START when the room is full → the server rolls
// EVERYTHING once (same house rules as the live local room: weighted case
// draws + ROLLDROP replacement per case chance) → clients animate the SAME
// pulls from the shared clock → settle: payout = takePerPlayer (winner
// take-all / 2v2 split / shared equal cut) credited to the DB balances.
//
// ANTI-PEEK: every pull is rolled the moment the room fills and stored in the
// row; each round's pulls go public only when that round begins on the shared
// schedule; totals shown while playing are VISIBLE-pulls-only; the winners /
// pot / per-player take unlock when the room flips to finished.
//
// MONEY: entries leave the DB balance on create/join (atomic balance guard);
// leave refunds while waiting; the settle credits each winner's take and
// records every skin in the ONE live-drop feed + the site-wide counters.

import crypto from "crypto";
import type { Battle as BattleRow } from "@prisma/client";
import type { Player as DbPlayer } from "@prisma/client";
import { db } from "@/lib/db";
import { bumpCounter } from "@/lib/server/auth";
import { publishBalance, recordLedger } from "@/lib/server/ledger";
import { checkSpendAllowed } from "@/lib/server/selfcare";
import { publish } from "@/lib/server/realtime";
import type { BattlePlayer, BattlePotRule, BattlePull, BattleResult, BattleType, BattleMode, RoundSlot } from "@/lib/battles";
import { computeOutcome, dropTotal, makeBot, openSeat, RBBOT_NAMES, takePerPlayer, teamForSeat, MAX_BATTLE_ROUNDS } from "@/lib/battles";
import { CASES, caseItemValue, skinWithWear, type CaseDef } from "@/lib/cases";
import { eventActive } from "@/lib/event";
import { rareCaseOf, rolldropChanceOf } from "@/lib/rolldrop";
import { computePublicHash, pickWeighted, rollFloat } from "@/lib/provably-fair";
import { awardXp } from "@/lib/server/xp";
import { trackMissions } from "@/lib/server/missions";
import { xpForCase } from "@/lib/progress";
import type { GlobalBattle, Seat } from "@/lib/gbattle-shared";
import { maxReelMs, RD_BEAT_MS, RD_HOLD_MS, REVEAL_PAD_MS, ROUND_BEAT_MS } from "@/lib/gbattle-shared";

// ---- small json/parse helpers (every complex column is a JSON string) ----

const jparse = <T,>(s: string | null | undefined, fb: T): T => {
  try {
    return s ? (JSON.parse(s) as T) : fb;
  } catch {
    return fb;
  }
};

const seatsOf = (row: BattleRow): Seat[] => jparse<Seat[]>(row.seats, []);
const roundsOf = (row: BattleRow): string[] => jparse<string[]>(row.rounds, []);
const colorListOf = (row: BattleRow): number[] => jparse<number[]>(row.colorOrder, [0, 1, 2, 3]);

const caseById = (id: string): CaseDef | undefined => CASES.find((c) => c.id === id);

// USER SPEC (battles × COMMUNITY): player-built cases live in the DB — a
// "cc_*" id falls through to the DB lookup, so community cases ride the EXACT
// same engine (rolls, ROLLDROP odds, XP, payouts) as the static catalog.
async function resolveCaseDef(id: string): Promise<CaseDef | undefined> {
  const staticDef = caseById(id);
  if (staticDef) return staticDef;
  if (!id.startsWith("cc_")) return undefined;
  const { findCommunityCase } = await import("@/lib/server/community-cases");
  return findCommunityCase(id);
}

const maxPlayersOf = (type: BattleType): number => (type === "1v1" ? 2 : type === "1v1v1" ? 3 : 4);

// ---- ids / codes ----

const CODE_ALPHA = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no I/L/O/0/1 look-alikes
const newCode = () =>
  "RB-" + Array.from({ length: 4 }, () => CODE_ALPHA[Math.floor(Math.random() * CODE_ALPHA.length)]).join("");

const newBattleRowId = () => crypto.randomBytes(8).toString("hex"); // <hex16>

async function uniqueCode(): Promise<string> {
  for (let i = 0; i < 10; i++) {
    const code = newCode();
    const taken = await db.battle.findUnique({ where: { code } }).catch(() => null);
    if (!taken) return code;
  }
  return "RB-" + Date.now().toString(36).slice(-4).toUpperCase();
}

// ---- seats -> the original BattlePlayer shape (Task 57: avatar flows through) ----

const toBattlePlayer = (s: Seat): BattlePlayer => ({
  id: s.key,
  name: s.name,
  avatar: s.avatar,
  isYou: false, // stamped per-viewer by the client adapter
  isBot: s.isBot,
  team: s.team,
  side: s.side,
  joinedAt: s.joinedAt,
  color: s.color,
  botsVote: s.botsVote ?? false, // USER SPEC (Task 66): the PLAY WITH BOTS vote
});

// ---- the house roll (same rules as the solo opener + local battles) ----
// SERVER PROVABLY FAIR (Task 151): every battle rolls against its OWN
// commit-reveal seed (clientSeed = the public battle code, so anyone can
// re-derive the pulls once the seed is revealed at settle). Pull index g is
// round-major (round r, seat s → g = r*seatCount + s); nonce = 2g is the
// ROLLDROP gate, 2g+1 the weighted item draw — the SAME convention as the
// solo opener.

/** One pull — a ROLLDROP hit REPLACES the skin with a rare-pool draw (rd:true). */
function rollPull(
  caseDef: CaseDef,
  round: number,
  g: number,
  serverSeed: string,
  clientSeed: string
): BattlePull {
  const gateFloat = rollFloat(serverSeed, clientSeed, 2 * g);
  const itemFloat = rollFloat(serverSeed, clientSeed, 2 * g + 1);
  if (gateFloat < rolldropChanceOf(caseDef)) {
    const rare = pickWeighted(rareCaseOf(caseDef).items, itemFloat);
    return { round, skinId: rare.skinId, wear: rare.wear, value: caseItemValue(rare), rd: true };
  }
  const item = pickWeighted(caseDef.items, itemFloat);
  return { round, skinId: item.skinId, wear: item.wear, value: caseItemValue(item) };
}

/** EVERY pull for the whole battle, rolled once at start (anti-peek stored).
 *  Rounds resolve against the static catalog AND the community table. */
async function rollAllPulls(
  rounds: string[],
  seats: Seat[],
  serverSeed: string,
  clientSeed: string
): Promise<BattleResult[]> {
  const results: BattleResult[] = seats.map((s) => ({ playerId: s.key, total: 0, pulls: [] }));
  const defs = await Promise.all(rounds.map((id) => resolveCaseDef(id)));
  rounds.forEach((caseId, ri) => {
    const caseDef = defs[ri];
    if (!caseDef) return;
    results.forEach((res, si) => {
      const pull = rollPull(caseDef, ri, ri * seats.length + si, serverSeed, clientSeed);
      res.pulls.push(pull);
      res.total += pull.value;
    });
  });
  return results;
}

/**
 * The shared clock — USER SPEC (Task 59 CRITICAL FIX): the old math derived the
 * round length from its own 2600/400 constants, which is SHORTER than the
 * other-seat reels the room actually plays (3400ms + 450ms stagger). The round
 * flipped before those reels landed — viewers never saw what the other players
 * got. The schedule is now built from the room view's EXACT reel lengths
 * (maxReelMs). USER SPEC (Task 66 CRITICAL FIX): a reel MOUNTS only when its
 * round's pulls reach the viewer — the publish heartbeat (~700ms grid) plus
 * fetch + render delay that mount, and a late mount was cut mid-air by the
 * flip ("players 3 and 4 almost land and the round continues", worst in FAST
 * where the window is tight). Every round now also carries REVEAL_PAD_MS:
 * a normal round = longest reel + pad + beat; a ROLLDROP round = the FULL
 * client chain (main reel + the 2.0s impact cutscene + bonus reel at reel+1s)
 * + pad + beat (Task 143). Every seat's reel now always lands before the next
 * round opens.
 * USER SPEC (R40): FAST MODE is DELETED — every battle plays the normal
 * case-style pacing (reel + REVEAL_PAD_MS + ROUND_BEAT_MS), so the schedule
 * math below IS the old normal math, byte-for-byte, for every room.
 */
function buildSchedule(rounds: string[], seatCount: number, rdRounds: Set<number>) {
  const maxReel = maxReelMs(seatCount);
  const pad = REVEAL_PAD_MS; // the wait-for-every-participant slack
  const tailBeat = ROUND_BEAT_MS; // the beat stays inside endMs
  const gapBeat = ROUND_BEAT_MS; // the between-rounds breather
  const schedule: RoundSlot[] = [];
  let t = 0;
  rounds.forEach((_, ri) => {
    const startMs = t;
    // the raredrop chain on the client: main reel + marker beat (RD_BEAT_MS,
    // Task 149: the cutscene video is gone) + bonus reel (reel + RD_HOLD)
    const rdChain = 2 * maxReel + RD_BEAT_MS + RD_HOLD_MS;
    const endMs = startMs + (rdRounds.has(ri) ? rdChain : maxReel) + pad + tailBeat;
    schedule.push({ startMs, mainMs: maxReel, endMs });
    t = endMs + gapBeat;
  });
  return { schedule, totalMs: t };
}

// ---- start: roll, schedule, flip to playing ----

async function startBattle(row: BattleRow): Promise<BattleRow> {
  const seats = seatsOf(row);
  const rounds = roundsOf(row);
  const maxPlayers = maxPlayersOf(row.type as BattleType);
  if (row.status !== "waiting" || seats.length < maxPlayers) return row;
  // SERVER PROVABLY FAIR (Task 151): every battle mints its own seed BEFORE
  // the pulls — the hash publishes from the first publicView, the raw seed
  // reveals at settle.
  const fairSeed = row.fairSeed
    ? { seed: row.fairSeed, salt: row.fairSalt ?? "", hash: row.fairHash ?? "" }
    : await (async () => {
        // reuse the shared generator shape: a battle-scoped seed via the
        // player-chain helpers would couple rooms to players — battles mint
        // their own pair with the same math (computePublicHash).
        const seed = crypto.randomBytes(32).toString("hex");
        const salt = crypto.randomBytes(16).toString("hex");
        return { seed, salt, hash: computePublicHash(seed, salt) };
      })();
  const results = await rollAllPulls(rounds, seats, fairSeed.seed, row.code);
  const rdRounds = new Set<number>();
  for (const res of results) for (const pull of res.pulls) if (pull.rd) rdRounds.add(pull.round);
  const { schedule, totalMs } = buildSchedule(rounds, seats.length, rdRounds);

  const started = await db.battle.update({
    where: { id: row.id },
    data: {
      status: "playing",
      startedAt: new Date(),
      schedule: JSON.stringify(schedule),
      pulls: JSON.stringify(results),
      totalMs,
      fairSeed: fairSeed.seed,
      fairSalt: fairSeed.salt,
      fairHash: fairSeed.hash,
    },
  });
  // USER SPEC (Task 32): the site-wide BATTLES-PLAYED counter lives in the DB
  // — incremented exactly once per battle, at the moment it flips to playing.
  await bumpCounter("battlesPlayed", 1).catch(() => {});
  return started;
}

// ---- the settle: outcome, payouts, drops, counters ----

async function settleRow(row: BattleRow): Promise<BattleRow> {
  const fresh = await loadBattle(row.id);
  if (!fresh) return row;
  const seats = seatsOf(fresh);
  const rounds = roundsOf(fresh);
  const results = jparse<BattleResult[]>(fresh.pulls, []);
  const players = seats.map(toBattlePlayer);

  // outcome by the ORIGINAL rules (standard/crazy × winner/jackpot/shared)
  const outcome = computeOutcome(players, results, fresh.mode as BattleMode, fresh.type === "2v2", fresh.potRule as BattlePotRule);
  let winnerIds = outcome.winnerIds;
  if (!winnerIds.length && outcome.tieIds) {
    // headless-style single coin flip among the tied sides — decided ONCE here.
    // SERVER PROVABLY FAIR (Task 151): the flip rides the battle's own seed
    // (nonce 999999 on the public code) when it exists — verifiable exactly
    // like every pull; legacy seedless rows keep the Math.random fallback.
    const tieFloat = fresh.fairSeed
      ? rollFloat(fresh.fairSeed, fresh.code, 999_999)
      : Math.random();
    const pick = outcome.tieIds[Math.floor(tieFloat * outcome.tieIds.length) % outcome.tieIds.length];
    winnerIds =
      pick === "t0" || pick === "t1"
        ? players.filter((p) => p.team === (pick === "t0" ? 0 : 1)).map((p) => p.id)
        : [pick];
  }
  const take = takePerPlayer(
    { teamMode: fresh.type === "2v2", players, potRule: fresh.potRule as BattlePotRule },
    results,
    winnerIds
  );
  const potTotal = dropTotal(results);

  // winners walk to the bank — DB balances only, bots are display-only
  // ANTI-CHEAT (Task 108): every REAL participant earns the battle-pass XP for
  // the rounds they paid for — win or lose, the exact Σ xpForCase(math) the
  // client mirrors at battle start — awarded here, SERVER-side only.
  // Rounds resolve against the static catalog AND the community table.
  const roundDefs = await Promise.all(rounds.map((id) => resolveCaseDef(id)));
  const battleXp = roundDefs.reduce((s, cs) => s + (cs ? xpForCase(cs.price) : 0), 0);
  let coinsPaidDelta = 0;
  // Task 32 (USER SPEC): mission progress lives in the DB — every human seat
  // played THIS battle: entry tiers ($3+ / $10+), battle size (4+ seats),
  // SHARED pot rule and "with bots" all feed the board's counters.
  const anyBot = seats.some((s) => s.isBot);
  const playBumps = (seatCount: number): Record<string, number> => ({
    battles3: fresh.entry >= 3 ? 1 : 0,
    battles10: fresh.entry >= 10 ? 1 : 0,
    battles4: seatCount >= 4 ? 1 : 0,
    battlesBots: anyBot ? 1 : 0,
    battlesShared: fresh.potRule === "shared" ? 1 : 0,
  });
  for (const seat of seats) {
    if (seat.isBot) continue;
    await awardXp(seat.key, battleXp);
    // Task 29 (USER SPEC): per-player CASES OPENED for the leaderboard —
    // every seat plays rounds.length cases; the global Counter bump alone
    // left the leaderboard's rows at 0 forever.
    await db.player
      .update({ where: { id: seat.key }, data: { casesOpened: { increment: rounds.length } } })
      .catch(() => {});
    // Task 76: cent-precise take — round to 2 decimals instead of flooring
    // whole coins (a 0.19-coin pull used to be floored away entirely)
    const amount = Math.max(0, Math.round((take[seat.key] ?? 0) * 100) / 100);
    await trackMissions(seat.key, playBumps(seats.length));
    if (amount > 0) {
      // HARDENING (Task 153): the payout and its ledger row commit as ONE
      // transaction — a crash between them can no longer leave a paid win
      // with no audit row.
      const updated = await db
        .$transaction(async (tx) => {
          const upd = await tx.player
            .update({ where: { id: seat.key }, data: { balance: { increment: amount } } });
          await recordLedger(seat.key, "battle_win", amount, upd.balance, fresh.code, tx);
          return upd;
        })
        .catch(() => null);
      if (updated) {
        coinsPaidDelta += amount;
        publishBalance(seat.key, updated.balance);
      }
    }
  }
  for (const wid of winnerIds) {
    if (wid.startsWith("bot_")) continue;
    await db.player
      .update({ where: { id: wid }, data: { battlesWon: { increment: 1 } } })
      .catch(() => null);
    // Task 32: the WIN side of the board — total wins + wins vs bot seats
    await trackMissions(wid, { battlesWon: 1, botsWon: anyBot ? 1 : 0 });
  }

  // every skin that fell lands in the ONE live feed
  const dropRows: {
    playerId: string | null;
    playerName: string;
    provider: string | null;
    caseId: string;
    caseName: string;
    skinId: string;
    skinName: string;
    value: number;
    isRd: boolean;
    source: string;
    battleId: string;
    wear?: string;
  }[] = [];
  for (const seat of seats) {
    const res = results.find((r) => r.playerId === seat.key);
    if (!res) continue;
    for (const pull of res.pulls) {
      const caseDef = roundDefs[pull.round];
      const skin = skinWithWear(pull.skinId, pull.wear);
      dropRows.push({
        playerId: seat.isBot ? null : seat.key,
        playerName: seat.name,
        provider: seat.isBot ? "bot" : seat.provider ?? null,
        caseId: caseDef?.id ?? "",
        caseName: caseDef?.name ?? "",
        skinId: pull.skinId,
        skinName: skin?.name ?? pull.skinId,
        value: pull.value,
        isRd: !!pull.rd,
        source: "battle",
        battleId: fresh.id,
        ...(pull.wear ? { wear: pull.wear } : {}),
      });
    }
  }
  if (dropRows.length) {
    // per-row create (not createMany) so each push carries the REAL feed id.
    // USER SPEC (Task 67): PRIVATE battles never touch the worldwide feed —
    // what the room opened stays in the room.
    for (const row of dropRows) {
      if (fresh.isPrivate) continue;
      const created = await db.drop.create({ data: row });
      if (created.provider && created.provider !== "bot") {
        publish("drop", {
          id: created.id,
          user: created.playerName,
          provider: created.provider,
          caseId: created.caseId,
          skinId: created.skinId,
          wear: created.wear ?? undefined,
          value: created.value,
          isRd: created.isRd,
          source: created.source,
          at: created.createdAt.getTime(),
        });
      }
    }
  }
  await bumpCounter("casesOpened", rounds.length * seats.length);
  if (coinsPaidDelta > 0) await bumpCounter("coinsPaid", coinsPaidDelta);
  publish("stats", { at: Date.now() });

  return db.battle.update({
    where: { id: fresh.id },
    data: {
      status: "finished",
      winnerIds: JSON.stringify(winnerIds),
      tieIds: outcome.tieIds ? JSON.stringify(outcome.tieIds) : null,
      potTotal,
      take: JSON.stringify(take),
      finishedAt: new Date(),
      // SERVER PROVABLY FAIR (Task 151): the battle's seed goes PUBLIC here —
      // from this moment anyone can re-derive every pull (and the tie flip)
      // from fairSeed + the room code and match them against the payouts.
      fairRevealedAt: fresh.fairSeed ? new Date() : null,
    },
  }).then((row) => {
    // the room flipped — every viewer on the planet gets it NOW (Task 64)
    publish("battle", { id: fresh.id });
    publish("battles", { at: Date.now() });
    return row;
  });
}

/**
 * Flip any room whose shared clock ran out. A "settling" claim guards against
 * two requests settling the same battle twice (double payouts are impossible).
 */
export async function settleIfDue(row: BattleRow): Promise<BattleRow> {
  if (row.status !== "playing" || row.startedAt === null || row.totalMs === null) return row;
  if (Date.now() - row.startedAt.getTime() < row.totalMs) return row;
  const claim = await db.battle
    .updateMany({ where: { id: row.id, status: "playing" }, data: { status: "settling" } })
    .catch(() => ({ count: 0 }));
  if (claim.count === 0) return (await loadBattle(row.id)) ?? row;
  try {
    return await settleRow(row);
  } catch {
    // let a later poll retry the settle — the room stays live meanwhile
    await db.battle
      .updateMany({ where: { id: row.id, status: "settling" }, data: { status: "playing" } })
      .catch(() => null);
    return (await loadBattle(row.id)) ?? row;
  }
}

export async function loadBattle(id: string): Promise<BattleRow | null> {
  try {
    return await db.battle.findUnique({ where: { id } });
  } catch {
    return null;
  }
}

// ---- create / join / bots / leave ----

/** A collision-free key for the next bot seat (humans can leave mid-waiting,
 *  so "bot_<next.length>" alone could double up — Task 67 CHOOSE BOT). */
const nextBotKey = (seats: Seat[]): string => {
  let max = -1;
  for (const s of seats) {
    const m = /^bot_(\d+)$/.exec(s.key);
    if (m) max = Math.max(max, Number(m[1]));
  }
  return `bot_${max + 1}`;
};

export async function createBattle(
  player: DbPlayer,
  opts: { type: BattleType; mode: BattleMode; potRule: BattlePotRule; rounds: string[]; private?: boolean; team?: 0 | 1; bots?: boolean }
): Promise<{ ok: true; id: string; balance: number } | { ok: false; error: string }> {
  // USER SPEC: the free daily LEVEL cases never enter battles (price 0 would
  // let a paid round smuggle free reels — dropped before anything else).
  // USER SPEC (battles × COMMUNITY/EVENT): player-built cc_* cases resolve
  // from the DB and ride the same engine; the EVENT case joins while its
  // window is live and is refused the moment it ends.
  const resolved = await Promise.all(opts.rounds.map((id) => resolveCaseDef(id)));
  const picked: CaseDef[] = [];
  for (let i = 0; i < opts.rounds.length && picked.length < MAX_BATTLE_ROUNDS; i++) {
    const c = resolved[i];
    if (c && c.kind !== "level" && !(c.kind === "event" && !eventActive())) picked.push(c);
  }
  const clean = picked.map((c) => c.id);
  if (clean.length === 0) return { ok: false, error: "Pick at least one case" };
  if (opts.potRule === "shared" && opts.type === "2v2") return { ok: false, error: "SHARED is not playable in 2v2" };

  const teamMode = opts.type === "2v2";
  const entry = picked.reduce((s, c) => s + c.price, 0);
  if (entry <= 0) return { ok: false, error: "Pick at least one case" };

  // USER SPEC (Task 75): SELF CARE — a TAKE A BREAK block or a deposit limit
  // stops the entry BEFORE the charge (server-enforced, not a UI trick).
  const blocked = await checkSpendAllowed(player, entry);
  if (blocked) return { ok: false, error: blocked };

  const colorOrder = [0, 1, 2, 3].sort(() => Math.random() - 0.5);
  // USER SPEC (Task 195): in 2v2 the creator's picked side wins — the host sits
  // LEFT in the chosen team (side 0); unpicked/1v1 keeps the seat-order default.
  const hostTeam: 0 | 1 = teamMode && opts.team !== undefined ? opts.team : teamForSeat(opts.type, 0);
  const hostSeat: Seat = {
    key: player.id,
    name: player.name,
    avatar: player.avatar ?? undefined,
    provider: player.provider,
    team: hostTeam,
    side: teamMode ? 0 : undefined,
    color: colorOrder[0],
    isBot: false,
    paid: entry,
    joinedAt: Date.now(),
  };
  // HARDENING (Task 153): the charge, the room row and the entry ledger commit
  // as ONE transaction — a crash can no longer leave a payer with no room.
  const created = await db
    .$transaction(async (tx) => {
      const charged = await tx.player
        .update({ where: { id: player.id, balance: { gte: entry } }, data: { balance: { decrement: entry } } })
        .catch(() => null);
      if (!charged) return null;
      const row = await tx.battle.create({
        data: {
          id: newBattleRowId(),
          code: await uniqueCode(),
          hostId: player.id,
          type: opts.type,
          mode: opts.mode,
          potRule: opts.potRule,
          isPrivate: opts.private ?? false,
          rounds: JSON.stringify(clean),
          entry,
          status: "waiting",
          colorOrder: JSON.stringify(colorOrder),
          seats: JSON.stringify([hostSeat]),
        },
      });
      await recordLedger(player.id, "battle_entry", -entry, charged.balance, row.code, tx);
      return { charged, row };
    })
    .catch(() => null);
  if (!created) return { ok: false, error: "Not enough funds" };
  publishBalance(player.id, created.charged.balance);
  publish("battles", { at: Date.now() }); // the worldwide lobby just grew
  // USER SPEC (Task 196): PLAY WITH BOTS — the created room fills EVERY empty
  // seat with [RBbot] site bots the moment it opens. Full room → the existing
  // auto-start rolls the fight right here, before the creator even lands in
  // it (the room view mounts the reels from the shared clock — no replay).
  if (opts.bots) {
    await fillWithBotsAndStart(created.row).catch(() => null);
  }
  return { ok: true, id: created.row.id, balance: created.charged.balance };
}

/**
 * HARDENING (Task 153): COMPARE-AND-SET the seats JSON of a WAITING room.
 * The write lands only when the seats string still equals `expected` (and the
 * room is still waiting) — two racing writers can no longer last-writer-win
 * each other (the classic lost-update on a JSON blob column). Returns the
 * updated row on success, null when someone else moved first.
 */
async function casSeats(row: BattleRow, expected: string, next: string): Promise<BattleRow | null> {
  const claimed = await db.battle
    .updateMany({ where: { id: row.id, status: "waiting", seats: expected }, data: { seats: next } })
    .catch(() => null);
  if (!claimed || claimed.count !== 1) return null;
  return { ...row, seats: next };
}

export async function joinBattle(
  row: BattleRow,
  player: DbPlayer
): Promise<{ ok: true; balance: number } | { ok: false; error: string }> {
  if (row.status !== "waiting") return { ok: false, error: "This battle already started" };
  const maxPlayers = maxPlayersOf(row.type as BattleType);

  // USER SPEC (Task 75): SELF CARE — a TAKE A BREAK block or a deposit limit
  // stops the join BEFORE the charge (server-enforced, not a UI trick).
  const blocked = await checkSpendAllowed(player, row.entry);
  if (blocked) return { ok: false, error: blocked };

  // the entry leaves the DB balance first (atomic guard); the SEAT itself is
  // claimed by CAS below — a lost seat race refunds the entry in full.
  const charged = await db.player
    .update({ where: { id: player.id, balance: { gte: row.entry } }, data: { balance: { decrement: row.entry } } })
    .catch(() => null);
  if (!charged) return { ok: false, error: "Not enough funds" };

  const refundEntry = async (error: string, code: string): Promise<{ ok: false; error: string }> => {
    // HARDENING (Task 153): refund + ledger row in ONE transaction
    const back = await db
      .$transaction(async (tx) => {
        const upd = await tx.player
          .update({ where: { id: player.id }, data: { balance: { increment: row.entry } } });
        await recordLedger(player.id, "battle_refund", row.entry, upd.balance, code, tx);
        return upd;
      })
      .catch(() => null);
    if (back) publishBalance(player.id, back.balance);
    return { ok: false, error };
  };

  let current = row;
  for (let attempt = 0; attempt < 6; attempt++) {
    const seats = seatsOf(current);
    if (seats.some((s) => s.key === player.id)) return refundEntry("You are already seated", current.code);
    if (current.status !== "waiting") return refundEntry("This battle already started", current.code);
    if (seats.length >= maxPlayers) return refundEntry("Room is full", current.code);

    const teamMode = row.type === "2v2";
    const open = teamMode ? openSeat(seats.map(toBattlePlayer)) : null;
    const colorOrder = colorListOf(current);
    const seat: Seat = {
      key: player.id,
      name: player.name,
      avatar: player.avatar ?? undefined,
      provider: player.provider,
      team: open ? open.team : teamForSeat(row.type as BattleType, seats.length),
      side: open?.side,
      color: colorOrder[seats.length % colorOrder.length] ?? 0,
      isBot: false,
      paid: row.entry,
      joinedAt: Date.now(),
    };
    const next = [...seats, seat];
    const claimed = await casSeats(current, current.seats, JSON.stringify(next));
    if (claimed) {
      await recordLedger(player.id, "battle_entry", -row.entry, charged.balance, current.code);
      publishBalance(player.id, charged.balance);
      if (next.length >= maxPlayers) {
        const started = await startBattle({ ...current, seats: JSON.stringify(next) }).catch(() => null);
        if (started) void started;
      }
      publish("battle", { id: row.id }); // seated + rolled — push to every viewer
      publish("battles", { at: Date.now() });
      return { ok: true, balance: charged.balance };
    }
    // lost the race — re-read the fresh seats and try again
    current = (await loadBattle(row.id)) ?? current;
  }
  return refundEntry("Room changed too fast — try again", current.code);
}

/** Any seated player fills every empty seat with [RBbot] site bots — the room rolls. */
export async function fillWithBotsAndStart(row: BattleRow): Promise<BattleRow> {
  const maxPlayers = maxPlayersOf(row.type as BattleType);
  // HARDENING (Task 153): the fill is a CAS on the seats JSON — a bot fill can
  // no longer clobber a human join landing at the same instant (the human's
  // paid seat used to be able to vanish under the bots).
  let current = row;
  for (let attempt = 0; attempt < 3; attempt++) {
    const seats = seatsOf(current);
    if (current.status !== "waiting" || seats.length >= maxPlayers) return current;

    const colorOrder = colorListOf(current);
    const taken = seats.map((s) => s.name);
    const next = [...seats];
    const teamMode = row.type === "2v2";
    while (next.length < maxPlayers) {
      const open = teamMode ? openSeat(next.map(toBattlePlayer)) : null;
      const team = open ? open.team : teamForSeat(row.type as BattleType, next.length);
      const side = open?.side;
      const bot = makeBot(taken, team, 0, side);
      taken.push(bot.name);
      next.push({
        key: nextBotKey(next),
        name: bot.name,
        provider: "bot",
        team,
        side,
        color: colorOrder[next.length % colorOrder.length] ?? 0,
        isBot: true,
        paid: 0,
        joinedAt: Date.now(),
      });
    }
    const claimed = await casSeats(current, current.seats, JSON.stringify(next));
    if (claimed) {
      const started = await startBattle(claimed);
      publish("battle", { id: row.id }); // bots called, room rolled — push it
      publish("battles", { at: Date.now() });
      return started;
    }
    current = (await loadBattle(row.id)) ?? current;
  }
  // lost every race — the room moved on without us; nothing of ours changed
  return current;
}

/**
 * USER SPEC (Task 66): pressing CALL BOTS is a VOTE for "PLAY WITH BOTS" —
 * one press NO LONGER fills the room. Bots take the empty seats ONLY when
 * every seated human has voted; a partial vote just lights the voter's
 * "PLAY WITH BOTS" chip for the whole room (live push) and waits. A solo
 * human is trivially unanimous (1/1) and still fills instantly.
 */
export async function castBotsVote(row: BattleRow, playerId: string): Promise<{ filled: boolean; row: BattleRow }> {
  const maxPlayers = maxPlayersOf(row.type as BattleType);
  // HARDENING (Task 153): the vote mark is a CAS on the seats JSON —
  // simultaneous votes can no longer last-writer-win each other's chip away.
  let current = row;
  for (let attempt = 0; attempt < 4; attempt++) {
    const seats = seatsOf(current);
    if (current.status !== "waiting" || seats.length >= maxPlayers) return { filled: false, row: current };
    const me = seats.find((s) => s.key === playerId);
    if (!me || me.isBot || me.botsVote) return { filled: false, row: current };

    const next = seats.map((s) => (s.key === playerId ? { ...s, botsVote: true } : s));
    const claimed = await casSeats(current, current.seats, JSON.stringify(next));
    if (claimed) {
      const humans = next.filter((s) => !s.isBot);
      if (humans.length > 0 && humans.every((s) => s.botsVote)) {
        return { filled: true, row: await fillWithBotsAndStart(claimed) };
      }
      publish("battle", { id: row.id }); // the vote chip goes live for every viewer NOW
      return { filled: false, row: claimed };
    }
    current = (await loadBattle(row.id)) ?? current;
  }
  return { filled: false, row: current };
}

/**
 * USER SPEC (Task 67) — CHOOSE BOT: a seated player summons a SPECIFIC site
 * bot into a specific empty seat (every empty reel carries a CHOOSE BOT
 * button). Unlike CALL BOTS this is a deliberate per-seat pick, so it does
 * NOT need the lobby vote. The room auto-starts the moment the last seat
 * (chosen bot included) fills.
 */
export async function seatChosenBot(
  row: BattleRow,
  playerId: string,
  botName: string,
  wantTeam?: 0 | 1,
  wantSide?: 0 | 1
): Promise<{ ok: true; row: BattleRow } | { ok: false; error: string }> {
  const maxPlayers = maxPlayersOf(row.type as BattleType);
  if (!RBBOT_NAMES.includes(botName)) return { ok: false, error: "Unknown bot" };
  // HARDENING (Task 153): the chosen bot lands via CAS — a concurrent join can
  // no longer be clobbered, and the same bot can no longer be twin-seated by
  // two simultaneous CHOOSE BOT presses.
  let current = row;
  for (let attempt = 0; attempt < 4; attempt++) {
    const seats = seatsOf(current);
    if (current.status !== "waiting") return { ok: false, error: "This battle already started" };
    if (!seats.some((s) => s.key === playerId)) return { ok: false, error: "Only seated players can call bots" };
    if (seats.length >= maxPlayers) return { ok: false, error: "The room is already full" };
    if (seats.some((s) => s.name === botName)) return { ok: false, error: "That bot is already seated" };

    const teamMode = row.type === "2v2";
    const open = teamMode ? openSeat(seats.map(toBattlePlayer)) : null;
    // 2v2: honor the tapped seat when it is free, else fall back to any open seat
    const team: 0 | 1 = teamMode
      ? wantTeam !== undefined && !seats.some((s) => s.team === wantTeam && s.side === (wantSide ?? 0))
        ? wantTeam
        : (open?.team ?? 0)
      : 0;
    const side: 0 | 1 | undefined = teamMode
      ? wantTeam !== undefined && !seats.some((s) => s.team === team && s.side === (wantSide ?? 0))
        ? (wantSide ?? 0)
        : (open?.side ?? 0)
      : undefined;
    const colorOrder = colorListOf(current);
    const next = [
      ...seats,
      {
        key: nextBotKey(seats),
        name: botName,
        provider: "bot",
        team,
        side,
        color: colorOrder[seats.length % colorOrder.length] ?? 0,
        isBot: true,
        paid: 0,
        joinedAt: Date.now(),
      } as Seat,
    ];
    const claimed = await casSeats(current, current.seats, JSON.stringify(next));
    if (claimed) {
      if (next.length >= maxPlayers) {
        const started = await startBattle(claimed).catch(() => null);
        publish("battle", { id: row.id }); // seated + rolled — push to every viewer
        publish("battles", { at: Date.now() });
        return { ok: true, row: started ?? claimed };
      }
      publish("battle", { id: row.id }); // the chosen bot lands live in every seat
      publish("battles", { at: Date.now() });
      return { ok: true, row: claimed };
    }
    current = (await loadBattle(row.id)) ?? current;
  }
  return { ok: false, error: "The room changed too fast — try again" };
}

/**
 * Leave a waiting room — USER SPEC (Task 196): LEAVING NEVER KILLS A ROOM.
 * The host walks out exactly like any other player: their seat opens, their
 * entry refunds, and the room STAYS in the battles list — empty or with the
 * remaining players — so anyone can take the open seats and play it with
 * bots (Call Bots) or other players. The old host-disband is gone.
 */
export async function leaveBattle(
  row: BattleRow,
  player: DbPlayer
): Promise<{ ok: true; refund: number; cancelled: boolean; balance: number } | { ok: false; error: string }> {
  if (row.status !== "waiting") return { ok: false, error: "Too late — the battle already started" };

  const refundHuman = async (seat: Seat): Promise<{ back: number; balanceAfter: number | null }> => {
    if (seat.isBot || seat.paid <= 0) return { back: 0, balanceAfter: null };
    // HARDENING (Task 153): refund + ledger row in ONE transaction
    const updated = await db
      .$transaction(async (tx) => {
        const upd = await tx.player
          .update({ where: { id: seat.key }, data: { balance: { increment: seat.paid } } });
        await recordLedger(seat.key, "battle_refund", seat.paid, upd.balance, row.code, tx);
        return upd;
      })
      .catch(() => null);
    return { back: updated ? seat.paid : 0, balanceAfter: updated?.balance ?? null };
  };

  // USER SPEC (Task 196): the room survives every leave — host or not, the
  // seat removal is a CAS (HARDENING, Task 153): the refund fires ONLY when
  // THIS call's removal actually landed, so a concurrent join/leave can no
  // longer double-pay the same seat.
  let current = row;
  for (let attempt = 0; attempt < 4; attempt++) {
    const seats = seatsOf(current);
    const me = seats.find((s) => s.key === player.id);
    if (!me) return { ok: false, error: "You are not in this room" };
    const next = seats.filter((s) => s.key !== player.id);
    const claimed = await casSeats(current, current.seats, JSON.stringify(next));
    if (claimed) {
      const { back, balanceAfter } = await refundHuman(me);
      publish("battle", { id: row.id });
      publish("battles", { at: Date.now() });
      return { ok: true, refund: back, cancelled: false, balance: balanceAfter ?? player.balance };
    }
    // lost the race — re-read the fresh seats and try again
    current = (await loadBattle(row.id)) ?? current;
    if (current.status !== "waiting") return { ok: false, error: "Too late — the battle already started" };
  }
  return { ok: false, error: "The room changed too fast — try again" };
}

// ---- public projections ----

/** The lobby row — the shared worldwide list EVERYONE sees. */
export function battleSummary(row: BattleRow) {
  const type = row.type as BattleType;
  return {
    id: row.id,
    code: row.code,
    hostId: row.hostId,
    entry: row.entry,
    type,
    mode: row.mode as BattleMode,
    potRule: row.potRule as BattlePotRule,
    isPrivate: row.isPrivate,
    status: row.status,
    maxPlayers: maxPlayersOf(type),
    teamMode: type === "2v2",
    rounds: roundsOf(row),
    colorOrder: colorListOf(row),
    createdAt: row.createdAt.getTime(),
    seats: seatsOf(row),
    serverNow: Date.now(),
  };
}

/**
 * Public room view — the anti-peek projection: pulls gate per round on the
 * shared schedule, totals while playing are visible-pulls-only, the outcome
 * (winners / pot / per-player take) unlocks with the finished status.
 */
export function publicView(row: BattleRow, _viewerId?: string): GlobalBattle {
  const seats = seatsOf(row);
  const rounds = roundsOf(row);
  const type = row.type as BattleType;
  const done = row.status === "finished";
  const cancelled = row.status === "cancelled";
  const live = row.status === "playing" || row.status === "settling";
  const startedMs = row.startedAt ? row.startedAt.getTime() : null;
  const schedule = jparse<RoundSlot[] | null>(row.schedule, null);
  const now = Date.now();
  const elapsed = startedMs ? now - startedMs : 0;

  // USER SPEC (Task 67): PRIVATE battles are invisible to anyone NOT seated —
  // no players, no pulls, no outcome, nothing. The viewer only learns it
  // exists, that it is private, and (while waiting) that a seat can be taken
  // with the code/link. Seated players (and bots' owner nobody) see it all.
  const seatedViewer = _viewerId ? seats.some((s) => s.key === _viewerId) : false;
  if (row.isPrivate && !seatedViewer) {
    return {
      id: row.id,
      code: row.code,
      hostId: row.hostId,
      entry: row.entry,
      type,
      mode: row.mode as BattleMode,
      potRule: row.potRule as BattlePotRule,
      maxPlayers: maxPlayersOf(type),
      teamMode: type === "2v2",
      isPrivate: true,
      redacted: true,
      rounds: [],
      status: cancelled ? "cancelled" : done ? "finished" : live ? "playing" : "waiting",
      createdAt: row.createdAt.getTime(),
      startedAt: null,
      totalMs: null,
      serverNow: now,
      players: [],
      colorOrder: [0, 1, 2, 3],
      schedule: null,
      results: null,
      winnerIds: null,
      tieIds: null,
      potTotal: null,
      take: null,
      fairHash: null,
      fairSeed: null,
      fairSalt: null,
      fairRevealed: false,
    };
  }

  const all = jparse<BattleResult[]>(row.pulls, []);
  const results: BattleResult[] | null =
    (live || done) && all.length
      ? all.map((res) => {
          const visible = done
            ? res.pulls
            : res.pulls.filter((pull) => {
                const slot = schedule?.[pull.round];
                return slot !== undefined && elapsed >= slot.startMs;
              });
          return { playerId: res.playerId, total: visible.reduce((s, p) => s + p.value, 0), pulls: visible };
        })
      : null;

  return {
    id: row.id,
    code: row.code,
    hostId: row.hostId,
    entry: row.entry,
    type,
    mode: row.mode as BattleMode,
    potRule: row.potRule as BattlePotRule,
    maxPlayers: maxPlayersOf(type),
    teamMode: type === "2v2",
    isPrivate: row.isPrivate,
    redacted: false,
    rounds,
    status: cancelled ? "cancelled" : done ? "finished" : live ? "playing" : "waiting",
    createdAt: row.createdAt.getTime(),
    startedAt: startedMs,
    totalMs: row.totalMs,
    serverNow: now,
    players: seats.map(toBattlePlayer),
    colorOrder: colorListOf(row),
    schedule,
    results,
    winnerIds: done ? jparse<string[] | null>(row.winnerIds, null) : null,
    tieIds: done ? jparse<string[] | null>(row.tieIds, null) : null,
    potTotal: done ? row.potTotal : null,
    take: done ? jparse<Record<string, number> | null>(row.take, null) : null,
    // SERVER PROVABLY FAIR (Task 151): the commitment is public from start;
    // the raw seed + salt go out ONLY with the settle stamp (fairRevealedAt).
    fairHash: row.fairHash,
    fairSeed: row.fairRevealedAt ? row.fairSeed : null,
    fairSalt: row.fairRevealedAt ? row.fairSalt : null,
    fairRevealed: !!row.fairRevealedAt,
  };
}
