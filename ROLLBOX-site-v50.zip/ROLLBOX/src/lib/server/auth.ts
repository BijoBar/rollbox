// ============ SERVER session + player helpers ============
// Signed-cookie sessions (HMAC-SHA256). No external auth deps — Steam OpenID
// is implemented directly in the route handlers.
// USER SPEC (Task 64): STEAM OPENID IS THE ONLY SIGN-IN. The cookie holds
// ONLY the player id + expiry (the session token) — never a balance or any
// game data; every sensitive number lives in the DATABASE and every action
// re-verifies it server-side.

import crypto from "crypto";
import fs from "fs";
import path from "path";
import type { NextRequest } from "next/server";
import type { Player as PrismaPlayer } from "@prisma/client";
import { db } from "@/lib/db";
import { publish } from "@/lib/server/realtime";

const COOKIE = "rb_session";
const SESSION_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

let cachedSecret: string | null = null;

/**
 * ANTI-CHEAT (Task 108): the session-signing secret.
 * The old `AUTH_SECRET || "rollbox-dev-secret"` fallback meant ANYONE who
 * knew the public constant could forge a session cookie for ANY player id
 * (the cookie body is just { pid, exp }) and land on their balance. Now:
 *   1. a real AUTH_SECRET env var wins when present (16+ chars),
 *   2. otherwise a strong random secret is generated ONCE and persisted to
 *      db/.auth-secret — sessions survive restarts, and the secret never
 *      appears in the source or the ZIP,
 *   3. if the db dir is unwritable, a random per-process secret is used
 *      (restart logs everyone out — annoying, never forgeable).
 */
function signingSecret(): string {
  if (cachedSecret) return cachedSecret;
  const fromEnv = process.env.AUTH_SECRET;
  if (fromEnv && fromEnv.length >= 16) {
    cachedSecret = fromEnv;
    return cachedSecret;
  }
  try {
    const file = path.join(process.cwd(), "db", ".auth-secret");
    let existing: string | null = null;
    try {
      existing = fs.readFileSync(file, "utf8").trim();
    } catch {
      existing = null; // first boot on this machine — the file just isn't there yet
    }
    if (existing && existing.length >= 32) {
      cachedSecret = existing;
      return cachedSecret;
    }
    const made = crypto.randomBytes(32).toString("hex");
    fs.writeFileSync(file, made, { mode: 0o600 });
    cachedSecret = made;
    return cachedSecret;
  } catch {
    cachedSecret = crypto.randomBytes(32).toString("hex");
    return cachedSecret;
  }
}

const sign = (payload: string) => crypto.createHmac("sha256", signingSecret()).update(payload).digest("base64url");

export const makeSessionToken = (playerId: string): string => {
  const body = Buffer.from(JSON.stringify({ pid: playerId, exp: Date.now() + SESSION_MS })).toString("base64url");
  return `${body}.${sign(body)}`;
};

export const readSessionToken = (token: string | undefined): string | null => {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const good = sign(body);
  if (good.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(good), Buffer.from(sig))) return null;
  try {
    const data = JSON.parse(Buffer.from(body, "base64url").toString()) as { pid: string; exp: number };
    if (!data.pid || data.exp < Date.now()) return null;
    return data.pid;
  } catch {
    return null;
  }
};

export const SESSION_COOKIE = COOKIE;

// SECURITY (Task 167): when the admin enables TOTP, /api/admin/* demands a
// SECOND signed cookie — rb_2fa — minted by a correct 6-digit authenticator
// code and valid 12 hours. A stolen rb_session alone then buys nothing: the
// admin routes flat-404 until the attacker also holds the rotating code.
const TWO_FA_COOKIE = "rb_2fa";
const TWO_FA_MS = 12 * 60 * 60 * 1000; // 12h re-unlock cadence

export const make2faToken = (): string => {
  const body = Buffer.from(JSON.stringify({ t: "2fa", exp: Date.now() + TWO_FA_MS })).toString("base64url");
  return `${body}.${sign(body)}`;
};

export const read2faToken = (token: string | undefined): boolean => {
  if (!token) return false;
  const [body, sig] = token.split(".");
  if (!body || !sig) return false;
  const good = sign(body);
  if (good.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(good), Buffer.from(sig))) return false;
  try {
    const data = JSON.parse(Buffer.from(body, "base64url").toString()) as { t?: string; exp: number };
    return data.t === "2fa" && data.exp > Date.now();
  } catch {
    return false;
  }
};

export const TWO_FA_COOKIE_NAME = TWO_FA_COOKIE;
export const TWO_FA_MAX_AGE = TWO_FA_MS / 1000;

/** The signed-in player for this request (null when signed out).
 *  USER SPEC (Task 22): a PERMANENTLY BANNED player's session is dead on
 *  every route — the cookie stays but the DB row is untouchable. */
export async function sessionPlayer(req: NextRequest): Promise<PrismaPlayer | null> {
  const pid = readSessionToken(req.cookies.get(COOKIE)?.value);
  if (!pid) return null;
  try {
    const player = await db.player.findUnique({ where: { id: pid } });
    if (!player || player.bannedAt) return null; // banned = signed out everywhere
    return player;
  } catch {
    return null;
  }
}

/**
 * USER SPEC (Task 180): the session IDENTITY resolver — a permanently banned
 * player still resolves so /api/auth/me can greet them with the ban shield
 * instead of a fake "Sign-in failed". READ-ONLY presentation use ONLY:
 * every action route keeps sessionPlayer (banned = null = 401), so a banned
 * session can browse the chrome but can never touch a coin, a case or a battle.
 */
export async function sessionPlayerAllowBanned(req: NextRequest): Promise<PrismaPlayer | null> {
  const pid = readSessionToken(req.cookies.get(COOKIE)?.value);
  if (!pid) return null;
  try {
    return await db.player.findUnique({ where: { id: pid } });
  } catch {
    return null;
  }
}

export function sessionCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    maxAge: SESSION_MS / 1000,
    secure: false, // the preview + tunnels terminate TLS upstream; http here
  };
}

/**
 * Site-wide counters — recorded exactly once each.
 * casesOpened / coinsPaid: gameplay totals. members: registered accounts.
 * USER SPEC (Task 32): upgrades — every UPGRADER spin site-wide; battlesPlayed
 * — every battle that actually started (flipped to "playing").
 */
export async function bumpCounter(
  key: "casesOpened" | "coinsPaid" | "members" | "upgrades" | "battlesPlayed",
  by: number,
): Promise<number> {
  const row = await db.counter.upsert({
    where: { key },
    create: { key, value: Math.max(0, by) },
    update: { value: { increment: by } },
  });
  return Math.max(0, row.value);
}

export const newPlayerId = () => "p_" + crypto.randomBytes(8).toString("hex");

// USER SPEC (Task 22): every player gets a personal REFERRAL CODE at signup
// (8 unambiguous chars). Existing players were backfilled by script.
export function makeRefCode(): string {
  const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.randomBytes(8);
  let out = "";
  for (let i = 0; i < 8; i++) out += ALPHABET[bytes[i] % ALPHABET.length];
  return out;
}

/**
 * USER SPEC (Task 183): NO SIGNUP MONEY — a brand-new account lands with a
 * ZERO balance and must DEPOSIT to play (the wallet is one click away).
 * The old $5 first-login bonus is gone.
 */
export async function upsertPlayer(provider: "steam", providerId: string, name: string, avatar: string | null) {
  const existing = await db.player.findUnique({ where: { providerId } });
  if (existing) {
    // C12: the Steam persona is ALWAYS snapshotted into steamName/steamAvatar
    // (the settings page's "Reset to Steam" restores from it), but it only
    // overwrites the live name/avatar when the player has NOT customized
    // them — a nickname set in settings survives every re-login.
    const patch: {
      name?: string;
      avatar?: string;
      steamName?: string;
      steamAvatar?: string;
    } = {};
    if (name && name !== existing.steamName) patch.steamName = name;
    if (avatar !== null && avatar !== existing.steamAvatar) patch.steamAvatar = avatar;
    if (name && !existing.nameCustom && name !== existing.name) patch.name = name;
    if (avatar !== null && !existing.avatarCustom && avatar !== existing.avatar) patch.avatar = avatar;
    if (Object.keys(patch).length) return db.player.update({ where: { id: existing.id }, data: patch });
    return existing;
  }
  // Task 22: the referral code rides the signup create; retry on the rare
  // unique-index collision with an already-issued code.
  let player: PrismaPlayer | null = null;
  for (let i = 0; i < 5 && !player; i++) {
    player = await db.player
      .create({
        data: {
          id: newPlayerId(), provider, providerId, name: (name || "Player").slice(0, 24),
          avatar, balance: 0, refCode: makeRefCode(),
          // C12: the very first login already snapshots the Steam persona.
          steamName: name || null, steamAvatar: avatar,
        },
      })
      .catch(() => null);
  }
  if (!player) throw new Error("player create failed");
  await bumpCounter("members", 1); // a brand-new account joined the site
  publish("stats", { at: Date.now() }); // the USERS counter just moved
  return player;
}
