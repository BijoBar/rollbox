// ============ LIVE STEAM STOCK — the EXCHANGE's only catalog ============
// USER SPEC: the COIN EXCHANGE lists EXACTLY what sits in the site's Steam
// inventories. Task 184: TWO accounts feed the shelf — the original
// https://steamcommunity.com/id/bijobarmain/inventory#730 AND the new
// https://steamcommunity.com/id/BijoBarStg/inventory/#730 — merged into ONE
// catalog. Every asset is its own tile (two "Desert Eagle | Serpent Strike"
// copies, one FN one BS, appear as two items), and each tile shows its wear
// label above the rarity. Everything the client renders is priced HERE, on
// the server, from the same catalog file the whole economy uses — the client
// never decides a price.
//
// USER SPEC (Task 24 — THE 5-MINUTE SYNC): buying a skin must NOT pull it off
// the shelf anymore. The exchange list is a PERSISTENT catalog that only the
// SYNC changes: every 5 minutes the server re-reads BOTH Steam inventories
// and reconciles the catalog with them — skins that joined either inventory
// appear, skins that physically left it (traded out by the owner) are the
// ONLY ones that leave the list. The catalog is persisted to
// db/exchange-stock.json so it survives restarts, sandbox restores and Steam
// outages: a failed sync never removes anything, it just leaves the list
// untouched. TASK 184 atomicity rule: the merge runs ONLY when EVERY account
// read succeeded — a partial Steam outage on one account keeps the whole
// shelf exactly as it was (no false "sold out" flips), the next timer pass
// self-heals.

import fs from "fs";
import path from "path";
import { catalogByName, type CatalogEntry } from "@/lib/server/catalog";
import { unifiedUsd } from "@/lib/server/pricing";
import { pricingRefreshInit } from "@/lib/server/pricing-refresh";
import { entryWearPrice, usdToCoins, type WearId } from "@/lib/wear";

// Task 27: the unified-pricing auto-refresh boots with the exchange engine —
// dormant without a key in db/pricing-config.json, a 6-hour crawl slice with one.
pricingRefreshInit();

/** USER SPEC (Task 184): the shelf's Steam accounts — BOTH inventories merge
 *  into one catalog. Env override accepts a comma-separated list. */
const VANITIES = (
  process.env.STEAM_STOCK_VANITIES ?? process.env.STEAM_STOCK_VANITY ?? "bijobarmain,BijoBarStg"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);
const STEAM_APP = 730;
const CONTEXT = 2;
const FETCH_URL = (id64: string) =>
  `https://steamcommunity.com/inventory/${id64}/${STEAM_APP}/${CONTEXT}?l=english&count=2000`;
const PROFILE_URL = (vanity: string) => `https://steamcommunity.com/id/${vanity}/?xml=1`;
// resolved once per vanity; the literals are the known fallbacks
const FALLBACK_ID64S: Record<string, string> = {
  bijobarmain: "76561199844753068",
  BijoBarStg: "76561199379772748",
};
/** Breathe between account fetches — Steam rate-limits hammering hard. */
const ACCOUNT_GAP_MS = 1_500;

/** USER SPEC: the automatic SYNC cadence — every 5 minutes. */
export const SYNC_INTERVAL_MS = 5 * 60_000;
const FETCH_TIMEOUT_MS = 15_000;
/** Steam aggressively rate-limits the inventory endpoint — after a refusal we
 *  stay quiet this long and keep serving the last synced catalog. */
const COOLDOWN_MS = 30_000;
const COOLDOWN_429_MS = 60_000;

/** The persistent catalog — db/exchange-stock.json (same folder as the site's
 *  DB and auth secret; the site ZIP carries it, so the list survives a full
 *  sandbox restore). available=false rows are HISTORY: an asset that left the
 *  Steam inventory keeps its row but stops being served. */
const STORE_PATH = path.join(process.cwd(), "db", "exchange-stock.json");

/** Steam "Exterior" tag internal_name → site wear id (verified live mapping). */
const WEAR_CATEGORY: Record<string, WearId> = {
  WearCategory0: "FN",
  WearCategory1: "MW",
  WearCategory2: "FT",
  WearCategory3: "WW",
  WearCategory4: "BS",
};

/** Steam Rarity internal_name → the site's six rarity keys. */
const RARITY_MAP: Record<string, string> = {
  Rarity_Contraband_Weapon: "contraband",
  Rarity_Ancient_Weapon: "covert",
  Rarity_Ancient: "covert",
  Rarity_Legendary_Weapon: "classified",
  Rarity_Legendary_Character: "classified",
  Rarity_Legendary: "classified",
  Rarity_Mythical_Weapon: "restricted",
  Rarity_Mythical: "restricted",
  Rarity_Rare_Weapon: "milspec",
  Rarity_Rare: "milspec",
  Rarity_Uncommon_Weapon: "consumer",
  Rarity_Common_Weapon: "consumer",
  Rarity_Common: "consumer",
  Rarity_Default: "consumer",
};

/** Weapon quality items we sell, keyed by their Type tag internal_name. */
const WEAPON_TYPE_RE =
  /^CSGO_Type_(Rifle|Pistol|SniperRifle|SMG|Shotgun|Machinegun|Equipment)$|^CSGO_Type_Knife$|^CSGO_Type_Weapon$/;

/** Non-weapon cosmetics we sell → the catalog `t` marker. Steam's internal
 *  names are quirky: agents are "Type_CustomPlayer", charms are keychains. */
const COSMETIC_TYPE: Record<string, "sticker" | "charm" | "agent" | "patch"> = {
  CSGO_Type_Sticker: "sticker",
  CSGO_Tool_Keychain: "charm", // real charms — keychain junk (Sticker Slab) is dropped by the catalog rule below
  Type_CustomPlayer: "agent",
  CSGO_Type_Agent: "agent",
  CSGO_Type_Patch: "patch",
};

/** Estimated USD price when an item is not in the site catalog at all. */
const RARITY_FALLBACK_USD: Record<string, number> = {
  consumer: 0.5,
  milspec: 3,
  restricted: 10,
  classified: 30,
  covert: 100,
  contraband: 400,
};

/** Market multipliers for qualities the base catalog does not carry. */
const STATTRAK_FACTOR = 1.5;
const SOUVENIR_FACTOR = 2.0;

/** USD → coin price — wear.ts's rate-aware helper (Task 27: ONE conversion
 *  site-wide; the local ×10 copy used to shadow the unified rate). */

export interface StockItem {
  /** "steam:<assetid>" — the id the buy route resolves, client NEVER prices. */
  id: string;
  assetid: string;
  /** Base display name, wear suffix stripped ("AK-47 | Slate"). */
  n: string;
  /** Full display name incl. wear ("AK-47 | Slate (Field-Tested)"). */
  name: string;
  /** Weapon / label line ("AK-47", "StatTrak™ AK-47", "Agent"). */
  w: string;
  /** Site rarity key (drives colors + backdrop). */
  r: string;
  /** Fixed wear of THIS asset (null = the item has no exterior). */
  wear: WearId | null;
  wearLabel: string | null;
  /** USD + coin price resolved server-side; est = factor estimate. */
  p: number;
  v: number;
  est?: 1;
  /** Image (catalog shorthand or "~1"+steam icon_url) — expandImg handles both. */
  img: string | null;
  /** Item type marker (undefined = weapon skin). */
  t?: "sticker" | "charm" | "agent" | "patch";
  /** Category key for the exchange filters. */
  cat?: string;
  /** SVG fallback art kind. */
  a?: string;
  quality: "normal" | "strange" | "tournament";
}

/** One catalog row as persisted in db/exchange-stock.json. */
export interface StoredItem extends StockItem {
  firstSeenAt: number;
  lastSeenAt: number;
  /** false = the sync saw the asset leave the Steam inventory. */
  available: boolean;
}

export interface StockStore {
  /** last sync ATTEMPT (success or failure). */
  syncedAt: number;
  /** last sync that actually produced an inventory snapshot. */
  lastOkAt: number;
  lastError: string | null;
  items: StoredItem[];
}

interface SteamDescription {
  classid: string;
  instanceid: string;
  icon_url?: string;
  market_hash_name?: string;
  marketable?: 0 | 1;
  tradable?: 0 | 1;
  tags?: { category: string; internal_name: string; localized_tag_name: string }[];
}

interface SteamInventoryResponse {
  assets?: { assetid: string; classid: string; instanceid: string }[];
  descriptions?: SteamDescription[];
  total_inventory_count?: number;
  start_assetid?: string;
  success?: 0 | 1;
}

export interface StockSnapshot {
  ok: boolean;
  error?: string;
  rateLimited?: boolean;
  fetchedAt: number;
  items: StockItem[];
}

/** What the exchange API serves: the persisted catalog + sync status. */
export interface StockView {
  ok: boolean;
  error?: string;
  /** last sync attempt (ms epoch) — drives the "synced X ago" label. */
  syncedAt: number;
  /** last SUCCESSFUL sync (ms epoch). */
  lastOkAt: number;
  /** the SYNC cadence, for the UI badge ("AUTO SYNC · 5 MIN"). */
  syncIntervalMs: number;
  items: StockItem[];
}

// ---- module state (one process = one store + one timer + one fetch) ----
let store: StockStore | null = null;
let storeLoaded = false;
let cooldownUntil = 0;
const id64Cache = new Map<string, string>();
let syncInFlight: Promise<StockSnapshot> | null = null;

/** Per-vanity steamID64 resolution (cached once, known fallback per vanity). */
async function resolveId64(vanity: string): Promise<string> {
  const hit = id64Cache.get(vanity);
  if (hit) return hit;
  try {
    const res = await fetch(PROFILE_URL(vanity), { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
    const xml = await res.text();
    const m = xml.match(/<steamID64>(\d{17})<\/steamID64>/);
    if (m) {
      id64Cache.set(vanity, m[1]);
      return m[1];
    }
  } catch {
    /* fall through to the known id */
  }
  const fb = FALLBACK_ID64S[vanity];
  if (fb) {
    id64Cache.set(vanity, fb);
    return fb;
  }
  throw new Error("cannot resolve the Steam account id");
}

/** One Steam inventory fetch. */
async function fetchInventoryPage(id: string): Promise<SteamInventoryResponse> {
  const res = await fetch(FETCH_URL(id), {
    cache: "no-store",
    headers: {
      Accept: "application/json",
      // Steam is friendlier to requests carrying a browser-like UA
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
    },
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
  });
  if (res.status === 429) throw new RateLimitError();
  if (!res.ok) throw new Error(`Steam responded ${res.status}`);
  const data = (await res.json()) as SteamInventoryResponse;
  if (!data || (data.success !== undefined && data.success !== 1 && !data.assets)) {
    throw new Error("Steam inventory unavailable (private or error)");
  }
  return data;
}

class RateLimitError extends Error {
  constructor() {
    super("Steam rate limit hit — retrying soon");
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Steam description → a priced StockItem, or null for things the exchange
 *  does not sell (pins, medals, cases, music kits, slabs). */
function toItem(desc: SteamDescription): StockItem | null {
  const tags = desc.tags ?? [];
  const typeTag = tags.find((t) => t.category === "Type");
  const typeInternal = typeTag?.internal_name ?? "";
  const isWeapon = WEAPON_TYPE_RE.test(typeInternal) || typeInternal.includes("Knife");
  const cosmetic = COSMETIC_TYPE[typeInternal];
  if (!isWeapon && !cosmetic) return null; // containers, pins, music kits, medals…

  const marketHash = desc.market_hash_name ?? "";
  if (!marketHash) return null;
  const marketable = desc.marketable !== 0;

  const qualityTag = tags.find((t) => t.category === "Quality")?.internal_name ?? "normal";
  const quality = qualityTag === "strange" ? "strange" : qualityTag === "tournament" ? "tournament" : "normal";
  const qualityPrefix = quality === "strange" ? "StatTrak™ " : quality === "tournament" ? "Souvenir " : "";

  const wearCat = tags.find((t) => t.category === "Exterior")?.internal_name;
  const wear = (wearCat && WEAR_CATEGORY[wearCat]) || null;
  const wearLabel = wear ? (tags.find((t) => t.category === "Exterior")?.localized_tag_name ?? null) : null;

  // base name for catalog lookup: wear suffix + quality prefix stripped,
  // whitespace collapsed (Steam emits "Michael Syfers  |" double spaces)
  const base = marketHash.replace(/ \((Factory New|Minimal Wear|Field-Tested|Well-Worn|Battle-Scarred)\)$/, "");
  const lookup = base.replace(/^StatTrak™ /, "").replace(/^Souvenir /, "").replace(/\s+/g, " ").trim();

  const entry: CatalogEntry | null = catalogByName(lookup);
  // keychain junk that is not a real priced charm ("Sticker Slab") stays out
  if (!entry && typeInternal === "CSGO_Tool_Keychain") return null;
  // non-marketable collectibles (service medals, pins, event coins) stay out
  // even when a type check slipped them in — they are not exchange stock
  if (!entry && !marketable) return null;
  const rarityTag = tags.find((t) => t.category === "Rarity");
  const r = entry?.r ?? RARITY_MAP[rarityTag?.internal_name ?? ""] ?? "consumer";

  // ---- price (SERVER-authoritative; same math the whole site uses) ----
  // Task 27: the unified table (steamanalyst.com / CSFLOAT real prices) wins
  // FIRST — keyed by the FULL market_hash_name, so StatTrak™ / Souvenir
  // variants price at their TRUE market value instead of the old ×1.5 / ×2
  // factor estimates. Only names the table lacks fall back to the legacy
  // catalog / factor math (flagged est, "~" in the UI).
  const realUsd = unifiedUsd(marketHash);
  let usd: number;
  let est: 1 | undefined;
  if (realUsd != null) {
    usd = realUsd;
  } else if (entry) {
    if (wear) {
      const priced = entryWearPrice(entry, wear);
      usd = priced.usd;
      if (priced.est) est = 1;
    } else {
      usd = entry.p;
    }
  } else {
    usd = RARITY_FALLBACK_USD[r] ?? 1;
    est = 1;
  }
  if (realUsd == null) {
    if (quality === "strange") {
      usd *= STATTRAK_FACTOR;
      est = 1;
    } else if (quality === "tournament") {
      usd *= SOUVENIR_FACTOR;
      est = 1;
    }
  }
  const tMarker = (entry?.t ?? cosmetic) as StockItem["t"];
  return {
    id: "", // filled per-asset by the caller
    assetid: "",
    n: base,
    name: marketHash,
    w:
      qualityPrefix +
      (entry?.w ?? (tags.find((t) => t.category === "Weapon")?.localized_tag_name ?? typeTag?.localized_tag_name ?? "Item")),
    r,
    wear,
    wearLabel,
    p: Math.round(usd * 100) / 100,
    v: usdToCoins(usd),
    ...(est ? { est } : {}),
    img: desc.icon_url ? "~1" + desc.icon_url : entry?.img ?? null,
    ...(tMarker ? { t: tMarker } : {}),
    ...(entry?.cat ? { cat: entry.cat } : {}),
    ...(entry?.a ? { a: entry.a } : {}),
    quality,
  };
}

/** ONE account's full inventory read (with Steam's partial-snapshot retry).
 *  A 429 aborts the pass at once — hammering only deepens the cooldown. */
async function fetchOneInventory(id: string): Promise<StockItem[]> {
  // Steam serves truncated snapshots under load — retry until the asset list
  // reaches the advertised total or no continuation token is left.
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const data = await fetchInventoryPage(id);
      const assets = data.assets ?? [];
      const total = data.total_inventory_count ?? assets.length;
      if (assets.length < total && data.start_assetid && attempt < 2) {
        await sleep(1_500);
        continue;
      }
      const descMap = new Map<string, SteamDescription>();
      for (const d of data.descriptions ?? []) descMap.set(d.classid + "_" + d.instanceid, d);
      const items: StockItem[] = [];
      for (const a of assets) {
        const desc = descMap.get(a.classid + "_" + a.instanceid);
        if (!desc) continue;
        const item = toItem(desc);
        if (!item) continue;
        items.push({ ...item, id: "steam:" + a.assetid, assetid: a.assetid });
      }
      return items;
    } catch (e) {
      if (e instanceof RateLimitError) throw e;
      await sleep(1_000);
    }
  }
  throw new Error("Steam inventory unavailable");
}

/** USER SPEC (Task 184): one sync pass = EVERY account's inventory, merged.
 *  All-or-nothing: if ANY account read fails the whole snapshot fails (the
 *  catalog stays untouched — see the Task-184 header note); when every read
 *  succeeded the item lists concatenate into one shelf. Accounts are fetched
 *  sequentially with a breathing gap — Steam rate-limits parallel hammering. */
async function fetchStock(): Promise<StockSnapshot> {
  const errors: string[] = [];
  let rateLimited = false;
  let items: StockItem[] = [];
  for (let i = 0; i < VANITIES.length; i++) {
    const vanity = VANITIES[i];
    if (i > 0) await sleep(ACCOUNT_GAP_MS);
    try {
      const id = await resolveId64(vanity);
      const one = await fetchOneInventory(id);
      items = items.concat(one);
    } catch (e) {
      if (e instanceof RateLimitError) {
        rateLimited = true;
        errors.push(`${vanity}: Steam is rate limiting us`);
        break; // a 429 poisons the whole pass — further reads would only deepen it
      }
      errors.push(`${vanity}: ${e instanceof Error ? e.message : "Steam fetch failed"}`);
    }
  }
  if (errors.length > 0) {
    return {
      ok: false,
      error: errors.join(" · ") || "Steam inventory unavailable",
      ...(rateLimited ? { rateLimited: true } : {}),
      fetchedAt: Date.now(),
      items: [],
    };
  }
  return { ok: true, fetchedAt: Date.now(), items };
}

// ==================== THE PERSISTENT SYNC ENGINE ====================

function loadStore(): StockStore {
  if (storeLoaded && store) return store;
  storeLoaded = true;
  try {
    const parsed = JSON.parse(fs.readFileSync(STORE_PATH, "utf8")) as StockStore;
    if (parsed && Array.isArray(parsed.items)) {
      store = {
        syncedAt: parsed.syncedAt ?? 0,
        lastOkAt: parsed.lastOkAt ?? 0,
        lastError: parsed.lastError ?? null,
        items: parsed.items,
      };
    }
  } catch {
    /* first boot — no catalog file yet */
  }
  if (!store) store = { syncedAt: 0, lastOkAt: 0, lastError: null, items: [] };
  return store;
}

/** Atomic write (tmp + rename) — a reader never sees a half-written file. */
function saveStore(s: StockStore): void {
  try {
    fs.mkdirSync(path.dirname(STORE_PATH), { recursive: true });
    const tmp = STORE_PATH + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(s));
    fs.renameSync(tmp, STORE_PATH);
  } catch {
    /* best effort — the in-memory copy still serves */
  }
}

/** Merge one successful fetch into the catalog (THE only way the list
 *  changes): assets still in the inventory stay/re-list, assets that left it
 *  flip to available=false (their row is kept, never deleted — a skin that
 *  comes back re-lists with its original firstSeenAt), brand-new assets join
 *  the shelf. Buying never touches this catalog. */
function mergeFetch(items: StockItem[]): StockStore {
  const s = loadStore();
  const now = Date.now();
  const fresh = new Map(items.map((i) => [i.assetid, i]));
  const next: StoredItem[] = [];
  for (const cur of s.items) {
    const live = fresh.get(cur.assetid);
    if (live) {
      next.push({ ...live, firstSeenAt: cur.firstSeenAt, lastSeenAt: now, available: true });
      fresh.delete(cur.assetid);
    } else if (cur.available) {
      next.push({ ...cur, available: false, lastSeenAt: now }); // left the inventory — listed no more
    } else {
      next.push(cur); // already historical — untouched
    }
  }
  for (const live of fresh.values()) {
    next.push({ ...live, firstSeenAt: now, lastSeenAt: now, available: true });
  }
  const merged: StockStore = { syncedAt: now, lastOkAt: now, lastError: null, items: next };
  store = merged;
  saveStore(merged);
  return merged;
}

/** A FAILED sync never removes anything — the catalog stays exactly as it
 *  was; only the bookkeeping (syncedAt/lastError) moves. */
function recordFailure(error: string): StockStore {
  const s = loadStore();
  s.syncedAt = Date.now();
  s.lastError = error;
  saveStore(s);
  return s;
}

/** One sync pass (deduped — concurrent callers share the same promise). */
function runSync(): Promise<StockSnapshot> {
  if (syncInFlight) return syncInFlight;
  syncInFlight = (async (): Promise<StockSnapshot> => {
    if (Date.now() < cooldownUntil) {
      const s = loadStore();
      return {
        ok: false,
        error: s.lastError ?? "sync cooldown",
        rateLimited: true,
        fetchedAt: s.syncedAt,
        items: [],
      };
    }
    const snap = await fetchStock();
    if (snap.ok) {
      cooldownUntil = 0;
      mergeFetch(snap.items);
    } else {
      cooldownUntil = Date.now() + (snap.rateLimited ? COOLDOWN_429_MS : COOLDOWN_MS);
      recordFailure(snap.error ?? "Steam inventory unavailable");
    }
    return snap;
  })().finally(() => {
    syncInFlight = null;
  });
  return syncInFlight;
}

/** The automatic 5-minute SYNC — one timer per process, started on the first
 *  stock access. Every 5 minutes the Steam inventory is re-read and the
 *  persistent catalog is reconciled with it. */
function ensureSyncTimer(): void {
  const g = globalThis as { __rbStockSyncTimer?: ReturnType<typeof setInterval> };
  if (g.__rbStockSyncTimer) return;
  g.__rbStockSyncTimer = setInterval(() => {
    void runSync().catch(() => {});
  }, SYNC_INTERVAL_MS);
  g.__rbStockSyncTimer.unref?.(); // never keep the process alive for the timer
}

/** Task 27: the LIVE price overlay — the unified table (steamanalyst.com /
 *  CSFLOAT real prices) wins over the price snapshotted at sync time, so the
 *  whole shelf follows the real prices THE MOMENT the table updates (the 5-
 *  minute sync governs the LIST, the unified table governs the PRICE). */
function applyUnifiedOverlay(item: StockItem): StockItem {
  const realUsd = unifiedUsd(item.name); // item.name IS the full market_hash_name
  if (realUsd == null) return item;
  return { ...item, p: Math.round(realUsd * 100) / 100, v: usdToCoins(realUsd), est: undefined };
}

/** The exchange's read path: serves the PERSISTENT catalog (instant, immune
 *  to Steam outages). Bootstrapping: a first boot with an empty catalog
 *  awaits one sync so the very first page load has stock; afterwards the
 *  5-minute timer keeps it fresh and stale reads just kick a background
 *  sync without blocking. */
export async function getStock(opts?: { forceSync?: boolean }): Promise<StockView> {
  ensureSyncTimer();
  const s = loadStore();
  const now = Date.now();
  const neverSynced = s.lastOkAt === 0;

  if (opts?.forceSync || neverSynced) {
    const snap = await runSync();
    const after = loadStore();
    if (after.items.length === 0 && !snap.ok) {
      return {
        ok: false,
        error: snap.error ?? after.lastError ?? "Steam inventory unavailable",
        syncedAt: after.syncedAt,
        lastOkAt: after.lastOkAt,
        syncIntervalMs: SYNC_INTERVAL_MS,
        items: [],
      };
    }
  } else if (now - s.lastOkAt > SYNC_INTERVAL_MS) {
    // timer gap (dev restart, sleeping machine) — refresh behind the scenes
    void runSync().catch(() => {});
  }

  const cur = loadStore();
  return {
    ok: true,
    syncedAt: cur.syncedAt,
    lastOkAt: cur.lastOkAt,
    syncIntervalMs: SYNC_INTERVAL_MS,
    items: cur.items
      .filter((i) => i.available)
      .map(({ firstSeenAt: _f, lastSeenAt: _l, available: _a, ...item }) => applyUnifiedOverlay(item)),
  };
}

/** SERVER-side buy resolution: the authoritative stock item for an id, or
 *  null when the sync no longer sees it in the Steam inventory. Bought skins
 *  STAY listed (USER SPEC) — nothing here marks anything sold. */
export async function findStockItem(entryId: string): Promise<StockItem | null> {
  const assetid = entryId.startsWith("steam:") ? entryId.slice(6) : "";
  if (!assetid) return null;
  await getStock(); // makes sure the catalog exists (first boot) + timer runs
  const row = loadStore().items.find((i) => i.assetid === assetid && i.available);
  if (!row) return null;
  const { firstSeenAt: _f, lastSeenAt: _l, available: _a, ...item } = row;
  return applyUnifiedOverlay(item); // the BUY charge = the displayed price
}
