// ============ TERMINAL — server game engine (Task 23, USER SPEC) ============
// Five weapon dealers, each with a MAX deal (50/100/500/1000/5000). A deal is
// paid up-front; the dealer then offers 5 skins drawn from HIS 10-skin table
// (each skin has a % chance) and the player approves EXACTLY ONE of them.
//
// EVERYTHING happens server-side: the charge, the draw, the grant. The client
// only ever names a dealer, an amount and an offer index. The offer set lives
// in an OpenPending row (caseId "terminal:<dealer>") with an atomic claimed
// flag — a double approval is impossible, and the stale-recovery path grants
// the LOWEST offer (abandoning a bad set can never be the smart move).

import crypto from "crypto";
import { db } from "@/lib/db";
import type { Player } from "@prisma/client";
import { recordLedger, publishBalance } from "@/lib/server/ledger";
import { publish, publishTo } from "@/lib/server/realtime";
import { checkSpendAllowed } from "@/lib/server/selfcare";
import { drawWeightedIndex, TERMINALS, type TerminalDef } from "@/lib/terminals";
import { catalogEntry } from "@/lib/server/catalog";
import { trackMissions } from "@/lib/server/missions";

/** The offer as it is parked in the pending row's `drops` JSON — everything
 *  the inventory + drawer need later, baked at draw time (never re-priced).
 *  USER SPEC (Task 29): the FULL catalog snapshot rides along (img / real-USD
 *  ref / category / SVG-fallback art) — inventory items used to arrive with
 *  no picture because only {id,n,w,r,v} was baked. */
export interface TerminalOffer {
  id: string; // catalog skin id (or "custom")
  n: string; // display name
  w: string; // weapon kind (drawer art)
  r: string; // rarity key (drawer colors)
  v: number; // coin value of THIS offer (pool value x amount/max)
  img?: string | null; // Steam CDN render (null/absent -> SVG art fallback)
  p?: number; // real-USD market reference
  cat?: string; // catalog category key
  a?: string; // SVG fallback art kind
  wear?: string; // R43: exterior shown on the offer card (pool skins: default FT)
}

/** One settled terminal deal, as the play route answers. */
export interface TerminalPlayResult {
  playId: string;
  dealerId: string;
  dealerName: string;
  amount: number;
  offers: TerminalOffer[];
}

const newId = (prefix: string) => prefix + crypto.randomBytes(8).toString("hex");

const round2 = (n: number) => Math.round(n * 100) / 100;

/** Build the inventory snapshot fields for a pool skin (catalog-backed).
 *  The snapshot IS the item — same shape the exchange writes (minus the bulk
 *  wear tables): every inventory surface gets name, art, rarity, USD ref AND
 *  the picture, while the coin value stays the OFFERED (scaled) value. */
function offerFromSkin(skin: { id: string | null; n: string; v: number }, value: number): TerminalOffer {
  const entry = skin.id ? catalogEntry(skin.id) : null;
  if (!entry) {
    // custom / unknown skin — the drawer falls back to generic weapon art
    return { id: skin.id ?? "custom", n: skin.n, w: "ak", r: "milspec", v: round2(value) };
  }
  const { wp: _wp, wa: _wa, v: _v, ...base } = entry;
  return { ...base, v: round2(value) };
}

/** Draw 5 DISTINCT offers: weighted pick, remove, renormalise, repeat. */
function drawOffers(dealer: TerminalDef, amount: number): TerminalOffer[] {
  const pool = dealer.skins.map((s) => ({ ...s }));
  const scale = amount / dealer.max; // values are priced at the dealer's MAX
  const out: TerminalOffer[] = [];
  for (let k = 0; k < 5 && pool.length > 0; k++) {
    const idx = drawWeightedIndex(pool);
    const skin = pool.splice(idx, 1)[0];
    out.push(offerFromSkin(skin, skin.v * scale));
  }
  return out;
}

/**
 * Charge a deal and draw the dealer's 5 offers. Throws an {error,status}
 * object-shaped result — routes translate it to a response.
 */
export async function playTerminal(
  player: Player,
  dealerId: string,
  amountRaw: unknown,
): Promise<{ ok: true; result: TerminalPlayResult } | { ok: false; error: string; status: number }> {
  const dealer = TERMINALS.find((d) => d.id === dealerId);
  if (!dealer) return { ok: false, error: "Unknown dealer", status: 400 };

  const amount = round2(Number(amountRaw));
  // Task 24: every dealer carries HIS OWN minimum deal (1/10/30/70/300)
  const min = Number.isFinite(dealer.min) && dealer.min > 0 ? dealer.min : 1;
  if (!Number.isFinite(amount) || amount < min) {
    return { ok: false, error: `${dealer.name}'s minimum deal is ${min}`, status: 400 };
  }
  if (amount > dealer.max) {
    return { ok: false, error: `${dealer.name}'s max deal is ${dealer.max}`, status: 400 };
  }

  // SELF CARE — a break / deposit limit blocks the deal like any other spend
  const blocked = await checkSpendAllowed(player, amount);
  if (blocked) return { ok: false, error: blocked, status: 403 };

  const offers = drawOffers(dealer, amount);
  const playId = newId("t_");
  // HARDENING (Task 153): the charge, the parked offers and the ledger row
  // commit as ONE transaction — a crash can no longer split a paid deal from
  // its audit row.
  const charged = await db
    .$transaction(async (tx) => {
      const upd = await tx.player.update({
        where: { id: player.id, balance: { gte: amount } },
        data: { balance: { decrement: amount } },
      });
      await tx.openPending.create({
        data: {
          id: playId,
          playerId: player.id,
          // amount stays 0 — this pending is SKIN offers; the balance-recovery
          // path skips terminal rows entirely (claimTerminal grants the skin)
          amount: 0,
          caseId: `terminal:${dealer.id}`,
          count: offers.length,
          drops: JSON.stringify(offers),
        },
      });
      await recordLedger(player.id, "terminal_entry", -amount, upd.balance, `${dealer.name} deal`, tx);
      return upd;
    })
    .catch(() => null);
  if (!charged) return { ok: false, error: "Not enough funds", status: 400 };
  // Task 32 (USER SPEC): mission progress lives in the DB — $5+ deals and
  // THE BOSS table feed the Contractor mission's counters.
  await trackMissions(player.id, {
    ...(amount >= 5 ? { term5: 1 } : {}),
    ...(dealer.id === "boss" ? { termBoss: 1 } : {}),
  });
  publishBalance(player.id, charged.balance);
  publish("stats", { at: Date.now() });

  return {
    ok: true,
    result: {
      playId,
      dealerId: dealer.id,
      dealerName: dealer.name,
      amount,
      offers,
    },
  };
}

/**
 * Approve ONE of the 5 offers (USER SPEC: only one). The atomic claimed flip
 * guarantees a single grant even across racing requests / devices.
 */
export async function claimTerminal(
  playerId: string,
  playId: string,
  indexRaw: unknown,
): Promise<
  | { ok: true; item: TerminalOffer & { uid: string } }
  | { ok: false; error: string; status: number }
> {
  const index = Math.floor(Number(indexRaw));
  if (!Number.isFinite(index) || index < 0 || index > 4) {
    return { ok: false, error: "Bad offer index", status: 400 };
  }
  const pending = await db.openPending.findUnique({ where: { id: playId } }).catch(() => null);
  if (!pending || pending.playerId !== playerId) {
    return { ok: false, error: "Deal not found", status: 404 };
  }
  if (!pending.caseId.startsWith("terminal:") || pending.claimed) {
    return { ok: false, error: "This deal is already settled", status: 409 };
  }

  let offers: TerminalOffer[] = [];
  try {
    offers = JSON.parse(pending.drops) as TerminalOffer[];
  } catch {
    offers = [];
  }
  const offer = offers[index];
  if (!offer) return { ok: false, error: "That offer expired", status: 400 };

  // the atomic guard — exactly ONE caller ever flips this deal to claimed
  const won = await db.openPending.updateMany({
    where: { id: pending.id, claimed: false },
    data: { claimed: true },
  });
  if (won.count === 0) return { ok: false, error: "This deal is already settled", status: 409 };

  const uid = newId("i_");
  // the snapshot IS the offer — image, art kind, USD ref and all (Task 29)
  const snapshot: TerminalOffer = { ...offer };
  await db.inventoryItem.create({
    data: {
      id: uid,
      playerId,
      entryId: offer.id,
      data: JSON.stringify(snapshot),
      value: offer.v,
    },
  });
  publishTo(playerId, "inventory", { playerId });
  return { ok: true, item: { uid, ...snapshot } };
}

/**
 * STALE-DEAL RECOVERY — a deal whose tab died before the player approved one
 * offer. Grants the LOWEST offer: walking away from the table must never be
 * the profitable move (approving any offer always beats it), so abandoning
 * can't be gamed. Wired next to the case-open recovery in /api/auth/me.
 */
export async function recoverTerminalPendings(playerId: string): Promise<void> {
  const stale = await db.openPending.findMany({
    where: {
      playerId,
      claimed: false,
      caseId: { startsWith: "terminal:" },
      createdAt: { lt: new Date(Date.now() - 60_000) },
    },
    orderBy: { createdAt: "asc" },
    take: 5,
  });
  for (const pending of stale) {
    let offers: TerminalOffer[] = [];
    try {
      offers = JSON.parse(pending.drops) as TerminalOffer[];
    } catch {
      offers = [];
    }
    if (!offers.length) {
      await db.openPending.updateMany({ where: { id: pending.id, claimed: false }, data: { claimed: true } });
      continue;
    }
    const worst = offers.reduce((a, b) => (b.v < a.v ? b : a));
    const won = await db.openPending.updateMany({
      where: { id: pending.id, claimed: false },
      data: { claimed: true },
    });
    if (won.count === 0) continue;
    const uid = newId("i_");
    await db.inventoryItem.create({
      data: {
        id: uid,
        playerId,
        entryId: worst.id,
        data: JSON.stringify({ ...worst }), // full snapshot incl. img (Task 29)
        value: worst.v,
      },
    });
    publishTo(playerId, "inventory", { playerId });
  }
}
