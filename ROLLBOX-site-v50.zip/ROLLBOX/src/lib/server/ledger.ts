// ============ LEDGER — every money move, recorded on the server (Task 64) ============
// USER SPEC: "all balances, bet history and trades must pass direct server
// verification before every action" — every balance mutation on the site goes
// through a route handler that VALIDATES the move against the DB and writes a
// Ledger row here: the signed delta + the balance AFTER the move + the cause.
// Nothing in this file trusts the client — amounts arrive from server logic.

import { db } from "@/lib/db";
import { publish } from "@/lib/server/realtime";
import type { Prisma } from "@prisma/client";

export type LedgerKind =
  | "signup" // legacy first-login bonus (Task 183 removed it — historical rows only)
  | "daily" // the 24h daily bonus
  | "levelup" // USER SPEC (Task 104): the DB battle pass crossed a level — the level-up coin reward
  | "topup" // USER SPEC (Task 28): the wallet TOPUP — demo money in, balance credited
  | "open_entry" // solo case opening — the charge
  | "open_win" // solo case opening — the skins' value back
  | "trade_buy" // exchange: coins -> skin
  | "trade_sell" // exchange: skin(s) -> coins
  | "battle_entry" // global battle seat (create/join)
  | "battle_refund" // leave/disband refund
  | "battle_win" // settle payout
  // USER SPEC (Task 22): the referral program + the admin panel grants
  | "referral_reward" // the INVITER's one-time 5% of the invitee's first spend
  | "referral_bonus" // the INVITEE's one-time +5% welcome gift from the site
  | "admin_gift" // admin panel: gift
  | "admin_comp" // admin panel: compensation
  | "admin_bonus" // admin panel: bonus
  // USER SPEC (Task 23): the two new games
  | "upgrader_loss" // UPGRADER — the stake the wheel ate
  | "upgrader_win" // UPGRADER — the target credited to the balance
  | "terminal_entry" // TERMINAL — the dealer deal charge
  // C7 PHASE 1: REAL crypto deposits & withdrawals (admin-reviewed)
  | "deposit" // a REAL USDT deposit the admin verified and approved
  | "withdraw_lock" // the coins locked the moment a payout request was created
  | "withdraw_refund" // a rejected payout request — the locked coins returned
  // USER SPEC (EVENTS): the EMERALD DROP wager race — the place prize
  | "event_prize" // the event's final prize credited to a top-5 balance
  // QOL (Task 167): giveaways — the winner's prize credited at draw time
  | "giveaway_win"; // a giveaway winner's prize pot credited to the balance

/**
 * HARDENING (Task 153): the global db client OR the tx of an open
 * $transaction. A ledger row handed a tx commits (or rolls back) TOGETHER
 * with the money move it documents — the audit trail can no longer be split
 * from the move by a crash between the two writes.
 */
export type LedgerClient = Prisma.TransactionClient;

/**
 * Record one money move. `balanceAfter` is the REAL server balance the caller
 * just read back from its own update — never a client number. Failures never
 * break the gameplay action itself (the move already happened).
 *
 * Pass the open $transaction's `tx` as `client` whenever the move itself runs
 * inside one — the row then joins that transaction. Standalone writes (no tx)
 * retry briefly: a transient SQLite lock must never drop the audit row.
 */
export async function recordLedger(
  playerId: string,
  kind: LedgerKind,
  amount: number,
  balanceAfter: number,
  ref?: string,
  client?: LedgerClient
): Promise<void> {
  for (let attempt = 0; ; attempt++) {
    try {
      await (client ?? db).ledger.create({
        data: { playerId, kind, amount, balanceAfter, ref: ref ?? null },
      });
      return;
    } catch {
      // inside a tx the failure surfaces to the transaction itself; standalone
      // writes retry twice before giving up (still best-effort, never throws)
      if (client || attempt >= 2) return;
      await new Promise((r) => setTimeout(r, 50 * (attempt + 1)));
    }
  }
}

/** Push the fresh balance to every device signed into this account. */
export function publishBalance(playerId: string, balance: number): void {
  publish("player", { playerId, balance });
}
