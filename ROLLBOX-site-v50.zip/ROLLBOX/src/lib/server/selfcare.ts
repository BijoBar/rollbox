// ============ SELF CARE — server-enforced player protection (Task 75) ============
// USER SPEC: the player can limit himself to an amount he chooses (deposit
// limit) for 1-3 days, or block the whole site for himself (TAKE A BREAK) for
// 1-3 days. Both live on the PLAYER ROW and are enforced ON THE SERVER — a
// cleared browser, a second device or a fresh cookie changes nothing, and a
// limit can never be removed early (that is the whole point of self-care).
//
// DEPOSIT LIMIT semantics: the site runs on Rollboxcoins and has no real-money
// deposit, so the limit caps the player's NET SPEND — case openings + battle
// entries + exchange buys, minus refunded battle entries — inside the chosen
// window. Every spending route calls checkSpendAllowed() BEFORE it charges.

import { db } from "@/lib/db";
import type { Player } from "@prisma/client";

/** Ledger kinds that count inside a deposit-limit window. battle_refund is a
 *  positive row — including it makes the measure NET (a refunded battle entry
 *  does not burn the limit). */
export const SPEND_KINDS = ["open_entry", "battle_entry", "trade_buy", "battle_refund"] as const;

export const DAY_MS = 24 * 60 * 60 * 1000;

export interface ActiveLimit {
  limit: number; // coins
  days: number; // 1 | 2 | 3
  startedAt: number; // ms epoch
  expiresAt: number; // ms epoch
}

/** The player's still-active deposit limit (null = none / already expired). */
export function activeDepositLimit(
  player: Pick<Player, "depositLimit" | "depositLimitStart" | "depositLimitDays">
): ActiveLimit | null {
  if (!player.depositLimit || !player.depositLimitStart || !player.depositLimitDays) return null;
  const startedAt = player.depositLimitStart.getTime();
  const expiresAt = startedAt + player.depositLimitDays * DAY_MS;
  if (Date.now() >= expiresAt) return null;
  return { limit: player.depositLimit, days: player.depositLimitDays, startedAt, expiresAt };
}

/** True while a TAKE A BREAK self-block is running. */
export function isOnBreak(player: Pick<Player, "breakUntil">): boolean {
  return !!player.breakUntil && player.breakUntil.getTime() > Date.now();
}

/** Net coins spent by this player since `since` (from the SERVER ledger —
 *  the same audit trail that backs every balance move on the site). */
export async function spentSince(playerId: string, since: Date): Promise<number> {
  const agg = await db.ledger.aggregate({
    where: { playerId, kind: { in: SPEND_KINDS as unknown as string[] }, createdAt: { gte: since } },
    _sum: { amount: true },
  });
  return Math.max(0, -(agg._sum.amount ?? 0));
}

/**
 * The gate EVERY spending route passes through before charging.
 * Returns null when the move is allowed, or the rejection message the client
 * sees (HTTP 403).
 */
export async function checkSpendAllowed(player: Player, cost: number): Promise<string | null> {
  if (isOnBreak(player)) {
    return (
      "You are on a TAKE A BREAK self-block until " +
      formatUntil(player.breakUntil as Date) +
      ". The site unlocks itself automatically when the break ends."
    );
  }
  const lim = activeDepositLimit(player);
  if (lim) {
    const spent = await spentSince(player.id, new Date(lim.startedAt));
    if (spent + cost > lim.limit) {
      const remaining = Math.max(0, lim.limit - spent);
      return (
        `Your ${lim.days}-day deposit limit blocks this move — $${remaining} left ` +
        `of your ${lim.limit} limit. The window ends ` +
        formatUntil(new Date(lim.expiresAt)) +
        "."
      );
    }
  }
  return null;
}

/** Compact English timestamp used inside server messages. */
export function formatUntil(d: Date): string {
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

/** The self-care half of GET /api/settings — everything the UI needs. */
export async function selfcareSnapshot(player: Player): Promise<{
  deposit: (ActiveLimit & { spent: number }) | null;
  breakUntil: string | null;
  onBreak: boolean;
}> {
  const lim = activeDepositLimit(player);
  const deposit = lim ? { ...lim, spent: await spentSince(player.id, new Date(lim.startedAt)) } : null;
  return {
    deposit,
    breakUntil: player.breakUntil && player.breakUntil.getTime() > Date.now() ? player.breakUntil.toISOString() : null,
    onBreak: isOnBreak(player),
  };
}
