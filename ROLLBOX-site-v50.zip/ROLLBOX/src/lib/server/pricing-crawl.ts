// ============ PRICING CRAWL (Task 27) — steamanalyst.com → unified table ============
// USER SPEC: every skin gets its REAL price from www.steamanalyst.com (the
// CSFLOAT feed that site compares), scope WEAPONS + AGENTS. The engine fills
// db/steamanalyst-prices.json (market_hash_name → USD) through the official
// API (api.steamanalyst.com/v1/prices — the FREE tier's endpoint; higher
// tiers remove the caps, the logic is identical).
//
// QUEUE PRIORITY (what gets priced first while the free budget is 100/24h):
//   1. the LIVE exchange shelf (db/exchange-stock.json names) — the tiles the
//      user actually sees, Souvenir/StatTrak names included,
//   2. every CASE + TERMINAL skin × the wears the skin actually comes in,
//   3. StatTrak™ / Souvenir variants of (2),
//   4. the whole catalog's weapons + agents × wears,
//   5. StatTrak™ / Souvenir variants of (4).
// Wear availability comes from the site's own data (SKIN_WEAR_AVAIL + catalog
// wa) — skins that only exist MW→FN are only ASKED MW→FN (USER SPEC: not
// every skin spans BS..FN).
//
// Everything is restart-proof: attempts + the rolling 24h request log persist
// to db/pricing-crawl-state.json after every 10 fetches, so a killed run
// resumes where it stopped without burning the daily budget twice.

import fs from "fs";
import path from "path";
import { WEAR_IDS, WEAR_BY_ID, type WearId } from "@/lib/wear";
import { SKINS } from "@/lib/cases";
import { SKIN_WEAR_AVAIL } from "@/lib/generated-wear-prices";
import { TERMINALS } from "@/lib/terminals";
import { PRICES_PATH, loadUnifiedTable, type UnifiedTable } from "@/lib/server/pricing";

const CONFIG_PATH = path.join(process.cwd(), "db", "pricing-config.json");
const STATE_PATH = path.join(process.cwd(), "db", "pricing-crawl-state.json");
const STOCK_PATH = path.join(process.cwd(), "db", "exchange-stock.json");
const SKINS_DB_PATH = path.join(process.cwd(), "scripts", "skins-db.json");

const API_BASE = "https://api.steamanalyst.com/v1/prices";
const FETCH_TIMEOUT_MS = 20_000;

/** freshness windows (ms) */
const PRICE_TTL = 7 * 24 * 60 * 60 * 1000; // a fetched price suppresses re-asking for 7 days
const FAIL_TTL = 3 * 24 * 60 * 60 * 1000; // a failed name is retried after 3 days

export type PricingTier = "free" | "basic" | "enterprise";

export interface PricingConfig {
  apiKey: string | null;
  tier: PricingTier;
  autoRefresh: boolean;
  dailyBudget: number;
}

export function loadPricingConfig(): PricingConfig {
  let cfg: Partial<PricingConfig> = {};
  try {
    cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8")) as Partial<PricingConfig>;
  } catch {
    /* defaults below */
  }
  return {
    apiKey: process.env.STEAMANALYST_API_KEY ?? (typeof cfg.apiKey === "string" && cfg.apiKey ? cfg.apiKey : null),
    tier: (cfg.tier === "basic" || cfg.tier === "enterprise" ? cfg.tier : "free") as PricingTier,
    autoRefresh: cfg.autoRefresh !== false,
    dailyBudget: Number.isFinite(cfg.dailyBudget) && (cfg.dailyBudget ?? 0) > 0 ? Number(cfg.dailyBudget) : 100,
  };
}

// ---------------- state (attempts + rolling request log) ----------------

interface AttemptRec {
  ts: number;
  ok: boolean;
}

interface CrawlState {
  attempts: Record<string, AttemptRec>;
  /** epoch ms of every request inside the last 24h — the rolling budget. */
  requests: number[];
}

let stateCache: CrawlState | null = null;

function loadState(): CrawlState {
  if (stateCache) return stateCache;
  try {
    const parsed = JSON.parse(fs.readFileSync(STATE_PATH, "utf8")) as CrawlState;
    if (parsed && parsed.attempts && Array.isArray(parsed.requests)) {
      stateCache = parsed;
      return stateCache;
    }
  } catch {
    /* first run */
  }
  stateCache = { attempts: {}, requests: [] };
  return stateCache;
}

function saveState(): void {
  if (!stateCache) return;
  try {
    const tmp = STATE_PATH + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(stateCache));
    fs.renameSync(tmp, STATE_PATH);
  } catch {
    /* best effort */
  }
}

function atomicWriteTable(table: UnifiedTable): void {
  try {
    const tmp = PRICES_PATH + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(table));
    fs.renameSync(tmp, PRICES_PATH);
  } catch {
    /* best effort */
  }
}

// ---------------- queue construction ----------------

const WEAPON_CATS = new Set(["rifles", "pistols", "smgs", "heavy", "knives", "gloves", "zeus"]);

/** catalog entries (id/n/wa/wp/cat/t) — read straight from the file the site
 *  serves (fs, not the server module — the CLI runs outside Next too). */
interface RawEntry {
  id: string;
  n: string;
  cat?: string;
  t?: string;
  wp?: Record<string, number>;
  wa?: string[];
}

function readCatalogEntries(): RawEntry[] {
  const candidates = [
    path.join(process.cwd(), "public", "skins-catalog.json"),
    path.join(process.cwd(), "..", "public", "skins-catalog.json"),
  ];
  for (const file of candidates) {
    try {
      if (!fs.existsSync(file)) continue;
      return JSON.parse(fs.readFileSync(file, "utf8")) as RawEntry[];
    } catch {
      /* next candidate */
    }
  }
  return [];
}

/** skins-db quality flags by display name (stattrak / souvenir availability). */
interface QualityFlags {
  stattrak: boolean;
  souvenir: boolean;
}

function readQualityFlags(): Map<string, QualityFlags> {
  const map = new Map<string, QualityFlags>();
  try {
    if (!fs.existsSync(SKINS_DB_PATH)) return map;
    const db = JSON.parse(fs.readFileSync(SKINS_DB_PATH, "utf8")) as {
      name?: string;
      stattrak?: boolean;
      souvenir?: boolean;
    }[];
    for (const s of db) {
      if (!s?.name) continue;
      map.set(s.name.replace(/\s+/g, " ").trim(), {
        stattrak: s.stattrak === true,
        souvenir: s.souvenir === true,
      });
    }
  } catch {
    /* the flags layer just stays empty */
  }
  return map;
}

/** case + terminal skin names (the user's own overlay included). */
function readCaseTerminalNames(): { name: string; wears: WearId[] }[] {
  const out: { name: string; wears: WearId[] }[] = [];
  const seen = new Set<string>();
  for (const s of Object.values(SKINS ?? {})) {
    if (!s?.name || seen.has(s.name)) continue;
    seen.add(s.name);
    const avail = SKIN_WEAR_AVAIL?.[s.id];
    out.push({ name: s.name, wears: Array.isArray(avail) ? [...avail] : [...WEAR_IDS] });
  }
  return out;
}

/** terminal display names (priced at their FT face — one number per dealer row). */
function readTerminalNames(): string[] {
  const out: string[] = [];
  for (const t of TERMINALS ?? []) {
    for (const s of t.skins ?? []) if (s.n) out.push(s.n);
  }
  return out;
}

const wearSuffix = (w: WearId): string => ` (${WEAR_BY_ID[w].label})`;
const STATTRAK_PREFIX = "StatTrak™ ";
const SOUVENIR_PREFIX = "Souvenir ";

/** The full crawl queue, deduped, priority-ordered, freshness-filtered. */
export function buildQueue(now = Date.now()): string[] {
  const table = loadUnifiedTable();
  const state = loadState();
  const seen = new Set<string>();
  const queue: string[] = [];
  const push = (name: string) => {
    const key = name.replace(/\s+/g, " ").trim();
    if (!key || seen.has(key)) return;
    seen.add(key);
    const hit = table.prices[key];
    if (hit && hit.usd > 0 && now - (hit.ts ?? 0) < PRICE_TTL) return; // fresh already
    const att = state.attempts[key];
    if (att && !att.ok && now - att.ts < FAIL_TTL) return; // recently failed
    if (att && att.ok && (!hit || hit.usd <= 0) && now - att.ts < FAIL_TTL) return;
    queue.push(key);
  };

  // 1. the live exchange shelf — full names, quality included
  try {
    const stock = JSON.parse(fs.readFileSync(STOCK_PATH, "utf8")) as {
      items?: { name?: string; available?: boolean }[];
    };
    for (const it of stock.items ?? []) {
      if (it?.available !== false && it.name) push(it.name);
    }
  } catch {
    /* no stock file yet */
  }

  // 2. case + terminal skins × their real wears
  for (const s of readCaseTerminalNames()) {
    const wears = s.wears.length ? s.wears : [];
    if (!wears.length) push(s.name); // vanilla knife: bare market name
    for (const w of wears) push(s.name + wearSuffix(w));
  }
  for (const n of readTerminalNames()) push(n + wearSuffix("FT"));

  // 3. StatTrak™ / Souvenir variants of the case layer
  const flags = readQualityFlags();
  for (const s of readCaseTerminalNames()) {
    const f = flags.get(s.name);
    if (!f) continue;
    const wears = s.wears.length ? s.wears : [];
    if (f.stattrak) {
      if (!wears.length) push(STATTRAK_PREFIX + s.name);
      for (const w of wears) push(STATTRAK_PREFIX + s.name + wearSuffix(w));
    }
    if (f.souvenir) {
      if (!wears.length) push(SOUVENIR_PREFIX + s.name);
      for (const w of wears) push(SOUVENIR_PREFIX + s.name + wearSuffix(w));
    }
  }

  // 4. the catalog's weapons + agents × wears (USER SCOPE: weapons + agents)
  const catalog = readCatalogEntries();
  const catQueue: { name: string; wears: WearId[] }[] = [];
  for (const e of catalog) {
    const isWeapon = e.cat ? WEAPON_CATS.has(e.cat) : false;
    const isAgent = e.t === "agent" || e.cat === "agents";
    if (!isWeapon && !isAgent) continue;
    const wears: WearId[] = e.wp
      ? e.wa && e.wa.length
        ? (e.wa.filter(isWearId) as WearId[])
        : [...WEAR_IDS]
      : [];
    catQueue.push({ name: e.n, wears });
  }
  for (const s of catQueue) {
    if (!s.wears.length) push(s.name);
    for (const w of s.wears) push(s.name + wearSuffix(w));
  }

  // 5. quality variants of the catalog layer
  for (const s of catQueue) {
    const f = flags.get(s.name);
    if (!f) continue;
    if (f.stattrak) {
      if (!s.wears.length) push(STATTRAK_PREFIX + s.name);
      for (const w of s.wears) push(STATTRAK_PREFIX + s.name + wearSuffix(w));
    }
    if (f.souvenir) {
      if (!s.wears.length) push(SOUVENIR_PREFIX + s.name);
      for (const w of s.wears) push(SOUVENIR_PREFIX + s.name + wearSuffix(w));
    }
  }

  return queue;
}

const isWearId = (v: string): v is WearId => (WEAR_IDS as string[]).includes(v);

// ---------------- the API call ----------------

interface ApiPriceResponse {
  success?: boolean;
  data?: { market_name?: string; price?: number };
  error?: { code?: string; message?: string };
}

export interface FetchResult {
  ok: boolean;
  usd?: number;
  error?: string;
  /** 403 INSUFFICIENT_TIER — the key cannot serve this endpoint at all. */
  insufficientTier?: boolean;
  rateLimited?: boolean;
}

export async function fetchSteamanalystPrice(apiKey: string, marketName: string): Promise<FetchResult> {
  try {
    const res = await fetch(API_BASE + "?market_name=" + encodeURIComponent(marketName), {
      headers: { Authorization: "Bearer " + apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    });
    if (res.status === 429) return { ok: false, rateLimited: true, error: "rate limited" };
    if (res.status === 403) {
      const body = (await res.json().catch(() => ({}))) as ApiPriceResponse;
      return {
        ok: false,
        insufficientTier: body?.error?.code === "INSUFFICIENT_TIER",
        error: body?.error?.code ?? "forbidden",
      };
    }
    if (!res.ok) return { ok: false, error: "HTTP " + res.status };
    const body = (await res.json()) as ApiPriceResponse;
    if (body?.success && typeof body.data?.price === "number" && body.data.price > 0) {
      return { ok: true, usd: body.data.price };
    }
    return { ok: false, error: body?.error?.code ?? body?.error?.message ?? "no price in response" };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "fetch failed" };
  }
}

// ---------------- the slice ----------------

export interface CrawlSummary {
  skipped?: "no-key" | "budget-spent" | "queue-empty";
  ran: number;
  priced: number;
  failed: number;
  budgetLeft: number;
  queueLeft: number;
  error?: string;
  samplePriced?: string[];
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** pacing per tier (ms between calls — under each tier's per-minute limit) */
function paceMs(tier: PricingTier): number {
  if (tier === "free") return 2_100; // 30/min
  if (tier === "basic") return 550; // 120/min
  return 250; // enterprise 300/min
}

const SLICE_MAX_REQUESTS = 2_000; // one slice never runs forever — the next tick resumes

/**
 * One crawl pass: price as many queued names as the rolling 24h budget
 * allows, persisting progress continuously. Called by the CLI runner and by
 * the server's auto-refresh timer.
 */
export async function crawlSlice(opts?: { maxRequests?: number }): Promise<CrawlSummary> {
  const cfg = loadPricingConfig();
  if (!cfg.apiKey) return { skipped: "no-key", ran: 0, priced: 0, failed: 0, budgetLeft: 0, queueLeft: 0 };

  const now = Date.now();
  const state = loadState();
  state.requests = state.requests.filter((ts) => now - ts < 24 * 60 * 60 * 1000);

  const budget = cfg.tier === "free" ? cfg.dailyBudget : Number.POSITIVE_INFINITY;
  const used = state.requests.length;
  let budgetLeft = Math.max(0, budget - used);
  if (budgetLeft <= 0) {
    return {
      skipped: "budget-spent",
      ran: 0,
      priced: 0,
      failed: 0,
      budgetLeft: 0,
      queueLeft: buildQueue(now).length,
    };
  }

  const queue = buildQueue(now);
  const cap = Math.min(budgetLeft, opts?.maxRequests ?? SLICE_MAX_REQUESTS);
  const names = queue.slice(0, cap);
  if (!names.length) {
    return { skipped: "queue-empty", ran: 0, priced: 0, failed: 0, budgetLeft, queueLeft: 0 };
  }

  const table = loadUnifiedTable();
  let priced = 0;
  let failed = 0;
  const samplePriced: string[] = [];
  let error: string | undefined;

  for (let i = 0; i < names.length; i++) {
    const name = names[i];
    state.requests.push(Date.now());
    const res = await fetchSteamanalystPrice(cfg.apiKey as string, name);
    state.attempts[name] = { ts: Date.now(), ok: res.ok };

    if (res.ok && typeof res.usd === "number") {
      table.prices[name] = { usd: res.usd, ts: Date.now(), src: "steamanalyst" };
      table.updatedAt = Date.now();
      priced++;
      if (samplePriced.length < 8) samplePriced.push(name + " = $" + res.usd);
    } else {
      failed++;
      if (res.insufficientTier) {
        error = "The key cannot serve /v1/prices (INSUFFICIENT_TIER) — check the key on steamanalyst.com";
        saveState();
        atomicWriteTable(table);
        break;
      }
      if (res.rateLimited) {
        error = "API rate limit hit — slice stopped, the next run resumes";
        saveState();
        atomicWriteTable(table);
        break;
      }
      if (!error) error = res.error ?? "unknown error"; // remember the first failure reason
    }

    // persist every 10 fetches — a killed slice resumes cleanly
    if ((i + 1) % 10 === 0) {
      state.requests = state.requests.filter((ts) => Date.now() - ts < 24 * 60 * 60 * 1000);
      saveState();
      atomicWriteTable(table);
    }
    if (i < names.length - 1) await sleep(paceMs(cfg.tier));
  }

  state.requests = state.requests.filter((ts) => Date.now() - ts < 24 * 60 * 60 * 1000);
  saveState();
  atomicWriteTable(table);

  return {
    ran: names.length,
    priced,
    failed,
    budgetLeft: Math.max(0, (cfg.tier === "free" ? cfg.dailyBudget : Number.POSITIVE_INFINITY) - state.requests.length),
    queueLeft: buildQueue().length,
    ...(error ? { error } : {}),
    ...(samplePriced.length ? { samplePriced } : {}),
  };
}
