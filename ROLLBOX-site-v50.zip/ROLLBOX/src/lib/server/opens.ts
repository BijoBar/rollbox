// ============ SERVER pending-open claim helpers (Task 78) ============
// USER SPEC: the solo-open WIN must land on the player's balance ONLY when
// the reel reveal finishes — never at the click. POST /api/open decides the
// roll, charges the price and parks the win in an OpenPending row; the
// client claims it the moment the skin is on screen (and the bonus ROLLDROP
// spin, when one hits, has locked too). Every claim is atomic (claimed flag),
// ownership-checked, and a stale-pending recovery credits rounds whose tab
// died mid-spin on the player's next load — a win can never be lost.

import { db } from "@/lib/db";
import { bumpCounter } from "@/lib/server/auth";
import { publishBalance, recordLedger } from "@/lib/server/ledger";
import { publish } from "@/lib/server/realtime";
import type { Drop } from "@prisma/client";

/** A pending older than this is "abandoned" (the longest spin is ~12s) and is
 *  auto-claimed by the recovery path — GET /api/auth/me — so a player who
 *  closed the tab mid-spin finds the win on the balance next load. */
export const PENDING_STALE_MS = 60_000;

/** The exact Drop-row shape /api/open parks in the pending's `drops` JSON. */
type PendingDrop = {
  playerId: string; playerName: string; provider: string; caseId: string; caseName: string;
  skinId: string; skinName: string; value: number; isRd: boolean; source: string; wear?: string;
};

export type ClaimResult = { claimedAmount: number; claimedRounds: number; balance: number };

/**
 * Claim pending solo-open wins for a player. Explicit claim (pendingId given):
 * claims that round regardless of age — this is the reel-finished call.
 * Recovery mode (no pendingId): claims only ABANDONED rounds (older than
 * PENDING_STALE_MS) so a live animation is never raced from another request.
 * Each round flips its claimed flag atomically — double claims are impossible.
 */
export async function claimOpenPendings(
  playerId: string,
  opts: { pendingId?: string; staleOnly?: boolean } = {}
): Promise<ClaimResult | null> {
  const pendings = await db.openPending.findMany({
    where: {
      playerId,
      claimed: false,
      // USER SPEC (Task 23): TERMINAL pendings are skin offers, not balance
      // credits — the balance-recovery path here must never touch them (the
      // terminal has its own recovery, granting an inventory skin instead).
      ...(opts.staleOnly ? { caseId: { not: { startsWith: "terminal:" } } } : {}),
      ...(opts.pendingId
        ? { id: opts.pendingId }
        : { createdAt: { lt: new Date(Date.now() - PENDING_STALE_MS) } }),
    },
    orderBy: { createdAt: "asc" },
  });
  if (pendings.length === 0) return null;

  let claimedAmount = 0;
  let claimedRounds = 0;
  let balance = (
    await db.player.findUniqueOrThrow({ where: { id: playerId }, select: { balance: true } })
  ).balance;

  for (const pending of pendings) {
    // parse the drops BEFORE the tx — pure JSON work, no db inside
    let drops: PendingDrop[] = [];
    try {
      drops = JSON.parse(pending.drops) as PendingDrop[];
    } catch {
      drops = [];
    }

    // HARDENING (Task 153): flip + drops + credit + ledger commit as ONE
    // transaction — the atomic claimed-flag guard still makes double claims
    // impossible, and the credit can no longer land without its ledger row.
    const credited = await db
      .$transaction(async (tx) => {
        // the atomic guard — only ONE caller ever flips a pending to claimed
        const won = await tx.openPending.updateMany({
          where: { id: pending.id, claimed: false },
          data: { claimed: true },
        });
        if (won.count === 0) return null;
        const created: Drop[] = [];
        for (const row of drops) {
          created.push(await tx.drop.create({ data: row }));
        }
        const winner = await tx.player.update({
          where: { id: playerId },
          data: { balance: { increment: pending.amount } },
        });
        await recordLedger(playerId, "open_win", pending.amount, winner.balance, pending.caseId, tx);
        return { balance: winner.balance, created };
      })
      .catch(() => null);
    if (!credited) continue;

    balance = credited.balance;
    claimedAmount += pending.amount;
    claimedRounds++;
    // the round's drops become public only NOW — same beat the player sees
    // them; publishing AFTER the commit pushes the REAL feed ids
    for (const d of credited.created) {
      publish("drop", {
        id: d.id,
        user: d.playerName,
        provider: d.provider,
        caseId: d.caseId,
        skinId: d.skinId,
        wear: d.wear ?? undefined,
        value: d.value,
        isRd: d.isRd,
        source: d.source,
        at: d.createdAt.getTime(),
      });
    }
  }

  if (claimedAmount > 0) {
    publishBalance(playerId, balance);
    await bumpCounter("coinsPaid", claimedAmount);
    publish("stats", { at: Date.now() });
  }
  return { claimedAmount, claimedRounds, balance };
}
