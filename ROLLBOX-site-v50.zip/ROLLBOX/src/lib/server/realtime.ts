// ============ REALTIME HUB — the multiplayer push channel (Task 64) ============
// USER SPEC: "every connected player sees the same data at the same time" —
// the server is the single source of truth and PUSHES every state change to
// all connected clients over a persistent server-sent-events stream
// (/api/realtime/stream). This module is the in-process hub: routes publish,
// every open stream receives. Pure pub/sub — no DB imports here (the settle
// ticker lives in realtime-ticker.ts to keep the import graph acyclic).

export interface RtEvent {
  type: string;
  data: unknown;
}

export interface RtClient {
  id: number;
  playerId: string | null; // signed-in player this stream belongs to (cookie)
  send: (type: string, data: unknown) => void;
}

interface Hub {
  seq: number;
  clients: Map<number, RtClient>;
}

// module state survives dev hot edits via globalThis (same process, one hub)
const G = globalThis as typeof globalThis & { __rbRealtimeHub?: Hub };

const hub = (): Hub => {
  if (!G.__rbRealtimeHub) G.__rbRealtimeHub = { seq: 0, clients: new Map() };
  return G.__rbRealtimeHub;
};

/** Register one connected stream. Returns the unsubscribe fn. */
export function subscribe(client: Omit<RtClient, "id">): () => void {
  const h = hub();
  const id = ++h.seq;
  h.clients.set(id, { ...client, id });
  return () => {
    h.clients.delete(id);
  };
}

/** Broadcast to EVERY connected player (lobby, drops, stats, rooms). */
export function publish(type: string, data: unknown): void {
  const h = hub();
  for (const c of h.clients.values()) {
    try {
      c.send(type, data);
    } catch {
      h.clients.delete(c.id); // dead stream — drop it, EventSource reconnects
    }
  }
}

/** Targeted push — only the streams of THIS player (balance, inventory). */
export function publishTo(playerId: string, type: string, data: unknown): void {
  const h = hub();
  for (const c of h.clients.values()) {
    if (c.playerId !== playerId) continue;
    try {
      c.send(type, data);
    } catch {
      h.clients.delete(c.id);
    }
  }
}

/** How many streams are attached (diagnostics). */
export function connectionCount(): number {
  return hub().clients.size;
}
