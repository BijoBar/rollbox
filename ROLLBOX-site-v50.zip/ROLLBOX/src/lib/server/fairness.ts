// ============ SERVER PROVABLY FAIR (Task 151) ============
// The real commit-reveal engine behind every SERVER roll (solo opens +
// upgrader + battles). Replaces the old Math.random()/crypto.randomInt draws:
//
//   COMMIT   — the server generates serverSeed (32B) + salt (16B), publishes
//              ONLY hash = SHA-256(serverSeed + salt) via /api/fair and in
//              every open response. The hash is locked BEFORE the rolls it
//              will ever decide — it cannot be swapped retroactively.
//   ROLL     — float = HMAC-SHA256(serverSeed, `${clientSeed}:${nonce}`)
//              mapped through the shared pickWeighted() (same math the
//              client-side verifier uses — src/lib/provably-fair.ts). The
//              player owns the clientSeed; the server cannot pre-roll.
//   NONCE    — consumed ATOMICALLY (conditional increment on the ACTIVE
//              seed) so two concurrent bets can never share a nonce.
//              Convention (documented on /provably-fair):
//                case open, reel i of a round starting at `start`:
//                  gate nonce = start + 2i     (ROLLDROP: float < chance)
//                  item nonce = start + 2i + 1 (weighted draw — the case's
//                                              table, or the rare pool on a
//                                              ROLLDROP hit)
//                upgrader: ONE slot — win iff float < chance
//                battle pull g (round-major order): gate 2g, item 2g+1,
//                clientSeed = the public battle code
//   REVEAL   — rotating the seed (/api/fair/rotate) stamps revealedAt on the
//              active row (its raw seed becomes public) and mints a fresh
//              one. Every FairRoll row carries its seedHash, so after the
//              reveal the player re-derives each outcome and matches it
//              against what the site actually paid out. Battles reveal their
//              seed in publicView the moment the battle settles.

import crypto from "crypto";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { computePublicHash, generateClientSeed, rollFloat } from "@/lib/provably-fair";

export type ActiveFairSeed = {
  id: string;
  playerId: string;
  serverSeed: string;
  salt: string;
  serverSeedHash: string;
  clientSeed: string;
  nonce: number;
};

/** Any Prisma client that can touch fairSeed — the global db OR a $transaction. */
type FairSeedClient = Pick<Prisma.TransactionClient, "fairSeed">;

const newId = () => "fs_" + crypto.randomBytes(8).toString("hex");

/** Client-seed guard: short printable token, no whitespace. */
export function sanitizeClientSeed(raw: unknown): string {
  const s = typeof raw === "string" ? raw.trim() : "";
  if (!s) return generateClientSeed();
  return s.replace(/[^a-zA-Z0-9_\-@#.]/g, "").slice(0, 64) || generateClientSeed();
}

async function createFairSeed(playerId: string, clientSeed?: string): Promise<ActiveFairSeed> {
  const serverSeed = crypto.randomBytes(32).toString("hex");
  const salt = crypto.randomBytes(16).toString("hex");
  return db.fairSeed.create({
    data: {
      id: newId(),
      playerId,
      serverSeed,
      salt,
      serverSeedHash: computePublicHash(serverSeed, salt),
      clientSeed: clientSeed ?? generateClientSeed(),
    },
  });
}

/** The player's ACTIVE (unrevealed) seed — created lazily on first use. */
export async function ensureFairSeed(playerId: string): Promise<ActiveFairSeed> {
  const existing = await db.fairSeed.findFirst({
    where: { playerId, revealedAt: null },
    orderBy: { createdAt: "desc" },
  });
  return existing ?? createFairSeed(playerId);
}

/**
 * Atomically bump the seed's nonce by `slots` — ONLY while it is still the
 * active (unrevealed) chain. Returns the FIRST reserved nonce, or null when
 * the seed was rotated mid-flight (the caller retries on the new chain).
 * Safe inside a $transaction: a rolled-back bet gives its nonces back.
 */
export async function reserveNoncesOn(
  client: FairSeedClient,
  seedId: string,
  slots: number
): Promise<number | null> {
  const updated = await client.fairSeed
    .update({
      where: { id: seedId, revealedAt: null },
      data: { nonce: { increment: slots } },
    })
    .catch(() => null);
  return updated ? updated.nonce - slots : null;
}

/**
 * Standalone reservation (no ambient transaction — the solo-open path):
 * retries across a concurrent rotation so two bets can never share a nonce.
 */
export async function reserveNonces(
  playerId: string,
  slots: number
): Promise<{ seed: ActiveFairSeed; start: number }> {
  for (let attempt = 0; attempt < 3; attempt++) {
    const seed = await ensureFairSeed(playerId);
    const start = await reserveNoncesOn(db, seed.id, slots);
    if (start !== null) return { seed, start };
  }
  throw new Error("fair-seed-unavailable");
}

/**
 * Reveal the active seed (stamps revealedAt — idempotent via the conditional
 * update) and mint a fresh one, optionally with the player's new clientSeed.
 * Returns the FULLY revealed old seed + the new active commitment.
 */
export async function rotateFairSeed(playerId: string, clientSeed?: string) {
  const current = await ensureFairSeed(playerId);
  const revealed = await db.fairSeed
    .update({
      where: { id: current.id, revealedAt: null },
      data: { revealedAt: new Date() },
    })
    .catch(() => null);
  if (!revealed) {
    return null; // lost a rotation race — caller asks the client to refetch
  }
  const next = await createFairSeed(playerId, clientSeed);
  return { revealed, next };
}

/** Public commitment snapshot — everything a player needs BEFORE betting. */
export async function fairSnapshot(playerId: string) {
  const seed = await ensureFairSeed(playerId);
  return {
    serverSeedHash: seed.serverSeedHash,
    clientSeed: seed.clientSeed,
    nextNonce: seed.nonce,
  };
}

export { rollFloat, computePublicHash };
