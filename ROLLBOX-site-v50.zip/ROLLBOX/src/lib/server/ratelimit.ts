// ============ In-memory rate limiter (ANTI-CHEAT, Task 108) ============
// A sliding-window limiter for the API routes. Single-process site (the user
// runs it via START-ROLLBOX on their own machine / LAN), so a per-process
// Map is the correct scope: every worker shares the same bucket store.
//
// Usage inside a route handler, AFTER the session is resolved:
//   if (!rateLimit(`open:${player.id}`, 30, 60_000)) return tooMany();
// For pre-auth routes (steam start) key by IP:
//   if (!rateLimit(`steam:${ipOf(req)}`, 10, 60_000)) return tooMany();

const buckets = new Map<string, number[]>();

/** Keep the store bounded — a hostile client must not grow memory forever. */
const MAX_BUCKETS = 5000;
let lastSweep = 0;

function sweep(now: number) {
  if (now - lastSweep < 60_000) return;
  lastSweep = now;
  for (const [key, hits] of buckets) {
    const alive = hits.filter((t) => now - t < 3_600_000);
    if (!alive.length) buckets.delete(key);
    else buckets.set(key, alive);
  }
}

/** True = allowed. False = the caller should answer 429. */
export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  sweep(now);
  const hits = buckets.get(key) ?? [];
  const fresh = hits.filter((t) => now - t < windowMs);
  if (fresh.length >= limit) {
    buckets.set(key, fresh); // keep pruning even on rejects
    return false;
  }
  fresh.push(now);
  buckets.set(key, fresh);
  if (buckets.size > MAX_BUCKETS) {
    // emergency trim: drop the oldest keys (Map keeps insertion order)
    for (const k of buckets.keys()) {
      buckets.delete(k);
      if (buckets.size <= MAX_BUCKETS) break;
    }
  }
  return true;
}

/** The caller's IP — x-forwarded-for first hop, else the loopback default. */
export function ipOf(headers: Headers): string {
  const fwd = headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return headers.get("x-real-ip") ?? "local";
}

/** The standard 429 JSON body. */
export const TOO_MANY = { error: "Too many requests — slow down a little." };
