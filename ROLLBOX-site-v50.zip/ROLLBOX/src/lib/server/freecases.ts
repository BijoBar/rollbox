// ============ FREE CASES server state (Task 183 — USER SPEC) ============
// "אני רוצה להוסיף לאדמינים אפשרות לתת תיבות חינם במתנה לשחקן, אני רוצה שהDB ידע
// בדיוק לכל שחקן כמה תיבות חינם יש לו" — the admins gift free boxes, the DB
// knows EXACTLY how many free boxes of each case every player owns, and every
// completed mission pays a free RB-106.
//
// STORAGE: the Player.freeCases JSON column — {"<caseId>": qty}. A player with
// no free boxes has null/empty — every case name renders plain, no FREE chip.
//
// CONSUMPTION: opening a case burns the player's free units FIRST (the paid
// charge only covers the remainder) — wired into /api/open.
//
// CONCURRENCY: exactly like the dailyOpens stamps (Task 153 hardening), every
// write is a COMPARE-AND-SET loop on the JSON snapshot — two simultaneous
// opens / grants can never double-spend or overwrite each other's units.

import { db } from "@/lib/db";

/** Clean {"<caseId>": qty>0} map out of the raw column (garbage-tolerant). */
export function parseFreeCases(raw: string | null | undefined): Record<string, number> {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const out: Record<string, number> = {};
    for (const [caseId, qty] of Object.entries(parsed as Record<string, unknown>)) {
      const n = typeof qty === "number" ? qty : Number(qty);
      if (Number.isFinite(n) && n > 0) out[caseId] = Math.min(9_999, Math.floor(n));
    }
    return out;
  } catch {
    return {};
  }
}

export async function freeCasesOf(playerId: string): Promise<Record<string, number>> {
  const row = await db.player
    .findUnique({ where: { id: playerId }, select: { freeCases: true } })
    .catch(() => null);
  return parseFreeCases(row?.freeCases);
}

/**
 * Grant qty free boxes of one case. CAS loop on the JSON snapshot — safe
 * against concurrent grants/opens. Returns the player's fresh freeCases map
 * (or null when the player row vanished / the CAS never landed).
 */
export async function grantFreeCases(
  playerId: string,
  caseId: string,
  qty: number,
): Promise<Record<string, number> | null> {
  const add = Math.max(1, Math.min(9_999, Math.floor(qty)));
  let raw: string | null = null;
  for (let attempt = 0; attempt < 6; attempt++) {
    if (attempt > 0 || raw === null) {
      const fresh = await db.player
        .findUnique({ where: { id: playerId }, select: { freeCases: true } })
        .catch(() => null);
      if (!fresh) return null;
      raw = fresh.freeCases ?? null;
    }
    const map = parseFreeCases(raw);
    map[caseId] = (map[caseId] ?? 0) + add;
    const res = await db.player
      .updateMany({
        where: { id: playerId, freeCases: raw },
        data: { freeCases: JSON.stringify(map) },
      })
      .catch(() => null);
    if (res && res.count === 1) return map;
    // the snapshot moved under us — re-read and retry
    const fresh = await db.player
      .findUnique({ where: { id: playerId }, select: { freeCases: true } })
      .catch(() => null);
    if (!fresh) return null;
    raw = fresh.freeCases ?? null;
  }
  return null;
}

/**
 * Consume up to `want` free units of one case. Returns HOW MANY were actually
 * consumed (0..want) plus the player's fresh map. Never throws — a free-case
 * hiccup must never block a paid opening (the caller falls back to full price).
 */
export async function consumeFreeCases(
  playerId: string,
  caseId: string,
  want: number,
): Promise<{ used: number; freeCases: Record<string, number> }> {
  const none = { used: 0, freeCases: await freeCasesOf(playerId) };
  const take = Math.max(0, Math.min(9_999, Math.floor(want)));
  if (take <= 0) return none;
  let raw: string | null = null;
  for (let attempt = 0; attempt < 6; attempt++) {
    if (attempt > 0 || raw === null) {
      const fresh = await db.player
        .findUnique({ where: { id: playerId }, select: { freeCases: true } })
        .catch(() => null);
      if (!fresh) return none;
      raw = fresh.freeCases ?? null;
    }
    const have = parseFreeCases(raw)[caseId] ?? 0;
    if (have <= 0) return { used: 0, freeCases: parseFreeCases(raw) };
    const used = Math.min(take, have);
    const map = parseFreeCases(raw);
    if (have - used > 0) map[caseId] = have - used;
    else delete map[caseId];
    const res = await db.player
      .updateMany({
        where: { id: playerId, freeCases: raw },
        data: { freeCases: JSON.stringify(map) },
      })
      .catch(() => null);
    if (res && res.count === 1) return { used, freeCases: map };
    const fresh = await db.player
      .findUnique({ where: { id: playerId }, select: { freeCases: true } })
      .catch(() => null);
    if (!fresh) return none;
    raw = fresh.freeCases ?? null;
  }
  return none;
}
