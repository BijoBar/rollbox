// ============ COMMUNITY CASES (Task 142 — USER SPEC) ============
// Players BUILD their own cases: pick up to 10 skins, weights MUST sum to
// exactly 100%, the site prices the case automatically (expected payout of
// the contents divided by 0.85 → a 15% house edge, so the site can only
// profit), a design + name are chosen, and PUBLISH CASE writes the row to
// the DB. From that moment ANY player can open it through the regular
// opening flow (/case/<id> → POST /api/open).

import crypto from "crypto";
import { db } from "@/lib/db";
import { SKINS, caseItemValue, type CaseDef, type CaseItem } from "@/lib/cases";
import {
  COMMUNITY_DESIGNS,
  COMMUNITY_MAX_ITEMS,
  DESIGN_COLORS,
  type CommunityDesign,
} from "@/lib/community-designs";

/** The house edge — the site's profit/loss calculation for a community case:
 *  price = expected payout / 0.85, so on average the site keeps 15%. */
export const HOUSE_EDGE = 0.85;

export { COMMUNITY_DESIGNS, COMMUNITY_MAX_ITEMS };
export type { CommunityDesign };

/** The automatic site price for a set of builder items — expected value of
 *  the contents (weights are percentages) divided by the house edge, rounded
 *  UP to whole cents so rounding can never flip the edge negative. */
export function communityPriceOf(items: { skinId: string; weight: number; value?: number }[]): number {
  const ev = items.reduce((sum, it) => sum + (it.weight / 100) * caseItemValue({ skinId: it.skinId, weight: it.weight, value: it.value }), 0);
  return Math.max(0.5, Math.ceil((ev / HOUSE_EDGE) * 100) / 100);
}

/** Validate a builder submission. Returns the sanitized item list or an error
 *  string. Server-side truth: skin ids must exist, values come from the
 *  catalog (the client never dictates prices), 1..10 items, weights > 0 and
 *  the total MUST be 100% ("מחוייבת ב100% סה״כ דרופים"). */
export function validateCommunityItems(raw: unknown): { ok: true; items: CaseItem[] } | { ok: false; error: string } {
  if (!Array.isArray(raw) || raw.length === 0) return { ok: false, error: "Pick at least one skin" };
  if (raw.length > COMMUNITY_MAX_ITEMS) return { ok: false, error: `A case holds at most ${COMMUNITY_MAX_ITEMS} skins` };
  const items: CaseItem[] = [];
  let total = 0;
  const seen = new Set<string>();
  for (const r of raw) {
    const skinId = typeof (r as { skinId?: unknown })?.skinId === "string" ? (r as { skinId: string }).skinId : "";
    if (!skinId || !SKINS[skinId]) return { ok: false, error: "Unknown skin in the list" };
    if (seen.has(skinId)) return { ok: false, error: "The same skin appears twice" };
    seen.add(skinId);
    const weight = Math.round(Number((r as { weight?: unknown })?.weight) * 100) / 100;
    if (!Number.isFinite(weight) || weight <= 0 || weight > 100) return { ok: false, error: "Every skin needs a drop chance between 0 and 100%" };
    total += weight;
    items.push({ skinId, weight });
  }
  if (Math.round(total * 100) !== 10000) return { ok: false, error: "The drop chances must add up to exactly 100%" };
  return { ok: true, items };
}

/** The server-authoritative CaseDef for a stored community case — flows
 *  through the regular opening engine untouched. ROLLDROP is disabled for
 *  player-made cases (the rare pool belongs to the official catalog). */
export function communityToCaseDef(row: {
  id: string;
  name: string;
  design: string;
  price: number;
  items: string;
}): CaseDef {
  const design = (COMMUNITY_DESIGNS as readonly string[]).includes(row.design)
    ? (row.design as CommunityDesign)
    : "red";
  const items = JSON.parse(row.items) as CaseItem[];
  const colors = DESIGN_COLORS[design];
  return {
    id: row.id,
    code: "COMMUNITY",
    name: row.name,
    subtitle: "A player-built community case.",
    kind: "standard",
    tierLabel: "COMMUNITY",
    price: row.price,
    tierColor: colors.c1,
    tierColor2: colors.c2,
    items,
    rolldropChance: 0,
    communityDesign: design,
  };
}

export async function findCommunityCase(id: string): Promise<CaseDef | undefined> {
  if (!id.startsWith("cc_")) return undefined;
  const row = await db.communityCase.findUnique({ where: { id } }).catch(() => null);
  if (!row) return undefined;
  return communityToCaseDef(row);
}

export function newCommunityCaseId(): string {
  return "cc_" + crypto.randomBytes(8).toString("hex");
}

/** The 10 NEWEST community cases (USER SPEC: the section always reads the
 *  10 latest created rows from the DB). EVENTS/battles picker: each row also
 *  carries its parsed items — the picker needs the contents for the top-prize
 *  sort and the VIEW DROPS dialog (public data, same as the case page). */
export async function newestCommunityCases(limit = 10) {
  const rows = await db.communityCase.findMany({
    orderBy: { createdAt: "desc" },
    take: limit,
  });
  return rows.map((r) => {
    let items: unknown[] = [];
    try {
      const parsed = JSON.parse(r.items);
      if (Array.isArray(parsed)) items = parsed;
    } catch {
      /* an unparsable row ships with an empty item list rather than crashing */
    }
    return {
      id: r.id,
      name: r.name,
      creatorName: r.creatorName,
      design: r.design,
      price: r.price,
      createdAt: r.createdAt.toISOString(),
      items,
    };
  });
}
