// ============ SERVER XP awards (ANTI-CHEAT, Task 108) ============
// The DATABASE battle pass is SERVER-AUTHORITATIVE: /api/xp no longer trusts
// a client-pushed absolute xp (anyone with curl could claim Level 100 and
// unlock every free daily case). XP is awarded ONLY by server-verified
// actions, with the exact same math the client mirrors for its instant UI:
//   POST /api/open        -> caseXp(caseDef) * count   (paid AND daily free)
//   battle settleRow      -> Σ over rounds of xpForCase(round case price),
//                            granted to every real (steam) seat
// The client's grantXp is a cosmetic local animation; every 15s the session
// heartbeat adopts the DB value as the truth.

import { db } from "@/lib/db";
import { levelFromXp } from "@/lib/progress";

/** Add XP to a player row and derive the level with the shared math. */
export async function awardXp(playerId: string, amount: number): Promise<void> {
  const gain = Math.max(0, Math.floor(amount));
  if (!gain) return;
  try {
    const row = await db.player.findUnique({ where: { id: playerId }, select: { xp: true } });
    if (!row) return;
    const xp = row.xp + gain; // ADDITIVE, server-computed — the client is never asked
    const level = levelFromXp(xp).level;
    await db.player.update({ where: { id: playerId }, data: { xp, level } });
  } catch {
    // a failed xp bump must never break the action that earned it
  }
}
