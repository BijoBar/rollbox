// ============ SERVER catalog loader — the exchange prices live HERE ============
// USER SPEC (Task 64): the client never decides prices. The buy/sell routes
// read the SAME public catalog the UI browses, but from the server's disk, and
// every trade is validated against THIS copy — a tampered client can send any
// id/amount it wants, the server still charges/credits the real price.

import crypto from "crypto";
import fs from "fs";
import path from "path";
import { entryWearPrice, isWearId, wearHashName, type WearId } from "@/lib/wear";
import { unifiedCoins } from "@/lib/server/pricing";

export interface CatalogEntry {
  id: string;
  n: string; // display name
  w: string; // weapon/label
  r: string; // rarity key
  p: number; // real USD price
  v: number; // site coin value — THE price the server charges/credits
  img: string | null;
  est?: 1;
  t?: string;
  cat?: string;
  a?: string;
  wp?: Partial<Record<WearId, number>>; // Task 72: USD per wear (market dump)
  wa?: WearId[]; // Task 72: in-game wear availability (absent = all five)
}

let cache: Map<string, CatalogEntry> | null = null;
let cacheMtimeMs = -1;

function loadCatalog(): Map<string, CatalogEntry> {
  // dev: project root. production standalone: process.cwd() is .next/standalone
  // (the build copies public/ there — make-package script keeps both in sync).
  const candidates = [
    path.join(process.cwd(), "public", "skins-catalog.json"),
    path.join(process.cwd(), "..", "public", "skins-catalog.json"),
  ];
  // Task 27: mtime-cached — scripts/apply-unified-prices.ts rewrites the
  // catalog file in place and the running server picks it up without a restart.
  for (const file of candidates) {
    try {
      if (!fs.existsSync(file)) continue;
      const mtimeMs = fs.statSync(file).mtimeMs;
      if (cache && mtimeMs === cacheMtimeMs) return cache;
      const map = new Map<string, CatalogEntry>();
      const raw = JSON.parse(fs.readFileSync(file, "utf8")) as CatalogEntry[];
      for (const e of raw) if (e && typeof e.id === "string") map.set(e.id, e);
      cache = map;
      cacheMtimeMs = mtimeMs;
      return map;
    } catch {
      /* try the next candidate */
    }
  }
  return cache ?? new Map<string, CatalogEntry>();
}

/** The authoritative catalog entry, or null when the id does not exist. */
export function catalogEntry(id: string): CatalogEntry | null {
  return loadCatalog().get(id) ?? null;
}

/**
 * Task 27: the entry's coin price — the REAL steamanalyst price when the
 * unified table holds the name (agents, vanilla knives and every other
 * no-wear item; wear-weapons resolve through catalogWearCoins instead),
 * otherwise the catalog's own value. This is what a buy without a wear
 * picker charges.
 */
export function catalogEntryCoins(entry: CatalogEntry): number {
  const real = unifiedCoins(entry.n);
  return real ?? entry.v;
}

/** Steam-stock support: index the catalog by display name ("AK-47 | Slate").
 *  First hit wins — the catalog is name-unique for practical purposes.
 *  Keys are whitespace-collapsed: Steam names carry double spaces
 *  ("Michael Syfers  | FBI Sniper") while lookups normalize the same way. */
let byName: Map<string, CatalogEntry> | null = null;

const nameKey = (n: string): string => n.replace(/\s+/g, " ").trim();

export function catalogByName(name: string): CatalogEntry | null {
  if (!byName) {
    byName = new Map<string, CatalogEntry>();
    for (const e of loadCatalog().values()) {
      const k = nameKey(e.n);
      if (!byName.has(k)) byName.set(k, e);
    }
  }
  return byName.get(nameKey(name)) ?? null;
}

/** Value-sorted catalog (built once) — the UPGRADER's prize picker (Task 28).
 *  WEAPONS ONLY: the catalog is ~80% stickers/charms/agents/patches, and the
 *  user spec says the winner receives a SKIN — so prize picks come from the
 *  2k+ real weapon entries (rifles/pistols/SMGs/heavy/knives/gloves/Zeus). */
let byValue: CatalogEntry[] | null = null;
function valueSorted(): CatalogEntry[] {
  if (!byValue) {
    byValue = [...loadCatalog().values()]
      .filter((e) => Number.isFinite(e.v) && e.v > 0 && !e.t)
      .sort((a, b) => a.v - b.v);
  }
  return byValue;
}

/**
 * USER SPEC (Task 28): the UPGRADER pays out in SKINS — the player stakes
 * inventory items and a WIN grants the catalog skin whose coin value is the
 * CLOSEST to the target (stake x multiplier). Ties (two values equidistant
 * from the target) resolve to the cheaper one — the house never rounds up.
 * Many skins share a value: one of the same-value group is picked at random
 * so repeated upgrades don't always pay the same skin.
 */
export function catalogNearest(target: number): CatalogEntry | null {
  const arr = valueSorted();
  if (!arr.length || !Number.isFinite(target) || target <= 0) return null;
  const t = Math.min(target, arr[arr.length - 1].v); // cap at the priciest skin

  let lo = 0;
  let hi = arr.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (arr[mid].v < t) lo = mid + 1;
    else hi = mid;
  }
  // arr[lo] = first entry with v >= t; arr[lo-1] = last entry with v < t
  const above = arr[lo];
  const below = arr[lo - 1];
  let best: CatalogEntry;
  if (!below) best = above;
  else if (Math.abs(above.v - t) < Math.abs(t - below.v)) best = above;
  else best = below;

  // every entry sharing the winning value — pick one at random for variety
  const same = [best];
  for (let i = arr.indexOf(best) - 1; i >= 0 && arr[i].v === best.v; i--) same.push(arr[i]);
  for (let i = arr.indexOf(best) + 1; i < arr.length && arr[i].v === best.v; i++) same.push(arr[i]);
  return same[cryptoRandomInt(same.length)];
}

/** crypto-random index in [0, n) — the server's RNG, not Math.random. */
function cryptoRandomInt(n: number): number {
  return crypto.randomInt(0, n);
}

/**
 * Task 72: the coin price of a catalog entry at a WEAR — resolved on the
 * SERVER from the same catalog file (entry.wp), never from the request.
 * Returns null when the entry has no wear picker or the wear is not one the
 * skin actually comes in.
 */
export function catalogWearCoins(entry: CatalogEntry, wear: unknown): number | null {
  if (!isWearId(wear)) return null;
  if (entry.wa && !entry.wa.includes(wear)) return null; // availability rules first
  // Task 27: the REAL price (steamanalyst.com / CSFLOAT) for this exact
  // "base (wear)" market name wins before any catalog/estimate math.
  const real = unifiedCoins(wearHashName(entry.n, wear));
  if (real != null) return real;
  if (!entry.wp) return null; // stickers / charms / vanilla knives: no wears
  return entryWearPrice(entry, wear).coins;
}
