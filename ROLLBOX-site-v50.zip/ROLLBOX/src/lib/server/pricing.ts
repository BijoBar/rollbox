// ============ UNIFIED PRICING (Task 27) — the real-price layer ============
// USER SPEC: "כל הסקינים יהיו באותו מחיר בכל האתר... שיקבלו את המחיר האמיתי
// שלהם מהאתר www.steamanalyst.com" — every skin carries ONE price everywhere
// (exchange, cases, terminals, upgrader, DROP EDITOR) and that price is the
// REAL market price steamanalyst.com shows (the CSFLOAT feed).
//
// HOW IT WORKS
//   db/steamanalyst-prices.json holds real USD prices keyed by the Steam
//   market_hash_name — the canonical join key, quality prefix and wear
//   suffix included ("Souvenir AWP | Desert Hydra (Field-Tested)"). The
//   crawler (src/lib/server/pricing-crawl.ts) fills it from the
//   steamanalyst API; until a key is configured the table stays EMPTY and
//   the site keeps its current prices (USER choice: infrastructure first).
//
//   Resolution order everywhere:
//     1. REAL  — unifiedUsd(marketHash) hits the table: coins = usd × the
//                site-wide USD_TO_COINS rate, never flagged as estimated.
//     2. LEGACY — the old catalog/factor math (est "~" in the UI).
//
//   USD_TO_COINS itself lives in src/lib/wear.ts (isomorphic, client+server)
//   and flips 10 → 1 inside scripts/apply-unified-prices.ts when the
//   migration runs — one constant, no hardcoded rates anywhere else.

import fs from "fs";
import path from "path";
import { coinsToUsd, usdToCoins, USD_TO_COINS } from "@/lib/wear";

export { coinsToUsd, usdToCoins, USD_TO_COINS };

export interface UnifiedPrice {
  usd: number;
  ts: number;
  src?: string;
}

export interface UnifiedTable {
  source?: string;
  currency?: string;
  updatedAt: number;
  prices: Record<string, UnifiedPrice>;
}

/** The table file — same folder as the site DB, rides along in the ZIP. */
export const PRICES_PATH = path.join(process.cwd(), "db", "steamanalyst-prices.json");

let cache: { table: UnifiedTable; mtimeMs: number } | null = null;

/** mtime-cached load — a fresh table (crawler/auto-refresh) serves without a
 *  restart, exactly like the steam-stock catalog file. */
export function loadUnifiedTable(): UnifiedTable {
  try {
    const st = fs.statSync(PRICES_PATH);
    if (cache && st.mtimeMs === cache.mtimeMs) return cache.table;
    const parsed = JSON.parse(fs.readFileSync(PRICES_PATH, "utf8")) as UnifiedTable;
    if (parsed && parsed.prices && typeof parsed.prices === "object") {
      cache = { table: parsed, mtimeMs: st.mtimeMs };
      return parsed;
    }
  } catch {
    /* no table yet — first boot before the crawler ever ran */
  }
  return { updatedAt: 0, prices: {} };
}

/** The REAL market USD price for a full market_hash_name, or null. */
export function unifiedUsd(marketHash: string): number | null {
  const hit = loadUnifiedTable().prices[marketHash];
  return hit && typeof hit.usd === "number" && hit.usd > 0 ? hit.usd : null;
}

/** The REAL price in SITE COINS (via the live USD_TO_COINS rate), or null. */
export function unifiedCoins(marketHash: string): number | null {
  const usd = unifiedUsd(marketHash);
  return usd == null ? null : usdToCoins(usd);
}

/** The REAL price in USD for the reverse-mapped snapshot fields, or null. */
export function unifiedUsdFromCoins(coins: number): number {
  return coinsToUsd(coins);
}

/** How many real prices the table holds (diagnostics / status route). */
export function unifiedCount(): number {
  return Object.keys(loadUnifiedTable().prices).length;
}

/** Last crawler update (ms epoch), 0 when the table was never filled. */
export function unifiedUpdatedAt(): number {
  return loadUnifiedTable().updatedAt ?? 0;
}
