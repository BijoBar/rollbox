// ============ REALTIME TICKER — the server's game clock (Task 64) ============
// The battles settle on the SHARED CLOCK, and their rounds go public on that
// same clock. Until now the only thing driving those flips was each client's
// own poll — every viewer advanced the world at its own pace. Now THIS server
// interval is the single heartbeat: every ~700ms it
//   1. settles any battle whose clock ran out (the ONE authoritative settle),
//   2. pushes "battle" the moment a round goes public — every viewer receives
//      the pulls at the SAME instant (no more per-client poll timing),
//   3. pushes "battles" when the lobby list itself changes shape.
// This module is server-only and imported by the stream route; it imports the
// battle engine — realtime.ts stays pure to keep the graph acyclic.

import { db } from "@/lib/db";
import { publish } from "@/lib/server/realtime";
import { loadBattle, settleIfDue } from "@/lib/server/gbattles";
import type { RoundSlot } from "@/lib/gbattle-shared";

const G = globalThis as typeof globalThis & { __rbRealtimeTicker?: boolean; __rbBattleWatch?: Map<string, number> };

const TICK_MS = 700;

async function tick(): Promise<void> {
  const watch = G.__rbBattleWatch ?? (G.__rbBattleWatch = new Map());
  let rows: { id: string; status: string; startedAt: Date | null; totalMs: number | null; schedule: string | null }[] = [];
  try {
    rows = await db.battle.findMany({
      where: { status: { in: ["playing", "settling"] } },
      select: { id: true, status: true, startedAt: true, totalMs: true, schedule: true },
    });
  } catch {
    return; // DB hiccup — the next tick retries
  }

  const now = Date.now();
  for (const row of rows) {
    if (!row.startedAt || row.totalMs === null) continue;
    const elapsed = now - row.startedAt.getTime();

    if (elapsed >= row.totalMs) {
      // the clock ran out — the authoritative settle flips + pays, then push
      const full = await loadBattle(row.id);
      if (!full) continue;
      const settled = await settleIfDue(full).catch(() => null);
      if (settled && settled.status !== row.status) {
        publish("battle", { id: row.id });
        publish("battles", { at: now }); // the room left the live lobby list
      }
      watch.delete(row.id);
      continue;
    }

    // which round slots have gone public so far on the shared clock?
    let slots: RoundSlot[] = [];
    try {
      slots = row.schedule ? (JSON.parse(row.schedule) as RoundSlot[]) : [];
    } catch {
      slots = [];
    }
    const visible = slots.filter((s) => elapsed >= s.startMs).length;
    const prev = watch.get(row.id) ?? 0;
    if (visible > prev) {
      watch.set(row.id, visible);
      publish("battle", { id: row.id }); // every viewer gets the new pulls NOW
    }
  }

  // drop watches for battles that are no longer live
  const liveIds = new Set(rows.map((r) => r.id));
  for (const id of watch.keys()) if (!liveIds.has(id)) watch.delete(id);
}

/** Start the heartbeat exactly once per process (dev hot-reload safe). */
export function startRealtimeTicker(): void {
  if (G.__rbRealtimeTicker) return;
  G.__rbRealtimeTicker = true;
  const t = setInterval(() => void tick(), TICK_MS);
  // never keep the process alive just for the ticker
  t.unref?.();
}
