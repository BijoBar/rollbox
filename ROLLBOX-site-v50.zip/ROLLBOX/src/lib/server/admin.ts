// ============ ADMIN gate (Task 22 — USER SPEC) ============
// Shared by every /api/admin route: the DATABASE isAdmin flag decides, never
// the client. A non-admin (or signed-out request) gets a flat 404 — for them
// the admin panel simply does not exist.
// The TopBar's red ADMIN button only VISIBILITY-previews the same truth; the
// routes here are the real wall.
//
// SECURITY (Task 167):
//  * 2FA — once the admin has confirmed a TOTP secret (SiteConfig
//    "admin.totpEnabled" == "1"), requireAdmin ALSO demands the rb_2fa
//    unlock cookie (12h, minted by a correct authenticator code). The
//    2FA self-service routes bypass this gate on purpose (chicken & egg) —
//    they use sessionPlayer + isAdmin directly.
//  * logAdmin — the append-only AuditLog writer every admin mutation calls.

import type { NextRequest } from "next/server";
import type { Player } from "@prisma/client";
import { db } from "@/lib/db";
import { sessionPlayer, read2faToken } from "@/lib/server/auth";

export async function requireAdmin(req: NextRequest): Promise<Player | null> {
  const player = await sessionPlayer(req);
  if (!player || !player.isAdmin) return null;
  const enabled = await db.siteConfig.findUnique({ where: { key: "admin.totpEnabled" } });
  if (enabled?.value === "1" && !read2faToken(req.cookies.get("rb_2fa")?.value)) return null;
  return player;
}

/**
 * Append one audit row for an admin action. Fire-and-forget ON PURPOSE: an
 * audit failure must never roll back the business action it describes (the
 * action is already committed / independent). Failures land in the server
 * log so a broken audit trail is visible in dev.log, never silent.
 */
export async function logAdmin(
  admin: { id: string; name: string },
  action: string,
  target?: string | null,
  meta?: unknown,
): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        adminId: admin.id,
        adminName: admin.name,
        action,
        target: target ?? null,
        meta: meta == null ? null : typeof meta === "string" ? meta : JSON.stringify(meta),
      },
    });
  } catch (err) {
    console.error("[audit] FAILED to record", action, target, err);
  }
}
