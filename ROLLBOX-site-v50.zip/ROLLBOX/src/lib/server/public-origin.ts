// ============ PUBLIC ORIGIN — the address the PLAYER's browser really uses ============
// Behind Cloudflare Tunnel (or any reverse proxy) the Next.js server receives
// Host: localhost:3000 while the player sits on https://<tunnel-domain>. Steam
// OpenID's return_to built from req.nextUrl.origin then sends the player's
// browser back to http(s)://localhost:3000 — Chrome dies with
// "localhost sent an invalid response" (ERR_SSL_PROTOCOL_ERROR) or "refused to
// connect", and NOBODY can sign in through the tunnel.
//
// This resolver rebuilds the PUBLIC origin from, in order of trust:
//   1. PUBLIC_URL / NEXT_PUBLIC_SITE_URL env  — explicit pin (named tunnels)
//   2. X-Forwarded-Host + X-Forwarded-Proto   — proper reverse proxies
//      (never trusted for loopback hosts — the https://localhost killer)
//   3. Origin header                          — sent by the login navigation
//   4. Referer header                         — the page the click came from
//                                               (zero-config for quick tunnels)
//   5. Host header (+ proto); http is FORCED for loopback hosts
//
// strict mode (used by the Steam callback) skips 3+4: on the way back from
// Steam those browser headers belong to steamcommunity.com, not to this site.
// Keep this file dependency-free — it must be importable from anywhere.

const LOOPBACK = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]|::1)(:\d+)?$/i;

/** Normalize to a clean scheme://host[:port] origin — null when unusable. */
export function sanitizePublicOrigin(value: string | null | undefined): string | null {
  if (!value) return null;
  try {
    const u = new URL(value.trim());
    if (u.protocol !== "https:" && u.protocol !== "http:") return null;
    // https://loopback is ALWAYS a proxy artifact (cloudflared's
    // X-Forwarded-Proto: https glued onto Host: localhost) — reject it.
    if (u.protocol === "https:" && LOOPBACK.test(u.hostname)) return null;
    return u.origin;
  } catch {
    return null;
  }
}

/** First entry of a comma-separated forwarded header. */
const firstForwarded = (v: string | null): string | null => v?.split(",")[0]?.trim() || null;

/** Origin from a host header + proto; http is forced for loopback hosts. */
const hostOrigin = (host: string | null, proto: string | null): string | null => {
  if (!host) return null;
  const scheme = LOOPBACK.test(host) ? "http" : proto === "https" ? "https" : "http";
  return sanitizePublicOrigin(`${scheme}://${host}`);
};

export function publicOrigin(req: Request, opts?: { strict?: boolean }): string {
  const h = req.headers;

  // 1 — the explicit pin wins over every guess
  const pinned = sanitizePublicOrigin(process.env.PUBLIC_URL || process.env.NEXT_PUBLIC_SITE_URL);
  if (pinned) return pinned;

  // 2 — proper reverse proxies announce the public host
  const xfp = firstForwarded(h.get("x-forwarded-proto"));
  const xfh = firstForwarded(h.get("x-forwarded-host"));
  if (xfh) {
    const origin = hostOrigin(xfh, xfp);
    if (origin && !LOOPBACK.test(new URL(origin).hostname)) return origin;
  }

  // 3+4 — the browser's own idea of where it is (skipped on the way back from Steam)
  if (!opts?.strict) {
    const browserOrigin = sanitizePublicOrigin(h.get("origin")) ?? sanitizePublicOrigin(h.get("referer"));
    if (browserOrigin) return browserOrigin;
  }

  // 5 — last resort: the host this request arrived on (loopback forced to http)
  return hostOrigin(h.get("host"), xfp) ?? "http://localhost:3000";
}
