// ============ PRICING AUTO-REFRESH (Task 27) — the server-side timer ============
// USER SPEC: "אוטומטי" — price updates run on the server by themselves. Once
// a steamanalyst API key sits in db/pricing-config.json (or the
// STEAMANALYST_API_KEY env), a globalThis-singleton timer crawls a slice
// every 6 hours (the free tier's rolling 24h budget of 100 requests still
// applies per the crawl state, so a tick without budget is a no-op). Without
// a key the timer stays dormant — zero requests, zero behavior change.
//
// Started from steam-stock.ts module scope (the exchange's own engine boot).

import { crawlSlice, loadPricingConfig } from "@/lib/server/pricing-crawl";

const TICK_MS = 6 * 60 * 60 * 1000; // every 6 hours
const BOOT_DELAY_MS = 45_000; // first catch-up slice 45s after boot

export function pricingRefreshInit(): void {
  const g = globalThis as typeof globalThis & { __rbPricingTimer?: ReturnType<typeof setInterval> };
  if (g.__rbPricingTimer) return; // one timer per process — hot reloads included

  g.__rbPricingTimer = setInterval(() => {
    const cfg = loadPricingConfig();
    if (!cfg.apiKey || !cfg.autoRefresh) return; // dormant — no key, no requests
    void crawlSlice().catch(() => {
      /* the slice persists its own state; the next tick retries */
    });
  }, TICK_MS);

  // the boot catch-up runs UNCONDITIONALLY of autoRefresh (a manual CLI run
  // shares the same budget ledger) — but only when a key exists at all.
  setTimeout(() => {
    const cfg = loadPricingConfig();
    if (cfg.apiKey) void crawlSlice().catch(() => {});
  }, BOOT_DELAY_MS).unref?.();
}
