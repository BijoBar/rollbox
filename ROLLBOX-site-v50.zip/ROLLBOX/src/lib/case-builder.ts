"use client";

// ============ CASE BUILDER store (Task 142 — USER SPEC) ============
// Two-page wizard: /case-builder (pick skins + weights) → /case-builder/design
// (crate artwork + name → PUBLISH CASE). The draft rides between the pages in
// sessionStorage, so a refresh never loses the builder's work.

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { COMMUNITY_MAX_ITEMS, type CommunityDesign } from "@/lib/community-designs";

export interface BuilderItem {
  skinId: string;
  weight: number; // percent — the list MUST total exactly 100
}

interface CaseBuilderState {
  items: BuilderItem[];
  name: string;
  design: CommunityDesign | null;
  addItem: (skinId: string) => boolean; // false when the case is full
  removeItem: (skinId: string) => void;
  setWeight: (skinId: string, weight: number) => void;
  bumpWeight: (skinId: string, delta: number) => void;
  splitEvenly: () => void;
  setName: (name: string) => void;
  setDesign: (design: CommunityDesign) => void;
  reset: () => void;
}

export const totalWeightOf = (items: BuilderItem[]): number =>
  Math.round(items.reduce((s, i) => s + i.weight, 0) * 100) / 100;

/** The case is publishable ONLY at exactly 100% total drop chance (USER SPEC:
 * "כל תיבה תיהיה מחוייבת ב100% סה״כ דרופים בשביל להמשיך"). */
export const builderComplete = (items: BuilderItem[]): boolean =>
  items.length > 0 && items.length <= COMMUNITY_MAX_ITEMS && totalWeightOf(items) === 100;

export const useCaseBuilder = create<CaseBuilderState>()(
  persist(
    (set, get) => ({
      items: [],
      name: "",
      design: null,
      addItem: (skinId) => {
        const { items } = get();
        if (items.length >= COMMUNITY_MAX_ITEMS || items.some((i) => i.skinId === skinId)) return false;
        set({ items: [...items, { skinId, weight: 10 }] });
        return true;
      },
      removeItem: (skinId) => set({ items: get().items.filter((i) => i.skinId !== skinId) }),
      setWeight: (skinId, weight) =>
        set({
          items: get().items.map((i) =>
            i.skinId === skinId ? { ...i, weight: Math.max(0, Math.min(100, Math.round(weight * 100) / 100)) } : i,
          ),
        }),
      bumpWeight: (skinId, delta) => {
        const cur = get().items.find((i) => i.skinId === skinId);
        if (cur) get().setWeight(skinId, cur.weight + delta);
      },
      splitEvenly: () => {
        const { items } = get();
        if (!items.length) return;
        const even = Math.floor((100 / items.length) * 100) / 100;
        const next = items.map((i) => ({ ...i, weight: even }));
        // the rounding dust lands on the last item so the total is EXACTLY 100
        next[next.length - 1].weight = Math.round((100 - even * (items.length - 1)) * 100) / 100;
        set({ items: next });
      },
      setName: (name) => set({ name }),
      setDesign: (design) => set({ design }),
      reset: () => set({ items: [], name: "", design: null }),
    }),
    { name: "rb-case-builder", storage: createJSONStorage(() => sessionStorage) },
  ),
);
