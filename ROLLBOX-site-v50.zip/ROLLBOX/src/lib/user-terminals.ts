// ============ USER TERMINALS (Task 23) — DO NOT auto-regenerate ============
// The overlay the CASE EDITOR writes (ROLLBOX-TERMINALS v1 export) lands here
// via scripts/import-terminals.mjs. Empty = the site runs the generated
// DEFAULT_TERMINALS in src/lib/terminals.ts.

import type { TerminalDef } from "./terminals";

export const USER_TERMINALS: TerminalDef[] = [];
