// ============ ROLLDROP — the site-wide ultra-rare bonus drop (Task 45) ============
// USER SPEC (R38): every case opening — solo OR any player's pull in a
// battle, standard or community-built — carries an independent 1.75% chance
// to hit a ROLLDROP. It does NOT change the case's skin odds (the case is
// not 101.75%). When it hits, THAT player gets ONE EXTRA ROUND in the same
// case, drawn ONLY from the case's rare skins (every skin whose hit chance
// is below 5%).
// On the hit: the reel stops → glow → that player's reel strip turns WHITE
// from its center (fast) → the whole screen flashes white for about a second
// with the raredrop.png art → during that second the extra reel is already
// spinning (its duration = a normal spin + 1s to compensate the white beat).

import type { CaseDef } from "./cases";

/** Chance per case opening / per player pull (USER SPEC R38: 1.75% — 1 in ~57). */
export const ROLLDROP_CHANCE = 0.0175;

/**
 * USER SPEC (R37): EVERY case rolls at the same flat site-wide chance — the
 * stored per-case values (builder cases 0.725%, community cases 0) stay
 * IGNORED. USER SPEC (R38): the owner's TEST box is the ONE exception — it
 * comes back at 70% through this explicit id map (nothing else may deviate;
 * the stored `CaseDef.rolldropChance` field remains retired for storage
 * compatibility). This function is the single source every path (solo
 * opener, /api/open, battles, community cases) funnels through.
 */
const ROLLDROP_CHANCE_OVERRIDES: Record<string, number> = {
  "test-rolldrop": 0.7, // the TEST case — 70% ROLLDROP (owner's testing tool)
};

export function rolldropChanceOf(caseDef: CaseDef): number {
  return ROLLDROP_CHANCE_OVERRIDES[caseDef.id] ?? ROLLDROP_CHANCE;
}

/** A skin qualifies for the ROLLDROP round when its hit chance is below this. */
export const ROLLDROP_RARE_BELOW_PCT = 5;

/**
 * Reel winner marker — when a ROLLDROP hits, the reel's winning tile is NOT a
 * skin: it renders the raredrop.png art instead (USER SPEC: the ROLLDROP
 * REPLACES the skin that came out). Both the solo opener and the battle reel
 * special-case this id.
 */
export const ROLLDROP_MARKER = "__rolldrop__";

/**
 * The case's RARE pool — every item whose drop chance is below 5%
 * (USER SPEC: "כל סקין שמתחת ל5% פגיעה"). Falls back to the 3 rarest items
 * when a case somehow has nothing below the threshold.
 */
export function rareCaseOf(caseDef: CaseDef): CaseDef {
  const total = caseDef.items.reduce((s, i) => s + i.weight, 0);
  let rare = caseDef.items.filter((i) => total > 0 && (i.weight / total) * 100 < ROLLDROP_RARE_BELOW_PCT);
  if (rare.length === 0) {
    rare = [...caseDef.items].sort((a, b) => a.weight - b.weight).slice(0, Math.min(3, caseDef.items.length));
  }
  return { ...caseDef, items: rare };
}

/**
 * Roll for a ROLLDROP at the given per-case chance (defaults to the site-wide
 * 5%). E2E/test hook: localStorage "rb-rolldrop-force" = "1" forces a
 * guaranteed hit so the flow can be verified end-to-end.
 */
export function maybeRollDrop(chance: number = ROLLDROP_CHANCE): boolean {
  if (typeof window !== "undefined") {
    try {
      if (window.localStorage.getItem("rb-rolldrop-force") === "1") return true;
    } catch {
      /* private mode — ignore */
    }
  }
  return Math.random() < chance;
}
