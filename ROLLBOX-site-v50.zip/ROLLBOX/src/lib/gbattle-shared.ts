// ============ CLIENT-SAFE shared types + timing for global battles ============
// Imported by BOTH the server engine (src/lib/server/gbattles.ts) and the
// room view — pure types/constants only, no DB, no server imports.

import type { BattlePlayer, BattlePotRule, BattleResult, BattleType, BattleMode, RoundSlot } from "@/lib/battles";
export type { RoundSlot };

// shared-clock timing — USER SPEC (Task 59): the schedule is built from the
// reel lengths the room view ACTUALLY plays (the old 2600/400 math was shorter
// than the other-seat reels, so the round flipped before their reel landed and
// the pull was never shown). The longest reel is always a NON-"you" seat
// (spectators / the other clients), never the fast local one.
// USER SPEC (Task 177): "adopt the case reel system AS-IS into battles" —
// every battle reel now plays the EXACT case-opener pacing (CaseOpener
// SPIN_MS = 6400 with the power-4 crawl ending) and all seats lock TOGETHER
// like a multi-reel case opening (stagger 0), instead of the old quick
// per-seat staggered spins.
export const REEL_YOU_MS = 6400; // your own reel — same as the case opener
export const REEL_OTHER_MS = 6400; // every seat plays the case reel length
export const REEL_STAGGER_MS = 0; // all seats lock together, case-style
export const RD_HOLD_MS = 1000; // raredrop: the bonus reel's own extra second
// Task 143→149 (USER SPEC): the impact CUTSCENE VIDEO IS DELETED (Task 149:
// "delete the rolldrop video, keep only the image") — between the main reel
// and the bonus reel there is now just a SHORT MARKER BEAT: the reel sits on
// the frameless raredrop image for RD_BEAT_MS, then the rare reel opens.
// (RD_HOLD_MS stays the bonus's own +1s.)
export const RD_BEAT_MS = 500;
export const ROUND_BEAT_MS = 250; // breather between rounds

/**
 * USER SPEC (Task 66, "the server must WAIT for every participant"): a reel
 * MOUNTS only when its round's pulls reach the viewer — and the publish
 * heartbeat runs on a ~700ms grid, plus fetch + render on top. A mount that
 * lands after the round flip cut the spin mid-air ("players 3 and 4 almost
 * land and the round continues"). Every scheduled round now stays open this
 * much longer than its longest reel, absorbing the worst-case publish delay.
 */
export const REVEAL_PAD_MS = 1000;

/** Longest reel a room of n seats can play (seat n-1 as a non-"you" viewer).
 *  USER SPEC (R40): FAST MODE is DELETED — every battle plays the normal
 *  case-style pacing, so the schedule math is the normal math, always. */
export function maxReelMs(seatCount: number): number {
  return REEL_OTHER_MS + Math.max(0, seatCount - 2) * REEL_STAGGER_MS;
}

export type GlobalStatus = "waiting" | "playing" | "finished" | "cancelled";

/** One seat in the room — a registered player or a site bot. */
export interface Seat {
  key: string; // playerId for humans, bot_<n> for bots
  name: string;
  avatar?: string;
  provider?: string;
  team: 0 | 1;
  side?: 0 | 1;
  color: number;
  isBot: boolean;
  paid: number; // entry actually charged (0 for bots)
  joinedAt: number;
  /** USER SPEC (Task 66): this human pressed CALL BOTS — "PLAY WITH BOTS".
   *  Bots fill the room only when EVERY seated human has voted. */
  botsVote?: boolean;
}

/** What the clients see — the original Battle shape, multiplayer-safe. */
export interface GlobalBattle {
  id: string;
  code: string;
  hostId: string;
  entry: number;
  type: BattleType;
  mode: BattleMode;
  /** USER SPEC (R40): FAST MODE was DELETED from battles — every room plays
   *  the normal case-style reel pacing. No toggle, no flag, no fast math. */
  potRule: BattlePotRule;
  maxPlayers: number;
  teamMode: boolean;
  /** USER SPEC (Task 67): PRIVATE — hidden from the lobby, code-only entry. */
  isPrivate: boolean;
  /** USER SPEC (Task 67): true when this viewer is NOT allowed to see the
   *  private room (not seated) — every other field except the basics is blank. */
  redacted: boolean;
  rounds: string[];
  status: GlobalStatus;
  createdAt: number;
  startedAt: number | null;
  totalMs: number | null;
  serverNow: number;
  players: BattlePlayer[];
  colorOrder: number[];
  schedule: RoundSlot[] | null;
  results: BattleResult[] | null; // pulls gated per round; totals = visible only
  winnerIds: string[] | null;
  tieIds: string[] | null;
  potTotal: number | null;
  /** per-player payout by the pot rules (winner take-all / 2v2 split / shared cut) */
  take: Record<string, number> | null;
  // SERVER PROVABLY FAIR (Task 151): fairHash = SHA-256(seed+salt) published
  // from the moment the battle starts; the raw fairSeed + fairSalt arrive
  // ONLY after the settle (fairRevealed) — then anyone can re-derive every
  // pull: float = HMAC(fairSeed, `${code}:${nonce}`), nonce = 2*pullIndex
  // (gate) / 2*pullIndex+1 (item), pullIndex = round*seatCount + seatIndex.
  fairHash: string | null;
  fairSeed: string | null;
  fairSalt: string | null;
  fairRevealed: boolean;
}
