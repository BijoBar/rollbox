/** The shipped catalog + the Steam stock store images in compact forms:
 *  full URLs pass through untouched, shorthand prefixes expand to their CDN
 *  hosts (see scripts/slim-catalog.mjs — ~600KB of repetition removed):
 *    ~1  → community.akamai.steamstatic.com/economy/image/  (Steam icon_url)
 *    ~2  → cdn.steamstatic.com/apps/730/icons/
 *    ~3  → ByMykel/counter-strike-image-tracker (panorama renders)
 *  EVERY surface that renders an inventory snapshot or a stock item MUST go
 *  through this helper — a raw "~1…" src is a broken relative URL and the
 *  browser silently falls back to the generic SVG art (the exact bug USER
 *  SPEC Task 26 reports: skins taken into the INVENTORY lose their image). */
export function expandImg(img: string | null | undefined): string | null {
  if (!img) return null;
  if (img.startsWith("~1")) return "https://community.akamai.steamstatic.com/economy/image/" + img.slice(2);
  if (img.startsWith("~2")) return "https://cdn.steamstatic.com/apps/730/icons/" + img.slice(2);
  if (img.startsWith("~3"))
    return "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/" + img.slice(2);
  return img;
}
