// ============ ROLLBOX data layer ============
// Rarity system + skin/case registries. The base content is auto-generated
// from the official CS2 skin database with real market prices — re-run
// scripts/build-content.mjs to regenerate. Task 76: the user's own
// RB-101..RB-109 (src/lib/user-cases.ts) are merged OVER the generated cases
// by code, and USER_SKINS / USER_SKIN_IMAGES extend the registries.

import { GEN_SKINS, GEN_CASES } from "./generated-cases";
import { USER_SKINS, USER_CASES, USER_ITEM_VALUES } from "./user-cases";
import { LEVEL_CASES } from "./level-cases";
import { skinWearValue, WEAR_BY_ID, type WearId } from "./wear";
import { eventActive } from "./event";

// re-export the wear vocabulary so data-layer consumers import from one place
export type { WearId } from "./wear";
export { WEARS, WEAR_BY_ID, WEAR_IDS } from "./wear";

export type Rarity =
  | "consumer"
  | "milspec"
  | "restricted"
  | "classified"
  | "covert"
  | "contraband";

export const RARITY_META: Record<
  Rarity,
  { label: string; color: string; order: number }
> = {
  consumer: { label: "Consumer", color: "#b0c3d9", order: 0 },
  milspec: { label: "Mil-Spec", color: "#4b69ff", order: 1 },
  restricted: { label: "Restricted", color: "#8847ff", order: 2 },
  classified: { label: "Classified", color: "#d32ce6", order: 3 },
  covert: { label: "Covert", color: "#eb4b4b", order: 4 },
  contraband: { label: "★ Rare Special", color: "#ffd700", order: 5 },
};

/** USER SPEC (Task 129): NEW backdrop artwork set behind each skin — the
 *  user-supplied ROLLBOX emblem images (metallic star + logo over a smoky
 *  rarity-color backdrop, 1080x1350 RGBA; served from /public/rarity/ under
 *  the user's own filenames). Replaces the Task-128 empty state (and the old
 *  Task-89/89b ECLIPSE set deleted in between). <RarityBackdrop /> renders
 *  the artwork with background-size:contain, so the 4:5 portrait scales
 *  cleanly inside every call-site box. */
export const RARITY_DICE: Partial<Record<Rarity, string>> = {
  consumer: "/rarity/rollboxconsumer.png",
  milspec: "/rarity/rollboxmilspec.png",
  restricted: "/rarity/rollboxrestricted.png",
  classified: "/rarity/rollboxclassified.png",
  covert: "/rarity/rollboxcovert.png",
  contraband: "/rarity/rollboxgold.png",
};

export type WeaponKind =
  | "ak"
  | "m4"
  | "awp"
  | "galil"
  | "p90"
  | "mp9"
  | "deagle"
  | "glock"
  | "usp"
  | "p250"
  | "karambit"
  | "bayonet"
  | "butterfly"
  | "gloves"
  | "sticker"
  | "charm"
  | "agent"
  | "patch";

export interface Skin {
  id: string;
  name: string; // display name (weapon | skin)
  weapon: WeaponKind; // art silhouette kind (SVG fallback)
  rarity: Rarity;
  value: number; // in Rollboxcoins (the site currency)
  colors: [string, string]; // gradient colors for the fallback weapon art
  wear?: string; // exterior label for wear-specific items (e.g. "Minimal Wear")
}

export interface CaseItem {
  skinId: string;
  weight: number; // relative weight (out of 100)
  /** USER SPEC (Task 72): the exterior this item comes in. Absent = the
   *  skin's base listing (legacy items before the wear system). */
  wear?: WearId;
  /** Manual coin-value override (the case editor's typed value wins over the
   *  market table). Absent = market wear price, else the skin's base value. */
  value?: number;
}

export interface CaseDef {
  id: string;
  code: string; // unique public case ID, e.g. "RB-101"
  name: string;
  subtitle: string;
  // USER SPEC: "level" = the free DAILY cases (LEVEL 10..100) — never sold,
  // never pickable for battles, one free open per 24h at the player's tier.
  // USER SPEC (EVENTS): "event" = the limited EVENT case — a regular case
  // while the event window is live (event.ts), gone from the pickers after it.
  kind: "standard" | "farm" | "level" | "event";
  tierLabel: string; // badge text, e.g. "ELITE" / "FARM" / "FREE"
  price: number;
  /** Level cases only: the level that unlocks the free daily open. */
  requiredLevel?: number;
  tierColor: string; // main glow color
  tierColor2: string; // secondary gradient color
  items: CaseItem[];
  /** Optional per-case ROLLDROP chance override (site-wide default: 0.095%). */
  rolldropChance?: number;
  /** USER SPEC (Task 142): set on player-built COMMUNITY cases — picks the
   *  uploaded crate artwork (communitycasered/white/yellow.png). */
  communityDesign?: "red" | "white" | "yellow";
  /** SECURITY/QOL (Task 167): hidden cases keep working by DIRECT LINK
   *  (/case/<id> and the open/resolve routes) but never appear in any public
   *  listing, the battles picker or search. RB-TST is hidden: 70% ROLLDROP
   *  odds are for testing, not for players. */
  hidden?: boolean;
}

// Task 76: USER_SKINS carries the skins the user's items need that the
// generated registry doesn't have; existing ids keep their generated entry
// (case items always carry their own cent-precise value override anyway).
export const SKINS: Record<string, Skin> = { ...GEN_SKINS, ...USER_SKINS };

// Task 72: the demo case now exercises the WEAR system — every weapon skin
// carries an explicit exterior; the credit lands at that wear's market price.
// Task 114: retuned from the user's ROLLBOX-CASES v1 export (price 28.88) —
// keep in sync with scripts/user-cases-spec.jsonl RB-TST
// (scripts/import-user-cases.mjs validates this block on every run).
// USER SPEC (R38): the TEST case's ROLLDROP comes back at 70% — the stored
// `rolldropChance` below is documentation only; the LIVE value is the
// ROLLDROP_CHANCE_OVERRIDES map in lib/rolldrop.ts (the R37 flat-rate rule
// ignores stored fields).
const TEST_CASE: CaseDef = {
  id: "test-rolldrop",
  code: "RB-TST",
  name: "TEST",
  subtitle: "Temporary demo case — 70% ROLLDROP chance per opening.",
  kind: "standard",
  tierLabel: "TEST",
  price: 28.88,
  tierColor: "#22c55e",
  tierColor2: "#bef264",
  rolldropChance: 0.7,
  hidden: true, // Task 167 (USER SPEC): off every public surface; /case/test-rolldrop still opens for testing
  items: [
    // Sticker | Dragon — 34%
    { skinId: "sticker-dragon", weight: 34, value: 0.3 }, // stickers have no exterior
    // Nova | Rising Sun (FN) — 33%
    { skinId: "nova-rising-sun", weight: 33, value: 3.5, wear: "FN" },
    // Dual Berettas | Cartel (FN) — 25%
    { skinId: "dual-berettas-cartel", weight: 25, value: 8.5, wear: "FN" },
    // AK-47 | Asiimov (FN) — 4%
    { skinId: "ak-47-asiimov", weight: 4, value: 400, wear: "FN" },
    // AWP | Asiimov (FT) — 2.5%
    { skinId: "awp-asiimov", weight: 2.5, value: 118.9, wear: "FT" }, // AWP Asiimov: no MW in-game (min_float 0.18)
    // M4A4 | Asiimov (FT) — 1%
    { skinId: "m4a4-asiimov", weight: 1, value: 231.9, wear: "FT" },
    // P90 | Asiimov (FN) — 0.5%
    { skinId: "p90-asiimov", weight: 0.5, value: 262.8, wear: "FN" },
  ],
};

// USER SPEC (EVENTS): the limited EMERALD DROP event case — REGULAR catalog
// rewards only (no special items), themed to the event's green-gold artwork.
// Price follows the house formula like every case: expected payout / 0.85
// (EV = 9.6221 → 9.6221 / 0.85 = 11.32). While the event is live it opens
// through the regular flow, counts up the event leaderboard (every coin
// wagered) and joins battles exactly like the COMMUNITY cases; when the
// window closes the server refuses it and the pickers hide it automatically.
export const EVENT_CASE: CaseDef = {
  id: "event-emerald-drop",
  code: "RB-EVT",
  name: "Emerald Drop",
  subtitle: "Limited event crate — green glow, golden odds.",
  kind: "event",
  tierLabel: "EVENT",
  price: 11.32,
  tierColor: "#10b981",
  tierColor2: "#facc15",
  items: [
    // Sticker | Fade Lethal — 27.6%
    { skinId: "sticker-fade-lethal", weight: 27.6, value: 0.7 },
    // AK-47 | Emerald Pinstripe — 25.6%
    { skinId: "ak-47-emerald-pinstripe", weight: 25.6, value: 2 },
    // AK-47 | Crossfade — 11.5%
    { skinId: "ak-47-crossfade", weight: 11.5, value: 2 },
    // M4A4 | Faded Zebra — 12%
    { skinId: "m4a4-faded-zebra", weight: 12, value: 8.3 },
    // Zeus x27 | Dragon Snore — 8%
    { skinId: "zeus-x27-dragon-snore", weight: 8, value: 8.6 },
    // P2000 | Imperial Dragon — 6%
    { skinId: "p2000-imperial-dragon", weight: 6, value: 12.3 },
    // MAC-10 | Amber Fade — 4%
    { skinId: "mac-10-amber-fade", weight: 4, value: 15.1 },
    // USP-S | Printstream — 2.5%
    { skinId: "usp-s-printstream", weight: 2.5, value: 34.4 },
    // AWP | Printstream — 1.2%
    { skinId: "awp-printstream", weight: 1.2, value: 42.4 },
    // P90 | Emerald Dragon — 0.8%
    { skinId: "p90-emerald-dragon", weight: 0.8, value: 114.9 },
    // ★ Shadow Daggers | Gamma Doppler (Emerald) — 0.5%
    { skinId: "shadow-daggers-gamma-doppler", weight: 0.5, value: 107.7 },
    // ★ Karambit | Tiger Tooth — 0.3% (the golden knife from the artwork)
    { skinId: "karambit-tiger-tooth", weight: 0.3, value: 944.8 },
  ],
};

// Task 76: the USER CASES overlay — the user's own case definitions (imported
// from the CASE EDITOR pipeline) replace the generated cases of the same code;
// every other generated case is kept. Task 93: overlay codes the generated
// catalog doesn't know yet (brand-new cases edited in the CASE EDITOR, e.g.
// RB-121+) are APPENDED too — without this the site silently dropped them.
// USER SPEC (LEVEL cases): LVL-* exports from the editor are NOT appended —
// they overlay the daily level-cases.ts definitions as CONTENT-ONLY patches
// (items + optional ROLLDROP); the daily shell (id/name/price/kind/level/
// colors) always stays the system's, so the 24h free-case engine can't break.
const USER_CASE_BY_CODE = new Map(USER_CASES.map((c) => [c.code, c]));
const LVL_CODE = /^LVL-(\d+)$/;
const USER_LVL_BY_CODE = new Map(
  USER_CASES.filter((c) => LVL_CODE.test(c.code)).map((c) => [c.code, c]),
);
const MERGED_LEVEL_CASES: CaseDef[] = LEVEL_CASES.map((lvl) => {
  const u = USER_LVL_BY_CODE.get(lvl.code);
  if (!u) return lvl;
  return {
    ...lvl,
    items: u.items,
    ...(u.rolldropChance != null ? { rolldropChance: u.rolldropChance } : {}),
  };
});
const OVERLAY_ONLY = USER_CASES.filter(
  (c) => !GEN_CASES.some((g) => g.code === c.code) && !LVL_CODE.test(c.code),
);

const MERGED_CASES: CaseDef[] = [
  ...GEN_CASES.map((c) => USER_CASE_BY_CODE.get(c.code) ?? c),
  ...OVERLAY_ONLY,
];
// stable numeric order so a new RB-121 slots in between RB-120 and the farm
// cases instead of landing after them (non-RB-nnn codes sink to the end)
const codeNum = (code: string): number => {
  const m = /^RB-(\d+)$/.exec(code);
  return m ? Number(m[1]) : Number.MAX_SAFE_INTEGER;
};
MERGED_CASES.sort((a, b) => codeNum(a.code) - codeNum(b.code));

export const CASES: CaseDef[] = [...MERGED_CASES, TEST_CASE, EVENT_CASE, ...MERGED_LEVEL_CASES];
// Task 167 (USER SPEC): hidden cases (RB-TST) leave every public listing —
// home grids, the battles picker and search — while CASES itself stays the
// complete registry that the direct-link page and the resolve/open routes use.
export const FARM_CASES: CaseDef[] = CASES.filter((c) => c.kind === "farm");
export const STANDARD_CASES: CaseDef[] = CASES.filter((c) => c.kind === "standard" && !c.hidden);
/** USER SPEC: the 10 free DAILY cases (LEVEL 10..100) — home page "Special for you". */
export const LEVEL_CASES_ALL: CaseDef[] = CASES.filter((c) => c.kind === "level");
/** Battles never accept the free daily cases (price 0 would be a free-entry
 *  exploit). The EVENT case joins while its window is live and drops out of
 *  every picker the moment it ends (existing rooms keep their rounds). */
export const BATTLE_CASES: CaseDef[] = CASES.filter(
  (c) => c.kind !== "level" && !c.hidden && !(c.kind === "event" && !eventActive()),
);

// ---------- wear-aware item helpers (Task 72) ----------

/** The coin value of a case item: explicit override > market wear price >
 *  wear factor estimate > the skin's base value. */
export function caseItemValue(item: CaseItem): number {
  if (item.value != null && Number.isFinite(item.value)) return item.value;
  const skin = SKINS[item.skinId];
  if (!skin) return 0;
  if (item.wear) return skinWearValue(item.skinId, item.wear, skin.value).value;
  return skin.value;
}

/** The skin as it should DISPLAY for this item — base skin, with the wear
 *  label and the wear-adjusted value baked in when the item carries a wear. */
export function caseItemSkin(item: CaseItem): Skin {
  const skin = SKINS[item.skinId];
  if (!skin) return { id: item.skinId, name: item.skinId, weapon: "ak", rarity: "consumer", value: 0, colors: ["#8882a8", "#1a1426"] };
  if (!item.wear) return item.value != null ? { ...skin, value: item.value } : skin;
  return {
    ...skin,
    wear: WEAR_BY_ID[item.wear].label,
    value: caseItemValue(item),
  };
}

/** A skin viewed at a specific wear (display object: label + adjusted value). */
export function skinWithWear(skinId: string, wear?: WearId): Skin {
  const skin = SKINS[skinId];
  if (!skin) return caseItemSkin({ skinId, weight: 0 });
  // Task 76: USER case items pin their own cent-precise value — the market
  // wear table never overrides the number the case editor typed. (Credits are
  // always case-scoped via caseItemValue; this aligns the item-less DISPLAY
  // paths: winner chips, reel locks, live feeds.)
  const pinned = wear ? USER_ITEM_VALUES[`${skinId}|${wear}`] : USER_ITEM_VALUES[`${skinId}|`];
  if (pinned != null) {
    return { ...skin, ...(wear ? { wear: WEAR_BY_ID[wear].label } : {}), value: pinned };
  }
  if (!wear) return skin;
  return { ...skin, wear: WEAR_BY_ID[wear].label, value: skinWearValue(skinId, wear, skin.value).value };
}

export interface CaseRoll {
  item: CaseItem;
  skin: Skin; // display skin (wear label + adjusted value when applicable)
}

/** Weighted draw of one case ITEM (the same odds the reels always used). */
export function rollCaseItem(caseDef: CaseDef): CaseRoll {
  const total = caseDef.items.reduce((s, i) => s + i.weight, 0);
  let r = Math.random() * total;
  for (const item of caseDef.items) {
    r -= item.weight;
    if (r <= 0) return { item, skin: caseItemSkin(item) };
  }
  const last = caseDef.items[caseDef.items.length - 1];
  return { item: last, skin: caseItemSkin(last) };
}

export function rollCase(caseDef: CaseDef): Skin {
  return rollCaseItem(caseDef).skin;
}

/** Drop chance (%) of a specific skin inside a case — used to gate rare-pull FX. */
export function oddsPct(caseDef: CaseDef, skinId: string): number {
  const total = caseDef.items.reduce((s, i) => s + i.weight, 0);
  const w = caseDef.items.find((i) => i.skinId === skinId)?.weight ?? 0;
  return total > 0 ? (w / total) * 100 : 0;
}

// Task 76: cent-precise display — user case items carry values like 8.85 or
// 0.19, and the old toFixed(1) rounded them to "8.9" / "0.2".
// USER SPEC: NO "K"/"M" abbreviations anywhere — full amounts with comma
// grouping: integers render "10,000" / "1,000", fractional amounts always
// show exactly 2 decimals with a dot and the trailing zero kept: "10,000.10".
export function formatCoins(n: number): string {
  if (!Number.isFinite(n)) return "0";
  const cents = Math.round(n * 100) / 100;
  if (Number.isInteger(cents)) return cents.toLocaleString("en-US");
  return cents.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/**
 * Format a drop-chance percentage for display.
 * Guarantees the string "100" only for a true 100% — a 99.5% item shows
 * "99.50" (never rounds up to "100").
 * USER SPEC (Task 100b): the odds chip shows the EXACT chance — the old
 * tiered toFixed() rounded editor-typed weights (27.5 → "28", 10.55 → "11",
 * 0.275 → "0.28", 0.175 → "0.17"), so the case page disagreed with the
 * CASE EDITOR export the user pasted. Now: round away float noise only
 * (3 decimals covers every weight the editor accepts) and strip trailing
 * zeros — 27.5 stays "27.5", 10.55 stays "10.55".
 * USER SPEC: tiny odds (< 0.01%) never collapse to "0%" — decimals extend
 * (cap 10) until the first significant digit survives, then trailing zeros
 * are trimmed: 0.000013 → "0.000013", 0.0000001 → "0.0000001".
 */
export function formatOdds(pct: number): string {
  if (pct <= 0) return "0";
  if (pct >= 99.995) return "100";
  if (pct > 99) return pct.toFixed(2); // 99.50 / 99.55
  if (pct >= 0.01) {
    const r = Math.round(pct * 1000) / 1000;
    return String(r);
  }
  const digits = Math.min(10, Math.max(4, Math.ceil(-Math.log10(pct)) + 1));
  return pct.toFixed(digits).replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
}
