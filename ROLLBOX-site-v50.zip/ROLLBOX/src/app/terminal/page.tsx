import type { Metadata } from "next";
import { TerminalView } from "@/components/rollbox/TerminalView";

export const metadata: Metadata = {
  title: "Terminal | ROLLBOX",
  description:
    "Five weapon dealers on one gray-market terminal. Every dealer has his own minimum deal — pay it, get 5 skin offers and approve exactly one. The pool's odds are yours to study.",
};

// USER SPEC (Task 23+24): the TERMINAL — 5 dealers (min 1/10/30/70/300, max
// 50/100/500/1000/5000), each with a 10-skin % pool, 5 offers per deal,
// exactly ONE approvable. Gray-screen page with the tablet device UI.
export default function TerminalPage() {
  return <TerminalView />;
}
