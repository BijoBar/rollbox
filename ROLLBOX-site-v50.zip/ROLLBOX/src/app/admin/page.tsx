import type { Metadata } from "next";
import { AdminView } from "@/components/rollbox/AdminView";

export const metadata: Metadata = {
  title: "Admin | ROLLBOX",
  robots: { index: false, follow: false },
};

// USER SPEC (Task 22): the ADMIN PANEL page — reachable only through the red
// TopBar shield, which renders ONLY for players the DATABASE marks isAdmin.
// The page itself re-checks the session and walls non-admins out.
export default function AdminPage() {
  return <AdminView />;
}
