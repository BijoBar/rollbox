import type { Metadata } from "next";
import { BattleCreateView } from "@/components/rollbox/BattleCreateView";

export const metadata: Metadata = {
  title: "Create a Battle — ROLLBOX",
  description:
    "Pick the battle format (1v1, 1v1v1, 1v1v1v1, 2v2), stack the cases and open your room.",
};

export default function NewBattlePage() {
  return <BattleCreateView />;
}
