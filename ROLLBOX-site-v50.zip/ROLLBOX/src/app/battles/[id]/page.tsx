import type { Metadata } from "next";
import { BattleRoomRouter } from "@/components/rollbox/GlobalBattleRoomView";

export const metadata: Metadata = {
  title: "Battle Room — ROLLBOX",
  description: "The battle room fills up, then every round opens live. Winner takes the total value of every skin that drops.",
};

export default async function BattleRoomPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <BattleRoomRouter id={id} />;
}
