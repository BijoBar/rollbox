import type { Metadata } from "next";
import { BattleLobbyView } from "@/components/rollbox/BattleLobbyView";
import { PageBackdrop } from "@/components/rollbox/PageBackdrop";

export const metadata: Metadata = {
  title: "Case Battles — ROLLBOX",
  description:
    "Join open case battles or create your own: same cases, same rounds, winner takes every skin that drops. Your rolls are provably fair.",
};

export default function BattlesPage() {
  return (
    <>
      {/* USER SPEC (Task 170): the uploaded battle artwork as the page
          background at 50% opacity, over the corridor */}
      <PageBackdrop src="/rollboxcasebattle.jpg" />
      <BattleLobbyView />
    </>
  );
}
