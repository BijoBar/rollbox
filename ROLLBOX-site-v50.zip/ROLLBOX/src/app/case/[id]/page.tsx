import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CASES } from "@/lib/cases";
import { findCommunityCase } from "@/lib/server/community-cases";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { CaseView } from "@/components/rollbox/CaseView";

export function generateStaticParams() {
  return CASES.map((c) => ({ id: c.id }));
}

// USER SPEC (Task 142): COMMUNITY cases live in the DB, not in the static
// catalog — unknown ids fall through to a DB lookup (a "cc_*" id) and render
// on demand through the exact same CaseView.
export const dynamicParams = true;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const caseDef = CASES.find((c) => c.id === id) ?? (await findCommunityCase(id));
  if (!caseDef) return { title: "Case Not Found | ROLLBOX" };
  return {
    title: `${caseDef.name} (${caseDef.code}) | ROLLBOX`,
    description: `${caseDef.subtitle} — open for ${caseDef.price} USD with provably fair odds.`,
  };
}

export default async function CasePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const caseDef = CASES.find((c) => c.id === id) ?? (await findCommunityCase(id));
  if (!caseDef) notFound();

  return (
    <SiteShell>
      <CaseView caseDef={caseDef} />
    </SiteShell>
  );
}
