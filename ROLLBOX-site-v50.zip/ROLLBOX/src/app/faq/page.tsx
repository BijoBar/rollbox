import type { Metadata } from "next";
import { CircleHelp } from "lucide-react";
import { ComingSoon } from "@/components/rollbox/ComingSoon";

export const metadata: Metadata = {
  title: "FAQ | ROLLBOX",
  description: "Frequently asked questions — coming soon.",
};

// USER SPEC (Task 29): FAQ is an empty placeholder page for now.
export default function FaqPage() {
  return (
    <ComingSoon
      title="FAQ"
      icon="help"
      blurb="Answers to the most common questions are on the way."
    />
  );
}
