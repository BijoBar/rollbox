import type { Metadata } from "next";
import { MissionsBoard } from "@/components/rollbox/MissionsBoard";

export const metadata: Metadata = {
  title: "Missions | ROLLBOX",
  description:
    "Ten ROLLBOX missions — battles, upgrader streaks, farm cases, deposits and more. Complete the steps, earn the rewards.",
};

// Task 31 (USER SPEC): the real MISSIONS board replaced the COMING SOON page.
// Task 32 (USER SPEC): the board now renders each player's LIVE progress —
// the counters live IN THE DATABASE on the player's own row (Player.missions)
// and this page is a thin server shell around the client board, which fetches
// /api/missions (the player's stored state) and derives every step bar with
// the shared src/lib/missions-progress.ts mapping.
export default function MissionsPage() {
  return <MissionsBoard />;
}
