import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { SettingsView } from "@/components/rollbox/SettingsView";

export const metadata: Metadata = {
  title: "Settings | ROLLBOX",
  description:
    "Every ROLLBOX setting in one organized place — email, language, sound and the self-care tools. No sign out here, settings only.",
};

// USER SPEC (Task 83): the dedicated SETTINGS page — the profile's SETTINGS
// button lands here. All the settings, organized; SIGN OUT deleted from the
// settings completely (the page is not a second profile).
export default function SettingsPage() {
  return (
    <SiteShell>
      <SettingsView />
    </SiteShell>
  );
}
