import type { Metadata } from "next";
import Link from "next/link";
import { ShieldAlert, Zap, ChevronRight } from "lucide-react";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { DISCORD_INVITE } from "@/lib/site";
import { DiscordIcon } from "@/components/rollbox/DiscordIcon";
import { TOS_SECTIONS, TOS_UPDATED, TOS_VERSION } from "./content";

export const metadata: Metadata = {
  title: "Terms of Service | ROLLBOX",
  description:
    "ROLLBOX Terms of Service — the binding legal agreement governing your use of the Site: eligibility, wagering rules, risk of loss, the coin Exchange and Inventory, KYC/AML, limitation of liability, indemnification and dispute resolution.",
};

export default function TosPage() {
  return (
    <SiteShell>
      <div className="relative">
        
        <div className="relative mx-auto max-w-3xl px-4 pb-20 pt-10">
          {/* header */}
          <div className="text-center">
            <p className="font-display text-sm font-bold tracking-[0.3em] text-amber-300/80">
              LEGAL
            </p>
            <h1 className="mt-2 text-4xl font-black text-white md:text-5xl">
              Terms of <span className="text-gradient-neon">Service</span>
            </h1>
            <p className="mt-3 text-sm text-white/45">
              Last updated: {TOS_UPDATED} • Version {TOS_VERSION}
            </p>
          </div>

          {/* risk notice */}
          <div className="mt-8 rounded-2xl border border-red-500/35 bg-red-500/[0.07] p-5">
            <div className="flex items-start gap-3">
              <ShieldAlert className="mt-0.5 h-6 w-6 shrink-0 text-red-400" />
              <div>
                <p className="font-display text-sm font-black tracking-wide text-red-300">
                  IMPORTANT — REAL-MONEY GAMING NOTICE
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-white/70">
                  ROLLBOX offers games of chance. Outcomes are random and there is{" "}
                  <span className="font-bold text-white">no way to win every time</span> — you can
                  lose the coins you wager. Never wager with money you cannot afford to lose, never
                  chase losses, and take a break if gaming stops being fun. Gaming can be
                  addictive — play responsibly. By using the Site you confirm you are 18 or older
                  and accept these Terms in full, including the binding arbitration and class
                  action waiver.
                </p>
              </div>
            </div>
          </div>

          {/* table of contents */}
          <nav
            aria-label="Table of contents"
            className="mt-8 grid grid-cols-1 gap-1.5 rounded-2xl border border-white/10 bg-white/[0.03] p-4 sm:grid-cols-2"
          >
            {TOS_SECTIONS.map((s, i) => (
              <a
                key={s.id}
                href={`#${s.id}`}
                className="flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[13px] font-semibold text-white/60 transition-colors hover:bg-white/5 hover:text-white"
              >
                <span className="font-display w-5 shrink-0 text-right text-[11px] font-black text-violet-300/80">
                  {i + 1}
                </span>
                <span className="truncate">{s.title}</span>
                <ChevronRight className="ml-auto h-3.5 w-3.5 shrink-0 text-white/25" />
              </a>
            ))}
          </nav>

          {/* sections */}
          <div className="mt-10 space-y-9">
            {TOS_SECTIONS.map((s, i) => (
              <section key={s.id} id={s.id} aria-label={s.title} className="scroll-mt-24">
                <h2 className="flex items-center gap-3 text-xl font-black text-white">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-violet-400/30 bg-violet-400/10">
                    <s.icon className="h-4.5 w-4.5 text-violet-300" />
                  </span>
                  <span className="font-display">
                    <span className="text-white/40">{i + 1}.</span> {s.title}
                  </span>
                </h2>
                <div className="mt-3 space-y-3 pl-0 md:pl-12">
                  {s.clauses.map((c, j) =>
                    c.cta ? (
                      <a
                        key="cta"
                        href={DISCORD_INVITE}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-2 inline-flex items-center gap-2 rounded-xl bg-[#5865F2] px-5 py-2.5 text-sm font-black text-white shadow-[0_0_22px_rgba(88,101,242,0.5)] transition-all hover:brightness-110"
                      >
                        <DiscordIcon className="h-4.5 w-4.5" />
                        Join the Discord Server
                      </a>
                    ) : c.warn ? (
                      <div
                        key={j}
                        className="rounded-xl border border-amber-400/35 bg-amber-400/[0.07] px-4 py-3"
                      >
                        <p className="text-[13px] font-bold leading-relaxed text-amber-100/90">
                          {c.p}
                        </p>
                      </div>
                    ) : (
                      <div key={j} className="space-y-2">
                        {c.h && (
                          <h3 className="pt-1 text-sm font-black tracking-wide text-white/85">
                            {c.h}
                          </h3>
                        )}
                        {c.p && (
                          <p className="text-sm leading-relaxed text-white/60">{c.p}</p>
                        )}
                        {c.ul && (
                          <ul className="space-y-1.5">
                            {c.ul.map((item) => (
                              <li
                                key={item.slice(0, 32)}
                                className="flex gap-2.5 text-sm leading-relaxed text-white/60"
                              >
                                <span
                                  className="font-display mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-violet-400/60"
                                  aria-hidden="true"
                                />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    )
                  )}
                </div>
              </section>
            ))}
          </div>

          {/* acknowledgment */}
          <div className="mt-12 rounded-2xl border border-violet-400/25 bg-violet-500/[0.06] p-5 text-center">
            <p className="text-sm leading-relaxed text-white/65">
              <span className="font-black text-violet-200">Acknowledgment:</span> by using the Site
              you confirm that you have read these Terms in full, that you are of legal age, and
              that you accept every clause above — including the risk of loss, the limitation of
              liability and the binding arbitration agreement.
            </p>
          </div>

          {/* back home */}
          <div className="mt-10 text-center">
            <Link
              href="/"
              className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-white/80 transition-colors hover:bg-white/10 hover:text-white"
            >
              <Zap className="h-4 w-4" fill="currentColor" />
              Back to ROLLBOX
            </Link>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
