import {
  ArrowLeftRight,
  Ban,
  Banknote,
  BookOpen,
  Coins,
  DollarSign,
  Copyright,
  Dices,
  FileSignature,
  FileText,
  Gamepad2,
  Gavel,
  Gift,
  Handshake,
  HeartHandshake,
  Landmark,
  Lock,
  Scale,
  Server,
  ShieldCheck,
  TrendingDown,
  UserCheck,
  type LucideIcon,
} from "lucide-react";
import { DiscordIcon } from "@/components/rollbox/DiscordIcon";

export const TOS_UPDATED = "September 19, 2026";
export const TOS_VERSION = "4.1";

export interface TosClause {
  /** sub-heading inside the section */
  h?: string;
  /** paragraph body (may include ALL-CAPS legal emphasis) */
  p?: string;
  /** numbered-style bullet clauses */
  ul?: string[];
  /** render inside an emphasized callout card */
  warn?: boolean;
  /** render the Discord CTA button */
  cta?: boolean;
}

export interface TosSection {
  id: string;
  icon: LucideIcon | typeof DiscordIcon;
  title: string;
  clauses: TosClause[];
}

export const TOS_SECTIONS: TosSection[] = [
  {
    id: "acceptance",
    icon: Scale,
    title: "Acceptance of Terms",
    clauses: [
      {
        p: "These Terms of Service (the \"Terms\") constitute a binding legal agreement between you (\"you\", \"your\" or \"Player\") and ROLLBOX (\"ROLLBOX\", \"we\", \"us\" or \"our\"), the operator of the website accessible at rollbox and any related applications, sub-domains, mobile or desktop versions (collectively, the \"Site\"). By creating an account, accessing, browsing or otherwise using the Site in any way, you confirm that you have read, understood, agree to be bound by, and accept to comply with, these Terms in their entirety, including our Privacy Policy and any game rules or bonus terms published on the Site, each of which is incorporated herein by reference.",
      },
      {
        p: "If you do not agree with any part of these Terms, you must immediately stop using the Site and close your account. We may amend these Terms at any time at our sole discretion. The current version is always published on this page together with its effective date, and material changes will be flagged on the Site. Your continued use of the Site after any amendment takes effect constitutes your full and unconditional acceptance of the amended Terms. It is your sole responsibility to review the Terms periodically.",
      },
      {
        warn: true,
        p: "BY USING THE SITE YOU SPECIFICALLY ACKNOWLEDGE AND ACCEPT SECTION 8 (RISK OF LOSS AND NO GUARANTEE OF WINNINGS), SECTION 18 (LIMITATION OF LIABILITY), SECTION 19 (INDEMNIFICATION) AND SECTION 20 (BINDING ARBITRATION AND CLASS ACTION WAIVER), WHICH LIMIT OUR LIABILITY AND GOVERN HOW DISPUTES BETWEEN YOU AND ROLLBOX ARE RESOLVED.",
      },
    ],
  },
  {
    id: "service",
    icon: Gamepad2,
    title: "About the Service — Real-Money Gambling",
    clauses: [
      {
        warn: true,
        p: "ROLLBOX IS, IN EVERY RESPECT, A REAL-MONEY GAMBLING WEBSITE. THE GAMES OFFERED — INCLUDING BUT NOT LIMITED TO CASE OPENINGS AND CASE BATTLES — ARE GAMES OF CHANCE IN WHICH PLAYERS WAGER FUNDS PURCHASED WITH REAL MONEY FOR THE CHANCE TO WIN VIRTUAL FUNDS AND VIRTUAL SKINS. YOU CAN LOSE THE ENTIRE AMOUNT YOU DEPOSIT. IF YOU ARE NOT PREPARED TO ACCEPT THAT RISK IN FULL, DO NOT USE THE SITE.",
      },
      {
        p: "ROLLBOX operates an online gambling platform offering games of chance — including but not limited to case openings, case battles, level rewards and daily bonuses — in which Players wager funds (the Site Balance, denominated in US dollars) for the chance to win additional funds, virtual skins and other virtual items. The Site also operates a skin Exchange and a player Inventory system as described in Section 9. The Site Balance is purchased with real money, and every wager placed with it is a real-money gamble. Whatever terminology the Site may use anywhere in its interface (balance, funds, credits or otherwise), the legal character of the Service is not changed by it: the Service is gambling, in every respect.",
      },
      {
        p: "The Service is provided for your personal, non-exclusive, non-transferable, revocable entertainment only. You may not use the Site for any commercial purpose, resell access to it, or use it on behalf of any third party. Nothing on the Site constitutes financial, investment or legal advice, and no communication from us shall be interpreted as a promise or guarantee of any return.",
      },
    ],
  },
  {
    id: "definitions",
    icon: BookOpen,
    title: "Definitions",
    clauses: [
      {
        ul: [
          "\"Account\" — your unique registered player profile on the Site, protected by your credentials.",
          "\"Site Balance\" — the virtual in-game funds, denominated in US dollars (USD), used to place wagers and to buy skins at the Exchange. The Site Balance is licensed, not sold, and has no cash value.",
          "\"Games\" — all chance-based features on the Site (case openings, case battles, and any future game modes).",
          "\"Wager\" — Site Balance committed by a Player to participate in a Game.",
          "\"Skin\" — a virtual cosmetic item displayed on the Site (weapon skins, knives, gloves, agents, stickers, charms, patches), held in the player Inventory.",
          "\"Inventory\" — the personal in-Game list of Skins a Player obtained through the Exchange.",
          "\"Exchange\" — the Site feature converting Site Balance into Skins at the listed dollar price.",
          "\"Provably Fair\" — our verifiable randomness system in which each outcome is committed in advance via a server-seed hash and can be independently re-verified by the Player.",
          "\"KYC\" — \"Know Your Customer\" identity verification we may require under Sections 5, 10 and 14.",
          "\"Restricted Jurisdiction\" — Israel and any other jurisdiction where accessing or using the Service is prohibited, restricted, or requires a licence we do not hold, as updated by us from time to time.",
        ],
      },
    ],
  },
  {
    id: "eligibility",
    icon: UserCheck,
    title: "Eligibility",
    clauses: [
      {
        p: "The Site is intended strictly for persons who are at least 18 years of age, or the legal age of majority in their jurisdiction, whichever is higher (the \"Legal Age\"). By using the Site you declare and warrant that you have reached the Legal Age and that you are legally capable of entering into binding contracts.",
      },
      {
        ul: [
          "persons who have not reached the Legal Age;",
          "persons who have self-excluded themselves or whom we have previously restricted, suspended or banned;",
          "persons located in, or accessing the Site from, any jurisdiction where its use is prohibited or restricted by law, whether by using the Site directly or through any circumvention method;",
          "persons on international sanctions lists, or who are subject to any gambling exclusion register or statutory self-exclusion scheme;",
          "employees, officers, contractors and direct family members of ROLLBOX, unless expressly authorised in writing;",
          "persons who are interdicted, legally incapacitated, or undergoing bankruptcy or insolvency proceedings.",
        ],
      },
      {
        p: "AVAILABILITY — FOREIGN MARKETS ONLY. The Service is offered exclusively to players located OUTSIDE Israel. The Site is NOT available to residents of, persons located in, or persons accessing it from Israel or any other Restricted Jurisdiction, and no licence for those markets is held or claimed. By depositing, wagering or withdrawing you declare and warrant that you are not subject to this exclusion. Accounts opened, deposits made or wagers placed in breach of this clause are a MATERIAL BREACH of these Terms: the balance and any winnings are void, may be confiscated, and the Account is closed without compensation.",
      },
      {
        p: "We may request proof of eligibility, age or identity at any time. Failure to provide satisfactory proof within a reasonable time entitles us to suspend the Account, void any winnings accrued, and confiscate balances.",
      },
      {
        p: "DETERMINING WHETHER YOU MAY LEGALLY GAMBLE — INCLUDING YOUR AGE AND THE LAW OF YOUR JURISDICTION — IS YOUR SOLE AND EXCLUSIVE RESPONSIBILITY. IT IS AGREED THAT ROLLBOX HAS NO DUTY TO WARN, SCREEN OR VERIFY ANY PLAYER'S AGE, IDENTITY OR JURISDICTION, AND THAT ANY VERIFICATION WE MAY PERFORM IS A VOLUNTARY COURTESY AND A PRIVILEGE WE GRANT, NEVER AN OBLIGATION. THE ABSENCE, FAILURE OR SKIP OF ANY CHECK, WARNING, NOTICE OR PROMPT OF ANY KIND — WHETHER TECHNICAL OR HUMAN — NEVER CREATES ANY LIABILITY FOR ROLLBOX, NEVER VALIDATES A PLAYER'S ELIGIBILITY, AND NEVER WAIVES ANY RIGHT OR REMEDY UNDER THESE TERMS.",
      },
      {
        warn: true,
        p: "ANY USE OF THE SITE IN BREACH OF THIS SECTION — INCLUDING PLAYING WHILE UNDERAGE OR FROM A PROHIBITED JURISDICTION — IS A MATERIAL BREACH OF THESE TERMS. ALL AFFECTED WAGERS AND WINNINGS ARE VOID, AND ANY REMAINING BALANCE OR INVENTORY ITEMS MAY BE CONFISCATED WITHOUT COMPENSATION.",
      },
    ],
  },
  {
    id: "account",
    icon: ShieldCheck,
    title: "Account Registration & Security",
    clauses: [
      {
        p: "You may hold only ONE (1) Account. Multiple accounts held by the same person, household, IP address or device are prohibited and may be merged or closed at our discretion, with any duplicate balances and winnings voided. All information you provide must be accurate, complete and kept up to date. It is strictly prohibited to register an Account on behalf of another person or to transfer, sell or lend your Account to anyone.",
      },
      {
        p: "You are solely responsible for maintaining the confidentiality of your login credentials and for every activity that occurs under your Account, whether authorised by you or not. Notify us immediately of any unauthorised access. We are not liable for losses caused by unauthorised access resulting from your failure to secure your credentials.",
      },
      {
        p: "We may, at any time and at our sole discretion, require you to complete KYC verification (for example a government-issued ID, proof of address, or proof that you control the means used on the Account). Until verification is completed we may limit gameplay, withhold withdrawals and freeze balances.",
      },
    ],
  },
  {
    id: "balance",
    icon: DollarSign,
    title: "Balance & Purchases",
    clauses: [
      {
        p: "The Site Balance is a limited, non-exclusive, revocable, non-transferable licence to use a virtual in-game credit solely within the Games on the Site. You have no ownership right in the Site Balance, Skins or balances. The Site Balance carries no monetary value outside the Site, cannot be sold, exchanged, transferred or pledged to any other player or third party, and does not accrue interest.",
      },
      {
        p: "All purchases of Site Balance, and all conversions of Site Balance at the Exchange, are FINAL. Site Balance and Skins are non-refundable and non-exchangeable for cash, credit or any real-world consideration, except where expressly and explicitly provided by a Site feature (for example selling an Inventory item back at its recorded price) or where refund is required by non-waivable applicable law.",
      },
      {
        warn: true,
        p: "UNAUTHORISED CHARGEBACKS, PAYMENT REVERSALS OR PAYMENT FRAUD ARE A MATERIAL BREACH. UPON SUCH AN EVENT WE MAY IMMEDIATELY TERMINATE YOUR ACCOUNT, VOID ALL WINNINGS, CONFISCATE THE ENTIRE SITE BALANCE AND INVENTORY ITEMS, AND RECOVER ANY OUTSTANDING AMOUNTS; WE MAY ALSO REPORT THE INCIDENT TO THE RELEVANT AUTHORITIES AND PAYMENT NETWORKS.",
      },
      {
        p: "We may manage, regulate, control, modify, add or remove Site Balance (including adjusting balances to correct technical errors, fraud or abuse) at any time and without liability, to the maximum extent permitted by law.",
      },
    ],
  },
  {
    id: "wagering",
    icon: Dices,
    title: "Wagering & Game Outcomes",
    clauses: [
      {
        p: "All Games are games of chance driven by our Provably Fair random system: the outcome of every roll is generated at the moment the wager is confirmed, committed in advance by a server-seed hash, and can be independently re-verified by you. Outcomes cannot be influenced by us after a wager is placed, by other players, or by any external party.",
      },
      {
        p: "A Wager is binding once confirmed. We may refuse, limit or cancel any Wager — in whole or in part — where we reasonably consider it necessary, including in the case of technical failure, obvious error in prices, odds or configuration, suspected fraud or abuse. In such cases the wagered Site Balance is returned to the Account.",
      },
      {
        p: "If a technical malfunction (hardware, software, network or otherwise) affects a Game, all affected Wagers and results are void and the affected Site Balance is restored to the Account. We are not liable for any loss of opportunity, expected winnings or consequential loss resulting from such voids.",
      },
    ],
  },
  {
    id: "losses",
    icon: TrendingDown,
    title: "Player Responsibility, Risk of Loss & No Guarantee of Winnings",
    clauses: [
      {
        warn: true,
        p: "ALL RESPONSIBILITY FOR GAMBLING ON THE SITE RESTS EXCLUSIVELY ON THE PLAYER. YOU UNDERSTAND, ACKNOWLEDGE AND ACCEPT THAT PLAYING THE GAMES CARRIES A REAL RISK OF LOSING THE ENTIRE AMOUNT YOU WAGER. OUTCOMES ARE RANDOM BY DESIGN. THERE IS NO SYSTEM, STRATEGY OR METHOD THAT GUARANTEES A WIN, AND NOTHING ON THE SITE — INCLUDING PAST RESULTS, DROP TABLES OR STATISTICS — CONSTITUTES A PROMISE, INDICATION OR GUARANTEE OF FUTURE RESULTS OR PROFIT.",
      },
      {
        warn: true,
        p: "THE SITE, ITS OWNER AND ITS OPERATORS ARE NOT RESPONSIBLE — FINANCIALLY, CIVILLY, CRIMINALLY OR IN ANY OTHER WAY — AND SHALL NOT BE LIABLE FOR ANY LOSS OR DAMAGE OF ANY KIND WHATSOEVER, INCLUDING WITHOUT LIMITATION LOSSES OF MONEY, SITE BALANCE, SKINS, VIRTUAL ITEMS, CRYPTOCURRENCY, DIGITAL ASSETS, DATA, OPPORTUNITY OR GOODWILL, IN ANY AMOUNT, WHETHER ARISING FROM GAMEPLAY, WAGERS, OUTCOMES, EXCHANGES, TECHNICAL FAILURES OR ANY OTHER CAUSE. THE PLAYER GAMBLES WILLINGLY, KNOWINGLY AND AT HIS OR HER OWN EXCLUSIVE RISK.",
      },
      {
        p: "All wagers are final once placed. Lost wagers, lost Site Balance, and any resulting losses are FINAL, NON-REFUNDABLE AND CANNOT BE RECLAIMED, REVERSED, CHARGED BACK, INDEMNIFIED OR COMPENSATED IN ANY WAY, IN ANY CIRCUMSTANCES, TO THE MAXIMUM EXTENT PERMITTED BY LAW.",
      },
      {
        p: "You play at your sole risk and at your own discretion. You confirm that you wager only with funds you can afford to lose — never with money needed for living expenses, rent, debts, or any essential purpose — and that you assume full and exclusive responsibility for every outcome of your gameplay. You further accept that the Site has no duty to warn you about the risks of gambling: you have been informed by these Terms, and any additional warning, notice, limit or prompt the Site may display is a voluntary courtesy whose presence or absence changes nothing.",
      },
      {
        p: "You are solely responsible for determining whether using the Site, wagering Site Balance, or exchanging it for Skins is legal in your jurisdiction, and for any tax consequences that may arise from your activity on the Site.",
      },
    ],
  },
  {
    id: "exchange",
    icon: ArrowLeftRight,
    title: "The Inventory & the Skin Exchange",
    clauses: [
      {
        p: "The Exchange allows you to convert Site Balance into Skins at the dollar price listed for each item at the moment of the exchange. Confirming an exchange deducts the price from your balance and delivers the Skin to your Inventory. Exchanges are FINAL and IRREVERSIBLE, except that an Inventory item may be sold back to the Site at any time for the price recorded on it.",
      },
      {
        p: "Skins are licensed virtual items with no cash value. Any USD figure displayed on the Site (market price, item value or otherwise) is indicative only. ROLLBOX is not a marketplace, custodian, broker or bank; we do not hold real assets for you, we do not guarantee any external market value for any Skin, and we are not responsible for any price reference from any third-party market.",
      },
      {
        p: "The catalog, its items, and their prices may be added, changed, limited or removed at any time. Inventory capacity is limited (currently 200 items); it is your responsibility to manage your Inventory within that limit. Items that reference content no longer supported by the Site may be removed from the Inventory with their recorded value credited back.",
      },
    ],
  },
  {
    id: "payouts",
    icon: Banknote,
    title: "Withdrawals & Payouts",
    clauses: [
      {
        p: "Any payout of Site Balance, Skins or other value out of the Site (where such a feature is made available at all) is strictly subject to: completed KYC verification; compliance with these Terms; completion of any wagering or bonus conditions; and our internal risk and compliance review.",
      },
      {
        p: "We may delay, withhold, condition or reverse any payout where we reasonably suspect fraud, money laundering, multi-accounting, a breach of these Terms, or where verification is incomplete. Requesting a payout constitutes consent to identity and source-of-funds checks. Payout methods, minimum amounts, fees and processing windows are set by us and may change at any time.",
      },
      {
        p: "Where an Account is terminated for a material breach, any pending payout is cancelled and balances may be confiscated as provided in Section 15.",
      },
    ],
  },
  {
    id: "bonuses",
    icon: Gift,
    title: "Bonuses, Promotions & Level Rewards",
    clauses: [
      {
        p: "Daily bonuses, level rewards, promotional credits, giveaways and any other benefits (\"Bonuses\") are discretionary courtesy benefits. Bonuses are personal, non-transferable and may be subject to additional conditions published with them (including wagering requirements or expiry). We may modify or discontinue any promotion at any time.",
      },
      {
        warn: true,
        p: "BONUS ABUSE — INCLUDING MULTI-ACCOUNTING, SYNDICATE PLAY, ARBITRAGE, EXPLOITING PROMOTION MECHANICS OR ANY OTHER PATTERN WE REASONABLY CONSIDER ABUSIVE — RESULTS IN THE IMMEDIATE CONFISCATION OF ALL BONUS CREDITS AND ANY ASSOCIATED WINNINGS, AND MAY RESULT IN ACCOUNT TERMINATION.",
      },
    ],
  },
  {
    id: "responsible",
    icon: HeartHandshake,
    title: "Responsible Gambling",
    clauses: [
      {
        p: "Gaming must stay entertainment. It can, however, be addictive, and chasing losses always makes things worse. We expect you to set personal limits, to take breaks, and to never wager funds you cannot afford to lose. If gaming stops being fun, stop.",
      },
      {
        ul: [
          "Deposit and loss limits — contact our support to set personal limits on your Account.",
          "Cool-off — request a temporary break from gameplay of any length.",
          "Self-exclusion — request exclusion from the Site for a minimum period of 6 months (or longer, at your choice). During self-exclusion the Account is locked, marketing stops, and any attempt to play is a breach of these Terms.",
          "Account closure — you may request permanent closure at any time.",
        ],
      },
      {
        p: "Winnings accrued in breach of a self-exclusion (including through a new or duplicate account) are void and may be confiscated. If you feel you may have a gaming problem, please seek help from a professional support organisation in your area — do not wait.",
      },
      {
        p: "The tools listed above are provided strictly as a voluntary courtesy. Providing, maintaining, or the failure or absence of any of them never creates any obligation or liability for ROLLBOX, and never shifts any responsibility from the Player: managing your own play remains your exclusive responsibility at all times.",
      },
    ],
  },
  {
    id: "conduct",
    icon: Ban,
    title: "Prohibited Conduct",
    clauses: [
      {
        p: "You must not, and must not attempt to, do any of the following:",
      },
      {
        ul: [
          "hold, operate or benefit from more than one Account, or play on behalf of another person;",
          "use bots, automation, scripts, emulators, scrapers, or any non-human method to access, play or interact with the Site;",
          "exploit, use or fail to privately report any bug, error or vulnerability for any advantage — results obtained through an exploit are void and must be reported;",
          "collude or attempt to collude with other players (for example in case battles) or manipulate any game, reel, outcome or statistic;",
          "engage in fraud, payment abuse, identity misrepresentation or any form of money laundering;",
          "circumvent geographic, age or eligibility restrictions using VPNs, proxies, emulators or any other method;",
          "sell, buy, trade or transfer Accounts, Site Balance, Skins or Inventory items outside the features expressly provided by the Site;",
          "harass, abuse, threaten or harm other players or our staff, or upload unlawful, hateful or infringing content anywhere on the Site;",
          "interfere with, overload or disrupt the Site, its servers, or other players' ability to use it.",
        ],
      },
      {
        p: "We may investigate any suspected breach, monitor Account activity, request information, and take any action we consider proportionate — including voiding wagers, confiscating balances and items, limiting or closing Accounts, and reporting to authorities. We are not obliged to disclose our investigative methods.",
      },
    ],
  },
  {
    id: "aml",
    icon: Landmark,
    title: "Anti-Money Laundering (AML) Policy",
    clauses: [
      {
        p: "ROLLBOX applies a zero-tolerance policy toward money laundering, terrorist financing and any other financial crime. We perform KYC checks on registration triggers and payout triggers, may require proof of the source of funds, and continuously monitor transactions for suspicious patterns.",
      },
      {
        p: "Payments from third parties, payment methods not registered in your name, and any structure designed to obscure the origin of funds are prohibited. We may freeze Accounts, refuse and report transactions, and disclose information to regulators, payment providers and law-enforcement agencies where required or where we reasonably consider it appropriate.",
      },
    ],
  },
  {
    id: "termination",
    icon: Lock,
    title: "Suspension, Restriction & Termination",
    clauses: [
      {
        p: "We may, at any time and at our sole discretion, suspend, restrict or close any Account — temporarily or permanently, with or without notice — including for suspected breach of these Terms, inactivity, compliance requirements, or to protect the Site or its players.",
      },
      {
        warn: true,
        p: "WHERE AN ACCOUNT IS CLOSED FOR A MATERIAL BREACH OF THESE TERMS, ALL WAGERS AND WINNINGS MAY BE DECLARED VOID, THE ENTIRE SITE BALANCE, INVENTORY ITEMS AND PENDING PAYOUTS MAY BE CONFISCATED, AND NO COMPENSATION OF ANY KIND WILL BE PROVIDED. WE RESERVE THE RIGHT TO PURSUE ANY AVAILABLE LEGAL REMEDY.",
      },
      {
        p: "You may close your Account at any time through support. Closing your Account does not excuse you from obligations accrued before closure, and does not entitle you to any refund of prior wagers or losses.",
      },
    ],
  },
  {
    id: "ip",
    icon: Copyright,
    title: "Intellectual Property",
    clauses: [
      {
        p: "The ROLLBOX name, logo, design, artwork, animations, sounds, code and all other content on the Site are owned by ROLLBOX or its licensors and are protected by intellectual property laws. We grant you a limited, personal, revocable, non-commercial licence to use the Site as intended. Any other use — including copying, derivative works, data mining or framing — is prohibited without our prior written consent.",
      },
      {
        p: "Counter-Strike, CS2, Steam and all referenced weapon and skin names and designs are the property of their respective owners, including Valve Corporation. ROLLBOX is not affiliated with, sponsored or endorsed by Valve Corporation; references are made for identification of virtual items only.",
      },
    ],
  },
  {
    id: "availability",
    icon: Server,
    title: "Disclaimers & Availability",
    clauses: [
      {
        p: "THE SITE IS PROVIDED \"AS IS\" AND \"AS AVAILABLE\", WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, ACCURACY, UNINTERRUPTED AVAILABILITY OR ERROR-FREE OPERATION. WE DO NOT WARRANT THAT THE SITE WILL BE AVAILABLE AT ALL TIMES OR THAT DEFECTS WILL BE CORRECTED.",
      },
      {
        p: "We may add, change, suspend or discontinue any part of the Site — including Games, the Exchange, promotions or the entire Site — at any time, with or without notice. We are not liable for loss of Site Balance, Skins, data or goodwill resulting from maintenance, technical failures, connectivity problems, or such changes, to the maximum extent permitted by law.",
      },
    ],
  },
  {
    id: "liability",
    icon: Gavel,
    title: "Limitation of Liability",
    clauses: [
      {
        warn: true,
        p: "TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, ROLLBOX AND ITS OWNERS, OFFICERS, DIRECTORS, EMPLOYEES, LICENSORS AND SUPPLIERS SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY OR PUNITIVE DAMAGES WHATSOEVER — INCLUDING ANY LOSS OF PROFITS, MONEY, SITE BALANCE, SKINS, VIRTUAL ITEMS, CRYPTOCURRENCY, DIGITAL ASSETS, DATA, GOODWILL, OR THE COST OF SUBSTITUTE SERVICES — ARISING OUT OF OR RELATED TO YOUR USE OF, OR INABILITY TO USE, THE SITE, ANY WAGER, ANY OUTCOME OR ANY EXCHANGE.",
      },
      {
        p: "To the maximum extent permitted by law, our total aggregate liability to you for all claims arising under or in connection with these Terms or the Site shall not exceed the total amount you actually deposited with us during the thirty (30) days immediately preceding the event giving rise to the claim (or one hundred US dollars ($100) where no deposits were made).",
      },
      {
        p: "Nothing in these Terms excludes or limits liability that cannot lawfully be excluded, including liability for death or personal injury caused by negligence, or for fraud or wilful misconduct. Where any statutory consumer right cannot be waived, it remains unaffected.",
      },
    ],
  },
  {
    id: "indemnity",
    icon: Handshake,
    title: "Indemnification",
    clauses: [
      {
        p: "You agree to indemnify, defend and hold harmless ROLLBOX and its owners, officers, directors, employees, licensors and suppliers from and against any claim, demand, action, damage, loss, liability, cost and expense (including reasonable legal fees) arising out of or related to: (a) your breach of these Terms or any law; (b) your use or misuse of the Site, including any wager, outcome, exchange or sale; (c) your violation of any third-party right; or (d) your Account activity, whether or not authorised by you.",
      },
      {
        p: "We reserve the right, at your expense, to assume the exclusive defence and control of any matter otherwise subject to indemnification by you, and you agree to cooperate with that defence. You may not settle any such matter without our prior written consent.",
      },
    ],
  },
  {
    id: "disputes",
    icon: FileSignature,
    title: "Governing Law, Disputes & Class Action Waiver",
    clauses: [
      {
        p: "These Terms and any dispute arising out of or relating to them or the Site are governed by the laws of the operator's principal place of establishment, without regard to conflict-of-laws rules. Your access to and use of the Site may also be subject to other local, national and international laws.",
      },
      {
        p: "Before starting formal proceedings you agree to attempt to resolve any dispute informally: contact us through support and allow at least thirty (30) days for a resolution. Most issues are resolved quickly this way.",
      },
      {
        warn: true,
        p: "BINDING ARBITRATION: TO THE MAXIMUM EXTENT PERMITTED BY LAW, ANY DISPUTE NOT RESOLVED INFORMALLY SHALL BE RESOLVED EXCLUSIVELY BY FINAL AND BINDING INDIVIDUAL ARBITRATION, AND NOT IN A COURT OF LAW OR BEFORE A JURY.",
      },
      {
        warn: true,
        p: "CLASS ACTION WAIVER: YOU AND ROLLBOX AGREE THAT CLAIMS MAY BE BROUGHT ONLY IN AN INDIVIDUAL CAPACITY AND NOT AS A PLAINTIFF OR CLASS MEMBER IN ANY PURPORTED CLASS, COLLECTIVE, CONSOLIDATED OR REPRESENTATIVE PROCEEDING, AND THAT THE ARBITRATOR MAY NOT CONSOLIDATE MORE THAN ONE PERSON'S CLAIMS.",
      },
      {
        p: "You agree that any claim arising out of or related to these Terms or the Site must be filed within one (1) year after the cause of action arose, or it is permanently barred. If the class action waiver or any part of this Section is found unenforceable, the affected claims shall proceed in the courts of a competent venue, with all remaining claims continuing in individual arbitration.",
      },
    ],
  },
  {
    id: "misc",
    icon: FileText,
    title: "Miscellaneous",
    clauses: [
      {
        ul: [
          "Entire agreement — these Terms, together with the Privacy Policy and published game and bonus rules, form the entire agreement between you and ROLLBOX regarding the Site.",
          "Severability — if any provision is held invalid or unenforceable, it will be modified to the minimum extent necessary or severed, and the remaining provisions stay in full force.",
          "Assignment — we may assign or transfer these Terms, in whole or in part, at any time; you may not assign your rights or obligations.",
          "Force majeure — we are not liable for any failure or delay caused by events beyond our reasonable control, including natural disasters, wars, strikes, failures of networks or utilities, and acts of government.",
          "No waiver — our failure to enforce any provision is not a waiver of that provision or of any other provision, and no waiver is effective unless in writing.",
          "Language — these Terms may be translated; the English version prevails in case of conflict.",
        ],
      },
    ],
  },
  {
    id: "contact",
    icon: DiscordIcon,
    title: "Contact & Player Support",
    clauses: [
      {
        p: "Questions about these Terms, your Account, responsible-gaming tools, verification, or anything else — our official Discord server is the fastest way to reach the ROLLBOX team. It is the only official community channel; any other group or person claiming to represent ROLLBOX is not affiliated with us.",
      },
      {
        p: "Responsible-gaming requests (limits, cool-off, self-exclusion, closure) are handled with priority. We are committed to answering every request fairly and as quickly as we can.",
      },
      { cta: true },
    ],
  },
];
