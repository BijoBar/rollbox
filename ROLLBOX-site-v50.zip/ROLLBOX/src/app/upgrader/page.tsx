import type { Metadata } from "next";
import { UpgraderView } from "@/components/rollbox/UpgraderView";
import { PageBackdrop } from "@/components/rollbox/PageBackdrop";

export const metadata: Metadata = {
  title: "Upgrader | ROLLBOX",
  description:
    "Stake skins from your inventory, pick your multiplier, spin the wheel. Win chance = 0.95 ÷ multiplier — a win pays a skin worth stake × multiplier.",
};

// USER SPEC (Task 23+28): the UPGRADER — inventory skins in, one bigger skin
// out. The roll is server-side; a win lands the catalog skin closest to
// stake x multiplier in the inventory, a loss consumes the stake.
export default function UpgraderPage() {
  return (
    <>
      {/* USER SPEC (Task 170): the uploaded upgrader artwork as the page
          background at 50% opacity, over the corridor */}
      <PageBackdrop src="/rollboxupgrader.jpg" />
      <UpgraderView />
    </>
  );
}
