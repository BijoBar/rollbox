import type { Metadata } from "next";
import { Suspense } from "react";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { LoginView } from "@/components/rollbox/LoginView";

export const metadata: Metadata = {
  title: "Sign In | ROLLBOX",
  description:
    "Sign in with STEAM — the only way in. One account keeps your coins, battles and drops across every device.",
};

export default function LoginPage() {
  return (
    <SiteShell>
      <Suspense>
        <LoginView />
      </Suspense>
    </SiteShell>
  );
}
