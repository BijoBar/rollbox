import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { GiveawaysView } from "@/components/rollbox/GiveawaysView";

export const metadata: Metadata = {
  title: "Giveaways | ROLLBOX",
  description: "Free ROLLBOX giveaways — join a pot with one click, winners drawn at the deadline and paid to the balance.",
};

export default function GiveawaysPage() {
  return <GiveawaysView />;
}
