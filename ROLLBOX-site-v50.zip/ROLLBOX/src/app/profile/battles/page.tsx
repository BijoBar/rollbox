import type { Metadata } from "next";
import { BattleHistoryView } from "@/components/rollbox/BattleHistoryView";

export const metadata: Metadata = {
  title: "Battle History | ROLLBOX",
  description:
    "Every battle you played — the cases that were opened, your results and a one-tap RECREATE button that re-stacks the same battle.",
};

// USER SPEC (Task 81): the battle history lives on its own page — the main
// profile's header button (the old SIGN OUT spot) links here.
export default function ProfileBattlesPage() {
  return <BattleHistoryView />;
}
