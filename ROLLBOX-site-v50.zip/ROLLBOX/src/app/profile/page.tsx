import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { ProfileView } from "@/components/rollbox/ProfileView";

export const metadata: Metadata = {
  title: "My Profile | ROLLBOX",
  description:
    "Your ROLLBOX profile — balance, opening stats, best drops and provably fair roll history.",
};

export default function ProfilePage() {
  return (
    <SiteShell>
      <ProfileView />
    </SiteShell>
  );
}
