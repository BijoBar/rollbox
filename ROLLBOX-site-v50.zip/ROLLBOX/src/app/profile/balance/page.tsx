import type { Metadata } from "next";
import { BalanceHistoryView } from "@/components/rollbox/BalanceHistoryView";

export const metadata: Metadata = {
  title: "Balance History | ROLLBOX",
  description:
    "Every coin move the server validated for your account — bonuses, entries, refunds, wins and trades, with account totals.",
};

// USER SPEC (Task 83): the BALANCE HISTORY lives on its own page — the
// profile's header button (between BATTLE HISTORY and SETTINGS) links here.
export default function ProfileBalancePage() {
  return <BalanceHistoryView />;
}
