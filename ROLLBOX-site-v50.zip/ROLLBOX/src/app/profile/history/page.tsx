import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { HistoryFullView } from "@/components/rollbox/HistoryFullView";

export const metadata: Metadata = {
  title: "My History | ROLLBOX",
  description: "Your complete ROLLBOX record — every case open, battle and coin movement on one page.",
};

export default function ProfileHistoryPage() {
  return (
    <SiteShell>
      <HistoryFullView />
    </SiteShell>
  );
}
