import type { Metadata } from "next";
import { ExchangeView } from "@/components/rollbox/ExchangeView";

export const metadata: Metadata = {
  title: "Skin Exchange | ROLLBOX",
  description:
    "The ROLLBOX EXCHANGE — trade your coins for any CS2 skin in the game. 13,000+ weapon skins, knives, gloves, agents, stickers, charms and patches with live coin prices. Hit EXCHANGE ITEM and the skin lands straight in your inventory.",
};

export default function ExchangePage() {
  return <ExchangeView />;
}
