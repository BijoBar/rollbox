import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { EventsView } from "@/components/rollbox/EventsView";

export const metadata: Metadata = {
  title: "Events | ROLLBOX",
  description: "The ROLLBOX Emerald Drop event — the limited case, the wager-race board and $150 in prizes for the top 5.",
};

// USER SPEC (EVENTS): the real EVENTS page replaces the Task-29 placeholder —
// the event artwork background, the limited Emerald Drop case and the
// 5-prize wager-race leaderboard. NO season pass (explicitly declined).
export default function EventPage() {
  return (
    <SiteShell>
      <EventsView />
    </SiteShell>
  );
}
