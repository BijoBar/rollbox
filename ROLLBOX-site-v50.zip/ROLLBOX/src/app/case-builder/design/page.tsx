import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { CaseDesignView } from "@/components/rollbox/CaseDesignView";

export const metadata: Metadata = {
  title: "Design Your Case | ROLLBOX",
  description: "Pick the crate artwork, name your case and publish it to the community.",
};

export default function CaseDesignPage() {
  return (
    <SiteShell>
      <CaseDesignView />
    </SiteShell>
  );
}
