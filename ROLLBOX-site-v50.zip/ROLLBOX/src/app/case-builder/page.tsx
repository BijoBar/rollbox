import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { CaseBuilderView } from "@/components/rollbox/CaseBuilderView";

export const metadata: Metadata = {
  title: "Create Your Own Case | ROLLBOX",
  description: "Build a case from your favorite skins, set the drop chances and publish it for the whole site.",
};

export default function CaseBuilderPage() {
  return (
    <SiteShell>
      <CaseBuilderView />
    </SiteShell>
  );
}
