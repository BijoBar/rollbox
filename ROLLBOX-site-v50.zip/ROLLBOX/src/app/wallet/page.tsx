import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { WalletView } from "@/components/rollbox/WalletView";

export const metadata: Metadata = {
  title: "Wallet | ROLLBOX",
  description:
    "Real crypto deposits and payouts — send USDT (TRC-20), paste the txid and the team verifies and credits your balance. Withdrawals are reviewed manually.",
};

// C7 PHASE 1: the WALLET page — real USDT (TRC-20) deposits & withdrawals,
// admin-reviewed. The TopupDialog links here for real money; the demo topup
// dialog stays untouched.
export default function WalletPage() {
  return (
    <SiteShell>
      <WalletView />
    </SiteShell>
  );
}
