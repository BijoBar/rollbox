import type { Metadata } from "next";
import { LeaderboardView } from "@/components/rollbox/LeaderboardView";

export const metadata: Metadata = {
  title: "Leaderboard | ROLLBOX",
  description:
    "Every ROLLBOX player, ranked — by level, cases opened and the biggest single win. No resets, the crown is forever.",
};

// USER SPEC (Task 22): the LEADERBOARD page — the TopBar's LEADERBOARD button
// lands here. Ranks every registered player from #1 down to the full DB count
// in three categories: level / cases opened / biggest win. No weekly reset.
export default function LeaderboardPage() {
  return <LeaderboardView />;
}
