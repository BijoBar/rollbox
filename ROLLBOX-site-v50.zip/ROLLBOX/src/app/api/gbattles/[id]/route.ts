import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { loadBattle, publicView, settleIfDue } from "@/lib/server/gbattles";
import { rateLimit, ipOf, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/** GET /api/gbattles/[id] — the anti-peek public room view (shared clock). */
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  // HARDENING (Task 153): the room view is polled every second or two by
  // spectators — 120/min per IP is far above any honest viewer.
  if (!rateLimit(`room:${ipOf(req.headers)}`, 120, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }
  const row = await loadBattle(id);
  if (!row) return NextResponse.json({ error: "Battle not found" }, { status: 404 });
  const settled = await settleIfDue(row);
  const player = await sessionPlayer(req);
  return NextResponse.json({ battle: publicView(settled, player?.id) });
}
