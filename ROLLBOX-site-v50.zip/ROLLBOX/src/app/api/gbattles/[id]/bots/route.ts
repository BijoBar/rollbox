import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { castBotsVote, loadBattle, publicView, seatChosenBot } from "@/lib/server/gbattles";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * POST /api/gbattles/[id]/bots — two summon flows, one endpoint:
 *
 * USER SPEC (Task 66) — no body: CALL BOTS is a VOTE for "PLAY WITH BOTS".
 * One press does NOT fill the room — bots take the empty seats ONLY when
 * EVERY human seated in the battle has voted. A solo human is trivially
 * unanimous (1/1) and still fills instantly; a partial vote just lights the
 * voter's "PLAY WITH BOTS" chip for the whole room (live push).
 *
 * USER SPEC (Task 67) — { bot: "[RBbot] …", team?, side? }: CHOOSE BOT — a
 * seated player summons a SPECIFIC site bot into a specific empty seat (every
 * empty reel carries a CHOOSE BOT button). A deliberate per-seat pick needs
 * no vote; the room auto-starts when the last seat fills.
 */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  // ANTI-CHEAT (Task 108): vote/summon spam is capped — every real press is
  // one click per seat at most.
  if (!rateLimit(`bbots:${player.id}`, 15, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await ctx.params;
  const row = await loadBattle(id);
  if (!row) return NextResponse.json({ error: "Battle not found" }, { status: 404 });
  if (row.status !== "waiting") return NextResponse.json({ error: "This battle already started" }, { status: 400 });
  const seats = JSON.parse(row.seats) as { key: string }[];
  if (!seats.some((s) => s.key === player.id)) {
    return NextResponse.json({ error: "Only seated players can call bots" }, { status: 403 });
  }

  let body: { bot?: unknown; team?: unknown; side?: unknown } = {};
  try {
    body = (await req.json()) as typeof body;
  } catch {
    body = {}; // no body = the plain CALL BOTS vote
  }

  if (typeof body.bot === "string" && body.bot.length > 0) {
    const team = body.team === 0 || body.team === 1 ? (body.team as 0 | 1) : undefined;
    const side = body.side === 0 || body.side === 1 ? (body.side as 0 | 1) : undefined;
    const res = await seatChosenBot(row, player.id, body.bot, team, side);
    if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    return NextResponse.json({ battle: publicView(res.row, player.id) });
  }

  const { row: updated } = await castBotsVote(row, player.id);
  return NextResponse.json({ battle: publicView(updated, player.id) });
}
