import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { joinBattle, loadBattle, publicView } from "@/lib/server/gbattles";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/** POST /api/gbattles/[id]/join — take a seat (entry charged on the server). */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in to join battles" }, { status: 401 });

  // ANTI-CHEAT (Task 108): also blunts join-code guessing (RB-XXXX).
  if (!rateLimit(`bjoin:${player.id}`, 20, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await ctx.params;
  const row = await loadBattle(id);
  if (!row) return NextResponse.json({ error: "Battle not found" }, { status: 404 });

  const res = await joinBattle(row, player);
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });

  const fresh = await loadBattle(id);
  return NextResponse.json({ balance: res.balance, battle: fresh ? publicView(fresh, player.id) : null });
}
