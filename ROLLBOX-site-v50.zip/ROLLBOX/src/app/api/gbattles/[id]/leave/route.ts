import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { leaveBattle, loadBattle, publicView } from "@/lib/server/gbattles";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/** POST /api/gbattles/[id]/leave — leave a waiting room (entry refunded; USER SPEC Task 196: the room STAYS in the lobby, open for the next players). */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`bleave:${player.id}`, 20, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await ctx.params;
  const row = await loadBattle(id);
  if (!row) return NextResponse.json({ error: "Battle not found" }, { status: 404 });

  const res = await leaveBattle(row, player);
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });

  const fresh = await loadBattle(id);
  return NextResponse.json({
    refund: res.refund,
    cancelled: res.cancelled,
    balance: res.balance,
    battle: fresh ? publicView(fresh, player.id) : null,
  });
}
