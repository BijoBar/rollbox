import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { battleSummary, createBattle, loadBattle, settleIfDue } from "@/lib/server/gbattles";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import type { BattleMode, BattlePotRule, BattleType } from "@/lib/battles";

export const dynamic = "force-dynamic";

/**
 * GET /api/gbattles — EVERYONE sees the same list: every waiting + playing
 * room. USER SPEC (Task 67): PRIVATE rooms are NEVER listed — they exist for
 * their invited players only. `?code=RB-XXXX` resolves ONE battle by its join
 * code (the private lobby entry point — knowing the code IS the invite).
 */
export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  if (code) {
    const row = await db.battle.findUnique({ where: { code: code.trim().toUpperCase() } });
    if (!row || row.status === "cancelled") return NextResponse.json({ battle: null }, { status: 404 });
    const settled = await settleIfDue(row);
    return NextResponse.json({ battle: battleSummary(settled) });
  }

  const rows = await db.battle.findMany({ orderBy: { createdAt: "desc" }, take: 60 });
  const live: ReturnType<typeof battleSummary>[] = [];
  for (const row of rows) {
    const settled = await settleIfDue(row); // flip any room whose clock ran out
    const status = settled.status;
    if (settled.isPrivate) continue; // USER SPEC (Task 67): private never lists
    if (status === "waiting" || status === "playing" || status === "settling") {
      live.push(battleSummary(settled));
    }
  }
  return NextResponse.json({ battles: live });
}

const TYPES: BattleType[] = ["1v1", "1v1v1", "1v1v1v1", "2v2"];
const MODES: BattleMode[] = ["standard", "crazy"];
const RULES: BattlePotRule[] = ["winner", "jackpot", "shared"];

/** POST /api/gbattles — create a global battle (entry charged immediately). */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in to create a battle" }, { status: 401 });

  // ANTI-CHEAT (Task 108): room spam (lobby flooding / seat hogging) is now
  // rate-limited — 12 created rooms per minute is far beyond real play.
  if (!rateLimit(`bcreate:${player.id}`, 12, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { type?: string; mode?: string; potRule?: string; rounds?: string[]; private?: boolean; team?: number; bots?: boolean };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const type = TYPES.includes(body.type as BattleType) ? (body.type as BattleType) : null;
  const mode = MODES.includes(body.mode as BattleMode) ? (body.mode as BattleMode) : null;
  const potRule = RULES.includes(body.potRule as BattlePotRule) ? (body.potRule as BattlePotRule) : null;
  const isPrivate = body.private === true;
  // USER SPEC (Task 196): PLAY WITH BOTS — ON means the created room fills
  // every empty seat with site bots IMMEDIATELY (the battle starts at once).
  const withBots = body.bots === true;
  // USER SPEC (Task 195): the 2v2 creator picks the side — CT (0) or T (1);
  // missing/invalid means the old default (CT). Ignored for 1v1 server-side.
  const team = body.team === 0 || body.team === 1 ? (body.team as 0 | 1) : null;
  const rounds = Array.isArray(body.rounds) ? body.rounds.filter((r) => typeof r === "string") : [];
  if (!type || !mode || !potRule) return NextResponse.json({ error: "Bad battle setup" }, { status: 400 });

  const res = await createBattle(player, { type, mode, potRule, rounds, private: isPrivate, team: team ?? undefined, bots: withBots });
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
  return NextResponse.json({ id: res.id, balance: res.balance });
}
