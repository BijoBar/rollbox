import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { selfcareSnapshot } from "@/lib/server/selfcare";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

// USER SPEC (Task 75): the profile SETTINGS panel — Steam trade link (to pull
// winnings), notification email, plus the SELF CARE state (deposit limit +
// take a break). Everything lives on the PLAYER ROW — the server is the truth.

/** A real Steam trade URL looks exactly like:
 *  https://steamcommunity.com/tradeoffer/new/?partner=123456789&token=Ab-cd_Ef */
const TRADE_LINK_RE =
  /^https:\/\/steamcommunity\.com\/tradeoffer\/new\/\?partner=\d+&token=[A-Za-z0-9_-]+$/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** GET /api/settings — the signed-in player's settings + self-care state. */
export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });
  return NextResponse.json({
    settings: { tradeLink: player.tradeLink ?? "", email: player.email ?? "" },
    selfcare: await selfcareSnapshot(player),
  });
}

/** POST /api/settings — save the trade link and/or the email. USER SPEC
 *  (Task 83): PARTIAL update — a field missing from the body is left exactly
 *  as it is (the profile saves only the trade link, the /settings page only
 *  the email, and neither may clobber the other); sending "" clears it.
 *  Invalid shapes are rejected with a hint. */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`settings:${player.id}`, 15, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { tradeLink?: unknown; email?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const wantsLink = typeof body.tradeLink === "string";
  const wantsMail = typeof body.email === "string";
  const tradeLink = wantsLink ? String(body.tradeLink).trim() : "";
  const email = wantsMail ? String(body.email).trim() : "";

  if (wantsLink && tradeLink && !TRADE_LINK_RE.test(tradeLink)) {
    return NextResponse.json(
      {
        error:
          "That is not a Steam trade URL — it should look like https://steamcommunity.com/tradeoffer/new/?partner=123456789&token=Ab-cd_Ef",
      },
      { status: 400 }
    );
  }
  if (wantsMail && email && !EMAIL_RE.test(email)) {
    return NextResponse.json({ error: "That email address doesn't look right." }, { status: 400 });
  }
  if (email.length > 120 || tradeLink.length > 200) {
    return NextResponse.json({ error: "Value too long." }, { status: 400 });
  }

  const updated = await db.player.update({
    where: { id: player.id },
    data: {
      ...(wantsLink ? { tradeLink: tradeLink || null } : {}),
      ...(wantsMail ? { email: email || null } : {}),
    },
  });
  return NextResponse.json({
    ok: true,
    settings: { tradeLink: updated.tradeLink ?? "", email: updated.email ?? "" },
  });
}
