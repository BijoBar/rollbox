import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { publish } from "@/lib/server/realtime";
import { DAY_MS, selfcareSnapshot } from "@/lib/server/selfcare";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

// USER SPEC (Task 75): SELF CARE — the player limits HIMSELF.
//   action "deposit" → a NET-spend cap he chooses, running 1-3 days.
//   action "break"   → the whole site blocked for him, 1-3 days.
// The client runs a double confirmation (LIMIT DEPOSIT / TAKE A BREAK →
// "are you sure?" dialog); the SERVER also refuses anything without
// confirm:true so the guard cannot be bypassed by a stray request.
// A running limit/block CANNOT be cancelled early — that is the point.

/** Push the new SELF CARE state to every signed-in device at once. */
function publishSelfcare(player: { id: string; balance: number; depositLimit: number | null; depositLimitDays: number | null; depositLimitStart: Date | null; breakUntil: Date | null }) {
  publish("player", {
    playerId: player.id,
    balance: player.balance,
    depositLimit: player.depositLimit,
    depositLimitDays: player.depositLimitDays,
    depositLimitStart: player.depositLimitStart ? player.depositLimitStart.toISOString() : null,
    breakUntil: player.breakUntil ? player.breakUntil.toISOString() : null,
  });
}

/** POST /api/settings/selfcare — { action: "deposit"|"break", days: 1|2|3, amount?, confirm: true } */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  // ANTI-CHEAT (Task 108): self-care locks CANNOT be cancelled early, so a
  // spam loop cannot un-protect an account either — this cap stops churn.
  if (!rateLimit(`selfcare:${player.id}`, 10, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { action?: string; days?: number; amount?: number; confirm?: boolean };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const days = Math.floor(Number(body.days ?? 0));
  if (days !== 1 && days !== 2 && days !== 3) {
    return NextResponse.json({ error: "Pick a 1, 2 or 3 day duration." }, { status: 400 });
  }
  if (body.confirm !== true) {
    return NextResponse.json({ error: "Confirm the self-care action first." }, { status: 400 });
  }

  if (body.action === "deposit") {
    // the UI collects DOLLARS ("0.00$" free-text, numbers only) and converts
    // to coins (10 coins = $1) — the server re-clamps whatever arrives.
    // Task 76: cent-precise — round to 2 decimals instead of flooring, so a
    // limit like $15.55 (155.5 coins) keeps its half-cent.
    const amount = Math.round(Number(body.amount ?? 0) * 100) / 100;
    if (!Number.isFinite(amount) || amount < 1) {
      return NextResponse.json({ error: "Enter an amount above zero." }, { status: 400 });
    }
    if (amount > 10_000_000) {
      return NextResponse.json({ error: "That limit is too high — max $10,000,000." }, { status: 400 });
    }
    const updated = await db.player.update({
      where: { id: player.id },
      data: { depositLimit: amount, depositLimitStart: new Date(), depositLimitDays: days },
    });
    publishSelfcare(updated); // every device sees the new limit instantly
    return NextResponse.json({ ok: true, selfcare: await selfcareSnapshot(updated) });
  }

  if (body.action === "break") {
    const updated = await db.player.update({
      where: { id: player.id },
      data: { breakUntil: new Date(Date.now() + days * DAY_MS) },
    });
    publishSelfcare(updated); // every device (this one too) blocks instantly
    return NextResponse.json({ ok: true, selfcare: await selfcareSnapshot(updated) });
  }

  return NextResponse.json({ error: "Unknown self-care action." }, { status: 400 });
}
