// SERVER PROVABLY FAIR (Task 151) — the commitment endpoint.
// GET /api/fair: the signed-in player's ACTIVE commitment (serverSeedHash +
// clientSeed + next nonce), the last revealed seeds (raw serverSeed + salt —
// public BY DESIGN after rotation) and the recent FairRoll bet history so the
// /provably-fair verifier can re-derive every server outcome.

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { fairSnapshot } from "@/lib/server/fairness";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`fair:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const active = await fairSnapshot(player.id);

  const [revealed, rolls] = await Promise.all([
    db.fairSeed.findMany({
      where: { playerId: player.id, revealedAt: { not: null } },
      orderBy: { revealedAt: "desc" },
      take: 10,
      select: {
        serverSeed: true,
        salt: true,
        serverSeedHash: true,
        clientSeed: true,
        nonce: true,
        revealedAt: true,
      },
    }),
    db.fairRoll.findMany({
      where: { playerId: player.id },
      orderBy: { createdAt: "desc" },
      take: 30,
    }),
  ]);

  return NextResponse.json({
    active,
    revealed: revealed.map((r) => ({
      serverSeed: r.serverSeed,
      salt: r.salt,
      serverSeedHash: r.serverSeedHash,
      clientSeed: r.clientSeed,
      nonceUsed: r.nonce,
      revealedAt: r.revealedAt?.getTime() ?? null,
    })),
    rolls: rolls.map((r) => ({
      id: r.id,
      game: r.game,
      ref: r.ref,
      seedHash: r.seedHash,
      clientSeed: r.clientSeed,
      nonce: r.nonce,
      detail: JSON.parse(r.detail || "{}"),
      createdAt: r.createdAt.getTime(),
    })),
  });
}
