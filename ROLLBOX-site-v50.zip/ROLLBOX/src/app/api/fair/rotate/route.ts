// SERVER PROVABLY FAIR (Task 151) — the reveal endpoint.
// POST /api/fair/rotate { clientSeed? }: reveals the CURRENT seed (its raw
// serverSeed + salt become public, verifiable against the hash that was
// published all along) and mints a fresh commitment. Optionally sets the
// player's new clientSeed — the value the player controls on the next chain.

import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { rotateFairSeed, sanitizeClientSeed } from "@/lib/server/fairness";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  // a rotation is a deliberate click — 10/min is plenty
  if (!rateLimit(`fair-rotate:${player.id}`, 10, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { clientSeed?: unknown } = {};
  try {
    body = await req.json();
  } catch {
    /* empty body is fine — the client seed is optional */
  }
  const clientSeed =
    typeof body.clientSeed === "string" && body.clientSeed.trim()
      ? sanitizeClientSeed(body.clientSeed)
      : undefined;

  const result = await rotateFairSeed(player.id, clientSeed);
  if (!result) {
    // lost a rotation race (two tabs) — the client refetches the new state
    return NextResponse.json({ error: "Seed already rotated — refetch" }, { status: 409 });
  }

  return NextResponse.json({
    revealed: {
      serverSeed: result.revealed.serverSeed,
      salt: result.revealed.salt,
      serverSeedHash: result.revealed.serverSeedHash,
      clientSeed: result.revealed.clientSeed,
      nonceUsed: result.revealed.nonce,
    },
    next: {
      serverSeedHash: result.next.serverSeedHash,
      clientSeed: result.next.clientSeed,
      nextNonce: result.next.nonce,
    },
  });
}
