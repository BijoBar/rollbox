import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { db } from "@/lib/db";
import { CASES } from "@/lib/cases";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

// USER SPEC (Task 75): the profile's BATTLE statistics + BATTLE HISTORY.
// Everything is derived ON THE SERVER from the finished `Battle` rows the
// player sat in — the same DB truth the worldwide lobby runs on. The client
// mirrors the returned history into localStorage so the browser keeps a copy
// even offline (the user asked for device-side persistence).

interface Seat {
  key: string;
  name: string;
  avatar?: string;
  team: 0 | 1;
  color: number;
  isBot: boolean;
  paid: number;
}

const jparse = <T,>(s: string | null | undefined, fb: T): T => {
  try {
    return s ? (JSON.parse(s) as T) : fb;
  } catch {
    return fb;
  }
};

const caseName = (id: string) => CASES.find((c) => c.id === id)?.name ?? id;

/** GET /api/profile/battles — totals, the last-5 W/L run and the history. */
export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });
  // HARDENING (Task 153): the history scans up to 500 finished rows — a cap
  // keeps a script from milking it in a loop.
  if (!rateLimit(`pbattles:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  // seats is a JSON string column — a quoted-id substring match finds every
  // room this player sat in (player ids are p_<hex>, bot keys are bot_<n>)
  const rows = await db.battle.findMany({
    where: { status: "finished", seats: { contains: `"${player.id}"` } },
    orderBy: { finishedAt: "desc" },
    take: 500,
  });

  const history = rows.map((row) => {
    const seats = jparse<Seat[]>(row.seats, []);
    const winnerIds = jparse<string[]>(row.winnerIds, []);
    const take = jparse<Record<string, number>>(row.take, {});
    const pulls = jparse<{ playerId: string; total: number; pulls: { value: number }[] }[]>(row.pulls, []);
    const rounds = jparse<string[]>(row.rounds, []);
    const mine = seats.find((s) => s.key === player.id);
    const myRes = pulls.find((r) => r.playerId === player.id);
    const myTotal = myRes?.total ?? 0;
    const myBest = Math.max(0, ...(myRes?.pulls.map((p) => p.value) ?? [0]));
    const entry = mine?.paid ?? 0;
    // Task 76: cent-precise — keep the real take (2-dec) instead of flooring
    const got = Math.max(0, Math.round((take[player.id] ?? 0) * 100) / 100);
    const result: "W" | "L" = winnerIds.includes(player.id) ? "W" : "L";
    return {
      id: row.id,
      code: row.code,
      type: row.type,
      mode: row.mode,
      potRule: row.potRule,
      result, // W = my side won, L = the other side took it (ties were coin-flipped at settle)
      entry,
      take: got,
      net: got - entry,
      myTotal,
      myBest,
      caseCount: rounds.length,
      cases: rounds.slice(0, 10).map(caseName),
      // USER SPEC (Task 81): the case IDS ride along so the battle-history
      // page can render the actual crate artwork (up to the first 7), and the
      // full battle config lets the RECREATE button re-stack the same battle
      // on the create screen (editable, never auto-started).
      caseIds: rounds.slice(0, 10),
      config: {
        type: row.type,
        mode: row.mode,
        potRule: row.potRule,
        isPrivate: row.isPrivate,
        rounds,
      },
      players: seats.map((s) => ({
        name: s.name,
        avatar: s.avatar ?? null,
        isBot: s.isBot,
        team: s.team,
        winner: winnerIds.includes(s.key),
      })),
      finishedAt: (row.finishedAt ?? row.updatedAt ?? row.createdAt).getTime(),
    };
  });

  const wins = history.filter((h) => h.result === "W").length;
  const battles = history.length;
  const totals = {
    battles,
    wins,
    losses: battles - wins,
    winRate: battles ? Math.round((wins / battles) * 1000) / 10 : 0,
  };

  return NextResponse.json({
    totals,
    last5: history.slice(0, 5).map((h) => h.result),
    history: history.slice(0, 30),
  });
}
