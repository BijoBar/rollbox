import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { publish } from "@/lib/server/realtime";

export const dynamic = "force-dynamic";

// C12: the display-identity endpoint — a custom nickname and/or avatar.
// The Steam login sync (upsertPlayer) never overwrites a customized
// name/avatar (the two flags), and "reset" restores the snapshotted
// Steam persona (steamName/steamAvatar) on demand.

const NAME_MIN = 2;
const NAME_MAX = 24; // same cap the signup path applies
const AVATAR_MAX = 500;

/** Control characters have no business in a display name. */
const CONTROL_CHARS = /[\u0000-\u001f\u007f]/g;

/** POST /api/profile — partial identity update:
 *  { name }                 -> set a custom nickname (2-24 chars),
 *  { avatar }               -> set a custom avatar (https URL; "" reverts
 *                              the avatar to the Steam persona),
 *  { reset: "name" | "avatar" | "both" }
 *                           -> restore the snapshotted Steam persona.
 *  Missing fields are left exactly as they are (same partial-update
 *  contract as /api/settings). */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`profile:${player.id}`, 10, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { name?: unknown; avatar?: unknown; reset?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const wantsName = typeof body.name === "string";
  const wantsAvatar = typeof body.avatar === "string";
  const reset = body.reset === "name" || body.reset === "avatar" || body.reset === "both" ? body.reset : null;
  if (!wantsName && !wantsAvatar && !reset) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }

  const data: {
    name?: string;
    avatar?: string | null;
    nameCustom?: boolean;
    avatarCustom?: boolean;
  } = {};

  if (wantsName) {
    const name = String(body.name).replace(CONTROL_CHARS, "").trim();
    if (name.length < NAME_MIN || name.length > NAME_MAX) {
      return NextResponse.json(
        { error: `The name must be ${NAME_MIN}-${NAME_MAX} characters (yours is ${name.length}).` },
        { status: 400 },
      );
    }
    data.name = name;
    data.nameCustom = true;
  }

  if (wantsAvatar) {
    const avatar = String(body.avatar).trim();
    if (!avatar) {
      // "" = drop the custom picture — the Steam one takes over again.
      data.avatar = player.steamAvatar ?? null;
      data.avatarCustom = false;
    } else {
      let parsed: URL | null = null;
      try {
        parsed = new URL(avatar);
      } catch {
        parsed = null;
      }
      if (!parsed || parsed.protocol !== "https:" || avatar.length > AVATAR_MAX) {
        return NextResponse.json(
          { error: "The avatar must be an https:// link to a picture (max 500 chars)." },
          { status: 400 },
        );
      }
      data.avatar = avatar;
      data.avatarCustom = true;
    }
  }

  if (reset) {
    // Reset WINS over any custom value sent in the same request.
    if (reset === "name" || reset === "both") {
      // No stored persona yet (first login after this feature) -> the name
      // stays as-is, only the flag clears — the next Steam login syncs it.
      if (player.steamName) data.name = player.steamName;
      data.nameCustom = false;
    }
    if (reset === "avatar" || reset === "both") {
      data.avatar = player.steamAvatar ?? null;
      data.avatarCustom = false;
    }
  }

  const updated = await db.player.update({ where: { id: player.id }, data });
  // C12: every signed-in tab/device adopts the new identity at once.
  publish("player", { playerId: player.id, name: updated.name, avatar: updated.avatar });
  return NextResponse.json({
    ok: true,
    player: { name: updated.name, avatar: updated.avatar },
    identity: { nameCustom: updated.nameCustom, avatarCustom: updated.avatarCustom },
  });
}
