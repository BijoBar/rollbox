import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { claimMissionPrizes, getMissionState } from "@/lib/server/missions";
import { rateLimit, ipOf, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * GET /api/missions — the signed-in player's mission progress, straight from
 * the DB (Task 32 USER SPEC: the progress of the missions lives on the
 * player's row). The board UI derives each step's bar from the lifetime
 * counters via the shared src/lib/missions-progress.ts mapping. Guests get
 * `state: null` — the board renders the catalog without personal progress.
 *
 * USER SPEC (Task 183): every mission's prize is ONE FREE RB-106 box. This
 * read also LAZILY CLAIMS the prizes of newly-completed missions (same
 * pattern as the giveaway auto-draw): the box lands in the player's
 * freeCases map exactly once per mission, `granted` carries the ids granted
 * by THIS call (the board toasts them) and `state.g` lists every
 * already-paid mission (the board renders its CLAIMED chip).
 */
export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  // HARDENING (Task 153): keyed by the player when signed in, by IP for guests.
  if (!rateLimit(`missions:${player?.id ?? ipOf(req.headers)}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }
  if (!player) return NextResponse.json({ state: null });
  const granted = await claimMissionPrizes(player.id);
  const state = await getMissionState(player.id);
  return NextResponse.json({
    state: { v: state.v, c: state.c, g: state.g ?? [] },
    granted,
  });
}
