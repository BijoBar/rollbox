import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// Public alias of the admin banner config (the TopBar reads this one).
// QOL (Task 167): a broadcast the admin writes in the TOOLS tab shows here
// on every page until the admin turns it off.
export async function GET() {
  const rows = await db.siteConfig.findMany({ where: { key: { in: ["site.bannerOn", "site.bannerText", "site.bannerTone"] } } });
  const map = new Map(rows.map((r) => [r.key, r.value]));
  return NextResponse.json({
    on: map.get("site.bannerOn") === "1",
    text: map.get("site.bannerText") ?? "",
    tone: map.get("site.bannerTone") ?? "gold",
  });
}
