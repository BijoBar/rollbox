import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { subscribe } from "@/lib/server/realtime";
import { startRealtimeTicker } from "@/lib/server/realtime-ticker";
import { rateLimit, ipOf, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

/**
 * GET /api/realtime/stream — THE multiplayer push channel (Task 64).
 * A persistent server-sent-events stream: the server pushes every state
 * change (lobby, room rounds, live drops, balances, inventory, site stats)
 * to every connected player at the same instant. The cookie travels with the
 * EventSource request, so the server knows WHICH player each stream belongs
 * to and can target balance/inventory pushes to that player alone.
 *
 * Event map:
 *   hello            { serverNow, you }     — on connect (clock sync)
 *   battles          { at }                 — the lobby list changed
 *   battle           { id }                 — that room's state advanced
 *   drop             { ...drop }            — a new live feed row (real players)
 *   player           { playerId, balance }  — targeted: this player's balance
 *   inventory        { playerId }           — targeted: this player's inventory
 *   stats            { }                    — site-wide counters changed
 *   support_admin    { playerId, kind }     — (Task 136) admins' inbox refresh +
 *                                           the SUPPORT CASE side alert
 *   support_player   { at }                 — (Task 136) targeted: the player's
 *                                           chat panel live-updates
 */
export async function GET(req: NextRequest) {
  // HARDENING (Task 153): one SSE connection per open tab; the cap (per IP)
  // stops reconnect-storm scripts from pinning sockets. Honest clients open
  // 1-2 streams per page — 30/min is far above that.
  if (!rateLimit(`sse:${ipOf(req.headers)}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }
  const player = await sessionPlayer(req).catch(() => null);
  const playerId = player?.id ?? null;

  startRealtimeTicker(); // idempotent — one heartbeat per process

  const encoder = new TextEncoder();
  let unsubscribe: (() => void) | null = null;
  let heartbeat: ReturnType<typeof setInterval> | null = null;

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      const write = (chunk: string) => {
        try {
          controller.enqueue(encoder.encode(chunk));
        } catch {
          /* stream already gone */
        }
      };
      const send = (type: string, data: unknown) => write(`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`);

      send("hello", { serverNow: Date.now(), you: playerId });
      unsubscribe = subscribe({ playerId, send });

      // comment ping keeps proxies from eating the idle stream
      heartbeat = setInterval(() => write(`: ping ${Date.now()}\n\n`), 20000);

      const cleanup = () => {
        if (heartbeat) clearInterval(heartbeat);
        heartbeat = null;
        unsubscribe?.();
        unsubscribe = null;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };
      req.signal.addEventListener("abort", cleanup);
    },
    cancel() {
      if (heartbeat) clearInterval(heartbeat);
      heartbeat = null;
      unsubscribe?.();
      unsubscribe = null;
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
