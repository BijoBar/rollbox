import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { caseDailyNextIn, dailyOpensOf } from "@/lib/progress";
import { unlockedDailyCases } from "@/lib/level-cases";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * GET/POST /api/daily — USER SPEC (Task 104): the daily reward is a set of
 * FREE CASES — EVERY daily case with requiredLevel <= the player's DB level
 * opens free once per 24h, EACH with its own cooldown (a Level 50 player
 * opens 10+20+30+40+50 every day). This endpoint REPORTS the per-case gates
 * for signed-in players; the cooldown is stamped by POST /api/open the moment
 * the player actually OPENS a case. Guests run the same gates locally
 * (store.dailyOpens).
 */
async function report(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`daily:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const opens = dailyOpensOf(player.dailyOpens);
  const cases: Record<string, { ready: boolean; nextIn: number }> = {};
  let anyReady = false;
  for (const c of unlockedDailyCases(player.level)) {
    const nextIn = caseDailyNextIn(opens, c.id);
    const ready = nextIn === 0;
    if (ready) anyReady = true;
    cases[c.id] = { ready, nextIn };
  }
  return NextResponse.json({ level: player.level, xp: player.xp, anyReady, cases });
}

export async function GET(req: NextRequest) {
  return report(req);
}

export async function POST(req: NextRequest) {
  return report(req);
}
