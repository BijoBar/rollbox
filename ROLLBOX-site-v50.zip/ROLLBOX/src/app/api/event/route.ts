import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { recordLedger, publishBalance } from "@/lib/server/ledger";
import { rateLimit, TOO_MANY, ipOf } from "@/lib/server/ratelimit";
import { EVENT_ENDS_AT, EVENT_PRIZES, eventActive } from "@/lib/event";

export const dynamic = "force-dynamic";

// USER SPEC (EVENTS): the EMERALD DROP event board — public leaderboard of
// the wager race (every coin spent opening the event case counts up), the
// prize ladder (1st $50 → 5th $10) and the closing countdown. When the
// window closes the FIRST read awards the prizes exactly once and freezes
// the board (see settleEventPrizes below).

const AWARDED_KEY = "event.prizesAwarded";
const WINNERS_KEY = "event.winners";

interface EventWinner {
  place: number;
  playerId: string;
  name: string;
  prize: number;
}

/**
 * Award the top 5 exactly once. The claim is the SiteConfig PRIMARY KEY
 * create — two concurrent readers cannot both win it, so the payout can
 * never double. Prizes follow the BOARD place (place 4 gets $20 even if a
 * higher row turns out unpayoutable); every credit rides its own
 * $transaction with the ledger row (the Task-153 money pattern).
 */
async function settleEventPrizes(): Promise<EventWinner[]> {
  const done = await db.siteConfig.findUnique({ where: { key: AWARDED_KEY } }).catch(() => null);
  if (done) {
    const w = await db.siteConfig.findUnique({ where: { key: WINNERS_KEY } }).catch(() => null);
    return w ? (JSON.parse(w.value) as EventWinner[]) : [];
  }
  const claimed = await db.siteConfig
    .create({ data: { key: AWARDED_KEY, value: new Date().toISOString() } })
    .catch(() => null);
  if (!claimed) return []; // another request claimed the payout this instant

  const top = await db.eventStat.findMany({
    orderBy: [{ wagered: "desc" }, { updatedAt: "asc" }],
    take: EVENT_PRIZES.length,
  });
  const winners: EventWinner[] = [];
  for (let i = 0; i < top.length; i++) {
    const prize = EVENT_PRIZES[i];
    const res = await db
      .$transaction(async (tx) => {
        const upd = await tx.player.update({
          where: { id: top[i].playerId },
          data: { balance: { increment: prize } },
        });
        await recordLedger(top[i].playerId, "event_prize", prize, upd.balance, "emerald-drop", tx);
        return upd;
      })
      .catch(() => null);
    if (!res) continue; // banned/deleted row — the place pays nobody
    publishBalance(top[i].playerId, res.balance);
    winners.push({ place: i + 1, playerId: top[i].playerId, name: top[i].name, prize });
  }
  await db.siteConfig
    .upsert({
      where: { key: WINNERS_KEY },
      create: { key: WINNERS_KEY, value: JSON.stringify(winners) },
      update: { value: JSON.stringify(winners) },
    })
    .catch(() => {});
  return winners;
}

/**
 * GET /api/event — public board state: countdown, prize ladder, top 10,
 * the viewer's own standing, and (after the window closes) the final
 * winners with the prizes credited to their balances.
 */
export async function GET(req: NextRequest) {
  if (!rateLimit(`event:${ipOf(req.headers)}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const active = eventActive();
  let prizesAwarded = false;
  let winners: EventWinner[] | null = null;
  if (!active) {
    // the window closed — this read settles the board (guarded to run once)
    winners = await settleEventPrizes();
    prizesAwarded = true;
  } else {
    const awarded = await db.siteConfig.findUnique({ where: { key: AWARDED_KEY } }).catch(() => null);
    prizesAwarded = !!awarded;
  }

  // banned players never appear on the board (same rule as /api/leaderboard)
  const top = await db.eventStat.findMany({
    orderBy: [{ wagered: "desc" }, { updatedAt: "asc" }],
    take: 10,
  });
  const ids = top.map((t) => t.playerId);
  const players = await db.player.findMany({
    where: { id: { in: ids } },
    select: { id: true, name: true, avatar: true, bannedAt: true },
  });
  const banned = new Set(players.filter((p) => p.bannedAt).map((p) => p.id));
  const meta = new Map(players.filter((p) => !p.bannedAt).map((p) => [p.id, p]));
  const leaderboard = top
    .filter((t) => !banned.has(t.playerId))
    .map((t, i) => ({
      rank: i + 1,
      playerId: t.playerId,
      name: meta.get(t.playerId)?.name ?? t.name,
      avatar: meta.get(t.playerId)?.avatar ?? null,
      wagered: t.wagered,
      opened: t.opened,
    }));

  // the viewer's own standing (rank = rows strictly ahead, +1)
  let me: { wagered: number; opened: number; rank: number } | null = null;
  const viewer = await sessionPlayer(req).catch(() => null);
  if (viewer && !viewer.bannedAt) {
    const mine = await db.eventStat.findUnique({ where: { playerId: viewer.id } }).catch(() => null);
    if (mine) {
      const ahead = await db.eventStat.count({ where: { wagered: { gt: mine.wagered } } });
      me = { wagered: mine.wagered, opened: mine.opened, rank: ahead + 1 };
    }
  }

  return NextResponse.json({
    active,
    endsAt: EVENT_ENDS_AT,
    prizes: EVENT_PRIZES,
    prizesAwarded,
    winners,
    leaderboard,
    me,
  });
}
