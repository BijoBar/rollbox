import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { claimOpenPendings } from "@/lib/server/opens";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * POST /api/open/claim — USER SPEC (Task 78): the reel finished and the skin
 * is on screen with its price; THIS is the moment the win becomes money.
 * Claims the round created by POST /api/open (ownership + one-time atomic
 * flag) and credits the exact rolled amount to the DB balance, records the
 * ledger win, publishes the LIVE-feed drops and the balance event.
 * Idempotent: claiming an already-claimed round returns the current balance
 * (no double credit) instead of an error.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in to open cases" }, { status: 401 });

  // ANTI-CHEAT (Task 108): a 20-reel reveal claims ~1/s at most — 60/min is
  // far beyond real play, well under a spam script.
  if (!rateLimit(`claim:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { pendingId?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
  const pendingId = typeof body.pendingId === "string" ? body.pendingId : "";
  if (!pendingId.startsWith("op_")) {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const result = await claimOpenPendings(player.id, { pendingId });
  if (result) {
    return NextResponse.json({
      credited: result.claimedAmount,
      claimed: true,
      balance: result.balance,
    });
  }

  // Nothing unclaimed matched — either already claimed (idempotent OK) or
  // not ours. Distinguish so the client never toasts a false error.
  const existing = await db.openPending.findUnique({
    where: { id: pendingId },
    select: { playerId: true, claimed: true },
  });
  if (existing && existing.playerId === player.id && existing.claimed) {
    const fresh = await db.player.findUniqueOrThrow({
      where: { id: player.id },
      select: { balance: true },
    });
    return NextResponse.json({ credited: 0, claimed: true, alreadyClaimed: true, balance: fresh.balance });
  }
  return NextResponse.json({ error: "Unknown pending round" }, { status: 404 });
}
