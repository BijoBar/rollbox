import crypto from "crypto";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { bumpCounter, sessionPlayer } from "@/lib/server/auth";
import { checkSpendAllowed } from "@/lib/server/selfcare";
import { recordLedger } from "@/lib/server/ledger";
import { publish } from "@/lib/server/realtime";
import { awardXp } from "@/lib/server/xp";
import { trackMissions } from "@/lib/server/missions";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { findCommunityCase } from "@/lib/server/community-cases";
import { consumeFreeCases } from "@/lib/server/freecases";
import { CASES, caseItemValue, SKINS, type CaseDef, type WearId } from "@/lib/cases";
import { eventActive } from "@/lib/event";
import { rareCaseOf, rolldropChanceOf } from "@/lib/rolldrop";
import { pickWeighted, rollFloat } from "@/lib/provably-fair";
import { reserveNonces } from "@/lib/server/fairness";
import { caseXp, dailyOpensOf } from "@/lib/progress";

export const dynamic = "force-dynamic";

const DAY_MS = 24 * 60 * 60 * 1000;

// USER SPEC (Task 133): multi-open is capped at FIVE cases at once (user
// request — was 20 in Task 67). Server-enforced: larger counts clamp to 5.
const MAX_REELS = 5;

// USER SPEC (Task 142): the catalog is code-static, but COMMUNITY cases live
// in the DB — a "cc_*" id falls through to the DB lookup before giving up.
async function caseById(id: string): Promise<CaseDef | undefined> {
  const staticDef = CASES.find((c) => c.id === id);
  if (staticDef) return staticDef;
  return findCommunityCase(id);
}

/**
 * POST /api/open — the SERVER rolls a solo opening for the signed-in player.
 * Same house rules as the local reels: weighted draw + the ROLLDROP chance
 * (a hit REPLACES the reel's skin with a rare-pool bonus pull).
 * Task 151: the draw is PROVABLY FAIR — floats come from the player's
 * commit-reveal chain (HMAC of the hidden serverSeed with the player's
 * clientSeed + reserved nonces), never from Math.random.
 *
 * USER SPEC (Task 78 — CRITICAL): the roll IS decided here and the case price
 * IS charged here, but the WIN is NOT credited at the click. It is parked in
 * an OpenPending row; the client claims it (POST /api/open/claim) the moment
 * the reveal finishes — skin on screen, price visible — and only then do the
 * balance, the ledger win row and the public LIVE-feed drops land. A round
 * whose tab died mid-spin is recovered on the player's next /api/auth/me.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in to open cases" }, { status: 401 });

  // ANTI-CHEAT (Task 108): generous for real play (5-case bursts), but a
  // script hammering the endpoint now hits a wall.
  if (!rateLimit(`open:${player.id}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { caseId?: string; count?: number };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const caseDef = await caseById(body.caseId ?? "");
  let count = Math.max(1, Math.min(MAX_REELS, Math.floor(body.count ?? 1)));
  if (!caseDef) return NextResponse.json({ error: "Unknown case" }, { status: 400 });

  // USER SPEC (EVENTS): the limited event case opens ONLY while its window is
  // live — after the closing timestamp the server refuses it everywhere.
  if (caseDef.kind === "event" && !eventActive()) {
    return NextResponse.json({ error: "The event has ended" }, { status: 403 });
  }

  // USER SPEC (Task 104): the free DAILY cases (LEVEL 10..100) open ONE at a
  // time and EVERY case up to the player's level opens free once per 24h —
  // EACH case carries its own cooldown. The SERVER gates everything: the
  // required level comes from the DATABASE battle pass (Player.level) and the
  // per-case cooldown lives in Player.dailyOpens, so it holds on every device.
  const isDailyCase = caseDef.kind === "level";
  let dailyNextIn = 0;
  if (isDailyCase) {
    count = 1;
    if (caseDef.requiredLevel != null && player.level < caseDef.requiredLevel) {
      return NextResponse.json(
        { error: `Reach Level ${caseDef.requiredLevel} first`, requiredLevel: caseDef.requiredLevel },
        { status: 403 },
      );
    }
    const opens = dailyOpensOf(player.dailyOpens);
    const last = opens[caseDef.id] ?? 0;
    dailyNextIn = Math.max(0, last + DAY_MS - Date.now());
    if (dailyNextIn > 0) {
      return NextResponse.json({ error: "Daily case already opened", nextIn: dailyNextIn }, { status: 403 });
    }
  }

  // USER SPEC (Task 183): FREE CASES burn FIRST — every gifted / mission-prize
  // unit of THIS case opens at charge 0, and the paid charge only covers the
  // remainder (2 free + a x5 open = 2 free opens + 3 charged reels). Daily
  // (level) cases are already free — gifted units are never burned on them
  // (and the admin gift route refuses to create them).
  let freeUsed = 0;
  let freeLeft: Record<string, number> = {};
  if (!isDailyCase) {
    const burned = await consumeFreeCases(player.id, caseDef.id, count).catch(() => ({ used: 0, freeCases: {} as Record<string, number> }));
    freeUsed = burned.used;
    freeLeft = burned.freeCases;
    if (freeUsed > 0) publish("player", { playerId: player.id, freeCases: freeLeft });
  }
  const price = caseDef.price * (count - freeUsed);

  // USER SPEC (Task 75): SELF CARE — a TAKE A BREAK block or a deposit limit
  // stops the opening BEFORE the charge (server-enforced, not a UI trick).
  const blocked = await checkSpendAllowed(player, price);
  if (blocked) return NextResponse.json({ error: blocked }, { status: 403 });

  // SERVER PROVABLY FAIR (Task 151): reserve this round's nonce slots on the
  // player's commit-reveal chain BEFORE anything is charged. Two slots per
  // reel: gate (ROLLDROP chance) + item draw. Order matters for the player:
  // a failed charge merely burns nonces (harmless gaps — each FairRoll row
  // records its own), while the opposite order could strand a charge if the
  // reservation ever failed.
  const { seed, start } = await reserveNonces(player.id, 2 * count);

  let balanceAfter: number;
  if (isDailyCase || price === 0) {
    // FREE — no charge, no ledger entry. Daily (level) cases also stamp THIS
    // case's 24h cooldown NOW.
    // HARDENING (Task 153): the stamp is a COMPARE-AND-SET on the dailyOpens
    // JSON — it lands only if the map still matches the snapshot the cooldown
    // check was made against. Two concurrent opens can no longer both pass
    // the gate: the loser re-reads, sees the fresh stamp and is refused with
    // the real remaining time.
    if (isDailyCase) {
      let opensStr: string | null = player.dailyOpens ?? null;
      let stamped = false;
      for (let attempt = 0; attempt < 4 && !stamped; attempt++) {
        const opens = dailyOpensOf(opensStr);
        const last = opens[caseDef.id] ?? 0;
        const nextIn = Math.max(0, last + DAY_MS - Date.now());
        if (nextIn > 0) {
          return NextResponse.json({ error: "Daily case already opened", nextIn }, { status: 403 });
        }
        opens[caseDef.id] = Date.now();
        const res = await db.player
          .updateMany({
            where: { id: player.id, dailyOpens: opensStr },
            data: { dailyOpens: JSON.stringify(opens) },
          })
          .catch(() => null);
        if (res && res.count === 1) stamped = true;
        else {
          const fresh = await db.player
            .findUnique({ where: { id: player.id }, select: { dailyOpens: true } })
            .catch(() => null);
          if (!fresh) return NextResponse.json({ error: "Could not open the case" }, { status: 500 });
          opensStr = fresh.dailyOpens ?? null;
        }
      }
      if (!stamped) return NextResponse.json({ error: "Could not open the case" }, { status: 500 });
      dailyNextIn = DAY_MS;
    }
    const bal = await db.player
      .findUnique({ where: { id: player.id }, select: { balance: true } })
      .catch(() => null);
    balanceAfter = bal?.balance ?? player.balance;
  } else {
    // HARDENING (Task 153): the charge and its ledger row commit as ONE
    // transaction — a crash between them can no longer leave a paid entry
    // with no audit row.
    // USER SPEC (EVENTS): the event wager-race counter rides the SAME
    // transaction — the leaderboard grows only with money that actually left
    // a balance, so it can never disagree with the ledger.
    const isEventCase = caseDef.kind === "event";
    const charged = await db
      .$transaction(async (tx) => {
        const upd = await tx.player.update({
          where: { id: player.id, balance: { gte: price } },
          data: { balance: { decrement: price } },
        });
        await recordLedger(player.id, "open_entry", -price, upd.balance, caseDef.id, tx);
        if (isEventCase) {
          await tx.eventStat.upsert({
            where: { playerId: player.id },
            create: { playerId: player.id, name: player.name, wagered: price, opened: count },
            update: { wagered: { increment: price }, opened: { increment: count }, name: player.name },
          });
        }
        return upd;
      })
      .catch(() => null);
    if (!charged) return NextResponse.json({ error: "Not enough funds" }, { status: 400 });
    balanceAfter = charged.balance;
  }

  // SERVER PROVABLY FAIR (Task 151): the two floats per reel — gate decides
  // the ROLLDROP (float < chance), item draw maps onto the case's table or
  // (on a hit) the rare pool. Same pickWeighted math the verifier reruns.
  const rare = rareCaseOf(caseDef);
  let credited = 0;
  const pulls: { skinId: string; wear?: WearId; value: number; rd: boolean; f: [number, number]; bonus?: { skinId: string; wear?: WearId; value: number } }[] = [];
  const dropRows: {
    playerId: string; playerName: string; provider: string; caseId: string; caseName: string;
    skinId: string; skinName: string; value: number; isRd: boolean; source: string; wear?: string;
  }[] = [];

  for (let i = 0; i < count; i++) {
    const gateNonce = start + 2 * i;
    const itemNonce = start + 2 * i + 1;
    const gateFloat = rollFloat(seed.serverSeed, seed.clientSeed, gateNonce);
    const itemFloat = rollFloat(seed.serverSeed, seed.clientSeed, itemNonce);
    if (gateFloat < rolldropChanceOf(caseDef)) {
      const bonusItem = pickWeighted(rare.items, itemFloat);
      const bonusValue = caseItemValue(bonusItem);
      credited += bonusValue;
      pulls.push({ skinId: bonusItem.skinId, wear: bonusItem.wear, value: bonusValue, rd: true, f: [gateFloat, itemFloat], bonus: { skinId: bonusItem.skinId, wear: bonusItem.wear, value: bonusValue } });
      const skin = SKINS[bonusItem.skinId];
      dropRows.push({
        playerId: player.id, playerName: player.name, provider: player.provider,
        caseId: caseDef.id, caseName: caseDef.name, skinId: bonusItem.skinId,
        skinName: skin?.name ?? bonusItem.skinId, value: bonusValue, isRd: true, source: "solo",
        ...(bonusItem.wear ? { wear: bonusItem.wear } : {}),
      });
    } else {
      const item = pickWeighted(caseDef.items, itemFloat);
      const value = caseItemValue(item);
      credited += value;
      pulls.push({ skinId: item.skinId, wear: item.wear, value, rd: false, f: [gateFloat, itemFloat] });
      const skin = SKINS[item.skinId];
      dropRows.push({
        playerId: player.id, playerName: player.name, provider: player.provider,
        caseId: caseDef.id, caseName: caseDef.name, skinId: item.skinId,
        skinName: skin?.name ?? item.skinId, value, isRd: false, source: "solo",
        ...(item.wear ? { wear: item.wear } : {}),
      });
    }
  }

  // Task 78: park the win — the balance stays price-deducted until the reveal
  // completes and the client claims; the Drop rows + LIVE feed land with it.
  // SERVER PROVABLY FAIR (Task 151): the round also lands a FairRoll row — the
  // player's verifiable bet history (nonces + outcomes; the floats are
  // re-computable once the seed is revealed via /api/fair/rotate).
  const pendingId = "op_" + crypto.randomUUID();
  await db.openPending.create({
    data: {
      id: pendingId,
      playerId: player.id,
      caseId: caseDef.id,
      amount: credited,
      count,
      drops: JSON.stringify(dropRows),
    },
  });
  await db.fairRoll.create({
    data: {
      playerId: player.id,
      game: "open",
      ref: caseDef.id,
      seedHash: seed.serverSeedHash,
      clientSeed: seed.clientSeed,
      nonce: start,
      detail: JSON.stringify({
        caseName: caseDef.name,
        count,
        rdChance: rolldropChanceOf(caseDef),
        reels: pulls.map((p, i) => ({
          n: start + 2 * i,
          ni: start + 2 * i + 1,
          rd: p.rd,
          skinId: p.skinId,
          ...(p.wear ? { wear: p.wear } : {}), // R43: the fair panel colors the exterior too
          value: p.value,
        })),
      }),
    },
  });
  await bumpCounter("casesOpened", count);
  // Task 29 (USER SPEC): the leaderboard's CASES OPENED ranks players by the
  // PER-PLAYER counter on the Player row — the global Counter bump alone left
  // every leaderboard row at 0 forever. Increment it with every open.
  await db.player
    .update({ where: { id: player.id }, data: { casesOpened: { increment: count } } })
    .catch(() => {});
  // Task 32 (USER SPEC): mission progress lives in the DB — daily cases,
  // FARM cases and $5+ cases feed the board's counters from the server path.
  const missionBumps: Record<string, number> = {};
  if (isDailyCase) missionBumps.casesDaily = 1;
  else {
    if (caseDef.price >= 5) missionBumps.cases5 = count;
    if (caseDef.kind === "farm") missionBumps.casesFarm = count;
  }
  if (Object.keys(missionBumps).length) await trackMissions(player.id, missionBumps);
  publish("stats", { at: Date.now() });

  // ANTI-CHEAT (Task 108): the SERVER awards the battle-pass XP for this
  // opening — the same caseXp math the client mirrors for its animation, but
  // the DB only ever grows through server-verified actions.
  await awardXp(player.id, caseXp(caseDef) * count);

  return NextResponse.json({
    pulls,
    credited,
    charged: price,
    // USER SPEC (Task 183): how many of the reels were paid by gifted free
    // boxes (0 = a plain paid open) + the player's fresh freeCases map so the
    // session chip updates the moment the reveal starts.
    freeUsed,
    freeCases: freeLeft,
    balance: balanceAfter, // price deducted — the win is NOT on yet
    pendingId,
    dailyNextIn: isDailyCase ? dailyNextIn : 0,
    // SERVER PROVABLY FAIR (Task 151): the commitment this round was decided
    // against — the client mirrors it into every reel's proof chip. The raw
    // serverSeed stays hidden until the player rotates the seed.
    fair: {
      hash: seed.serverSeedHash,
      clientSeed: seed.clientSeed,
      startNonce: start,
    },
  });
}
