import { NextRequest, NextResponse } from "next/server";
import { CASES, type CaseDef } from "@/lib/cases";
import { findCommunityCase } from "@/lib/server/community-cases";
import { rateLimit, TOO_MANY, ipOf } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

// USER SPEC (battles × COMMUNITY/EVENT): the battle room views render the
// round strip and the reels from CaseDefs — the static catalog resolves
// client-side, but player-built cc_* cases live in the DB. The room fetches
// exactly the round ids it cannot resolve locally and merges them over the
// catalog (the defs are public data — the same drops anyone can view).

const MAX_IDS = 60;

export async function GET(req: NextRequest) {
  if (!rateLimit(`cases-resolve:${ipOf(req.headers)}`, 120, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const ids = new URLSearchParams(req.nextUrl.search).get("ids") ?? "";
  const list = [...new Set(ids.split(",").map((s) => s.trim()).filter(Boolean))].slice(0, MAX_IDS);
  if (list.length === 0) return NextResponse.json({ cases: [] });

  const defs: CaseDef[] = [];
  for (const id of list) {
    const staticDef = CASES.find((c) => c.id === id);
    if (staticDef) {
      defs.push(staticDef);
      continue;
    }
    const cc = await findCommunityCase(id).catch(() => undefined);
    if (cc) defs.push(cc);
  }
  return NextResponse.json({ cases: defs });
}
