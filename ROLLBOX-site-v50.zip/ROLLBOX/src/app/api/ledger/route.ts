import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * GET /api/ledger — the signed-in player's money history, straight from the
 * DATABASE (Task 64): every bonus, entry, refund, win and trade the server
 * ever validated for this account. Newest first.
 * USER SPEC (Task 83): the BALANCE HISTORY page consumes this — `take`
 * query param (10..300, default 120) sizes the row page, and `totals`
 * (credits / spent / net / count) is computed over EVERY row of the account,
 * not just the returned page.
 */
export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`ledger:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const raw = Number(req.nextUrl.searchParams.get("take") ?? "120");
  const take = Math.max(10, Math.min(300, Number.isFinite(raw) ? Math.floor(raw) : 120));

  const [rows, credits, debits, count] = await Promise.all([
    db.ledger.findMany({
      where: { playerId: player.id },
      orderBy: { id: "desc" },
      take,
    }),
    db.ledger.aggregate({
      where: { playerId: player.id, amount: { gt: 0 } },
      _sum: { amount: true },
    }),
    db.ledger.aggregate({
      where: { playerId: player.id, amount: { lt: 0 } },
      _sum: { amount: true },
    }),
    db.ledger.count({ where: { playerId: player.id } }),
  ]);

  const creditSum = credits._sum.amount ?? 0;
  const debitSum = debits._sum.amount ?? 0;

  return NextResponse.json({
    ledger: rows.map((r) => ({
      id: r.id,
      kind: r.kind,
      amount: r.amount,
      balanceAfter: r.balanceAfter,
      ref: r.ref,
      at: r.createdAt.getTime(),
    })),
    balance: player.balance,
    totals: {
      credits: creditSum,
      spent: debitSum,
      net: creditSum + debitSum,
      count,
      showing: rows.length,
    },
  });
}
