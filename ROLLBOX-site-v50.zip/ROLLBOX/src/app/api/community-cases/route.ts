import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import {
  communityPriceOf,
  newestCommunityCases,
  validateCommunityItems,
} from "@/lib/server/community-cases";
import { isCommunityDesign } from "@/lib/community-designs";

export const dynamic = "force-dynamic";

/**
 * GET /api/community-cases — the 10 NEWEST player-built cases (USER SPEC:
 * the home-page section always reads the 10 latest rows from the DB; the
 * client rotates the display every 30 minutes).
 */
export async function GET() {
  try {
    const cases = await newestCommunityCases(10);
    return NextResponse.json({ cases });
  } catch {
    return NextResponse.json({ error: "Could not load community cases" }, { status: 500 });
  }
}

/**
 * POST /api/community-cases — PUBLISH CASE (USER SPEC Task 142). Signed-in
 * player only. The server re-validates EVERYTHING (1..10 skins, catalog
 * prices, weights = exactly 100%) and computes the price itself from the
 * EV/house-edge formula — the client never dictates money.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in to publish a case" }, { status: 401 });
  if (player.bannedAt) return NextResponse.json({ error: "You are banned" }, { status: 403 });

  // publishing is a deliberate, rare action — 5 per 10 minutes is plenty
  if (!rateLimit(`ccpub:${player.id}`, 5, 600_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { name?: unknown; design?: unknown; items?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const name = String(body.name ?? "").trim().replace(/\s+/g, " ");
  if (name.length < 3 || name.length > 32) {
    return NextResponse.json({ error: "The case name must be 3-32 characters" }, { status: 400 });
  }

  const design = String(body.design ?? "");
  if (!isCommunityDesign(design)) {
    return NextResponse.json({ error: "Pick a design for your case" }, { status: 400 });
  }

  const check = validateCommunityItems(body.items);
  if (!check.ok) return NextResponse.json({ error: check.error }, { status: 400 });

  const price = communityPriceOf(check.items);
  const id = `cc_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  const row = await db.communityCase
    .create({
      data: {
        id,
        creatorId: player.id,
        creatorName: player.name,
        name,
        design,
        price,
        items: JSON.stringify(check.items),
      },
    })
    .catch(() => null);
  if (!row) return NextResponse.json({ error: "Could not publish the case" }, { status: 500 });

  return NextResponse.json({
    id: row.id,
    name: row.name,
    price: row.price,
    design: row.design,
    creatorName: row.creatorName,
  });
}
