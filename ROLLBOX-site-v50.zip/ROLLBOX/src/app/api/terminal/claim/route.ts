import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { claimTerminal } from "@/lib/server/terminal";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * POST /api/terminal/claim { playId, index } — USER SPEC (Task 23): approve
 * EXACTLY ONE of the dealer's 5 offers. The chosen skin lands in the DATABASE
 * inventory at the offered value; the other four offers expire. The atomic
 * claimed flag makes a double approval impossible.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`terminalclaim:${player.id}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { playId?: string; index?: number };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const result = await claimTerminal(player.id, String(body.playId ?? ""), body.index);
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status });
  return NextResponse.json({ ok: true, item: result.item });
}
