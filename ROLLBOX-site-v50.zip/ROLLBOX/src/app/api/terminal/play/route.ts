import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { playTerminal } from "@/lib/server/terminal";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * POST /api/terminal/play { dealerId, amount } — USER SPEC (Task 23): pay a
 * deal to one of the 5 weapon dealers and get HIS 5 skin offers back (drawn
 * server-side from the dealer's 10-skin % table, values scaled by amount/max).
 * Nothing is granted yet — the player approves exactly ONE offer through
 * /api/terminal/claim.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  // deals are deliberate clicks — 30/min is plenty
  if (!rateLimit(`terminal:${player.id}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { dealerId?: string; amount?: number };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const result = await playTerminal(player, String(body.dealerId ?? ""), body.amount);
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status });
  return NextResponse.json(result.result);
}
