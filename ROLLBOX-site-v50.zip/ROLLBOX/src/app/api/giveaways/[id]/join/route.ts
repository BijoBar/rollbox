import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * QOL (Task 167): POST — join an active giveaway. One entry per player per
 * giveaway (DB unique index; the race lands on a 409, never on a double
 * entry). Banned/signed-out players get the flat 404 wall.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`gwjoin:${player.id}`, 10, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const { id } = await params;
  const gw = await db.giveaway.findUnique({ where: { id }, select: { id: true, status: true, endsAt: true } });
  if (!gw || gw.status !== "active" || gw.endsAt.getTime() <= Date.now()) {
    return NextResponse.json({ error: "This giveaway is not open" }, { status: 409 });
  }
  try {
    await db.giveawayEntry.create({
      data: { id: "ge_" + crypto.randomUUID().replace(/-/g, "").slice(0, 20), giveawayId: id, playerId: player.id },
    });
  } catch {
    return NextResponse.json({ error: "You already joined this giveaway" }, { status: 409 });
  }
  return NextResponse.json({ ok: true });
}
