import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { drawGiveaway } from "@/lib/server/giveaways";

export const dynamic = "force-dynamic";

/**
 * QOL (Task 167): public giveaways list.
 *  GET → { active: [...], recent: [...] } — every ACTIVE giveaway that has
 *  passed its endsAt is lazily drawn right here (first read after the
 *  deadline pays the winners), so prizes never wait for the admin to click.
 */
export async function GET(req: NextRequest) {
  if (!rateLimit("giveaways:list", 120, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  // lazy auto-draw: every overdue active giveaway settles on first read
  const overdue = await db.giveaway.findMany({ where: { status: "active", endsAt: { lte: new Date() } }, select: { id: true } });
  for (const g of overdue) await drawGiveaway(g.id).catch(() => null);

  const me = await sessionPlayer(req);
  const [active, recent, myEntries] = await Promise.all([
    db.giveaway.findMany({
      where: { status: "active", endsAt: { gt: new Date() } },
      orderBy: { endsAt: "asc" },
      include: { _count: { select: { entries: true } } },
    }),
    db.giveaway.findMany({ where: { status: "drawn" }, orderBy: { endsAt: "desc" }, take: 6 }),
    me ? db.giveawayEntry.findMany({ where: { playerId: me.id }, select: { giveawayId: true } }) : Promise.resolve([]),
  ]);
  const mine = new Set(myEntries.map((e) => e.giveawayId));

  const shape = (g: (typeof active)[number]) => ({
    id: g.id,
    title: g.title,
    prizeCoins: g.prizeCoins,
    prizeLabel: g.prizeLabel,
    winnerCount: g.winnerCount,
    endsAt: g.endsAt.getTime(),
    entries: g._count?.entries ?? 0,
    entered: mine.has(g.id),
  });
  const shapeDrawn = (g: (typeof recent)[number]) => ({
    id: g.id,
    title: g.title,
    prizeCoins: g.prizeCoins,
    prizeLabel: g.prizeLabel,
    endsAt: g.endsAt.getTime(),
    winners: JSON.parse(g.winners ?? "[]") as { playerId: string; name: string }[],
  });

  return NextResponse.json({
    active: active.map(shape),
    recent: recent.map(shapeDrawn),
    signedIn: !!me,
  });
}
