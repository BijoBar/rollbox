import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { checkSpendAllowed } from "@/lib/server/selfcare";
import { catalogEntry, catalogEntryCoins, catalogWearCoins } from "@/lib/server/catalog";
import { findStockItem } from "@/lib/server/steam-stock";
import { expandImg } from "@/lib/skin-img";
import { publishBalance, recordLedger } from "@/lib/server/ledger";
import { publish, publishTo } from "@/lib/server/realtime";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { coinsToUsd, WEAR_BY_ID, isWearId, type WearId } from "@/lib/wear";

export const dynamic = "force-dynamic";

const newItemId = () => "i_" + crypto.randomBytes(8).toString("hex");

/** GET /api/inventory — the player's skins, FROM THE DATABASE (Task 64).
 *  USER SPEC (Task 29) SELF-HEAL: terminal grants used to snapshot items
 *  WITHOUT an image. Any imageless row whose entryId resolves in the server
 *  catalog gets its img / p / cat / a baked in on read (the name, the weapon
 *  label and the coin value are never touched) — old rows fix themselves the
 *  first time the inventory loads after this update.
 *  USER SPEC (Task 26) SELF-HEAL #2: steam-bought rows used to snapshot the
 *  COMPACT "~1…" shorthand the exchange browser understands but the plain
 *  <img> surfaces don't — any row still carrying a "~" img gets the full CDN
 *  URL baked in on read, so every existing skin regains its picture without
 *  a migration. */
export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`inv:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const rows = await db.inventoryItem.findMany({
    where: { playerId: player.id },
    orderBy: { id: "desc" },
  });

  const items = await Promise.all(
    rows.map(async (r) => {
      let data: Record<string, unknown> = {};
      try {
        data = JSON.parse(r.data) as Record<string, unknown>;
      } catch {
        data = {};
      }
      if (!data.img) {
        const entry = catalogEntry(r.entryId);
        if (entry && (entry.img || entry.a)) {
          const patched: Record<string, unknown> = { ...data };
          if (patched.img === undefined && entry.img) patched.img = entry.img;
          if (patched.a === undefined && entry.a) patched.a = entry.a;
          if (patched.p === undefined && entry.p !== undefined) patched.p = entry.p;
          if (patched.cat === undefined && entry.cat !== undefined) patched.cat = entry.cat;
          if (patched.img !== data.img || patched.a !== data.a) {
            data = patched;
            // persist once so the fix sticks (best-effort — the read still wins)
            await db.inventoryItem
              .update({ where: { id: r.id }, data: { data: JSON.stringify(patched) } })
              .catch(() => {});
          }
        }
      } else if (typeof data.img === "string" && data.img.startsWith("~")) {
        // Task 26: compact shorthand → the real CDN URL (persisted, best-effort)
        const expanded = expandImg(data.img);
        if (expanded && expanded !== data.img) {
          const patched = { ...data, img: expanded };
          data = patched;
          await db.inventoryItem
            .update({ where: { id: r.id }, data: { data: JSON.stringify(patched) } })
            .catch(() => {});
        }
      }
      return { uid: r.id, ...data, v: r.value, at: r.createdAt.getTime() };
    }),
  );

  return NextResponse.json({ items });
}

/**
 * POST /api/inventory — the EXCHANGE, fully server-side (Task 64).
 * Body: { entryId, wear? } — the client picks a catalog ITEM (and, since
 * Task 72, the exterior it wants), never a price. The server loads the
 * authoritative entry, resolves the wear price from ITS catalog copy, charges
 * atomically and writes the item to the DATABASE. A tampered client cannot buy
 * a 280K-coin knife for 1: the id (+ wear) decides the price, not the request.
 *
 * USER SPEC (this task): ids shaped "steam:<assetid>" buy straight from the
 * LIVE Steam inventory — the same feed the exchange browses. The price is the
 * server's own resolution for that asset (catalog match / rarity fallback).
 * USER SPEC (Task 24 — 5-MINUTE SYNC): a purchase NO LONGER removes the skin
 * from the exchange — the tile stays listed; only the sync decides what the
 * list holds (skins that left the Steam inventory are the only ones that
 * leave it).
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  // ANTI-CHEAT (Task 108): buys are deliberate clicks — 30/min is plenty.
  if (!rateLimit(`buy:${player.id}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { entryId?: string; wear?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const rawId = String(body.entryId ?? "");

  // ---- LIVE STEAM STOCK branch — the exchange's own inventory feed ----
  if (rawId.startsWith("steam:")) {
    const stockItem = await findStockItem(rawId);
    if (!stockItem) {
      // the 5-minute sync no longer sees this asset in the Steam inventory
      return NextResponse.json({ error: "This item just left the stock" }, { status: 410 });
    }
    const coins = stockItem.v;
    if (!Number.isFinite(coins) || coins <= 0) {
      return NextResponse.json({ error: "Unknown item" }, { status: 400 });
    }
    const blocked = await checkSpendAllowed(player, coins);
    if (blocked) return NextResponse.json({ error: blocked }, { status: 403 });
    const charged = await db.player
      .update({ where: { id: player.id, balance: { gte: coins } }, data: { balance: { decrement: coins } } })
      .catch(() => null);
    if (!charged) return NextResponse.json({ error: "Not enough funds" }, { status: 400 });

    // USER SPEC (Task 24): NO markSold — the skin stays on the shelf; the
    // sync alone governs the list.
    const { wear: _w0, wearLabel: _wl0, ...base } = stockItem;
    const snapshot: Record<string, unknown> = { ...base, n: stockItem.name, v: coins };
    // USER SPEC (Task 26): bake the FULL CDN URL into the snapshot — the
    // "~1…" shorthand is an exchange-internal compact form, the inventory
    // surfaces need a real src.
    if (typeof snapshot.img === "string" && snapshot.img.startsWith("~")) {
      snapshot.img = expandImg(snapshot.img);
    }
    if (stockItem.wear) {
      snapshot.wear = stockItem.wear;
      snapshot.wearLabel = stockItem.wearLabel;
    }

    const row = await db.inventoryItem.create({
      data: {
        id: newItemId(),
        playerId: player.id,
        entryId: stockItem.id,
        data: JSON.stringify(snapshot),
        value: coins,
        ...(stockItem.wear ? { wear: stockItem.wear } : {}),
      },
    });

    await recordLedger(player.id, "trade_buy", -coins, charged.balance, String(snapshot.n));
    publishBalance(player.id, charged.balance);
    publishTo(player.id, "inventory", { playerId: player.id });
    publish("stats", { at: Date.now() });

    let data: Record<string, unknown> = {};
    try {
      data = JSON.parse(row.data) as Record<string, unknown>;
    } catch {
      data = {};
    }
    return NextResponse.json({
      balance: charged.balance,
      item: { uid: row.id, ...data, v: row.value, at: row.createdAt.getTime() },
    });
  }

  const entry = catalogEntry(rawId);
  // Task 27: the charge goes through catalogEntryCoins — the REAL unified
  // price when the table holds the name, the catalog value otherwise.
  const baseCoins = entry ? catalogEntryCoins(entry) : NaN;
  if (!entry || !Number.isFinite(baseCoins) || baseCoins <= 0) {
    return NextResponse.json({ error: "Unknown item" }, { status: 400 });
  }

  // Task 72: optional exterior — the price is the SERVER's wear price, and a
  // wear the skin does not come in is rejected outright.
  let wear: WearId | null = null;
  let coins = baseCoins;
  if (body.wear != null && body.wear !== "") {
    if (!isWearId(body.wear)) return NextResponse.json({ error: "Unknown exterior" }, { status: 400 });
    const wearCoins = catalogWearCoins(entry, body.wear);
    if (wearCoins == null) return NextResponse.json({ error: "Exterior not available" }, { status: 400 });
    wear = body.wear;
    coins = wearCoins;
  }

  // USER SPEC (Task 75): SELF CARE — a TAKE A BREAK block or a deposit limit
  // stops the buy BEFORE the charge (server-enforced, not a UI trick).
  const blocked = await checkSpendAllowed(player, coins);
  if (blocked) return NextResponse.json({ error: blocked }, { status: 403 });

  const charged = await db.player
    .update({ where: { id: player.id, balance: { gte: coins } }, data: { balance: { decrement: coins } } })
    .catch(() => null);
  if (!charged) return NextResponse.json({ error: "Not enough funds" }, { status: 400 });

  // the stored snapshot IS the item: wear label baked into the display name so
  // every inventory surface shows "AK-47 | Redline (Field-Tested)". The bulk
  // wear price tables stay OUT of the snapshot (rows stay lean).
  const { wp: _wp, wa: _wa, ...base } = entry;
  const snapshot: Record<string, unknown> = { ...base, v: coins };
  if (wear) {
    snapshot.n = `${entry.n} (${WEAR_BY_ID[wear].label})`;
    snapshot.p = coinsToUsd(coins); // Task 27: rate-aware reverse (was a hardcoded ÷10)
    snapshot.wear = wear;
  }

  const row = await db.inventoryItem.create({
    data: {
      id: newItemId(),
      playerId: player.id,
      entryId: entry.id,
      data: JSON.stringify(snapshot),
      value: coins,
      ...(wear ? { wear } : {}),
    },
  });

  await recordLedger(player.id, "trade_buy", -coins, charged.balance, String(snapshot.n));
  publishBalance(player.id, charged.balance);
  publishTo(player.id, "inventory", { playerId: player.id });
  publish("stats", { at: Date.now() });

  let data: Record<string, unknown> = {};
  try {
    data = JSON.parse(row.data) as Record<string, unknown>;
  } catch {
    data = {};
  }
  return NextResponse.json({
    balance: charged.balance,
    item: { uid: row.id, ...data, v: row.value, at: row.createdAt.getTime() },
  });
}
