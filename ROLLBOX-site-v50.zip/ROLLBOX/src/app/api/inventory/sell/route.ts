import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { publishBalance, recordLedger } from "@/lib/server/ledger";
import { publishTo } from "@/lib/server/realtime";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { trackMissions } from "@/lib/server/missions";

export const dynamic = "force-dynamic";

/**
 * POST /api/inventory/sell — sell skins back, SERVER-VALIDATED (Task 64).
 * Body: { uids: string[] } or { all: true }. The server loads the rows owned
 * by THIS player, credits the values IT stored at buy time and deletes the
 * rows. The old client-decided `credit` amount is GONE — a tampered client
 * can no longer print coins by selling skins it never owned for any price.
 * ANTI-CHEAT (Task 108): the whole find+credit+delete now runs inside ONE
 * transaction — two concurrent sells of the same items can no longer both
 * see the rows and double-credit the balance (SQLite serializes writers).
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  // ANTI-CHEAT (Task 108): "sell all" is one press — 15/min is generous.
  if (!rateLimit(`sell:${player.id}`, 15, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { uids?: string[]; all?: boolean };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const where =
    body.all === true
      ? { playerId: player.id }
      : Array.isArray(body.uids) && body.uids.length
        ? { playerId: player.id, id: { in: body.uids.filter((u) => typeof u === "string").slice(0, 200) } }
        : null;
  if (!where) return NextResponse.json({ error: "Nothing to sell" }, { status: 400 });

  const credit = await db
    .$transaction(async (tx) => {
      const rows = await tx.inventoryItem.findMany({ where });
      if (!rows.length) return null;
      // delete FIRST — the rows are atomically claimed by THIS transaction;
      // a racing sell finds nothing left and credits nothing
      await tx.inventoryItem.deleteMany({ where: { id: { in: rows.map((r) => r.id) } } });
      const sum = rows.reduce((s, r) => s + Math.max(0, r.value), 0);
      const updated = await tx.player.update({
        where: { id: player.id },
        data: { balance: { increment: sum } },
      });
      // HARDENING (Task 153): the ledger row now rides the SAME transaction —
      // the credit and its audit row commit (or roll back) together. Handing
      // recordLedger the tx client is what makes this deadlock-free: the old
      // note applied to it using the GLOBAL db inside the callback.
      await recordLedger(
        player.id,
        "trade_sell",
        sum,
        updated.balance,
        rows.length === 1 ? (rows[0]?.entryId ?? undefined) : `${rows.length} items`,
        tx
      );
      return { credit: sum, balance: updated.balance, sold: rows.length };
    })
    .catch(() => null);

  if (!credit) {
    // nothing found (empty inventory / a racing sell got there first)
    const fresh = await db.player.findUnique({ where: { id: player.id }, select: { balance: true } });
    if (fresh) return NextResponse.json({ balance: fresh.balance, credit: 0, sold: 0 });
    return NextResponse.json({ error: "Could not credit the sale" }, { status: 500 });
  }

  // Task 32 (USER SPEC): mission progress lives in the DB — the Contractor
  // mission counts skins sold back to the site.
  await trackMissions(player.id, { sold: credit.sold });
  publishBalance(player.id, credit.balance);
  publishTo(player.id, "inventory", { playerId: player.id });

  return NextResponse.json({ balance: credit.balance, credit: credit.credit, sold: credit.sold });
}
