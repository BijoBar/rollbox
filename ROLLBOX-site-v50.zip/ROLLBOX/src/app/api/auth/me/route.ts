import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayerAllowBanned } from "@/lib/server/auth";
import { claimOpenPendings } from "@/lib/server/opens";
import { recoverTerminalPendings } from "@/lib/server/terminal";
import { parseFreeCases } from "@/lib/server/freecases";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/** The signed-in player's public data — polled by the header chip.
 *  USER SPEC (Task 180): a PERMANENTLY banned player is SIGNED IN — the
 *  identity resolves (with bannedAt) so the site greets them with the
 *  BanGuard shield instead of a fake "Sign-in failed". This is the ONLY
 *  route that lets a banned session through, and it is strictly read-only;
 *  every action route keeps sessionPlayer (banned = null = 401). */
export async function GET(req: NextRequest) {
  const player = await sessionPlayerAllowBanned(req);
  if (!player) return NextResponse.json({ player: null });

  // the client heartbeats this every 15s — 60/min leaves huge headroom while
  // stopping a hammering script from making the DB work overtime
  if (!rateLimit(`me:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  // USER SPEC (Task 180): a banned player's me is a pure identity read —
  // no pendings are recovered and no gameplay state is touched. The row is
  // already fully loaded; the client renders the ban shield from bannedAt.
  if (player.bannedAt) {
    return NextResponse.json({
      player: {
        id: player.id,
        name: player.name,
        avatar: player.avatar,
        provider: player.provider,
        providerId: player.providerId,
        balance: player.balance,
        casesOpened: player.casesOpened,
        battlesWon: player.battlesWon,
        xp: player.xp,
        level: player.level,
        createdAt: player.createdAt,
        tradeLink: player.tradeLink,
        email: player.email,
        depositLimit: player.depositLimit,
        depositLimitDays: player.depositLimitDays,
        depositLimitStart: player.depositLimitStart,
        breakUntil: player.breakUntil,
        isAdmin: player.isAdmin,
        refCode: player.refCode,
        referredBy: player.referredBy,
        nameCustom: player.nameCustom,
        avatarCustom: player.avatarCustom,
        // USER SPEC (Task 183): identity-only read — the free-cases chip still
        // renders from the same map (a banned account cannot OPEN anything).
        freeCases: parseFreeCases(player.freeCases),
        bannedAt: player.bannedAt.toISOString(),
      },
    });
  }

  // USER SPEC (Task 78): recover solo-open rounds whose tab died mid-spin —
  // a win decided by the server can never be lost. Only pendings older than
  // PENDING_STALE_MS are touched here, so a live animation is never raced;
  // the fresh round claims itself through /api/open/claim at the reveal.
  await claimOpenPendings(player.id, { staleOnly: true }).catch(() => null);
  // USER SPEC (Task 23): a TERMINAL deal whose tab died before the player
  // approved one offer — the LOWEST offer lands in the inventory instead
  // (walking away can never be the profitable move).
  await recoverTerminalPendings(player.id).catch(() => null);

  const fresh = (await db.player.findUnique({
    where: { id: player.id },
  })) ?? player;
  return NextResponse.json({
    player: {
      id: fresh.id,
      name: fresh.name,
      avatar: fresh.avatar,
      provider: fresh.provider,
      // USER SPEC (Task 81): the Steam id64 — the profile's STEAM button links
      // https://steamcommunity.com/profiles/<id64> with it.
      providerId: fresh.providerId,
      balance: fresh.balance,
      casesOpened: fresh.casesOpened,
      battlesWon: fresh.battlesWon,
      // USER SPEC (Task 104): the DB battle pass — the client adopts this xp
      // whenever its local copy is behind (fresh device / second browser).
      xp: fresh.xp,
      level: fresh.level,
      createdAt: fresh.createdAt,
      // USER SPEC (Task 75): settings + SELF CARE ride on the session too —
      // the BreakGuard overlay and the settings panel read them from here.
      tradeLink: fresh.tradeLink,
      email: fresh.email,
      depositLimit: fresh.depositLimit,
      depositLimitDays: fresh.depositLimitDays,
      depositLimitStart: fresh.depositLimitStart,
      breakUntil: fresh.breakUntil,
      // USER SPEC (Task 22): the admin chip in the TopBar + the referral code
      // on the profile both read the DATABASE columns through the session.
      isAdmin: fresh.isAdmin,
      refCode: fresh.refCode,
      // USER SPEC (Task 23): code-only referral — hides the code entry once applied.
      referredBy: fresh.referredBy,
      // C12: the identity flags drive the settings page's "Reset to Steam".
      nameCustom: fresh.nameCustom,
      avatarCustom: fresh.avatarCustom,
      // USER SPEC (Task 183): the player's gifted / mission-prize FREE boxes —
      // the FREE ×N chip next to every case name reads this map.
      freeCases: parseFreeCases(fresh.freeCases),
      // USER SPEC (Task 180): always null on this path (sessionPlayer filters
      // banned rows) — carried for a uniform client shape with the ban branch.
      bannedAt: null,
    },
  });
}
