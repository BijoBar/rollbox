import { NextResponse, type NextRequest } from "next/server";
import { publicOrigin } from "@/lib/server/public-origin";
import { ipOf, rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * Steam sign-in — OpenID 2.0 redirect (no API key needed to LOG IN).
 * Steam shows its own login page and returns the user to our callback.
 * return_to/realm MUST be the PUBLIC address the player's browser actually
 * uses — behind Cloudflare Tunnel that is never localhost
 * (see public-origin.ts for the "localhost sent an invalid response" saga).
 */
export async function GET(req: NextRequest) {
  // ANTI-CHEAT (Task 108): pre-auth route — key by IP so a script cannot pump
  // Steam-login redirects (each one also makes Steam fetch OUR callback).
  if (!rateLimit(`steam:${ipOf(req.headers)}`, 10, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const origin = publicOrigin(req);
  const params = new URLSearchParams({
    "openid.ns": "http://specs.openid.net/auth/2.0",
    "openid.mode": "checkid_setup",
    "openid.return_to": `${origin}/api/auth/steam/callback`,
    "openid.realm": origin,
    "openid.identity": "http://specs.openid.net/auth/2.0/identifier_select",
    "openid.claimed_id": "http://specs.openid.net/auth/2.0/identifier_select",
  });
  return NextResponse.redirect(`https://steamcommunity.com/openid/login?${params.toString()}`);
}
