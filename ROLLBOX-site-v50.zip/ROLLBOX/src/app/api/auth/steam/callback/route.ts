import { NextRequest, NextResponse } from "next/server";
import { makeSessionToken, SESSION_COOKIE, sessionCookieOptions, upsertPlayer } from "@/lib/server/auth";
import { publicOrigin, sanitizePublicOrigin } from "@/lib/server/public-origin";

export const dynamic = "force-dynamic";

/** Decode the few XML entities Steam uses inside profile names. */
const decodeXml = (s: string) =>
  s
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");

/** First <tag>value</tag> in the profile XML — CDATA-wrapped or plain. */
const xmlTag = (xml: string, name: string): string | null => {
  const m = xml.match(new RegExp(`<${name}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${name}>`));
  return m ? m[1].trim() : null;
};

/**
 * Real Steam identity — persona name + full avatar URL, exactly as they appear
 * on the public profile. With STEAM_API_KEY: the official GetPlayerSummaries
 * API. Without one: the public profile endpoint (?xml=1), which needs NO key —
 * the nickname and avatar are public even when the rest of the profile is
 * private. Cosmetic only — any failure keeps the neutral fallback name.
 */
async function fetchSteamProfile(steamId: string): Promise<{ name: string | null; avatar: string | null }> {
  const key = process.env.STEAM_API_KEY;
  if (key) {
    try {
      const r = await fetch(
        `https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=${key}&steamids=${steamId}`,
        { cache: "no-store", signal: AbortSignal.timeout(6000) }
      );
      const data = (await r.json()) as { response?: { players?: { personaname?: string; avatarfull?: string }[] } };
      const p = data.response?.players?.[0];
      return { name: p?.personaname ?? null, avatar: p?.avatarfull ?? null };
    } catch {
      return { name: null, avatar: null };
    }
  }
  try {
    const r = await fetch(`https://steamcommunity.com/profiles/${steamId}/?xml=1`, {
      cache: "no-store",
      signal: AbortSignal.timeout(6000),
    });
    const xml = await r.text();
    const name = xmlTag(xml, "steamID");
    const avatar = xmlTag(xml, "avatarFull");
    return { name: name ? decodeXml(name) : null, avatar: avatar || null };
  } catch {
    return { name: null, avatar: null };
  }
}

/**
 * Steam OpenID callback — verify the assertion WITH Steam (check_authentication),
 * extract the steamid64, fetch the real profile (name + avatar), upsert the
 * player, set the session, go home.
 */
export async function GET(req: NextRequest) {
  /**
   * Redirect base = the origin the BROWSER used when the flow started.
   * openid.return_to carries it, and Steam SIGNS return_to (it is inside
   * openid.signed) — check_authentication below just validated the whole
   * assertion, so on SUCCESS its origin is the safest redirect base.
   * On FAILURE return_to is unvalidated attacker input, so the error
   * redirect uses the strict resolver instead (no browser headers either —
   * on the way back from Steam they belong to steamcommunity.com).
   */
  const returnToOrigin = sanitizePublicOrigin(req.nextUrl.searchParams.get("openid.return_to"));
  const strictOrigin = () => publicOrigin(req, { strict: true });

  // Steam asserts via query params — forward them back for verification
  const claim = new URLSearchParams();
  req.nextUrl.searchParams.forEach((v, k) => {
    if (k.startsWith("openid.")) claim.set(k, v);
  });
  claim.set("openid.mode", "check_authentication");

  let steamId: string | null = null;
  try {
    const verify = await fetch("https://steamcommunity.com/openid/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: claim.toString(),
      cache: "no-store",
      signal: AbortSignal.timeout(8000),
    });
    const text = await verify.text();
    if (!text.includes("is_valid:true")) steamId = null;
    else {
      const claimed = claim.get("openid.claimed_id") ?? "";
      const m = claimed.match(/\/openid\/id\/(\d{17})$/);
      steamId = m ? m[1] : null;
    }
  } catch {
    steamId = null;
  }

  if (!steamId) {
    return NextResponse.redirect(`${strictOrigin()}/login?error=steam`);
  }

  const profile = await fetchSteamProfile(steamId);
  const name = profile.name ?? `Steam ${steamId.slice(-4)}`;

  const player = await upsertPlayer("steam", steamId, name, profile.avatar);

  // USER SPEC (Task 180): a PERMANENTLY banned player now SIGNS IN like
  // anyone else — the session is minted and the site greets them with the
  // full-screen ban shield (BanGuard) instead of a fake "Sign-in failed".
  // Task 22 semantics live on where they matter: sessionPlayer keeps
  // returning null for banned rows, so every ACTION route refuses them.
  const res = NextResponse.redirect((returnToOrigin ?? strictOrigin()) + "/");
  res.cookies.set(SESSION_COOKIE, makeSessionToken(player.id), sessionCookieOptions());
  return res;
}
