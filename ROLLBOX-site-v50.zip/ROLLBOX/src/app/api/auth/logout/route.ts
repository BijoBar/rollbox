import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE } from "@/lib/server/auth";
import { rateLimit, ipOf, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  // HARDENING (Task 153): logout is trivial — the cap only stops junk floods.
  if (!rateLimit(`out:${ipOf(req.headers)}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, "", { path: "/", maxAge: 0 });
  return res;
}
