import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { publishBalance, recordLedger } from "@/lib/server/ledger";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { trackMissions } from "@/lib/server/missions";

export const dynamic = "force-dynamic";

/** USER SPEC (Task 142): the TOPUP cap per single BUY is now $10,000. */
const TOPUP_MAX = 10_000;
/** USER SPEC (Task 142): the referral gift the INVITER gets for a friend. */
const REF_INVITER_GIFT = 1.5;
/** USER SPEC (Task 142): the invitee's extra % on his FIRST deposit. */
const REF_INVITEE_PCT = 0.05;

/**
 * POST /api/topup { amount, refCode? } — the WALLET deposit. Money on ROLLBOX
 * is not real (USER SPEC): the player types an amount, presses BUY and the
 * balance is credited — no payment processor behind it. Everything is still
 * server-validated + audited: session required, amount clamped to
 * [1 .. TOPUP_MAX] (2-dec), a Ledger row ("topup") documents the credit and
 * the fresh balance is pushed to every signed-in device.
 *
 * USER SPEC (Task 142) — REFERRAL: the DEPOSIT dialog carries a REFERRAL CODE
 * field. A player who enters a friend's code on his FIRST deposit gets +5%
 * extra coins, and the friend who owns the code gets a flat $1.5 gift. The
 * whole referral is claimed atomically (referredBy IS NULL) — double-pasting
 * the code can never double-pay, and a code can never fire twice.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  // BUY is a deliberate click — 20/min is generous
  if (!rateLimit(`topup:${player.id}`, 20, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { amount?: unknown; refCode?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const amount = Math.round(Number(body.amount) * 100) / 100;
  if (!Number.isFinite(amount) || amount < 1) {
    return NextResponse.json({ error: "Minimum topup is 1 coin" }, { status: 400 });
  }
  if (amount > TOPUP_MAX) {
    return NextResponse.json({ error: `Maximum deposit is $${TOPUP_MAX.toLocaleString("en-US")}` }, { status: 400 });
  }

  // ---- referral pre-checks (before the credit; the claim itself is atomic) ----
  const cleanRef = String(body.refCode ?? "").trim().toUpperCase();
  const wantsReferral = /^[A-Z2-9]{8}$/.test(cleanRef);
  let referralNote: string | undefined;
  let refIgnoredReason: string | undefined;

  const prevTopups = await db.ledger.count({ where: { playerId: player.id, kind: "topup" } }).catch(() => 0);
  const isFirstDeposit = prevTopups === 0;

  if (wantsReferral && !isFirstDeposit) {
    refIgnoredReason = "not_first";
    referralNote = "Referral codes only work on your first deposit.";
  } else if (wantsReferral && (player.referredBy || player.refBonusAt)) {
    refIgnoredReason = "already_used";
    referralNote = "You already used a referral code.";
  } else if (wantsReferral && player.refCode === cleanRef) {
    refIgnoredReason = "own_code";
    referralNote = "You cannot use your own code.";
  }

  // ---- the deposit credit (HARDENING Task 153: credit + ledger row in ONE
  // transaction — the audit row can no longer be split from the credit) ----
  const updated = await db
    .$transaction(async (tx) => {
      const upd = await tx.player.update({
        where: { id: player.id },
        data: { balance: { increment: amount } },
      });
      await recordLedger(player.id, "topup", amount, upd.balance, "Wallet deposit (demo)", tx);
      return upd;
    })
    .catch(() => null);
  if (!updated) return NextResponse.json({ error: "Could not credit the topup" }, { status: 500 });

  // Task 32 (USER SPEC): mission progress lives in the DB — the lifetime
  // deposit total feeds the Verified Player / Daydreamer / Highroller steps.
  await trackMissions(player.id, { depTotal: amount });
  publishBalance(player.id, updated.balance);

  // ---- the referral itself: +5% to the depositor, $1.5 to the inviter ----
  let balance = updated.balance;
  let inviterName: string | undefined;
  let inviteeBonus = 0;

  if (wantsReferral && !refIgnoredReason) {
    const inviter = await db.player.findUnique({ where: { refCode: cleanRef } }).catch(() => null);
    if (!inviter || inviter.bannedAt || inviter.id === player.id) {
      refIgnoredReason = "bad_code";
      referralNote = "Unknown referral code.";
    } else {
      inviteeBonus = Math.max(0.01, Math.round(amount * REF_INVITEE_PCT * 100) / 100);
      const now = new Date();
      // HARDENING (Task 153): the WHOLE referral grant is ONE transaction —
      // the atomic claim (referredBy must still be NULL), the +5% bonus, the
      // inviter's flat gift and BOTH ledger rows commit or roll back together.
      const granted = await db
        .$transaction(async (tx) => {
          const claim = await tx.player.updateMany({
            where: { id: player.id, referredBy: null, refBonusAt: null },
            data: { referredBy: inviter.id, refBonusAt: now, balance: { increment: inviteeBonus } },
          });
          if (claim.count !== 1) return null;
          const fresh = await tx.player.findUnique({ where: { id: player.id }, select: { balance: true } });
          if (!fresh) return null;
          await recordLedger(player.id, "referral_bonus", inviteeBonus, fresh.balance, `+5% first deposit — invited by ${inviter.name}`, tx);
          const gifted = await tx.player.update({
            where: { id: inviter.id },
            data: { balance: { increment: REF_INVITER_GIFT } },
          });
          await recordLedger(inviter.id, "referral_reward", REF_INVITER_GIFT, gifted.balance, `Friend deposited: ${player.name}`, tx);
          return { invitee: fresh.balance, inviter: gifted.balance };
        })
        .catch(() => null);
      if (granted) {
        balance = granted.invitee;
        publishBalance(player.id, granted.invitee);
        publishBalance(inviter.id, granted.inviter);
        inviterName = inviter.name;
        // Task 32: a completed referral counts toward the inviter's missions
        await trackMissions(inviter.id, { refInvites: 1 }).catch(() => {});
      } else {
        inviteeBonus = 0;
        refIgnoredReason = "race_lost";
        referralNote = "You already used a referral code.";
      }
    }
  }

  return NextResponse.json({
    balance,
    referral: wantsReferral && inviterName ? "applied" : "ignored",
    ...(inviterName ? { inviter: inviterName, referralBonus: inviteeBonus } : {}),
    ...(referralNote ? { referralNote } : {}),
    ...(refIgnoredReason ? { reason: refIgnoredReason } : {}),
  });
}
