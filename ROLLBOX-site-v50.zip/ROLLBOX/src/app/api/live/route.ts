import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, ipOf, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/** GET /api/live — the ONE global live-drops feed (latest first).
 * USER SPEC (Task 59): ONLY real players' drops — bot pulls (provider "bot",
 * from bot seats in battles) NEVER reach the public feed (site credibility).
 * USER SPEC (Task 64): the only real provider is STEAM. */
export async function GET(req: NextRequest) {
  // HARDENING (Task 153): the live feed is polled by every tab — 120/min per
  // IP is far above honest refresh cadence.
  if (!rateLimit(`live:${ipOf(req.headers)}`, 120, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }
  const drops = await db.drop.findMany({
    where: { provider: "steam" },
    orderBy: { id: "desc" },
    take: 24,
  });
  return NextResponse.json({
    drops: drops.map((d) => ({
      id: d.id,
      user: d.playerName,
      provider: d.provider,
      caseId: d.caseId,
      skinId: d.skinId,
      wear: d.wear ?? undefined,
      value: d.value,
      isRd: d.isRd,
      source: d.source,
      at: d.createdAt.getTime(),
    })),
  });
}
