import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { FARM_CASES, STANDARD_CASES, LEVEL_CASES_ALL } from "@/lib/cases";
import { rateLimit, ipOf, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/** USER SPEC (Task 32): the CASES stat — every case type that exists on the
 *  site (standard + farm + the free daily level cases), straight from the
 *  catalog so a new case shows up in the strip the moment it ships. */
const CASES_ON_SITE = STANDARD_CASES.length + FARM_CASES.length + LEVEL_CASES_ALL.length;

/**
 * GET /api/stats — the site-wide totals (the strip ABOVE the header).
 *  players       — registered accounts (DB rows)
 *  members       — the persistent members counter (self-seeds from the DB the
 *                  first time it is read, so pre-counter databases stay correct)
 *  casesOpened   — every case ever opened (solo reels + battle rounds)
 *  coinsPaid     — every coin the house ever paid out (wins, refunds excluded)
 *  upgrades      — USER SPEC (Task 32): every UPGRADER spin ever (Counter,
 *                  self-seeds once from the upgrader ledger history)
 *  battlesPlayed — USER SPEC (Task 32): every battle that ever started
 *                  (Counter, self-seeds once from the finished-battle rows)
 *  cases         — USER SPEC (Task 32): how many case types the site carries
 */
export async function GET(req: NextRequest) {
  // HARDENING (Task 153): a public strip polled by every open tab — the IP
  // bucket only stops scripted hammering, never honest refreshes.
  if (!rateLimit(`stats:${ipOf(req.headers)}`, 120, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }
  try {
    const [players, casesRow, coinsRow] = await Promise.all([
      db.player.count(),
      db.counter.findUnique({ where: { key: "casesOpened" } }),
      db.counter.findUnique({ where: { key: "coinsPaid" } }),
    ]);

    // one-time seed: the members counter did not exist on older databases —
    // the first read backfills it with the real registered-account count
    let membersRow = await db.counter.findUnique({ where: { key: "members" } });
    if (!membersRow) {
      const count = players;
      membersRow = await db.counter.upsert({
        where: { key: "members" },
        update: { value: count },
        create: { key: "members", value: count },
      });
    }

    // USER SPEC (Task 32): the upgrades + battlesPlayed counters self-seed the
    // same way — backfilled once from the real history, then kept by the
    // bumpCounter hooks on every live event (real-time + persisted).
    let upgradesRow = await db.counter.findUnique({ where: { key: "upgrades" } });
    if (!upgradesRow) {
      const count = await db.ledger.count({
        where: { kind: { in: ["upgrader_win", "upgrader_loss"] } },
      });
      upgradesRow = await db.counter.upsert({
        where: { key: "upgrades" },
        update: { value: count },
        create: { key: "upgrades", value: count },
      });
    }
    let battlesRow = await db.counter.findUnique({ where: { key: "battlesPlayed" } });
    if (!battlesRow) {
      const count = await db.battle.count({ where: { status: "finished" } });
      battlesRow = await db.counter.upsert({
        where: { key: "battlesPlayed" },
        update: { value: count },
        create: { key: "battlesPlayed", value: count },
      });
    }

    return NextResponse.json({
      players,
      members: Math.max(0, membersRow.value),
      casesOpened: Math.max(0, casesRow?.value ?? 0),
      coinsPaid: Math.max(0, coinsRow?.value ?? 0),
      upgrades: Math.max(0, upgradesRow.value),
      battlesPlayed: Math.max(0, battlesRow.value),
      cases: CASES_ON_SITE,
    });
  } catch {
    return NextResponse.json({
      players: 0,
      members: 0,
      casesOpened: 0,
      coinsPaid: 0,
      upgrades: 0,
      battlesPlayed: 0,
      cases: 0,
    });
  }
}
