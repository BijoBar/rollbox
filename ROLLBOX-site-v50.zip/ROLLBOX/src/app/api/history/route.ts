import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

const PAGE = 25;

/**
 * QOL (Task 167): the player's FULL personal history — the deep version of
 * the profile's battle history. Three tabs, one endpoint, 25 rows/page:
 *   opens  — every case drop of mine (solo + the battles' reels share it)
 *   battles— every battle my seat appears in (seats JSON contains my id)
 *   money  — my ledger (charges, wins, deposits, prizes, ...), newest first
 */
export async function GET(req: NextRequest) {
  const me = await sessionPlayer(req);
  if (!me) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`history:${me.id}`, 60, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const url = new URL(req.url);
  const tab = ["opens", "battles", "money"].includes(url.searchParams.get("tab") ?? "")
    ? (url.searchParams.get("tab") as "opens" | "battles" | "money")
    : "opens";
  const page = Math.max(1, Math.min(400, Number(url.searchParams.get("page") ?? "1") || 1));
  const skip = (page - 1) * PAGE;

  if (tab === "opens") {
    const [rows, total] = await Promise.all([
      db.drop.findMany({
        where: { playerId: me.id },
        orderBy: { id: "desc" },
        take: PAGE,
        skip,
        select: { id: true, caseName: true, skinName: true, value: true, wear: true, isRd: true, source: true, createdAt: true },
      }),
      db.drop.count({ where: { playerId: me.id } }),
    ]);
    return NextResponse.json({ rows, page, pages: Math.max(1, Math.ceil(total / PAGE)), total });
  }

  if (tab === "battles") {
    const where = { OR: [{ hostId: me.id }, { seats: { contains: me.id } }] };
    const [rows, total] = await Promise.all([
      db.battle.findMany({
        where,
        orderBy: { createdAt: "desc" },
        take: PAGE,
        skip,
        select: { id: true, code: true, entry: true, status: true, potTotal: true, winnerIds: true, rounds: true, seats: true, createdAt: true },
      }),
      db.battle.count({ where }),
    ]);
    return NextResponse.json({
      rows: rows.map((b) => ({
        id: b.id,
        code: b.code,
        entry: b.entry,
        status: b.status,
        potTotal: b.potTotal,
        won: !!b.winnerIds && b.winnerIds.includes(me.id),
        rounds: JSON.parse(b.rounds ?? "[]") as string[],
        players: (JSON.parse(b.seats ?? "[]") as { playerId?: string; name?: string }[])
          .map((s) => s?.name ?? "")
          .filter(Boolean),
        createdAt: b.createdAt,
      })),
      page,
      pages: Math.max(1, Math.ceil(total / PAGE)),
      total,
    });
  }

  const [rows, total] = await Promise.all([
    db.ledger.findMany({ where: { playerId: me.id }, orderBy: { id: "desc" }, take: PAGE, skip }),
    db.ledger.count({ where: { playerId: me.id } }),
  ]);
  return NextResponse.json({ rows, page, pages: Math.max(1, Math.ceil(total / PAGE)), total });
}
