import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { walletConfig, WALLET_METHOD_ID, isTxid, isTronAddress, round2 } from "@/lib/server/wallet";

export const dynamic = "force-dynamic";

/** Max PENDING deposit requests per player — the admin queue must stay sane. */
const MAX_PENDING = 3;

/**
 * POST /api/wallet/deposit { amountUsd, txid, declared }
 * C7 PHASE 1 — a REAL USDT (TRC-20) deposit request. The player claims he
 * sent exactly `amountUsd` USDT to the site wallet and pastes the on-chain
 * txid. NOTHING is credited here: the request lands PENDING in the admin
 * queue, and only the admin's APPROVE (after verifying the txid on a block
 * explorer) credits the balance inside $transaction.
 *
 * Guards: wallet enabled + address configured, break self-block, the
 * jurisdiction declaration, amount within [minDeposit .. maxDeposit] (2-dec),
 * a valid 64-hex txid, one deposit per txid EVER (unique index + a friendly
 * pre-check), max 3 pending requests, rate limit.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`wdeposit:${player.id}`, 6, 600_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  if (player.breakUntil && player.breakUntil.getTime() > Date.now()) {
    return NextResponse.json({ error: "You are on a TAKE A BREAK self-block — deposits are locked." }, { status: 403 });
  }

  const cfg = await walletConfig();
  if (!cfg.enabled) {
    return NextResponse.json({ error: "Deposits are temporarily disabled." }, { status: 403 });
  }
  if (!cfg.usdtAddress || !isTronAddress(cfg.usdtAddress)) {
    return NextResponse.json({ error: "No deposit address is configured yet — try again later." }, { status: 403 });
  }

  let body: { amountUsd?: unknown; txid?: unknown; declared?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  // the jurisdiction declaration is REQUIRED — its exact sentence lives in
  // the wallet lib and is mirrored by the checkbox in the UI
  if (body.declared !== true) {
    return NextResponse.json({ error: "You must confirm the eligibility declaration." }, { status: 400 });
  }

  const amountUsd = round2(Number(body.amountUsd));
  if (!Number.isFinite(amountUsd) || amountUsd < cfg.minDeposit) {
    return NextResponse.json({ error: `Minimum deposit is $${cfg.minDeposit}` }, { status: 400 });
  }
  if (amountUsd > cfg.maxDeposit) {
    return NextResponse.json({ error: `Maximum deposit is $${cfg.maxDeposit.toLocaleString("en-US")}` }, { status: 400 });
  }

  const txid = String(body.txid ?? "").trim();
  if (!isTxid(txid)) {
    return NextResponse.json({ error: "The txid must be the 64-character transaction hash." }, { status: 400 });
  }

  const dup = await db.depositRequest.findUnique({ where: { txid }, select: { id: true, playerId: true } }).catch(() => null);
  if (dup) {
    return NextResponse.json(
      { error: dup.playerId === player.id ? "You already submitted this txid." : "This transaction was already submitted." },
      { status: 409 },
    );
  }

  const pending = await db.depositRequest.count({ where: { playerId: player.id, status: "pending" } });
  if (pending >= MAX_PENDING) {
    return NextResponse.json({ error: `You already have ${MAX_PENDING} pending deposits — wait for a review.` }, { status: 429 });
  }

  const created = await db.depositRequest
    .create({
      data: {
        id: randomUUID(),
        playerId: player.id,
        method: WALLET_METHOD_ID,
        amountUsd,
        amountCrypto: amountUsd, // 1 USDT = $1 = 1 coin (USD_TO_COINS)
        address: cfg.usdtAddress, // snapshot: the address shown when the request was born
        txid: txid.toLowerCase(),
      },
    })
    .catch(() => null);
  if (!created) return NextResponse.json({ error: "Could not create the deposit request" }, { status: 500 });

  return NextResponse.json({ ok: true, request: created });
}
