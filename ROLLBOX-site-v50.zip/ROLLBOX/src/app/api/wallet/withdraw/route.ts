import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { recordLedger, publishBalance } from "@/lib/server/ledger";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { walletConfig, WALLET_METHOD_ID, isTronAddress, round2 } from "@/lib/server/wallet";

export const dynamic = "force-dynamic";

/**
 * POST /api/wallet/withdraw { amountCoins, address, declared }
 * C7 PHASE 1 — a REAL USDT (TRC-20) payout request. The requested coins are
 * LOCKED THE MOMENT the request is created: balance decrement + the negative
 * "withdraw_lock" ledger row commit in ONE $transaction guarded by
 * `balance >= amount` (a player can never withdraw coins he does not have,
 * never double-spend locked coins while the request is pending, and never
 * open two payouts at once). The admin then sends the USDT manually and
 * marks the request PAID — or REJECTS it, which refunds the locked coins.
 *
 * Guards: wallet enabled + payout address configured, break self-block, the
 * jurisdiction declaration, amount within [minWithdraw .. maxWithdraw] (2-dec),
 * a valid TRON address, one pending withdrawal per player, rate limit.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`wwithdraw:${player.id}`, 6, 600_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  if (player.breakUntil && player.breakUntil.getTime() > Date.now()) {
    return NextResponse.json({ error: "You are on a TAKE A BREAK self-block — withdrawals are locked." }, { status: 403 });
  }

  const cfg = await walletConfig();
  if (!cfg.enabled) {
    return NextResponse.json({ error: "Withdrawals are temporarily disabled." }, { status: 403 });
  }
  if (!cfg.usdtAddress || !isTronAddress(cfg.usdtAddress)) {
    return NextResponse.json({ error: "Withdrawals are not configured yet — try again later." }, { status: 403 });
  }

  let body: { amountCoins?: unknown; address?: unknown; declared?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  if (body.declared !== true) {
    return NextResponse.json({ error: "You must confirm the eligibility declaration." }, { status: 400 });
  }

  const amountCoins = round2(Number(body.amountCoins));
  if (!Number.isFinite(amountCoins) || amountCoins < cfg.minWithdraw) {
    return NextResponse.json({ error: `Minimum withdrawal is $${cfg.minWithdraw}` }, { status: 400 });
  }
  if (amountCoins > cfg.maxWithdraw) {
    return NextResponse.json({ error: `Maximum withdrawal is $${cfg.maxWithdraw.toLocaleString("en-US")}` }, { status: 400 });
  }

  const address = String(body.address ?? "").trim();
  if (!isTronAddress(address)) {
    return NextResponse.json({ error: "Enter a valid TRC-20 address — it starts with T and has 34 characters." }, { status: 400 });
  }

  const already = await db.withdrawalRequest.findFirst({ where: { playerId: player.id, status: "pending" }, select: { id: true } });
  if (already) {
    return NextResponse.json({ error: "You already have a pending withdrawal — wait for its review." }, { status: 429 });
  }

  const requestId = randomUUID();
  // HARDENED like every money move: the lock + its ledger row commit together,
  // and the WHERE clause re-checks the balance INSIDE the transaction.
  const locked = await db
    .$transaction(async (tx) => {
      const upd = await tx.player.updateMany({
        where: { id: player.id, balance: { gte: amountCoins } },
        data: { balance: { decrement: amountCoins } },
      });
      if (upd.count !== 1) return null;
      const fresh = await tx.player.findUnique({ where: { id: player.id }, select: { balance: true } });
      if (!fresh) return null;
      await recordLedger(player.id, "withdraw_lock", -amountCoins, fresh.balance, `Payout request ${requestId.slice(0, 8)}`, tx);
      const row = await tx.withdrawalRequest.create({
        data: {
          id: requestId,
          playerId: player.id,
          method: WALLET_METHOD_ID,
          amountCoins,
          amountCrypto: amountCoins, // 1 USDT = $1 = 1 coin
          address,
        },
      });
      return { row, balance: fresh.balance };
    })
    .catch(() => null);
  if (!locked) return NextResponse.json({ error: "Not enough balance for this withdrawal." }, { status: 400 });

  publishBalance(player.id, locked.balance);
  return NextResponse.json({ ok: true, request: locked.row, balance: locked.balance });
}
