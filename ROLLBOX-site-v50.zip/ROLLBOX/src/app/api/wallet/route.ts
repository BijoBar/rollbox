import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { walletConfig, WALLET_METHODS, JURISDICTION_DECLARATION } from "@/lib/server/wallet";

export const dynamic = "force-dynamic";

/**
 * GET /api/wallet — everything the WALLET page needs for the signed-in
 * player: the live config (master switch, the configured deposit address,
 * min/max amounts), the availability of each method, the jurisdiction
 * declaration sentence and the player's own last 20 requests of each kind.
 * The address is not a secret — the depositor must see it to send money.
 */
export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  if (!rateLimit(`walletget:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const cfg = await walletConfig();
  const [deposits, withdrawals] = await Promise.all([
    db.depositRequest.findMany({ where: { playerId: player.id }, orderBy: { createdAt: "desc" }, take: 20 }),
    db.withdrawalRequest.findMany({ where: { playerId: player.id }, orderBy: { createdAt: "desc" }, take: 20 }),
  ]);

  return NextResponse.json({
    enabled: cfg.enabled,
    declaration: JURISDICTION_DECLARATION,
    onBreak: !!player.breakUntil && player.breakUntil.getTime() > Date.now(),
    methods: WALLET_METHODS.map((m) => ({
      id: m.id,
      label: m.label,
      network: m.network,
      addressHint: m.addressHint,
      // the address leaves the server ONLY when configured; an empty address
      // means the method is closed for deposits AND withdrawals
      address: cfg.usdtAddress || null,
    })),
    minDeposit: cfg.minDeposit,
    maxDeposit: cfg.maxDeposit,
    minWithdraw: cfg.minWithdraw,
    maxWithdraw: cfg.maxWithdraw,
    deposits,
    withdrawals,
  });
}
