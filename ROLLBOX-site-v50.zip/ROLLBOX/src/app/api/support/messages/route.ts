// ============ SUPPORT CHAT — the player side (Task 136 — USER SPEC) ============
// ONE persistent conversation per player. GET returns the history (and opens
// it with the ROLLBOX AI welcome on first visit); POST appends the player's
// message and answers it instantly from the FAQ knowledge base — unless a
// human SUPPORT CASE is open, in which case the human takes over and the AI
// stays quiet.

import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { publish, publishTo } from "@/lib/server/realtime";
import {
  SUPPORT_FALLBACK,
  SUPPORT_WELCOME,
  matchFaq,
} from "@/lib/support-faq";

export const dynamic = "force-dynamic";

const newMsgId = () => "sm_" + crypto.randomBytes(8).toString("hex");

const serialize = (m: { id: string; role: string; body: string; createdAt: Date }) => ({
  id: m.id,
  role: m.role,
  body: m.body,
  at: m.createdAt.toISOString(),
});

/** Case row for this player (null = never requested a human). */
const caseOf = (playerId: string) => db.supportCase.findUnique({ where: { playerId } });
const caseOpen = (status: string | undefined | null) => status === "human_requested" || status === "handled";

/**
 * GET /api/support/messages — the player's conversation.
 * First visit seeds the ROLLBOX AI welcome. AI/agent messages are marked
 * read (this fetch IS the player reading them → the ? badge clears).
 */
export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "sign in" }, { status: 401 });

  // first visit → the AI opens the conversation (idempotent enough: only when
  // the history is completely empty)
  const existing = await db.supportMessage.count({ where: { playerId: player.id } });
  if (existing === 0) {
    await db.supportMessage.create({
      data: { id: newMsgId(), playerId: player.id, role: "ai", body: SUPPORT_WELCOME },
    });
  }

  const [messages, supportCase] = await Promise.all([
    db.supportMessage.findMany({ where: { playerId: player.id }, orderBy: { createdAt: "asc" } }),
    caseOf(player.id),
  ]);

  // every AI/agent message just became read
  await db.supportMessage.updateMany({
    where: { playerId: player.id, role: { not: "player" }, readByPlayer: false },
    data: { readByPlayer: true },
  });

  return NextResponse.json({
    messages: messages.map(serialize),
    caseStatus: supportCase?.status ?? null,
  });
}

/**
 * POST /api/support/messages — send { text }.
 * The AI answers instantly from the FAQ (keyword match → canned answer, no
 * match → the fallback invitation). While a human case is OPEN the AI stays
 * silent so the agent's answers are not drowned out.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "sign in" }, { status: 401 });
  if (!rateLimit(`support:${player.id}`, 20, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  let text = "";
  try {
    const body = (await req.json()) as { text?: unknown };
    text = typeof body.text === "string" ? body.text.trim() : "";
  } catch {
    return NextResponse.json({ error: "bad body" }, { status: 400 });
  }
  if (!text) return NextResponse.json({ error: "empty" }, { status: 400 });
  if (text.length > 700) text = text.slice(0, 700);

  const supportCase = await caseOf(player.id);
  const humanOpen = caseOpen(supportCase?.status);

  const playerMsg = await db.supportMessage.create({
    data: { id: newMsgId(), playerId: player.id, role: "player", body: text },
  });

  let aiMsg: { id: string; role: string; body: string; createdAt: Date } | null = null;
  if (!humanOpen) {
    const faq = matchFaq(text);
    aiMsg = await db.supportMessage.create({
      data: {
        id: newMsgId(),
        playerId: player.id,
        role: "ai",
        body: faq ? faq.answer : SUPPORT_FALLBACK,
      },
    });
  }

  // push: admins' inbox refreshes; the player's other devices update live
  publish("support_admin", { playerId: player.id, playerName: player.name, kind: "message", at: Date.now() });
  publishTo(player.id, "support_player", { at: Date.now() });

  return NextResponse.json({
    player: serialize(playerMsg),
    ai: aiMsg ? serialize(aiMsg) : null,
    caseStatus: supportCase?.status ?? null,
  });
}
