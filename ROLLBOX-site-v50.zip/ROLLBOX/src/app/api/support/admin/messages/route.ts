// ============ SUPPORT CHAT — admin reads one conversation (Task 136) =========
// GET /api/support/admin/messages?playerId=... — the full thread plus the
// player identity. Reading ALSO marks the player's messages read (the unread
// badge on the thread clears).

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "not found" }, { status: 404 });
  // HARDENING (Task 153): admin reads capped like every other route.
  if (!rateLimit(`smsgs:${admin.id}`, 120, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const playerId = req.nextUrl.searchParams.get("playerId");
  if (!playerId) return NextResponse.json({ error: "playerId required" }, { status: 400 });

  const [player, messages, supportCase] = await Promise.all([
    db.player.findUnique({ where: { id: playerId }, select: { id: true, name: true, avatar: true } }),
    db.supportMessage.findMany({ where: { playerId }, orderBy: { createdAt: "asc" } }),
    db.supportCase.findUnique({ where: { playerId } }),
  ]);
  if (!player) return NextResponse.json({ error: "no such player" }, { status: 404 });

  await db.supportMessage.updateMany({
    where: { playerId, role: "player", readByAdmin: false },
    data: { readByAdmin: true },
  });

  return NextResponse.json({
    player,
    caseStatus: supportCase?.status ?? null,
    messages: messages.map((m) => ({
      id: m.id,
      role: m.role,
      body: m.body,
      at: m.createdAt.toISOString(),
    })),
  });
}
