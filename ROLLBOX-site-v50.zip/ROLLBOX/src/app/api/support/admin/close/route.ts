// ============ SUPPORT CHAT — the agent closes the case (Task 136) ============
// POST /api/support/admin/close { playerId } — resolves the SUPPORT CASE and
// posts the closing note into the conversation. The player can always reopen
// by pressing Request human support again.

import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { publish, publishTo } from "@/lib/server/realtime";
import { SUPPORT_CASE_CLOSED } from "@/lib/support-faq";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "not found" }, { status: 404 });
  // HARDENING (Task 153): closing is a deliberate click — 30/min is ample.
  if (!rateLimit(`sclose:${admin.id}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let playerId = "";
  try {
    const body = (await req.json()) as { playerId?: unknown };
    playerId = typeof body.playerId === "string" ? body.playerId : "";
  } catch {
    return NextResponse.json({ error: "bad body" }, { status: 400 });
  }
  if (!playerId) return NextResponse.json({ error: "playerId required" }, { status: 400 });

  const supportCase = await db.supportCase.findUnique({ where: { playerId } });
  if (supportCase && supportCase.status !== "closed") {
    await db.supportCase.update({ where: { id: supportCase.id }, data: { status: "closed" } });
    // the visible "case closed" line in the chat
    await db.supportMessage.create({
      data: {
        id: "sm_" + crypto.randomBytes(8).toString("hex"),
        playerId,
        role: "ai",
        body: SUPPORT_CASE_CLOSED,
      },
    });
  }

  publishTo(playerId, "support_player", { at: Date.now() });
  publish("support_admin", { playerId, playerName: admin.name, kind: "close", at: Date.now() });
  await logAdmin(admin, "support.close", playerId, null);

  return NextResponse.json({ ok: true, caseStatus: "closed" });
}
