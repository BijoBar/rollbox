// ============ SUPPORT CHAT — the agent answers (Task 136 — USER SPEC) ========
// POST /api/support/admin/reply { playerId, text } — the human reply lands in
// the player's conversation and is PUSHED to every open chat panel of that
// player instantly (support_player realtime event). The first agent reply on
// an open case flips it to "handled".

import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { publish, publishTo } from "@/lib/server/realtime";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "not found" }, { status: 404 });
  if (!rateLimit(`support-reply:${admin.id}`, 60, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  let playerId = "";
  let text = "";
  try {
    const body = (await req.json()) as { playerId?: unknown; text?: unknown };
    playerId = typeof body.playerId === "string" ? body.playerId : "";
    text = typeof body.text === "string" ? body.text.trim() : "";
  } catch {
    return NextResponse.json({ error: "bad body" }, { status: 400 });
  }
  if (!playerId || !text) return NextResponse.json({ error: "empty" }, { status: 400 });
  if (text.length > 700) text = text.slice(0, 700);

  const target = await db.player.findUnique({ where: { id: playerId }, select: { id: true } });
  if (!target) return NextResponse.json({ error: "no such player" }, { status: 404 });

  const msg = await db.supportMessage.create({
    data: {
      id: "sm_" + crypto.randomBytes(8).toString("hex"),
      playerId,
      role: "admin",
      body: text,
    },
  });

  // an open case just got its first human answer
  const supportCase = await db.supportCase.findUnique({ where: { playerId } });
  if (supportCase?.status === "human_requested") {
    await db.supportCase.update({ where: { id: supportCase.id }, data: { status: "handled" } });
  }

  // the player's chat panel updates live; the admins' inbox re-sorts
  publishTo(playerId, "support_player", { at: Date.now() });
  publish("support_admin", { playerId, playerName: admin.name, kind: "reply", at: Date.now() });
  await logAdmin(admin, "support.reply", playerId, { chars: text.length });

  return NextResponse.json({
    ok: true,
    caseStatus: supportCase?.status === "human_requested" ? "handled" : (supportCase?.status ?? null),
    message: { id: msg.id, role: msg.role, body: msg.body, at: msg.createdAt.toISOString() },
  });
}
