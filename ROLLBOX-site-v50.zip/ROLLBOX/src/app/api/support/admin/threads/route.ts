// ============ SUPPORT CHAT — admin inbox feed (Task 136 — USER SPEC) =========
// GET /api/support/admin/threads — every conversation on the site: who wrote
// last, unread counter, and the SUPPORT CASE status. Threads with an OPEN
// case (human_requested) sort FIRST — an agent should never hunt for them.

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

export interface SupportThread {
  playerId: string;
  playerName: string;
  avatar: string | null;
  caseStatus: string | null;
  unread: number;
  lastRole: string;
  lastBody: string;
  lastAt: string;
}

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "not found" }, { status: 404 });
  // HARDENING (Task 153): admin reads capped like every other route.
  if (!rateLimit(`sthreads:${admin.id}`, 120, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  // every player that ever chatted or opened a case
  const [chatting, cases] = await Promise.all([
    db.supportMessage.findMany({
      distinct: ["playerId"],
      select: { playerId: true },
    }),
    db.supportCase.findMany({ select: { playerId: true, status: true } }),
  ]);

  const ids = Array.from(new Set([...chatting.map((c) => c.playerId), ...cases.map((c) => c.playerId)]));
  if (ids.length === 0) return NextResponse.json({ threads: [] });

  const [players, lastMsgs, unreadGroups] = await Promise.all([
    db.player.findMany({ where: { id: { in: ids } }, select: { id: true, name: true, avatar: true } }),
    db.supportMessage.findMany({
      where: { playerId: { in: ids } },
      orderBy: { createdAt: "desc" },
      // take ALL messages of those players once and keep the newest per player
    }),
    db.supportMessage.groupBy({
      by: ["playerId"],
      where: { playerId: { in: ids }, role: "player", readByAdmin: false },
      _count: { _all: true },
    }),
  ]);

  const playerMap = new Map(players.map((p) => [p.id, p]));
  const caseMap = new Map(cases.map((c) => [c.playerId, c.status]));
  const lastMap = new Map<string, (typeof lastMsgs)[number]>();
  for (const m of lastMsgs) if (!lastMap.has(m.playerId)) lastMap.set(m.playerId, m);
  const unreadMap = new Map(unreadGroups.map((g) => [g.playerId, g._count._all]));

  const threads: SupportThread[] = ids
    .filter((id) => playerMap.has(id))
    .map((id) => {
      const p = playerMap.get(id)!;
      const last = lastMap.get(id);
      return {
        playerId: id,
        playerName: p.name,
        avatar: p.avatar,
        caseStatus: caseMap.get(id) ?? null,
        unread: unreadMap.get(id) ?? 0,
        lastRole: last?.role ?? "ai",
        lastBody: last?.body ?? "",
        lastAt: (last?.createdAt ?? new Date(0)).toISOString(),
      };
    })
    .sort((a, b) => {
      // SUPPORT CASE first (needs an agent), then the freshest conversation
      const aOpen = a.caseStatus === "human_requested" ? 1 : 0;
      const bOpen = b.caseStatus === "human_requested" ? 1 : 0;
      if (aOpen !== bOpen) return bOpen - aOpen;
      return b.lastAt.localeCompare(a.lastAt);
    });

  return NextResponse.json({ threads });
}
