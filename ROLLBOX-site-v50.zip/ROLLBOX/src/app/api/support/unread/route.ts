// ============ SUPPORT CHAT — the "?" unread badge (Task 136 — USER SPEC) =====
// Cheap poll for the floating button: how many AI/agent messages the player
// has NOT read yet. Does NOT mark anything read — only opening the chat does.

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ count: 0 });
  // HARDENING (Task 153): the floating-badge poll — capped per player.
  if (!rateLimit(`sunread:${player.id}`, 120, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const count = await db.supportMessage.count({
    where: { playerId: player.id, role: { not: "player" }, readByPlayer: false },
  });
  return NextResponse.json({ count });
}
