// ============ SUPPORT CHAT — "Request human support" (Task 136 — USER SPEC) ===
// The button under the chat: when the ROLLBOX AI cannot solve it, the player
// opens a SUPPORT CASE — the red alert that pops on every admin's screen.
// Idempotent: pressing again while a case is already open does nothing noisy;
// a CLOSED case can be re-opened with a fresh alert.

import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { publish, publishTo } from "@/lib/server/realtime";
import { SUPPORT_CASE_OPENED } from "@/lib/support-faq";

export const dynamic = "force-dynamic";

/**
 * POST /api/support/human — open (or re-open) the player's SUPPORT CASE.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "sign in" }, { status: 401 });
  if (!rateLimit(`support-human:${player.id}`, 5, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const existing = await db.supportCase.findUnique({ where: { playerId: player.id } });

  if (existing?.status === "human_requested") {
    // already queued — no duplicate alert, no duplicate chat message
    return NextResponse.json({ ok: true, caseStatus: existing.status, already: true });
  }

  if (existing) {
    await db.supportCase.update({ where: { id: existing.id }, data: { status: "human_requested" } });
  } else {
    await db.supportCase.create({
      data: { id: "sc_" + crypto.randomBytes(8).toString("hex"), playerId: player.id, status: "human_requested" },
    });
  }

  // the conversation itself notes the handoff (admins see it in the thread)
  await db.supportMessage.create({
    data: {
      id: "sm_" + crypto.randomBytes(8).toString("hex"),
      playerId: player.id,
      role: "ai",
      body: SUPPORT_CASE_OPENED,
    },
  });

  // THE ALERT: every signed-in admin's screen pops the SUPPORT CASE banner
  publish("support_admin", { playerId: player.id, playerName: player.name, kind: "case", at: Date.now() });
  publishTo(player.id, "support_player", { at: Date.now() });

  return NextResponse.json({ ok: true, caseStatus: "human_requested" });
}
