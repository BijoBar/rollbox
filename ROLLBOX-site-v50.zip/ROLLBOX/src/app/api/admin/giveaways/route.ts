import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * QOL (Task 167): admin giveaways desk.
 *  GET  → every giveaway (newest first) with entry counts, for the tab list.
 *  POST → create one. Prize money is NOT moved at creation — winners are
 *         credited at DRAW time (draw/cancel live on /api/admin/giveaways/[id]).
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`gwadmin:${admin.id}`, 60, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });
  const rows = await db.giveaway.findMany({
    orderBy: { id: "desc" },
    include: { _count: { select: { entries: true } } },
  });
  return NextResponse.json({
    rows: rows.map((g) => ({
      id: g.id,
      title: g.title,
      prizeCoins: g.prizeCoins,
      prizeLabel: g.prizeLabel,
      winnerCount: g.winnerCount,
      status: g.status,
      endsAt: g.endsAt.getTime(),
      createdAt: g.createdAt.getTime(),
      entries: g._count?.entries ?? 0,
      winners: JSON.parse(g.winners ?? "[]") as { playerId: string; name: string }[],
    })),
  });
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`gwadmin:${admin.id}`, 20, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const b = (await req.json().catch(() => ({}))) as {
    title?: string;
    prizeCoins?: number;
    prizeLabel?: string;
    winnerCount?: number;
    endsAt?: number | string;
  };
  const title = (b.title ?? "").trim().slice(0, 80);
  const prizeCoins = Math.round((Number(b.prizeCoins) || 0) * 100) / 100;
  const winnerCount = Math.floor(Number(b.winnerCount) || 1);
  const endsAtMs = typeof b.endsAt === "number" ? b.endsAt : Date.parse(String(b.endsAt ?? ""));
  if (title.length < 3) return NextResponse.json({ error: "Title too short" }, { status: 400 });
  if (prizeCoins <= 0 || prizeCoins > 10000) return NextResponse.json({ error: "Prize must be $0.01..$10000" }, { status: 400 });
  if (winnerCount < 1 || winnerCount > 10) return NextResponse.json({ error: "1..10 winners" }, { status: 400 });
  if (!Number.isFinite(endsAtMs) || endsAtMs <= Date.now() + 60_000 || endsAtMs > Date.now() + 30 * 24 * 3600_000) {
    return NextResponse.json({ error: "Ends must be between 1 minute and 30 days from now" }, { status: 400 });
  }

  const gw = await db.giveaway.create({
    data: {
      id: "g_" + crypto.randomBytes(8).toString("hex"),
      title,
      prizeCoins,
      prizeLabel: (b.prizeLabel ?? "").trim().slice(0, 60) || null,
      winnerCount,
      createdBy: admin.id,
      endsAt: new Date(endsAtMs),
    },
  });
  await logAdmin(admin, "giveaway.create", gw.id, { title, prizeCoins, winnerCount, endsAt: endsAtMs });
  return NextResponse.json({ ok: true, id: gw.id });
}
