import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { drawGiveaway } from "@/lib/server/giveaways";

export const dynamic = "force-dynamic";

/**
 * QOL (Task 167): POST { action: "draw" | "cancel" } on one giveaway.
 *  draw   → force the draw NOW (CAS-guarded; winners paid in transactions).
 *  cancel → close an active giveaway with no payout (nothing moved yet).
 * Both actions land in the audit trail.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`gwadmin:${admin.id}`, 30, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const { id } = await params;
  const body = (await req.json().catch(() => ({}))) as { action?: string };
  const gw = await db.giveaway.findUnique({ where: { id } });
  if (!gw) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (body.action === "draw") {
    if (gw.status !== "active") return NextResponse.json({ error: "Already settled" }, { status: 409 });
    const res = await drawGiveaway(id, { force: true });
    if (!res) return NextResponse.json({ error: "Draw lost a race — refresh" }, { status: 409 });
    await logAdmin(admin, "giveaway.draw", id, { title: gw.title, winners: res.winners });
    return NextResponse.json({ ok: true, winners: res.winners });
  }

  if (body.action === "cancel") {
    const claimed = await db.giveaway.updateMany({ where: { id, status: "active" }, data: { status: "cancelled" } });
    if (claimed.count !== 1) return NextResponse.json({ error: "Already settled" }, { status: 409 });
    await logAdmin(admin, "giveaway.cancel", id, { title: gw.title });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
