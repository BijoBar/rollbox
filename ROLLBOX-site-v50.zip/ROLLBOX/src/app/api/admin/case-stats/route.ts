import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { CASES } from "@/lib/cases";

export const dynamic = "force-dynamic";

/**
 * QOL (Task 167): the CASE STATS dashboard — opens per case over the last
 * 24h / 7d / all-time (Drop groupBys), merged with the static registry for
 * display names + prices. Community cases (cc_*) carry their id as name;
 * revenue is the coins charged at today's prices (historical re-prices make
 * the all-time figure an approximation — noted in the UI).
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`casestats:${admin.id}`, 60, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const now = Date.now();
  const [d24, d7, all, latest] = await Promise.all([
    db.drop.groupBy({ by: ["caseId"], where: { createdAt: { gte: new Date(now - 24 * 3600_000) } }, _count: { _all: true } }),
    db.drop.groupBy({ by: ["caseId"], where: { createdAt: { gte: new Date(now - 7 * 24 * 3600_000) } }, _count: { _all: true } }),
    db.drop.groupBy({ by: ["caseId"], _count: { _all: true } }),
    db.drop.findMany({ orderBy: { id: "desc" }, take: 400, select: { caseId: true, caseName: true } }),
  ]);

  const names = new Map<string, string>();
  for (const d of latest) if (!names.has(d.caseId)) names.set(d.caseId, d.caseName);

  const rows = new Map<string, { opens24: number; opens7: number; opensAll: number }>();
  for (const g of all) rows.set(g.caseId, { opens24: 0, opens7: 0, opensAll: g._count._all });
  for (const g of d7) {
    const r = rows.get(g.caseId) ?? { opens24: 0, opens7: 0, opensAll: 0 };
    r.opens7 = g._count._all;
    rows.set(g.caseId, r);
  }
  for (const g of d24) {
    const r = rows.get(g.caseId) ?? { opens24: 0, opens7: 0, opensAll: 0 };
    r.opens24 = g._count._all;
    rows.set(g.caseId, r);
  }

  const out = [...rows.entries()]
    .map(([caseId, r]) => {
      const def = CASES.find((c) => c.id === caseId);
      return {
        caseId,
        name: def?.name ?? names.get(caseId) ?? caseId,
        price: def?.price ?? null,
        ...r,
      };
    })
    .sort((a, b) => b.opens24 - a.opens24 || b.opens7 - a.opens7 || b.opensAll - a.opensAll)
    .slice(0, 60);

  return NextResponse.json({ rows: out });
}
