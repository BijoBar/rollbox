import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

// QOL (Task 167): the site-wide broadcast banner lives in SiteConfig —
//   site.bannerOn ("1"/"0"), site.bannerText (<=200 chars), site.bannerTone
//   ("gold" | "info" | "alert"). GET is public (the TopBar reads it); the
//   POST is the admin editor and lands in the audit trail.

const TONES = new Set(["gold", "info", "alert"]);

export async function GET() {
  const rows = await db.siteConfig.findMany({ where: { key: { in: ["site.bannerOn", "site.bannerText", "site.bannerTone"] } } });
  const map = new Map(rows.map((r) => [r.key, r.value]));
  return NextResponse.json({
    on: map.get("site.bannerOn") === "1",
    text: map.get("site.bannerText") ?? "",
    tone: TONES.has(map.get("site.bannerTone") ?? "") ? map.get("site.bannerTone") : "gold",
  });
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`banner:${admin.id}`, 20, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const b = (await req.json().catch(() => ({}))) as { on?: boolean; text?: string; tone?: string };
  const text = (b.text ?? "").trim().slice(0, 200);
  const tone = TONES.has(b.tone ?? "") ? (b.tone as string) : "gold";
  if (b.on && text.length < 3) return NextResponse.json({ error: "Banner text too short" }, { status: 400 });

  const up = (key: string, value: string) =>
    db.siteConfig.upsert({ where: { key }, create: { key, value }, update: { value } });
  await Promise.all([
    up("site.bannerOn", b.on ? "1" : "0"),
    up("site.bannerText", text),
    up("site.bannerTone", tone),
  ]);
  await logAdmin(admin, "banner.save", null, { on: !!b.on, text, tone });
  return NextResponse.json({ ok: true });
}
