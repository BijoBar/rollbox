import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { walletConfig, WALLET_CONFIG_KEYS, WALLET_CONFIG_DEFAULTS, WALLET_METHODS, JURISDICTION_DECLARATION } from "@/lib/server/wallet";

export const dynamic = "force-dynamic";

/**
 * GET /api/admin/wallet — the admin WALLET tab's data: the live config (raw
 * string values so the inputs mirror exactly what is stored), the review
 * queues (pending first) with the player's name attached, and the pending
 * counts for the tab badge.
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (!rateLimit(`adminwallet:${admin.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const cfg = await walletConfig();
  const [deposits, withdrawals] = await Promise.all([
    db.depositRequest.findMany({ orderBy: [{ status: "desc" }, { createdAt: "desc" }], take: 60 }),
    db.withdrawalRequest.findMany({ orderBy: [{ status: "desc" }, { createdAt: "desc" }], take: 60 }),
  ]);
  const ids = [...new Set([...deposits, ...withdrawals].map((r) => r.playerId))];
  const players = await db.player.findMany({ where: { id: { in: ids } }, select: { id: true, name: true, avatar: true, bannedAt: true } });
  const nameOf = new Map(players.map((p) => [p.id, p.name]));

  // raw stored values for the config editor (empty string = default shown)
  const rows = await db.siteConfig.findMany({ where: { key: { in: [...WALLET_CONFIG_KEYS] } } });
  const raw = Object.fromEntries(WALLET_CONFIG_KEYS.map((k) => [k, rows.find((r) => r.key === k)?.value ?? WALLET_CONFIG_DEFAULTS[k]]));

  return NextResponse.json({
    raw,
    methods: WALLET_METHODS.map((m) => ({ id: m.id, label: m.label, network: m.network, addressKey: m.addressKey, addressHint: m.addressHint })),
    declaration: JURISDICTION_DECLARATION,
    deposits: deposits.map((d) => ({ ...d, playerName: nameOf.get(d.playerId) ?? d.playerId })),
    withdrawals: withdrawals.map((w) => ({ ...w, playerName: nameOf.get(w.playerId) ?? w.playerId })),
    pendingDeposits: deposits.filter((d) => d.status === "pending").length,
    pendingWithdrawals: withdrawals.filter((w) => w.status === "pending").length,
  });
}
