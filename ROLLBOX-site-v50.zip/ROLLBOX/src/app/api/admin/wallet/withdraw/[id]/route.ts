import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { recordLedger, publishBalance } from "@/lib/server/ledger";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { isTxid } from "@/lib/server/wallet";

export const dynamic = "force-dynamic";

/**
 * POST /api/admin/wallet/withdraw/[id] { action: "paid" | "reject", note?,
 * payoutTxid? }
 * C7 PHASE 1 — the admin's review of a payout request. The coins were ALREADY
 * locked on the player's balance when the request was born.
 *
 * PAID — the admin sent the USDT out-of-band (his wallet app) and records the
 *   payout txid here: a pure status flip (pending -> paid) guarded by
 *   updateMany, so a double-click can never mark a request twice.
 * REJECT — ONE $transaction: the status flip + the refund of the locked
 *   coins + the positive "withdraw_refund" ledger row. The player's money
 *   comes back the instant the request is rejected.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (!rateLimit(`adminwwd:${admin.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await params;
  let body: { action?: unknown; note?: unknown; payoutTxid?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
  const action = body.action === "paid" || body.action === "reject" ? body.action : null;
  if (!action) return NextResponse.json({ error: "Unknown action" }, { status: 400 });

  const note = String(body.note ?? "").trim().slice(0, 300) || null;
  const payoutTxid = String(body.payoutTxid ?? "").trim().toLowerCase();
  if (action === "paid" && payoutTxid && !isTxid(payoutTxid)) {
    return NextResponse.json({ error: "The payout txid must be the 64-character transaction hash." }, { status: 400 });
  }

  const request = await db.withdrawalRequest.findUnique({ where: { id } });
  if (!request) return NextResponse.json({ error: "Request not found" }, { status: 404 });
  if (request.status !== "pending") {
    return NextResponse.json({ error: `Already reviewed (${request.status})` }, { status: 409 });
  }

  if (action === "paid") {
    const flipped = await db.withdrawalRequest.updateMany({
      where: { id, status: "pending" },
      data: { status: "paid", adminNote: note, payoutTxid: payoutTxid || null, reviewedAt: new Date(), reviewedBy: admin.id },
    });
    if (flipped.count !== 1) return NextResponse.json({ error: "Already reviewed" }, { status: 409 });
    await logAdmin(admin, "withdraw.paid", id, { player: request.playerId, amount: request.amountCoins, address: request.address, payoutTxid: payoutTxid || null });
    return NextResponse.json({ ok: true, status: "paid" });
  }

  // ---- reject: flip + refund in ONE transaction ----
  const refunded = await db
    .$transaction(async (tx) => {
      const flip = await tx.withdrawalRequest.updateMany({
        where: { id, status: "pending" },
        data: { status: "rejected", adminNote: note, reviewedAt: new Date(), reviewedBy: admin.id },
      });
      if (flip.count !== 1) return null;
      const upd = await tx.player.update({
        where: { id: request.playerId },
        data: { balance: { increment: request.amountCoins } },
      });
      await recordLedger(
        request.playerId,
        "withdraw_refund",
        request.amountCoins,
        upd.balance,
        `Payout request ${request.id.slice(0, 8)} rejected`,
        tx,
      );
      return upd;
    })
    .catch(() => null);
  if (!refunded) return NextResponse.json({ error: "Already reviewed" }, { status: 409 });

  publishBalance(request.playerId, refunded.balance);
  await logAdmin(admin, "withdraw.reject", id, { player: request.playerId, amount: request.amountCoins, address: request.address, note });
  return NextResponse.json({ ok: true, status: "rejected", balance: refunded.balance });
}
