import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { WALLET_CONFIG_DEFAULTS, WALLET_CONFIG_KEYS, isTronAddress } from "@/lib/server/wallet";

export const dynamic = "force-dynamic";

/**
 * POST /api/admin/wallet/config { values: { "wallet.usdt_address": "T…",
 * "wallet.minDeposit": "10", "wallet.enabled": "1", ... } }
 * Saves the wallet configuration. EVERY key is validated against a strict
 * rule set before it touches the DB — a typo can never brick the feature:
 *   • the USDT address must be a valid TRON address (or empty = method closed)
 *   • min/max amounts must parse to positive numbers, min <= max
 *   • enabled must be "0" or "1"
 * Unknown keys are silently dropped.
 */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (!rateLimit(`adminwalletcfg:${admin.id}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { values?: Record<string, unknown> };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
  const incoming = body.values ?? {};

  const clean: { key: string; value: string }[] = [];
  for (const key of WALLET_CONFIG_KEYS) {
    if (!(key in incoming)) continue;
    const value = String(incoming[key] ?? "").trim();

    if (key === "wallet.enabled") {
      if (value !== "0" && value !== "1") {
        return NextResponse.json({ error: "The master switch must be on or off." }, { status: 400 });
      }
      clean.push({ key, value });
      continue;
    }

    if (key === "wallet.usdt_address") {
      if (value && !isTronAddress(value)) {
        return NextResponse.json({ error: "The USDT (TRC-20) address must start with T and have exactly 34 characters." }, { status: 400 });
      }
      clean.push({ key, value });
      continue;
    }

    // the four min/max keys
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) {
      return NextResponse.json({ error: `${key.replace("wallet.", "")} must be a positive number.` }, { status: 400 });
    }
    if (n > 100_000) {
      return NextResponse.json({ error: `${key.replace("wallet.", "")} cap is 100,000.` }, { status: 400 });
    }
    clean.push({ key, value: String(Math.round(n * 100) / 100) });
  }

  // min <= max cross-checks on the RESULTING config
  const merged = { ...WALLET_CONFIG_DEFAULTS } as Record<string, string>;
  for (const { key, value } of clean) merged[key] = value;
  const num = (k: string) => Number(merged[k]);
  if (num("wallet.minDeposit") > num("wallet.maxDeposit")) {
    return NextResponse.json({ error: "minDeposit must not exceed maxDeposit." }, { status: 400 });
  }
  if (num("wallet.minWithdraw") > num("wallet.maxWithdraw")) {
    return NextResponse.json({ error: "minWithdraw must not exceed maxWithdraw." }, { status: 400 });
  }

  for (const { key, value } of clean) {
    await db.siteConfig.upsert({ where: { key }, create: { key, value }, update: { value } });
  }

  await logAdmin(
    admin,
    "wallet.config",
    null,
    Object.fromEntries(clean.map((c) => [c.key, c.key === "wallet.usdt_address" ? `${c.value.slice(0, 6)}…` : c.value])),
  );
  return NextResponse.json({ ok: true, saved: clean.length });
}
