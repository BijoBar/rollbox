import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { recordLedger, publishBalance } from "@/lib/server/ledger";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { trackMissions } from "@/lib/server/missions";

export const dynamic = "force-dynamic";

/**
 * POST /api/admin/wallet/deposit/[id] { action: "approve" | "reject", note? }
 * C7 PHASE 1 — the admin's review of a REAL deposit request. The admin is
 * expected to have verified the txid on a block explorer FIRST (the UI
 * deep-links to tronscan.org).
 *
 * APPROVE — the ONLY path that credits real-deposit money:
 *   ONE $transaction: the status guard (pending -> approved, updateMany so a
 *   double-click / second admin can never double-approve), the balance
 *   increment, the "deposit" ledger row. The audit row and the credit commit
 *   or roll back together. Banned players can NOT be approved — the admin
 *   must reject instead.
 * REJECT — a pure status flip, no money moves.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (!rateLimit(`adminwdep:${admin.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await params;
  let body: { action?: unknown; note?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
  const action = body.action === "approve" || body.action === "reject" ? body.action : null;
  if (!action) return NextResponse.json({ error: "Unknown action" }, { status: 400 });

  const note = String(body.note ?? "").trim().slice(0, 300) || null;
  const request = await db.depositRequest.findUnique({ where: { id } });
  if (!request) return NextResponse.json({ error: "Request not found" }, { status: 404 });
  if (request.status !== "pending") {
    return NextResponse.json({ error: `Already reviewed (${request.status})` }, { status: 409 });
  }

  if (action === "reject") {
    const flipped = await db.depositRequest.updateMany({
      where: { id, status: "pending" },
      data: { status: "rejected", adminNote: note, reviewedAt: new Date(), reviewedBy: admin.id },
    });
    if (flipped.count !== 1) return NextResponse.json({ error: "Already reviewed" }, { status: 409 });
    await logAdmin(admin, "deposit.reject", id, { player: request.playerId, amount: request.amountUsd, txid: request.txid, note });
    return NextResponse.json({ ok: true, status: "rejected" });
  }

  // ---- approve ----
  const target = await db.player.findUnique({ where: { id: request.playerId }, select: { id: true, bannedAt: true } });
  if (!target) return NextResponse.json({ error: "Player not found" }, { status: 404 });
  if (target.bannedAt) {
    return NextResponse.json({ error: "This player is banned — REJECT the request instead." }, { status: 409 });
  }

  const credited = await db
    .$transaction(async (tx) => {
      const flip = await tx.depositRequest.updateMany({
        where: { id, status: "pending" },
        data: { status: "approved", adminNote: note, reviewedAt: new Date(), reviewedBy: admin.id },
      });
      if (flip.count !== 1) return null;
      const upd = await tx.player.update({
        where: { id: request.playerId },
        data: { balance: { increment: request.amountUsd } },
      });
      await recordLedger(
        request.playerId,
        "deposit",
        request.amountUsd,
        upd.balance,
        `USDT (TRC-20) deposit — txid ${request.txid.slice(0, 12)}…`,
        tx,
      );
      return upd;
    })
    .catch(() => null);
  if (!credited) return NextResponse.json({ error: "Already reviewed" }, { status: 409 });

  publishBalance(request.playerId, credited.balance);
  // the lifetime deposit total feeds the Verified Player / Highroller steps
  await trackMissions(request.playerId, { depTotal: request.amountUsd }).catch(() => {});
  await logAdmin(admin, "deposit.approve", id, { player: request.playerId, amount: request.amountUsd, txid: request.txid, note });

  return NextResponse.json({ ok: true, status: "approved", balance: credited.balance });
}
