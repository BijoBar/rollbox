import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

const PAGE = 50;

/**
 * SECURITY (Task 167): the append-only ADMIN AUDIT TRAIL, newest first.
 * Reading is the admin panel's SECURITY tab; nothing in the shipped code
 * path edits or deletes rows — audit integrity is the whole point.
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`audit:${admin.id}`, 60, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const url = new URL(req.url);
  const page = Math.max(1, Math.min(200, Number(url.searchParams.get("page") ?? "1") || 1));
  const [rows, total] = await Promise.all([
    db.auditLog.findMany({ orderBy: { id: "desc" }, take: PAGE, skip: (page - 1) * PAGE }),
    db.auditLog.count(),
  ]);
  return NextResponse.json({ rows, page, pages: Math.max(1, Math.ceil(total / PAGE)), total });
}
