import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer, read2faToken } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { logAdmin } from "@/lib/server/admin";
import { generateTotpSecret, verifyTotp, totpUri } from "@/lib/server/totp";

export const dynamic = "force-dynamic";

/**
 * SECURITY (Task 167): the admin's TOTP self-service.
 * These handlers deliberately bypass requireAdmin (which demands the unlock
 * cookie once 2FA is on — setup/disable must stay reachable without it) and
 * gate on sessionPlayer + isAdmin directly. Everyone else gets the flat 404.
 *
 *  GET  → { configured, enabled, unlocked }        (the panel's lock screen)
 *  POST { action: "begin" }    → new secret + otpauth URI (not enabled yet)
 *  POST { action: "confirm", code } → verify + ENABLE (writes the audit log)
 *  POST { action: "disable", code } → verify + remove (writes the audit log)
 */
async function adminOnly(req: NextRequest) {
  const admin = await sessionPlayer(req);
  if (!admin?.isAdmin) return null;
  return admin;
}

export async function GET(req: NextRequest) {
  const admin = await adminOnly(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`2fa:${admin.id}`, 60, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });
  const [secret, enabled] = await Promise.all([
    db.siteConfig.findUnique({ where: { key: "admin.totpSecret" } }),
    db.siteConfig.findUnique({ where: { key: "admin.totpEnabled" } }),
  ]);
  return NextResponse.json({
    configured: !!secret?.value,
    enabled: enabled?.value === "1",
    unlocked: read2faToken(req.cookies.get("rb_2fa")?.value),
  });
}

export async function POST(req: NextRequest) {
  const admin = await adminOnly(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`2fa:${admin.id}`, 15, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const body = (await req.json().catch(() => ({}))) as { action?: string; code?: string };
  const enabledRow = await db.siteConfig.findUnique({ where: { key: "admin.totpEnabled" } });
  const enabled = enabledRow?.value === "1";

  if (body.action === "begin") {
    if (enabled) return NextResponse.json({ error: "2FA is already enabled" }, { status: 409 });
    const secret = generateTotpSecret();
    await db.siteConfig.upsert({
      where: { key: "admin.totpSecret" },
      create: { key: "admin.totpSecret", value: secret },
      update: { value: secret },
    });
    return NextResponse.json({ ok: true, secret, uri: totpUri(secret) });
  }

  const secretRow = await db.siteConfig.findUnique({ where: { key: "admin.totpSecret" } });
  if (!secretRow?.value) return NextResponse.json({ error: "Begin the setup first" }, { status: 400 });
  if (!verifyTotp(secretRow.value, body.code ?? "")) {
    return NextResponse.json({ error: "Wrong code — check the 6 digits and try again" }, { status: 400 });
  }

  if (body.action === "confirm") {
    if (enabled) return NextResponse.json({ ok: true, alreadyEnabled: true });
    await db.siteConfig.upsert({
      where: { key: "admin.totpEnabled" },
      create: { key: "admin.totpEnabled", value: "1" },
      update: { value: "1" },
    });
    await logAdmin(admin, "2fa.enable", admin.id, "TOTP two-factor ENABLED for the admin panel");
    return NextResponse.json({ ok: true, enabled: true });
  }

  if (body.action === "disable") {
    if (!enabled) return NextResponse.json({ ok: true, alreadyDisabled: true });
    await db.siteConfig.deleteMany({ where: { key: "admin.totpEnabled" } });
    await db.siteConfig.deleteMany({ where: { key: "admin.totpSecret" } });
    await logAdmin(admin, "2fa.disable", admin.id, "TOTP two-factor DISABLED for the admin panel");
    return NextResponse.json({ ok: true, enabled: false });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
