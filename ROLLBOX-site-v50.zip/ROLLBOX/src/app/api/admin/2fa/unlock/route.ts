import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer, make2faToken, TWO_FA_COOKIE_NAME, TWO_FA_MAX_AGE } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { logAdmin } from "@/lib/server/admin";
import { verifyTotp } from "@/lib/server/totp";

export const dynamic = "force-dynamic";

/**
 * SECURITY (Task 167): POST { code } — exchange a valid authenticator code
 * for the 12h rb_2fa unlock cookie. This is the door the lock screen knocks
 * on; every other /api/admin route refuses to open until it is answered.
 * Brute-force budget: 5 tries / minute (a TOTP code space is 10^6 with 30s
 * rotation — the rate limit is what makes guessing hopeless).
 */
export async function POST(req: NextRequest) {
  const admin = await sessionPlayer(req);
  if (!admin?.isAdmin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`2faunlock:${admin.id}`, 5, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });

  const [enabled, secretRow] = await Promise.all([
    db.siteConfig.findUnique({ where: { key: "admin.totpEnabled" } }),
    db.siteConfig.findUnique({ where: { key: "admin.totpSecret" } }),
  ]);
  if (enabled?.value !== "1" || !secretRow?.value) {
    return NextResponse.json({ error: "2FA is not enabled" }, { status: 400 });
  }

  const body = (await req.json().catch(() => ({}))) as { code?: string };
  if (!verifyTotp(secretRow.value, body.code ?? "")) {
    return NextResponse.json({ error: "Wrong code — check the 6 digits and try again" }, { status: 400 });
  }

  await logAdmin(admin, "2fa.unlock", admin.id, "Admin panel unlocked for 12h");
  const res = NextResponse.json({ ok: true, unlockedForHours: TWO_FA_MAX_AGE / 3600 });
  res.cookies.set(TWO_FA_COOKIE_NAME, make2faToken(), {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    maxAge: TWO_FA_MAX_AGE,
    secure: false, // TLS terminates upstream (same as the session cookie)
  });
  return res;
}
