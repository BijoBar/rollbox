import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, logAdmin } from "@/lib/server/admin";
import { grantFreeCases } from "@/lib/server/freecases";
import { publish } from "@/lib/server/realtime";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { CASES } from "@/lib/cases";
import { findCommunityCase } from "@/lib/server/community-cases";

export const dynamic = "force-dynamic";

/**
 * POST /api/admin/player/[id]/freecase { caseId, qty }
 * USER SPEC (Task 183): the admin can gift FREE CASES to any player. The DB
 * keeps the exact per-case quantity on the player's row (Player.freeCases);
 * the player's own devices learn about the gift the same instant through the
 * realtime "player" push (the FREE ×N chip appears next to the case name).
 * The DAILY (level) cases are refused — they already open free once per 24h.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`adminfreecase:${admin.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await params;
  let body: { caseId?: string; qty?: number };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const caseId = String(body.caseId ?? "");
  const qty = Math.floor(Number(body.qty));
  if (!Number.isFinite(qty) || qty <= 0) {
    return NextResponse.json({ error: "Quantity must be a positive number" }, { status: 400 });
  }
  if (qty > 999) {
    return NextResponse.json({ error: "Single gift cap is 999 boxes" }, { status: 400 });
  }

  // the case must exist in the catalog (static OR community-built) and must
  // NOT be a free-daily LEVEL case (those open free anyway — nothing to gift)
  const staticDef = CASES.find((c) => c.id === caseId);
  const caseDef = staticDef ?? (await findCommunityCase(caseId));
  if (!caseDef) return NextResponse.json({ error: "Unknown case" }, { status: 400 });
  if (caseDef.kind === "level") {
    return NextResponse.json({ error: "Daily cases are already free — gift a regular case" }, { status: 400 });
  }

  const target = await db.player.findUnique({ where: { id }, select: { id: true } });
  if (!target) return NextResponse.json({ error: "Player not found" }, { status: 404 });

  const freeCases = await grantFreeCases(id, caseId, qty);
  if (!freeCases) return NextResponse.json({ error: "Could not grant the free cases" }, { status: 500 });

  publish("player", { playerId: id, freeCases });
  await logAdmin(admin, "player.freecase", id, { caseId, qty, freeCases, target: id });
  return NextResponse.json({ ok: true, caseId, qty, freeCases });
}
