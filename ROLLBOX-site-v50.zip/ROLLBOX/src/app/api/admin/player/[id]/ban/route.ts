import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { logAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { publishTo } from "@/lib/server/realtime";

export const dynamic = "force-dynamic";

/**
 * POST /api/admin/player/[id]/ban — PERMANENT ban (USER SPEC, Task 22).
 * The row is stamped bannedAt. USER SPEC (Task 180): the banned player STAYS
 * signed in — their next me carries bannedAt and the BanGuard shield covers
 * every open tab — while sessionPlayer keeps returning null on EVERY action
 * route (all their API calls turn 401). There is no unban — permanent means
 * permanent.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await sessionPlayer(req);
  if (!admin?.isAdmin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`adminban:${admin.id}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await params;
  if (id === admin.id) {
    return NextResponse.json({ error: "You cannot ban yourself" }, { status: 400 });
  }
  const target = await db.player.findUnique({ where: { id }, select: { id: true, name: true, bannedAt: true } });
  if (!target) return NextResponse.json({ error: "Player not found" }, { status: 404 });
  if (target.bannedAt) return NextResponse.json({ ok: true, alreadyBanned: true });

  const bannedAt = new Date();
  await db.player.update({ where: { id }, data: { bannedAt } });

  // USER SPEC (Task 180): nudge the banned player's open tabs — the event
  // carries bannedAt so the ban shield covers them on the spot (they stay
  // signed in; every action route still refuses the session).
  publishTo(id, "player", { playerId: id, bannedAt: bannedAt.toISOString() });
  await logAdmin(admin, "player.ban", id, { name: target.name ?? undefined });
  return NextResponse.json({ ok: true, bannedAt: bannedAt.toISOString() });
}
