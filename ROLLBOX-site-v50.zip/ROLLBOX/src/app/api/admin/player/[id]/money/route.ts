import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { logAdmin } from "@/lib/server/admin";
import { recordLedger, publishBalance } from "@/lib/server/ledger";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

const KINDS = {
  gift: "admin_gift",
  comp: "admin_comp",
  bonus: "admin_bonus",
} as const;

/**
 * POST /api/admin/player/[id]/money { amount, kind: "gift"|"comp"|"bonus" }
 * USER SPEC (Task 22): the admin can ONLY ADD money — the server REJECTS any
 * zero/negative amount, so no admin can drain or delete a balance. Every
 * grant lands in the ledger under its kind (מתנה / פיצוי / בונוס) and the
 * player's devices update instantly through the realtime balance push.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await sessionPlayer(req);
  if (!admin?.isAdmin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`adminmoney:${admin.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await params;
  let body: { amount?: number; kind?: keyof typeof KINDS };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  // ADD-ONLY, server-enforced: no subtraction, no zero, no nonsense
  const amount = Math.round(Number(body.amount) * 100) / 100;
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Amount must be a positive number — admins can only ADD" }, { status: 400 });
  }
  if (amount > 1_000_000) {
    return NextResponse.json({ error: "Single grant cap is 1,000,000" }, { status: 400 });
  }
  const kind = body.kind && body.kind in KINDS ? body.kind : "gift";
  if (kind === "comp" && amount > 100_000) {
    return NextResponse.json({ error: "Compensation grant cap is 100,000" }, { status: 400 });
  }

  const target = await db.player.findUnique({ where: { id }, select: { id: true, bannedAt: true } });
  if (!target) return NextResponse.json({ error: "Player not found" }, { status: 404 });

  // HARDENING (Task 153): grant + ledger row in ONE transaction.
  const updated = await db
    .$transaction(async (tx) => {
      const upd = await tx.player.update({
        where: { id },
        data: { balance: { increment: amount } },
      });
      await recordLedger(id, KINDS[kind], amount, upd.balance, `By admin ${admin.name}`, tx);
      return upd;
    })
    .catch(() => null);
  if (!updated) return NextResponse.json({ error: "Could not grant the amount" }, { status: 500 });

  publishBalance(id, updated.balance);
  await logAdmin(admin, `player.${kind}`, id, { amount, balanceAfter: updated.balance, target: id });
  return NextResponse.json({ ok: true, balance: updated.balance, granted: amount, kind });
}
