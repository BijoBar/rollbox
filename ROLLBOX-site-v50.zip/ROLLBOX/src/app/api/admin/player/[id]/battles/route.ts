import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * GET /api/admin/player/[id]/battles — USER SPEC (Task 23): the admin's
 * player overlay now shows the player's RECENT BATTLES. Same server truth
 * the profile history runs on (finished `Battle` rows whose seats contain
 * the player id), trimmed to the overlay: result / mode / entry / take /
 * net / when. Admin-gated — anyone else gets a flat 404.
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await sessionPlayer(req);
  if (!admin?.isAdmin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`adminbattles:${admin.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await params;

  // seats is a JSON string column — a quoted-id substring match finds every
  // room this player sat in (player ids are p_<hex>, bot keys are bot_<n>)
  const rows = await db.battle.findMany({
    where: { status: "finished", seats: { contains: `"${id}"` } },
    orderBy: { finishedAt: "desc" },
    take: 12,
  });

  const jparse = <T,>(s: string | null | undefined, fb: T): T => {
    try {
      return s ? (JSON.parse(s) as T) : fb;
    } catch {
      return fb;
    }
  };

  interface Seat {
    key: string;
    paid: number;
  }

  const battles = rows.map((row) => {
    const seats = jparse<Seat[]>(row.seats, []);
    const winnerIds = jparse<string[]>(row.winnerIds, []);
    const take = jparse<Record<string, number>>(row.take, {});
    const rounds = jparse<string[]>(row.rounds, []);
    const mine = seats.find((s) => s.key === id);
    const entry = mine?.paid ?? 0;
    const got = Math.max(0, Math.round((take[id] ?? 0) * 100) / 100);
    return {
      code: row.code,
      type: row.type,
      mode: row.mode,
      result: winnerIds.includes(id) ? ("W" as const) : ("L" as const),
      entry,
      take: got,
      net: Math.round((got - entry) * 100) / 100,
      caseCount: rounds.length,
      at: (row.finishedAt ?? row.updatedAt ?? row.createdAt).getTime(),
    };
  });

  return NextResponse.json({ battles });
}
