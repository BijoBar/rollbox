import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { logAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";
import { xpFloorForLevel } from "@/lib/progress";
import { publish } from "@/lib/server/realtime";

export const dynamic = "force-dynamic";

/**
 * POST /api/admin/player/[id]/level { level } — set a player's battle-pass
 * level (USER SPEC, Task 22). The xp is pinned to the new level's floor so
 * the server's next awardXp (which recomputes the level from xp) KEEPS the
 * admin's choice instead of snapping the player back to their old level.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await sessionPlayer(req);
  if (!admin?.isAdmin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`adminlvl:${admin.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const { id } = await params;
  let body: { level?: number };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
  const level = Math.floor(Number(body.level));
  if (!Number.isFinite(level) || level < 1 || level > 200) {
    return NextResponse.json({ error: "Level must be between 1 and 200" }, { status: 400 });
  }

  const target = await db.player.findUnique({ where: { id }, select: { id: true, name: true, level: true } });
  if (!target) return NextResponse.json({ error: "Player not found" }, { status: 404 });

  const updated = await db.player.update({
    where: { id },
    data: { level, xp: xpFloorForLevel(level) },
  });

  // the affected player's devices adopt the new xp/level on their next sync
  publish("player", { playerId: id, xp: updated.xp, level });
  await logAdmin(admin, "player.level", id, { from: target.level, to: level });
  return NextResponse.json({ ok: true, level: updated.level, xp: updated.xp });
}
