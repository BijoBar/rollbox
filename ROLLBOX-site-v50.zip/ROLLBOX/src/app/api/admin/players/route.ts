import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/server/admin";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

const publicRow = (p: {
  id: string;
  name: string;
  avatar: string | null;
  balance: number;
  level: number;
  xp: number;
  casesOpened: number;
  battlesWon: number;
  isAdmin: boolean;
  bannedAt: Date | null;
  createdAt: Date;
  lastSeenAt: Date;
  email: string | null;
  tradeLink: string | null;
  refCode: string | null;
  referredBy: string | null;
  freeCases: string | null;
}) => ({
  id: p.id,
  name: p.name,
  avatar: p.avatar,
  balance: p.balance,
  level: p.level,
  xp: p.xp,
  casesOpened: p.casesOpened,
  battlesWon: p.battlesWon,
  isAdmin: p.isAdmin,
  bannedAt: p.bannedAt ? p.bannedAt.toISOString() : null,
  createdAt: p.createdAt.toISOString(),
  lastSeenAt: p.lastSeenAt.toISOString(),
  email: p.email,
  tradeLink: p.tradeLink,
  refCode: p.refCode,
  referredBy: p.referredBy,
  // USER SPEC (Task 183): the player's gifted free boxes ("doppler-realm": 2)
  // — the overlay's FREE CASES detail + the gift control read it.
  freeCases: parseFreeCasesJson(p.freeCases),
});

/** garbage in the column must never kill the list — clean map or empty */
function parseFreeCasesJson(raw: string | null): Record<string, number> {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const out: Record<string, number> = {};
    for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
      const n = typeof v === "number" ? v : Number(v);
      if (Number.isFinite(n) && n > 0) out[k] = Math.floor(n);
    }
    return out;
  } catch {
    return {};
  }
}

/**
 * GET /api/admin/players?q=<site id> — the admin panel's player list.
 * USER SPEC: search by SITE ID ONLY (substring match), the full list without
 * a query. Rows carry avatar + name + site id as the spec demands.
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if (!admin) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!rateLimit(`admin:${admin.id}`, 120, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const q = (req.nextUrl.searchParams.get("q") ?? "").trim();
  const players = await db.player.findMany({
    // USER SPEC: the search box matches the SITE id alone — nothing else
    ...(q ? { where: { id: { contains: q } } } : {}),
    orderBy: { createdAt: "asc" },
    take: 500,
  });

  return NextResponse.json({ players: players.map(publicRow), total: players.length });
}
