import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { sessionPlayer, bumpCounter } from "@/lib/server/auth";
import { checkSpendAllowed } from "@/lib/server/selfcare";
import { recordLedger } from "@/lib/server/ledger";
import { catalogNearest, type CatalogEntry } from "@/lib/server/catalog";
import { ensureFairSeed, reserveNoncesOn } from "@/lib/server/fairness";
import { rollFloat } from "@/lib/provably-fair";
import { getMissionState, trackMissions } from "@/lib/server/missions";
import { publishTo } from "@/lib/server/realtime";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/** USER SPEC (R38): the maximum total skin value one spin may stake —
 *  raised from the Task-177 $350 to $1000. The UI mirrors the same cap. */
export const UPGRADER_STAKE_CAP = 1000;

/**
 * POST /api/upgrader { uids, multiplier } — USER SPEC (Task 28): the UPGRADER
 * is now an ITEM game, not a coin game. The player stakes skins FROM HIS
 * INVENTORY, picks a target multiplier, and the wheel decides:
 *
 *   WIN  → the stake is gone, ONE new catalog skin lands in the inventory —
 *          the skin whose coin value is the CLOSEST to stake x multiplier
 *          (a 1-coin Safari Mesh at 2x pays a skin worth ~2 coins).
 *   LOSS → the stake is gone, nothing comes back.
 *
 *   chance = 0.95 / multiplier   (clamped to 1.5% .. 92%)
 *
 * The stake values are read from the SERVER's InventoryItem rows (never from
 * the request), the rows are deleted inside ONE transaction (a racing spin
 * can never stake the same skins twice) and the roll is the SERVER PROVABLY
 * FAIR chain (Task 151): float = HMAC(serverSeed, clientSeed:nonce) on the
 * player's committed seed — ONE nonce slot, win iff float < chance — the
 * client only animates the wheel and can re-verify the whole spin after the
 * seed reveal.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  // spins are deliberate clicks — 30/min is plenty
  if (!rateLimit(`upgrader:${player.id}`, 30, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  let body: { uids?: unknown; multiplier?: unknown };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const uids = Array.isArray(body.uids)
    ? body.uids.filter((u): u is string => typeof u === "string" && u.length > 0).slice(0, 200)
    : [];
  if (!uids.length) {
    return NextResponse.json({ error: "Pick at least one skin to upgrade" }, { status: 400 });
  }
  const multiplier = Number(body.multiplier);
  // USER SPEC (Task 142): the upgrader's maximum is now 10X (was a 100 clamp
  // with the UI showing 15) — the SERVER enforces the cap, not just the UI.
  if (!Number.isFinite(multiplier) || multiplier < 1.05 || multiplier > 10) {
    return NextResponse.json({ error: "Bad multiplier" }, { status: 400 });
  }

  // the stake = the SERVER's own row values — the client only names uids
  const rows = await db.inventoryItem.findMany({
    where: { playerId: player.id, id: { in: uids } },
  });
  if (!rows.length) {
    return NextResponse.json({ error: "Those skins are no longer in your inventory" }, { status: 400 });
  }
  const stake = Math.round(rows.reduce((s, r) => s + Math.max(0, r.value), 0) * 100) / 100;

  // USER SPEC (R38): the stake is CAPPED at $1000 per spin — the server
  // enforces it, the UI only mirrors the limit.
  if (stake > UPGRADER_STAKE_CAP) {
    return NextResponse.json(
      { error: `The upgrader stake is capped at $${UPGRADER_STAKE_CAP} per spin` },
      { status: 400 }
    );
  }

  // SELF CARE — a break / deposit limit blocks the stake like any other spend
  const blocked = await checkSpendAllowed(player, stake);
  if (blocked) return NextResponse.json({ error: blocked }, { status: 403 });

  const chance = Math.min(0.92, Math.max(0.015, 0.95 / multiplier));
  const target = Math.round(stake * multiplier * 100) / 100;

  // SERVER PROVABLY FAIR (Task 151): lock the commitment before the spin —
  // the raw seed stays hidden; only its hash + the reserved nonce are used.
  const fairSeed = await ensureFairSeed(player.id);

  // ONE transaction: the delete IS the atomic claim on the stake — a second
  // concurrent spin of the same skins finds nothing left and wins nothing.
  // The nonce reservation rides the SAME transaction: a rolled-back spin
  // gives its nonce back, a committed spin's nonce is burned forever.
  let fairNonce: number | null = null;
  const outcome = await db
    .$transaction(async (tx) => {
      const claimed = await tx.inventoryItem.deleteMany({
        where: { playerId: player.id, id: { in: rows.map((r) => r.id) } },
      });
      if (claimed.count !== rows.length) return null; // a racing spin got there first

      const start = await reserveNoncesOn(tx, fairSeed.id, 1);
      if (start === null) return null; // seed rotated mid-spin — honest jam, retryable
      fairNonce = start;
      const roll = rollFloat(fairSeed.serverSeed, fairSeed.clientSeed, start);
      const win = roll < chance;

      // HARDENING (Task 153): the spin's ledger row now rides THIS transaction
      // — the audit row commits (or rolls back) with the very move it
      // documents (no balance moved: the ledger documents the ITEM flow).
      const lossRef = `${rows.length} skin${rows.length === 1 ? "" : "s"} (${stake}) @ ${multiplier}x`;
      if (!win) {
        await recordLedger(player.id, "upgrader_loss", 0, player.balance, lossRef, tx);
        return { win, granted: null as CatalogEntry | null, ref: lossRef };
      }

      const prize = catalogNearest(target);
      if (!prize) return null;
      // the snapshot IS the item (same shape the exchange writes) — display
      // name, art kind, rarity, real-USD reference and the coin value it pays
      const { wp: _wp, wa: _wa, ...base } = prize;
      await tx.inventoryItem.create({
        data: {
          id: "i_" + crypto.randomBytes(8).toString("hex"),
          playerId: player.id,
          entryId: prize.id,
          data: JSON.stringify(base),
          value: prize.v,
        },
      });
      const ref = `${rows.length} skin${rows.length === 1 ? "" : "s"} (${stake}) → ${prize.n} (${prize.v}) @ ${multiplier}x`;
      await recordLedger(player.id, "upgrader_win", 0, player.balance, ref, tx);
      return { win, granted: prize, ref };
    })
    .catch(() => null);

  if (!outcome) {
    return NextResponse.json({ error: "The wheel jammed — try again" }, { status: 500 });
  }

  // post-commit bookkeeping (no balance moved — the ledger row already rode
  // the spin transaction above)
  const ref = outcome.ref;
  // USER SPEC (Task 32): the site-wide UPGRADES counter lives in the DB —
  // every spin (win or loss) counts once, real-time, persisted in Counter.
  await bumpCounter("upgrades", 1).catch(() => {});
  // Task 32 (USER SPEC): mission progress lives in the DB — upgrade attempts
  // at 2x+, $10+ stakes, wins at 3x/5x/10x, and the 1.05x WIN STREAK (a loss
  // on 1.05x resets it — spins at other multipliers don't touch it).
  const upBumps: Record<string, number> = {
    ...(multiplier >= 2 ? { up2: 1 } : {}),
    ...(stake >= 10 ? { up10: 1 } : {}),
    ...(outcome.win && multiplier >= 3 ? { upWin3: 1 } : {}),
    ...(outcome.win && multiplier >= 5 ? { upWin5: 1 } : {}),
    ...(outcome.win && multiplier >= 10 ? { upWin10: 1 } : {}),
  };
  let upSets: Record<string, number> | undefined;
  if (multiplier === 1.05) {
    const streak = outcome.win ? ((await getMissionState(player.id)).c.upStreak105 ?? 0) + 1 : 0;
    upSets = { upStreak105: streak };
  }
  await trackMissions(player.id, upBumps, upSets);
  publishTo(player.id, "inventory", { playerId: player.id });

  // SERVER PROVABLY FAIR (Task 151): the verifiable bet history row. After
  // the seed's reveal, float + chance fully reproduce win/loss (the prize is
  // a deterministic nearest-value lookup on the server catalog).
  await db.fairRoll
    .create({
      data: {
        playerId: player.id,
        game: "upgrader",
        ref: `${multiplier}x`,
        seedHash: fairSeed.serverSeedHash,
        clientSeed: fairSeed.clientSeed,
        nonce: fairNonce ?? 0,
        detail: JSON.stringify({
          win: outcome.win,
          chance,
          stake,
          target,
          removed: rows.length,
          prizeId: outcome.granted?.id ?? null,
        }),
      },
    })
    .catch(() => {});

  return NextResponse.json({
    win: outcome.win,
    chance,
    stake,
    target,
    removed: rows.length,
    granted: outcome.granted
      ? { id: outcome.granted.id, n: outcome.granted.n, w: outcome.granted.w, r: outcome.granted.r, v: outcome.granted.v, img: outcome.granted.img }
      : null,
    // SERVER PROVABLY FAIR (Task 151): proof for the spin — hash commitment,
    // the player's clientSeed and the exact nonce + float that decided it.
    fair: {
      hash: fairSeed.serverSeedHash,
      clientSeed: fairSeed.clientSeed,
      nonce: fairNonce ?? 0,
    },
  });
}
