import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { catalogNearest } from "@/lib/server/catalog";

export const dynamic = "force-dynamic";

/**
 * GET /api/upgrader/preview?target=<value> — USER SPEC (Task 177): the
 * UPGRADER's big RESULT DISPLAY shows, before the spin, the skin that CAN
 * come out for the player (stake × multiplier). The prize rule is "the
 * catalog skin CLOSEST to stake × multiplier" — the exact same server-side
 * lookup the spin itself uses (catalogNearest), so what the display promises
 * is EXACTLY what a win lands. Signed-in only (it reads the same catalog the
 * exchange trades on).
 */
export async function GET(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  const target = Number(new URL(req.url).searchParams.get("target"));
  if (!Number.isFinite(target) || target <= 0) {
    return NextResponse.json({ error: "Bad target" }, { status: 400 });
  }

  const prize = catalogNearest(target);
  if (!prize) return NextResponse.json({ prize: null });

  return NextResponse.json({
    prize: {
      id: prize.id,
      n: prize.n,
      w: prize.w,
      r: prize.r,
      v: prize.v,
      img: prize.img,
    },
  });
}
