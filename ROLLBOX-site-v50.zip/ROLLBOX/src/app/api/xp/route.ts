import { NextRequest, NextResponse } from "next/server";
import { sessionPlayer } from "@/lib/server/auth";
import { rateLimit, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * POST /api/xp — ANTI-CHEAT (Task 108): READ-ONLY since the security pass.
 *
 * This endpoint USED to accept the client's absolute xp and MAX-merge it into
 * the DB — which meant anyone with curl could post { xp: 99999999 } and claim
 * Level 100 on the spot, unlocking every free daily LEVEL case. The battle
 * pass is now SERVER-AUTHORITATIVE: XP is awarded only by server-verified
 * actions (POST /api/open and the battle settle), never by client requests.
 *
 * The route stays alive (returns the DB truth, ignores the body) so older
 * clients that still push their xp get a harmless 200 and keep working.
 */
export async function POST(req: NextRequest) {
  const player = await sessionPlayer(req);
  if (!player) return NextResponse.json({ error: "Sign in first" }, { status: 401 });
  if (!rateLimit(`xp:${player.id}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }
  return NextResponse.json({ xp: player.xp, level: player.level, balance: player.balance });
}
