import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sessionPlayer } from "@/lib/server/auth";
import { getStock } from "@/lib/server/steam-stock";
import { rateLimit, ipOf, TOO_MANY } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

/**
 * GET /api/steam-exchange — the COIN EXCHANGE's live feed (USER SPEC).
 * Serves the PERSISTENT catalog the 5-minute SYNC keeps reconciled with the
 * site's Steam inventories (Task 184: BOTH accounts —
 * steamcommunity.com/id/bijobarmain/inventory#730 AND
 * steamcommunity.com/id/BijoBarStg/inventory/#730 — merged into one shelf) —
 * one entry per ASSET, every wear of a skin is its own item. Prices are
 * resolved server-side from the site catalog; the client never decides them.
 *
 * The read never touches Steam (instant, outage-proof). `?sync=1` asks for an
 * extra sync pass right now (the REFRESH button) — the 5-minute timer does
 * this automatically for the rest of the time.
 *
 * USER SPEC (this task): for a SIGNED-IN caller the response also carries
 * `owned` — the assetids THIS player already took into his inventory. The
 * exchange marks those tiles "IN CART" for him alone; nobody else sees the
 * mark (guests mark their own takes locally).
 */
export async function GET(req: NextRequest) {
  // HARDENING (Task 153): the feed is polled often — a generous IP bucket;
  // ?sync=1 additionally triggers a LIVE Steam fetch, a much tighter bucket
  // so a script cannot hammer the upstream inventory.
  const ip = ipOf(req.headers);
  if (!rateLimit(`xfeed:${ip}`, 120, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });
  const force = req.nextUrl.searchParams.get("sync") === "1";
  if (force && !rateLimit(`xsync:${ip}`, 6, 60_000)) return NextResponse.json(TOO_MANY, { status: 429 });
  const view = await getStock(force ? { forceSync: true } : undefined);
  if (!view.ok) {
    return NextResponse.json({ ok: false, error: view.error ?? "Steam inventory unavailable" }, { status: 502 });
  }

  // the caller's own takes — entryIds shaped "steam:<assetid>" (public no-op)
  const player = await sessionPlayer(req);
  let owned: string[] = [];
  if (player) {
    const rows = await db.inventoryItem.findMany({
      where: { playerId: player.id, entryId: { startsWith: "steam:" } },
      select: { entryId: true },
    });
    owned = [...new Set(rows.map((r) => r.entryId))];
  }

  return NextResponse.json({
    ok: true,
    syncedAt: view.syncedAt,
    lastOkAt: view.lastOkAt,
    syncIntervalMs: view.syncIntervalMs,
    fetchedAt: view.syncedAt, // compat for older clients
    count: view.items.length,
    owned,
    items: view.items,
  });
}
