import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, TOO_MANY, ipOf } from "@/lib/server/ratelimit";

export const dynamic = "force-dynamic";

// USER SPEC (Task 22): the leaderboard ranks EVERY registered player — from
// rank 1 down to the full count in the DB — in THREE categories, with NO
// weekly reset (the numbers only ever grow):
//   1. LEVEL        — the DB battle pass level (ties: more xp first)
//   2. CASES OPENED — lifetime solo+battle opens (ties: newer player first)
//   3. BIGGEST WIN  — the single most valuable drop the player ever landed
// Permanently banned players are LEFT OUT — a blocked account earns nothing.

export interface LeaderRow {
  rank: number;
  id: string;
  name: string;
  avatar: string | null;
  level: number;
  value: number;
}

/** GET /api/leaderboard — public; one call returns all three lists. */
export async function GET(req: NextRequest) {
  // a public page — brake per IP so a scraper cannot hammer the DB
  if (!rateLimit(`lb:${ipOf(req.headers)}`, 60, 60_000)) {
    return NextResponse.json(TOO_MANY, { status: 429 });
  }

  const players = await db.player.findMany({
    where: { bannedAt: null },
    select: { id: true, name: true, avatar: true, level: true, xp: true, casesOpened: true },
  });

  // biggest single drop per player — one grouped query over the live-feed rows
  const maxes = await db.drop.groupBy({
    by: ["playerId"],
    _max: { value: true },
  });
  const biggest = new Map<string, number>();
  for (const m of maxes) {
    if (m.playerId && m._max.value != null) biggest.set(m.playerId, m._max.value);
  }

  const withWins = players.map((p) => ({ ...p, biggestWin: biggest.get(p.id) ?? 0 }));

  const toRows = (arr: typeof withWins, valueOf: (p: (typeof withWins)[number]) => number, displayOf: (p: (typeof withWins)[number]) => number): LeaderRow[] =>
    [...arr]
      .sort((a, b) => valueOf(b) - valueOf(a))
      .map((p, i) => ({
        rank: i + 1,
        id: p.id,
        name: p.name,
        avatar: p.avatar,
        level: p.level,
        value: displayOf(p),
      }));

  // the LEVEL tab sorts by (level, xp) so the fuller battle pass wins a tie,
  // but DISPLAYS the plain level — and shares one rank across the same level
  const levelSorted = [...withWins].sort((a, b) => b.level * 1e9 + b.xp - (a.level * 1e9 + a.xp));
  const levelRows: LeaderRow[] = [];
  levelSorted.forEach((p, i) => {
    levelRows.push({
      rank: i > 0 && levelSorted[i - 1].level === p.level ? levelRows[i - 1].rank : i + 1,
      id: p.id,
      name: p.name,
      avatar: p.avatar,
      level: p.level,
      value: p.level,
    });
  });

  return NextResponse.json({
    level: levelRows,
    cases: toRows(withWins, (p) => p.casesOpened, (p) => p.casesOpened),
    biggest: toRows(withWins, (p) => p.biggestWin, (p) => p.biggestWin),
    total: players.length,
  });
}
