import type { Metadata } from "next";
import { Suspense } from "react";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { ProvablyFairView } from "@/components/rollbox/ProvablyFairView";

export const metadata: Metadata = {
  title: "Provably Fair | ROLLBOX",
  description:
    "ROLLBOX Provably Fair system — inspect your client seed, server seed commitment and nonce, then re-verify every roll yourself with the built-in roll checker.",
};

export default function ProvablyFairPage() {
  return (
    <SiteShell>
      <Suspense fallback={null}>
        <ProvablyFairView />
      </Suspense>
    </SiteShell>
  );
}
