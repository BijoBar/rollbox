import type { Metadata } from "next";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { ProvablyFairGuide } from "@/components/rollbox/ProvablyFairGuide";

export const metadata: Metadata = {
  title: "How to use Provably Fair | ROLLBOX",
  description:
    "Step-by-step: save your Public Hash and Client Seed, reveal the Server Seed, recompute any drop in CHECK ROLL and verify ROLLBOX from the outside with plain SHA-256 / HMAC commands.",
};

export default function ProvablyFairHowToUsePage() {
  return (
    <SiteShell>
      <ProvablyFairGuide />
    </SiteShell>
  );
}
