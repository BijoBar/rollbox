import type { Metadata } from "next";
import { Rajdhani, Saira } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { SessionProvider } from "@/lib/session";
import { RealtimeProvider } from "@/lib/realtime";
import { BreakGuard } from "@/components/rollbox/BreakGuard";
import { BanGuard } from "@/components/rollbox/BanGuard";
import { DownloadDataButton } from "@/components/rollbox/DownloadDataButton";
import { RefCapture } from "@/components/rollbox/RefCapture";
import { SupportChatWidget } from "@/components/rollbox/SupportChatWidget";
import { CorridorBackground } from "@/components/rollbox/CorridorBackground";
import { DefaultBackdrop } from "@/components/rollbox/DefaultBackdrop";
import { WarpProvider } from "@/components/rollbox/WarpProvider";
import { BUILD_TAG } from "@/lib/build-info";

// USER SPEC (Task 72): English/Latin fonts only — the Hebrew glyphs fall back
// to the viewer's system font exactly like before, but every Latin letter,
// digit, price and skin name now renders in the new CS2-style HUD fonts:
//   Rajdhani — squared semi-condensed display, the closest Google font to
//              CS2's own Stratum2 HUD font (numbers, prices, labels, titles)
//   Saira    — sporty-tech grotesque for body text, variable 100-900 so
//              font-medium / font-extrabold keep their exact weights
const saira = Saira({
  variable: "--font-saira",
  subsets: ["latin"],
});

const rajdhani = Rajdhani({
  variable: "--font-rajdhani",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "ROLLBOX | CS2 Case Opening",
  description:
    "CS2-style case opening site - animated roulette, rare skins and live drops. Entertainment demo with virtual currency only.",
  keywords: ["CS2", "case opening", "skins", "counter-strike", "cases"],
  // USER SPEC (Task 45): the OFFICIAL logo everywhere — the dice crop as the
  // browser-tab icon, the full lockup on the site
  icons: {
    icon: "/rollboxlogo-icon.png",
    apple: "/rollboxlogo-icon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" dir="ltr" data-scroll-behavior="smooth" suppressHydrationWarning>
      <body
        className={`${saira.variable} ${rajdhani.variable} antialiased bg-background text-foreground min-h-screen flex flex-col overflow-x-clip relative`}
      >
        {/* USER SPEC (Task 84): the WHOLE SITE now flies inside an infinite
            neon corridor — a fixed canvas BEHIND everything (not an absolute
            document layer): scrolling walks the camera deeper into the
            tunnel, the site's crates float inside it and swap randomly, and
            TopBar navigation boosts it to light speed (WarpProvider). */}
        <CorridorBackground />
        {/* USER SPEC (Task 171): the home artwork is the DEFAULT page backdrop
            on every route — pages with their own artwork (upgrader, battles,
            event, terminal) suppress it and mount theirs instead. */}
        <DefaultBackdrop />
        <RealtimeProvider>
          <SessionProvider>
            <WarpProvider>{children}</WarpProvider>
            {/* USER SPEC (Task 75): TAKE A BREAK covers the whole site while a
                self-imposed break runs (server-enforced behind it) */}
            <BreakGuard />
            {/* USER SPEC (Task 180): a PERMANENTLY banned player signs in
                normally but meets this shield on every page */}
            <BanGuard />
            {/* USER SPEC (Task 22): catches /?ref=CODE invite links and claims
                them once the visitor signs in */}
            <RefCapture />
            {/* USER SPEC (Task 136): the SUPPORT CHAT — the floating "?" button
                at the bottom-right of EVERY page opens the ROLLBOX AI chat with
                the human-support handoff (admins use the panel inbox instead) */}
            <SupportChatWidget />
            <Toaster />
            {/* Task 121/122: verified-build badge on EVERY page — if a locally-run
                copy does NOT show this, it is the old pre-retune package.
                Task 180: DOWNLOAD DATA — the package download now asks for the
                owner's password before it fires. */}
            <div className="fixed bottom-1.5 left-2 z-40 select-none font-rajdhani text-[10px] font-semibold tracking-[0.18em] text-white/25 flex items-center gap-2">
              <span className="pointer-events-none">{BUILD_TAG}</span>
              <DownloadDataButton zipHref="/ROLLBOX-site-v50.zip" />
            </div>
          </SessionProvider>
        </RealtimeProvider>
      </body>
    </html>
  );
}
