"use client";

import { motion } from "framer-motion";
import { FARM_CASES, STANDARD_CASES } from "@/lib/cases";
import { SiteShell } from "@/components/rollbox/SiteShell";
import { Hero } from "@/components/rollbox/Hero";
import { PromoSection } from "@/components/rollbox/PromoSection";
import { CaseCard } from "@/components/rollbox/CaseCard";

export default function Home() {
  return (
    <SiteShell>
      {/* USER SPEC (Task 32): the stats strip moved ABOVE the header — it now
          lives in SiteShell, the first element on EVERY page. */}
      <Hero />

      {/* ===== community & updates promos ===== */}
      <PromoSection />

      {/* ===== cases ===== */}
      <section id="cases" className="relative mx-auto max-w-7xl scroll-mt-28 px-4 py-14" aria-label="Our cases">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5 }}
          className="mb-10 text-center"
        >
          <p className="font-display text-sm font-bold tracking-[0.3em] text-violet-300/80">
            CHOOSE YOUR CASE
          </p>
          {/* USER SPEC (Task 43 + 33): the official heading — "RollBox Official";
              the tagline under it is GONE (Task 33) */}
          <h2 className="mt-2 text-3xl font-black text-white md:text-4xl">
            RollBox <span className="text-gradient-neon">Official</span>
          </h2>
        </motion.div>

        <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
          {STANDARD_CASES.map((c, i) => (
            <motion.div
              key={c.id}
              className="min-w-0"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: (i % 4) * 0.08 }}
            >
              <CaseCard caseDef={c} index={i} />
            </motion.div>
          ))}
        </div>

        {/* ===== farm cases ===== */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5 }}
          className="mb-8 mt-16 text-center"
        >
          {/* USER SPEC (Task 33): the FARM header is just "Farm cases" — the
              FARM ZONE eyebrow and both taglines are GONE */}
          <h2 className="text-3xl font-black text-white md:text-4xl">
            Farm <span className="text-gradient-neon">cases</span>
          </h2>
        </motion.div>
        <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3">
          {FARM_CASES.map((c, i) => (
            <motion.div
              key={c.id}
              className="min-w-0"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
            >
              <CaseCard caseDef={c} index={i} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* USER SPEC: the "Browse every skin" strip and the HOW IT WORKS section
          are GONE — the home page now ends with the cases grid. */}
    </SiteShell>
  );
}
