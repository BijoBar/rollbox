import type { NextConfig } from "next";

// HARDENING (Task 153): a real Content-Security-Policy on every response.
// Dev needs 'unsafe-eval' (Turbopack HMR) + ws: (the HMR socket) — the
// production build needs neither. The 'self' default + explicit https: images
// keep Steam CDN avatars/renders working.
// frame-ancestors stays OUT on purpose (Task 108 decision stands): the site is
// legitimately embedded by preview panes; ANY frame-ancestors value would
// break that embed. Every other CSP vector is locked below.
const isDev = process.env.NODE_ENV !== "production";
const CSP = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline'${isDev ? " 'unsafe-eval'" : ""}`,
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob: https:",
  "font-src 'self' data:",
  `connect-src 'self'${isDev ? " ws:" : ""}`,
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join("; ");

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // ANTI-CHEAT / hardening pass (Task 108): baseline security headers on every
  // response — extended in Task 153 with CSP + HSTS (no X-Frame-Options /
  // frame-ancestors — see the CSP note above for the preview-embed reason).
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=()" },
          { key: "Content-Security-Policy", value: CSP },
          { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
        ],
      },
    ];
  },
};

export default nextConfig;
