// E2E cleanup: remove ONLY the chat rows created during this E2E session
// (player p_t66A never had stored messages before this task — Task 136
// deleted its own test rows too). Never touches players.
import { db } from "../src/lib/db";

const msgs = await db.supportMessage.deleteMany({ where: { playerId: "p_t66A" } });
const cases = await db.supportCase.deleteMany({ where: { playerId: "p_t66A" } });
const players = await db.player.count();
console.log(JSON.stringify({ deletedMessages: msgs.count, deletedCases: cases.count, players }));
process.exit(0);
