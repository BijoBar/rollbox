// Task 94 probe helper — mint a signed rb_session cookie for a DB player
// (same HMAC scheme as src/lib/server/auth.ts, default dev secret).
import crypto from "crypto";

const playerId = process.argv[2] || "p_t72B";
const secret = process.env.AUTH_SECRET || "rollbox-dev-secret";
const SESSION_MS = 30 * 24 * 60 * 60 * 1000;

const body = Buffer.from(JSON.stringify({ pid: playerId, exp: Date.now() + SESSION_MS })).toString("base64url");
const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
console.log(`${body}.${sig}`);
