#!/usr/bin/env python3
"""Task 68 image assets:
- ctside.png / tside.png  -> public/teams/ct.webp / t.webp  (2v2 team patches, 512px)
- rollboxcoin.png         -> public/rollboxcoin-icon.png    (square coin icon, 128px)
                                       + public/rollboxcoin.png (256px, hero-sized use)
All uploads arrive pre-cut (transparent background) — we trim to the alpha
bounding box, pad to square when needed and downscale.
"""
from PIL import Image
import numpy as np
import os

UP = "/home/z/my-project/upload"
PUB = "/home/z/my-project/public"


def alpha_bbox(im: Image.Image, thresh: int = 8) -> tuple[int, int, int, int]:
    a = np.array(im)[..., 3]
    ys, xs = np.where(a > thresh)
    if len(xs) == 0:
        return (0, 0, im.width, im.height)
    return (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)


def pad_square(im: Image.Image) -> Image.Image:
    side = max(im.width, im.height)
    canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    canvas.paste(im, ((side - im.width) // 2, (side - im.height) // 2), im)
    return canvas


def team(src: str, dst: str) -> None:
    im = Image.open(src).convert("RGBA")
    x0, y0, x1, y1 = alpha_bbox(im)
    im = im.crop((x0, y0, x1, y1))
    im = pad_square(im).resize((512, 512), Image.LANCZOS)
    im.save(dst, "WEBP", quality=88, method=6)
    kb = os.path.getsize(dst) / 1024
    print(f"{dst}  {im.size}  {kb:.0f}KB")


def coin(src: str) -> None:
    im = Image.open(src).convert("RGBA")
    x0, y0, x1, y1 = alpha_bbox(im)
    im = im.crop((x0, y0, x1, y1))
    sq = pad_square(im)
    for size, dst in ((256, f"{PUB}/rollboxcoin.png"), (128, f"{PUB}/rollboxcoin-icon.png")):
        out = sq.resize((size, size), Image.LANCZOS)
        out.save(dst, "PNG", optimize=True)
        print(f"{dst}  {out.size}  {os.path.getsize(dst)/1024:.0f}KB")


if __name__ == "__main__":
    os.makedirs(f"{PUB}/teams", exist_ok=True)
    team(f"{UP}/tside.png", f"{PUB}/teams/t.webp")
    team(f"{UP}/ctside.png", f"{PUB}/teams/ct.webp")
    coin(f"{UP}/rollboxcoin.png")
