#!/usr/bin/env python3
"""Task 194: convert the user's 800x800 CT/T emblem PNGs to the site's 512x512 RGBA webp format."""
from PIL import Image
import os

SRC = "/home/z/my-project/.team-swap"
DST = "/home/z/my-project/public/teams"

pairs = [
    ("ryRh6bDh_ctside.png", "ct.webp"),
    ("jqn8V9Dk_tside.png", "t.webp"),
]

for src_name, dst_name in pairs:
    src = os.path.join(SRC, src_name)
    dst = os.path.join(DST, dst_name)
    im = Image.open(src).convert("RGBA")
    # corner alpha check (transparency proof)
    corners = [im.getpixel(p)[3] for p in [(2, 2), (799, 2), (2, 799), (799, 799)]]
    out = im.resize((512, 512), Image.LANCZOS)
    out.save(dst, "WEBP", method=6, quality=90, exact=True)
    size = os.path.getsize(dst)
    print(f"{src_name} -> {dst_name}: corners alpha={corners}, out={size}B, mode={out.mode}, size={out.size}")
