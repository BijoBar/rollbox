// ============ Task 32 (USER SPEC): TRUE CENT PRICES in the skin catalog ============
// The owner: "בUPGRADER אני רוצה שסקינים יוכלו לקבל מחירים של 0.01 ולא רק 0.1,
// ממש למחירי הסנט ולא רק עשר סנט" — skins must be able to carry REAL cent
// prices (0.01 precision), not just the old 0.1 grid.
//
// ROOT CAUSE: every LIVE derivation path (wear.ts usdToCoins, the steam-stock
// sync, apply-unified-prices.ts) already rounds to 0.01 with a 0.01 floor —
// but the STATIC catalog file itself still carries v = round(p, 1) from an old
// generation pass: all 2,126 prize-pool weapons sit on the 0.1 grid (246 of
// them are really worth LESS than $0.10 — one AUG is a $0.01 skin), so the
// UPGRADER's catalogNearest prize picker could never land on a true cent value.
//
// FIX: re-derive v = max(0.01, round(p * 100) / 100) for EVERY entry with a
// real market reference p > 0 — the exact math of usdToCoins at the site's
// USD_TO_COINS = 1 rate. p is untouched (it IS the real-USD reference).
// Consumers: the UPGRADER prize pool (the owner's ask), the exchange buy/sell
// fallback, and every future catalogNearest-style picker — all become
// cent-precise. Idempotent: running twice changes nothing the second time.
//
// SAFETY: a timestamped backup is written next to the file before the first
// write. InventoryItem rows / case prices / terminal tables / battle entries
// are NOT derived from catalog v at runtime — they keep their stored values
// (red line: player data is never touched).

import fs from "fs";
import path from "path";

const ROOT = process.cwd();
const FILE = path.join(ROOT, "public", "skins-catalog.json");
const BACKUP = path.join(ROOT, "public", "skins-catalog.json.t32-pre-cents");

const raw = JSON.parse(fs.readFileSync(FILE, "utf8"));
if (!Array.isArray(raw)) {
  console.error("FATAL: skins-catalog.json is not an array");
  process.exit(1);
}

if (!fs.existsSync(BACKUP)) {
  fs.writeFileSync(BACKUP, JSON.stringify(raw));
  console.log(`✓ backup written: ${path.basename(BACKUP)}`);
} else {
  console.log("• backup already exists — left untouched");
}

// the site's own conversion, inlined (wear.ts usdToCoins @ USD_TO_COINS = 1)
const cent = (usd) => Math.max(0.01, Math.round(usd * 100) / 100);

let changed = 0;
let subDime = 0;
let minV = Infinity;
let minName = "";
for (const e of raw) {
  if (!e || typeof e !== "object") continue;
  if (!(Number.isFinite(e.p) && e.p > 0)) continue; // no market ref → keep v
  const nv = cent(e.p);
  if (!Number.isFinite(nv)) continue;
  if (Math.abs((e.v ?? 0) - nv) > 1e-9) {
    e.v = nv;
    changed++;
  }
  if (nv < 0.1) subDime++;
  if (nv < minV) {
    minV = nv;
    minName = e.n ?? e.id ?? "?";
  }
}

fs.writeFileSync(FILE, JSON.stringify(raw));
console.log(`✓ catalog re-derived at true cent precision`);
console.log(`  entries total:            ${raw.length}`);
console.log(`  values changed (v := p):  ${changed}`);
console.log(`  weapons now priced <0.10: ${subDime}`);
console.log(`  cheapest value now:       ${minV.toFixed(2)} — ${minName}`);

// verify: prize pool granularity after the rewrite
const weapons = raw.filter((e) => e && Number.isFinite(e.v) && e.v > 0 && !e.t);
const oneDecimal = weapons.filter((e) => (String(e.v).split(".")[1] ?? "").length <= 1).length;
const trueCents = weapons.filter((e) => Math.round(e.v * 100) % 10 !== 0).length;
console.log(`  prize pool (weapons):     ${weapons.length} — on 0.1 grid: ${oneDecimal}, true cent values: ${trueCents}`);
