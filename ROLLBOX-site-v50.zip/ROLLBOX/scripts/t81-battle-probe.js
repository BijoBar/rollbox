(() => {
  // Battle reel EDGING probe — locked reels in the room:
  // offset = wrapCenterY - winnerCellCenterY (positive = winner rests ABOVE
  // the center line = overshoot toward the NEXT cell below).
  const out = [];
  const wraps = [...document.querySelectorAll('div.relative.overflow-hidden')].filter(w => {
    const r = w.getBoundingClientRect();
    return r.height > 120 && Math.abs(r.width - r.height) < 30; // the seat squares
  });
  for (const wrap of wraps) {
    const wr = wrap.getBoundingClientRect();
    const cells = [...wrap.querySelectorAll('div')].filter(c => {
      const cls = c.className || '';
      return typeof cls === 'string' && cls.includes('aspect-[2/1]') && cls.includes('grid');
    });
    const winCell = cells.find(c => {
      const img = c.querySelector('img');
      return img && (img.className || '').includes('scale-110');
    });
    if (!winCell) { out.push({ h: Math.round(wr.height), cells: cells.length, locked: false }); continue; }
    const tr = winCell.getBoundingClientRect();
    const t0 = cells[0].getBoundingClientRect();
    const t1 = cells[1] ? cells[1].getBoundingClientRect() : null;
    const cell = Math.round(t0.height);
    const gap = t1 ? Math.round(t1.top - t0.bottom) : 10;
    const offset = Math.round((wr.top + wr.height / 2) - (tr.top + tr.height / 2));
    const dist = cell / 2 + gap;
    out.push({ cell, gap, offset, frac: +(offset / dist).toFixed(3) });
  }
  return JSON.stringify(out);
})()
