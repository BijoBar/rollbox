"""Trace the .rd-white-cover lifecycle (attach/detach) in normal AND
reduced-motion contexts. Expected lifetime passed as argv[1] in ms
(default 750)."""
import json
import sys
import time
from playwright.sync_api import sync_playwright

EXPECT_MS = int(sys.argv[1]) if len(sys.argv) > 1 else 750
URL = "http://localhost:3000/case/test-rolldrop"
SHOTS = "/home/z/my-project/download/e2e-shots"

OBSERVER = """() => {
  window.__rdLog = [];
  const log = (m) => window.__rdLog.push([performance.now().toFixed(0), m]);
  const target = document.querySelector('section[aria-label*="unboxing reel"]');
  const mo = new MutationObserver((muts) => {
    for (const m of muts) {
      for (const n of m.addedNodes) if (n.className && String(n.className).includes('rd-white-cover')) log('ATTACH ' + performance.now().toFixed(0));
      for (const n of m.removedNodes) if (n.className && String(n.className).includes('rd-white-cover')) log('DETACH ' + performance.now().toFixed(0));
    }
  });
  mo.observe(target, { childList: true, subtree: true });
  log('OBSERVER_ARMED');
}"""

READ_ANIM = """() => {
  const el = document.querySelector('.rd-white-cover');
  if (!el) return null;
  const cs = getComputedStyle(el);
  return { name: cs.animationName, duration: cs.animationDuration };
}"""

READ_ANIM_STATIC = """() => {
  const el = document.querySelector('.rd-white-cover');
  if (!el) return { name: 'NOT-MOUNTED-YET', duration: null };
  const cs = getComputedStyle(el);
  return { name: cs.animationName, duration: cs.animationDuration };
}"""


def balance(pg):
    try:
        return pg.evaluate(
            "() => { const s = JSON.parse(localStorage.getItem('rollbox-store')||'null'); return s && s.state ? s.state.balance : null; }"
        )
    except Exception:
        return None


def run(ctx, label, shots):
    pg = ctx.new_page()
    pg.goto(URL, wait_until="domcontentloaded", timeout=90000)
    pg.wait_for_timeout(1500)
    pg.evaluate("localStorage.setItem('rb-rolldrop-force','1')")
    pg.reload(wait_until="domcontentloaded", timeout=90000)
    pg.wait_for_timeout(1200)
    pg.evaluate(OBSERVER)
    bal0 = balance(pg)
    t0 = time.time()
    pg.click("button:has-text('Open Case')")
    pg.wait_for_selector(".rd-white-cover", state="attached", timeout=25000)
    attach = round(time.time() - t0, 2)
    anim = pg.evaluate(READ_ANIM)

    if shots:
        box = pg.evaluate(
            """() => {
              const el = document.querySelector('.rd-white-cover');
              const r = el.parentElement.getBoundingClientRect();
              return {x: r.x, y: r.y, width: r.width, height: r.height};
            }"""
        )
        # schedule the burst inside the ACTUAL hold window, not past it
        for delay in (int(EXPECT_MS * 0.3), int(EXPECT_MS * 0.6)):
            pg.wait_for_timeout(delay if delay == int(EXPECT_MS * 0.3) else int(EXPECT_MS * 0.3))
            pg.screenshot(path=f"{SHOTS}/45i-white-{delay}ms-{label}.png", clip=box)
    else:
        pg.wait_for_timeout(EXPECT_MS + 600)

    time.sleep(1.6)  # let the unmount land
    log = pg.evaluate("window.__rdLog")
    anim_late = pg.evaluate(READ_ANIM_STATIC)
    bal1 = balance(pg)
    print(f"--- {label} ---")
    print("white attached after click (s):", attach)
    print("computed animation at mount:", json.dumps(anim))
    print("lifecycle log:", json.dumps(log))
    print("balance before/after:", bal0, "->", bal1)
    pg.close()
    return log, anim, anim_late


with sync_playwright() as p:
    b = p.chromium.launch()
    norm = b.new_context(viewport={"width": 1440, "height": 900})
    red = b.new_context(viewport={"width": 1440, "height": 900}, reduced_motion="reduce")

    log_n, anim_n, late_n = run(norm, "normal", shots=True)
    log_r, anim_r, late_r = run(red, "reduced", shots=True)

    b.close()

def lifetime(log):
    a = d = None
    for _, m in log:
        if m.startswith("ATTACH"):
            a = float(m.split()[1])
        if m.startswith("DETACH"):
            d = float(m.split()[1])
    return (d - a) if a is not None and d is not None else None

ln, lr = lifetime(log_n), lifetime(log_r)
lo, hi = EXPECT_MS - 250, EXPECT_MS + 250
want_dur = f"{EXPECT_MS / 1000}s"
print()
print("=== VERDICT ===")
print(f"normal  ATTACH->DETACH: {ln}ms (expect ~{EXPECT_MS})")
print(f"reduce  ATTACH->DETACH: {lr}ms (expect ~{EXPECT_MS})")
print(f"computed CSS duration normal : {anim_n['duration']} (want {want_dur})")
print(f"computed CSS duration reduced: {anim_r['duration']} (want {want_dur}, name {anim_r['name']})")
print(f"late animation probe normal : {json.dumps(late_n)}")
print(f"late animation probe reduced: {json.dumps(late_r)}")
ok = (
    ln and lo <= ln <= hi
    and lr and lo <= lr <= hi
    and anim_n["duration"] == want_dur
    and anim_r["duration"] == want_dur
    and anim_r["name"] == "rd-white-cover-static"
)
print("RESULT:", "PASS" if ok else "FAIL")
