// e2e seed — keep p_t66A (THE test account) stocked with a few cheap skins so
// the upgrader E2E always has a stake + a fresh pick available. Idempotent:
// fixed row ids, upsert. NEVER touches any other player (players:9 stays put).
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const PID = "p_t66A";

const SEEDS = [
  {
    id: "i_e2eseed0001",
    data: {
      id: "awp-pit-viper",
      n: "AWP | Pit Viper",
      w: "AWP",
      r: "restricted",
      p: 0.93,
      v: 0.93,
      img: "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf9Ttk_PyvY6F-K_mdMWuZxuZi_rQ_GS3mxRwk4jvTyNv6eC-RPQV1W5AlTOZb4xLtw9fuNriw51Hd3otbjXKp4cSTTIs",
      cat: "rifles",
      a: "awp",
    },
  },
  {
    id: "i_e2eseed0002",
    data: {
      id: "ak-redline",
      n: "AK-47 | Redline",
      w: "AK-47",
      r: "classified",
      p: 2.4,
      v: 2.4,
      img: null as string | null,
      cat: "rifles",
      a: "ak",
    },
  },
  {
    id: "i_e2eseed0003",
    data: {
      id: "mp9-green-plaid",
      n: "MP9 | Green Plaid",
      w: "MP9",
      r: "milspec",
      p: 1.2,
      v: 1.2,
      img: null as string | null,
      cat: "smgs",
      a: "mp9",
    },
  },
  {
    id: "i_e2eseed0004",
    data: {
      id: "nova-rising-sun",
      n: "Nova | Rising Sun",
      w: "Nova",
      r: "milspec",
      p: 3.5,
      v: 3.5,
      img: null as string | null,
      cat: "shotguns",
      a: "nova",
    },
  },
];

for (const s of SEEDS) {
  await db.inventoryItem.upsert({
    where: { id: s.id },
    update: { value: s.data.v, data: JSON.stringify(s.data) },
    create: { id: s.id, playerId: PID, entryId: s.data.id, value: s.data.v, data: JSON.stringify(s.data) },
  });
}

const n = await db.inventoryItem.count({ where: { playerId: PID } });
console.log(`p_t66A inventory now: ${n} items (seeds ensured)`);
await db.$disconnect();
