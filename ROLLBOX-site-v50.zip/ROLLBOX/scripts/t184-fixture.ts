// E2E fixture for Task 184 — Special-for-you free cases block.
// --create  : creates a THROWAWAY non-admin player (balance 0), gifts it
//             doppler-realm ×2 (static) + the newest community case ×1
//             (exercises /api/cases/resolve), and mints a signed session
//             cookie (printed as JSON). Direct db writes — the members
//             counter is NOT bumped, no ledger rows, no spins.
// --cleanup : deletes the throwaway row and prints the remaining count.
import { db } from "../src/lib/db";
import { makeSessionToken } from "../src/lib/server/auth";
import { grantFreeCases } from "../src/lib/server/freecases";

const ID = "p_e2e_free_t184";

const mode = process.argv[2] ?? "--create";

if (mode === "--create") {
  await db.player.deleteMany({ where: { id: ID } }); // stale fixture from a crashed run
  const p = await db.player.create({
    data: {
      id: ID,
      provider: "steam",
      providerId: "steam_e2e_free_t184",
      name: "E2E Special Test",
      balance: 0, // Task 183: new accounts start at zero
      isAdmin: false,
    },
  });
  const cc = await db.communityCase.findFirst({ orderBy: { createdAt: "desc" }, select: { id: true } });
  const g1 = await grantFreeCases(ID, "doppler-realm", 2);
  let ccId: string | null = null;
  if (cc) {
    const g2 = await grantFreeCases(ID, cc.id, 1);
    ccId = cc.id;
    console.log(JSON.stringify({ id: p.id, token: makeSessionToken(p.id), g1: g1?.["doppler-realm"], ccId, g2: g2?.[ccId] }));
  } else {
    console.log(JSON.stringify({ id: p.id, token: makeSessionToken(p.id), g1: g1?.["doppler-realm"], ccId, g2: null }));
  }
} else if (mode === "--state") {
  const p = await db.player.findUnique({ where: { id: ID } });
  if (!p) {
    console.log(JSON.stringify({ missing: true }));
  } else {
    let free: unknown = {};
    try { free = JSON.parse(p.freeCases ?? "{}"); } catch { free = { garbage: p.freeCases }; }
    console.log(JSON.stringify({ freeCases: free, balance: p.balance }));
  }
} else if (mode === "--cleanup") {
  await db.player.deleteMany({ where: { id: ID } });
  const n = await db.player.count();
  console.log(JSON.stringify({ deleted: ID, players: n }));
}
process.exit(0);
