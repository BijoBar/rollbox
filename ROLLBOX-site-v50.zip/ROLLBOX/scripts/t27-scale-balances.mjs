// ============ Task 27 OPTIONAL: divide every player balance by 10 ============
// ⚠️ DELIBERATELY NOT RUN BY THE MIGRATION — the data red line ("never touch
// player data without the owner's say-so"). Run ONLY if the owner explicitly
// asks for it after the 1$ = 1 coin denomination flip:
//
//   bun scripts/t27-scale-balances.mjs
//
// What it does: Player.balance ÷ 10 (cent-precise, 0.01 floor) for EVERY
// player, plus a ledger row (type "system", note) per change so the audit
// trail shows exactly what happened. InventoryItem rows are NOT touched —
// they are historic purchase records of what was actually paid.
//
// Idempotency guard: a marker file db/.t27-balances-scaled prevents a double
// run. Delete that file ONLY if you truly intend to divide again.

import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const MARKER = path.join(process.cwd(), "db", ".t27-balances-scaled");

if (fs.existsSync(MARKER)) {
  console.error("REFUSED: db/.t27-balances-scaled exists — the balances were already divided once.");
  console.error("Delete the marker file first if this is genuinely a second, intended run.");
  process.exit(1);
}

const players = await db.player.findMany({ select: { id: true, name: true, balance: true } });
console.log("Players found:", players.length);
for (const p of players) console.log("  -", p.name ?? p.id, "balance:", p.balance, "→", Math.max(0.01, Math.round(p.balance / 10 * 100) / 100));

console.log("\nThis divides every balance by 10. THIS CONSOLE IS NOT A CONFIRMATION.");
console.log("Only the site owner can authorize it — run again with --yes to proceed.");
if (!process.argv.includes("--yes")) process.exit(0);

for (const p of players) {
  const next = Math.max(0.01, Math.round((p.balance / 10) * 100) / 100);
  await db.player.update({ where: { id: p.id }, data: { balance: next } });
  await db.ledger.create({
    data: {
      playerId: p.id,
      kind: "admin_comp",
      amount: Math.round((next - p.balance) * 100) / 100,
      balanceAfter: next,
      ref: "Task 27 denomination: balance /10 (1$ = 1 coin)",
    },
  }).catch(() => {});
  console.log("✓", p.name ?? p.id, p.balance, "→", next);
}

fs.writeFileSync(MARKER, new Date().toISOString());
console.log("Marker written: db/.t27-balances-scaled");
await db.$disconnect();
