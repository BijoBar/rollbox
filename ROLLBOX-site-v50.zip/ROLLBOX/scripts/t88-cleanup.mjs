// Deletes the T88 E2E test player and every row he owns. Refuses to touch
// anything else — never runs without the exact id below.
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const PID = "p_t88a";

const inv = await db.inventoryItem.deleteMany({ where: { playerId: PID } });
const pend = await db.openPending.deleteMany({ where: { playerId: PID } });
const led = await db.ledger.deleteMany({ where: { playerId: PID } });
const drops = await db.drop.deleteMany({ where: { playerId: PID } });
const battles = await db.battle.deleteMany({ where: { playerId: PID } }).catch(() => null);
const pl = await db.player.deleteMany({ where: { id: PID } });
console.log(`cleanup: inv=${inv.count} pend=${pend.count} led=${led.count} drops=${drops.count} player=${pl.count}`);
await db.$disconnect();
