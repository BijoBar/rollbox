"""E2E capture of the fixed ROLLDROP sequence (white ONLY on the reel).
Task 45-f: the white holds THREE FULL SECONDS at 35% opacity.
Clip-to-reel screenshots (~50-150ms) + absolute-time scheduling so every
frame lands where it was aimed even under software rendering."""
import json
from playwright.sync_api import sync_playwright

OUT = "/home/z/my-project/download/e2e-shots"

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    pg.goto("http://localhost:3000/case/test-rolldrop", wait_until="load", timeout=60000)
    pg.evaluate("localStorage.setItem('rb-rolldrop-force','1')")
    pg.reload(wait_until="load", timeout=60000)
    pg.wait_for_timeout(2500)

    bal0 = pg.evaluate("JSON.parse(localStorage.getItem('rollbox-store')).state.balance")
    pg.click("button:has-text('Open Case')")
    print("clicked, balance before =", bal0)

    # the pause beat: main spin locks on the raredrop tile (~8.1s after click),
    # the white mounts ~1s later — shoot mid-pause
    pg.wait_for_timeout(8500)
    pg.screenshot(path=f"{OUT}/45h-pause.png")

    # frame-perfect: the INSTANT the reel-only white mounts
    pg.wait_for_selector(".rd-white-cover", state="attached", timeout=20000)
    t0 = pg.evaluate("performance.now()")
    # the cover's parent IS the reel box — clip every shot to it for ~100ms latency
    r = pg.evaluate(
        "(() => { const b = document.querySelector('.rd-white-cover')"
        ".parentElement.getBoundingClientRect();"
        " return {x: b.x, y: b.y, width: b.width, height: b.height}; })()"
    )
    clip = {k: max(0, round(v)) for k, v in r.items()}

    def at(target_ms, name):
        while pg.evaluate("performance.now()") - t0 < target_ms - 60:
            pg.wait_for_timeout(40)
        pg.screenshot(path=f"{OUT}/{name}", clip=clip)
        print(f"{name} shot at +{round(pg.evaluate('performance.now()') - t0)}ms")

    at(60, "45h-white-0ms.png")
    at(700, "45h-white-700ms.png")
    at(1600, "45h-white-1600ms.png")
    at(2500, "45h-white-2500ms.png")
    at(3600, "45h-after-white.png")

    # opacity probe just after the fade should read detached (unmount at 3s)
    op = pg.evaluate(
        "(() => { const el = document.querySelector('.rd-white-cover');"
        " return el ? getComputedStyle(el).opacity : 'detached'; })()"
    )
    print("computed opacity on .rd-white-cover:", op)

    # no full-screen flash element may exist anymore
    has_flash = pg.evaluate("!!document.querySelector('.rd-flash')")
    print("rd-flash element present:", has_flash)

    # wait for the bonus reel to lock and credit
    pg.wait_for_timeout(7000)
    bal1 = pg.evaluate("JSON.parse(localStorage.getItem('rollbox-store')).state.balance")
    rolls = pg.evaluate("JSON.parse(localStorage.getItem('rollbox-store')).state.pfRolls.length")
    pg.screenshot(path=f"{OUT}/45h-final.png")
    print(json.dumps({"balance_before": bal0, "balance_after": bal1, "rolls": rolls, "rd_flash": has_flash}))

    b.close()
