#!/usr/bin/env python3
"""Task 75 verification — PROFILE: battle stats + battle history + SETTINGS + SELF CARE.

Static checks (schema columns, selfcare lib, spend guards, routes, profile UI,
break overlay, volume plumbing) + a live server smoke against :3000:
settings save + validation, deposit-limit enforcement on /api/open (server-side),
TAKE A BREAK blocking open/buy/battle-create, and /api/profile/battles math
from seeded battle rows. Runs against the dev server on :3000.
"""
import base64
import hashlib
import hmac
import json
import os
import sqlite3
import sys
import time

import requests

BASE = "http://localhost:3000"
DB = "db/custom.db"
SECRET = "rollbox-dev-secret"
PASS: list[str] = []
FAIL: list[str] = []

TRADE_URL = "https://steamcommunity.com/tradeoffer/new/?partner=123456789&token=Ab-cd_Ef"


def check(name: str, ok: bool, extra: str = "") -> None:
    (PASS if ok else FAIL).append(name + (f" — {extra}" if (extra and not ok) else ""))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if (extra and not ok) else ""))


def read(*parts: str) -> str:
    with open(os.path.join(*parts), encoding="utf-8") as f:
        return f.read()


def mint(pid: str) -> str:
    body = base64.urlsafe_b64encode(json.dumps({"pid": pid, "exp": int(time.time() * 1000) + 86400000},
                                               separators=(",", ":")).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()
    return body + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")


def sess(pid: str) -> dict:
    return {"rb_session": mint(pid)}


def make_player(tag: str, balance: int = 500) -> str:
    pid = f"p_t75{tag}"
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
        "VALUES (?, 'steam', ?, ?, ?, 0, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
        (pid, f"t75-{tag}-steamid", f"T75 {tag}", balance),
    )
    con.commit()
    con.close()
    return pid


def seed_battle(bid: str, code: str, me: str, finished_ago_s: int, me_wins: bool, entry: int = 30, take: int = 0) -> None:
    """One finished 1v1 battle row: me vs one bot, 'me' seated and finished."""
    seats = json.dumps([
        {"key": me, "name": "T75 A", "team": 0, "color": 0, "isBot": False, "paid": entry},
        {"key": "bot_0", "name": "[RBbot] Vic", "team": 1, "color": 1, "isBot": True, "paid": 0},
    ])
    winner = me if me_wins else "bot_0"
    pulls = json.dumps([
        {"playerId": me, "total": take, "pulls": [{"round": 0, "value": take}]},
        {"playerId": "bot_0", "total": 10, "pulls": [{"round": 0, "value": 10}]},
    ])
    winners = json.dumps([winner])
    takes = json.dumps({me: take if me_wins else 0, "bot_0": 0 if me_wins else 60})
    rounds = json.dumps(["test-rolldrop"])
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT OR REPLACE INTO Battle (id, code, hostId, type, mode, potRule, fast, isPrivate, rounds, entry, status, "
        "colorOrder, seats, pulls, winnerIds, tieIds, potTotal, take, startedAt, totalMs, createdAt, updatedAt, finishedAt) "
        "VALUES (?, ?, ?, '1v1', 'standard', 'winner', 0, 0, ?, ?, 'finished', '[0,1,2,3]', ?, ?, ?, NULL, ?, ?, NULL, NULL, "
        "CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, datetime('now', ?))",
        (bid, code, me, rounds, entry, seats, pulls, winners, take + 10, takes, f"-{finished_ago_s} seconds"),
    )
    con.commit()
    con.close()


def main() -> None:
    print("== Task 75 — static checks ==")
    schema = read("prisma", "schema.prisma")
    check("schema: Player carries the settings + self-care columns",
          all(c in schema for c in ["tradeLink", "email", "depositLimit", "depositLimitStart", "depositLimitDays", "breakUntil"]))
    sc = read("src", "lib", "server", "selfcare.ts")
    check("selfcare lib: spend kinds + gate + day math",
          all(k in sc for k in ["SPEND_KINDS", "checkSpendAllowed", "activeDepositLimit", "isOnBreak", "DAY_MS"]))
    check("guard wired: /api/open", "checkSpendAllowed" in read("src", "app", "api", "open", "route.ts"))
    gb = read("src", "lib", "server", "gbattles.ts")
    check("guard wired: battle create + join (2x)", gb.count("checkSpendAllowed") >= 2, str(gb.count("checkSpendAllowed")))
    check("guard wired: exchange buy", "checkSpendAllowed" in read("src", "app", "api", "inventory", "route.ts"))
    routes_ok = (
        os.path.exists("src/app/api/settings/route.ts")
        and os.path.exists("src/app/api/settings/selfcare/route.ts")
        and os.path.exists("src/app/api/profile/battles/route.ts")
    )
    check("routes: settings / selfcare / profile battles exist", routes_ok)
    pv = read("src", "components", "rollbox", "ProfileView.tsx")
    # USER SPEC (Task 81): the history MOVED off the profile onto its own page
    # (/profile/battles) — the profile keeps stats + last-5 and grew the
    # BATTLE HISTORY header button; the new page carries the list + RECREATE.
    bh = read("src", "components", "rollbox", "BattleHistoryView.tsx")
    check("profile UI: stats + last-5 + BATTLE HISTORY button (history on its own page, Task 81)",
          all(k in pv for k in ["Battle stats", "Last 5 battles", "BATTLE HISTORY", "rb_battle_history_v1"])
          and "/profile/battles" in pv
          and all(k in bh for k in ["RECREATE", "caseIds", "rb_battle_history_v1"]))
    # USER SPEC (Task 83): settings + self care moved OFF the profile onto the
    # dedicated /settings page (SettingsView) — NO sign out anywhere in them.
    # The profile header stacks BATTLE HISTORY / BALANCE HISTORY / SETTINGS.
    sv = read("src", "components", "rollbox", "SettingsView.tsx")
    check("profile UI: the three header buttons in the user's order",
          pv.find("BATTLE HISTORY") < pv.find("BALANCE HISTORY") < pv.find("SETTINGS")
          and "/profile/balance" in pv and "href=\"/settings\"" in pv)
    check("settings page UI: SETTINGS + SELF CARE + the two actions (moved off the profile, Task 83)",
          all(k in sv for k in ["Main settings", "SELF CARE", "LIMIT DEPOSIT", "TAKE A BREAK", "0.00$"])
          and os.path.exists("src/app/settings/page.tsx") and "SettingsView" in read("src", "app", "settings", "page.tsx"))
    check("settings page: SIGN OUT deleted from the settings completely",
          "auth/logout" not in sv and "signOut" not in sv and "LogOut" not in sv
          and "auth/logout" not in pv and "signOut" not in pv and "LogOut" not in pv)
    # USER SPEC (Task 83): the BALANCE HISTORY page carries the money ledger.
    bal = read("src", "components", "rollbox", "BalanceHistoryView.tsx")
    check("balance history page: ledger table + labels + totals (Task 83)",
          os.path.exists("src/app/profile/balance/page.tsx")
          and all(k in bal for k in ["LEDGER_LABELS", "balanceAfter", "Total Credits", "Current Balance", "/api/ledger"])
          and "BalanceHistoryView" in read("src", "app", "profile", "balance", "page.tsx"))
    check("profile UI: ROUND avatar + LEVEL ring (levelTier bands)",
          "LevelRing" in pv and "levelTier" in pv
          and all(k in read("src", "lib", "progress.ts") for k in ["Gold", "Turquoise", "levelTier"]))
    check("profile UI: neon W (emerald) vs L (rose) glow",
          "rgba(52,211,153" in pv and "rgba(244,63,94" in pv)
    check("break overlay: BreakGuard exists and sits in the root layout",
          os.path.exists("src/components/rollbox/BreakGuard.tsx") and "BreakGuard" in read("src", "app", "layout.tsx"))
    check("volume: store field + setter + master gain",
          "soundVolume" in read("src", "lib", "store.ts") and "setSoundVolume" in read("src", "lib", "store.ts")
          and "setMasterVolume" in read("src", "lib", "sound.ts"))

    # ===== live: settings + validation =====
    print("== live: settings ==")
    a = make_player("A", 500)

    r = requests.get(BASE + "/api/settings", timeout=15, cookies=sess(a))
    d = r.json() if r.ok else {}
    check("live: GET settings empty state", r.status_code == 200 and d.get("settings") == {"tradeLink": "", "email": ""}
          and d.get("selfcare", {}).get("deposit") is None and d.get("selfcare", {}).get("breakUntil") is None, r.text[:140])

    r = requests.post(BASE + "/api/settings", timeout=15, cookies=sess(a),
                      json={"tradeLink": "https://evil.example.com/trade", "email": ""})
    check("live: bogus trade link rejected", r.status_code == 400, f"{r.status_code} {r.text[:100]}")

    r = requests.post(BASE + "/api/settings", timeout=15, cookies=sess(a),
                      json={"tradeLink": TRADE_URL, "email": "t75@example.com"})
    ok = r.status_code == 200 and r.json().get("settings", {}).get("tradeLink") == TRADE_URL
    check("live: valid trade link + email saved", ok, r.text[:140])

    r = requests.get(BASE + "/api/auth/me", timeout=15, cookies=sess(a))
    me = r.json().get("player", {})
    check("live: /api/auth/me carries the new fields",
          me.get("tradeLink") == TRADE_URL and me.get("email") == "t75@example.com"
          and "depositLimit" in me and "breakUntil" in me, r.text[:160])

    r = requests.post(BASE + "/api/settings", timeout=15, cookies=sess(a),
                      json={"tradeLink": "", "email": "not-an-email"})
    check("live: bogus email rejected", r.status_code == 400, f"{r.status_code}")

    # USER SPEC (Task 83): PARTIAL saves — a field missing from the body keeps
    # its stored value (profile saves only the link, /settings only the email).
    r = requests.post(BASE + "/api/settings", timeout=15, cookies=sess(a), json={"tradeLink": ""})
    ok = r.status_code == 200 and r.json().get("settings", {}).get("tradeLink") == "" \
        and r.json().get("settings", {}).get("email") == "t75@example.com"
    check("live: partial save keeps the untouched field (email survives link clear)", ok, r.text[:140])

    r = requests.post(BASE + "/api/settings", timeout=15, cookies=sess(a),
                      json={"email": "t75b@example.com"})
    ok = r.status_code == 200 and r.json().get("settings", {}).get("email") == "t75b@example.com" \
        and r.json().get("settings", {}).get("tradeLink") == ""
    check("live: partial save touches only the email (link stays cleared)", ok, r.text[:140])

    # ===== live: self care — deposit limit enforced ON THE SERVER =====
    print("== live: deposit limit ==")
    r = requests.post(BASE + "/api/settings/selfcare", timeout=15, cookies=sess(a),
                      json={"action": "deposit", "days": 1, "amount": 50})
    check("live: selfcare without confirm refused", r.status_code == 400, f"{r.status_code} {r.text[:100]}")

    r = requests.post(BASE + "/api/settings/selfcare", timeout=15, cookies=sess(a),
                      json={"action": "deposit", "days": 5, "amount": 50, "confirm": True})
    check("live: 5-day duration refused (1-3 only)", r.status_code == 400, f"{r.status_code}")

    r = requests.post(BASE + "/api/settings/selfcare", timeout=15, cookies=sess(a),
                      json={"action": "deposit", "days": 1, "amount": 50, "confirm": True})
    d = r.json() if r.ok else {}
    dep = d.get("selfcare", {}).get("deposit") or {}
    check("live: deposit limit set (50 coins / 1 day)", r.status_code == 200 and dep.get("limit") == 50 and dep.get("days") == 1, r.text[:160])

    r = requests.get(BASE + "/api/settings", timeout=15, cookies=sess(a))
    spent = (r.json().get("selfcare", {}).get("deposit") or {}).get("spent")
    check("live: spent starts at 0", spent == 0, str(spent))

    r = requests.post(BASE + "/api/open", timeout=20, cookies=sess(a), json={"caseId": "test-rolldrop", "count": 1})
    check("live: opening under the limit allowed", r.status_code == 200, f"{r.status_code} {r.text[:100]}")

    r = requests.get(BASE + "/api/settings", timeout=15, cookies=sess(a))
    spent = (r.json().get("selfcare", {}).get("deposit") or {}).get("spent")
    check("live: ledger spend counted (10 coins)", spent == 10, str(spent))

    r = requests.post(BASE + "/api/open", timeout=20, cookies=sess(a), json={"caseId": "test-rolldrop", "count": 5})
    check("live: move past the limit blocked (403 + hint)",
          r.status_code == 403 and "deposit limit" in r.json().get("error", ""), f"{r.status_code} {r.text[:120]}")

    r = requests.post(BASE + "/api/open", timeout=20, cookies=sess(a), json={"caseId": "test-rolldrop", "count": 4})
    check("live: boundary move (exactly the limit) allowed", r.status_code == 200, f"{r.status_code} {r.text[:100]}")

    r = requests.post(BASE + "/api/open", timeout=20, cookies=sess(a), json={"caseId": "test-rolldrop", "count": 1})
    check("live: limit exhausted -> blocked", r.status_code == 403, f"{r.status_code} {r.text[:120]}")

    # ===== live: TAKE A BREAK blocks every spending route =====
    print("== live: take a break ==")
    b = make_player("B", 5000)
    r = requests.post(BASE + "/api/settings/selfcare", timeout=15, cookies=sess(b),
                      json={"action": "break", "days": 2, "confirm": True})
    d = r.json() if r.ok else {}
    check("live: break set (2 days)", r.status_code == 200 and d.get("selfcare", {}).get("onBreak") is True
          and d.get("selfcare", {}).get("breakUntil"), r.text[:140])

    r = requests.post(BASE + "/api/open", timeout=20, cookies=sess(b), json={"caseId": "test-rolldrop", "count": 1})
    check("live: open blocked on break", r.status_code == 403 and "break" in r.json().get("error", "").lower(), f"{r.status_code} {r.text[:120]}")

    r = requests.post(BASE + "/api/inventory", timeout=15, cookies=sess(b), json={"entryId": "ak-47-redline", "wear": "FT"})
    check("live: exchange buy blocked on break", r.status_code == 403, f"{r.status_code} {r.text[:120]}")

    r = requests.post(BASE + "/api/gbattles", timeout=15, cookies=sess(b),
                      json={"type": "1v1", "mode": "standard", "potRule": "winner", "rounds": ["test-rolldrop"]})
    check("live: battle create blocked on break", r.status_code == 400 and "break" in r.json().get("error", "").lower(), f"{r.status_code} {r.text[:140]}")

    # ===== live: profile battles stats + history =====
    print("== live: battle stats + history ==")
    seed_battle("t75battleold", "RB-OLD", a, finished_ago_s=7200, me_wins=False)
    seed_battle("t75battlenew", "RB-NEW", a, finished_ago_s=60, me_wins=True, take=60)

    r = requests.get(BASE + "/api/profile/battles", timeout=15, cookies=sess(a))
    d = r.json() if r.ok else {}
    t = d.get("totals", {})
    check("live: totals battles/wins/losses", t.get("battles") == 2 and t.get("wins") == 1 and t.get("losses") == 1, json.dumps(t))
    check("live: win rate 50%", t.get("winRate") == 50.0, str(t.get("winRate")))
    check("live: last5 = W,L (newest first)", d.get("last5") == ["W", "L"], str(d.get("last5")))
    hist = d.get("history", [])
    newest = hist[0] if hist else {}
    check("live: newest history row is the W with +30 net",
          newest.get("code") == "RB-NEW" and newest.get("result") == "W" and newest.get("net") == 30
          and newest.get("take") == 60 and newest.get("entry") == 30, json.dumps(newest)[:220])
    check("live: history carries cases + players",
          newest.get("caseCount") == 1 and newest.get("cases") == ["TEST"]
          and len(newest.get("players", [])) == 2 and newest.get("players", [])[0].get("winner") is True, json.dumps(newest)[:260])

    r = requests.get(BASE + "/api/profile/battles", timeout=15, cookies=sess(b))
    d = r.json() if r.ok else {}
    check("live: player with no battles -> zeros", d.get("totals", {}).get("battles") == 0
          and d.get("last5") == [] and d.get("history") == [], r.text[:140])

    print(f"\n== {len(PASS)} passed, {len(FAIL)} failed ==")
    if FAIL:
        print("FAILED:", *FAIL, sep="\n  - ")
        sys.exit(1)


if __name__ == "__main__":
    main()
