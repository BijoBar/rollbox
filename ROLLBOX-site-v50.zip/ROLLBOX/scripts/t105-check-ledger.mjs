import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const rows = await db.ledger.findMany({ where: { playerId: "p_t72B" }, orderBy: { id: "desc" }, take: 5 });
console.log(JSON.stringify(rows.map(r => ({ kind: r.kind, delta: r.delta, note: r.note })), null, 1));
const lu = await db.ledger.count({ where: { playerId: "p_t72B", kind: "levelup" } });
console.log("levelup rows:", lu);
await db.$disconnect();
