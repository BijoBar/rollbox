#!/usr/bin/env bash
# Task 44 E2E — part 2: ROLLDROP (forced) — solo case opening + battle.
set -u
AB="agent-browser"
D="/home/z/my-project/download"

echo "=== solo: force ROLLDROP on a Farm AK-47 spin ==="
$AB open http://localhost:3000/ >/dev/null 2>&1
sleep 3
$AB eval '(() => { localStorage.setItem("rb-rolldrop-force", "1"); const b0 = JSON.parse(localStorage.getItem("rollbox-store")).state.balance; window.__bal0 = b0; return "balance before: " + b0; })()' 2>&1 | tail -1
$AB eval '(() => { const a = document.querySelector("a[href=\"/case/farm-ak47\"]"); a?.scrollIntoView({block: "center"}); return a ? "card found" : "no card"; })()' 2>&1 | tail -1
sleep 0.5
$AB eval '(() => { const a = document.querySelector("a[href=\"/case/farm-ak47\"]"); a?.click(); return a ? "nav" : "no card"; })()' 2>&1 | tail -1
sleep 2.5
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => /Open Case/i.test(x.textContent) && !x.disabled); if (!b) return "NO OPEN BTN: " + [...document.querySelectorAll("button")].map(x => x.textContent.trim()).filter(t => t && t.length < 30).join("|").slice(0, 200); b.click(); return "spin started"; })()' 2>&1 | tail -1
sleep 9
$AB eval '(() => {
  const dlg = document.querySelector("[role=\"alertdialog\"]");
  const img = dlg?.querySelector("img[src=\"/raredrop.png\"]");
  const st = JSON.parse(localStorage.getItem("rollbox-store")).state;
  const txt = dlg?.textContent ?? "";
  return JSON.stringify({
    overlay: !!dlg,
    art: !!img,
    artLoaded: img ? img.complete && img.naturalWidth > 0 : false,
    title: txt.includes("ROLLDROP"),
    rewardShown: txt.match(/\+₡[0-9,.K M]+/)?.[0] ?? null,
    balanceAfter: st.balance,
    delta: st.balance - (window.__bal0 || 0)
  });
})()' 2>&1 | tail -1
$AB screenshot "$D/task44-rolldrop-solo.png" >/dev/null 2>&1
$AB eval '(() => { const dlg = document.querySelector("[role=\"alertdialog\"]"); dlg?.click(); return dlg ? "dismissed by tap" : "gone"; })()' 2>&1 | tail -1
sleep 0.4
$AB eval 'JSON.stringify({goneAfterTap: !document.querySelector("[role=\"alertdialog\"]")})' 2>&1 | tail -1