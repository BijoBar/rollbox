#!/bin/bash
# Task 182 v2 — CLEAN audio tracer: only LOOPING sources are logged.
# Fixes the v1 bug: originals saved BEFORE wrapping; fresh descriptor objects.
set -u
BASE="http://localhost:3000"

agent-browser close >/dev/null 2>&1 || true
sleep 1

echo "== open /case/test-rolldrop =="
agent-browser open "$BASE/case/test-rolldrop" >/dev/null
sleep 6

echo "== install clean tracer (loop-sources only) =="
agent-browser eval '
(() => {
  if (window.__tracer) return "already";
  window.__log = [];
  window.__alive = new Set();
  window.__samples = [];
  window.__tArm = null;
  const t0ms = () => Math.round(performance.now());

  const BS = AudioBufferSourceNode.prototype;
  const Sched = AudioScheduledSourceNode.prototype;
  const dStart = Object.getOwnPropertyDescriptor(BS, "start") || Object.getOwnPropertyDescriptor(Sched, "start");
  const dStop  = Object.getOwnPropertyDescriptor(BS, "stop")  || Object.getOwnPropertyDescriptor(Sched, "stop");
  // SAVE ORIGINALS FIRST (unbound fns — always call with .apply(this,...))
  const origStart = dStart.value;
  const origStop  = dStop.value;
  const onBS = Object.getOwnPropertyDescriptor(BS, "start") ? BS : Sched;

  const nStart = function(...a) {
    if (window.__tArm !== null && this.loop === true) {
      window.__alive.add(this);
      window.__log.push({ ev: "start", t: t0ms() - window.__tArm, rate: Number(this.playbackRate.value.toFixed(2)) });
    }
    return origStart.apply(this, a);
  };
  const nStop = function(...a) {
    if (window.__alive.has(this)) {
      window.__alive.delete(this);
      window.__log.push({ ev: "stop", t: t0ms() - window.__tArm });
    }
    return origStop.apply(this, a);
  };
  Object.defineProperty(onBS, "start", { value: nStart, writable: true, configurable: true });
  Object.defineProperty(onBS, "stop",  { value: nStop,  writable: true, configurable: true });

  // in-page sampler every 150ms: alive looping sources
  window.__sampler = setInterval(() => {
    if (window.__tArm === null) return;
    window.__samples.push({ t: t0ms() - window.__tArm, n: window.__alive.size });
  }, 150);

  window.__tracer = true;
  return "clean-tracer-installed";
})()
' > /tmp/t182b-install.txt 2>&1
cat /tmp/t182b-install.txt

echo "== arm + click OPEN in-place =="
agent-browser eval 'window.__tArm = Math.round(performance.now()); "armed"' >/dev/null
agent-browser eval '
(() => {
  const btns = Array.from(document.querySelectorAll("button"));
  const b = btns.find((x) => /OPEN\b/i.test(x.textContent || ""));
  if (!b) return "NO-OPEN-BUTTON";
  b.click();
  return "clicked";
})()
' > /tmp/t182b-click.txt 2>&1
cat /tmp/t182b-click.txt

echo "== wait 26s (spin + beat + bonus) =="
sleep 26

echo "== loop events =="
agent-browser eval 'JSON.stringify(window.__log)' > /tmp/t182b-log.json 2>&1
head -c 2500 /tmp/t182b-log.json
echo ""
echo "== alive-loop samples AFTER t=12s (bonus window + tail) =="
agent-browser eval 'JSON.stringify(window.__samples.filter(s=>s.t>12000))' > /tmp/t182b-samples.json 2>&1
head -c 2000 /tmp/t182b-samples.json
echo ""
echo "== page errors? =="
agent-browser errors 2>&1 | head -5
