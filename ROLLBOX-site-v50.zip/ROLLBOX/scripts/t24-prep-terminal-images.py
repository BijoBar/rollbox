#!/usr/bin/env python3
# Task 24 — prepare TERMINAL page assets:
#  1. terminal.png -> public/terminal/terminal.png (verify alpha, trim, downscale)
#  2. dealer jpgs  -> public/terminal/<dealer>.jpg (downscale for web)
#  3. measure the inner SCREEN rect of the tablet (fractions) so the UI can
#     overlay the dealer photo / chat / input exactly on the device screen.

from PIL import Image
import os

UP = "/home/z/my-project/upload"
OUT = "/home/z/my-project/public/terminal"
os.makedirs(OUT, exist_ok=True)

# ---------- 1. terminal.png ----------
im = Image.open(f"{UP}/terminal.png").convert("RGBA")
W, H = im.size
px = im.load()
corners = [(0, 0), (W - 1, 0), (0, H - 1), (W - 1, H - 1)]
print("corner alpha:", [px[x, y][3] for x, y in corners])

# alpha bounding box of the device itself
alpha = im.getchannel("A")
bbox = alpha.getbbox()
print("device bbox:", bbox)

# trim to device, then downscale to 1400px wide
dev = im.crop(bbox)
dw, dh = dev.size
target_w = 1400
if dw > target_w:
    dev = dev.resize((target_w, round(dh * target_w / dw)), Image.LANCZOS)
dev.save(f"{OUT}/terminal.png", optimize=True)
print("saved terminal.png:", dev.size, os.path.getsize(f"{OUT}/terminal.png") // 1024, "KB")

# ---------- 2. measure the inner screen rect ----------
# work on the TRIMMED original-resolution crop for precision
dev_full = im.crop(bbox)
w, h = dev_full.size
rgb = dev_full.convert("RGB")
p = rgb.load()

def dark(x, y):
    r, g, b = p[x, y]
    return r + g + b < 100

cx, cy = w // 2, h // 2

def expand(fixed_lo, fixed_hi, is_row, center):
    # scan outward from center along one axis while pixels are dark
    lo, hi = center, center
    step = 4
    # expand low side
    x = center
    misses = 0
    while x > 0:
        ok = 0
        for t in range(fixed_lo, fixed_hi, max(1, (fixed_hi - fixed_lo) // 24)):
            if is_row:
                if dark(t, x): ok += 1
            else:
                if dark(x, t): ok += 1
        if ok >= 8:
            lo = x; x -= step; misses = 0
        else:
            misses += 1
            if misses > 3: break
            x -= 1
    # expand high side
    x = center
    misses = 0
    while x < (h if is_row else w) - 1:
        ok = 0
        for t in range(fixed_lo, fixed_hi, max(1, (fixed_hi - fixed_lo) // 24)):
            if is_row:
                if dark(t, x): ok += 1
            else:
                if dark(x, t): ok += 1
        if ok >= 8:
            hi = x; x += step; misses = 0
        else:
            misses += 1
            if misses > 3: break
            x += 1
    return lo, hi

# first rough screen bounds: expand rows within the middle third of columns,
# then columns within the middle of the found rows
r_lo, r_hi = expand(w // 3, 2 * w // 3, True, cy)
c_lo, c_hi = expand(r_lo + (r_hi - r_lo) // 4, r_hi - (r_hi - r_lo) // 4, False, cx)

fx0, fy0, fx1, fy1 = c_lo / w, r_lo / h, c_hi / w, r_hi / h
print(f"screen rect fractions on TRIMMED image: x0={fx0:.4f} y0={fy0:.4f} x1={fx1:.4f} y1={fy1:.4f}")
print(f"screen rect fractions on ORIGINAL upload: x0={(bbox[0]+c_lo)/W:.4f} y0={(bbox[1]+r_lo)/H:.4f} x1={(bbox[0]+c_hi)/W:.4f} y1={(bbox[1]+r_hi)/H:.4f}")

# ---------- 3. dealer photos ----------
for f in ["danny.jpg", "viktor.jpg", "mrwolf.jpg", "sasha.jpg", "theboss.jpg"]:
    d = Image.open(f"{UP}/{f}").convert("RGB")
    dw2, dh2 = d.size
    tw = 1280
    if dw2 > tw:
        d = d.resize((tw, round(dh2 * tw / dw2)), Image.LANCZOS)
    d.save(f"{OUT}/{f}", quality=84, optimize=True)
    print("saved", f, d.size, os.path.getsize(f"{OUT}/{f}") // 1024, "KB")
