// ============ Task 27 MIGRATION: bun scripts/apply-unified-prices.ts ============
// Flips the WHOLE site onto the unified price system in one atomic pass:
//
//   1. USD_TO_COINS 10 → 1 in src/lib/wear.ts (the site-wide dollar rate) —
//      USER SPEC "1$ = 1". Every conversion in the codebase flows through
//      this constant, so the flip re-denominates the whole economy.
//   2. public/skins-catalog.json — real steamanalyst (CSFLOAT) prices into
//      p/wp (USD) and the coin values re-derived at the new rate; legacy
//      coin values are ÷10 (the denomination change) where no real price
//      exists yet.
//   3. generated-wear-prices.ts — SKIN_WEAR_PRICES re-valued (real per wear
//      where the table has it, legacy ÷10 otherwise).
//   4. generated-cases.ts / user-cases.ts — SKINS values, case prices and
//      the user's item value pins re-valued the same way.
//   5. terminals.ts — dealer skins (real FT price where known, else ÷10) and
//      the dealers' MIN/MAX (÷10).
//
// IDEMPOTENT: re-runs after further crawl sessions only refresh the real
// values (the ÷10 step is guarded by the rate flip). Every touched file gets
// a .bak-t27 backup the first time this script runs.
//
// PLAYER BALANCES ARE NOT TOUCHED (the data red line). To re-denominate the
// balances too, run scripts/t27-scale-balances.mjs SEPARATELY — it is
// prepared but deliberately NOT part of this pass.

import fs from "fs";
import path from "path";
import { SKINS } from "../src/lib/cases";
import { SKIN_WEAR_PRICES, SKIN_WEAR_AVAIL } from "../src/lib/generated-wear-prices";
import { WEARS, WEAR_BY_ID } from "../src/lib/wear";
import { unifiedUsd } from "../src/lib/server/pricing";

const ROOT = path.join(dirname(), "..");
function dirname(): string {
  return path.dirname(new URL(import.meta.url).pathname);
}

const WEAR_LABEL: Record<string, string> = Object.fromEntries(WEARS.map((w) => [w.id, w.label]));

// ---------------- backup ----------------
const BACKUP_SUFFIX = ".bak-t27";
const backedUp = new Set<string>();
function backup(rel: string): void {
  if (backedUp.has(rel)) return;
  const src = path.join(ROOT, rel);
  const dst = src + BACKUP_SUFFIX;
  if (fs.existsSync(src) && !fs.existsSync(dst)) fs.copyFileSync(src, dst);
  backedUp.add(rel);
}

// ---------------- helpers ----------------
const coins = (usd: number, rate: number): number =>
  Math.max(0.01, Math.round(usd * 100 * rate) / 100);

/** real USD for "name (wear)" — null when the table has no price yet */
const realWear = (name: string, wear: string): number | null =>
  unifiedUsd(`${name} (${WEAR_LABEL[wear] ?? wear})`);

/** real USD for a bare name (agents / vanilla knives) */
const realBare = (name: string): number | null => unifiedUsd(name);

// ---------------- 1. the rate flip (also detects first-run) ----------------
const WEAR_TS = "src/lib/wear.ts";
backup(WEAR_TS);
const wearSrc = fs.readFileSync(path.join(ROOT, WEAR_TS), "utf8");
const rateMatch = wearSrc.match(/export const USD_TO_COINS = (\d+(?:\.\d+)?);/);
if (!rateMatch) {
  console.error("FAIL: USD_TO_COINS not found in src/lib/wear.ts");
  process.exit(1);
}
const firstRun = rateMatch[1] !== "1";
const RATE = 1; // the rate this migration writes
if (firstRun) {
  fs.writeFileSync(
    path.join(ROOT, WEAR_TS),
    wearSrc.replace(/export const USD_TO_COINS = \d+(?:\.\d+)?;/, "export const USD_TO_COINS = " + RATE + ";"),
  );
  console.log("✓ wear.ts: USD_TO_COINS " + rateMatch[1] + " → " + RATE + "  (1$ = 1 coin — the site-wide denomination flip)");
} else {
  console.log("• wear.ts: USD_TO_COINS already 1 — the migration ran before; refreshing real prices only");
}
// note: this process imported the OLD wear.ts values — all coin math below
// uses the LOCAL coins() helper with RATE, never the imported usdToCoins.

// ---------------- shared: catalog by name ----------------
const CATALOG_TS = "public/skins-catalog.json";
interface CatEntry {
  id: string;
  n: string;
  p: number;
  v: number;
  wp?: Record<string, number>;
  wa?: string[];
  cat?: string;
  t?: string;
}
const catalog: CatEntry[] = JSON.parse(fs.readFileSync(path.join(ROOT, CATALOG_TS), "utf8"));
const byName = new Map<string, CatEntry>();
for (const e of catalog) byName.set(e.n.replace(/\s+/g, " ").trim(), e);

/** the site's unified value for a base skin name: the cheapest REAL wear
 *  price when the table has any, else the bare-name real price (agents),
 *  else null (caller falls back to the legacy ÷10). */
function realBaseUsd(name: string): number | null {
  const bare = realBare(name);
  if (bare != null) return bare;
  const entry = byName.get(name.replace(/\s+/g, " ").trim());
  const wears = entry?.wp
    ? entry.wa && entry.wa.length
      ? entry.wa
      : Object.keys(entry.wp)
    : [];
  let best: number | null = null;
  for (const w of wears) {
    const usd = realWear(name, w);
    if (usd != null && (best == null || usd < best)) best = usd;
  }
  return best;
}

// ---------------- 2. the catalog ----------------
{
  backup(CATALOG_TS);
  let realW = 0;
  let realB = 0;
  let scaled = 0;
  for (const e of catalog) {
    if (e.wp) {
      // wear-priced weapon skin: refresh wp with real prices where known
      const wears = e.wa && e.wa.length ? e.wa : Object.keys(e.wp);
      let best: number | null = null;
      for (const w of wears) {
        const usd = realWear(e.n, w);
        if (usd != null) {
          e.wp[w] = usd;
          if (best == null || usd < best) best = usd;
        }
      }
      if (best != null) {
        e.p = Math.round(best * 100) / 100;
        e.v = coins(best, RATE);
        realW++;
      } else if (firstRun) {
        e.v = Math.round((e.v / 10) * 100) / 100;
        scaled++;
      }
    } else {
      const bare = realBare(e.n);
      if (bare != null) {
        e.p = Math.round(bare * 100) / 100;
        e.v = coins(bare, RATE);
        realB++;
      } else if (firstRun) {
        e.v = Math.round((e.v / 10) * 100) / 100;
        scaled++;
      }
    }
  }
  const tmp = path.join(ROOT, CATALOG_TS) + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(catalog));
  fs.renameSync(tmp, path.join(ROOT, CATALOG_TS));
  console.log(`✓ skins-catalog.json: ${catalog.length} entries — real wear prices: ${realW}, real bare: ${realB}, legacy ÷10: ${scaled}`);
}

// ---------------- 3. generated-wear-prices.ts ----------------
{
  const rel = "src/lib/generated-wear-prices.ts";
  backup(rel);
  const lines: string[] = [
    "// ============ GENERATED FILE — do not edit by hand ============",
    "// Per-wear market prices for every case skin (Task 72; re-valued Task 27).",
    "// Source: steamanalyst.com (CSFLOAT) real prices where the unified table",
    "// has them; otherwise the pre-migration market.csgo.com values ÷10 (the",
    "// 1$ = 1 coin denomination). Refresh: bun scripts/apply-unified-prices.ts",
    "// Values are COINS at the site's USD_TO_COINS rate.",
    "",
    "export type GenWearId = \"FN\" | \"MW\" | \"FT\" | \"WW\" | \"BS\";",
    "",
    "export const SKIN_WEAR_PRICES: Record<string, Partial<Record<GenWearId, number>>> = {",
  ];
  let real = 0;
  let scaled = 0;
  const ids = Object.keys(SKIN_WEAR_PRICES).sort();
  ids.forEach((id, idx) => {
    const name = SKINS[id]?.name;
    const src = SKIN_WEAR_PRICES[id];
    const out: Record<string, number> = {};
    for (const [w, legacy] of Object.entries(src)) {
      if (!legacy) continue;
      const usd = name ? realWear(name, w) : null;
      if (usd != null) {
        out[w] = coins(usd, RATE);
        real++;
      } else if (firstRun) {
        out[w] = Math.round((legacy / 10) * 100) / 100;
        scaled++;
      } else {
        out[w] = legacy;
      }
    }
    const comma = idx < ids.length - 1 ? "," : "";
    lines.push(` "${id}": ${JSON.stringify(out)}${comma}`);
  });
  lines.push("};");
  lines.push("");
  lines.push("// Task 72: wears a skin actually comes in (official CS2 DB) — unchanged");
  lines.push("// by the price migration; empty array = no wear picker (vanilla knives).");
  lines.push("export const SKIN_WEAR_AVAIL: Record<string, GenWearId[]> = {");
  const availIds = Object.keys(SKIN_WEAR_AVAIL).sort();
  availIds.forEach((id, idx) => {
    const comma = idx < availIds.length - 1 ? "," : "";
    lines.push(` "${id}": ${JSON.stringify(SKIN_WEAR_AVAIL[id])}${comma}`);
  });
  lines.push("};");
  fs.writeFileSync(path.join(ROOT, rel), lines.join("\n") + "\n");
  console.log(`✓ generated-wear-prices.ts: ${ids.length} skins — real: ${real} wears, legacy ÷10: ${scaled}`);
}

// ---------------- 4. generated-cases.ts ----------------
{
  const rel = "src/lib/generated-cases.ts";
  backup(rel);
  let src = fs.readFileSync(path.join(ROOT, rel), "utf8");
  let real = 0;
  let scaled = 0;
  // skin value lines (one skin per line; lines are indented -> \s* after ^)
  src = src.replace(
    /^(\s*"(?:[a-z0-9-]+)": \{ id: "(?:[a-z0-9-]+)", name: "([^"]+)",[^}]*?value: )(\d+(?:\.\d+)?)(,)/gm,
    (_m, head: string, name: string, val: string, tail: string) => {
      const usd = realBaseUsd(name);
      if (usd != null) {
        real++;
        return head + coins(usd, RATE) + tail;
      }
      if (!firstRun) return _m;
      scaled++;
      return head + Math.round((parseFloat(val) / 10) * 100) / 100 + tail;
    },
  );
  // case prices (the shell's own price — pure denomination)
  if (firstRun) {
    src = src.replace(/^(\s+price: )(\d+(?:\.\d+)?)(,)$/gm, (_m, head: string, val: string, tail: string) => {
      const n = parseFloat(val);
      if (!Number.isFinite(n) || n === 0) return _m;
      return head + Math.round((n / 10) * 100) / 100 + tail;
    });
  }
  fs.writeFileSync(path.join(ROOT, rel), src);
  console.log(`✓ generated-cases.ts: skin values real:${real} ÷10:${scaled}${firstRun ? ", case prices ÷10" : ""}`);
}

// ---------------- 5. user-cases.ts ----------------
{
  const rel = "src/lib/user-cases.ts";
  if (fs.existsSync(path.join(ROOT, rel))) {
    backup(rel);
    let src = fs.readFileSync(path.join(ROOT, rel), "utf8");
    let real = 0;
    let scaled = 0;
    // line-level pass: each USER_SKINS entry is one line ending with value + colors
    src = src.replace(
      /^(\s*"[a-z0-9-]+": \{ id: "[a-z0-9-]+", name: "([^"]+)".*?value: )(\d+(?:\.\d+)?)(, colors:)/gm,
      (_m, head: string, name: string, val: string, tail: string) => {
        const usd = realBaseUsd(name);
        if (usd != null) {
          real++;
          return head + coins(usd, RATE) + tail;
        }
        if (!firstRun) return _m;
        scaled++;
        return head + Math.round((parseFloat(val) / 10) * 100) / 100 + tail;
      },
    );
    // USER_ITEM_VALUES: "skinId|WEAR": N
    src = src.replace(
      /^(\s*"([a-z0-9-]+)\|(FN|MW|FT|WW|BS)": )(\d+(?:\.\d+)?)(,?)$/gm,
      (_m, head: string, skinId: string, wear: string, val: string, tail: string) => {
        const name = SKINS[skinId]?.name ?? skinId;
        const usd = realWear(name, wear);
        if (usd != null) {
          real++;
          return head + coins(usd, RATE) + tail;
        }
        if (!firstRun) return _m;
        scaled++;
        return head + Math.round((parseFloat(val) / 10) * 100) / 100 + tail;
      },
    );
    // USER_CASES: price + item value pins (skinId + wear are on the same line)
    if (firstRun) {
      src = src.replace(/^(\s+price: )(\d+(?:\.\d+)?)(,)$/gm, (_m, head: string, val: string, tail: string) => {
        const n = parseFloat(val);
        if (!Number.isFinite(n) || n === 0) return _m;
        return head + Math.round((n / 10) * 100) / 100 + tail;
      });
    }
    src = src.replace(
      /^(\s*\{ skinId: "([a-z0-9-]+)", weight: [\d.]+, value: )(\d+(?:\.\d+)?)(, wear: "(?:FN|MW|FT|WW|BS)" \},?)$/gm,
      (_m, head: string, skinId: string, val: string, tail: string) => {
        const wear = /wear: "(FN|MW|FT|WW|BS)"/.exec(tail)?.[1] ?? "FT";
        const name = SKINS[skinId]?.name ?? skinId;
        const usd = realWear(name, wear);
        if (usd != null) {
          real++;
          return head + coins(usd, RATE) + tail;
        }
        if (!firstRun) return _m;
        scaled++;
        return head + Math.round((parseFloat(val) / 10) * 100) / 100 + tail;
      },
    );
    fs.writeFileSync(path.join(ROOT, rel), src);
    console.log(`✓ user-cases.ts: real:${real} ÷10:${scaled}`);
  }
}

// ---------------- 6. terminals.ts ----------------
{
  const rel = "src/lib/terminals.ts";
  backup(rel);
  let src = fs.readFileSync(path.join(ROOT, rel), "utf8");
  let real = 0;
  let scaled = 0;
  // skin blocks: "n": "<name>" on its own line, "v": N two lines below —
  // handle each object by matching n and the v inside the same {} block
  src = src.replace(/"n": "([^"]+)",\n(\s*)"v": (\d+(?:\.\d+)?)/g, (_m, name: string, gap: string, val: string) => {
    const usd = realWear(name, "FT");
    if (usd != null) {
      real++;
      return `"n": "${name}",\n${gap}"v": ${coins(usd, RATE)}`;
    }
    if (!firstRun) return _m;
    scaled++;
    return `"n": "${name}",\n${gap}"v": ${Math.round((parseFloat(val) / 10) * 100) / 100}`;
  });
  if (firstRun) {
    // dealer MIN / MAX — the deal ladder re-denominates with the economy
    src = src.replace(/("min": )(\d+)(,)/g, (_m, head: string, val: string, tail: string) => head + Math.max(1, Math.round(parseFloat(val) / 10)) + tail);
    src = src.replace(/("max": )(\d+)(,)/g, (_m, head: string, val: string, tail: string) => head + Math.max(1, Math.round(parseFloat(val) / 10)) + tail);
  }
  fs.writeFileSync(path.join(ROOT, rel), src);
  console.log(`✓ terminals.ts: dealer skins real:${real} ÷10:${scaled}${firstRun ? ", MIN/MAX ÷10" : ""}`);
}

console.log("\nDONE — the unified price system is applied.");
console.log("NOT touched: player balances and inventory rows (the data red line).");
console.log("Optional: bun scripts/t27-scale-balances.mjs — divide balances by 10 (denomination), ONLY on the owner's say-so.");
console.log("Next: bun scripts/build-drop-editor.ts — rebuild the DROP EDITOR with the new prices.");
