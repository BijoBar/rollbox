#!/usr/bin/env bash
# Task 42 E2E round 2 — the three flows round 1 mismeasured:
# (a) opening-order sort with MIXED prices, (b) SHARED battle full audit,
# (c) FAST MODE on a real case page.
set -u
AB="agent-browser"
D="/home/z/my-project/download"
chk() { $AB eval "$1" 2>/dev/null | tail -1; }
esc() { $AB eval 'document.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true})); "esc"' >/dev/null 2>&1; sleep 0.7; }

echo "=== A) sort with mixed prices ==="
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 3
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.getAttribute("aria-label") === "Add a case to the battle"); b?.click(); return b ? "picker" : "NOT FOUND"; })()' 2>/dev/null | tail -1
sleep 1.2
# pick a cheap case (price-asc sort is default in the picker) = first tile, then search an expensive one
$AB eval '(() => { const tiles = [...document.querySelectorAll("[role=\"dialog\"] button")].filter(x => x.querySelector("img")); tiles[0]?.click(); return "cheap added"; })()' >/dev/null 2>&1
$AB eval '(() => { const i = document.querySelector("[role=\"dialog\"] input[placeholder^=\"Search\"]"); const s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set; s.call(i, "Revolution"); i.dispatchEvent(new Event("input", {bubbles: true})); return "typed"; })()' >/dev/null 2>&1
sleep 1.2
$AB eval '(() => { const tiles = [...document.querySelectorAll("[role=\"dialog\"] button")].filter(x => x.querySelector("img")); tiles[0]?.click(); return tiles[0]?.textContent ?? "none"; })()' 2>/dev/null | tail -1
esc
echo "order before sort: $(chk '(() => { const groups = [...document.querySelectorAll("main .grid > div.relative")]; return JSON.stringify(groups.map(g => g.querySelector("p.text-center, p:not(.text-center)")?.textContent)); })()')"
$AB eval '(() => { const trg = document.querySelector("[aria-label=\"Opening order of the battle cases\"]"); trg?.dispatchEvent(new PointerEvent("pointerdown", {bubbles: true})); trg?.click(); return "select open"; })()' >/dev/null 2>&1
sleep 0.8
$AB eval '(() => { const opt = [...document.querySelectorAll("[role=\"option\"]")].find(o => o.textContent.includes("cheap")); opt?.click(); return opt ? "asc" : "NO OPTION"; })()' 2>/dev/null | tail -1
sleep 0.8
echo "order after asc: $(chk '(() => { const groups = [...document.querySelectorAll("main .grid > div.relative")]; return JSON.stringify(groups.map(g => g.querySelectorAll("p")[0]?.textContent + "@" + (g.querySelectorAll("p")[1]?.textContent ?? ""))); })()')"
$AB eval '(() => { const trg = document.querySelector("[aria-label=\"Opening order of the battle cases\"]"); trg?.dispatchEvent(new PointerEvent("pointerdown", {bubbles: true})); trg?.click(); return "select open"; })()' >/dev/null 2>&1
sleep 0.8
$AB eval '(() => { const opt = [...document.querySelectorAll("[role=\"option\"]")].find(o => o.textContent.includes("expensive") && o.textContent.includes("→")); opt?.click(); return opt ? "desc" : "NO OPTION"; })()' 2>/dev/null | tail -1
sleep 0.8
echo "order after desc: $(chk '(() => { const groups = [...document.querySelectorAll("main .grid > div.relative")]; return JSON.stringify(groups.map(g => g.querySelectorAll("p")[0]?.textContent + "@" + (g.querySelectorAll("p")[1]?.textContent ?? ""))); })()')"

echo "=== B) SHARED battle — full audit ==="
BAL0=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "balance before: $BAL0"
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim() === "SHARED"); b?.click(); return b ? "shared" : "NOT FOUND"; })()' 2>/dev/null | tail -1
sleep 0.4
echo "banner: $(chk '(() => { const t = document.body.innerText.toUpperCase(); return JSON.stringify({split: t.includes("THE POT SPLITS EQUALLY")}); })()')"
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Create Battle")); b?.click(); return "created"; })()' >/dev/null 2>&1
sleep 3
URL=$($AB eval 'location.pathname' 2>/dev/null | tail -1)
echo "url: $URL"
echo "badge: $(chk 'document.body.innerText.toUpperCase().includes("SHARED — EQUAL SPLIT")')"
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Call Bots")); b?.click(); return "called"; })()' >/dev/null 2>&1
FIN=0
for i in $(seq 1 45); do
  sleep 1
  FIN=$(chk 'document.body.innerText.toUpperCase().includes("POT SPLIT")' | rg -o true | head -1)
  [ "$FIN" = "true" ] && { echo "POT SPLIT at ${i}s"; break; }
done
BAL1=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "balance after: $BAL1 (before $BAL0)"
echo "audit: $(chk '(() => {
  const h = JSON.parse(localStorage.getItem("rollbox-store")).state.battleHistory[0];
  if (!h) return "no history";
  const drops = (h.results ?? []).reduce((s, r) => s + r.total, 0);
  const share = Math.floor(drops / h.players.length);
  const me = h.players.find(p => p.isYou);
  const iWon = h.winnerIds?.includes(me?.id ?? "");
  return JSON.stringify({rule: h.potRule, drops, players: h.players.length, share, iWon, delta: "balance moved "});
})()')"
$AB screenshot "$D/task42-shared-done2.png" >/dev/null 2>&1

echo "=== C) FAST MODE real run ==="
$AB open http://localhost:3000/cases >/dev/null 2>&1
sleep 2.5
HREF=$(chk '(() => { const a = [...document.querySelectorAll("a[href*=\"/case/\"]")][0]; return a ? a.getAttribute("href") : "none"; })()')
echo "case href: $HREF"
$AB open "http://localhost:3000$HREF" >/dev/null 2>&1
sleep 3
echo "fast label: $(chk '(() => { const lbl = [...document.querySelectorAll("label")].find(x => x.textContent.includes("Fast mode")); return JSON.stringify(lbl?.textContent ?? null); })()')"
$AB eval '(() => { const lbl = [...document.querySelectorAll("label")].find(x => x.textContent.includes("Fast mode")); const i = lbl?.querySelector("input"); if (i && !i.checked) i.click(); return "fast on"; })()' >/dev/null 2>&1
BALC0=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
T0=$(date +%s%3N)
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.toUpperCase().includes("OPEN CASE")); b?.click(); return "clicked"; })()' >/dev/null 2>&1
SPIN=0; REV=0
for i in $(seq 1 80); do
  sleep 0.25
  if [ "$SPIN" = "0" ]; then SPIN=$(chk 'document.body.innerText.toUpperCase().includes("SPINNING")' | rg -o true | head -1); fi
  REV=$(chk 'document.body.innerText.toUpperCase().includes("OPEN AGAIN")' | rg -o true | head -1)
  [ "$REV" = "true" ] && break
done
T1=$(date +%s%3N)
BALC1=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "spinning seen: ${SPIN:-false}; revealed: ${REV:-false}; total ms: $((T1 - T0))"
echo "balance: $BALC0 -> $BALC1 (win credited instantly as coins)"
$AB screenshot "$D/task42-fast-mode.png" >/dev/null 2>&1
echo "=== done ==="
