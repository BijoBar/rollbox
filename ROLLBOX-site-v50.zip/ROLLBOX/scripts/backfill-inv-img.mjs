// Task 29 — backfill: terminal inventory items used to be snapshotted WITHOUT
// an image ({id,n,w,r,v} only). This one-shot patch adds the missing catalog
// fields (img / p / cat / a) to EXISTING rows — never touching n / w / r / v,
// the row value, or rows whose entryId is not in the catalog (custom skins).
import { createRequire } from "module";
import fs from "fs";
import path from "path";
const require = createRequire(import.meta.url);
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();

const catalog = new Map(
  JSON.parse(fs.readFileSync(path.join(process.cwd(), "public", "skins-catalog.json"), "utf8")).map((e) => [e.id, e]),
);

const rows = await db.inventoryItem.findMany();
let patched = 0;
let skippedCatalogMiss = 0;
for (const row of rows) {
  let data;
  try {
    data = JSON.parse(row.data);
  } catch {
    continue;
  }
  if (!data || typeof data !== "object" || data.img) continue; // already has a picture
  const entry = catalog.get(row.entryId);
  if (!entry) {
    skippedCatalogMiss++;
    continue;
  }
  const next = { ...data };
  if (next.img === undefined && entry.img !== undefined) next.img = entry.img;
  if (next.p === undefined && entry.p !== undefined) next.p = entry.p;
  if (next.cat === undefined && entry.cat !== undefined) next.cat = entry.cat;
  if (next.a === undefined && entry.a !== undefined) next.a = entry.a;
  await db.inventoryItem.update({ where: { id: row.id }, data: { data: JSON.stringify(next) } });
  patched++;
  console.log(`patched ${row.id} (${next.n}) img=${next.img ? "yes" : "null"}`);
}
console.log(`done: ${patched} rows patched, ${skippedCatalogMiss} skipped (entry not in catalog), ${rows.length} scanned`);
await db.$disconnect();
