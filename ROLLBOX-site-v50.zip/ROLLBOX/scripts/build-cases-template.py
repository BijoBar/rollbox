# Build ROLLBOX cases fill-template (Excel) from scripts/cases-dump.json
# Sheets: הוראות | סיכום | תיבות | פריטים  — all RTL, live SUMIF/COUNTIF checks.
import sys, os, json

SKILL_DIR = "/home/z/my-project/skills/xlsx"
for sub in [SKILL_DIR, os.path.join(SKILL_DIR, "templates")]:
    if sub not in sys.path:
        sys.path.insert(0, sub)

import base
base.use_palette_explicit("bloomberg")   # deep-space terminal look, fits CS2 vibe
base.FONT_NAME = "Calibri"               # Hebrew-first workbook, opened on Windows
base.HEADER_BOLD = True

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.formatting.rule import FormulaRule

DUMP = json.load(open("/home/z/my-project/scripts/cases-dump.json", encoding="utf-8"))
OUT = "/home/z/my-project/download/ROLLBOX-cases-template.xlsx"

ITEMS_BUFFER = 60
CASES_BUFFER = 20
SUMMARY_BUFFER = 12

A_RIGHT = Alignment(horizontal="right", vertical="center")
A_CENTER = Alignment(horizontal="center", vertical="center")
FMT_INT = "#,##0"

KIND_HEB = {"standard": "רגילה", "farm": "FARM"}


def put(ws, row, col, value, fmt=None, align=None, font=None):
    c = ws.cell(row=row, column=col, value=value)
    if fmt:
        c.number_format = fmt
    if align:
        c.alignment = align
    if font:
        c.font = font
    return c


def sheet_title(ws, text, last_col):
    base.setup_sheet(ws, title=text, last_col=last_col)
    ws["B2"].alignment = A_RIGHT  # RTL sheet → title on the right
    ws.sheet_view.rightToLeft = True


def headers_row(ws, headers, row=4):
    for i, h in enumerate(headers, start=2):
        ws.cell(row=row, column=i, value=h)
    base.style_header_row(ws, row_num=row, col_start=2, col_end=len(headers) + 1)


def caption_note(ws, row, col, text):
    c = ws.cell(row=row, column=col, value=text)
    c.font = base.font_caption()
    c.alignment = A_RIGHT


wb = Workbook()
wb.properties.creator = "Z.ai"

# ============================================================ 1. הוראות
ws = wb.active
ws.title = "הוראות"
ws.sheet_properties.tabColor = base.NEUTRAL_600
sheet_title(ws, "ROLLBOX — תבנית בניית תיבות עם אחוזים", 3)
intro = ("מלאו את הגיליון \u00abפריטים\u00bb — כל שורה היא פריט אחד בתיבה. "
         "בסיום שלחו את הקובץ חזרה אליי בצ'אט ואני אבנה את התיבות באתר.")
put(ws, 3, 2, intro, font=Font(name=base.FONT_NAME, size=10, color=base.ACCENT_WARNING))
ws.row_dimensions[3].height = 18
ws.merge_cells(start_row=3, start_column=2, end_row=3, end_column=3)

instructions = [
    "גיליון \u00abפריטים\u00bb — כל שורה: קוד תיבה (בחירה מהתפריט), שם הפריט, ערך ב-Rollboxcoins ואחוזי צניחה. בעמודה \u00abמזהה פנימי\u00bb לא נוגעים — היא שומרת על הגרפיקה של הפריט המקורי.",
    "האחוזים של כל תיבה צריכים להסתכם ל-100. גיליון \u00abסיכום\u00bb מחשב את זה לבד: סימן ירוק = תקין, סימן אדום = חסר או עודף.",
    "עריכה: אפשר לשנות אחוזים, ערך, שם פריט, שם תיבה ומחיר תיבה — פשוט עורכים את התא. אפשר גם לסנן לפי קוד תיבה עם המסננים שבכותרת.",
    "הוספת פריט: כותבים בשורה ריקה ב-\u00abפריטים\u00bb — בוחרים קוד תיבה מהתפריט, שם, ערך ואחוזים. לא ממלאים \u00abמזהה פנימי\u00bb בשורות חדשות.",
    "מחיקת פריט: מוחקים את השורה כולה (קליק ימני על מספר השורה, מחיקה, לא רק ריקון התאים).",
    "מחיקת תיבה שלמה: מוחקים את כל שורות הפריטים שלה — תיבה בלי פריטים תוסר מהאתר.",
    "תיבה חדשה: מוסיפים שורה בגיליון \u00abתיבות\u00bb עם קוד ייחודי (למשל RB-121), שם, מחיר וסוג — ואז מוסיפים לה פריטים. הקוד הוא המפתח: לא משנים קוד של תיבה קיימת.",
    "סוג תיבה: \u00abרגילה\u00bb מוצגת בחנות הראשית, \u00abFARM\u00bb מוצגת באזור ה-FARM.",
    "עמודת ROLLDROP % ב-\u00abתיבות\u00bb: ריק = ברירת המחדל של האתר (0.095%). תיבת ה-TEST היא דמו זמני עם 70% — אפשר להסיר אותה כמו כל תיבה.",
    "עמודת \u00abהערות\u00bb בפריטים: מקום חופשי לבקשות מיוחדות (למשל \u00abנדירות של classified\u00bb או \u00abאותה גרפיקה כמו X\u00bb) — אני קורא ומבצע.",
    "פריטים חדשים לגמרי: כותבים את השם שיוצג באתר, את הערך והאחוזים — אני אדאג לגרפיקה ולנדירות לפי הערך.",
    "אחרי שהכל ירוק ב-\u00abסיכום\u00bb — שולחים את הקובץ חזרה בצ'אט. זהו!",
]
headers_row(ws, ["#", "הוראה"])
for i, txt in enumerate(instructions):
    r = 5 + i
    base.style_data_row(ws, row_num=r, col_start=2, col_end=3, row_index=i)
    put(ws, r, 2, i + 1, align=A_CENTER)
    c = put(ws, r, 3, txt, align=A_RIGHT)
    c.alignment = Alignment(horizontal="right", vertical="center", wrap_text=True)
    ws.row_dimensions[r].height = 34
ws.column_dimensions["B"].width = 5
ws.column_dimensions["C"].width = 95
caption_note(ws, 5 + len(instructions) + 1, 2,
             "הקובץ נוצר מהנתונים הקיימים באתר — כל התיבות והאחוזים הנוכחיים כבר מולאו פה, אפשר רק לערוק ולשלוח חזרה.")

# ============================================================ 2. תיבות (metadata)
ws_cases = wb.create_sheet("תיבות")
ws_cases.sheet_properties.tabColor = base.PRIMARY
sheet_title(ws_cases, "התיבות — קוד, שם, מחיר, סוג", 8)
CASE_HEADERS = ["קוד התיבה (לא משנים)", "שם התיבה", "תיאור קצר", "מחיר (Rollboxcoins)", "סוג", "ROLLDROP %", "הערות"]
headers_row(ws_cases, CASE_HEADERS)
n_cases = len(DUMP)
for i, c in enumerate(DUMP):
    r = 5 + i
    base.style_data_row(ws_cases, row_num=r, col_start=2, col_end=8, row_index=i)
    put(ws_cases, r, 2, c["code"], align=A_CENTER)
    put(ws_cases, r, 3, c["name"], align=A_RIGHT)
    put(ws_cases, r, 4, c["subtitle"], align=A_RIGHT)
    put(ws_cases, r, 5, c["price"], fmt=FMT_INT, align=A_RIGHT)
    put(ws_cases, r, 6, KIND_HEB[c["kind"]], align=A_CENTER)
    put(ws_cases, r, 7, c["rolldropChance"] * 100 if c["rolldropChance"] else None, align=A_RIGHT)
    note = "דמו זמני — מחיקת כל שורות הפריטים שלה מסירה אותה מהאתר" if c["code"] == "RB-TST" else None
    put(ws_cases, r, 8, note, align=A_RIGHT)
for i in range(CASES_BUFFER):  # styled empty rows for new cases
    r = 5 + n_cases + i
    base.style_data_row(ws_cases, row_num=r, col_start=2, col_end=8, row_index=n_cases + i)
last_cases_row = 4 + n_cases + CASES_BUFFER

dv_kind = DataValidation(type="list", formula1='"\u05e8\u05d2\u05d9\u05dc\u05d4,FARM"', allow_blank=True)
ws_cases.add_data_validation(dv_kind)
dv_kind.add(f"F5:F{last_cases_row}")
ws_cases.freeze_panes = "A5"
widths = {"B": 14, "C": 22, "D": 40, "E": 16, "F": 9, "G": 13, "H": 42}
for col, w in widths.items():
    ws_cases.column_dimensions[col].width = w

# ============================================================ 3. פריטים (the fill table)
ws_items = wb.create_sheet("פריטים")
ws_items.sheet_properties.tabColor = base.ACCENT_POSITIVE
sheet_title(ws_items, "הפריטים — ערכים ואחוזים (כל שורה: פריט אחד)", 7)
ITEM_HEADERS = ["קוד תיבה", "שם הפריט", "ערך (Rollboxcoins)", "אחוזים (%)", "מזהה פנימי — לא נוגעים", "הערות"]
headers_row(ws_items, ITEM_HEADERS)
rows = []
for c in DUMP:
    for it in c["items"]:
        rows.append((c["code"], it["name"], it["value"], it["weight"], it["skinId"]))
n_items = len(rows)
for i, (code, name, value, weight, skin_id) in enumerate(rows):
    r = 5 + i
    base.style_data_row(ws_items, row_num=r, col_start=2, col_end=7, row_index=i)
    put(ws_items, r, 2, code, align=A_CENTER)
    put(ws_items, r, 3, name, align=A_RIGHT)
    put(ws_items, r, 4, value, fmt=FMT_INT, align=A_RIGHT)
    put(ws_items, r, 5, weight, align=A_RIGHT)
    put(ws_items, r, 6, skin_id, align=A_RIGHT, font=Font(name=base.FONT_NAME, size=9, color=base.NEUTRAL_600))
for i in range(ITEMS_BUFFER):  # styled empty rows ready for new items
    r = 5 + n_items + i
    base.style_data_row(ws_items, row_num=r, col_start=2, col_end=7, row_index=n_items + i)
    ws_items.cell(row=r, column=5).number_format = "General"
last_items_row = 4 + n_items + ITEMS_BUFFER

# dropdown of case codes (named range over תיבות!B)
code_range = f"'תיבות'!$B$5:$B${last_cases_row}"
dn = DefinedName("CaseCodes", attr_text=code_range)
try:
    wb.defined_names.add(dn)                # openpyxl < 3.1
except AttributeError:
    wb.defined_names["CaseCodes"] = dn      # openpyxl >= 3.1
dv_code = DataValidation(type="list", formula1="=CaseCodes", allow_blank=True,
                         errorStyle="warning", showErrorMessage=True,
                         error="עדיף לבחור קוד מהרשימה — קוד שלא קיים בגיליון תיבות לא ייחשב תיבה.",
                         errorTitle="קוד תיבה")
ws_items.add_data_validation(dv_code)
dv_code.add(f"B5:B{last_items_row}")

ws_items.freeze_panes = "A5"
ws_items.auto_filter.ref = f"B4:G{last_items_row}"
widths = {"B": 12, "C": 48, "D": 15, "E": 12, "F": 38, "G": 26}
for col, w in widths.items():
    ws_items.column_dimensions[col].width = w

# ============================================================ 4. סיכום (live checks)
ws_sum = wb.create_sheet("סיכום")
ws_sum.sheet_properties.tabColor = base.ACCENT_WARNING
sheet_title(ws_sum, "סיכום — בדיקת אחוזים לכל תיבה (חי)", 7)
SUM_HEADERS = ["קוד", "שם התיבה", "מחיר", "מספר פריטים", "סך האחוזים", "בדיקה"]
headers_row(ws_sum, SUM_HEADERS)
sum_rows = n_cases + SUMMARY_BUFFER
ITEMS_CODE_RANGE = f"'פריטים'!$B$5:$B${last_items_row}"
ITEMS_PCT_RANGE = f"'פריטים'!$E$5:$E${last_items_row}"
for i in range(sum_rows):
    r = 5 + i
    src = 5 + i  # matching row in תיבות
    base.style_data_row(ws_sum, row_num=r, col_start=2, col_end=7, row_index=i)
    put(ws_sum, r, 2, f"=IF('תיבות'!$B${src}=\"\",\"\",'תיבות'!$B${src})", align=A_CENTER)
    put(ws_sum, r, 3, f"=IF($B{r}=\"\",\"\",'תיבות'!$C${src})", align=A_RIGHT)
    put(ws_sum, r, 4, f"=IF($B{r}=\"\",\"\",'תיבות'!$E${src})", fmt=FMT_INT, align=A_RIGHT)
    put(ws_sum, r, 5, f"=IF($B{r}=\"\",\"\",COUNTIF({ITEMS_CODE_RANGE},$B{r}))", fmt=FMT_INT, align=A_RIGHT)
    put(ws_sum, r, 6, f"=IF($B{r}=\"\",\"\",SUMIF({ITEMS_CODE_RANGE},$B{r},{ITEMS_PCT_RANGE}))", align=A_RIGHT)
    put(ws_sum, r, 7, f"=IF($B{r}=\"\",\"\",IF(ABS($F{r}-100)<0.01,\"\u2713 \u05ea\u05e7\u05d9\u05df\",\"\u2717 \u05dc\u05d0 100\"))", align=A_CENTER)
last_sum_row = 4 + sum_rows

for rule_range, formula, fill, font in [
    (f"G5:G{last_sum_row}", 'NOT(ISERROR(SEARCH("\u2713",$G5)))', base.CF_POSITIVE_FILL, base.CF_POSITIVE_FONT),
    (f"G5:G{last_sum_row}", 'NOT(ISERROR(SEARCH("\u2717",$G5)))', base.CF_NEGATIVE_FILL, base.CF_NEGATIVE_FONT),
    (f"F5:F{last_sum_row}", 'AND($B5<>"",ABS($F5-100)<0.01)', base.CF_POSITIVE_FILL, base.CF_POSITIVE_FONT),
    (f"F5:F{last_sum_row}", 'AND($B5<>"",ABS($F5-100)>=0.01)', base.CF_NEGATIVE_FILL, base.CF_NEGATIVE_FONT),
]:
    ws_sum.conditional_formatting.add(rule_range, FormulaRule(formula=[formula], fill=fill, font=font))

ws_sum.freeze_panes = "A5"
widths = {"B": 12, "C": 24, "D": 12, "E": 13, "F": 14, "G": 12}
for col, w in widths.items():
    ws_sum.column_dimensions[col].width = w
caption_note(ws_sum, last_sum_row + 2, 2,
             "הסיכום מחושב אוטומטית מהגיליונות תיבות ופריטים — אין צורך לערוך כאן כלום. סימן אדום = האחוזים של אותה תיבה לא מסתכמים ל-100.")

wb.save(OUT)
print("saved", OUT)
print("cases:", n_cases, "| item rows:", n_items, "| items sheet last row:", last_items_row)
