// Task 32: add the Player.missions column (mission progress lives in the DB).
// Deterministic single ALTER — prisma db push is avoided on purpose so the
// tool can never propose anything beyond this one additive change.
import { Database } from "bun:sqlite";

const db = new Database("/home/z/my-project/db/custom.db");

const cols = db.prepare(`PRAGMA table_info("Player")`).all().map((c) => c.name);
if (cols.includes("missions")) {
  console.log("• Player.missions already exists — nothing to do");
} else {
  db.exec(`ALTER TABLE "Player" ADD COLUMN "missions" TEXT;`);
  console.log("✓ Player.missions TEXT added");
}

// sanity: player count untouched
const n = db.prepare(`SELECT COUNT(*) AS n FROM "Player"`).get();
console.log(`players in DB: ${n.n}`);
const after = db.prepare(`PRAGMA table_info("Player")`).all().map((c) => c.name);
console.log("columns now:", after.join(", "));
db.close();
