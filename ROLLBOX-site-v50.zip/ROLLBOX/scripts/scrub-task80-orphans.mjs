// Task 80 cleanup stage 2: purge orphan rows left by QA runs —
// battles hosted by players that no longer exist, ledger/drop rows whose
// player is gone, and bot Seat players created by "Call Bots" E2E runs.
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const players = await db.player.findMany({ select: { id: true } });
const ids = new Set(players.map((p) => p.id));

const battles = await db.battle.findMany({ select: { id: true, hostId: true, seats: true } });
const orphanB = battles.filter((b) => !ids.has(b.hostId));
for (const b of orphanB) await db.battle.delete({ where: { id: b.id } });

const ledger = await db.ledger.findMany({ select: { id: true, playerId: true } });
const orphanL = ledger.filter((l) => !l.playerId || !ids.has(l.playerId));
for (const l of orphanL) await db.ledger.delete({ where: { id: l.id } });

const drops = await db.drop.findMany({ select: { id: true, playerId: true } });
const orphanD = drops.filter((d) => d.playerId && !ids.has(d.playerId));
for (const d of orphanD) await db.drop.delete({ where: { id: d.id } });

console.log(
  `orphan battles removed: ${orphanB.length} | ledger: ${orphanL.length} | drops: ${orphanD.length}`
);
const counts = `${await db.player.count()}p/${await db.battle.count()}b/${await db.ledger.count()}l`;
console.log("DB now: " + counts);
await db.$disconnect();
