// Task 77 cleanup: remove the FormatQA player + all its rows (factory-clean DB).
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const p = await db.player.findUnique({ where: { providerId: "76561198000000077" } });
if (p) {
  await db.ledger.deleteMany({ where: { playerId: p.id } });
  await db.drop.deleteMany({ where: { playerId: p.id } });
  await db.inventoryItem.deleteMany({ where: { playerId: p.id } });
  await db.player.delete({ where: { id: p.id } });
  console.log("scrubbed QA player " + p.id);
}
const counts = `${await db.player.count()}p/${await db.battle.count()}b/${await db.ledger.count()}l`;
console.log("DB now: " + counts);
await db.$disconnect();
