#!/usr/bin/env bash
# Task 106 v2 — fixed click regex + arm-after-click probe
# ROUND A = x5 (P(no-rd)~0.24%), ROUNDS B,C = x1 singles
set -u
cd /home/z/my-project
AB="agent-browser"

arm_probe() {
  $AB eval "(() => {
    window.__pr = { s: [], done: false, t0: performance.now() };
    const iv = setInterval(() => {
      const sec = document.querySelector('section[aria-label*=\"unboxing\"]');
      const ps = [...document.querySelectorAll('p')];
      const again = [...document.querySelectorAll('button')].some(b => /open again/i.test(b.textContent || ''));
      const spin = ps.some(p => /SPINNING/i.test(p.textContent || ''));
      const tw = ps.some(p => /^total won\$/i.test((p.textContent || '').trim()));
      const wd = sec ? sec.querySelectorAll('p[style*=\"rgb(57, 255, 20)\"]').length : 0;
      const rd = sec ? sec.querySelectorAll('[aria-label=\"ROLLDROP\"]').length : 0;
      const t = Math.round(performance.now() - window.__pr.t0);
      window.__pr.s.push([t, spin ? 1 : 0, again ? 1 : 0, tw ? 1 : 0, wd, rd]);
      if (tw || t > 40000) { clearInterval(iv); window.__pr.done = true; }
    }, 60);
    return 'armed';
  })()"
}

dump_probe() { $AB eval "JSON.stringify(window.__pr)"; }

click_btn() {
  $AB eval "(() => { const b = [...document.querySelectorAll('button')].find(x => $1.test((x.textContent||'').trim())); if (b) { b.click(); return 'clicked:' + (b.textContent||'').trim(); } return 'NOT_FOUND'; })()"
}

wait_done() { # $1 = iterations
  for i in $(seq 1 "${1:-50}"); do
    D=$($AB eval "window.__pr && window.__pr.done ? 'yes' : 'no'" 2>/dev/null)
    [ "$D" = "yes" ] && return 0
    sleep 1
  done
  return 1
}

echo "=== open test-rolldrop ==="
$AB open http://localhost:3000/case/test-rolldrop >/dev/null
$AB wait --load networkidle >/dev/null 2>&1
sleep 1.5

echo "=== ROUND A: x5 (expect rd) ==="
click_btn "/^x5\$/" | head -1
sleep 0.4
click_btn "/^Open (Case|x[0-9])/" | head -1
sleep 0.5          # phase is now opening/filling — previous round's TOTAL gone
arm_probe
sleep 12           # mid-bonus window (main ~10.3s + bonus running)
$AB screenshot /home/z/my-project/scripts/t106-mid-bonus-x5.png >/dev/null 2>&1
wait_done 40
sleep 0.5
echo "PROBE_A=$(dump_probe)"

for r in B C; do
  echo "=== ROUND $r: x1 ==="
  click_btn "/^x1\$/" | head -1
  sleep 0.4
  click_btn "/^Open (Case|x[0-9]|Again)/" | head -1
  sleep 0.5
  arm_probe
  wait_done 40
  sleep 0.5
  echo "PROBE_$r=$(dump_probe)"
done

echo "=== page errors ==="
$AB errors 2>/dev/null | head -8
echo "DONE"
