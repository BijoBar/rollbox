// Task 36 — verify the new bot rules in makeBotBattle:
// 1) bots never open 2v2; 2) max 3 waiting bots; 3) always ≥1 free seat
// (a battle never starts bot-vs-bot — it needs a real player).
import { makeBotBattle, emptySeats } from "../src/lib/battles";

let twoVtwo = 0;
let tooManyBots = 0;
let noFreeSeat = 0;
const types = new Set<string>();

for (let i = 0; i < 4000; i++) {
  const b = makeBotBattle();
  types.add(b.type);
  if (b.type === "2v2") twoVtwo++;
  const bots = b.players.filter((p) => p.isBot).length;
  if (bots > 3) tooManyBots++;
  if (emptySeats(b) <= 0) noFreeSeat++;
}

console.log(`types seen: ${[...types].sort().join(", ")}`);
console.log(`2v2 created: ${twoVtwo} (expected 0)`);
console.log(`battles with >3 bots: ${tooManyBots} (expected 0)`);
console.log(`battles with no free seat: ${noFreeSeat} (expected 0)`);
if (twoVtwo === 0 && tooManyBots === 0 && noFreeSeat === 0 && !types.has("2v2")) {
  console.log("BOT RULES: ALL OK");
} else {
  console.log("BOT RULES: FAILED");
  process.exit(1);
}
