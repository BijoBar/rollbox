#!/usr/bin/env bash
# Task 42 E2E round 3 — SHARED battle done-phase audit (stay in the room!),
# FAST MODE on the real catalog (/), mixed-price opening-order sort.
set -u
AB="agent-browser"
D="/home/z/my-project/download"
chk() { $AB eval "$1" 2>/dev/null | tail -1; }

BID=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.battles.find(b => b.potRule === "shared")?.id ?? "none"')
echo "shared battle id: $BID"

echo "=== B2) SHARED battle — stay in the room ==="
BAL0=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "balance before: $BAL0"
$AB open "http://localhost:3000/battles/$BID" >/dev/null 2>&1
sleep 3
FIN=""
for i in $(seq 1 60); do
  sleep 1
  FIN=$(chk 'document.body.innerText.includes("POT SPLIT!")' | rg -o true | head -1)
  [ "$FIN" = "true" ] && { echo "POT SPLIT! at ${i}s"; break; }
done
if [ "$FIN" != "true" ]; then echo "NO SPLIT — verdict area: $(chk '(() => { const m = document.body.innerText.toUpperCase().match(/(VICTORY|LOST|POT|SPLIT)[^\\n]*/g); return JSON.stringify((m ?? []).slice(0, 6)); })()')"; fi
BAL1=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "balance after: $BAL1"
echo "audit: $(chk '(() => {
  const h = JSON.parse(localStorage.getItem("rollbox-store")).state.battleHistory[0];
  if (!h) return "no history";
  const drops = (h.results ?? []).reduce((s, r) => s + r.total, 0);
  const me = h.players.find(p => p.isYou);
  const myShare = Math.floor(drops / h.players.length) + ((drops % h.players.length > 0) ? 1 : 0);
  return JSON.stringify({rule: h.potRule, drops, players: h.players.length, winners: h.winnerIds?.length, myShare, expectDelta: myShare});
})()')"
echo "verdict: $(chk '(() => { const t = document.body.innerText; const m = t.match(/POT SPLIT!\\s*₡[\\d.,KM]+/); return JSON.stringify(m?.[0] ?? null); })()')"
$AB screenshot "$D/task42-shared-done.png" >/dev/null 2>&1

echo "=== C2) FAST MODE real run (catalog at /) ==="
$AB open http://localhost:3000/ >/dev/null 2>&1
sleep 3
HREF=$(chk '(() => { const a = [...document.querySelectorAll("a[href*=\"/case/\"]")][0]; return a ? a.getAttribute("href") : "none"; })()')
echo "case href: $HREF"
$AB open "http://localhost:3000$HREF" >/dev/null 2>&1
sleep 3
echo "fast label: $(chk '(() => { const lbl = [...document.querySelectorAll("label")].find(x => x.textContent.includes("Fast mode")); return JSON.stringify(lbl?.textContent ?? null); })()')"
$AB eval '(() => { const lbl = [...document.querySelectorAll("label")].find(x => x.textContent.includes("Fast mode")); const i = lbl?.querySelector("input"); if (i && !i.checked) i.click(); return "fast on"; })()' >/dev/null 2>&1
BALC0=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
T0=$(date +%s%3N)
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.toUpperCase().includes("OPEN CASE")); b?.click(); return "clicked"; })()' >/dev/null 2>&1
SPIN=0; REV=""
for i in $(seq 1 80); do
  sleep 0.25
  if [ "$SPIN" = "0" ]; then SPIN=$(chk 'document.body.innerText.toUpperCase().includes("SPINNING")' | rg -o true | head -1); fi
  REV=$(chk 'document.body.innerText.toUpperCase().includes("OPEN AGAIN")' | rg -o true | head -1)
  [ "$REV" = "true" ] && break
done
T1=$(date +%s%3N)
BALC1=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "spinning seen: ${SPIN:-false}; revealed: ${REV:-false}; total ms: $((T1 - T0))"
echo "balance: $BALC0 -> $BALC1"
$AB screenshot "$D/task42-fast-mode.png" >/dev/null 2>&1

echo "=== A2) mixed-price opening-order sort ==="
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 3
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.getAttribute("aria-label") === "Add a case to the battle"); b?.click(); return "picker"; })()' >/dev/null 2>&1
sleep 1.2
$AB eval '(() => { const tiles = [...document.querySelectorAll("[role=\"dialog\"] button")].filter(x => x.querySelector("img")); tiles[0]?.click(); tiles[tiles.length - 1]?.click(); return "added first + last (picker is price-asc sorted)"; })()' 2>/dev/null | tail -1
esc
$AB eval '(() => { const trg = document.querySelector("[aria-label=\"Opening order of the battle cases\"]"); trg?.dispatchEvent(new PointerEvent("pointerdown", {bubbles: true})); trg?.click(); return "open"; })()' >/dev/null 2>&1
sleep 0.8
$AB eval '(() => { const opt = [...document.querySelectorAll("[role=\"option\"]")].find(o => o.textContent.includes("cheap")); opt?.click(); return "asc"; })()' >/dev/null 2>&1
sleep 0.8
echo "asc:  $(chk '(() => { const gs = [...document.querySelectorAll("main .grid > div.relative")]; return JSON.stringify(gs.map(g => (g.querySelectorAll("p")[1]?.textContent ?? ""))); })()')"
$AB eval '(() => { const trg = document.querySelector("[aria-label=\"Opening order of the battle cases\"]"); trg?.dispatchEvent(new PointerEvent("pointerdown", {bubbles: true})); trg?.click(); return "open"; })()' >/dev/null 2>&1
sleep 0.8
$AB eval '(() => { const opt = [...document.querySelectorAll("[role=\"option\"]")].find(o => o.textContent.includes("expensive")); opt?.click(); return "desc"; })()' >/dev/null 2>&1
sleep 0.8
echo "desc: $(chk '(() => { const gs = [...document.querySelectorAll("main .grid > div.relative")]; return JSON.stringify(gs.map(g => (g.querySelectorAll("p")[1]?.textContent ?? ""))); })()')"
$AB screenshot "$D/task42-sort.png" >/dev/null 2>&1
echo "=== done ==="
