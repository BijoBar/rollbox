#!/usr/bin/env bash
# Task 39 E2E — loop battles until we capture (a) the decider reel at the TOP
# of the room and (b) a VICTORY header verdict.
set -u
AB="agent-browser"
TIE_SHOT="/home/z/my-project/download/task39-decider-top.png"
WIN_SHOT="/home/z/my-project/download/task39-victory-header.png"

check() { $AB eval "$1" 2>/dev/null | rg -o "true|false" | head -1; }

for attempt in 1 2 3 4 5 6; do
  echo "=== attempt $attempt ==="
  # recreate the battle from the header buttons (or create via lobby fallback)
  if ! $AB find role button click --name "Recreate battle" >/dev/null 2>&1; then
    echo "no recreate button — abort"; break
  fi
  sleep 1.2
  $AB find role button click --name "Call Bots" >/dev/null 2>&1
  caught_tie=0; caught_win=0
  for i in $(seq 1 30); do
    sleep 0.55
    tie=$(check "document.body.innerText.includes(\"It's a tie\")")
    win=$(check "document.body.innerText.includes('VICTORY!')")
    if [ "$tie" = "true" ] && [ "$caught_tie" = "0" ]; then
      caught_tie=1
      $AB screenshot "$TIE_SHOT" >/dev/null 2>&1
      echo "TIE captured at poll $i"
    fi
    if [ "$win" = "true" ]; then
      caught_win=1
      $AB screenshot "$WIN_SHOT" >/dev/null 2>&1
      echo "WIN captured at poll $i"
      break
    fi
  done
  [ "$caught_tie" = "1" ] && echo "tie-shot OK"
  [ "$caught_win" = "1" ] && echo "win-shot OK"
  if [ "$caught_tie" = "1" ] && [ "$caught_win" = "1" ]; then break; fi
done
echo "=== balance: $($AB eval "JSON.parse(localStorage.getItem('rollbox-store')).state.balance" 2>/dev/null | tail -1)"
