#!/usr/bin/env python3
"""Task 44 — interim placeholder art for public/:
- rollboxlogo.png  (the official logo file did not arrive; clean gold RB badge)
- raredrop.png     (the ROLLDROP rare-drop art; gold crate + star burst)
Both are RGBA on transparent bg, swapped 1:1 the moment the real files land.
"""
from PIL import Image, ImageDraw, ImageFont

GOLD = (240, 185, 11, 255)
GOLD_L = (255, 243, 196, 255)
GOLD_D = (146, 64, 14, 255)
VIOLET = (192, 38, 211, 255)
FUCHSIA = (232, 121, 249, 255)
FONT_B = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

# ---------- rollboxlogo.png (512) ----------
S = 512
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
# rounded violet->fuchsia gradient badge
badge = Image.new("RGBA", (S, S), (0, 0, 0, 0))
bd = ImageDraw.Draw(badge)
for y in range(S):
    t = y / S
    c = tuple(int(VIOLET[i] + (FUCHSIA[i] - VIOLET[i]) * t) for i in range(3)) + (255,)
    bd.line([(0, y), (S, y)], fill=c)
mask = Image.new("L", (S, S), 0)
md = ImageDraw.Draw(mask)
md.rounded_rectangle([16, 16, S - 16, S - 16], radius=110, fill=255)
img.paste(badge, (0, 0), mask)
# gold "RB"
f = ImageFont.truetype(FONT_B, 268)
bb = d.textbbox((0, 0), "RB", font=f)
d.text(((S - bb[2] + bb[0]) / 2 - bb[0], (S - bb[3] + bb[1]) / 2 - bb[1] - 10), "RB", font=f, fill=GOLD)
img.save("/home/z/my-project/public/rollboxlogo.png")
print("public/rollboxlogo.png", img.size)

# ---------- raredrop.png (640) ----------
S = 640
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
cx, cy = S // 2, S // 2 + 10
# star burst rays
import math
for i in range(12):
    a = i * math.pi / 6
    L = 300 if i % 2 == 0 else 210
    x2, y2 = cx + L * math.cos(a), cy + L * math.sin(a)
    d.line([(cx, cy), (x2, y2)], fill=GOLD if i % 2 == 0 else (240, 185, 11, 140), width=16 if i % 2 == 0 else 8)
# crate: isometric-ish box
d.polygon([(cx, cy - 150), (cx + 170, cy - 70), (cx, cy + 10), (cx - 170, cy - 70)], fill=GOLD_L)          # top
d.polygon([(cx - 170, cy - 70), (cx, cy + 10), (cx, cy + 210), (cx - 170, cy + 130)], fill=GOLD_D)         # left
d.polygon([(cx + 170, cy - 70), (cx, cy + 10), (cx, cy + 210), (cx + 170, cy + 130)], fill=(217, 119, 6, 255))  # right
d.polygon([(cx, cy - 150), (cx + 170, cy - 70), (cx, cy + 10), (cx - 170, cy - 70)], outline=(255, 255, 255, 200), width=6)
# bolt on the front
d.polygon([(cx + 18, cy + 30), (cx - 30, cy + 120), (cx + 2, cy + 118), (cx - 12, cy + 172), (cx + 52, cy + 92), (cx + 20, cy + 96)], fill=(255, 253, 230, 255))
img.save("/home/z/my-project/public/raredrop.png")
print("public/raredrop.png", img.size)
