(() => {
  // Task 82-fix EDGING probe — TEMPORAL sampler. Injected right after a spin
  // starts; samples every reel strip's translate each frame until `dur` ms.
  // mode: 'solo'  — the single-opener horizontal reel (axis x)
  //       'cols'  — every vertical multi-open column   (axis y)
  //       'battle'— every seat square's battle reel    (axis y)
  // Produces window.__t82traces = [{ item, gap, samples: [{t, v}] }] keyed by
  // strip element identity (battle reels remount per round -> one trace per
  // round; the solo strip persists -> one trace holding every round).
  const cfg = window.__t82cfg || {};
  const mode = cfg.mode || 'solo';
  const dur = cfg.dur || 11500;
  const axis = mode === 'solo' ? 'x' : 'y';

  const M = (el) => {
    const tr = getComputedStyle(el).transform;
    return new DOMMatrixReadOnly(tr === 'none' ? 'matrix(1,0,0,1,0,0)' : tr);
  };
  const getReels = () => {
    if (mode === 'solo') {
      const wrap = [...document.querySelectorAll('div.relative.overflow-hidden.rounded-2xl')][0];
      const strip = wrap && wrap.querySelector('.absolute.flex.will-change-transform');
      return strip ? [strip] : [];
    }
    if (mode === 'cols') {
      return [...document.querySelectorAll('.absolute.flex.will-change-transform')].filter(
        (s) => (s.className || '').includes('flex-col')
      );
    }
    // battle: strips inside the seat squares (square-ish reel boxes)
    const wraps = [...document.querySelectorAll('div.relative.overflow-hidden')].filter((w) => {
      const r = w.getBoundingClientRect();
      return r.height > 120 && Math.abs(r.width - r.height) < 30;
    });
    return wraps
      .map((w) => w.querySelector('.absolute.inset-x-0.top-0.flex.flex-col'))
      .filter(Boolean);
  };

  const traces = [];
  const byEl = new Map();
  const t0 = performance.now();
  function step(t) {
    for (const el of getReels()) {
      let tr = byEl.get(el);
      if (!tr) {
        tr = { el, item: 0, gap: 0, samples: [] };
        byEl.set(el, tr);
        traces.push(tr);
      }
      const c0 = el.children[0] && el.children[0].getBoundingClientRect();
      const c1 = el.children[1] && el.children[1].getBoundingClientRect();
      if (c0 && c1) {
        tr.item = Math.max(1, Math.round(axis === 'x' ? c0.width : c0.height));
        tr.gap = Math.max(0, Math.round(axis === 'x' ? c1.left - c0.right : c1.top - c0.bottom));
      }
      const m = M(el);
      tr.samples.push({ t: Math.round(t - t0), v: +(axis === 'x' ? m.m41 : m.m42).toFixed(2) });
    }
    if (t - t0 < dur) requestAnimationFrame(step);
    else {
      for (const tr of traces) delete tr.el; // not serializable
      window.__t82traces = traces;
      window.__t82done = true;
    }
  }
  window.__t82traces = null;
  window.__t82done = false;
  requestAnimationFrame(step);
  return JSON.stringify({ ok: true, mode, axis, dur });
})()
