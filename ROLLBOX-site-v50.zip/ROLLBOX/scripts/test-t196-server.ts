// Task 196 server verification — runs against a TEMP COPY of the DB.
// The real db/custom.db is NEVER touched: we copy it first and point
// DATABASE_URL at the copy BEFORE any project import (db.ts passes
// absolute file: URLs through untouched).
import fs from "fs";

const SRC = "/home/z/my-project/db/custom.db";
const DST = "/home/z/my-project/scripts/.tmp-t196.db";

for (const f of [DST, `${DST}-wal`, `${DST}-shm`]) {
  if (fs.existsSync(f)) fs.rmSync(f);
}
fs.copyFileSync(SRC, DST);
process.env.DATABASE_URL = `file:${DST}`;

type Check = { name: string; pass: boolean; detail: string };
const checks: Check[] = [];
const expect = (name: string, pass: boolean, detail: string) => {
  checks.push({ name, pass, detail });
  console.log(`${pass ? "PASS" : "FAIL"} — ${name} :: ${detail}`);
};

const { db } = await import("@/lib/db");
const gb = await import("@/lib/server/gbattles");
const { CASES } = await import("@/lib/cases");
const { db: prisma } = await import("@/lib/db");

const cs = CASES.find((c) => c.price > 0 && c.kind !== "level" && c.kind !== "event");
if (!cs) throw new Error("no pickable case in the static catalog");

const players = await db.player.findMany({ take: 9, orderBy: { createdAt: "asc" as const } });
if (players.length < 9) throw new Error(`expected 9 players, got ${players.length}`);
expect("player count is 9", players.length === 9, `${players.length} players`);
for (const p of players) {
  await db.player.update({ where: { id: p.id }, data: { balance: 1_000_000 } });
}
const [P0, P1, P2, P3, P4, P5, P6, P7, P8] = players;

// ---- Test 1: PLAY WITH BOTS ON → the created room fills + starts at once
const t1 = await gb.createBattle(P0, {
  type: "1v1", mode: "standard", potRule: "winner", rounds: [cs.id], bots: true,
});
expect("T1 create(bots:true) ok", t1.ok === true, JSON.stringify(t1).slice(0, 120));
if (t1.ok) {
  const row = await gb.loadBattle(t1.id);
  const seats = JSON.parse(row?.seats ?? "[]") as { key: string; isBot: boolean }[];
  expect("T1 room is PLAYING immediately", row?.status === "playing", `status=${row?.status}`);
  expect("T1 room is FULL (2/2)", seats.length === 2, `seats=${seats.length}`);
  expect("T1 second seat is a bot", seats[1]?.isBot === true, `seat1=${seats[1]?.name}/${seats[1]?.isBot}`);
}

// ---- Test 2: bots OFF → the normal waiting flow is untouched
const t2 = await gb.createBattle(P1, {
  type: "1v1", mode: "standard", potRule: "winner", rounds: [cs.id], bots: false,
});
if (t2.ok) {
  let row = await gb.loadBattle(t2.id);
  expect("T2 room waits (bots off)", row?.status === "waiting", `status=${row?.status}`);
  const joined = await gb.joinBattle(row!, P2);
  expect("T2 join ok", joined.ok === true, JSON.stringify(joined).slice(0, 100));
  row = await gb.loadBattle(t2.id);
  const seats = JSON.parse(row?.seats ?? "[]") as { key: string }[];
  expect("T2 full room auto-started", row?.status === "playing" && seats.length === 2, `status=${row?.status} seats=${seats.length}`);
}

// ---- Test 3: 2v2 + team pick T (1) + bots ON → 4 seats, host on team 1
const t3 = await gb.createBattle(P3, {
  type: "2v2", mode: "standard", potRule: "winner", rounds: [cs.id], bots: true, team: 1,
});
if (t3.ok) {
  const row = await gb.loadBattle(t3.id);
  const seats = JSON.parse(row?.seats ?? "[]") as { key: string; isBot: boolean; team: number }[];
  const host = seats.find((s) => s.key === P3.id);
  expect("T3 2v2 PLAYING with 4 seats", row?.status === "playing" && seats.length === 4, `status=${row?.status} seats=${seats.length}`);
  expect("T3 host sits on picked team T", host?.team === 1, `hostTeam=${host?.team}`);
  expect("T3 three bots filled in", seats.filter((s) => s.isBot).length === 3, `bots=${seats.filter((s) => s.isBot).length}`);
}

// ---- Test 4: LEAVE never kills the room (host included) — 1v1v1 keeps it waiting
const t4 = await gb.createBattle(P4, {
  type: "1v1v1", mode: "standard", potRule: "winner", rounds: [cs.id], bots: false,
});
if (t4.ok) {
  let row = await gb.loadBattle(t4.id);
  const j = await gb.joinBattle(row!, P5);
  expect("T4 joiner seated (2/3, still waiting)", j.ok === true && row?.status === "waiting", `status=${row?.status}`);
  row = await gb.loadBattle(t4.id);

  const hostLeave = await gb.leaveBattle(row!, P4); // HOST leaves
  row = await gb.loadBattle(t4.id);
  const seatsAfterHost = JSON.parse(row?.seats ?? "[]") as { key: string }[];
  expect(
    "T4 HOST leave: room stays WAITING (not cancelled)",
    hostLeave.ok === true && hostLeave.cancelled === false && row?.status === "waiting",
    `ok=${hostLeave.ok} cancelled=${hostLeave.ok ? hostLeave.cancelled : "-"} status=${row?.status}`,
  );
  expect("T4 HOST seat opened, joiner kept", seatsAfterHost.length === 1 && seatsAfterHost[0].key === P5.id, `seats=${JSON.stringify(seatsAfterHost)}`);

  const p5row = await db.player.findUnique({ where: { id: P5.id } });
  expect("T4 joiner NOT refunded by host leave", (p5row?.balance ?? 0) > 900_000, `balance=${p5row?.balance}`);

  const lastLeave = await gb.leaveBattle(row!, P5); // last player leaves → EMPTY room
  row = await gb.loadBattle(t4.id);
  const seatsEmpty = JSON.parse(row?.seats ?? "[]") as { key: string }[];
  expect(
    "T4 empty room stays WAITING in the list",
    lastLeave.ok === true && row?.status === "waiting" && seatsEmpty.length === 0,
    `status=${row?.status} seats=${seatsEmpty.length}`,
  );

  const rejoin = await gb.joinBattle(row!, P6); // anyone can take the empty room
  row = await gb.loadBattle(t4.id);
  const seatsRe = JSON.parse(row?.seats ?? "[]") as { key: string }[];
  expect("T4 a new player JOINED the empty room", rejoin.ok === true && seatsRe[0]?.key === P6.id, `ok=${rejoin.ok} seat0=${seatsRe[0]?.key}`);
}

// ---- Test 5: empty 2v2 room re-joins on team CT side 0 (openSeat([]) default)
const t5 = await gb.createBattle(P7, {
  type: "2v2", mode: "standard", potRule: "winner", rounds: [cs.id], bots: false,
});
if (t5.ok) {
  let row = await gb.loadBattle(t5.id);
  await gb.leaveBattle(row!, P7);
  row = await gb.loadBattle(t5.id);
  const rejoin = await gb.joinBattle(row!, P8);
  row = await gb.loadBattle(t5.id);
  const seats = JSON.parse(row?.seats ?? "[]") as { key: string; team: number; side: number }[];
  expect(
    "T5 empty 2v2 room: leave → wait → rejoin lands CT-left",
    rejoin.ok === true && row?.status === "waiting" && seats[0]?.team === 0 && seats[0]?.side === 0,
    `status=${row?.status} seat0=team${seats[0]?.team}/side${seats[0]?.side}`,
  );
}

// ---- the ORIGINAL db must be untouched (mtime + a spot checksum differ only if buggy)
const origCount = (await (await import("bun:sqlite")).default.open(SRC)).query("SELECT COUNT(*) c FROM Player").get() as { c: number };
expect("original DB untouched: still 9 players", origCount.c === 9, `Player=${origCount.c}`);

console.log(`\n==== ${checks.filter((c) => c.pass).length}/${checks.length} checks passed ====`);
fs.rmSync(DST); // clean the copy (wal/shm die with it)
process.exit(checks.every((c) => c.pass) ? 0 : 1);
