"""Task 47 E2E — GLOBAL multiplayer battles on the ORIGINAL battle system.

  A (host)  /battles/new — the ORIGINAL builder — stacks TEST ×2 and creates
            a GLOBAL room (entry charged only after the server confirms)
  B (guest) /battles lobby → GLOBAL BATTLES section → JOIN → the room fills
            to 2/2 and AUTO-STARTS on the server; both animate the same pulls
  terminal  → server data: totals↔pulls, pot = dropTotal, winner take = pot
            → ledgers: each side −entry, winner +take — EXACT
  API-only  → 1v1v1 + CALL BOTS (3 seats, 2 bots) and 1v1 SHARED split rules
"""
import json
import time
import urllib.request

from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = "/home/z/my-project/download/e2e-shots"


def api(path, payload=None):
    req = urllib.request.Request(
        f"{BASE}{path}",
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={"Content-Type": "application/json"},
        method="POST" if payload is not None else "GET",
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def wait_finished(room_id, timeout=120):
    for _ in range(timeout):
        room = api(f"/api/battles/rooms/{room_id}")["room"]
        if room["status"] == "finished":
            return room
        time.sleep(1)
    raise AssertionError("battle never finished")


def balance(pg):
    return pg.evaluate(
        "() => { const s = JSON.parse(localStorage.getItem('rollbox-store')||'null'); return s && s.state ? s.state.balance : null; }"
    )


failures = []


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f" — {detail}" if detail else ""))
    if not ok:
        failures.append(name)


with sync_playwright() as p:
    b = p.chromium.launch()
    A = b.new_context(viewport={"width": 1440, "height": 900}).new_page()
    B = b.new_context(viewport={"width": 1440, "height": 900}).new_page()

    # ---- A: the ORIGINAL builder creates a GLOBAL room (TEST ×2, 1v1)
    A.goto(f"{BASE}/battles/new", wait_until="domcontentloaded", timeout=90000)
    A.wait_for_selector("text=CREATE", timeout=30000)
    A.wait_for_timeout(700)
    A.locator('button[aria-label="Add a case to the battle"]').click()
    A.wait_for_selector('button[aria-label^="Add TEST,"]', timeout=20000)
    A.locator('button[aria-label^="Add TEST,"]').click()
    A.locator('button[aria-label^="Add TEST,"]').click()
    A.keyboard.press("Escape")
    A.wait_for_timeout(400)
    A.screenshot(path=f"{SHOTS}/47-create-original-builder.png")
    bal_a0 = balance(A)
    A.locator("button:has-text('Create Global Battle')").click()
    A.wait_for_selector("text=Waiting for players", timeout=25000)
    room_id = A.url.split("/battles/")[1].split("?")[0]
    code = A.locator("button[title='Copy the room code']").inner_text().strip().split("\n")[0]
    bal_a1 = balance(A)
    A.screenshot(path=f"{SHOTS}/47a-waiting.png")
    print(f"room {room_id} code {code} | A: {bal_a0} -> {bal_a1}")

    # ---- B: joins from the lobby's GLOBAL section
    B.goto(f"{BASE}/battles", wait_until="domcontentloaded", timeout=90000)
    B.wait_for_selector("text=Global battles", timeout=30000)
    B.wait_for_selector('div[aria-label="Global battles list"]', timeout=20000)
    B.screenshot(path=f"{SHOTS}/47b-lobby.png")
    bal_b0 = balance(B)
    B.locator('div[aria-label="Global battles list"] button:has-text("JOIN")').first.click()
    B.wait_for_url(f"**/battles/{room_id}", timeout=20000)
    bal_b1 = balance(B)
    print(f"B: {bal_b0} -> {bal_b1}")

    # the room auto-started for both
    A.wait_for_selector("text=Rolling", timeout=20000)
    B.wait_for_selector("text=Rolling", timeout=20000)
    time.sleep(1.4)
    A.screenshot(path=f"{SHOTS}/47-rolling-a.png", clip={"x": 100, "y": 60, "width": 1240, "height": 720})
    B.screenshot(path=f"{SHOTS}/47-rolling-b.png", clip={"x": 100, "y": 60, "width": 1240, "height": 720})

    final = wait_finished(room_id)
    entry = final["entry"]
    pot = final["potTotal"] or 0
    totals = {r["playerId"]: r["total"] for r in final["results"]}
    take = final["take"] or {}
    visible_totals = {}
    for r in final["results"]:
        visible_totals[r["playerId"]] = sum(pl["value"] for pl in r["pulls"])
    print("FINAL: pot", pot, "| totals", json.dumps(totals), "| take", json.dumps(take))
    print("rd flags:", [[bool(pl.get("rd")) for pl in r["pulls"]] for r in final["results"]])

    check("totals match the pulls", totals == visible_totals)
    check("pot = dropTotal", pot == sum(totals.values()))
    winners = final["winnerIds"] or []
    check("single winner", len(winners) == 1)
    check("winner take = whole pot (winner rule)", take.get(winners[0]) == pot and len(take) >= 1)
    check("winner is the max total", totals.get(winners[0]) == max(totals.values()))

    # ---- ledgers on both clients
    time.sleep(3.5)
    A.wait_for_selector("text=Finished", timeout=25000)
    B.wait_for_selector("text=Finished", timeout=25000)
    bal_a2, bal_b2 = balance(A), balance(B)
    a_id = A.evaluate("localStorage.getItem('rb-player-id')")
    b_id = B.evaluate("localStorage.getItem('rb-player-id')")
    exp_a = bal_a1 + take.get(a_id, 0)
    exp_b = bal_b1 + take.get(b_id, 0)
    print(f"A final {bal_a2} (expect {exp_a}) | B final {bal_b2} (expect {exp_b})")
    check("entry charged on both", bal_a1 == bal_a0 - entry and bal_b1 == bal_b0 - entry)
    check("payout credited exactly", bal_a2 == exp_a and bal_b2 == exp_b)
    A.screenshot(path=f"{SHOTS}/47a-done.png", clip={"x": 100, "y": 60, "width": 1240, "height": 720})
    B.screenshot(path=f"{SHOTS}/47b-done.png", clip={"x": 100, "y": 60, "width": 1240, "height": 720})

    # ---- API-only: 1v1v1 + CALL BOTS
    host = "e2e-botfill-host"
    made = api("/api/battles/rooms", {"playerId": host, "name": "Host1", "type": "1v1v1", "mode": "standard", "potRule": "winner", "rounds": ["test-rolldrop"]})
    trio = made["room"]["id"]
    filled = api(f"/api/battles/rooms/{trio}/bots", {"playerId": host})["room"]
    bots = [pl for pl in filled["players"] if pl["isBot"]]
    check("bot fill: 3 seats, 2 bots", len(filled["players"]) == 3 and len(bots) == 2)
    trio_final = wait_finished(trio)
    trio_take = trio_final["take"] or {}
    check("1v1v1 pot distributed by winner rule", sum(trio_take.values()) == (trio_final["potTotal"] or 0) and len([v for v in trio_take.values() if v > 0]) == 1)
    print("1v1v1 done: pot", trio_final["potTotal"], "take", json.dumps(trio_take))

    # ---- API-only: 1v1 SHARED split
    shared = api("/api/battles/rooms", {"playerId": "e2e-shared-host", "name": "Host2", "type": "1v1", "mode": "standard", "potRule": "shared", "rounds": ["test-rolldrop"]})["room"]
    shared2 = api(f"/api/battles/rooms/{shared['id']}/join", {"playerId": "e2e-shared-guest", "name": "Guest2"})["room"]
    check("shared auto-started", shared2["status"] in ("playing", "finished"))
    shared_final = wait_finished(shared["id"])
    s_take = shared_final["take"] or {}
    half = (shared_final["potTotal"] or 0) // 2
    check("shared = equal split", abs(s_take.get(shared["hostId"], 0) - s_take.get("e2e-shared-guest", 0)) <= 1 and sum(s_take.values()) == (shared_final["potTotal"] or 0))
    print("shared done: pot", shared_final["potTotal"], "take", json.dumps(s_take), "(expect ~", half, "each)")

    b.close()

print()
print("RESULT:", "PASS" if not failures else f"FAIL ({failures})")
