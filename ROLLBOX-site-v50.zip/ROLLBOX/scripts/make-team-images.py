#!/usr/bin/env python3
"""Build public/teams/ct.webp + t.webp from the downloaded CS2 renders.

- T comes as a transparent PNG (Skinport render) -> crop to alpha bbox.
- CT comes as a JPEG on a flat dark-gray backdrop -> flood-fill from the
  borders (protects dark pixels inside the character), then crop.
Both are resized to a common height and saved as quality WebP with alpha.
"""
from PIL import Image, ImageDraw

OUT_H = 520

def crop_resize(im: Image.Image) -> Image.Image:
    bbox = im.getbbox()
    im = im.crop(bbox)
    w, h = im.size
    nh = OUT_H
    nw = round(w * nh / h)
    return im.resize((nw, nh), Image.LANCZOS)

# ---- T: already transparent ----
t = Image.open("tool-results/cand-378fcc349859.png").convert("RGBA")
t = crop_resize(t)
t.save("public/teams/t.webp", "WEBP", quality=88, method=6)
print("t.webp", t.size)

# ---- CT: key out the studio backdrop via border flood-fill ----
ct = Image.open("tool-results/cand-8f4b027078fb.jpeg").convert("RGB")
MAGIC = (255, 0, 254)
seeds = [(0, 0), (ct.width - 1, 0), (0, ct.height - 1), (ct.width - 1, ct.height - 1),
         (ct.width // 2, 0), (ct.width // 2, ct.height - 1), (0, ct.height // 2), (ct.width - 1, ct.height // 2)]
for s in seeds:
    if ct.getpixel(s) != MAGIC:
        ImageDraw.floodfill(ct, s, MAGIC, thresh=38)
ct = ct.convert("RGBA")
px = ct.load()
n_keyed = 0
for y in range(ct.height):
    for x in range(ct.width):
        r, g, b, a = px[x, y]
        if (r, g, b) == MAGIC:
            px[x, y] = (0, 0, 0, 0)
            n_keyed += 1
print("keyed px:", n_keyed, f"({100 * n_keyed / (ct.width * ct.height):.1f}%)")
ct = crop_resize(ct)
# soften the cutout: 1px alpha erosion-ish via slight blur on alpha only
from PIL import ImageFilter
a = ct.getchannel("A").filter(ImageFilter.GaussianBlur(0.6))
ct.putalpha(a)
ct.save("public/teams/ct.webp", "WEBP", quality=88, method=6)
print("ct.webp", ct.size)
