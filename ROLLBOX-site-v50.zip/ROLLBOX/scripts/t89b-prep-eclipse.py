#!/usr/bin/env python3
"""Task 89b — swap the 5 placeholder glass-DICE rarities PNGs for the user's
FINAL eclipse artworks (crescent moon + lightning, one per rarity) and add the
new GOLD one for contraband.

Pipeline per image: alpha-bbox trim -> union bbox across all 6 (same
composition, keeps identical scale) -> 4% pad -> centered square canvas ->
LANCZOS downscale to 512x512 -> optimized PNG in public/rarity/.
Same filenames as before (rollbox-<rarity>.png) so code paths stay stable;
rollbox-gold.png is new (contraband -> /rarity/rollbox-gold.png).
"""
from PIL import Image
import numpy as np
import os

SRC = {
    "consumer":   "upload/rollboxconsumer.png",
    "milspec":    "upload/rollboxmilspec.png",
    "restricted": "upload/rollboxrestricted.png",
    "classified": "upload/rollboxclassified.png",
    "covert":     "upload/rollboxcovert.png",
    "gold":       "upload/rollboxgold.png",
}
OUT_DIR = "public/rarity"
TH = 8  # alpha threshold: ignores the faint (a<8) glow noise that spans the frame

imgs = {name: Image.open(p).convert("RGBA") for name, p in SRC.items()}

# per-image VISIBLE content bbox (alpha >= TH)
bboxes = {}
for n, im in imgs.items():
    a = np.array(im.getchannel("A"))
    ys, xs = np.where(a >= TH)
    bboxes[n] = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)
for n, b in bboxes.items():
    print(f"{n:11s} bbox={b}")

# The per-image lightning reach differs (gold streaks far left, classified far
# right) but the MOON sits in the same spot in all six (high-alpha centroids
# cluster at ~(1290, 654)). Frame all six identically: fixed center + side so
# the moon is dead-center and the scale matches across rarities.
CX, CY, SIDE = 1290, 654, 1560
l, t, r, btm = CX - SIDE // 2, CY - SIDE // 2, CX + SIDE // 2, CY + SIDE // 2
print(f"fixed square crop box=({l},{t},{r},{btm})  side={SIDE}")

for name, im in imgs.items():
    sq = im.crop((l, t, r, btm)).resize((512, 512), Image.LANCZOS)
    out = os.path.join(OUT_DIR, f"rollbox-{name}.png")
    sq.save(out, optimize=True)
    print(f"wrote {out}  {sq.size}  {os.path.getsize(out)//1024} KB")
