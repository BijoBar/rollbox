"""Task 57 verification — the waiting screen IS the battle screen.

Creates a real 1v1 battle (DB session), then checks:
  1. the room renders the unified columns while WAITING
  2. the empty square says WAITING FOR PLAYER in caps
  3. the filled square carries the future-reel hint
  4. the plate is compact: the picture is 36px (h-9) and the "PLAYER"
     caption under the name is GONE
  5. NO emoji/reaction button while waiting
  6. the seat square's bounding box is PIXEL-IDENTICAL before and after
     the battle starts (the columns never move — measured!)
  7. the reel actually spins inside the SAME square while playing
  8. the fire reaction button returns only when the battle is live
  9. the battle reaches a finished state
"""
import json
import subprocess
import sys
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = Path("/home/z/my-project/download/e2e-shots")
SHOTS.mkdir(parents=True, exist_ok=True)
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS  " if ok else "FAIL  ") + name + ("  — " + detail if detail else ""))

# ---- mint a real session + a battle with a DB avatar ----------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); "
     "await db.player.upsert({where:{providerId:'e2e-avatar'},update:{},create:{id:'p_e2ea',provider:'steam',providerId:'e2e-avatar',name:'E2E Alpha',avatar:'/logo.svg'}}); "
     "await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
out = subprocess.run(["bun", "scripts/mint-session.mjs"], capture_output=True, text=True, cwd="/home/z/my-project").stdout.strip().splitlines()
A = json.loads(out[0])
# give the session player a real avatar so the compact plate shows a picture
subprocess.run(
    ["bun", "-e",
     f"const {{PrismaClient}}=require('@prisma/client'); const db=new PrismaClient(); "
     f"(async()=>{{ await db.player.update({{ where:{{ id:'{A['id']}' }}, data:{{ avatar:'/logo.svg' }} }}); await db.$disconnect(); }})()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1440, "height": 900})
    ctx.add_cookies([{"name": "rb_session", "value": A["token"], "url": BASE}])
    pa = ctx.new_page()

    # create the battle through the API (the builder UI is covered by the E2E)
    r = ctx.request.post(BASE + "/api/gbattles", data={"type": "1v1", "mode": "standard", "potRule": "winner", "rounds": ["test-rolldrop"]})
    ok = r.ok
    bid = r.json().get("id", "") if ok else ""
    check("battle created via API", ok and bool(bid), "id=" + bid)
    if not bid:
        print("RESULT: ABORT")
        sys.exit(1)

    pa.goto(BASE + f"/battles/{bid}", wait_until="domcontentloaded")
    pa.wait_for_timeout(2500)
    body = pa.inner_text("body").upper()

    # 1-3. unified waiting columns (the 1v1 grid is .max-w-md.grid-cols-2)
    COLS = "div.grid.max-w-md.grid-cols-2"
    check("waiting title renders", "WAITING" in body)
    squares = pa.locator(COLS + " > div")
    empty_caps = pa.get_by_text("WAITING FOR PLAYER", exact=True).count()
    check("empty square says WAITING FOR PLAYER (caps)", empty_caps >= 1, f"empty squares={empty_caps}")
    hint = pa.get_by_text("REEL", exact=False).count()
    check("filled square shows the future-reel hint", hint >= 1, f"reel hints={hint}")

    # 4. compact plate: 36px picture, no PLAYER caption
    plate_img = pa.locator(COLS + " img").first
    try:
        box = plate_img.bounding_box(timeout=4000)
        check("plate picture is compact (36px)", box is not None and 30 <= box["height"] <= 42, f"h={box['height'] if box else '?'}")
    except Exception:
        check("plate picture is compact (36px)", False, "no picture found")
    captions = pa.get_by_text("PLAYER", exact=True).count()
    check("no PLAYER caption under the name", captions == 0, f"captions={captions}")

    # 5. no emoji/reaction button while waiting
    fire_waiting = pa.locator("button[aria-label='Open the reactions menu']").count()
    check("no reaction button while waiting", fire_waiting == 0, f"fire buttons={fire_waiting}")

    # 6. measure MY square's bounding box, start the battle, measure again
    square = pa.locator(COLS + " > div").first
    before = square.bounding_box()
    pa.get_by_role("button", name="Call Bots").click(timeout=8000)
    pa.wait_for_timeout(2600)
    after = pa.locator(COLS + " > div").first.bounding_box()
    same = (
        before and after
        and abs(before["x"] - after["x"]) < 1.5
        and abs(before["y"] - after["y"]) < 1.5
        and abs(before["width"] - after["width"]) < 1.5
    )
    check("columns did NOT move at start (pixel-identical square)",
          bool(same),
          f"before=({before['x']:.0f},{before['y']:.0f},{before['width']:.0f}) after=({after['x']:.0f},{after['y']:.0f},{after['width']:.0f})" if before and after else "no box")
    pa.screenshot(path=str(SHOTS / "57-playing-unified.png"))

    # 7. the reel spins inside the square (BattleReel strip is mounted)
    spinning = pa.locator(COLS + " .reel-fade-t").count()
    check("reel spins inside the same square while playing", spinning >= 1, f"reels={spinning}")

    # 8. fire reaction button returns when live
    pa.wait_for_timeout(600)
    fire_live = pa.locator("button[aria-label='Open the reactions menu']").count()
    check("fire button available while live", fire_live >= 1, f"fire buttons={fire_live}")

    # 9. finished
    deadline = time.time() + 60
    fin = False
    while time.time() < deadline:
        st = ctx.request.get(BASE + f"/api/gbattles/{bid}").json().get("battle", {})
        if st.get("status") == "finished":
            fin = True
            break
        time.sleep(1.0)
    check("battle reached a finished state", fin)
    pa.screenshot(path=str(SHOTS / "57-finished.png"))
    browser.close()

print("\n===== VERDICT =====")
fails = [r for r in results if not r[1]]
print("RESULT:", "ALL PASS" if not fails else "%d FAILURES" % len(fails))
sys.exit(0 if not fails else 1)
