// Task 151 — battle provably-fair verification (dev-only).
// Recomputes EVERY pull of a finished battle from its revealed seed and the
// public room code, using the exact shared math, and asserts it matches the
// stored pulls the payouts came from — including the tie-decider nonce 999999.
// Usage: bun scripts/check-battle-fair.ts [battleId?]

import { db } from "../src/lib/db";
import { computePublicHash, pickWeighted, rollFloat } from "../src/lib/provably-fair";
import { rareCaseOf } from "../src/lib/rolldrop";
import { CASES, caseItemValue } from "../src/lib/cases";
import { findCommunityCase } from "../src/lib/server/community-cases";
import type { CaseDef } from "../src/lib/cases";

let failures = 0;
const ok = (cond: boolean, label: string) => {
  console.log(`${cond ? "  PASS" : "  FAIL"}  ${label}`);
  if (!cond) failures++;
};

const argId = process.argv[2];
const battle = argId
  ? await db.battle.findUnique({ where: { id: argId } })
  : await db.battle.findFirst({ where: { status: "finished", fairSeed: { not: null } }, orderBy: { createdAt: "desc" } });

if (!battle) {
  console.error("NO FINISHED FAIR BATTLE FOUND");
  process.exit(1);
}
console.log(`battle ${battle.id} code=${battle.code} status=${battle.status} rounds=${battle.rounds}`);

ok(!!battle.fairSeed && !!battle.fairHash && !!battle.fairSalt, "battle carries its commit-reveal seed");
ok(!!battle.fairRevealedAt, "seed is revealed (battle settled)");
ok(computePublicHash(battle.fairSeed!, battle.fairSalt!) === battle.fairHash, "SHA-256(seed + salt) == the hash published while the room was LIVE");

const rounds = JSON.parse(battle.rounds) as string[];
const seats = JSON.parse(battle.seats) as { key: string; name: string }[];
const pulls = JSON.parse(battle.pulls!) as { playerId: string; total: number; pulls: { round: number; skinId: string; wear?: string; value: number; rd: boolean }[] }[];
ok(pulls.length === seats.length, `pulls exist for all ${seats.length} seats`);

for (let ri = 0; ri < rounds.length; ri++) {
  // USER SPEC (battles × COMMUNITY/EVENT): rounds can reference player-built
  // cc_* cases — resolve them from the DB like the engine does, so EVERY
  // round of every battle stays publicly verifiable.
  const caseDef: CaseDef | undefined =
    CASES.find((c) => c.id === rounds[ri]) ?? (await findCommunityCase(rounds[ri]));
  if (!caseDef) {
    ok(false, `r${ri}: case ${rounds[ri]} resolves`);
    continue;
  }
  const rare = rareCaseOf(caseDef);
  for (let si = 0; si < seats.length; si++) {
    const g = ri * seats.length + si;
    const gate = rollFloat(battle.fairSeed!, battle.code, 2 * g);
    const itemF = rollFloat(battle.fairSeed!, battle.code, 2 * g + 1);
    const stored = pulls.find((p) => p.playerId === seats[si].key)!.pulls.find((p) => p.round === ri)!;
    const rdRepro = gate < (caseDef.rolldropChance ?? 0.00095);
    ok(rdRepro === !!stored.rd, `r${ri}s${si} (${seats[si].name}): ROLLDROP gate reproduces (${stored.rd})`);
    const expected = pickWeighted(stored.rd ? rare.items : caseDef.items, itemF);
    ok(expected.skinId === stored.skinId, `r${ri}s${si}: item reproduces ${stored.skinId} (${expected.skinId})`);
    ok(Math.abs(caseItemValue(expected) - stored.value) < 0.01, `r${ri}s${si}: value reproduces $${stored.value}`);
  }
}

// the tie decider ran in this battle ("DECIDED BY THE DECIDER") — reproduce it
const tieIds = battle.tieIds ? (JSON.parse(battle.tieIds) as string[]) : null;
if (tieIds?.length && battle.winnerIds) {
  const f = rollFloat(battle.fairSeed!, battle.code, 999_999);
  const pick = tieIds[Math.floor(f * tieIds.length) % tieIds.length];
  const expectedWinners =
    pick === "t0" || pick === "t1"
      ? null // team picks need player teams — skip for 1v1 flows
      : [pick];
  console.log(`  decider: float=${f.toFixed(6)} → pick=${pick} (tieIds=${tieIds.join(",")})`);
  if (expectedWinners) {
    const recorded = JSON.parse(battle.winnerIds!) as string[];
    ok(JSON.stringify(expectedWinners) === JSON.stringify(recorded), "tie decider reproduces the recorded winner");
  }
}

console.log(failures === 0 ? "\nBATTLE FAIRNESS VERIFIED ✅" : `\n${failures} BATTLE CHECK(S) FAILED ❌`);
await db.$disconnect();
process.exit(failures === 0 ? 0 : 1);
