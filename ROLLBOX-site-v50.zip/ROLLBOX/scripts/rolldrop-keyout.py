#!/usr/bin/env python3
"""
Task 144: remove the WHITE BACKGROUND from rolldrop.mp4 completely.
Task 146 (USER SPEC): the clip still read as a GOLDEN-FRAMED window on the
reel - the amber halo that used to be baked behind the dice (plus the halo
div the component drew) formed a warm glowing rectangle. So:

  * the amber halo layer is GONE from the bake - the backdrop is now ONLY
    the case reel's own radial gradient (#160f2b -> #0b0716),
  * the component's halo div is removed and .rd-hit-video gets a CSS
    radial MASK that feathers the clip's rectangular boundary away,
  * Task 146 time-compressed the clip to EXACTLY 2.000s (75 frames @
    37.5fps - every source frame plays, 1.25x faster, nothing truncated).
  * Task 147 (USER SPEC: 1.5 seconds exactly): the SAME 75 frames now play
    @ 50fps = EXACTLY 1.500s (1.667x, still nothing truncated).

Why not a plain colorkey: the clip itself contains near-white pixels that
belong to the OBJECT - the dice's pale face plates (min RGB ~230) and the
white-hot glow core at the center (min RGB ~249). A global white key would
punch holes in both. So the background is identified by CONNECTIVITY:

  1. whiteness w = min(R,G,B); bg_seed = pixels with w >= 246 (bg is 252).
  2. connected components of bg_seed that TOUCH the frame border = background.
     Enclosed near-white regions (face plates, glow core) are never reached.
  3. a 4px band around the background gets a SOFT alpha ramp
     (w 150..246 -> alpha 255..0) so smoke wisps and anti-aliased edges melt
     into the dark UI instead of showing a hard cut.
  4. band pixels are de-contaminated: fg = (C - (1-a)*252) / a, which removes
     the white fringe the h264 edges carry into the dark theme.
  5. ENCLOSED near-white pockets: the gaps between the opened panels show the
     studio background through the object, but they are sealed off from the
     border fill. A component qualifies as a pocket ONLY when it is big,
     FLAT (no bloom gradient), neutral and at full background brightness -
     the white-hot glow core carries a bloom gradient (std) and sits below
     full white, so it and the ivory face plates / pip glints stay opaque.
     Qualifying pockets melt away completely, with a 2px soft rim.

Output: public/rolldrop.mp4 (OVERWRITES the white-bg original). ffmpeg's
libvpx CANNOT encode a real alpha channel here (verified: alpha_mode tag is
written but the alpha BlockAdditional data is not), so instead of alpha we
BAKE the site's own backdrop into the clip: the case reel's radial gradient
(#160f2b -> #0b0716), NO halo. The clip only ever plays on those dark reels
and its rect edge is feathered by the component's CSS mask, so the result
reads as perfect transparency with zero browser risk - and h264 keeps it
small. Previews composited on the same backdrop are written next to this
script.
"""

import subprocess
from pathlib import Path

import cv2
import numpy as np

SRC = "/home/z/my-project/upload/rolldrop.mp4"
OUT = "/home/z/my-project/public/rolldrop.mp4"
PREV_DIR = Path("/home/z/my-project/scripts/rd-frames")
SEED_T = 246.0   # >= this whiteness counts as background candidate (bg is 252)
LOW_T = 150.0    # soft-ramp low end inside the edge band
WHITE = 252.0    # the background's actual white level (decontamination ref)
BAND_ITER = 4    # dilate iterations -> soft edge band width
POCKET_MIN = 200   # enclosed components smaller than this stay opaque
POCKET_WARM = 4.0  # |mean R-B| above this = ivory face plate, stays opaque
POCKET_BRIGHT = 249.0  # mean whiteness below this = glow/bloom, stays opaque
POCKET_FLAT = 2.2  # internal std above this = bloom gradient, stays opaque
PREVIEW_FRAMES = (0, 15, 35, 55, 69, 71, 73, 74)

cap = cv2.VideoCapture(SRC)
frames = []
while True:
    ok, f = cap.read()
    if not ok:
        break
    frames.append(f)
cap.release()
assert len(frames) == 75, f"expected 75 frames, got {len(frames)}"
h, wpx = frames[0].shape[:2]
assert (wpx, h) == (1280, 720), f"unexpected size {wpx}x{h}"

proc = subprocess.Popen(
    [
        "ffmpeg", "-y", "-v", "error",
        # Task 147: 75 frames @ 50fps = EXACTLY 1.500s (was 37.5fps / 2.0s)
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{wpx}x{h}", "-r", "50",
        "-i", "pipe:0",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19",
        "-preset", "slow", "-movflags", "+faststart", "-an",
        OUT,
    ],
    stdin=subprocess.PIPE,
)

# --- the site's backdrop, baked: ONLY the case reel's radial gradient.
# --- (Task 146: the amber halo layer is deleted - it was the golden
# --- rectangle the user still saw around the playing clip.)
# --- Task 146b: the gradient is sampled in REEL SPACE - the clip displays
# --- as a 16:9 rect centred on the reel (ref solo reel 1068x320, clip rect
# --- 320x180), so the baked edge colour matches the real reel bg behind the
# --- clip's rect edge almost exactly (CSS: radial-gradient(ellipse at
# --- center, #160f2b 0%, #0b0716 72%) - gradient ray = farthest corner).
import math
yy, xx = np.mgrid[0:h, 0:wpx].astype(np.float64)
REF_RW, REF_RH = 1068.0, 320.0   # reference solo reel (desktop, measured)
REF_VW, REF_VH = 320.0, 180.0    # the clip's displayed rect on that reel
edge_r = 0.72 * math.hypot(REF_RW / 2.0, REF_RH / 2.0)
ox = (xx + 0.5) / wpx * REF_VW - REF_VW / 2.0   # reel-space offset from centre
oy = (yy + 0.5) / h * REF_VH - REF_VH / 2.0
t = np.clip(np.sqrt(ox**2 + oy**2) / edge_r, 0.0, 1.0)
c_in = np.array([0x16, 0x0F, 0x2B], dtype=np.float64)   # #160f2b center
c_out = np.array([0x0B, 0x07, 0x16], dtype=np.float64)  # #0b0716 edge
backdrop = c_in[None, None, :] * (1.0 - t[..., None]) + c_out[None, None, :] * t[..., None]


kernel = np.ones((3, 3), np.uint8)
max_dx = 0.0  # Task 146: content extents for the CSS mask calibration
max_dy = 0.0
for i, bgr in enumerate(frames):
    rgb = bgr[..., ::-1].astype(np.float64)
    w = rgb.min(axis=2)
    warmth = rgb[..., 0] - rgb[..., 2]  # R-B: ivory face plates are warm, bg is neutral

    seed = (w >= SEED_T).astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(seed, connectivity=4)
    border = np.unique(
        np.concatenate([labels[0, :], labels[-1, :], labels[:, 0], labels[:, -1]])
    )
    border_set = {int(b) for b in border if b != 0}
    bg = np.isin(labels, list(border_set))

    band = (
        cv2.dilate(bg.astype(np.uint8), kernel, iterations=BAND_ITER).astype(bool)
        & ~bg
    )

    a = np.ones_like(w)          # alpha 0..1
    a[bg] = 0.0
    ab = np.clip((SEED_T - w[band]) / (SEED_T - LOW_T), 0.0, 1.0)
    a[band] = ab

    # enclosed near-white components: white seen THROUGH the object. Only big
    # flat neutral bright comps are true background pockets between the panels
    # (they melt away completely + a soft rim); the glow core (bloom gradient),
    # ivory faces and pip glints stay opaque exactly as rendered.
    # NOTE: disabled on the blast/smoke frames (n >= 69) - the fireball's
    # white-hot saturated center is flat neutral white too and MUST stay lit.
    for lab_id in range(1, n if i < 69 else 0):
        if lab_id in border_set or stats[lab_id, cv2.CC_STAT_AREA] < POCKET_MIN:
            continue
        mask = labels == lab_id
        ws = w[mask]
        if abs(warmth[mask].mean()) >= POCKET_WARM:
            continue  # warm = ivory face plate of the dice itself
        if ws.mean() < POCKET_BRIGHT or ws.std() > POCKET_FLAT:
            continue  # glow core / bloom: gradient or below full white
        a[mask] = 0.0
        ring = (
            cv2.dilate(mask.astype(np.uint8), kernel, iterations=2).astype(bool)
            & ~mask
            & ~bg
        )
        a[ring] = np.minimum(a[ring], np.clip((SEED_T - w[ring]) / 11.0, 0.0, 1.0))

    # white de-contamination on every partial-alpha pixel (band + pockets)
    soft = a < 1.0
    asoft = a[soft]
    for c in range(3):
        ch = rgb[..., c]
        ch[soft] = np.clip(
            (ch[soft] - (1.0 - asoft) * WHITE) / np.maximum(asoft, 1.0 / 255.0), 0, 255
        )

    # BAKE: composite the keyed content over the site backdrop - the clip
    # plays only on the dark reels, so this reads as real transparency.
    af = a[..., None]
    baked = rgb * af + backdrop * (1.0 - af)
    out = np.clip(baked, 0, 255).astype(np.uint8)  # RGB
    proc.stdin.write(out.tobytes())

    # Task 146: how far does the OBJECT reach (dice phase + panels phase,
    # smoke frames fill the frame by design)? -> mask calibration
    if i < 69:
        ys, xs = np.nonzero(a > 0.02)
        if len(xs):
            max_dx = max(max_dx, float(np.abs(xs - (wpx - 1) / 2.0).max()))
            max_dy = max(max_dy, float(np.abs(ys - (h - 1) / 2.0).max()))

    if i in PREVIEW_FRAMES:
        compf = out[..., ::-1].astype(np.float64)
        cv2.imwrite(str(PREV_DIR / f"prev_{i:02d}.png"), compf.astype(np.uint8))
        semi = int(((a > 0.02) & (a < 0.98)).sum())
        print(f"frame {i:02d}: bg={int(bg.sum()):7d} band={int(band.sum()):6d} semi={semi:6d}")

proc.stdin.close()
proc.wait()
assert proc.returncode == 0, "ffmpeg encode failed"
size = Path(OUT).stat().st_size
print(f"content extents (frames<69): dx={max_dx:.0f}px dy={max_dy:.0f}px of {wpx}x{h}")
probe = subprocess.run(
    ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
     "stream=nb_frames,avg_frame_rate,duration", "-of", "csv=p=0", OUT],
    capture_output=True, text=True,
)
print(f"encoded: {probe.stdout.strip()} (want 75 frames, 50 fps, 1.5s)")
print(f"OK wrote {OUT} ({size} bytes)")
