// Task 32 helper: forge a valid rb_session cookie for a test player
// (same HMAC scheme as src/lib/server/auth.ts) and print it.
import crypto from "crypto";
import fs from "fs";

const [, , pid] = process.argv;
const secret = fs.readFileSync("/home/z/my-project/db/.auth-secret", "utf8").trim();
const payload = Buffer.from(JSON.stringify({ pid, exp_ms: Date.now() + 24 * 3600 * 1000 })).toString("base64url");
const sig = crypto.createHmac("sha256", secret).update(payload).digest("base64url");
console.log(`${payload}.${sig}`);
