"""Task 46 E2E — REAL friend battles, two browser contexts:

  A (host)  /battles/friend/new → name → stack the TEST case x2 → CREATE ROOM
            → lands in the waiting room (code visible, entry paid)
  B (guest) /battles → FRIEND BATTLES section → sees the room row → JOIN
            → server AUTO-STARTS the battle → both animate the same pulls
  terminal  → server data: status done, totals/pot/winner consistent
            → ledgers: each side -entry; winner +pot; EXACT arithmetic

Also proves the friend-room ROLLDROP chain (TEST case = 70% per pull).
"""
import json
import time
import urllib.request

from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = "/home/z/my-project/download/e2e-shots"


def api_room(room_id):
    with urllib.request.urlopen(f"{BASE}/api/battles/rooms/{room_id}", timeout=10) as r:
        return json.loads(r.read().decode())


def balance(pg):
    return pg.evaluate(
        "() => { const s = JSON.parse(localStorage.getItem('rollbox-store')||'null'); return s && s.state ? s.state.balance : null; }"
    )


with sync_playwright() as p:
    b = p.chromium.launch()
    ctx_a = b.new_context(viewport={"width": 1440, "height": 900})
    ctx_b = b.new_context(viewport={"width": 1440, "height": 900})
    A = ctx_a.new_page()
    B = ctx_b.new_page()

    # ---- A: create the friend battle (TEST case x2 — 70% ROLLDROP each pull)
    A.goto(f"{BASE}/battles/friend/new", wait_until="domcontentloaded", timeout=90000)
    A.wait_for_selector("text=NEW FRIEND BATTLE", timeout=30000)
    A.wait_for_timeout(600)
    A.locator('button[title*="Add TEST"]').first.click()
    A.locator('button[title*="Add TEST"]').first.click()  # 2 rounds
    A.screenshot(path=f"{SHOTS}/46-create-stack.png")
    bal_a0 = balance(A)
    A.get_by_role("button", name="CREATE ROOM").click()
    A.wait_for_selector("text=Waiting for a friend", timeout=20000)  # only the ROOM page shows this
    room_id = A.url.split("/battles/friend/")[1].split("?")[0]
    assert room_id != "new" and len(room_id) >= 8, f"bad room id: {room_id}"
    A.wait_for_selector("text=RB-", timeout=10000)
    bal_a1 = balance(A)
    A.screenshot(path=f"{SHOTS}/46a-waiting.png")
    print("room:", room_id, "| A balance:", bal_a0, "->", bal_a1, "(entry should be gone)")

    # ---- B: join from the lobby
    B.goto(f"{BASE}/battles", wait_until="domcontentloaded", timeout=90000)
    B.wait_for_selector("text=Friend battles", timeout=30000)
    B.wait_for_selector('div[aria-label="Friend battles list"]', timeout=20000)
    B.screenshot(path=f"{SHOTS}/46b-lobby-row.png")
    bal_b0 = balance(B)
    B.locator('div[aria-label="Friend battles list"] button:has-text("JOIN")').first.click()
    B.wait_for_url("**/battles/friend/**", timeout=20000)
    bal_b1 = balance(B)
    print("B balance:", bal_b0, "->", bal_b1, "(entry should be gone)")

    # ---- the battle rolls on both sides
    A.wait_for_selector("text=Rolling", timeout=15000)
    B.wait_for_selector("text=Rolling", timeout=15000)
    time.sleep(1.4)
    A.screenshot(path=f"{SHOTS}/46-rolling-a.png", clip={"x": 100, "y": 60, "width": 1240, "height": 700})
    B.screenshot(path=f"{SHOTS}/46-rolling-b.png", clip={"x": 100, "y": 60, "width": 1240, "height": 700})

    # ---- wait for the server to flip the room to done
    final = None
    for _ in range(60):
        data = api_room(room_id)
        if data["room"]["status"] == "done":
            final = data["room"]
            break
        time.sleep(1.0)
    assert final is not None, "battle never finished"
    pot = final["pot"] or 0
    entry = final["entry"]
    totals = final["totals"]
    winner = final["winnerId"]
    print("FINAL(server): status=done pot=", pot, "entry=", entry, "totals=", json.dumps(totals), "winner=", winner)

    # pulls ↔ totals consistency
    calc = {}
    for rnd in final["rounds"]:
        for pid, pull in (rnd["pulls"] or {}).items():
            calc[pid] = calc.get(pid, 0) + pull["value"]
    assert calc == totals, f"totals mismatch: {calc} vs {totals}"
    assert pot == sum(totals.values()), "pot must equal the total of every drop"
    print("rd pulls:", [(r["caseId"], {k: v["rd"] for k, v in (r["pulls"] or {}).items()}) for r in final["rounds"]])

    # ---- let both clients poll the done state + settle the pot
    time.sleep(3.5)
    A.wait_for_selector("text=Finished", timeout=20000)
    B.wait_for_selector("text=Finished", timeout=20000)
    bal_a2 = balance(A)
    bal_b2 = balance(B)
    names = {pl["id"]: pl["name"] for pl in final["players"]}
    print("winner is:", names.get(winner), "| A final:", bal_a2, "| B final:", bal_b2)

    exp_a = bal_a1 + (pot if winner and winner in [pl["id"] for pl in final["players"] if pl["id"] == A.evaluate("localStorage.getItem('rb-player-id')")] else 0)
    exp_b = bal_b1 + (pot if winner and winner in [pl["id"] for pl in final["players"] if pl["id"] == B.evaluate("localStorage.getItem('rb-player-id')")] else 0)
    print("expected: A", exp_a, "B", exp_b)
    ok_money = bal_a2 == exp_a and bal_b2 == exp_b
    ok_entry = bal_a1 == bal_a0 - entry and bal_b1 == bal_b0 - entry
    print("ENTRY LEDGER:", "PASS" if ok_entry else "FAIL", "| PAYOUT LEDGER:", "PASS" if ok_money else "FAIL")

    A.screenshot(path=f"{SHOTS}/46a-done.png", clip={"x": 100, "y": 60, "width": 1240, "height": 700})
    B.screenshot(path=f"{SHOTS}/46b-done.png", clip={"x": 100, "y": 60, "width": 1240, "height": 700})

    verdict = ok_entry and ok_money
    print("RESULT:", "PASS" if verdict else "FAIL")
    b.close()
