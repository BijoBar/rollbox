/**
 * R44 USER SPEC — batch-generate the new designed artwork for EVERY public
 * case: open-crate house style on a pure black void, the case's RAREST skin
 * featured floating above the opening, a glowing ROLLBOX nameplate, per-case
 * unique theme + special effects, 1152x864.
 *
 * Resumable: skips raws that already exist. Concurrency 2, retry x3.
 * Run: node scripts/gen-case-art.mjs [slug ...]   (no args = all missing)
 */
import ZAI from "z-ai-web-dev-sdk";
import fs from "node:fs";
import path from "node:path";

const ROOT = "/home/z/my-project";
const OUT_DIR = path.join(ROOT, "upload/cases-gen");
const MANIFEST = JSON.parse(fs.readFileSync(path.join(ROOT, "scripts/case-art-manifest.json"), "utf-8"));
fs.mkdirSync(OUT_DIR, { recursive: true });

const filter = process.argv.slice(2);
const jobs = MANIFEST.filter((c) => (filter.length ? filter.includes(c.slug) : true)).filter(
  (c) => !fs.existsSync(path.join(OUT_DIR, `${c.slug}.png`)),
);

// ---- per-case visual language: theme + effects so EVERY design is unique ----
const THEME = {
  "asiimov-protocol": { theme: "white and orange Asiimov futurist sci-fi panels with black accents, orange sci-fi markings", fx: "pulsing orange energy rings and floating orange sparks" },
  "printstream-cartel": { theme: "monochrome white-and-black printstream chrome panels, silver steel trim, urban street-art cartel vibe", fx: "silver halftone dot glow and drifting white mist" },
  "dragons-vault": { theme: "dark bronze bank-vault panels engraved with golden oriental dragons, red seals", fx: "golden embers and a swirling dragon-shaped flame silhouette" },
  "fade-factory": { theme: "glossy panels airbrushed with the iconic rainbow fade gradient purple to pink to yellow, factory conveyor chrome", fx: "iridescent rainbow light rays and floating glitter" },
  "crimson-covenant": { theme: "deep crimson velvet and dark gothic metal panels, ornate gold filigree, vampire aristocracy", fx: "drifting crimson rose petals and dark red mist" },
  "doppler-realm": { theme: "cosmic galaxy panels with doppler phase swirls of blue, purple and pink nebula marble", fx: "a starfield with floating cosmic stardust and a small glowing planet" },
  "hardened-crown": { theme: "case-hardened blue-and-gold patina steel panels with a royal golden crown emblem", fx: "blue-purple oil-slick shimmer and floating gold flakes" },
  "hellfire-club": { theme: "matte black club panels with hellfire red-orange flame engravings and chrome studs", fx: "real flames licking the crate edges and rising fire particles" },
  "neon-district": { theme: "cyberpunk city panels in magenta and cyan neon signs, wet asphalt reflections, holographic ads", fx: "neon glow bloom and floating cyan holographic glyphs" },
  "emerald-sanctum": { theme: "jeweled emerald vault panels with glowing green gemstones set in gold", fx: "green crystal shards orbiting the crate and soft emerald glow" },
  "tiger-tribe": { theme: "orange and black tiger-stripe tribal panels with fang ornaments", fx: "orange jungle fireflies and bold claw-scratch light streaks" },
  "hyper-beast-bazaar": { theme: "colorful hyperbeast graffiti panels with wild multicolor abstract beast artwork", fx: "explosive multicolor paint splashes frozen mid-air" },
  "awp-command": { theme: "a simple rectangular black trunk-shaped weapon crate standing on its base, hinged lid open upward at 45 degrees, red japanese oni demon mask artwork painted on the inside of the lid, and a LARGE glowing white rectangular nameplate covering most of the front face reading ROLLBOX in huge clean letters", fx: "red laser lines and falling cherry blossom petals" },
  "ak-imperium": { theme: "imperial roman purple and gold caesar panels with laurel wreath emblems and marble", fx: "golden laurel leaves floating and imperial light beams" },
  "blade-barony": { theme: "gamma doppler emerald metallic swirl panels, noble barony silver frame", fx: "liquid emerald metal swirls orbiting the crate" },
  "glove-syndicate": { theme: "teal and black sport leather panels with stitched syndicate patches and carbon fiber", fx: "teal energy wisps and floating leather stitching glow" },
  "gold-rush": { theme: "old-west gold rush panels covered in gold arabesque engravings, nuggets and bars", fx: "a golden dust storm with sparkling nuggets raining down" },
  "urban-ops": { theme: "tactical urban grey camouflage military panels with stencil markings and velcro patches", fx: "tactical smoke grenade haze and green night-vision glow" },
  "glitch-protocol": { theme: "digital glitch panels with RGB channel-split artifacts and corrupted datamosh patterns", fx: "RGB glitch scanlines and floating pixel cubes" },
  "polar-front": { theme: "arctic frost panels covered in ice crystals and snow, steel-blue military winter camo", fx: "swirling snowflakes and freezing blue mist" },
  "farm-m4a4": { theme: "ranch barn-wood panels with a full moon backdrop and a wolf silhouette artwork", fx: "a huge glowing full moon behind the crate and howling wind mist" },
  "farm-m4a1s": { theme: "medieval knight armor panels in polished silver steel with cross sigils", fx: "silver light rays and floating steel sparks" },
  "farm-ak47": { theme: "serene pink lotus pond panels with soft watercolor florals on dark wood", fx: "pink lotus petals drifting and gentle water ripples of light" },
  "farm-deagle": { theme: "black panels with fierce orange-blue blaze flame artwork", fx: "intense blue-white flame bursts" },
  "farm-glock": { theme: "glossy panels with the fade rainbow gradient and chrome trim", fx: "candy-colored iridescent bubbles" },
  "farm-usps": { theme: "tactical white-and-orange panels with crosshair target markings", fx: "orange target-lock holograms and tracer streaks" },
  "farm-awp": { theme: "norse mythology panels with the gungnir spear engravings in silver on arctic blue steel", fx: "aurora borealis ribbons overhead and rune glyphs glowing" },
  "farm-gloves": { theme: "black-and-orange racing sport leather panels with blaze flame stitching", fx: "fire sparks streaking like a racetrack at night" },
  "farm-knives": { theme: "collector display cabinet panels in walnut wood with velvet fade-gradient lining", fx: "soft museum spotlight beams and floating dust glitter" },
  "farm-zeus": { theme: "playful lightning-lab panels in yellow and black hazard stripes with a cute dragon doodle", fx: "cartoon lightning bolts crackling around the crate" },
  "level-10": { theme: "fresh recruit bronze panels with simple star insignia", fx: "soft bronze confetti sparks" },
  "level-20": { theme: "seasoned steel panels with double-star insignia and clean military lines", fx: "steel sparkles and light flares" },
  "level-30": { theme: "gunmetal veteran panels with winged insignia and orange accents", fx: "orange ember sparks rising" },
  "level-40-forced-asiimov": { theme: "placeholder", fx: "placeholder" },
  "level-40": { theme: "royal navy-blue panels with gold koi wave engravings", fx: "golden koi fish light trails swimming around the crate" },
  "level-50": { theme: "elite emerald panels with gamma doppler swirls and a silver crest", fx: "emerald energy waves" },
  "level-60": { theme: "prestige black-and-gold panels with tiger-stripe gold inlays", fx: "golden lightning arcs" },
  "level-70": { theme: "mythic deep-sea panels with medusa green snake engravings on dark teal", fx: "green glowing serpent wisps" },
  "level-80": { theme: "knighted chrome panels with royal blue velvet and silver crest", fx: "silver star burst flares" },
  "level-90": { theme: "ascended obsidian panels with white-gold engravings and a glowing halo emblem", fx: "golden halo light ring and holy particles" },
  "level-100": { theme: "legendary mythic panels with prismatic rainbow chrome and a diamond crest", fx: "prismatic rainbow explosions and diamond sparkle shower" },
};

// weapon-kind -> human phrasing used in the prompt for the featured skin
const WEAPON_PHRASE = {
  ak: "AK-47 rifle", m4: "M4 rifle", awp: "AWP sniper rifle", deagle: "Desert Eagle pistol",
  usp: "USP-S pistol", glock: "Glock-18 pistol", p90: "P90 SMG", mp9: "MP9 SMG",
  ssg08: "SSG 08 sniper rifle", galil: "Galil AR rifle", mac10: "MAC-10 SMG", nova: "Nova shotgun",
  zeus: "Zeus x27 taser", knife: "CS2 knife", gloves: "pair of CS2 sport gloves", "dual-berettas": "Dual Berettas pistols",
  p2000: "P2000 pistol", p250: "P250 pistol", "tec-9": "Tec-9 pistol", "five-seven": "Five-SeveN pistol",
  "m4a1-s": "M4A1-S rifle", "mp7": "MP7 SMG", ump: "UMP-45 SMG", "scar-20": "SCAR-20 rifle", "mag-7": "MAG-7 shotgun",
};

const HINT = {
  "level-60": "The knife blade is covered in the swirling dark-green and black Gamma Doppler marbled pattern with emerald highlights.",
  "awp-command": "",
};

const promptFor = (c) => {
  const t = THEME[c.slug] ?? { theme: `dark tactical panels in ${c.tierColor} and ${c.tierColor2} tones`, fx: "cinematic light particles" };
  const skin = c.rarest;
  const weapon = WEAPON_PHRASE[skin?.weapon] ?? "CS2 weapon";
  const skinDesc = skin ? `the iconic "${skin.name}" CS2 skin` : "";
  return [
    "Premium 3D product render of an open CS2 weapon case crate, three-quarter view, lid raised open, floating in a pure black void, NO floor, NO surface, NO ground reflections, NO shadows on the ground.",
    `The crate armor panels are: ${t.theme}. The crate stands upright at a three-quarter angle with its front face fully visible toward the viewer.`,
    `Intense neon glow in ${c.tierColor} and ${c.tierColor2} shining from the open interior.`,
    skin
      ? `Featured reward floating above the opening surrounded by soft smoke: ${skinDesc} — a ${weapon} rendered in its skin artwork, tilted hero pose, clearly visible. The featured skin MUST be exactly "${skin.name}" — no other skin.`
      : "Featured reward floating above the opening surrounded by soft smoke.",
    "A bright glowing rectangular nameplate on the front face of the crate reading exactly ROLLBOX in clean glowing capital letters. The ONLY text anywhere in the image is the word ROLLBOX — do NOT write the skin name or any other text anywhere.",
    `Special effects: ${t.fx}.`,
    "Volumetric glow, gold rim lighting, isolated on a solid #000000 pure black background, studio product shot, ultra detailed, high quality 3D render.",
  ].join(" ");
};

const zai = await ZAI.create();
let done = 0;
const failed = [];

const runOne = async (c, attempt = 1) => {
  const out = path.join(OUT_DIR, `${c.slug}.png`);
  try {
    const res = await zai.images.generations.create({ prompt: promptFor(c), size: "1152x864" });
    const b64 = res?.data?.[0]?.base64;
    if (!b64) throw new Error("empty base64");
    fs.writeFileSync(out, Buffer.from(b64, "base64"));
    done += 1;
    console.log(`[${done}/${jobs.length}] ${c.slug} OK (${(fs.statSync(out).size / 1024).toFixed(0)} KB)`);
  } catch (e) {
    if (attempt < 3) {
      await new Promise((r) => setTimeout(r, 1500 * attempt));
      return runOne(c, attempt + 1);
    }
    failed.push(c.slug);
    console.error(`FAIL ${c.slug}: ${e.message}`);
  }
};

const workers = Array.from({ length: 2 }, async function worker() {
  while (jobs.length) {
    const c = jobs.shift();
    if (!c) break;
    await runOne(c);
  }
});
await Promise.all(workers);
console.log(`\nDONE generated=${done} failed=${failed.length}${failed.length ? " -> " + failed.join(",") : ""}`);
