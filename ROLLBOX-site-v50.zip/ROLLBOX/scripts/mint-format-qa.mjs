// Task 77 helper: create/refresh a QA player with a comma-worthy balance and
// mint a signed rb_session cookie for live browser verification.
import { PrismaClient } from "@prisma/client";
import crypto from "crypto";

const db = new PrismaClient();
const secret = () => process.env.AUTH_SECRET || "rollbox-dev-secret";
const sign = (payload) =>
  crypto.createHmac("sha256", secret()).update(payload).digest("base64url");

const SESSION_MS = 30 * 24 * 60 * 60 * 1000;
const makeSessionToken = (playerId) => {
  const body = Buffer.from(JSON.stringify({ pid: playerId, exp: Date.now() + SESSION_MS })).toString("base64url");
  return `${body}.${sign(body)}`;
};

const steamId = "76561198000000077";
const player = await db.player.upsert({
  where: { providerId: steamId },
  update: { balance: 12345.67, name: "FormatQA" },
  create: {
    id: "p_" + crypto.randomBytes(8).toString("hex"),
    provider: "steam",
    providerId: steamId,
    name: "FormatQA",
    avatar: "",
    balance: 12345.67,
  },
});
console.log("PLAYER_ID=" + player.id);
console.log("BALANCE=" + player.balance);
console.log("COOKIE=" + makeSessionToken(player.id));
await db.$disconnect();
