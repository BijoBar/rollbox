// ============ Task 29: backfill Player.casesOpened from Drop history ============
// The leaderboard's CASES OPENED read the per-player counter that was NEVER
// incremented (only the global Counter was) — every row sat at 0. Forward
// fixes live in /api/open and gbattles resolve; this script restores the
// LIFETIME numbers retroactively: every case open writes exactly ONE Drop
// row per case, so the count of the player's Drop rows IS their lifetime
// opens (solo + battles, bots never match a Player row).
//
//   bun scripts/t29-backfill-cases-opened.mjs

import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const counts = await db.drop.groupBy({ by: ["playerId"], _count: { _all: true } });
const dropCount = new Map(counts.map((c) => [c.playerId, c._count._all]));

const players = await db.player.findMany({ select: { id: true, name: true, casesOpened: true } });
console.log("Players:", players.length);
for (const p of players) {
  const fromHistory = dropCount.get(p.id) ?? 0;
  const next = Math.max(p.casesOpened, fromHistory);
  if (next !== p.casesOpened) {
    await db.player.update({ where: { id: p.id }, data: { casesOpened: next } });
    console.log(`✓ ${p.name ?? p.id}: ${p.casesOpened} → ${next} (from ${fromHistory} Drop rows)`);
  } else {
    console.log(`• ${p.name ?? p.id}: already ${p.casesOpened}`);
  }
}
await db.$disconnect();
