// T30 lab: upserts the referral E2E pair — p_t88a (depositing invitee) and
// p_t88b (inviter) — with CLEAN referral state, prints both cookies and the
// inviter's refCode. Usage: bun scripts/t130-reflab.mjs
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const ROOT = "/home/z/my-project";

function signingSecret() {
  const file = path.join(ROOT, "db", ".auth-secret");
  const s = fs.readFileSync(file, "utf8").trim();
  if (s.length >= 32) return s;
  throw new Error("db/.auth-secret missing — start the dev server once first");
}

const sign = (payload) =>
  crypto.createHmac("sha256", signingSecret()).update(payload).digest("base64url");
const makeToken = (pid) => {
  const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 30 * 864e5 })).toString("base64url");
  return `${body}.${sign(body)}`;
};

const upsert = (id, providerId, name, code) =>
  db.player.upsert({
    where: { id },
    create: { id, provider: "steam", providerId, name, balance: 5000, refCode: code },
    update: { bannedAt: null, referredBy: null, refPaidAt: null, refBonusAt: null },
  });

const a = await upsert("p_t88a", "e2e-t88a", "T88 A", "T88TEST1");
const b = await upsert("p_t88b", "e2e-t88b", "T88 B", "T88TEST2");

console.log("A_COOKIE=" + makeToken(a.id));
console.log("B_COOKIE=" + makeToken(b.id));
console.log("B_REFCODE=" + b.refCode);
console.log("A_BAL=" + a.balance, "B_BAL=" + b.balance);
await db.$disconnect();
