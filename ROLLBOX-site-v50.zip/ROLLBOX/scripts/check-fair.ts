// Task 151 — SERVER PROVABLY FAIR end-to-end verification (dev-only script).
// Runs the FULL loop against the live server on :3000 and PROVES the math:
//   1. GET  /api/fair           -> active commitment exists
//   2. POST /api/open           -> fair fields + per-reel floats, price charged
//   3. GET  /api/fair           -> the open landed in the bet history
//   4. POST /api/fair/rotate    -> seed revealed; SHA-256(seed+salt) == hash
//   5. RECOMPUTE every recorded reel from the revealed seed via the SHARED
//      libs (rollFloat + pickWeighted) and assert it reproduces the exact
//      skin the server paid — gate -> ROLLDROP flag, item draw -> skinId.
//   6. Upgrader spin (stake granted in-DB first) -> same recompute for win/loss.
// Exit code 0 = everything reproduces. Any mismatch = non-zero + report.

import { db } from "../src/lib/db";
import { makeSessionToken } from "../src/lib/server/auth";
import { computePublicHash, pickWeighted, rollFloat } from "../src/lib/provably-fair";
import { rareCaseOf } from "../src/lib/rolldrop";
import { CASES, caseItemValue } from "../src/lib/cases";

const BASE = "http://localhost:3000";
let failures = 0;
const ok = (cond: boolean, label: string) => {
  console.log(`${cond ? "  PASS" : "  FAIL"}  ${label}`);
  if (!cond) failures++;
};

const player = await db.player.findFirst({ where: { isAdmin: false }, orderBy: { id: "asc" } });
if (!player) {
  console.error("NO PLAYER FOUND");
  process.exit(1);
}
const token = makeSessionToken(player.id);
const cookie = `rb_session=${token}`;
console.log(`player: ${player.id} (${player.name}) balance=$${player.balance}`);

const jfetch = async (path: string, init?: RequestInit) => {
  const res = await fetch(BASE + path, {
    ...init,
    headers: { "content-type": "application/json", cookie, ...(init?.headers ?? {}) },
  });
  return { status: res.status, json: (await res.json().catch(() => ({}))) as never as Record<string, never> };
};

// ---- 1. commitment exists ----
console.log("\n[1] GET /api/fair — active commitment");
const fair1 = await jfetch("/api/fair");
ok(fair1.status === 200, `status 200 (got ${fair1.status})`);
const active0 = fair1.json.active as { serverSeedHash: string; clientSeed: string; nextNonce: number } | undefined;
ok(!!active0?.serverSeedHash && active0.serverSeedHash.length === 64, "serverSeedHash published (64 hex)");
ok(typeof active0?.clientSeed === "string" && active0.clientSeed.length >= 8, "clientSeed present");
console.log(`  hash=${active0?.serverSeedHash.slice(0, 16)}… client=${active0?.clientSeed} nextNonce=${active0?.nextNonce}`);

// ---- 2. open a case on the server ----
console.log("\n[2] POST /api/open — provably fair roll");
const caseDef = CASES.find((c) => c.price > 0 && c.kind !== "level") ?? CASES[0];
const open = await jfetch("/api/open", {
  method: "POST",
  body: JSON.stringify({ caseId: caseDef.id, count: 2 }),
});
ok(open.status === 200, `status 200 (got ${open.status} ${(open.json.error as string) ?? ""})`);
const pulls = open.json.pulls as { skinId: string; wear?: string; value: number; rd: boolean; f: [number, number] }[] | undefined;
const fair = open.json.fair as { hash: string; clientSeed: string; startNonce: number } | undefined;
ok(!!pulls && pulls.length === 2, "2 pulls returned");
ok(!!fair && fair.hash === active0?.serverSeedHash, "response fair.hash == the commitment we saw BEFORE the roll");
ok(!!(pulls?.every((p) => p.f[0] >= 0 && p.f[0] < 1 && p.f[1] >= 0 && p.f[1] < 1)), "per-reel floats in [0,1)");
console.log(`  case=${caseDef.id} startNonce=${fair?.startNonce} credited=$${open.json.credited}`);

// claim the parked win so the balance is consistent for the upgrader step
const pendingId = open.json.pendingId as string | undefined;
if (pendingId) await jfetch("/api/open/claim", { method: "POST", body: JSON.stringify({ pendingId }) });

// ---- 3. bet history recorded ----
console.log("\n[3] GET /api/fair — bet history");
const fair2 = await jfetch("/api/fair");
const rolls = fair2.json.rolls as { id: number; game: string; ref: string; seedHash: string; clientSeed: string; nonce: number; detail: { count: number; rdChance: number; reels: { n: number; ni: number; rd: boolean; skinId: string; value: number }[] } }[];
const myRoll = rolls.find((r) => r.game === "open" && r.seedHash === fair?.hash && r.nonce === fair?.startNonce);
ok(!!myRoll, "the open landed in FairRoll history with its nonces");
ok(myRoll?.detail.reels.length === 2, "history carries both reels");
ok(typeof myRoll?.detail.rdChance === "number", "rdChance recorded at roll time");

// ---- 4. rotate + hash commitment check ----
console.log("\n[4] POST /api/fair/rotate — reveal");
const rot = await jfetch("/api/fair/rotate", { method: "POST", body: JSON.stringify({ clientSeed: "e2e-check-seed" }) });
ok(rot.status === 200, `status 200 (got ${rot.status})`);
const revealed = rot.json.revealed as { serverSeed: string; salt: string; serverSeedHash: string; clientSeed: string; nonceUsed: number };
ok(computePublicHash(revealed.serverSeed, revealed.salt) === revealed.serverSeedHash, "SHA-256(seed + salt) == the hash that was published BEFORE the rolls");
ok(revealed.serverSeedHash === fair?.hash, "revealed hash == the hash the open was rolled against");
const rot2 = await jfetch("/api/fair");
const active2 = rot2.json.active as { serverSeedHash: string; clientSeed: string; nextNonce: number };
ok(active2.serverSeedHash !== revealed.serverSeedHash, "a FRESH commitment is active after rotation");
ok(active2.nextNonce === 0, "new chain starts at nonce 0");

// ---- 5. THE MATH — recompute every reel from the revealed seed ----
console.log("\n[5] recompute both reels from the revealed seed (shared libs)");
if (myRoll && pulls) {
  for (let i = 0; i < myRoll.detail.reels.length; i++) {
    const reel = myRoll.detail.reels[i];
    const gate = rollFloat(revealed.serverSeed, myRoll.clientSeed, reel.n);
    const item = rollFloat(revealed.serverSeed, myRoll.clientSeed, reel.ni);
    const rdRepro = gate < myRoll.detail.rdChance;
    ok(rdRepro === reel.rd, `reel ${i}: gate reproduces the ROLLDROP flag (${reel.rd})`);
    const table = reel.rd ? rareCaseOf(caseDef).items : caseDef.items;
    const expected = pickWeighted(table, item);
    ok(expected.skinId === reel.skinId, `reel ${i}: item draw reproduces ${reel.skinId} (${expected.skinId})`);
    const val = caseItemValue(expected);
    ok(Math.abs(val - reel.value) < 0.01, `reel ${i}: value reproduces $${reel.value}`);
    ok(Math.abs(item - pulls[i].f[1]) < 1e-12, `reel ${i}: server's own float matches the recompute bit-for-bit`);
  }
}

// ---- 6. upgrader on the fair chain ----
console.log("\n[6] POST /api/upgrader — provably fair spin");
const invCount = await db.inventoryItem.count({ where: { playerId: player.id } });
if (invCount === 0) {
  await db.inventoryItem.create({
    data: {
      id: "i_fair_e2e_" + Date.now(),
      playerId: player.id,
      entryId: "test-e2e-stake",
      data: JSON.stringify({ id: "test-e2e-stake", n: "E2E Stake Skin", w: "_TEST", r: "mil-spec", v: 2, k: "test" }),
      value: 2,
    },
  });
  console.log("  (granted a $2 stake item for the spin)");
}
const rows = await db.inventoryItem.findMany({ where: { playerId: player.id }, take: 1 });
const up = await jfetch("/api/upgrader", { method: "POST", body: JSON.stringify({ uids: rows.map((r) => r.id), multiplier: 1.05 }) });
ok(up.status === 200, `status 200 (got ${up.status} ${(up.json.error as string) ?? ""})`);
const upFair = up.json.fair as { hash: string; clientSeed: string; nonce: number } | undefined;
ok(!!upFair && typeof upFair.nonce === "number", "upgrader returned its fair nonce");
const upRolls = (await jfetch("/api/fair")).json.rolls as { game: string; seedHash: string; nonce: number; detail: { win: boolean; chance: number } }[];
const upRoll = upRolls.find((r) => r.game === "upgrader" && r.nonce === upFair?.nonce && r.seedHash === upFair?.hash);
ok(!!upRoll, "the spin landed in FairRoll history");
if (upRoll && upFair) {
  // the spin rolled on the chain that was ACTIVE at spin time — which, after
  // step 4's rotation, is the FRESH (still hidden) seed. Correct commit-reveal
  // behavior: reveal it now with a second rotation, then recompute.
  await jfetch("/api/fair/rotate", { method: "POST", body: JSON.stringify({}) });
  const seeds = ((await jfetch("/api/fair")).json.revealed as { serverSeed: string; salt: string; serverSeedHash: string }[]);
  const upSeed = seeds.find((s) => s.serverSeedHash === upFair.hash);
  ok(!!upSeed, "after a second reveal, the spin's seed is public and in the revealed set");
  if (upSeed) {
    const f = rollFloat(upSeed.serverSeed, upFair.clientSeed, upFair.nonce);
    ok((f < upRoll.detail.chance) === upRoll.detail.win, `recompute reproduces win=${upRoll.detail.win} (float ${f.toFixed(6)} vs chance ${upRoll.detail.chance.toFixed(4)})`);
  }
  // the stake was consumed by the spin — restore it for future runs
  await db.inventoryItem.create({
    data: {
      id: "i_fair_e2e_" + Date.now() + "_r",
      playerId: player.id,
      entryId: "test-e2e-stake",
      data: JSON.stringify({ id: "test-e2e-stake", n: "E2E Stake Skin", w: "_TEST", r: "mil-spec", v: 2, k: "test" }),
      value: 2,
    },
  }).catch(() => {});
}

console.log("\nplayers:", await db.player.count(), "| fairSeeds:", await db.fairSeed.count(), "| fairRolls:", await db.fairRoll.count());
console.log(failures === 0 ? "\nALL FAIRNESS CHECKS PASSED ✅" : `\n${failures} CHECK(S) FAILED ❌`);
await db.$disconnect();
process.exit(failures === 0 ? 0 : 1);
