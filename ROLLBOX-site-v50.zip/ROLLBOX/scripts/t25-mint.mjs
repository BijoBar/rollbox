// Task 25 — mint a disposable test player + signed session cookie (UI check only)
import { createRequire } from "module";
import crypto from "crypto";
const require = createRequire(import.meta.url);
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
const fs = await import("fs");

const SECRET = fs.readFileSync("/home/z/my-project/db/.auth-secret", "utf8").trim();
const sign = (p) => crypto.createHmac("sha256", SECRET).update(p).digest("base64url");
const PID = "p_t26ui";

await db.player.upsert({
  where: { id: PID },
  create: { id: PID, provider: "steam", providerId: "7650000000026000", name: "T26 UI", balance: 800 },
  update: { balance: 800, bannedAt: null },
});
const body = Buffer.from(JSON.stringify({ pid: PID, exp: Date.now() + 86400000 })).toString("base64url");
console.log("rb_session=" + body + "." + sign(body));
await db.$disconnect();
