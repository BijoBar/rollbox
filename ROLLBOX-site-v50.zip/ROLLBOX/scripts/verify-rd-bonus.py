"""Task 61 E2E — the ROLLDROP bonus reel in battles must land on the REAL
rare skin, never on the raredrop art again.

THE BUG THIS GUARDS: RoundReel swapped main->bonus BattleReel without a key,
so React kept the SAME instance and the bonus reel spun on the stale strip
whose winner cell was still the ROLLDROP marker — every bonus round looked
like "another rolldrop box" while the skin was silently credited.

Flow: signed-in 1v1 local battle with the TEST case + rb-rolldrop-force=1
(every round hits ROLLDROP) -> Call Bots -> the room resolves.

Checks:
  1. the MAIN reel locks ON the raredrop art (the marker tile is present);
  2. CRITICAL: from the bonus mount (white cover) until it detaches, the
     seat square contains ZERO raredrop images — the bonus strip is a fresh
     rare-skin reel, so the winner cell is a real skin;
  3. the room still reaches a finished state (the flow was not broken).
"""
import json
import subprocess
import sys
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = Path("/home/z/my-project/download/e2e-shots")
SHOTS.mkdir(parents=True, exist_ok=True)
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS  " if ok else "FAIL  ") + name + ("  — " + detail if detail else ""))

# ---- clean world + mint ONE real DB session --------------------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
out = subprocess.run(
    ["bun", "scripts/mint-session.mjs"], capture_output=True, text=True, cwd="/home/z/my-project"
).stdout.strip().splitlines()
A = json.loads(out[0])
print(f"session: A={A['name']}({A['id']})")

with sync_playwright() as pw:
    browser = pw.chromium.launch(
        args=["--disable-background-timer-throttling", "--disable-renderer-backgrounding"]
    )
    ctx = browser.new_context(viewport={"width": 1440, "height": 900})
    ctx.add_cookies([{"name": "rb_session", "value": A["token"], "url": BASE}])
    room = ctx.new_page()
    room.goto(BASE + "/battles", wait_until="domcontentloaded")
    # force EVERY pull into the ROLLDROP chain (local-battle hook, Task 45)
    room.evaluate("localStorage.setItem('rb-rolldrop-force','1')")

    # ---- build a 1-round TEST-case battle ------------------------------------
    room.goto(BASE + "/battles/new", wait_until="domcontentloaded")
    room.wait_for_selector("button:has-text('Create Battle')", timeout=15000)
    room.get_by_role("button", name="Add a case to the battle").click(timeout=6000)
    room.wait_for_timeout(600)
    # TEST *is* the 70% ROLLDROP demo case — three rounds make an RD hit a
    # statistical certainty (P(no RD) = 0.3^6 ~ 0.07%). The SERVER rolls the
    # pulls (anti-peek), so the per-case chance — not the localStorage flag —
    # is what forces the chain here.
    for _ in range(3):
        room.get_by_role("button", name="Add TEST, price $10").click(timeout=6000)
        room.wait_for_timeout(400)
    room.keyboard.press("Escape")
    try:
        room.wait_for_selector('[data-slot="dialog-overlay"]', state="detached", timeout=4000)
    except Exception:
        room.keyboard.press("Escape")
        room.wait_for_selector('[data-slot="dialog-overlay"]', state="detached", timeout=4000)
    room.wait_for_timeout(500)
    room.locator("button:has-text('Create Battle')").first.click(timeout=6000)
    deadline = time.time() + 45  # Turbopack first-compile of the room can stall
    new_id = ""
    while time.time() < deadline:
        seg = room.url.rstrip("/").split("/")[-1]
        if seg != "new" and "/battles/" in room.url:
            new_id = seg
            break
        time.sleep(0.3)
    if not new_id:
        r = ctx.request.get(BASE + "/api/gbattles")
        lst = r.json().get("battles", [])
        if lst:
            new_id = lst[0]["id"]
            room.goto(BASE + "/battles/" + new_id, wait_until="domcontentloaded")
    check("room opened", bool(new_id), "id=" + (new_id or "?"))
    room.wait_for_timeout(1500)

    # ---- fill the seat, the battle starts ------------------------------------
    cb = room.locator("button:has-text('Call Bots')").first
    cb.wait_for(state="visible", timeout=20000)
    cb.click(timeout=6000)
    check("Call Bots pressed", True)
    t0 = time.time()

    # ---- 1. the MAIN reel locks ON the raredrop marker ------------------------
    got_marker = False
    while time.time() - t0 < 100 and not got_marker:
        got_marker = room.evaluate(
            "(() => { const covers = document.querySelectorAll('.rd-white-cover');"
            " if (covers.length) return false;"  # bonus already started — too late
            " return document.querySelectorAll('img[src=\"/raredrop.png\"]').length > 0; })()"
        )
        time.sleep(0.25)
    check("main reel locks on the raredrop marker", got_marker)
    if got_marker:
        room.screenshot(path=str(SHOTS / "61-rd-main-marker.png"))

    # ---- 2. CRITICAL: the BONUS reel carries ZERO raredrop art ----------------
    # From the first white cover mount, poll every covered seat square: the
    # fresh bonus strip (rare pool, real winner skin) must contain no
    # RolldropTile — the stale-marker bug would show exactly one.
    poll_deadline = time.time() + 14
    samples = 0
    stale_hits = 0
    shot_taken = False
    while time.time() < poll_deadline:
        n = room.evaluate(
            "(() => { let bad = 0, covers = 0;"
            " for (const c of document.querySelectorAll('.rd-white-cover')) {"
            "  covers++;"
            "  bad += c.parentElement.querySelectorAll('img[src=\"/raredrop.png\"]').length;"
            " }"
            " return JSON.stringify({covers, bad}); })()"
        )
        state = json.loads(n)
        if state["covers"] > 0:
            samples += 1
            stale_hits += state["bad"]
            if not shot_taken:
                room.screenshot(path=str(SHOTS / "61-rd-bonus-spin.png"))
                shot_taken = True
        time.sleep(0.25)
    check("bonus reel sampled during the white cover", samples >= 8, f"samples={samples}")
    check(
        "CRITICAL: bonus reel never shows the raredrop art",
        samples > 0 and stale_hits == 0,
        f"stale raredrop imgs seen={stale_hits}",
    )

    # ---- 3. the flow still completes ------------------------------------------
    finished = False
    while time.time() - t0 < 120:
        low = room.inner_text("body").lower()
        if "victory" in low or "you win" in low or "wins" in low or "finished" in low:
            finished = True
            break
        time.sleep(1.0)
    check("room reached a finished state", finished)
    if finished:
        room.screenshot(path=str(SHOTS / "61-rd-done.png"))
    # clean the forced flag so later suites stay vanilla
    room.evaluate("localStorage.removeItem('rb-rolldrop-force')")
    browser.close()

# ---- scrub E2E data ----------------------------------------------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}});"
     " await db.drop.deleteMany({}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)

print("\n===== VERDICT =====")
fails = [r for r in results if not r[1]]
for name, ok, det in results:
    print(("PASS  " if ok else "FAIL  ") + name)
print("RESULT:", "ALL PASS" if not fails else "%d FAILURES" % len(fails))
sys.exit(0 if not fails else 1)
