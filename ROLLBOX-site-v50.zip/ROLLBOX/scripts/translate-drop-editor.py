# -*- coding: utf-8 -*-
# Translate ROLLBOX-drop-editor.html to Hebrew (full RTL UI), keep export protocol + data intact.
import io, sys

SRC = "/home/z/my-project/upload/ROLLBOX-drop-editor.html"
DST = "/home/z/my-project/download/ROLLBOX-drop-editor-HE.html"

with io.open(SRC, "r", encoding="utf-8") as f:
    t = f.read()

edits = []

def rep(old, new, count=1):
    edits.append((old, new, count))

# ---------- <html> + title ----------
rep('<html lang="en" dir="ltr">', '<html lang="he" dir="rtl">', 1)
rep('<title>ROLLBOX — DROP EDITOR (cases + terminals)</title>',
    '<title>ROLLBOX — עורך דרופים (קופסאות + טרמינלים)</title>', 1)

# ---------- CSS tweaks for RTL ----------
rep('#out{display:none;', '#out{direction:ltr; display:none;', 1)
rep('th{background:#161c26; color:var(--dim); font-size:11.5px; text-align:left;',
    'th{background:#161c26; color:var(--dim); font-size:11.5px; text-align:start;', 1)
rep('.dealerbtn{display:flex; align-items:center; gap:8px; text-align:left; padding:8px 10px}',
    '.dealerbtn{display:flex; align-items:center; gap:8px; text-align:start; padding:8px 10px}', 1)
rep('.sugg .it small{color:var(--dim); margin-left:auto}',
    '.sugg .it small{color:var(--dim); margin-inline-start:auto}', 1)
rep('input[type=number]{width:86px; text-align:left}',
    'input[type=number]{width:86px; text-align:center}', 1)
rep('.casehead .code{font:700 12px monospace;',
    '.casehead .code{direction:ltr; display:inline-block; font:700 12px monospace;', 1)
rep('input:disabled{opacity:.5; cursor:not-allowed}',
    'input:disabled{opacity:.5; cursor:not-allowed}\n'
    '  #cName,#tName,.nm input{direction:ltr; text-align:left}', 1)

# ---------- header ----------
rep('<h1>ROLLBOX — <b>DROP EDITOR</b> <span style="color:var(--dim); font-size:13px; font-weight:400">(every case + every terminal)</span></h1>',
    '<h1>ROLLBOX — <b>עורך דרופים</b> <span style="color:var(--dim); font-size:13px; font-weight:400">(כל קופסה + כל טרמינל)</span></h1>', 1)

rep('<button id="copyBtn" class="primary">Copy for chat</button>',
    '<button id="copyBtn" class="primary">העתקה לצ\u2019אט</button>', 1)
rep('<button id="dlBtn">Download txt</button>',
    '<button id="dlBtn">הורדה כקובץ txt</button>', 1)
rep('<button id="showBtn">Show what will be sent</button>',
    '<button id="showBtn">הצגת מה שיישלח</button>', 1)

rep('<div class="empty">Pick a case or a terminal from the list to edit its drops</div>',
    '<div class="empty">בחרו קופסה או טרמינל מהרשימה כדי לערוך את הדרופים</div>', 2)

# ---------- JS: shared ----------
rep('const DEFAULT_RD_PCT = 0.095;',
    'const DEFAULT_RD_PCT = 0.095;\n'
    'var GRP_LABEL = {standard:"סטנדרט", farm:"פארם", level:"יומי", test:"בדיקה"};', 1)
rep('esc(c.grp.toUpperCase())', 'esc(GRP_LABEL[c.grp] || c.grp.toUpperCase())', 1)
rep('$("#status").textContent = nc + " case(s) + " + nt + " terminal(s) changed";',
    '$("#status").textContent = "שונו: " + nc + " קופסאות + " + nt + " טרמינלים";', 1)

# nav group labels
rep('{key:"standard", label:"CASES — STANDARD"}', '{key:"standard", label:"קופסאות — סטנדרט"}', 1)
rep('{key:"farm", label:"CASES — FARM"}', '{key:"farm", label:"קופסאות — פארם"}', 1)
rep('{key:"level", label:"CASES — DAILY (LEVEL)"}', '{key:"level", label:"קופסאות — יומיות (LEVEL)"}', 1)
rep('{key:"test", label:"CASES — TEST"}', '{key:"test", label:"קופסאות — בדיקה"}', 1)
rep('{key:"term", label:"TERMINALS"}', '{key:"term", label:"טרמינלים"}', 1)

# nav button line: isolate LTR ids + the MIN/MAX summary from the RTL flow
rep("b.innerHTML = '<span class=\"dot ' + st + '\"></span><span style=\"flex:1; overflow:hidden\"><span style=\"font-family:monospace; font-size:11.5px\">' + esc(isTerm ? e.id : e.code) + '</span><br><small>' + esc(isTerm ? e.name : e.name) + '</small></span><small>' + esc(small) + '</small>';",
    "b.innerHTML = '<span class=\"dot ' + st + '\"></span><span style=\"flex:1; overflow:hidden\"><span dir=\"ltr\" style=\"font-family:monospace; font-size:11.5px\">' + esc(isTerm ? e.id : e.code) + '</span><br><small dir=\"ltr\">' + esc(isTerm ? e.name : e.name) + '</small></span><small dir=\"ltr\">' + esc(small) + '</small>';", 1)
rep('var small = isTerm ? ("MIN " + e.min + " · MAX " + e.max) : (e.kind === "level" ? "FREE · daily" : e.price + " coins");',
    'var small = isTerm ? ("MIN " + e.min + " · MAX " + e.max) : (e.kind === "level" ? "חינם · יומי" : e.price + " מטבעות");', 1)

# ---------- suggestion box ----------
rep("'<div class=\"none\">No catalog match — a free-name row is kept as-is</div>'",
    "'<div class=\"none\">אין התאמה בקטלוג — השורה נשמרת כשם חופשי</div>'", 1)

# ---------- case pane ----------
rep('disabled title="Daily case shell is system-owned — edit drops only"',
    'disabled title="מעטפת הקופסה היומית בבעלות המערכת — עריכת דרופים בלבד"', 1)
rep('placeholder="Case name"', 'placeholder="שם הקופסה"', 1)
rep('<label class="lbl" title="What a player pays for one opening">Price</label>',
    '<label class="lbl" title="מה השחקן משלם על פתיחה אחת">מחיר</label>', 1)
rep('<label class="lbl" title="Ultra-rare bonus drop chance per opening (site default 0.095%)">ROLLDROP %</label>',
    '<label class="lbl" title="סיכוי לדרופ בונוס אולטרה־נדיר בכל פתיחה (ברירת מחדל באתר: 0.095%)">ROLLDROP %</label>', 1)
rep("'<span class=\"subline\">Free daily vault — unlocks at Level ' + esc(c.lvl) + ' · refills every 24h · name &amp; price are system-owned</span>'",
    "'<span class=\"subline\">כספת יומית חינמית — נפתחת בדרגה ' + esc(c.lvl) + ' · מתחדשת כל 24 שעות · שם ומחיר בבעלות המערכת</span>'", 1)

rep("note.innerHTML = '<b>Chance (%)</b> is each skin\\'s drop probability — the column must sum to <b>100</b>. <b>Value</b> is the coins credited for the item at the selected wear; <b>~</b> marks a factor estimate (no market listing). Editing the value pins it; changing the wear re-computes it from the market table.';",
    "note.innerHTML = '<b>סיכוי (%)</b> הוא הסתברות הדרופ של כל סקין — העמודה חייבת להסתכם ל־<b>100</b>. <b>ערך</b> הוא המטבעות שהפריט מזכה בו בבלאי הנבחר; <b>~</b> מסמן הערכת פקטור (אין מחיר שוק). עריכת הערך נועלת אותו; שינוי הבלאי מחשב אותו מחדש מטבלאות המחירים.';", 1)

rep("'<span class=\"lbl\">Case math:</span>'", "'<span class=\"lbl\">חישוב קופסה:</span>'", 1)
rep("'<span class=\"lbl\">Cost</span>", "'<span class=\"lbl\">עלות</span>", 1)
rep("'<span class=\"lbl\">Average drop</span>", "'<span class=\"lbl\">ממוצע דרופ</span>", 1)
rep("'<span class=\"lbl\">House edge</span>", "'<span class=\"lbl\">יתרון הבית</span>", 1)
rep("'<span class=\"note\">Average drop = the value a random opening returns on average (sum of chance x value). House edge = (cost - average drop) / cost. Free daily cases have no cost — only the average is shown.</span>'",
    "'<span class=\"note\">ממוצע דרופ = הערך הממוצע שמחזירה פתיחה אקראית (סכום של סיכוי × ערך). יתרון הבית = (עלות − ממוצע דרופ) ÷ עלות. לקופסאות יומיות חינמיות אין עלות — מוצג רק הממוצע.</span>'", 1)

rep('>Normalize to 100</button>', '>נרמול ל־100</button>', 2)
rep('>+ Add skin</button>', '>+ הוספת סקין</button>', 2)
rep('title="Re-compute every value from the price tables (real price > site table > estimate)">Auto values</button>',
    'title="חישוב מחדש של כל הערכים מטבלאות המחירים (מחיר אמיתי > טבלת האתר > הערכה)">ערכים אוטומטיים</button>', 2)
rep('class="danger">Reset to original</button>', 'class="danger">איפוס למקור</button>', 2)

rep("'<thead><tr><th style=\"width:52%\">Skin — type to pick from the catalog (or free name)</th><th style=\"width:120px\">Wear</th><th>Value (coins)</th><th>Chance (%)</th><th></th></tr></thead><tbody id=\"cTbody\"></tbody>'",
    "'<thead><tr><th style=\"width:52%\">סקין — הקלידו כדי לבחור מהקטלוג (או שם חופשי)</th><th style=\"width:120px\">בלאי</th><th>ערך (מטבעות)</th><th>סיכוי (%)</th><th></th></tr></thead><tbody id=\"cTbody\"></tbody>'", 1)

rep('placeholder="Skin name"', 'placeholder="שם הסקין"', 2)
rep('disabled title="This item has no exterior"', 'disabled title="לפריט זה אין מצב חיצוני"', 1)
rep('"Estimated value — no market listing for this wear"', '"ערך מוערך — אין מחיר שוק לבלאי זה"', 2)
rep('title="Remove this skin"', 'title="הסרת הסקין"', 2)

# ---------- terminal pane ----------
rep('placeholder="Dealer name"', 'placeholder="שם הסוחר"', 1)
rep('<label class="lbl" title="Minimum purchase for a deal — what the player pays at least">MIN</label>',
    '<label class="lbl" title="מינימום רכישה לעסקה — מה שהשחקן משלם לפחות">MIN</label>', 1)
rep('<label class="lbl" title="Maximum purchase for one deal — the table values are priced at this">MAX</label>',
    '<label class="lbl" title="מקסימום רכישה לעסקה — ערכי הטבלה מתומחרים לפי זה">MAX</label>', 1)

rep("note.innerHTML = 'The values here are priced at <b>the dealer\\'s MAX</b> — at a smaller deal every offer scales by the same ratio. Each purchase shows one offer at a time (up to <b>5</b>): the player takes or refuses, and the fifth is final — so the <b>EV at MAX</b> is computed on the best of 5 (the worst-case scenario for the house).';",
    "note.innerHTML = 'הערכים כאן מתומחרים לפי <b>ה־MAX של הסוחר</b> — בעסקה קטנה יותר כל הצעה מתכווננת באותו יחס. כל רכישה מציגה הצעה אחת בכל פעם (עד <b>5</b>): השחקן מקבל או מסרב, והחמישית סופית — לכן ה־EV ב־MAX מחושב על הטובה מ־5 (תרחיש הגרוע ביותר עבור הבית).';", 1)

rep("'<span class=\"lbl\">Profit calculator:</span>'", "'<span class=\"lbl\">מחשבון רווח:</span>'", 1)
rep("'<span class=\"lbl\">EV at MAX deal (best of 5)</span>", "'<span class=\"lbl\">EV בעסקת MAX (הטובה מ־5)</span>", 1)
rep("'<span class=\"lbl\">Average single offer</span>", "'<span class=\"lbl\">ממוצע הצעה בודדת</span>", 1)
rep("'<span class=\"lbl\">House edge (vs EV)</span>", "'<span class=\"lbl\">יתרון הבית (מול EV)</span>", 1)
rep("'<span class=\"note\">Monte-Carlo over 5 distinct offers using your percentages. Recommended house edge: 5%-15% — a player who refuses a lot may take less, which only grows the edge.</span>'",
    "'<span class=\"note\">מונטה־קרלו על 5 הצעות שונות לפי האחוזים שהגדרתם. יתרון בית מומלץ: בין 5% ל־15% — שחקן שמסרב הרבה עשוי לקחת פחות, מה שרק מגדיל את היתרון.</span>'", 1)

rep("'<thead><tr><th style=\"width:55%\">Skin — type to pick from the catalog (or free name)</th><th>Value (coins) at MAX</th><th>Chance (%)</th><th></th></tr></thead><tbody id=\"tTbody\"></tbody>'",
    "'<thead><tr><th style=\"width:55%\">סקין — הקלידו כדי לבחור מהקטלוג (או שם חופשי)</th><th>ערך (מטבעות) ב־MAX</th><th>סיכוי (%)</th><th></th></tr></thead><tbody id=\"tTbody\"></tbody>'", 1)

# ---------- badges / misc ----------
rep('"SUM " + fmtPct(s)', '"סה״כ " + fmtPct(s)', 2)
rep('"— (free)"', '"— (חינם)"', 1)
rep('fmtCoins(ev) + " (no MAX)"', 'fmtCoins(ev) + " (ללא MAX)"', 1)
rep('"(nothing changed yet)"', '"(עדיין לא שונה כלום)"', 1)

# ---------- flash messages ----------
rep('flash(n ? "Re-computed " + n + " value(s) from the price tables" : "No catalog rows to re-compute");',
    'flash(n ? "חושבו מחדש " + n + " ערכים מטבלאות המחירים" : "אין שורות קטלוג לחישוב מחדש");', 2)
rep('flash("Restored to the original site values");', 'flash("שוחזר לערכי המקור של האתר");', 2)
rep('flash("Nothing changed yet");', 'flash("עדיין לא שונה כלום");', 2)
rep('flash("Copied — paste it into the chat");', 'flash("הועתק — הדביקו בצ\u2019אט");', 1)
rep('flash("Clipboard blocked — copy from the box below");', 'flash("ההעתקה נחסמה — העתיקו מהתיבה למטה");', 1)

# ---------- init line ----------
rep('if(el) el.textContent = uc + " real price names · updated " + (UNIFIED_AT ? new Date(UNIFIED_AT).toISOString().slice(0, 10) : "never") + " · 1$ = " + RATE + " coins";',
    'if(el) el.textContent = uc + " שמות עם מחיר אמיתי · עודכן " + (UNIFIED_AT ? new Date(UNIFIED_AT).toISOString().slice(0, 10) : "אף פעם") + " · שער: " + RATE + " מטבעות לדולר";', 1)

# ---------- apply + verify ----------
errors = []
for old, new, count in edits:
    found = t.count(old)
    if found != count:
        errors.append("COUNT MISMATCH (%d != %d): %r" % (found, count, old[:80]))
        continue
    t = t.replace(old, new)

# ---------- hint block (multi-line) ----------
start = t.find('<div class="hint">')
if start < 0:
    errors.append("hint block start not found")
else:
    end = t.find('</div>', start)
    if end < 0:
        errors.append("hint block end not found")
    else:
        hint_he = (
            '<div class="hint">\n'
            '    עורך עצמאי — שום דבר לא נשמר בשרת. כשתסיימו לחצו על <b>העתקה לצ\u2019אט</b> והדביקו את התוצאה חזרה בצ\u2019אט (או הורידו את קובץ ה־txt וצרפו אותו), והשינויים יוחלו על האתר.<br>\n'
            '    הקובץ הזה מכסה <b>כל קופסה באתר</b> — סטנדרט <b dir="ltr">RB-101..RB-120</b>, פארם <b dir="ltr">RB-201..RB-210</b>, את קופסאות ה־LEVEL היומיות החינמיות ואת קופסת ה־TEST — וגם את כל <b>חמשת הטרמינלים</b> (הסוחרים).<br>\n'
            '    <b>תפריט הסקינים (Task 27):</b> הקלידו בשדה השם כדי לחפש <b>כל סקין במשחק</b> — כולל גרסאות <b>StatTrak™</b> ו־<b>Souvenir</b> — והערך <b>מתמלא אוטומטית לפי בלאי</b> מטבלאות המחירים: קודם מחירים אמיתיים מ־<span dir="ltr">steamanalyst.com</span> (CSFLOAT) (<span id="unifiedCount">—</span>), אחר כך טבלאות השוק של האתר, ולבסוף הערכות פקטור (מסומנות ב־<b>~</b>). כפתור <b>ערכים אוטומטיים</b> מחשב טבלה שלמה בבת אחת.<br>\n'
            '    <b>קופסאות:</b> לכל סקין הגדירו את <b>סיכוי הדרופ (%)</b> — הטבלה חייבת להסתכם ל־100 — ואת <b>ערך המטבעות</b> שהפריט מזכה בו. <b>בלאי</b> קובע את המצב החיצוני (<span dir="ltr">FN / MW / FT / WW / BS</span>) — מוצעים רק הבלאים שבהם הסקין באמת קיים. <b>ROLLDROP</b> הוא סיכוי דרופ הבונוס האולטרה־נדיר לכל פתיחה (ברירת מחדל באתר: 0.095%).<br>\n'
            '    <b>קופסאות יומיות (LEVEL):</b> המעטפת (שם / מחיר / דרגת פתיחה) בבעלות המערכת — ערכו דרופים וערכים בלבד.<br>\n'
            '    <b>טרמינלים:</b> בחרו אילו סקינים כל סוחר מציע, הגדירו אחוזים (חייבים להסתכם ל־100) ואת הערך <b>בעסקת ה־MAX של הסוחר</b>; MIN ו־MAX ניתנים לעריכה כאן. רכישה מציגה עד <b>5 הצעות שונות</b> — השחקן לוקח אחת, וההצעה החמישית נכפית.\n'
            '  '
        )
        t = t[:start] + hint_he + t[end:]

if errors:
    for e in errors:
        print("FAIL:", e)
    sys.exit(1)

with io.open(DST, "w", encoding="utf-8") as f:
    f.write(t)

print("OK — wrote", DST, len(t), "bytes")
