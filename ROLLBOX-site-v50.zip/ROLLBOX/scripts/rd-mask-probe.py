#!/usr/bin/env python3
"""Task 146 probe: how far does the KEYED CONTENT of rolldrop.mp4 really
reach, per alpha level? The CSS mask on .rd-hit-video must stay OPAQUE out
past the strong content and feather only the faint haze. Reuses the exact
keying of rolldrop-keyout.py on representative frames."""

import cv2
import numpy as np

SRC = "/home/z/my-project/upload/rolldrop.mp4"
SEED_T, LOW_T, WHITE, BAND_ITER = 246.0, 150.0, 252.0, 4
POCKET_MIN, POCKET_WARM, POCKET_BRIGHT, POCKET_FLAT = 200, 4.0, 249.0, 2.2
CHECK = (0, 8, 15, 25, 35, 45, 55, 62, 68)

cap = cv2.VideoCapture(SRC)
frames = []
while True:
    ok, f = cap.read()
    if not ok:
        break
    frames.append(f)
cap.release()

kernel = np.ones((3, 3), np.uint8)
h, wpx = frames[0].shape[:2]
cx, cy = (wpx - 1) / 2.0, (h - 1) / 2.0
agg = {0.05: [0.0, 0.0], 0.3: [0.0, 0.0], 0.6: [0.0, 0.0], 0.9: [0.0, 0.0]}
for i, bgr in enumerate(frames):
    if i >= 69:
        break
    rgb = bgr[..., ::-1].astype(np.float64)
    w = rgb.min(axis=2)
    warmth = rgb[..., 0] - rgb[..., 2]
    seed = (w >= SEED_T).astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(seed, connectivity=4)
    border = np.unique(np.concatenate([labels[0, :], labels[-1, :], labels[:, 0], labels[:, -1]]))
    border_set = {int(b) for b in border if b != 0}
    bg = np.isin(labels, list(border_set))
    band = cv2.dilate(bg.astype(np.uint8), kernel, iterations=BAND_ITER).astype(bool) & ~bg
    a = np.ones_like(w)
    a[bg] = 0.0
    a[band] = np.clip((SEED_T - w[band]) / (SEED_T - LOW_T), 0.0, 1.0)
    for lab_id in range(1, n):
        if lab_id in border_set or stats[lab_id, cv2.CC_STAT_AREA] < POCKET_MIN:
            continue
        mask = labels == lab_id
        ws = w[mask]
        if abs(warmth[mask].mean()) >= POCKET_WARM:
            continue
        if ws.mean() < POCKET_BRIGHT or ws.std() > POCKET_FLAT:
            continue
        a[mask] = 0.0
    for th in agg:
        ys, xs = np.nonzero(a > th)
        if len(xs):
            agg[th][0] = max(agg[th][0], float(np.abs(xs - cx).max()))
            agg[th][1] = max(agg[th][1], float(np.abs(ys - cy).max()))
print(f"frame size {wpx}x{h}, half extents {wpx/2:.0f}x{h/2:.0f}")
for th, (dx, dy) in agg.items():
    print(
        f"alpha>{th:.2f}: dx={dx:5.0f}px ({dx/(wpx/2)*100:4.1f}% of half-w)  "
        f"dy={dy:5.0f}px ({dy/(h/2)*100:4.1f}% of half-h)"
    )
