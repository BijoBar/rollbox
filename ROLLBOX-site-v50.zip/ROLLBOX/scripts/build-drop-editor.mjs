// ============ build-drop-editor.mjs (Task 95) ============
// Builds the DROP EDITOR (ROLLBOX-drop-editor.html) — the single offline HTML
// file that edits EVERY case on the site:
//   1. SITE CASES   — all 21 standard (RB-101..120 + RB-TST) + 10 farm
//                     (RB-201..210): per-skin percent + coin value + exterior
//   2. DAILY VAULTS — the 10 free LEVEL 10..100 vaults: per-skin percent
//                     (prices always come from the global catalog on the site)
//   3. TERMINALS    — the 5 dealers: skins, percents, values, MIN/MAX
// The injected data is read straight out of the site's own TypeScript data
// layer with bun (no regex parsing = zero drift):
//   src/lib/cases.ts        CASES (merged: USER_CASES overlay + TEST + dailies)
//   src/lib/user-cases.ts   USER_CASES (which codes are user overlays)
//   src/lib/generated-wear-prices.ts  SKIN_WEAR_PRICES / SKIN_WEAR_AVAIL
//   src/lib/terminals.ts    TERMINALS (merged with USER_TERMINALS)
// It also writes scripts/drop-editor-base.json — the base shells the import
// script (scripts/import-cases.mjs) merges the ROLLBOX-CASES v1 export into.
//
// Run:  bun scripts/build-drop-editor.mjs
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const TPL = path.join(ROOT, "scripts", "terminal-editor.template.html");
const OUTS = [
  path.join(ROOT, "editor", "ROLLBOX-drop-editor.html"),
  path.join(ROOT, "ROLLBOX-drop-editor.html"),
  path.join(ROOT, "download", "ROLLBOX-drop-editor.html"),
];

const { CASES, SKINS } = await import(path.join(ROOT, "src/lib/cases.ts"));
const { USER_CASES } = await import(path.join(ROOT, "src/lib/user-cases.ts"));
const { SKIN_WEAR_PRICES, SKIN_WEAR_AVAIL } = await import(
  path.join(ROOT, "src/lib/generated-wear-prices.ts")
);
const { TERMINALS } = await import(path.join(ROOT, "src/lib/terminals.ts"));

const json = (o) => JSON.stringify(o);

// ---------- SITE CASES (standard + farm, TEST included, dailies excluded) ----------
const userCodes = new Set(USER_CASES.map((c) => c.code));
const siteCases = CASES.filter((c) => c.kind !== "level").map((c) => ({
  id: c.id,
  code: c.code,
  name: c.name,
  subtitle: c.subtitle,
  kind: c.kind,
  tierLabel: c.tierLabel,
  price: c.price,
  tierColor: c.tierColor,
  tierColor2: c.tierColor2,
  rolldropChance: c.rolldropChance ?? null,
  userOverlay: userCodes.has(c.code), // true = this case lives in user-cases.ts
  items: c.items.map((it) => ({
    id: it.skinId,
    v: it.value != null && Number.isFinite(it.value) ? it.value : null, // explicit override
    p: it.weight,
    w: it.wear ?? null,
  })),
}));
const casesLine = "const CASES = " + json(siteCases) + ";";

// ---------- DAILY VAULTS (LEVEL 10..100, merged with USER_DAILY_OVERRIDES) ----------
const dailies = CASES.filter((c) => c.kind === "level")
  .map((c) => ({
    id: c.id,
    tier: c.requiredLevel ?? 0,
    items: c.items.map((it) => [it.skinId, it.weight]), // already normalized to 100
  }))
  .sort((a, b) => a.tier - b.tier);
if (dailies.length !== 10) throw new Error(`expected 10 daily vaults, got ${dailies.length}`);
const dailyLine = "const DAILY_CASES = " + json(dailies) + ";";

// ---------- TERMINALS (merged with USER_TERMINALS overlay) ----------
const terminals = TERMINALS.map((t) => ({
  id: t.id,
  name: t.name,
  min: t.min,
  max: t.max,
  skins: t.skins.map((s) => ({ id: s.id ?? null, n: s.n, v: s.v, p: s.p })),
}));
const termLine = "const BASE_TERMINALS = " + json(terminals) + ";";

// ---------- catalog (every skin the site knows: name / coin value / rarity) ----------
const catalog = {};
for (const [id, s] of Object.entries(SKINS)) {
  catalog[id] = { n: s.name, v: s.value, r: s.rarity };
}
const skinsLine = "const SKINS = " + json(catalog) + ";";
const wpLine = "const WEAR_PRICES = " + json(SKIN_WEAR_PRICES ?? {}) + ";";
const availLine = "const WEAR_AVAIL = " + json(SKIN_WEAR_AVAIL ?? {}) + ";";

// ---------- base shells for scripts/import-cases.mjs ----------
fs.writeFileSync(
  path.join(ROOT, "scripts", "drop-editor-base.json"),
  json({
    generatedAt: new Date().toISOString().slice(0, 10),
    cases: siteCases.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      subtitle: c.subtitle,
      kind: c.kind,
      tierLabel: c.tierLabel,
      price: c.price,
      tierColor: c.tierColor,
      tierColor2: c.tierColor2,
      rolldropChance: c.rolldropChance,
      userOverlay: c.userOverlay,
      items: c.items,
    })),
    skins: catalog,
  })
);

// ---------- inject into the template ----------
const tpl = fs.readFileSync(TPL, "utf8");
if (!tpl.includes("//__SKINS_LINE__")) throw new Error("template placeholders missing — check terminal-editor.template.html");
const out = tpl
  .replace("//__SKINS_LINE__", skinsLine)
  .replace("//__WEARPRICES_LINE__", wpLine)
  .replace("//__AVAIL_LINE__", availLine)
  .replace("//__CASES_LINE__", casesLine)
  .replace("//__DAILY_LINE__", dailyLine)
  .replace("//__TERM_LINE__", termLine);

for (const outPath of OUTS) {
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, out);
  console.log(`wrote ${path.relative(ROOT, outPath)} (${(out.length / 1024).toFixed(0)} KB)`);
}
console.log(
  `cases: ${siteCases.length} (${siteCases.filter((c) => c.kind === "standard").length} standard / ${siteCases.filter((c) => c.kind === "farm").length} farm), ` +
  `user overlays: ${siteCases.filter((c) => c.userOverlay).length}, ` +
  `dailies: ${dailies.length}, terminals: ${terminals.length}, catalog skins: ${Object.keys(catalog).length}`
);
