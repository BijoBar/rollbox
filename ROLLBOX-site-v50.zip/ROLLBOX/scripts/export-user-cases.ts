/**
 * export-user-cases.ts — src/lib/user-cases.ts → scripts/user-cases-spec.jsonl
 *
 * The reverse direction of import-user-cases.mjs: turns the USER_CASES data
 * the site runs on back into the CASE EDITOR JSONL dialect (one JSON case per
 * line: {"code","name","price","kind","rd","items":[{"n","v","p","w"}]} —
 * n = skin name, v = value in Rollboxcoins, p = weight %, w = CS2 exterior,
 * w omitted when the item has no exterior (stickers), rd = ROLLDROP chance
 * as a fraction or null for the site default).
 *
 * Run:  bun scripts/export-user-cases.ts
 */
import { writeFileSync } from "node:fs";
import { USER_CASES } from "../src/lib/user-cases";
import { SKINS, caseItemValue } from "../src/lib/cases";

interface EditorItem {
  n: string;
  v: number;
  p: number;
  w?: string;
}

const lines: string[] = [];
for (const c of USER_CASES) {
  const items: EditorItem[] = c.items.map((it) => {
    const skin = SKINS[it.skinId];
    const entry: EditorItem = {
      n: skin?.name ?? it.skinId,
      v: it.value ?? caseItemValue(it),
      p: it.weight,
    };
    if (it.wear) entry.w = it.wear;
    return entry;
  });
  lines.push(
    JSON.stringify({
      code: c.code,
      name: c.name,
      price: c.price,
      kind: c.kind,
      rd: c.rolldropChance ?? null,
      items,
    }),
  );
}

const out = lines.join("\n") + "\n";
const url = new URL("./user-cases-spec.jsonl", import.meta.url);
writeFileSync(url, out);

// ---- sanity report -------------------------------------------------------
const totalItems = USER_CASES.reduce((s, c) => s + c.items.length, 0);
const badSums = USER_CASES.filter((c) => {
  const t = c.items.reduce((s, i) => s + i.weight, 0);
  return Math.abs(t - 100) > 1e-6;
}).map((c) => `${c.code}=${c.items.reduce((s, i) => s + i.weight, 0)}`);
const unknownSkins = USER_CASES.flatMap((c) => c.items).filter((i) => !SKINS[i.skinId]);
console.log(`exported ${USER_CASES.length} cases / ${totalItems} items → ${url.pathname}`);
console.log(`weight sums != 100: ${badSums.length ? badSums.join(" ") : "none"}`);
console.log(`skins missing from registry: ${unknownSkins.length ? unknownSkins.map((i) => i.skinId).join(", ") : "none"}`);
