// Validates src/lib/level-cases.ts: every skinId exists, weights normalize to
// 100, and prints the EV per case for a quick economy sanity check.
import { SKINS, caseItemValue } from "../src/lib/cases";
import { LEVEL_CASES, dailyCaseTierOf, unlockedDailyCases } from "../src/lib/level-cases";

let bad = 0;
for (const c of LEVEL_CASES) {
  const total = c.items.reduce((s, i) => s + i.weight, 0);
  const ev = c.items.reduce((s, i) => s + caseItemValue(i) * (i.weight / total), 0);
  const sorted = [...c.items].sort((a, b) => caseItemValue(b) - caseItemValue(a));
  const top = caseItemSkin0(sorted[0].skinId);
  const missing = c.items.filter((i) => !SKINS[i.skinId]);
  if (missing.length) {
    bad++;
    console.log(`${c.name}: MISSING SKINS -> ${missing.map((m) => m.skinId).join(", ")}`);
  }
  console.log(
    `${c.name.padEnd(10)} items=${String(c.items.length).padStart(2)} weightTotal=${total.toFixed(2).padStart(6)} EV=${ev.toFixed(1).padStart(7)} top=${top}`
  );
}

function caseItemSkin0(id: string) {
  const s = SKINS[id];
  return s ? `${s.name} (${s.value})` : id;
}

// helper coverage checks
console.log("---");
console.log("tier(7) =", dailyCaseTierOf(7), "| tier(10) =", dailyCaseTierOf(10), "| tier(47) =", dailyCaseTierOf(47), "| tier(100) =", dailyCaseTierOf(100), "| tier(140) =", dailyCaseTierOf(140));
for (const lv of [7, 10, 19, 47, 50, 99, 100, 130]) {
  const ids = unlockedDailyCases(lv).map((c) => c.name).join(",");
  console.log(`unlockedDailyCases(${lv}) -> [${ids}]`);
}
console.log(bad === 0 ? "ALL OK" : `${bad} CASES WITH MISSING SKINS`);
