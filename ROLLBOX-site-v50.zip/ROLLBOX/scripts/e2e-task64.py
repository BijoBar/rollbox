"""Task 64 E2E — the site is 100% SERVER-AUTHORITATIVE and REALTIME.

Proves with two cookie-forged sessions (real signed-in players, no backdoors):
  A. /login is STEAM-ONLY (Steam present, Google gone, google routes 404).
  B. REALTIME push: an SSE subscriber to /api/realtime/stream receives
     "battles" the moment player A creates a battle from ANOTHER connection,
     "battle" twice (start + settle) after bots fill the room, and "drop" +
     "player" (targeted balance) when player B opens a case.
  C. The ticker-settled battle finishes ON THE SERVER and pays: the winner's
     ledger carries battle_entry (-entry) and battle_win (+pot) rows.
  D. INVENTORY is server-priced: buy charges the CATALOG value (never a client
     number), unknown ids are rejected, sells of fake uids are rejected, and a
     real sell credits exactly the stored value — every move in the ledger.
  E. The money LEDGER API returns the full signed audit trail.
"""
import json
import queue
import subprocess
import threading
import time
from pathlib import Path

import requests
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = Path("/home/z/my-project/download/e2e-shots")
SHOTS.mkdir(parents=True, exist_ok=True)
results = []


def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS  " if ok else "FAIL  ") + name + ("  — " + detail if detail else ""))


# ---- SSE mini-client (background reader -> queue) --------------------------
class SSEClient:
    def __init__(self, timeout=60):
        self.events = queue.Queue()
        self.seen = []
        self._stop = False

        def run():
            try:
                import http.client

                conn = http.client.HTTPConnection("localhost", 3000, timeout=timeout)
                conn.request("GET", "/api/realtime/stream", headers={"Accept": "text/event-stream"})
                resp = conn.getresponse()
                event = None
                while not self._stop:
                    line = resp.fp.readline()
                    if not line:
                        break
                    text = line.decode("utf-8", "replace").rstrip("\n")
                    if text.startswith("event: "):
                        event = text[7:].strip()
                    elif text.startswith("data: ") and event:
                        self.events.put((event, text[6:]))
                        self.seen.append(event)
                        event = None
            except Exception:
                pass

        threading.Thread(target=run, daemon=True).start()

    def next_event(self, want, timeout=8):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                ev, data = self.events.get(timeout=0.5)
                if ev == want:
                    return json.loads(data) if data else {}
            except queue.Empty:
                continue
        return None


# ---- mint two real DB sessions + clean the world ---------------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
out = subprocess.run(
    ["bun", "scripts/mint-session.mjs"], capture_output=True, text=True, cwd="/home/z/my-project"
).stdout.strip().splitlines()
A, B = json.loads(out[0]), json.loads(out[1])
print(f"sessions: A={A['name']}({A['id']}) B={B['name']}({B['id']})")

sA = requests.Session()
sB = requests.Session()
sA.cookies.set("rb_session", A["token"])
sB.cookies.set("rb_session", B["token"])

cheapest = min(requests.get(BASE + "/skins-catalog.json", timeout=30).json(), key=lambda e: e["v"])

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--disable-background-timer-throttling", "--disable-renderer-backgrounding"])

    # ---- A. STEAM-ONLY login ------------------------------------------------
    pg = browser.new_context(viewport={"width": 1440, "height": 900}).new_page()
    pg.goto(BASE + "/login", wait_until="domcontentloaded")
    pg.wait_for_timeout(1200)
    body = pg.inner_text("body")
    check("A1 login shows the STEAM button", "SIGN IN WITH STEAM" in body.upper())
    check("A2 login has NO Google anywhere", "GOOGLE" not in body.upper())
    check("A3 login shows the $5 first-login bonus", "$5" in body)
    r404 = pg.request.get(BASE + "/api/auth/google/start")
    check("A4 google auth routes removed", r404.status in (404, 405), f"status={r404.status}")
    rex = requests.post(BASE + "/api/exchange", json={"credit": 999}, timeout=10)
    check("A5 the client-priced /api/exchange hole is CLOSED", rex.status_code in (404, 405), f"status={rex.status_code}")
    pg.screenshot(path=str(SHOTS / "64-login-steam-only.png"))
    pg.close()

    # ---- B. REALTIME push channel -------------------------------------------
    sse = SSEClient()
    time.sleep(1.0)  # let the stream attach
    created = sA.post(BASE + "/api/gbattles", json={
        "type": "1v1", "mode": "standard", "potRule": "winner",
        "rounds": ["asiimov-protocol"], "fast": True,
    }, timeout=15).json()
    got_battles = sse.next_event("battles", timeout=6)
    check("B1 'battles' pushed on create (cross-connection)", got_battles is not None)

    # bots fill the room -> the server rolls + starts, then settles the clock
    room_id = created.get("id")
    bots = sA.post(BASE + f"/api/gbattles/{room_id}/bots", timeout=15)
    got_start = sse.next_event("battle", timeout=6)
    check("B2 'battle' pushed the moment the room starts", got_start is not None)

    # B opens a case on a THIRD connection -> 'drop' + targeted 'player'
    opened = sB.post(BASE + "/api/open", json={"caseId": "asiimov-protocol", "count": 1}, timeout=20)
    check("B3 solo open charged+rolled on the server", opened.status_code == 200 and "pulls" in opened.json())
    ev_player = sse.next_event("player", timeout=6)
    ev_drop = sse.next_event("drop", timeout=6)
    check("B4 targeted 'player' balance push arrived", ev_player is not None and ev_player.get("playerId") == B["id"],
          json.dumps(ev_player) if ev_player else "none")
    check("B5 'drop' pushed for the worldwide live feed", ev_drop is not None and ev_drop.get("skinId"))

    # ---- C. the ticker settles ON THE SERVER --------------------------------
    deadline = time.time() + 30
    status = None
    while time.time() < deadline:
        row = requests.get(BASE + f"/api/gbattles/{room_id}", timeout=10).json().get("battle") or {}
        status = row.get("status")
        if status == "finished":
            break
        time.sleep(1.0)
    check("C1 server settled the battle on its own clock", status == "finished", f"status={status}")
    got_settle = sse.next_event("battle", timeout=8)
    check("C2 'battle' pushed on the settle flip", got_settle is not None)

    # ---- D+E. LEDGER + SERVER-PRICED INVENTORY ------------------------------
    ledA = sA.get(BASE + "/api/ledger", timeout=10).json()["ledger"]
    kindsA = [r["kind"] for r in ledA]
    entry_row = next((r for r in ledA if r["kind"] == "battle_entry"), None)
    win_row = next((r for r in ledA if r["kind"] == "battle_win"), None)
    check("D1 battle_entry row (-entry) in A's ledger", entry_row is not None and entry_row["amount"] < 0,
          json.dumps(entry_row) if entry_row else "none")
    # D2 made DETERMINISTIC: the server draws the winner and a bot CAN take the
    # pot (correct house behavior — the bot haul can beat the human's). The
    # ledger must simply match THE SERVER'S DRAW, whichever way it went.
    winner_ids = row.get("winnerIds") or []
    a_won = A["id"] in winner_ids
    if a_won:
        check("D2 A won the server draw -> battle_win (+exact pot) in A's ledger",
              win_row is not None and win_row["amount"] > 0 and win_row["amount"] == (row.get("potTotal") or 0),
              f"win={json.dumps(win_row)} pot={row.get('potTotal')}")
    else:
        check("D2 bot won the server draw -> NO battle_win row for A (pot went to the bot)",
              win_row is None,
              json.dumps(win_row) if win_row else "none (correct)")

    cat_v = cheapest["v"]
    buy = sB.post(BASE + "/api/inventory", json={"entryId": cheapest["id"]}, timeout=15).json()
    check("D3 buy charged the SERVER catalog price", buy.get("item", {}).get("v") == cat_v, f"item v={buy.get('item', {}).get('v')} want={cat_v}")
    uid = buy.get("item", {}).get("uid")

    hack = sB.post(BASE + "/api/inventory", json={"entryId": "totally-made-up-item", "cost": 1}, timeout=15)
    check("D4 unknown entry id rejected (no client pricing)", hack.status_code == 400, f"status={hack.status_code}")

    inv = sB.get(BASE + "/api/inventory", timeout=10).json()["items"]
    check("D5 GET inventory mirrors the DATABASE", any(i.get("uid") == uid for i in inv))

    bad_sell = sB.post(BASE + "/api/inventory/sell", json={"uids": ["i_not_yours"]}, timeout=10)
    check("D6 selling a uid you do not own is rejected", bad_sell.status_code == 400, f"status={bad_sell.status_code}")

    sell = sB.post(BASE + "/api/inventory/sell", json={"uids": [uid]}, timeout=10).json()
    check("D7 sell credited exactly the stored value", sell.get("credit") == cat_v, f"credit={sell.get('credit')} want={cat_v}")

    ledB = sB.get(BASE + "/api/ledger", timeout=10).json()["ledger"]
    kindsB = [r["kind"] for r in ledB]
    check("E1 B's ledger holds the full signed trail", "trade_buy" in kindsB and "trade_sell" in kindsB and "open_entry" in kindsB and "open_win" in kindsB,
          ",".join(kindsB[:6]))

    # ---- screenshots: profile ledger ---------------------------------------
    pgb = browser.new_context(viewport={"width": 1440, "height": 1000})
    pgb.add_cookies([{"name": "rb_session", "value": B["token"], "url": BASE}])
    pb = pgb.new_page()
    pb.goto(BASE + "/profile", wait_until="domcontentloaded")
    pb.wait_for_timeout(2500)
    prof = pb.inner_text("body")
    check("E2 profile shows the Money ledger section", "MONEY" in prof.upper() and "LEDGER" in prof.upper())
    check("E3 ledger rows render with server labels", "TRADE" in prof.upper() or "BATTLE" in prof.upper() or "CASE" in prof.upper())
    pb.screenshot(path=str(SHOTS / "64-profile-ledger.png"))
    pgb.close()
    browser.close()

# ---- cleanup: leave the shipped DB spotless --------------------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.drop.deleteMany({}); await db.ledger.deleteMany({}); await db.inventoryItem.deleteMany({}); "
     "await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); "
     "await db.counter.updateMany({data:{value:0}}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)

fails = [n for n, ok, _ in results if not ok]
print(f"\ne2e-task64: {len(results) - len(fails)}/{len(results)} PASS" + (f"  FAILURES: {fails}" if fails else "  — ALL PASS"))
sys_exit = 1 if fails else 0
raise SystemExit(sys_exit)
