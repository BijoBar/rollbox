"""Task 48 E2E (updated for the shared-world architecture) — the ORIGINAL
battle experience is intact and GLOBAL BATTLE remnants stay gone.

Checks:
  A. /battles lobby (guest): NO "GLOBAL"/"LIVE MULTIPLAYER" remnants; the
     stats strip, the CREATE BATTLE CTA and the empty state render. The room
     list is server-backed now — JOIN appears as soon as a battle exists.
  B. /battles/new guest gate: guests see "Sign in first" (the server charges
     entries, so creation needs an identity).
  C. Signed-in original flow: the session loads in the original builder, the
     TEST case is added via the aria-labelled picker tile, Create ->
     /battles/<id>, the room waits, Call Bots fills the seat, rounds roll,
     finished state renders, the DB balance moves by the EXACT pot rule
     (winner takes the sum of all pulls), no global remnants in the room.
  D. The lobby then renders the live room with a JOIN action.
  E. Deleted Task-47 surfaces really are gone: /api/battles/rooms 404,
     /battles/friend/new 404.
"""
import json
import subprocess
import sys
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = Path("/home/z/my-project/download/e2e-shots")
SHOTS.mkdir(parents=True, exist_ok=True)
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS  " if ok else "FAIL  ") + name + ("  — " + detail if detail else ""))

# ---- mint ONE real DB session + clean the world ---------------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
out = subprocess.run(
    ["bun", "scripts/mint-session.mjs"], capture_output=True, text=True, cwd="/home/z/my-project"
).stdout.strip().splitlines()
A = json.loads(out[0])
print(f"session: A={A['name']}({A['id']})")

def wait_daily_settled(ctx, timeout=45):
    """Waits until the +300 daily bonus has landed (balance stabilizes above
    the 1300 start) so entry-charge math is exact."""
    deadline = time.time() + timeout
    bal = None
    while time.time() < deadline:
        bal = ctx.request.get(BASE + "/api/auth/me").json()["player"]["balance"]
        if bal != 1300:  # daily (+300) claimed
            return bal
        time.sleep(1.0)
    return bal  # daily never came (already claimed earlier today) — take it as-is

with sync_playwright() as pw:
    browser = pw.chromium.launch()

    # ---- A. guest lobby: no GLOBAL BATTLE remnants, structure renders -----
    gctx = browser.new_context(viewport={"width": 1440, "height": 900})
    page = gctx.new_page()
    page.goto(BASE + "/battles", wait_until="domcontentloaded")
    page.wait_for_timeout(2500)
    body = page.inner_text("body").upper()
    check("lobby has NO 'GLOBAL'", "GLOBAL" not in body, "GLOBAL BATTLE remnants visible" if "GLOBAL" in body else "")
    check("lobby has NO 'LIVE MULTIPLAYER'", "LIVE MULTIPLAYER" not in body)
    check("lobby hero renders", "CASE" in body and "BATTLES" in body)
    check("lobby create CTA renders", "CREATE BATTLE" in body)
    check("lobby empty state renders", "NO BATTLES" in body, "fresh world should say no battles yet")
    page.screenshot(path=str(SHOTS / "48-lobby.png"))

    # ---- B. guest creator gate ---------------------------------------------
    page.goto(BASE + "/battles/new", wait_until="domcontentloaded")
    page.wait_for_timeout(2000)
    body = page.inner_text("body")
    check("creator says 'Create Battle'", "Create Battle" in body, "button text changed")
    check("creator has NO 'Global'", "Global" not in body)
    # the picker works for guests — add TEST so Create enables (guest balance is local)
    page.get_by_role("button", name="Add a case to the battle").click(timeout=4000)
    page.wait_for_timeout(600)
    page.get_by_role("button", name="Add TEST, price $10").click(timeout=4000)
    page.wait_for_timeout(400)
    page.keyboard.press("Escape")
    page.wait_for_timeout(500)
    # the guest gate is invisible in the design: Create as a guest -> straight to sign-in
    page.locator("button:has-text('Create Battle')").first.click()
    try:
        page.wait_for_url("**/login**", timeout=10000)
        check("guest Create routes to sign-in", True)
    except Exception:
        check("guest Create routes to sign-in", False, "url=" + page.url)
    page.screenshot(path=str(SHOTS / "48-create.png"))

    # ---- C. signed-in original flow ----------------------------------------
    ctxA = browser.new_context(viewport={"width": 1440, "height": 900})
    ctxA.add_cookies([{"name": "rb_session", "value": A["token"], "url": BASE}])
    room = ctxA.new_page()
    room.goto(BASE + "/battles/new", wait_until="domcontentloaded")
    try:
        room.wait_for_selector("button:has-text('Create Battle')", timeout=15000)
        check("A's session loaded in the builder", True)
    except Exception:
        check("A's session loaded in the builder", False)
    base_bal = wait_daily_settled(ctxA)

    # open the case picker via the ADD CASE slot, add TEST (aria-labelled
    # tile), close the dialog, then create the battle
    try:
        room.get_by_role("button", name="Add a case to the battle").click(timeout=4000)
        room.wait_for_timeout(600)
        room.get_by_role("button", name="Add TEST, price $10").click(timeout=4000)
        room.wait_for_timeout(400)
        check("TEST case added via picker", True)
        room.keyboard.press("Escape")
        room.wait_for_timeout(500)
    except Exception as e:
        check("TEST case added via picker", False, str(e)[:120])

    try:
        room.locator("button:has-text('Create Battle')").first.click(timeout=4000)
    except Exception as e:
        check("Create Battle clickable", False, str(e)[:120])

    new_id = ""
    deadline = time.time() + 12
    while time.time() < deadline:
        seg = room.url.rstrip("/").split("/")[-1]
        if seg != "new" and "/battles/" in room.url:
            new_id = seg
            break
        time.sleep(0.3)
    if not new_id:
        # hydration-proof fallback: read the newest waiting battle id from the API
        r = ctxA.request.get(BASE + "/api/gbattles")
        lst = r.json().get("battles", [])
        if lst:
            new_id = lst[0]["id"]
            room.goto(BASE + "/battles/" + new_id, wait_until="domcontentloaded")
    check("navigated into room", bool(new_id), "id=" + (new_id or "?"))
    me_after_create = ctxA.request.get(BASE + "/api/auth/me").json()["player"]
    check("DB entry charged on create", me_after_create["balance"] == base_bal - 10,
          f"bal={me_after_create['balance']} want={base_bal - 10}")

    # ---- D. the shared lobby renders the WAITING room with a JOIN action --
    # (finished rooms are dropped from the list by design, so this runs while
    # the room still waits — exactly what another player would see)
    page.goto(BASE + "/battles", wait_until="domcontentloaded")
    page.wait_for_timeout(2500)
    lob = page.inner_text("body")
    from_api = gctx.request.get(BASE + "/api/gbattles").json().get("battles", [])
    # the restored rows no longer print codes — the shared list is proven by
    # the server API containing THIS battle (the JOIN check covers the UI)
    check("lobby lists the battle (shared world)", any(b["id"] == new_id for b in from_api),
          "in list=" + str(any(b["id"] == new_id for b in from_api)))
    check("lobby shows a JOIN/WATCH action", ("JOIN" in lob.upper()) or ("WATCH" in lob.upper()))
    page.screenshot(path=str(SHOTS / "48-lobby-live.png"))
    page.goto(BASE + "/battles", wait_until="domcontentloaded")  # leave the list before resolving

    # the room waits for seats — then Call Bots fills and resolves it
    room.wait_for_timeout(2200)
    try:
        cb = room.locator("button:has-text('Call Bots')").first
        cb.wait_for(state="visible", timeout=15000)
        cb.click(timeout=4000)
        check("Call Bots pressed", True)
    except Exception as e:
        check("Call Bots pressed", False, str(e)[:120])

    deadline = time.time() + 120
    finished = False
    rolling = False
    while time.time() < deadline:
        txt = room.inner_text("body")
        if not rolling and ("ROUND 1" in txt.upper() or "ROUND 2" in txt.upper()):
            rolling = True
            room.screenshot(path=str(SHOTS / "48-rolling.png"))
        low = txt.lower()
        if ("winner" in low and ("you win" in low or "wins" in low)) or "finished" in low or "victory" in low:
            finished = True
            break
        time.sleep(1.0)
    check("room reached a finished state", finished, "no winner/finish banner within 120s" if not finished else "")
    check("rounds actually rolled", rolling)
    if finished:
        room.screenshot(path=str(SHOTS / "48-done.png"))
        low = room.inner_text("body").lower()
        check("room has NO global remnants", "global" not in low)

        # exact DB ledger: winner takes the pot == sum of ALL pull values
        me = ctxA.request.get(BASE + "/api/auth/me").json()["player"]
        bv = ctxA.request.get(BASE + f"/api/gbattles/{new_id}").json()["battle"]
        pot = sum(r["total"] for r in (bv.get("results") or []))
        won = A["id"] in (bv.get("winnerIds") or [])
        want = base_bal - 10 + (pot if won else 0)
        check("DB balance moved by the exact pot rule", me["balance"] == want,
              f"bal={me['balance']} want={want} pot={pot} won={won}")
        check("winnerIds published", won or len(bv.get("winnerIds") or []) > 0)
    else:
        # keep the ledger count stable even on a failed finish
        check("DB balance moved by the exact pot rule", False, "no finished state to verify against")
        check("winnerIds published", False, "no finished state to verify against")

    # ---- E. deleted surfaces -----------------------------------------------
    r = ctxA.request.get(BASE + "/api/battles/rooms")
    check("GET /api/battles/rooms -> 404", r.status == 404, "status=%d" % r.status)
    resp = page.goto(BASE + "/battles/friend/new", wait_until="domcontentloaded")
    check("/battles/friend/new -> 404", resp is not None and resp.status == 404, "status=%s" % (resp.status if resp else "?"))

    browser.close()

# ---- scrub E2E data from the DB -------------------------------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); await db.drop.deleteMany({}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)

print("\n===== VERDICT =====")
fails = [r for r in results if not r[1]]
for name, ok, det in results:
    print(("PASS  " if ok else "FAIL  ") + name)
print("RESULT:", "ALL PASS" if not fails else "%d FAILURES" % len(fails))
sys.exit(0 if not fails else 1)
