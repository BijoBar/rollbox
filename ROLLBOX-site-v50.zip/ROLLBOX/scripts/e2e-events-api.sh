#!/usr/bin/env bash
# EVENTS E2E (API layer) — Emerald Drop case, wager board, community+event battles.
# Uses the minted p_t66A session; read-only against players (count must stay 9).
set -u
BASE="http://localhost:3000"
TOKEN="$1"
C="Cookie: rb_session=$TOKEN"
J="Content-Type: application/json"
PASS=0; FAIL=0
ck() { # ck <desc> <expected> <actual>
  if [ "$2" = "$3" ]; then PASS=$((PASS+1)); echo "PASS  $1";
  else FAIL=$((FAIL+1)); echo "FAIL  $1 (expected [$2] got [$3])"; fi
}

echo "== 1. GET /api/event (public shape) =="
R=$(curl -s $BASE/api/event)
ACTIVE=$(echo "$R" | python3 -c "import sys,json;print(json.load(sys.stdin)['active'])")
PRIZES=$(echo "$R" | python3 -c "import sys,json;print(json.load(sys.stdin)['prizes'])")
ENDS=$(echo "$R" | python3 -c "import sys,json;print(json.load(sys.stdin)['endsAt'])")
ck "active true"  "True"  "$ACTIVE"
ck "prize ladder" "[50, 40, 30, 20, 10]" "$PRIZES"
ck "endsAt set"   "1791061200000" "$ENDS" # 2026-10-03T21:00:00Z

echo "== 2. baseline =="
ME=$(curl -s -H "$C" $BASE/api/auth/me)
BAL0=$(echo "$ME" | python3 -c "import sys,json;print(json.load(sys.stdin)['player']['balance'])")
echo "baseline balance: $BAL0"

echo "== 3. open the EVENT case (count 2) =="
O=$(curl -s -H "$C" -H "$J" -d '{"caseId":"event-emerald-drop","count":2}' $BASE/api/open)
OK=$(echo "$O" | python3 -c "import sys,json;print('pulls' in json.load(sys.stdin))")
ck "open 200 with pulls" "True" "$OK"
PID=$(echo "$O" | python3 -c "import sys,json;print(json.load(sys.stdin).get('pendingId',''))")
BAL1=$(echo "$O" | python3 -c "import sys,json;print(json.load(sys.stdin)['balance'])")
ck "charged 22.64" "$(python3 -c "print(round($BAL0-22.64,2))")" "$BAL1"

echo "== 4. claim the pending win =="
CL=$(curl -s -H "$C" -H "$J" -d "{\"pendingId\":\"$PID\"}" $BASE/api/open/claim)
COK=$(echo "$CL" | python3 -c "import sys,json;print('balance' in json.load(sys.stdin))")
ck "claim ok" "True" "$COK"

echo "== 5. board shows the wager =="
E=$(curl -s -H "$C" $BASE/api/event)
MYW=$(echo "$E" | python3 -c "import sys,json;m=json.load(sys.stdin)['me'];print(m['wagered'] if m else 'none')")
MYO=$(echo "$E" | python3 -c "import sys,json;m=json.load(sys.stdin)['me'];print(m['opened'] if m else 'none')")
MYR=$(echo "$E" | python3 -c "import sys,json;m=json.load(sys.stdin)['me'];print(m['rank'] if m else 'none')")
ck "wagered 22.64"  "22.64" "$MYW"
ck "opened 2"       "2"     "$MYO"
ck "rank 1"         "1"     "$MYR"
TOPW=$(echo "$E" | python3 -c "import sys,json;print(json.load(sys.stdin)['leaderboard'][0]['wagered'])")
ck "leaderboard row" "22.64" "$TOPW"

echo "== 6. publish a community case =="
CC=$(curl -s -H "$C" -H "$J" -d '{"name":"E2E Battle Crate","design":"yellow","items":[{"skinId":"ak-47-crossfade","weight":60},{"skinId":"sticker-fade-lethal","weight":40}]}' $BASE/api/community-cases)
CCID=$(echo "$CC" | python3 -c "import sys,json;print(json.load(sys.stdin).get('id',''))")
CCPRICE=$(echo "$CC" | python3 -c "import sys,json;print(json.load(sys.stdin).get('price',0))")
echo "community case: $CCID price $CCPRICE"
if [ -n "$CCID" ]; then PASS=$((PASS+1)); echo "PASS  community case created"; else FAIL=$((FAIL+1)); echo "FAIL  community case created"; fi
GTE1=$(python3 -c "print(1 if $CCPRICE>=1.74 else 0)")
ck "community price sane (EV 1.48/0.85=1.74+)" "1" "$GTE1"

echo "== 7. community-cases API carries items =="
CCAPI=$(curl -s $BASE/api/community-cases)
HASITEMS=$(echo "$CCAPI" | python3 -c "import sys,json;cs=json.load(sys.stdin)['cases'];print(any('items' in c and len(c['items'])==2 for c in cs if c['id']=='$CCID'))")
ck "items in API" "True" "$HASITEMS"

echo "== 8. battle with EVENT + COMMUNITY rounds =="
B=$(curl -s -H "$C" -H "$J" -d "{\"type\":\"1v1\",\"mode\":\"standard\",\"potRule\":\"winner\",\"rounds\":[\"event-emerald-drop\",\"$CCID\"],\"fast\":true}" $BASE/api/gbattles)
BID=$(echo "$B" | python3 -c "import sys,json;print(json.load(sys.stdin).get('id',''))")
ENTRY=$(python3 -c "print(round(11.32+$CCPRICE,2))")
echo "battle $BID (expect entry $ENTRY)"
if [ -n "$BID" ]; then PASS=$((PASS+1)); echo "PASS  battle created"; else FAIL=$((FAIL+1)); echo "FAIL  battle created"; fi
BAL2=$(curl -s -H "$C" $BASE/api/auth/me | python3 -c "import sys,json;print(json.load(sys.stdin)['player']['balance'])")
ck "entry charged" "$(python3 -c "print(round($BAL1-$ENTRY,2))")" "$BAL2"

echo "== 9. fill with bots -> auto-start =="
curl -s -H "$C" -H "$J" -d '{}' $BASE/api/gbattles/$BID/bots > /dev/null
sleep 2
ST=$(curl -s $BASE/api/gbattles/$BID)
STATUS=$(echo "$ST" | python3 -c "import sys,json;print(json.load(sys.stdin)['battle']['status'])")
ck "battle playing" "playing" "$STATUS"
sleep 3
for i in 1 2 3 4 5 6 7 8 9 10; do
  ST=$(curl -s $BASE/api/gbattles/$BID)
  STATUS=$(echo "$ST" | python3 -c "import sys,json;print(json.load(sys.stdin)['battle']['status'])")
  [ "$STATUS" = "finished" ] && break
  sleep 3
done
ck "battle finished" "finished" "$STATUS"
WIN=$(echo "$ST" | python3 -c "import sys,json;print(','.join(json.load(sys.stdin)['battle']['winnerIds'] or []))")
echo "winners: $WIN"
if [ -n "$WIN" ]; then PASS=$((PASS+1)); echo "PASS  winners set"; else FAIL=$((FAIL+1)); echo "FAIL  winners set"; fi
FAIR=$(echo "$ST" | python3 -c "import sys,json;b=json.load(sys.stdin)['battle'];print(bool(b.get('fairSeed')))")
ck "fair seed revealed" "True" "$FAIR"

echo "== 10. ledger rows exist =="
LG=$(curl -s -H "$C" "$BASE/api/ledger?limit=40")
K1=$(echo "$LG" | python3 -c "
import sys,json
d=json.load(sys.stdin)
rows=d.get('rows') or d.get('ledger') or []
ks=[r.get('kind') for r in rows]
print('open_entry' in ks)
" 2>/dev/null)
ck "open_entry in ledger" "True" "$K1"
LEK=$(echo "$LG" | python3 -c "
import sys,json
d=json.load(sys.stdin)
rows=d.get('rows') or d.get('ledger') or []
ks=[r.get('kind') for r in rows]
out=[k for k in ('battle_entry','battle_win') if k in ks]
print(','.join(out) if out else 'none')
" 2>/dev/null)
echo "battle ledger kinds present: $LEK"

echo "== 11. players intact =="
STATS=$(curl -s $BASE/api/stats)
P=$(echo "$STATS" | python3 -c "import sys,json;print(json.load(sys.stdin).get('players'))")
ck "players 9" "9" "$P"

echo ""
echo "RESULT: PASS=$PASS FAIL=$FAIL"
echo "CCID=$CCID BID=$BID BAL_AFTER=$BAL2"
