// Task 81 cleanup: remove the FormatQA player, its seeded history battles
// (t81seed*), the two live E2E battles it hosted, and every QA money/drop
// trail — restores the pre-test baseline (9 fixture players, no QA battles).
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const qaProviderIds = ["76561198000000077"];
let removedBattles = 0;
for (const pid of qaProviderIds) {
  const p = await db.player.findUnique({ where: { providerId: pid } });
  if (!p) continue;
  const b = await db.battle.deleteMany({ where: { hostId: p.id } });
  removedBattles += b.count;
  await db.ledger.deleteMany({ where: { playerId: p.id } });
  await db.drop.deleteMany({ where: { playerId: p.id } });
  await db.inventoryItem.deleteMany({ where: { playerId: p.id } });
  await db.openPending.deleteMany({ where: { playerId: p.id } });
  await db.player.delete({ where: { id: p.id } });
  console.log(`scrubbed ${p.id} (${pid}) + ${b.count} hosted battle(s)`);
}
// belt & suspenders: any leftover Task 81 seeded battle rows
const seeded = await db.battle.deleteMany({ where: { id: { startsWith: "t81seed" } } });
if (seeded.count) console.log(`removed ${seeded.count} leftover seeded battle(s)`);
const counts = `${await db.player.count()}p/${await db.battle.count()}b/${await db.ledger.count()}l`;
console.log(`battles removed: ${removedBattles} | DB now: ${counts}`);
await db.$disconnect();
