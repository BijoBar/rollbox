// Test-player mint: upserts scripts player "t9x-exchange" with a big balance
// and prints a signed rb_session cookie for browser E2E testing.
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const PROVIDER_ID = "t9x-exchange-tester";
const NAME = "T9X Tester";

const secret = fs.readFileSync(path.join(process.cwd(), "db", ".auth-secret"), "utf8").trim();
const sign = (payload) => crypto.createHmac("sha256", secret).update(payload).digest("base64url");
const makeToken = (playerId) => {
  const body = Buffer.from(JSON.stringify({ pid: playerId, exp: Date.now() + 30 * 864e5 })).toString("base64url");
  return body + "." + sign(body);
};

const player = await db.player.upsert({
  where: { providerId: PROVIDER_ID },
  create: { id: "p_" + crypto.randomBytes(8).toString("hex"), provider: "steam", providerId: PROVIDER_ID, name: NAME, avatar: null, balance: 25000, refCode: "T9XTEST2" },
  update: { balance: 25000, bannedAt: null },
});
console.log(JSON.stringify({ pid: player.id, balance: player.balance, cookie: "rb_session=" + makeToken(player.id) }));
await db.$disconnect();
