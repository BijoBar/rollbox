// VERIFY Task 55 — members counter logic in upsertPlayer (then cleans up after itself)
import { upsertPlayer, bumpCounter } from "../src/lib/server/auth";
import { db } from "../src/lib/db";

const before = await db.counter.findUnique({ where: { key: "members" } });
const m0 = before?.value ?? 0;

// 1) brand-new player -> members +1
const p = await upsertPlayer("steam", "e2e-members-test-55", "E2E Members", "https://example.com/a.jpg");
const m1 = (await db.counter.findUnique({ where: { key: "members" } }))?.value ?? 0;
console.log(m1 === m0 + 1 ? "PASS new signup -> members +1" : `FAIL ${m0} -> ${m1}`);

// 2) re-login with a NEW Steam name/avatar -> row updated, members unchanged
const p2 = await upsertPlayer("steam", "e2e-members-test-55", "Renamed Steam User", "https://example.com/b.jpg");
const m2 = (await db.counter.findUnique({ where: { key: "members" } }))?.value ?? 0;
console.log(p2.name === "Renamed Steam User" && p2.avatar === "https://example.com/b.jpg"
  ? "PASS re-login refreshes name+avatar" : `FAIL got ${p2.name}/${p2.avatar}`);
console.log(m2 === m1 ? "PASS re-login -> members unchanged" : `FAIL ${m1} -> ${m2}`);

// cleanup: remove the test player and restore the counter
await db.player.delete({ where: { id: p.id } });
await bumpCounter("members", -1);
const m3 = (await db.counter.findUnique({ where: { key: "members" } }))?.value ?? 0;
console.log(m3 === m0 ? "PASS cleanup restored counter" : `FAIL counter left at ${m3}`);
await db.$disconnect();
