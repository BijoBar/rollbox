// t105: inspect (and optionally set) the test player's xp/level for level-flow testing
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const [,, mode, xpArg] = process.argv;
const id = "p_t72B";
if (mode === "set") {
  const xp = parseInt(xpArg, 10);
  const { levelFromXp } = await import("../src/lib/progress.ts");
  const level = levelFromXp(xp).level;
  const p = await db.player.update({ where: { id }, data: { xp, level } });
  console.log("SET:", JSON.stringify({ xp: p.xp, level: p.level, balance: p.balance }));
} else {
  const p = await db.player.findUnique({ where: { id }, select: { id: true, name: true, xp: true, level: true, balance: true } });
  console.log(JSON.stringify(p));
}
await db.$disconnect();
