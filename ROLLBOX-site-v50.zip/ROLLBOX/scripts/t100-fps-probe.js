// Task 100 — FPS probe helpers injected via agent-browser eval.
// Measures rAF frame deltas while idle / scrolling / spinning.
(() => {
  window.__rbFpsProbe = async (ms, scrollMode) => {
    const deltas = [];
    let last = performance.now();
    let raf = 0;
    let stop = false;
    const step = (t) => {
      deltas.push(t - last);
      last = t;
      if (scrollMode === "scroll") window.scrollBy(0, 18);
      if (scrollMode === "jump") window.scrollTo(0, Math.random() * 1200);
      if (!stop) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    await new Promise((r) => setTimeout(r, ms));
    stop = true;
    cancelAnimationFrame(raf);
    const sorted = [...deltas].sort((a, b) => a - b);
    const p = (q) => Math.round(sorted[Math.floor(sorted.length * q)] * 10) / 10;
    const jank = deltas.filter((d) => d > 33).length; // missed frames (>2 vsyncs)
    const heavy = deltas.filter((d) => d > 50).length; // severe stalls
    return JSON.stringify({
      frames: deltas.length,
      avgMs: Math.round((deltas.reduce((a, b) => a + b, 0) / deltas.length) * 10) / 10,
      p50: p(0.5), p90: p(0.9), p99: p(0.99), max: Math.round(sorted[sorted.length - 1]),
      jankFrames: jank, heavyStalls: heavy,
    });
  };
  return "probe ready";
})()
