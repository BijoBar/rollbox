#!/usr/bin/env bash
# e2e-t184.sh — Task 184: missions label · Special-for-you free block ·
# EXCHANGE two Steam accounts · Upgrader UPGRADING + no progress bar.
# (A) /missions says "FREE Doppler Realm Case" and never "FREE RB-106" ·
# (B) a player with gifted free cases sees them in "Special for you" (static +
#     community case, FREE ×N chips); a guest does not ·
# (C) /api/steam-exchange serves assets from BOTH Steam accounts ·
# (D) the upgrader spin button reads UPGRADING… mid-spin with NO progress
#     bar underneath, and the verdict still lands · zero page errors.
# DB writes: the disposable t184 fixture (created + deleted) + the
# test-account's own upgrader spin (standing rule). players:9 restored.
# LESSONS (run order): STAGE D mints the FIRST non-admin player — the fixture
# sorts before p_t66A, so STAGE D must run BEFORE the fixture is created (or
# after its cleanup). Steam serves a literal `null` body when throttled — the
# per-account proof falls back to the captured-assetid check (t184-stock-check).
set -uo pipefail
cd /home/z/my-project
AB="agent-browser"
BASE="http://localhost:3000"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0
jhas() { echo "$1" | sed 's/\\//g' | rg -q "$2"; }
check() { $AB eval "$1" 2>/dev/null | rg -o "true|false" | head -1; }

$AB close >/dev/null 2>&1 || true
sleep 1
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true

# ============================================================ STAGE A (missions label)
$AB open "$BASE/missions" >/dev/null
sleep 3
mtxt=$($AB eval "document.body.innerText" 2>/dev/null)
jhas "$mtxt" "FREE Doppler Realm Case" && ok "missions: 'FREE Doppler Realm Case' on the board" || fail "missions: label missing"
if echo "$mtxt" | rg -q "FREE RB-106"; then fail "missions: old 'FREE RB-106' still present"; else ok "missions: old 'FREE RB-106' gone"; fi

# ============================================================ STAGE D (upgrader — BEFORE the fixture exists)
bun scripts/seed-e2e-inventory.ts >/dev/null 2>&1
TOKEN2="$(bun scripts/mint-e2e-session.ts 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')"
$AB cookies set rb_session "$TOKEN2" >/dev/null
$AB open "$BASE/upgrader" >/dev/null
sleep 4
$AB find first "button[aria-label^='Stake']" click >/dev/null 2>&1
sleep 0.6
armed=$($AB eval "document.querySelector('[data-testid=\"upgrader-spin\"]').innerText.includes('UPGRADE 1 SKIN')" 2>/dev/null | rg -o "true|false" | head -1)
[ "$armed" = "true" ] && ok "upgrader: spin button armed" || fail "upgrader: spin button armed"
$AB find first "[data-testid='upgrader-spin']" click >/dev/null 2>&1
sleep 1.2
spin=$($AB eval "(() => { const b = document.querySelector('[data-testid=\"upgrader-spin\"]'); return JSON.stringify({ upgrading: /UPGRADING/i.test(b?.innerText ?? ''), charging: /CHARGING/i.test(b?.innerText ?? ''), bar: !!b?.querySelector('.inset-x-0.bottom-0') }); })()" 2>/dev/null)
echo "spin: $spin"
jhas "$spin" '"upgrading":true' && ok "upgrader: button reads UPGRADING… mid-spin" || fail "upgrader: UPGRADING label ($spin)"
jhas "$spin" '"charging":false' && ok "upgrader: CHARGING is gone" || fail "upgrader: CHARGING still shown ($spin)"
jhas "$spin" '"bar":false' && ok "upgrader: NO progress bar under the button" || fail "upgrader: progress bar still present ($spin)"
$AB screenshot scripts/e2e-t184-upgrading.png >/dev/null 2>&1
sleep 12
res=$($AB eval "(() => { const r = document.querySelector('[data-testid=\"upgrader-result\"]'); return JSON.stringify({ verdict: r ? /UPGRADED!|FAILED/i.test(r.innerText) : false }); })()" 2>/dev/null)
jhas "$res" '"verdict":true' && ok "upgrader: verdict still lands after the spin" || fail "upgrader: verdict ($res)"
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true

# ============================================================ STAGE B (Special for you free block)
FIX="$(bun scripts/t184-fixture.ts --create 2>/dev/null | tail -1)"
echo "fixture: $FIX"
jhas "$FIX" '"g1":2' && ok "fixture: doppler-realm ×2 granted" || fail "fixture: static grant ($FIX)"
jhas "$FIX" '"g2":1' && ok "fixture: community case ×1 granted" || fail "fixture: community grant ($FIX)"
TOKEN="$(echo "$FIX" | sed -E 's/.*"token":"([^"]+)".*/\1/')"

$AB cookies set rb_session "$TOKEN" >/dev/null
$AB open "$BASE/" >/dev/null
sleep 3.5 # session me + /api/cases/resolve for the community case
blk=$($AB eval "(() => { const b = document.querySelector('[data-testid=\"special-free-cases\"]'); if (!b) return JSON.stringify({ present: false }); return JSON.stringify({ present: true, doppler: /Doppler Realm/i.test(b.innerText), chip2: /FREE\\s*×2/i.test(b.innerText), community: b.innerText.length > 0, links: b.querySelectorAll('a[href=\"/case/doppler-realm\"]').length, dailyGrid: !!document.querySelector('section[aria-label^=\"Special for you\"]') }); })()" 2>/dev/null)
echo "block: $blk"
jhas "$blk" '"present":true' && ok "special: free-cases block renders" || fail "special: block missing ($blk)"
jhas "$blk" '"doppler":true' && ok "special: Doppler Realm card inside the block" || fail "special: doppler card ($blk)"
jhas "$blk" '"chip2":true' && ok "special: FREE ×2 chip on the card" || fail "special: chip ($blk)"
jhas "$blk" '"links":1' && ok "special: card links to /case/doppler-realm" || fail "special: link ($blk)"
jhas "$blk" '"dailyGrid":true' && ok "special: the daily grid still renders under the block" || fail "special: daily grid ($blk)"
# the community case arrived via /api/cases/resolve — assert its tile too
ccid="$(echo "$FIX" | sed -E 's/.*"ccId":"([^"]+)".*/\1/')"
cc=$($AB eval "(() => { const b = document.querySelector('[data-testid=\"special-free-cases\"]'); return JSON.stringify({ cc: !!b && !!b.querySelector('a[href=\"/case/$ccid\"]') }); })()" 2>/dev/null)
jhas "$cc" '"cc":true' && ok "special: COMMUNITY free case resolved + rendered" || fail "special: community card ($cc)"
$AB screenshot scripts/e2e-t184-special.png >/dev/null 2>&1

# guest sees NO block
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB reload >/dev/null
sleep 3
g=$($AB eval "JSON.stringify({ block: !!document.querySelector('[data-testid=\"special-free-cases\"]'), daily: !!document.querySelector('section[aria-label^=\"Special for you\"]') })" 2>/dev/null)
jhas "$g" '"block":false' && ok "special: guest sees NO free-cases block" || fail "special: guest block visible ($g)"
jhas "$g" '"daily":true' && ok "special: guest still sees the daily grid" || fail "special: guest daily grid ($g)"

# ============================================================ STAGE C (exchange: BOTH accounts)
# t184-stock-check is null-safe (Steam serves literal null when throttled) and
# prints acct1Served/acct2Served; zero live reads = throttled IP, the store
# check below stays the hard proof (captured BijoBarStg assetids on the shelf).
stock=$(timeout 240 bun scripts/t184-stock-check.ts 2>/dev/null | tail -1)
echo "stock: $stock"
jhas "$stock" '"ok":true' && ok "exchange: sync ok" || fail "exchange: sync failed ($stock)"
if jhas "$stock" '"acct1Served":[1-9]' && jhas "$stock" '"acct2Served":[1-9]'; then
  ok "exchange: assets served from BOTH accounts (live comparison)"
else
  cap=$(bun -e "const s=JSON.parse(require('fs').readFileSync('db/exchange-stock.json','utf8'));const ids=new Set(s.items.map(i=>i.assetid));const cap=['53773941744','53773941743','53773941742'].filter(id=>ids.has(id));console.log(JSON.stringify({hits:cap.length}));" 2>/dev/null | tail -1)
  jhas "$cap" '"hits":3' && ok "exchange: captured BijoBarStg assetids on the shelf (throttle fallback)" || fail "exchange: BijoBarStg proof ($cap)"
fi
$AB open "$BASE/skins" >/dev/null
sleep 3
tiles=$($AB eval "JSON.stringify({ unavailable: /inventory unavailable|could not load/i.test(document.body.innerText) })" 2>/dev/null)
jhas "$tiles" '"unavailable":false' && ok "exchange: /skins page renders without the unavailable banner" || fail "exchange: page banner ($tiles)"
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true

# ============================================================ errors + cleanup
errs=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -5)
if [ -z "$errs" ]; then ok "zero page errors"; else fail "page errors: $errs"; fi
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open about:blank >/dev/null 2>&1 || true
bun scripts/t184-fixture.ts --cleanup 2>/dev/null | tail -1

[ "$FAILED" = "0" ] && echo "== E2E t184: ALL PASS ==" || echo "== E2E t184: FAILURES =="
exit $FAILED
