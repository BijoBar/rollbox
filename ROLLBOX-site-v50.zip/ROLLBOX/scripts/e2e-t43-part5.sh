#!/usr/bin/env bash
# Task 43 E2E — part 5: 2v2 JACKPOT — the wheel spins per TEAM (Team CT /
# Team T cells with combined-haul odds) and the landed team wins.
set -u
AB="agent-browser"
D="/home/z/my-project/download"

echo "=== create 2v2 JACKPOT ==="
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 2.5
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "2 Vs 2")?.click(); return "2v2"; })()' 2>/dev/null | tail -1
sleep 0.4
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "JACKPOT")?.click(); return "jackpot"; })()' 2>/dev/null | tail -1
sleep 0.4
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "Add Case")?.click(); return "picker"; })()' 2>/dev/null | tail -1
sleep 1.2
$AB eval '(() => { [...document.querySelectorAll("[role=\"dialog\"] button[aria-label^=\"Add\"]")].find(b => b.getAttribute("aria-label").includes("$3"))?.click(); return "case added"; })()' 2>/dev/null | tail -1
sleep 0.4
$AB eval '(() => { const d = document.querySelector("[role=\"dialog\"]"); d?.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true})); return "esc"; })()' 2>/dev/null | tail -1
sleep 0.6
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.includes("Create Battle"))?.click(); return "created"; })()' 2>/dev/null | tail -1
sleep 2.5
$AB eval 'JSON.stringify({url: location.pathname, jackpotBadge: document.body.textContent.includes("JACKPOT"), pickChips: [...document.querySelectorAll("button")].filter(b => (b.getAttribute("aria-label") || "").includes("Pick which bot")).length})' 2>/dev/null | tail -1

echo "=== Call Bots (fills 3 empty seats) ==="
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.includes("Call Bots"))?.click(); return "called"; })()' 2>/dev/null | tail -1
sleep 1.2
$AB eval 'JSON.stringify({kickButtons: [...document.querySelectorAll("button")].filter(b => b.textContent.trim() === "Kick").length, teams: document.body.textContent.includes("Team CT") && document.body.textContent.includes("Team T")})' 2>/dev/null | tail -1

echo "=== wait for countdown + round + settle (jackpot reel) ==="
sleep 11
$AB eval '(() => {
  const t = document.body.textContent;
  const reelCells = [...document.querySelectorAll("[role=\"status\"] .font-display.rounded")].map(x => x.textContent).slice(0, 6);
  return JSON.stringify({
    jackpotDraw: t.includes("Jackpot draw"),
    teamCT: t.includes("Team CT"),
    teamT: t.includes("Team T"),
    percents: reelCells.filter(x => x.includes("%")),
    subline: t.includes("COMBINED haul") ? "team-subline" : (t.includes("lowest haul") ? "solo-crazy" : "other")
  });
})()' 2>/dev/null | tail -1
$AB screenshot "$D/task43-jackpot-teams-live.png" >/dev/null 2>&1
sleep 6
$AB eval 'JSON.stringify({decided: document.body.textContent.includes("DECIDED BY THE JACKPOT DRAW") || document.body.textContent.includes("Decided by the jackpot draw"), banner: document.body.textContent.match(/Team C[TT] wins the jackpot/)?.[0] ?? null, victory: document.body.textContent.includes("VICTORY")})' 2>/dev/null | tail -1
$AB screenshot "$D/task43-jackpot-teams-done.png" >/dev/null 2>&1