#!/usr/bin/env bash
# Task 42 E2E — VIEW DROPS, FAST MODE, opening-order sort, bot picker,
# JACKPOT battle (weighted reel) and SHARED battle (equal split).
set -u
AB="agent-browser"
D="/home/z/my-project/download"
chk() { $AB eval "$1" 2>/dev/null | tail -1; }

echo "=== 1) /battles/new — mode bar + VIEW DROPS + sort ==="
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 3
echo "modes: $(chk '(() => { const t = document.body.innerText.toUpperCase(); return JSON.stringify({standard: t.includes("STANDARD"), crazy: t.includes("CRAZY"), jackpot: t.includes("JACKPOT"), shared: t.includes("SHARED")}); })()')"
echo "sort select: $(chk '!!document.querySelector("[aria-label=\"Opening order of the battle cases\"]")')"
$AB screenshot "$D/task42-create-top.png" >/dev/null 2>&1

# add a case via ADD CASE -> pick first case in picker
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim().toUpperCase() === "ADD CASE"); b?.click(); return "opened"; })()' >/dev/null 2>&1
sleep 1.2
$AB eval '(() => { const tiles = [...document.querySelectorAll("[role=\"dialog\"] button")].filter(x => x.querySelector("img") && x.textContent.length > 3); tiles[0]?.click(); tiles[1]?.click(); tiles[2]?.click(); return "added 3"; })()' >/dev/null 2>&1
sleep 0.8
$AB eval '(() => { const d = document.querySelector("[role=\"dialog\"] [aria-label=\"Close\"]") || [...document.querySelectorAll("[role=\"dialog\"] button")].find(x => x.textContent.trim() === "" ); document.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true})); return "esc"; })()' >/dev/null 2>&1
sleep 0.8
echo "selected tiles: $(chk 'document.querySelectorAll("main .grid > .relative").length')"

echo "=== 2) VIEW DROPS from a selected-case tile ==="
$AB eval '(() => { const b = [...document.querySelectorAll("main button")].find(x => x.textContent.toUpperCase().includes("VIEW DROPS")); b?.click(); return b ? "clicked" : "NOT FOUND"; })()' 2>/dev/null | tail -1
sleep 1.2
echo "drops dialog: $(chk '(() => { const d = document.querySelector("[role=\"dialog\"]"); const t = d?.textContent ?? ""; return JSON.stringify({open: !!d, hasDrops: t.toUpperCase().includes("DROPS"), pctCount: (t.match(/%/g) || []).length}); })()')"
$AB screenshot "$D/task42-view-drops.png" >/dev/null 2>&1
$AB eval 'document.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true}))' >/dev/null 2>&1
sleep 0.6

echo "=== 3) opening order sort cheap->expensive ==="
echo "before: $(chk '(() => { const names = [...document.querySelectorAll("main .grid p.text-center")].map(p => p.textContent); return JSON.stringify(names.slice(0,6)); })()')"
$AB eval '(() => { const trg = document.querySelector("[aria-label=\"Opening order of the battle cases\"]"); trg?.dispatchEvent(new PointerEvent("pointerdown", {bubbles: true})); trg?.click(); return "opened select"; })()' >/dev/null 2>&1
sleep 0.8
$AB eval '(() => { const opt = [...document.querySelectorAll("[role=\"option\"]")].find(o => o.textContent.includes("cheap")); opt?.click(); return opt ? "sorted asc" : "no option"; })()' >/dev/null 2>&1
sleep 0.8
echo "after: $(chk '(() => { const names = [...document.querySelectorAll("main .grid p.text-center")].map(p => p.textContent); return JSON.stringify(names.slice(0,6)); })()')"

echo "=== 4) SHARED blocked in 2v2 ==="
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("2 Vs 2")); b?.click(); return "2v2"; })()' >/dev/null 2>&1
sleep 0.5
echo "shared disabled: $(chk '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim() === "SHARED"); return JSON.stringify({found: !!b, disabled: b?.disabled ?? null}); })()')"
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("2 Players")); b?.click(); return "back to 1v1"; })()' >/dev/null 2>&1
sleep 0.4

echo "=== 5) create JACKPOT battle ==="
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim() === "JACKPOT"); b?.click(); return b ? "jackpot mode" : "NOT FOUND"; })()' 2>/dev/null | tail -1
sleep 0.4
echo "crazy-odds toggle visible: $(chk '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Crazy odds")); return JSON.stringify({found: !!b, label: b?.textContent ?? null}); })()')"
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Create Battle")); b?.click(); return "created"; })()' >/dev/null 2>&1
sleep 2.5
echo "url: $($AB eval 'location.pathname' 2>/dev/null | tail -1)"
echo "room jackpot chip: $(chk 'document.body.innerText.toUpperCase().includes("JACKPOT")')"

echo "=== 6) bot picker on EMPTY seat ==="
echo "pick buttons: $(chk '(() => { const n = [...document.querySelectorAll("button")].filter(x => x.textContent.trim().toUpperCase() === "PICK BOT").length; return String(n); })()')"
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim().toUpperCase() === "PICK BOT"); b?.click(); return "opened"; })()' >/dev/null 2>&1
sleep 1
$AB screenshot "$D/task42-bot-picker.png" >/dev/null 2>&1
echo "picker bots: $(chk '(() => { const opts = [...document.querySelectorAll("[role=\"dialog\"] button")].filter(x => x.textContent.includes("[RBbot]")); return String(opts.length); })()')"
$AB eval '(() => { const b = [...document.querySelectorAll("[role=\"dialog\"] button")].find(x => x.textContent.includes("Agent67")); b?.click(); return "picked Agent67"; })()' >/dev/null 2>&1
sleep 1.5
echo "seated: $(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.battles[0]?.players.map(p => p.name).join("|")')"
echo "phase after fill (countdown auto): $(chk 'document.body.innerText.toUpperCase().includes("WAITING FOR PLAYERS")')"

echo "=== 7) wait for the jackpot battle to finish (1 round, 1 case) ==="
for i in $(seq 1 40); do
  sleep 1
  done_=$(chk 'document.body.innerText.toUpperCase().includes("VICTORY") || document.body.innerText.toUpperCase().includes("BATTLE LOST")')
  [ "$done_" = "true" ] && { echo "finished at ${i}s"; break; }
done
echo "jackpot reel seen: $(chk 'document.body.innerText.toUpperCase().includes("JACKPOT DRAW")')"
echo "verdict chip: $(chk 'document.body.innerText.toUpperCase().includes("DECIDED BY THE JACKPOT DRAW")')"
$AB screenshot "$D/task42-jackpot-done.png" >/dev/null 2>&1
echo "balance now: $(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')"

echo "=== 8) SHARED battle 1v1 ==="
BAL_BEFORE=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 2.5
$AB eval '(() => { const t = [...document.querySelectorAll("button")].find(x => x.textContent.trim() === "ADD CASE"); t?.click(); return "picker"; })()' >/dev/null 2>&1
sleep 1.2
$AB eval '(() => { const tiles = [...document.querySelectorAll("[role=\"dialog\"] button")].filter(x => x.querySelector("img") && x.textContent.length > 3); tiles[0]?.click(); return "added"; })()' >/dev/null 2>&1
sleep 0.6
$AB eval 'document.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true})); "esc"' >/dev/null 2>&1
sleep 0.6
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim() === "SHARED"); b?.click(); return "shared mode"; })()' >/dev/null 2>&1
sleep 0.4
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Create Battle")); b?.click(); return "created"; })()' >/dev/null 2>&1
sleep 2.5
echo "url: $($AB eval 'location.pathname' 2>/dev/null | tail -1)"
# fill with a random bot via Call Bots
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Call Bots")); b?.click(); return "called"; })()' >/dev/null 2>&1
for i in $(seq 1 40); do
  sleep 1
  done_=$(chk 'document.body.innerText.toUpperCase().includes("POT SPLIT")')
  [ "$done_" = "true" ] && { echo "split at ${i}s"; break; }
done
$AB screenshot "$D/task42-shared-done.png" >/dev/null 2>&1
BAL_AFTER=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "balance before: $BAL_BEFORE after: $BAL_AFTER"
echo "verdict text: $(chk '(() => { const t = document.body.innerText; const m = t.match(/POT SPLIT!\\s*$[\\d.,KM]+/i); return JSON.stringify(m?.[0] ?? null); })()')"

echo "=== 9) FAST MODE on a case page ==="
$AB open http://localhost:3000/cases >/dev/null 2>&1
sleep 2.5
$AB eval '(() => { const a = [...document.querySelectorAll("a")].find(x => x.href.includes("/case/")); a?.click(); return a?.href ?? "no link"; })()' >/dev/null 2>&1
sleep 2.5
echo "fast label: $(chk '(() => { const lbl = [...document.querySelectorAll("label")].find(x => x.textContent.includes("Fast mode")); return JSON.stringify(lbl?.textContent ?? null); })()')"
$AB eval '(() => { const lbl = [...document.querySelectorAll("label")].find(x => x.textContent.includes("Fast mode")); const i = lbl?.querySelector("input"); if (i && !i.checked) i.click(); return "fast on"; })()' >/dev/null 2>&1
T0=$(date +%s%3N)
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.toUpperCase().includes("OPEN CASE")); b?.click(); return "opened"; })()' >/dev/null 2>&1
# wait for reveal
for i in $(seq 1 60); do
  sleep 0.25
  rev=$(chk 'document.body.innerText.toUpperCase().includes("OPEN AGAIN")')
  [ "$rev" = "true" ] && break
done
T1=$(date +%s%3N)
echo "fast open total ms: $((T1 - T0)) (must include the spin — well under the 6.5s slow spin)"
echo "spinning phase seen: $(chk 'document.body.innerText.toUpperCase().includes("SPINNING") || document.body.innerText.toUpperCase().includes("OPEN AGAIN")')"

echo "=== done ==="
