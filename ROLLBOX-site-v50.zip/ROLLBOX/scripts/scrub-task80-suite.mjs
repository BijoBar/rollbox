// Task 80 cleanup stage 3: purge TODAY's regression-suite artifacts —
// battles hosted by the tNN QA players and today's ledger rows of theirs —
// while keeping the player rows themselves (suite fixtures, part of the 9p).
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const start = new Date(Date.now() - 12 * 3600 * 1000);
const qaPlayers = await db.player.findMany({
  where: { providerId: { contains: "-steamid" } },
  select: { id: true, providerId: true },
});
const qaIds = qaPlayers.map((p) => p.id);

let battles = 0;
for (const id of qaIds) {
  const r = await db.battle.deleteMany({ where: { hostId: id, createdAt: { gte: start } } });
  battles += r.count;
}
const ledger = await db.ledger.deleteMany({
  where: { playerId: { in: qaIds }, createdAt: { gte: start } },
});
console.log(`suite battles removed: ${battles} | suite ledger rows removed: ${ledger.count}`);
const counts = `${await db.player.count()}p/${await db.battle.count()}b/${await db.ledger.count()}l`;
console.log("DB now: " + counts);
await db.$disconnect();
