#!/usr/bin/env python3
"""Task 81 browser-E2E seed — finished battles with REAL case ids for the
FormatQA player, so the dedicated battle-history page (artwork strip +
RECREATE) and the create-screen prefill can be verified end to end."""
import json
import sqlite3

DB = "db/custom.db"
PID = "p_66f910a4133e258e"  # FormatQA (minted by scripts/mint-format-qa.mjs)

CASES = [
    "asiimov-protocol",
    "printstream-cartel",
    "dragons-vault",
    "gold-rush",
    "doppler-realm",
    "hellfire-club",
    "neon-district",
    "hyper-beast-bazaar",
    "asiimov-protocol",
]

con = sqlite3.connect(DB)
con.execute(
    "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
    "VALUES (?, 'steam', '76561198000000077', 'FormatQA', 12345.67, 0, 2, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
    (PID,),
)


def seed(bid, code, btype, finished_ago_s, me_wins, rounds, entry):
    team = 1 if btype == "2v2" else 0
    seats = json.dumps([
        {"key": PID, "name": "FormatQA", "team": 0, "color": 0, "isBot": False, "paid": entry},
        {"key": "bot_0", "name": "[RBbot] Vic", "team": team, "color": 1, "isBot": True, "paid": entry},
        {"key": "bot_1", "name": "[RBbot] Rex", "team": team, "color": 2, "isBot": True, "paid": entry},
    ])
    winners = json.dumps([PID if me_wins else "bot_0"])
    total = round(entry * 1.8, 2)
    pulls = json.dumps([
        {"playerId": PID, "total": total, "pulls": [{"round": 0, "value": total}]},
        {"playerId": "bot_0", "total": 5, "pulls": [{"round": 0, "value": 5}]},
        {"playerId": "bot_1", "total": 4, "pulls": [{"round": 0, "value": 4}]},
    ])
    takes = json.dumps({PID: total if me_wins else 0, "bot_0": 0 if me_wins else entry * 3, "bot_1": 0})
    con.execute(
        "INSERT OR REPLACE INTO Battle (id, code, hostId, type, mode, potRule, fast, isPrivate, rounds, entry, status, "
        "colorOrder, seats, schedule, pulls, winnerIds, tieIds, potTotal, take, startedAt, totalMs, createdAt, updatedAt, finishedAt) "
        "VALUES (?, ?, ?, ?, 'standard', 'winner', 0, 0, ?, ?, 'finished', '[0,1,2,3]', ?, NULL, ?, ?, NULL, ?, ?, NULL, NULL, "
        "CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, datetime('now', ?))",
        (bid, code, PID, btype, json.dumps(rounds), entry, seats, pulls, winners, entry * 3, takes, f"-{finished_ago_s} seconds"),
    )


# one 9-round 1v1 win (7 crates shown + "+2"), one 3-round 2v2 loss, one 5-round 1v1 win
seed("t81seed09", "RB-T81A", "1v1", 3600, True, CASES, 210)
seed("t81seed03", "RB-T81B", "2v2", 900, False, CASES[:3], 40)
seed("t81seed05", "RB-T81C", "1v1", 120, True, CASES[:5], 96)
con.commit()
con.close()
print("seeded 3 battles for", PID)
