#!/usr/bin/env python3
"""dev-daemon.py — start `bun run dev` as a TRUE daemon (double-fork) so the
dev server is reparented to init (tini, PID 1) DURING this call, not at call
end. This mimics the agent-browser daemon's survival pattern (PPID=1, own
session) — plain `setsid nohup ... &` children of the tool shell get reaped
when the tool shell exits between calls; init-parented daemons survive.

Usage: python3 scripts/dev-daemon.py   (parent exits immediately after fork)
"""
import os
import sys

CWD = "/home/z/my-project"
LOG = os.path.join(CWD, "dev.log")


def daemonize_exec() -> None:
    # 1st fork: the parent returns to caller (exits NOW), child continues.
    pid = os.fork()
    if pid > 0:
        return  # parent path — caller prints and exits while child lives
    os.setsid()  # new session, detach from controlling terminal

    # 2nd fork: the middle process exits immediately -> the grandchild is
    # reparented to init RIGHT NOW (during this tool call), not at call end.
    pid = os.fork()
    if pid > 0:
        os._exit(0)

    # Grandchild = future daemon: clean fds, own cwd, exec the dev server.
    os.chdir(CWD)
    devnull = os.open("/dev/null", os.O_RDONLY)
    os.dup2(devnull, 0)
    fd = os.open(LOG, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
    os.dup2(fd, 1)
    os.dup2(fd, 2)
    os.execvpe("bun", ["bun", "run", "dev"], dict(os.environ))
    os._exit(127)  # exec failed


def main() -> int:
    # Avoid double-start: if port 3000 already answers, do nothing.
    import socket

    s = socket.socket()
    try:
        s.connect(("127.0.0.1", 3000))
        s.close()
        print("already-running: port 3000 answers, nothing to do")
        return 0
    except OSError:
        pass
    finally:
        s.close()

    daemonize_exec()
    print("daemonized: bun run dev forked to init (double-fork), parent out")
    return 0


if __name__ == "__main__":
    sys.exit(main())
