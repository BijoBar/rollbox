#!/usr/bin/env bash
# e2e-t172-debug3.sh — forensic per-seat lock profile for scenario 3.
# Hypothesis: spunPastSchedule=1 is a TEST artifact — the sampler polls the
# FIRST [data-testid="round-reel"] in the DOM while REEL_LOCK=2660 assumes the
# YOU reel (2400+260). Bot reels run 3400/3850 (lock ~3660/4110). If the first
# DOM reel is a bot's (column order != players order), one unlocked sample in
# el∈(3560,3660) is EXPECTED product behavior. This probe tracks EVERY reel
# separately: max unlocked el + first locked el + seat name, per round.
set -euo pipefail
cd /home/z/my-project
BASE=http://localhost:3000
TOKEN=$(bun scripts/mint-e2e-session.ts 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')
api() { curl -s --max-time 5 -H "Cookie: rb_session=$TOKEN" -H 'Content-Type: application/json' "$@"; }
field() { python3 -c "import sys,json;d=json.load(sys.stdin);print(eval(\"d$1\"))"; }

echo "== minted, creating battle =="
BID=$(api -X POST "$BASE/api/gbattles" -d '{"type":"1v1v1","mode":"standard","potRule":"winner","rounds":["farm-ak47","farm-ak47","farm-ak47"],"fast":false,"private":false}' | field "['id']")
echo "BID=$BID"
api -X POST "$BASE/api/gbattles/$BID/bots" -d '{}' >/dev/null
for i in $(seq 1 40); do
  ST=$(api "$BASE/api/gbattles/$BID" | python3 -c "import sys,json;print(json.load(sys.stdin)['battle']['status'])" 2>/dev/null || echo)
  [ "$ST" = "playing" ] && break; sleep 0.4
done
[ "$ST" = "playing" ] || { echo "NEVER-PLAYING"; exit 0; }

STARTED=$(( $(date +%s%3N) - $(api "$BASE/api/gbattles/$BID" | python3 -c "import sys,json,time;print(int(time.time()*1000)-json.load(sys.stdin)['battle']['serverNow'])") ))
SLOT1=$(api "$BASE/api/gbattles/$BID" | field "['battle']['schedule'][1]['startMs']")
DIFF=$(( $SLOT1 + 500 - ( $(date +%s%3N) - $STARTED ) ))
if [ "$DIFF" -gt 0 ]; then python3 -c "import time;time.sleep($DIFF/1000)"; fi
echo "== round 1 just started, opening room =="

agent-browser open "$BASE/" >/dev/null 2>&1
agent-browser wait 700 >/dev/null 2>&1
agent-browser cookies set rb_session "$TOKEN" >/dev/null 2>&1
agent-browser open "$BASE/battles/$BID" >/dev/null 2>&1
agent-browser wait 1200 >/dev/null 2>&1

python3 << PYEOF
import subprocess, time, json

def ev(js):
    r = subprocess.run(["agent-browser", "eval", js], capture_output=True, text=True)
    out = (r.stdout or "").strip().splitlines()
    try:
        v = json.loads(out[-1]) if out else {}
        return json.loads(v) if isinstance(v, str) else v
    except Exception:
        return {}

POLL = """(() => {
  const reels = [...document.querySelectorAll('[data-testid="round-reel"]')];
  const rounds = [...document.querySelectorAll('[data-round]')].map(e => Number(e.dataset.round));
  const first = reels[0] || null;
  return JSON.stringify({
    t: Date.now(),
    maxRound: rounds.length ? Math.max(...rounds) : -1,
    globalLocked: !!document.querySelector('[aria-label*="won"]'),
    firstSa: first ? (first.dataset.startAt || null) : null,
    firstLocked: first ? !!first.querySelector('[aria-label*="won"]') : null,
    reelCount: reels.length,
    reels: reels.map(r => ({
      sa: r.dataset.startAt || null,
      locked: !!r.querySelector('[aria-label*="won"]'),
      name: (r.querySelector('[aria-label*="won"]')?.ariaLabel || '').split(' ')[0] || null
    })),
    verdict: /VICTORY!|BATTLE LOST!|POT SPLIT!/i.test(document.body.innerText)
  });
})()"""

samples = []
t0 = time.time()
while time.time() - t0 < 24:
    s = ev(POLL)
    if s.get("reels") is not None:
        samples.append(s)
    if s.get("verdict"):
        break
    time.sleep(0.15)

# THE SUITE'S EXACT METRIC: first reel in DOM, global locked check
violations = []
for i, s in enumerate(samples):
    sa = s.get("firstSa")
    if sa and not s.get("globalLocked"):
        el = s["t"] - float(sa)
        if el > 3560:
            ctx = [{"el": round(s2["t"] - float(s2["firstSa"]), 0) if s2.get("firstSa") else None,
                    "gL": s2.get("globalLocked"), "fL": s2.get("firstLocked"),
                    "n": s2.get("reelCount"), "r": s2.get("maxRound")}
                   for s2 in samples[max(0, i - 2):i + 3]]
            violations.append({"sampleIdx": i, "el": round(el, 0), "context": ctx})

tracks = {}
for s in samples:
    for i, r in enumerate(s.get("reels", [])):
        if not r.get("sa"):
            continue
        key = (s.get("maxRound"), i)
        el = s["t"] - float(r["sa"])
        tr = tracks.setdefault(key, {"name": None, "maxUnlockEl": -1, "firstLockEl": None, "n": 0})
        tr["n"] += 1
        if r.get("name"):
            tr["name"] = r["name"]
        if r.get("locked"):
            if tr["firstLockEl"] is None:
                tr["firstLockEl"] = el
        else:
            tr["maxUnlockEl"] = max(tr["maxUnlockEl"], el)

print(json.dumps({
    "verdict": any(s.get("verdict") for s in samples),
    "sampleCount": len(samples),
    "violations": violations,
    "seatOrderNote": "idx = order of reels in DOM",
    "tracks": [
        {"round": k[0], "domIdx": k[1], "seat": v["name"], "samples": v["n"],
         "maxUnlockEl": v["maxUnlockEl"], "firstLockEl": v["firstLockEl"]}
        for k, v in sorted(tracks.items())
    ]
}, indent=1))
PYEOF

agent-browser cookies clear >/dev/null 2>&1 || true
agent-browser storage local clear >/dev/null 2>&1 || true
agent-browser open about:blank >/dev/null 2>&1 || true
