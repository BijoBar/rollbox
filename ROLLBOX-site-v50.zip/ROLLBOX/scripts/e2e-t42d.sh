#!/usr/bin/env bash
# Task 42 E2E round 4 — FAST MODE run, SHARED battle full loop, sort close-out.
set -u
AB="agent-browser"
D="/home/z/my-project/download"
chk() { $AB eval "$1" 2>/dev/null | tail -1; }

echo "=== C3) FAST MODE (page already warm) ==="
$AB open http://localhost:3000/case/asiimov-protocol >/dev/null 2>&1
sleep 6
echo "fast label: $(chk '(() => { const lbl = [...document.querySelectorAll("label")].find(x => x.textContent.includes("Fast mode")); return JSON.stringify(lbl?.textContent ?? null); })()')"
$AB eval '(() => { const lbl = [...document.querySelectorAll("label")].find(x => x.textContent.includes("Fast mode")); const i = lbl?.querySelector("input"); if (i && !i.checked) i.click(); return "fast on"; })()' >/dev/null 2>&1
BALC0=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
T0=$(date +%s%3N)
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.toUpperCase().includes("OPEN CASE")); b?.click(); return "clicked"; })()' >/dev/null 2>&1
SPIN=0; REV=""
for i in $(seq 1 120); do
  sleep 0.25
  if [ "$SPIN" = "0" ]; then SPIN=$(chk 'document.body.innerText.toUpperCase().includes("SPINNING")' | rg -o true | head -1); fi
  REV=$(chk 'document.body.innerText.toUpperCase().includes("OPEN AGAIN")' | rg -o true | head -1)
  [ "$REV" = "true" ] && break
done
T1=$(date +%s%3N)
BALC1=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "spinning seen: ${SPIN:-false}; revealed: ${REV:-false}; total ms: $((T1 - T0))"
echo "balance: $BALC0 -> $BALC1 (entry -60 + win)"
$AB screenshot "$D/task42-fast-mode.png" >/dev/null 2>&1

echo "=== B3) SHARED battle — full loop, stay in room ==="
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 3
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.getAttribute("aria-label") === "Add a case to the battle"); b?.click(); return "picker"; })()' >/dev/null 2>&1
sleep 1.5
$AB eval '(() => { const tiles = [...document.querySelectorAll("[role=\"dialog\"] button")].filter(x => x.querySelector("img")); tiles[0]?.click(); return "added"; })()' >/dev/null 2>&1
sleep 0.5
$AB eval '(() => { document.querySelector("[role=\"dialog\"] [title=\"Close\"]")?.click(); const c = document.querySelector("[role=\"dialog\"] button[data-slot=\"dialog-close\"]"); c?.click(); return "closed"; })()' >/dev/null 2>&1
sleep 0.8
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim() === "SHARED"); b?.click(); return "shared"; })()' >/dev/null 2>&1
sleep 0.4
BAL0=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Create Battle")); b?.click(); return "created"; })()' >/dev/null 2>&1
sleep 3
echo "url: $($AB eval 'location.pathname' 2>/dev/null | tail -1)"
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Call Bots")); b?.click(); return "called"; })()' >/dev/null 2>&1
FIN=""
for i in $(seq 1 75); do
  sleep 1
  FIN=$(chk 'document.body.innerText.includes("POT SPLIT!")' | rg -o true | head -1)
  [ "$FIN" = "true" ] && { echo "POT SPLIT! at ${i}s"; break; }
done
BAL1=$(chk 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance')
echo "balance: $BAL0 -> $BAL1"
echo "audit: $(chk '(() => {
  const h = JSON.parse(localStorage.getItem("rollbox-store")).state.battleHistory[0];
  if (!h) return "no history";
  const drops = (h.results ?? []).reduce((s, r) => s + r.total, 0);
  return JSON.stringify({rule: h.potRule, drops, players: h.players.length, winners: h.winnerIds?.length});
})()')"
echo "verdict: $(chk '(() => { const t = document.body.innerText; const m = t.match(/POT SPLIT!\\s*$[\\d.,KM]+/); return JSON.stringify(m?.[0] ?? null); })()')"
$AB screenshot "$D/task42-shared-done.png" >/dev/null 2>&1

echo "=== A3) mixed-price sort (proper close) ==="
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 3
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.getAttribute("aria-label") === "Add a case to the battle"); b?.click(); return "picker"; })()' >/dev/null 2>&1
sleep 1.5
$AB eval '(() => { const tiles = [...document.querySelectorAll("[role=\"dialog\"] button")].filter(x => x.querySelector("img")); tiles[0]?.click(); tiles[tiles.length - 1]?.click(); return "two added"; })()' >/dev/null 2>&1
sleep 0.5
$AB eval '(() => { const c = document.querySelector("[role=\"dialog\"] button[data-slot=\"dialog-close\"]") || document.querySelector("[role=\"dialog\"] [title=\"Close\"]"); c?.click(); return "closed"; })()' >/dev/null 2>&1
sleep 1
echo "picker closed: $(chk '!document.querySelector("[role=\"dialog\"]")')"
sort_once() {
  $AB eval '(() => { const trg = document.querySelector("[aria-label=\"Opening order of the battle cases\"]"); trg?.dispatchEvent(new PointerEvent("pointerdown", {bubbles: true})); trg?.click(); return "open"; })()' >/dev/null 2>&1
  sleep 1
  $AB eval "(() => { const opt = [...document.querySelectorAll(\"[role='option']\")].find(o => o.textContent.includes(\"$1\")); opt?.click(); return opt ? \"picked $1\" : \"NO OPTION\"; })()" 2>/dev/null | tail -1
  sleep 0.8
}
sort_once "cheap"
echo "asc:  $(chk '(() => { const gs = [...document.querySelectorAll("main .grid > div.relative")]; return JSON.stringify(gs.map(g => (g.querySelectorAll("p")[1]?.textContent ?? ""))); })()')"
sort_once "expensive"
echo "desc: $(chk '(() => { const gs = [...document.querySelectorAll("main .grid > div.relative")]; return JSON.stringify(gs.map(g => (g.querySelectorAll("p")[1]?.textContent ?? ""))); })()')"
$AB screenshot "$D/task42-sort.png" >/dev/null 2>&1
echo "=== done ==="
