#!/usr/bin/env bash
# e2e-t175.sh — UPGRADER air-whoosh removal E2E (Task 175)
# User spec: the air/fan blowing sound during the upgrader round must be GONE.
# Verifies: reactor core still renders, a full spin round works (CHARGING ->
# verdict), and — via an AudioBufferSourceNode probe — that NO long-lived
# looping noise source (the whoosh layer) is alive during/after the round.
# Zero console/page errors + mobile 375x812 overflow check. Cleanup after.
set -uo pipefail
cd /home/z/my-project
AB="agent-browser"
TOKEN="$(bun scripts/mint-e2e-session.ts | sed -E 's/.*"token":"([^"]+)".*/\1/')"
SHOT="scripts/e2e-t175"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0

check() { $AB eval "$1" 2>/dev/null | rg -o "true|false" | head -1; }

$AB cookies clear >/dev/null 2>&1 || true
$AB open http://localhost:3000/upgrader >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
$AB reload >/dev/null
sleep 2.5

# 0. install the audio probe BEFORE any sfx fires: track every buffer source
#    that is started LOOPED and never stopped — the whoosh is exactly that
#    (bursts loop but are stopped; one-shot samples are not looped).
#    NOTE: loop is OWN on AudioBufferSourceNode.prototype; start/stop live on
#    the BASE class AudioScheduledSourceNode.prototype in modern Chrome —
#    grabbing them from the wrong prototype yields undefined descriptors and
#    breaks the audio graph (Task-175 run #1 lesson).
probe=$($AB eval '(() => { const p = AudioBufferSourceNode.prototype; const b = (typeof AudioScheduledSourceNode !== "undefined") ? AudioScheduledSourceNode.prototype : p; if (!window.__audioProbe) { window.__audioProbe = true; window.__loopSrcs = new Set(); const d = Object.getOwnPropertyDescriptor(p, "loop"); const st = Object.getOwnPropertyDescriptor(b, "start"); const sp = Object.getOwnPropertyDescriptor(b, "stop"); if (!d || !st || !sp) return "probe-descriptor-missing"; Object.defineProperty(p, "loop", { get() { return d.get.call(this); }, set(v) { if (v) window.__loopSrcs.add(this); d.set.call(this, v); } }); Object.defineProperty(b, "start", { value(...a) { this.__t175Started = true; if (this.loop) window.__loopSrcs.add(this); return st.value.apply(this, a); } }); Object.defineProperty(b, "stop", { value(...a) { this.__t175Stopped = true; return sp.value.apply(this, a); } }); } return "probe-installed"; })()' 2>/dev/null)
echo "audio probe: $probe"
echo "$probe" | rg -q "probe-installed" && ok "audio probe installed" || fail "audio probe installed"
$AB errors --clear >/dev/null 2>&1 || true

# 1. the reactor core still renders
w=$(check "!!document.querySelector('[data-testid=\"upgrader-wheel\"] svg')")
c=$(check "!!document.querySelector('[data-testid=\"upgrader-wheel\"] canvas')")
[ "$w" = "true" ] && ok "wheel svg present" || fail "wheel svg present"
[ "$c" = "true" ] && ok "spark canvas present" || fail "spark canvas present"

# 2. pick one inventory skin — spin button arms
$AB find first "button[aria-label^='Stake']" click >/dev/null 2>&1
sleep 0.4
armed=$(check "document.querySelector('[data-testid=\"upgrader-spin\"]').innerText.includes('UPGRADE 1 SKIN')")
[ "$armed" = "true" ] && ok "spin button armed (UPGRADE 1 SKIN)" || fail "spin button armed"

# 3. spin the full round
$AB find first "[data-testid='upgrader-spin']" click >/dev/null 2>&1
sleep 0.8
charging=$(check "document.body.innerText.includes('CHARGING')")
[ "$charging" = "true" ] && ok "CHARGING state visible" || fail "CHARGING state visible"
$AB screenshot "$SHOT-spinning.png" >/dev/null 2>&1
sleep 5.4
res=$($AB eval "document.querySelector('[data-testid=\"upgrader-result\"]').innerText" 2>/dev/null | head -3 | tr '\n' ' ')
echo "verdict: $res"
if echo "$res" | rg -q "UPGRADED!|FAILED"; then ok "verdict banner landed"; else fail "verdict banner landed"; fi

# 4. THE USER SPEC — no looping air source alive through/after the round.
#    (With the old Task-174 code the whoosh would show up here as >= 1 and
#    never stop; with the fix every looped burst is stopped and no whoosh
#    is ever created.)
sleep 1.6
alive=$($AB eval '[...(window.__loopSrcs || [])].filter((s) => s.__t175Started && s.loop && !s.__t175Stopped).length' 2>/dev/null | rg -o "[0-9]+" | head -1)
alive="${alive:-?}"
echo "alive looped audio sources: $alive"
[ "$alive" = "0" ] && ok "no air-whoosh loop alive (user spec)" || fail "air-whoosh loop still alive ($alive)"

# 5. console + page errors (buffer was cleared post-load, so anything here is new)
errs=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -5)
if [ -z "$errs" ]; then ok "zero page errors"; else fail "page errors: $errs"; fi

# 6. mobile 375x812 — zero horizontal overflow
$AB set viewport 375 812 >/dev/null
$AB reload >/dev/null
sleep 2.2
ov=$(check "document.documentElement.scrollWidth <= 375")
[ "$ov" = "true" ] && ok "mobile 375px: zero horizontal overflow" || fail "mobile 375px: horizontal overflow"
$AB screenshot "$SHOT-mobile.png" >/dev/null 2>&1
$AB set viewport 1440 900 >/dev/null

# 7. cleanup
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open about:blank >/dev/null 2>&1 || true

[ "$FAILED" = "0" ] && echo "== E2E t175: ALL PASS ==" || echo "== E2E t175: FAILURES =="
exit $FAILED
