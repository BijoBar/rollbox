// ROLLBOX DROP EDITOR — HTML template (English-only, LTR).
// Data placeholders __SKINS_JSON__ / __CASES_JSON__ / __TERMINALS_JSON__ are
// replaced by scripts/build-drop-editor.ts with the site's REAL data layer.
// Inner JS deliberately avoids template literals and "<" + "/" adjacency.

const CSS = `
  :root{
    --bg:#0b0e13; --panel:#12161d; --line:#232a35; --ink:#e8ecf3; --dim:#8b96a8;
    --gold:#f5b942; --ok:#37d67a; --bad:#ff5d5d; --accent:#4cc2ff;
  }
  *{box-sizing:border-box}
  body{margin:0; background:var(--bg); color:var(--ink); font:14px/1.5 "Segoe UI",Arial,sans-serif}
  header{padding:14px 18px 10px; border-bottom:1px solid var(--line); background:linear-gradient(180deg,#12161f,#0b0e13)}
  h1{margin:0 0 6px; font-size:19px}
  h1 b{color:var(--gold)}
  .hint{color:var(--dim); font-size:12.5px; max-width:1150px}
  .hint b{color:var(--gold)}
  .bar{display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:10px 0 6px}
  button{background:#1b222d; color:var(--ink); border:1px solid var(--line); border-radius:8px; padding:8px 14px; font:600 13px/1 "Segoe UI",Arial; cursor:pointer}
  button:hover{border-color:var(--gold)}
  button.primary{background:linear-gradient(180deg,#f7c957,#e8a925); border-color:#c98d12; color:#241a02}
  button.danger{color:#ffb4b4}
  button.danger:hover{border-color:var(--bad)}
  #out{display:none; width:100%; height:150px; margin-top:6px; background:#0d1117; color:#cfe3ff; border:1px solid var(--line); border-radius:8px; padding:8px; font:12px/1.4 monospace; text-align:left}
  main{display:flex; gap:14px; padding:14px 18px; align-items:flex-start}
  nav{width:250px; flex:none; display:flex; flex-direction:column; gap:5px; position:sticky; top:12px; max-height:calc(100vh - 24px); overflow-y:auto; padding-right:2px}
  .navgroup{color:var(--gold); font:700 11px/1 "Segoe UI"; letter-spacing:.6px; margin:10px 2px 3px}
  .navgroup:first-child{margin-top:0}
  .dealerbtn{display:flex; align-items:center; gap:8px; text-align:left; padding:8px 10px}
  .dealerbtn small{color:var(--dim)}
  .dot{width:9px; height:9px; border-radius:50%; background:#3a4256; flex:none}
  .dot.ok{background:var(--ok)} .dot.mod{background:var(--gold)} .dot.bad{background:var(--bad)}
  section{flex:1; min-width:0}
  .empty{color:var(--dim); padding:40px; text-align:center; border:1px dashed var(--line); border-radius:12px}
  .casehead{display:flex; gap:10px; align-items:center; flex-wrap:wrap; background:var(--panel); border:1px solid var(--line); border-radius:12px; padding:10px 12px}
  .casehead .code{font:700 12px monospace; background:#0d1117; border:1px solid var(--line); border-radius:6px; padding:5px 8px; color:var(--accent)}
  .badge{font:700 10.5px/1 "Segoe UI"; letter-spacing:.5px; border-radius:6px; padding:5px 8px; border:1px solid var(--line); color:var(--dim)}
  .badge.farm{color:#8ce99a; border-color:rgba(140,233,154,.35)}
  .badge.level{color:#f5b942; border-color:rgba(245,185,66,.4)}
  .badge.test{color:#4cc2ff; border-color:rgba(76,194,255,.4)}
  .subline{width:100%; color:var(--dim); font-size:12px}
  input,select{background:#0d1117; color:var(--ink); border:1px solid var(--line); border-radius:7px; padding:8px 9px; font:600 13px "Segoe UI",Arial}
  input:focus,select:focus{outline:none; border-color:var(--gold)}
  input[type=number]{width:86px; text-align:left}
  input:disabled{opacity:.5; cursor:not-allowed}
  label.lbl{color:var(--dim); font-size:12px}
  .sum{font:700 12.5px "Segoe UI"; padding:6px 10px; border-radius:7px; border:1px solid var(--line)}
  .sum.ok{color:var(--ok); border-color:rgba(55,214,122,.45)}
  .sum.bad{color:var(--bad); border-color:rgba(255,93,93,.45)}
  .hint2{color:var(--dim); font-size:12.5px; margin:8px 2px}
  .hint2 b{color:var(--gold)}
  .calc{display:flex; gap:14px; align-items:center; flex-wrap:wrap; background:#101623; border:1px solid #1d2740; border-radius:10px; padding:9px 12px; margin:8px 0}
  .calc .lbl{color:var(--dim); font-size:12px}
  .calc b.gold{color:var(--gold); font-size:15px}
  .calc b.pos{color:var(--ok)} .calc b.neg{color:var(--bad)}
  .calc .sep{width:1px; height:22px; background:var(--line)}
  .calc .note{color:var(--dim); font-size:10.5px; flex-basis:100%}
  .actions{display:flex; gap:8px; flex-wrap:wrap; margin:8px 0}
  table{width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--line); border-radius:12px; overflow:hidden}
  th{background:#161c26; color:var(--dim); font-size:11.5px; text-align:left; padding:9px 8px; border-bottom:1px solid var(--line)}
  td{padding:7px 8px; border-bottom:1px solid #1a2029; vertical-align:middle}
  tr:last-child td{border-bottom:none}
  td .nm{display:flex; align-items:center; gap:8px; min-width:260px}
  .rarity{width:10px; height:26px; border-radius:3px; background:#3a4256; flex:none}
  td .nm input{flex:1; min-width:150px}
  .est{color:var(--dim); font-size:10px; flex:none; width:16px; text-align:center; cursor:help}
  .picker{position:relative}
  .sugg{position:absolute; z-index:30; top:calc(100% + 3px); left:0; right:0; background:#10151d; border:1px solid var(--gold); border-radius:8px; max-height:250px; overflow-y:auto; box-shadow:0 14px 30px rgba(0,0,0,.55)}
  .sugg .it{display:flex; gap:8px; align-items:center; padding:7px 9px; cursor:pointer; font-size:12.5px}
  .sugg .it:hover{background:#1a2230}
  .sugg .it .r{width:7px; height:18px; border-radius:2px; flex:none}
  .sugg .it small{color:var(--dim); margin-left:auto}
  .sugg .none{padding:8px 10px; color:var(--dim); font-size:12px}
  .del{padding:5px 10px}
  #flash{position:fixed; bottom:18px; left:50%; transform:translateX(-50%) translateY(20px); background:var(--gold); color:#241a02; font:700 13px "Segoe UI"; padding:10px 18px; border-radius:10px; opacity:0; pointer-events:none; transition:all .25s}
  #flash.show{opacity:1; transform:translateX(-50%) translateY(0)}
  @media(max-width:860px){
    main{flex-direction:column}
    nav{position:static; width:100%; max-height:none; flex-direction:row; flex-wrap:wrap}
    section{width:100%}
    .navgroup{flex-basis:100%}
    .dealerbtn{flex:1 1 auto}
    td .nm{min-width:150px}
    input[type=number]{width:72px; padding:7px 5px}
    td,th{padding:6px 4px}
  }
`;

const BODY = `
<header>
  <h1>ROLLBOX — <b>DROP EDITOR</b> <span style="color:var(--dim); font-size:13px; font-weight:400">(every case + every terminal)</span></h1>
  <div class="hint">
    Standalone editor — nothing is saved to a server. When you are done press <b>Copy for chat</b> and paste the result back into the chat (or download the txt file and attach it) and the changes get applied to the site.<br>
    This file covers <b>every case on the site</b> — standard RB-101..RB-120, farm RB-201..RB-210, the free daily LEVEL cases and the TEST case — plus all <b>five TERMINALS</b> (the dealers).<br>
    <b>Skin dropdown (Task 27):</b> type in the name field to search <b>EVERY skin in the game</b> — including <b>StatTrak™</b> and <b>Souvenir</b> variants — and the <b>value fills itself per wear</b> from the price tables: real steamanalyst.com (CSFLOAT) prices first (<span id="unifiedCount">—</span>), the site market tables second, factor estimates last (marked <b>~</b>). The <b>Auto values</b> button re-computes a whole table at once.<br>
    <b>Cases:</b> for every skin set the <b>drop chance (%)</b> — the table must sum to 100 — and the <b>coin value</b> credited for that item. <b>Wear</b> picks the exterior (FN / MW / FT / WW / BS) — only the wears the skin actually comes in are offered. <b>ROLLDROP</b> is the ultra-rare bonus-drop chance per opening (site default 0.095%).<br>
    <b>Daily (LEVEL) cases:</b> the shell (name / price / unlock level) is system-owned — edit drops and values only.<br>
    <b>Terminals:</b> pick which skins each dealer offers, set percentages (must sum to 100) and the value <b>at the dealer's MAX deal</b>; MIN and MAX are editable here. A purchase shows up to <b>5 distinct offers</b> — the player takes one, and the fifth offer is forced.
  </div>
  <div class="bar">
    <button id="copyBtn" class="primary">Copy for chat</button>
    <button id="dlBtn">Download txt</button>
    <button id="showBtn">Show what will be sent</button>
    <span id="status" style="color:var(--dim); font-size:13px"></span>
  </div>
  <textarea id="out" readonly></textarea>
</header>
<main>
  <nav id="navList"></nav>
  <section id="pane"><div class="empty">Pick a case or a terminal from the list to edit its drops</div></section>
</main>
<div id="flash"></div>
`;

export function renderEditor(skinsJson, casesJson, terminalsJson, gameJson, unifiedJson, rate, unifiedUpdatedAt) {
  const js = [
    '<script>',
    '// ============ data (injected from the site data layer) ============',
    'const SKINS = ' + skinsJson + ';',
    'const RARITY_COLORS = {consumer:"#b0c3d9", milspec:"#4b69ff", restricted:"#8847ff", classified:"#d32ce6", covert:"#eb4b4b", contraband:"#ffd700"};',
    'const WEARS = [["FN","Factory New"],["MW","Minimal Wear"],["FT","Field-Tested"],["WW","Well-Worn"],["BS","Battle-Scarred"]];',
    'const WEAR_FACTOR = {FN:1.45, MW:1.18, FT:1, WW:0.87, BS:0.78};',
    'const DEFAULT_RD_PCT = 0.095;',
    'const BASE_CASES = ' + casesJson + ';',
    'const BASE_TERMINALS = ' + terminalsJson + ';',
    '// Task 27: the FULL-GAME picker (every base skin + StatTrak™ / Souvenir variants) and',
    '// the unified price table (steamanalyst.com / CSFLOAT real prices, USD) at the site rate.',
    'const GAME = ' + gameJson + ';',
    'const UNIFIED = ' + unifiedJson + ';',
    'const RATE = ' + rate + ';',
    'const UNIFIED_AT = ' + unifiedUpdatedAt + ';',
    EDITOR_JS,
    '<' + '/script>'
  ].join('\n');
  return '<!doctype html>\n<html lang="en" dir="ltr">\n<head>\n<meta charset="utf-8">\n'
    + '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
    + '<title>ROLLBOX — DROP EDITOR (cases + terminals)</title>\n'
    + '<style>' + CSS + '</style>\n</head>\n<body>\n' + BODY + js + '\n</body>\n</html>\n';
}

// ===================== editor application logic =====================
const EDITOR_JS = `
// ============ helpers ============
var $ = function(s){ return document.querySelector(s); };
function esc(s){ return String(s == null ? "" : s).replace(/[&<>"]/g, function(m){ return ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[m]; }); }
function fmtCoins(x){ x = +x || 0; return (Math.round(x * 100) / 100).toLocaleString("en-US", {minimumFractionDigits:0, maximumFractionDigits:2}); }
function fmtPct(x){ return String(Math.round((+x || 0) * 1e6) / 1e6); }
function flash(msg){
  var f = $("#flash"); f.textContent = msg; f.classList.add("show");
  setTimeout(function(){ f.classList.remove("show"); }, 2200);
}

// ============ skin catalog helpers ============
function skinOf(id){ return id ? SKINS[id] : null; }
function availWears(skinId){
  var s = skinOf(skinId);
  if(!s) return [];
  if(s.wa) return s.wa.slice(); // explicit availability (may be empty = no exterior)
  // absent = every CS2 wear (the site entryWearIds rule — user skins included)
  return WEARS.map(function(w){ return w[0]; });
}
function wearLabel(w){ for(var i = 0; i < WEARS.length; i++) if(WEARS[i][0] === w) return WEARS[i][1]; return w; }

// ============ FULL-GAME picker (Task 27) ============
// every base skin in the game + its StatTrak™ / Souvenir variants — the
// dropdown covers ALL of them, priced per wear from the unified table
// (steamanalyst.com / CSFLOAT real prices) first, the site tables second.
var GAME_BY_NAME = {};
for(var _gi = 0; _gi < GAME.length; _gi++) GAME_BY_NAME[GAME[_gi].n] = GAME[_gi];
var QUALITY_PREFIX = {normal:"", st:"StatTrak™ ", sv:"Souvenir "};
var QUALITY_MULT = {normal:1, st:1.5, sv:2}; // last-resort estimate multipliers
function gameEntryOf(name){
  var n = String(name || "").replace(/\s+/g, " ").trim();
  var q = "normal";
  if(n.indexOf("StatTrak™ ") === 0) q = "st";
  else if(n.indexOf("Souvenir ") === 0) q = "sv";
  var bare = n.replace(/^StatTrak™ /, "").replace(/^Souvenir /, "");
  var g = GAME_BY_NAME[bare];
  return g ? {g:g, q:q} : null;
}
function availWearsGame(g){
  if(g.wa === null) return WEARS.map(function(w){ return w[0]; });
  return (g.wa || []).slice();
}
function normSearch(s){ return String(s || "").toLowerCase().replace(/™/g, "").replace(/\s+/g, " ").trim(); }
/** mirrors the site resolution: REAL unified price > site wear table > nearest-wear > factor estimate.
 *  Variant estimates carry the quality multiplier (StatTrak™ x1.5 / Souvenir x2) and are always ~. */
function gameValue(g, q, wear){
  var full = (QUALITY_PREFIX[q] || "") + g.n + (wear ? " (" + wearLabel(wear) + ")" : "");
  if(UNIFIED[full] > 0) return {v:Math.max(0.01, Math.round(UNIFIED[full] * 100 * RATE) / 100), est:false};
  var wp = g.wp || null;
  var qm = QUALITY_MULT[q] || 1;
  if(wp && wp[wear] > 0) return {v:Math.max(1, Math.round(wp[wear] * qm)), est: q !== "normal"};
  if(wp){
    var best = null;
    for(var w in wp){
      if(!wp[w]) continue;
      if(!best || Math.abs(WEAR_FACTOR[w] - WEAR_FACTOR[wear]) < Math.abs(WEAR_FACTOR[best.w] - WEAR_FACTOR[wear])) best = {w:w, v:wp[w]};
    }
    if(best) return {v:Math.max(1, Math.round(best.v * WEAR_FACTOR[wear] / WEAR_FACTOR[best.w] * qm)), est:true};
  }
  var base = 0;
  if(wp){ for(var w2 in wp) if(wp[w2]){ base = wp[w2]; break; } }
  return {v:Math.max(1, Math.round(base * WEAR_FACTOR[wear] * qm)), est:true};
}
/** mirrors the site skinWearValue: market price > nearest-wear estimate > base x factor */
function computeValue(skinId, wear){
  var s = skinOf(skinId);
  if(!s) return {v:0, est:false};
  if(!wear) return {v:s.value, est:false};
  var wp = s.wp || null;
  if(wp && wp[wear] > 0) return {v:wp[wear], est:false};
  if(wp){
    var best = null;
    for(var w in wp){
      if(!wp[w]) continue;
      if(!best || Math.abs(WEAR_FACTOR[w] - WEAR_FACTOR[wear]) < Math.abs(WEAR_FACTOR[best.w] - WEAR_FACTOR[wear])) best = {w:w, v:wp[w]};
    }
    if(best) return {v:Math.max(1, Math.round(best.v * WEAR_FACTOR[wear] / WEAR_FACTOR[best.w])), est:true};
  }
  return {v:Math.max(1, Math.round(s.value * WEAR_FACTOR[wear])), est:true};
}

// ============ state ============
var cases = BASE_CASES.map(function(c){
  return {
    code:c.code, name:c.name, sub:c.subtitle || "", kind:c.kind, grp:c.grp || c.kind, price:+c.price || 0, lvl:c.lvl || null,
    rd:(c.rd == null ? null : +c.rd),
    items:c.items.map(function(i){ return {id:i.id || null, n:i.n, v:+i.v || 0, p:+i.p || 0, w:i.w || null, pin:!!i.pin}; })
  };
});
var terminals = BASE_TERMINALS.map(function(t){
  return {
    id:t.id, name:t.name, sub:t.subtitle || "", min:+t.min || 1, max:+t.max || 0,
    skins:t.skins.map(function(s){ return {id:s.id || null, n:s.n, v:+s.v || 0, p:+s.p || 0}; })
  };
});
var selected = null;        // "case:RB-101" / "term:danny"
var selKind = null, selId = null;

function findCase(code){ for(var i=0;i<cases.length;i++) if(cases[i].code === code) return cases[i]; return null; }
function findTerm(id){ for(var i=0;i<terminals.length;i++) if(terminals[i].id === id) return terminals[i]; return null; }

// ============ change detection ============
function caseChanged(c){
  var b = null;
  for(var i=0;i<BASE_CASES.length;i++) if(BASE_CASES[i].code === c.code) b = BASE_CASES[i];
  if(!b) return true;
  var isLvl = c.kind === "level";
  if(!isLvl && (c.name !== b.name || +c.price !== +b.price)) return true;
  if((c.rd == null ? null : Math.round(c.rd * 1e6) / 1e6) !== (b.rd == null ? null : Math.round(b.rd * 1e6) / 1e6)) return true;
  var norm = function(items){ return JSON.stringify(items.map(function(i){ return [i.id || null, i.n, +i.v || 0, Math.round((+i.p || 0) * 1e6) / 1e6, i.w || null]; })); };
  var bItems = b.items.map(function(i){ return {id:i.id || null, n:i.n, v:+i.v || 0, p:+i.p || 0, w:i.w || null}; });
  return norm(c.items) !== norm(bItems);
}
function termChanged(t){
  var b = null;
  for(var i=0;i<BASE_TERMINALS.length;i++) if(BASE_TERMINALS[i].id === t.id) b = BASE_TERMINALS[i];
  if(!b) return true;
  var norm = function(x){ return JSON.stringify({n:x.name, mn:+x.min, m:+x.max, sk:x.skins.map(function(s){ return [s.id || null, s.n, +s.v || 0, Math.round((+s.p || 0) * 1e6) / 1e6]; })}); };
  return norm(t) !== norm({name:b.name, min:+b.min, max:+b.max, skins:b.skins});
}
function sumOf(items){ return items.reduce(function(a,i){ return a + (+i.p || 0); }, 0); }
function entState(sum, changed, hasItems){
  if(hasItems && Math.abs(sum - 100) >= 0.01) return "bad";
  return changed ? "mod" : "ok";
}

// ============ math: cases ============
function caseAvg(items){
  var tp = 0, acc = 0;
  items.forEach(function(i){ tp += (+i.p || 0); acc += (+i.v || 0) * (+i.p || 0); });
  return tp > 0 ? acc / tp : 0;
}
// ============ math: terminals ============
function avgDraw(skins){
  var total = skins.reduce(function(a,s){ return a + (+s.p || 0); }, 0);
  return skins.reduce(function(a,s){ return a + (+s.v || 0) * (+s.p || 0); }, 0) / Math.max(1e-9, total);
}
/** best-of-5 EV via Monte-Carlo (5 distinct weighted draws, like the site) */
function best5EV(skins, iters){
  iters = iters || 3000;
  var ps = skins.map(function(s){ return +s.p || 0; }), vs = skins.map(function(s){ return +s.v || 0; });
  var acc = 0;
  for(var it = 0; it < iters; it++){
    var alive = ps.map(function(){ return true; });
    var best = 0;
    for(var k = 0; k < 5 && k < alive.length; k++){
      var total = 0;
      for(var i = 0; i < ps.length; i++) if(alive[i]) total += ps[i];
      if(total <= 0) break;
      var r = Math.random() * total, pick = -1;
      for(var j = 0; j < ps.length; j++){ if(!alive[j]) continue; r -= ps[j]; if(r <= 0){ pick = j; break; } }
      if(pick < 0) pick = ps.length - 1;
      alive[pick] = false;
      if(vs[pick] > best) best = vs[pick];
    }
    acc += best;
  }
  return acc / iters;
}

// ============ catalog picker ============
function searchSkins(q){
  var out = [];
  q = String(q || "").trim();
  if(q.length < 2) return out;
  // token-AND search, order-independent: "souvenir desert hydra" hits
  // "Souvenir AWP | Desert Hydra", "stattrak awp asiimov" hits "StatTrak™ AWP | Asiimov"
  var toks = normSearch(q).split(" ").filter(Boolean);
  if(!toks.length) return out;
  var hit = function(s){
    s = normSearch(s);
    for(var i = 0; i < toks.length; i++) if(s.indexOf(toks[i]) < 0) return false;
    return true;
  };
  // 1) the case registry — every skin the site knows by id (incl stickers)
  for(var id in SKINS){
    var s = SKINS[id];
    if(hit(s.name) || hit(id)){
      out.push({id:id, name:s.name, v:s.value, r:s.rarity});
      if(out.length >= 8) return out;
    }
  }
  // 2) the FULL GAME list + StatTrak™ / Souvenir variants (Task 27)
  for(var i = 0; i < GAME.length; i++){
    var g = GAME[i];
    var vars = [{q:"normal", n:g.n}];
    if(g.st) vars.push({q:"st", n:"StatTrak™ " + g.n});
    if(g.sv) vars.push({q:"sv", n:"Souvenir " + g.n});
    for(var j = 0; j < vars.length; j++){
      if(hit(vars[j].n) || hit(g.id)){
        var known = vars[j].q === "normal" && !!SKINS[g.id];
        out.push({id: known ? g.id : null, name:vars[j].n, v:gameValue(g, vars[j].q, "FT").v, r:g.r, g:g, q:vars[j].q});
        if(out.length >= 8) return out;
      }
    }
  }
  return out;
}
function closeSugg(){ var all = document.querySelectorAll(".sugg"); for(var i=0;i<all.length;i++) all[i].remove(); }
document.addEventListener("mousedown", function(e){ if(!e.target.closest || !e.target.closest(".picker")) closeSugg(); });
/** wrap the items table so phones scroll it horizontally (desktop: no clip — keeps the dropdown visible) */
var onWinResize = null;
function scrollWrap(el){
  var wrap = document.createElement("div");
  wrap.appendChild(el);
  var apply = function(){ wrap.style.overflowX = (window.innerWidth <= 860) ? "auto" : "visible"; };
  apply();
  if(onWinResize) window.removeEventListener("resize", onWinResize);
  onWinResize = apply;
  window.addEventListener("resize", apply);
  return wrap;
}
function openSugg(idx, inputEl, onPick){
  closeSugg(); // never stack boxes — each keystroke replaces the list
  var hits = searchSkins(inputEl.value);
  var box = document.createElement("div");
  box.className = "sugg";
  if(!hits.length){
    box.innerHTML = '<div class="none">No catalog match — a free-name row is kept as-is</div>';
  } else {
    hits.forEach(function(h){
      var it = document.createElement("div");
      it.className = "it";
      it.innerHTML = '<span class="r" style="background:' + (RARITY_COLORS[h.r] || "#3a4256") + '"></span><span>' + esc(h.name) + '</span><small>' + esc(fmtCoins(h.v)) + '</small>';
      it.onmousedown = function(ev){ ev.preventDefault(); onPick(h); box.remove(); };
      box.appendChild(it);
    });
  }
  inputEl.parentNode.appendChild(box);
}

// ============ export ============
function caseLine(c){
  var items = c.items.map(function(i){
    var o = {n:String(i.n).trim(), v:Math.round((+i.v || 0) * 100) / 100, p:Math.round((+i.p || 0) * 1e6) / 1e6};
    if(i.id) o.id = i.id;
    if(i.w) o.w = i.w;
    if(i.g) o.g = i.g;
    if(i.q && i.q !== "normal") o.q = i.q;
    return o;
  });
  if(c.kind === "level"){
    // daily shell is system-owned: content-only patch (items + optional ROLLDROP)
    var line = {code:c.code};
    if(c.rd != null) line.rd = Math.round(c.rd * 1e6) / 1e6;
    line.items = items;
    return line;
  }
  return {code:c.code, name:c.name.trim() || c.code, price:Math.max(0, +c.price || 0), kind:c.kind,
          rd:(c.rd == null ? null : Math.round(c.rd * 1e6) / 1e6), items:items};
}
function termLine(t){
  return {id:t.id, name:t.name.trim() || t.id, min:Math.max(1, Math.round(+t.min || 1)), max:+t.max || 0,
          skins:t.skins.map(function(s){
            var o = {n:String(s.n).trim(), v:Math.round((+s.v || 0) * 100) / 100, p:Math.round((+s.p || 0) * 1e6) / 1e6};
            if(s.id) o.id = s.id;
            if(s.g) o.g = s.g;
            if(s.q && s.q !== "normal") o.q = s.q;
            return o;
          })};
}
function buildOutput(){
  var lines = [];
  var cl = cases.filter(function(c){ return caseChanged(c); }).map(caseLine);
  if(cl.length){ lines.push("ROLLBOX-CASES v1"); lines = lines.concat(cl.map(JSON.stringify)); }
  var tl = terminals.filter(function(t){ return termChanged(t); }).map(termLine);
  if(tl.length){ lines.push("ROLLBOX-TERMINALS v1"); lines = lines.concat(tl.map(JSON.stringify)); }
  return lines.join("\\n");
}
function statusText(){
  var nc = cases.filter(function(c){ return caseChanged(c); }).length;
  var nt = terminals.filter(function(t){ return termChanged(t); }).length;
  $("#status").textContent = nc + " case(s) + " + nt + " terminal(s) changed";
}

// ============ nav ============
var GROUPS = [
  {key:"standard", label:"CASES — STANDARD"},
  {key:"farm", label:"CASES — FARM"},
  {key:"level", label:"CASES — DAILY (LEVEL)"},
  {key:"test", label:"CASES — TEST"},
  {key:"term", label:"TERMINALS"}
];
function groupOf(c){ return c.grp || c.kind; }
function renderNav(){
  var nav = $("#navList"); nav.innerHTML = "";
  GROUPS.forEach(function(g){
    var entries = g.key === "term" ? terminals : cases.filter(function(c){ return groupOf(c) === g.key; });
    if(!entries.length) return;
    var h = document.createElement("div");
    h.className = "navgroup";
    h.textContent = g.label + " (" + entries.length + ")";
    nav.appendChild(h);
    entries.forEach(function(e){
      var b = document.createElement("button");
      b.className = "dealerbtn";
      var isTerm = g.key === "term";
      var key = isTerm ? "term:" + e.id : "case:" + e.code;
      var sum = isTerm ? sumOf(e.skins) : sumOf(e.items);
      var st = entState(sum, isTerm ? termChanged(e) : caseChanged(e), (isTerm ? e.skins : e.items).length > 0);
      var small = isTerm ? ("MIN " + e.min + " · MAX " + e.max) : (e.kind === "level" ? "FREE · daily" : e.price + " coins");
      b.innerHTML = '<span class="dot ' + st + '"></span><span style="flex:1; overflow:hidden"><span style="font-family:monospace; font-size:11.5px">' + esc(isTerm ? e.id : e.code) + '</span><br><small>' + esc(isTerm ? e.name : e.name) + '</small></span><small>' + esc(small) + '</small>';
      if(key === selected) b.style.borderColor = "var(--gold)";
      b.onclick = function(){ selected = key; selKind = isTerm ? "term" : "case"; selId = isTerm ? e.id : e.code; renderNav(); renderPane(); };
      nav.appendChild(b);
    });
  });
  statusText();
}

// ============ case pane ============
function renderPane(){
  var pane = $("#pane");
  pane.innerHTML = "";
  if(!selected){ pane.innerHTML = '<div class="empty">Pick a case or a terminal from the list to edit its drops</div>'; return; }
  if(selKind === "term") renderTermPane(pane); else renderCasePane(pane);
}

function renderCasePane(pane){
  var c = findCase(selId);
  if(!c) return;
  var isLvl = c.kind === "level";

  var head = document.createElement("div");
  head.className = "casehead";
  head.innerHTML =
    '<span class="code">' + esc(c.code) + '</span>' +
    '<span class="badge ' + esc(c.grp) + '">' + esc(c.grp.toUpperCase()) + '</span>' +
    '<input id="cName" style="flex:1; min-width:160px" value="' + esc(c.name) + '"' + (isLvl ? ' disabled title="Daily case shell is system-owned — edit drops only"' : ' placeholder="Case name"') + '>' +
    '<label class="lbl" title="What a player pays for one opening">Price</label>' +
    '<input id="cPrice" type="number" min="0" style="width:80px" value="' + esc(c.price) + '"' + (isLvl ? ' disabled' : '') + '>' +
    '<label class="lbl" title="Ultra-rare bonus drop chance per opening (site default 0.095%)">ROLLDROP %</label>' +
    '<input id="cRd" type="number" min="0" step="0.001" style="width:95px" value="' + esc(c.rd == null ? DEFAULT_RD_PCT : Math.round(c.rd * 100 * 1e6) / 1e6) + '">' +
    '<span id="cSum" class="sum"></span>' +
    (isLvl ? '<span class="subline">Free daily vault — unlocks at Level ' + esc(c.lvl) + ' · refills every 24h · name &amp; price are system-owned</span>'
           : (c.sub ? '<span class="subline">' + esc(c.sub) + '</span>' : ''));
  pane.appendChild(head);

  var note = document.createElement("div");
  note.className = "hint2";
  note.innerHTML = '<b>Chance (%)</b> is each skin\\'s drop probability — the column must sum to <b>100</b>. <b>Value</b> is the coins credited for the item at the selected wear; <b>~</b> marks a factor estimate (no market listing). Editing the value pins it; changing the wear re-computes it from the market table.';
  pane.appendChild(note);

  var calc = document.createElement("div");
  calc.className = "calc";
  calc.innerHTML =
    '<span class="lbl">Case math:</span>' +
    '<span class="lbl">Cost</span><b id="cCost" class="gold">—</b>' +
    '<span class="sep"></span>' +
    '<span class="lbl">Average drop</span><b id="cAvg" class="gold">—</b>' +
    '<span class="sep"></span>' +
    '<span class="lbl">House edge</span><b id="cEdge">—</b>' +
    '<span class="note">Average drop = the value a random opening returns on average (sum of chance x value). House edge = (cost - average drop) / cost. Free daily cases have no cost — only the average is shown.</span>';
  pane.appendChild(calc);

  var tools = document.createElement("div");
  tools.className = "actions";
  tools.innerHTML =
    '<button id="cNorm">Normalize to 100</button>' +
    '<button id="cAdd">+ Add skin</button>' +
    '<button id="cAuto" title="Re-compute every value from the price tables (real price > site table > estimate)">Auto values</button>' +
    '<button id="cReset" class="danger">Reset to original</button>';
  pane.appendChild(tools);

  var tbl = document.createElement("table");
  tbl.innerHTML = '<thead><tr><th style="width:52%">Skin — type to pick from the catalog (or free name)</th><th style="width:120px">Wear</th><th>Value (coins)</th><th>Chance (%)</th><th></th></tr></thead><tbody id="cTbody"></tbody>';
  pane.appendChild(scrollWrap(tbl));

  $("#cName").oninput = function(e){ c.name = e.target.value; renderNav(); };
  $("#cPrice").oninput = function(e){ c.price = +e.target.value || 0; updateCaseCalc(); renderNav(); };
  $("#cRd").oninput = function(e){
    var v = parseFloat(e.target.value);
    c.rd = (isNaN(v) || Math.round(v * 1e6) / 1e6 === DEFAULT_RD_PCT) ? null : Math.round(v / 100 * 1e9) / 1e9;
    renderNav();
  };
  $("#cNorm").onclick = function(){
    var s = sumOf(c.items); if(s <= 0) return;
    var factor = 100 / s;
    c.items.forEach(function(i){ i.p = Math.round((+i.p || 0) * factor * 1e6) / 1e6; });
    var acc = sumOf(c.items);
    var diff = Math.round((100 - acc) * 1e6) / 1e6;
    if(c.items.length){
      var big = 0;
      for(var i = 1; i < c.items.length; i++) if((+c.items[i].p || 0) > (+c.items[big].p || 0)) big = i;
      c.items[big].p = Math.round(((+c.items[big].p || 0) + diff) * 1e6) / 1e6;
    }
    renderItems(); updateCaseCalc(); setCaseBadge(); renderNav();
  };
  $("#cAdd").onclick = function(){ c.items.push({id:null, n:"", v:0, p:0, w:null, pin:false}); renderItems(); setCaseBadge(); };
  $("#cAuto").onclick = function(){
    var n = 0;
    c.items.forEach(function(k){
      var g = k.g ? GAME_BY_NAME[k.g] : null;
      if(g){
        var cv = gameValue(g, k.q || "normal", k.w || "FT");
        k.v = cv.v; k.estm = cv.est; k.pin = false; n++;
      } else if(k.id && skinOf(k.id)){
        var s = skinOf(k.id);
        if(k.w){ var cv2 = computeValue(k.id, k.w); k.v = cv2.v; k.estm = cv2.est; }
        else k.v = s.value;
        k.pin = false; n++;
      }
    });
    renderItems(); updateCaseCalc(); renderNav();
    flash(n ? "Re-computed " + n + " value(s) from the price tables" : "No catalog rows to re-compute");
  };
  $("#cReset").onclick = function(){
    var b = null;
    for(var i = 0; i < BASE_CASES.length; i++) if(BASE_CASES[i].code === c.code) b = BASE_CASES[i];
    if(!b) return;
    c.name = b.name; c.price = +b.price || 0; c.rd = (b.rd == null ? null : +b.rd);
    c.items = b.items.map(function(i){ return {id:i.id || null, n:i.n, v:+i.v || 0, p:+i.p || 0, w:i.w || null, pin:!!i.pin}; });
    renderPane(); renderNav(); flash("Restored to the original site values");
  };

  function setCaseBadge(){
    var s = Math.round(sumOf(c.items) * 1e4) / 1e4;
    var ok = Math.abs(s - 100) < 0.01;
    var bEl = $("#cSum");
    bEl.textContent = "SUM " + fmtPct(s);
    bEl.className = "sum " + (ok ? "ok" : "bad");
  }
  function updateCaseCalc(){
    var cost = +c.price || 0, avg = caseAvg(c.items);
    $("#cCost").textContent = fmtCoins(cost);
    $("#cAvg").textContent = fmtCoins(avg);
    var eEl = $("#cEdge");
    if(cost > 0){
      var edge = (cost - avg) / cost * 100;
      eEl.textContent = Math.round(edge * 100) / 100 + "%";
      eEl.className = edge >= 0 ? "pos" : "neg";
    } else {
      eEl.textContent = "— (free)";
      eEl.className = "";
    }
  }

  function renderItems(){
    var tb = $("#cTbody"); tb.innerHTML = "";
    c.items.forEach(function(k, idx){
      var tr = document.createElement("tr");
      var sk = skinOf(k.id);
      var rk = k.r || (sk ? sk.rarity : null);
      var col = rk ? (RARITY_COLORS[rk] || "#3a4256") : "#3a4256";
      var isGame = !!k.g;
      var est = !k.pin && (isGame ? (k.estm !== false && !!k.n) : (!!k.id && !!k.w));
      var gEnt = isGame ? GAME_BY_NAME[k.g] : null;
      var avail = isGame ? availWearsGame(gEnt) : availWears(k.id);
      var wearOpts = '<option value="">—</option>';
      avail.forEach(function(w){
        var lbl = "";
        for(var i = 0; i < WEARS.length; i++) if(WEARS[i][0] === w) lbl = WEARS[i][0] + " — " + WEARS[i][1];
        wearOpts += '<option value="' + w + '"' + (k.w === w ? " selected" : "") + '>' + esc(lbl || w) + '</option>';
      });
      tr.innerHTML =
        '<td><div class="nm">' +
          '<span class="rarity" style="background:' + col + '"></span>' +
          '<span class="picker"><input data-i="' + idx + '" data-k="n" value="' + esc(k.n) + '" placeholder="Skin name"></span>' +
        '</div></td>' +
        '<td><select data-i="' + idx + '" data-k="w"' + (avail.length ? '' : ' disabled title="This item has no exterior"') + '>' + wearOpts + '</select></td>' +
        '<td><span class="est" title="' + (est ? "Estimated value — no market listing for this wear" : "") + '">' + (est ? "~" : "") + '</span><input type="number" min="0" step="0.01" data-i="' + idx + '" data-k="v" style="width:100px" value="' + esc(k.v) + '"></td>' +
        '<td><input type="number" min="0" step="0.000001" data-i="' + idx + '" data-k="p" style="width:100px" value="' + esc(fmtPct(k.p)) + '"></td>' +
        '<td><button class="del danger" data-i="' + idx + '" title="Remove this skin">X</button></td>';
      tb.appendChild(tr);
      var nin = tr.querySelector('input[data-k="n"]');
      var pickFn = function(h){
        k.id = h.id || null; k.n = h.name; k.pin = false;
        k.r = h.r || k.r; k.g = h.g ? h.g.n : null; k.q = h.q || "normal"; k.estm = null;
        var av = h.g ? availWearsGame(h.g) : availWears(h.id);
        if(av.length){ if(!k.w || av.indexOf(k.w) < 0) k.w = av.indexOf("FT") >= 0 ? "FT" : av[0]; }
        else k.w = null;
        var cv = h.g ? gameValue(h.g, h.q, k.w || "FT") : computeValue(k.id, k.w);
        k.v = cv.v; k.estm = cv.est;
        renderItems(); updateCaseCalc(); renderNav();
      };
      nin.onfocus = function(){ openSugg(idx, nin, pickFn); };
      nin.oninput = function(){ openSugg(idx, nin, pickFn); };
    });
    wireRows();
  }

  function wireRows(){
    var tb = $("#cTbody");
    tb.oninput = function(e){
      var i = +e.target.dataset.i, key = e.target.dataset.k;
      if(isNaN(i) || !key) return;
      var k = c.items[i];
      if(key === "n"){ k.n = e.target.value; }
      else if(key === "v"){ k.v = +e.target.value || 0; k.pin = true; refreshRow(i); }
      else if(key === "p"){ k.p = +e.target.value || 0; setCaseBadge(); updateCaseCalc(); renderNav(); }
    };
    tb.onchange = function(e){
      if(e.target.tagName !== "SELECT") return;
      var i = +e.target.dataset.i;
      var k = c.items[i];
      var w = e.target.value || null;
      k.w = w; k.pin = false;
      var g = k.g ? GAME_BY_NAME[k.g] : null;
      if(g){ var cv = gameValue(g, k.q || "normal", w || "FT"); k.v = cv.v; k.estm = cv.est; }
      else if(k.id){ var cv2 = computeValue(k.id, w); k.v = cv2.v; k.estm = cv2.est; }
      refreshRow(i); updateCaseCalc(); renderNav();
    };
    tb.onclick = function(e){
      if(!e.target.classList || !e.target.classList.contains("del")) return;
      var i = +e.target.dataset.i;
      c.items.splice(i, 1);
      renderItems(); setCaseBadge(); updateCaseCalc(); renderNav();
    };
  }

  function refreshRow(idx){
    var tb = $("#cTbody");
    var cell = tb.children[idx];
    if(!cell) return;
    var k = c.items[idx];
    var g = k.g ? GAME_BY_NAME[k.g] : null;
    var est = !k.pin && (g ? (k.estm !== false && !!k.n) : (!!k.id && !!k.w));
    cell.querySelector(".est").textContent = est ? "~" : "";
    cell.querySelector(".est").title = est ? "Estimated value — no market listing for this wear" : "";
    var vIn = cell.querySelector('input[data-k="v"]');
    if(document.activeElement !== vIn) vIn.value = k.v;
  }

  renderItems(); setCaseBadge(); updateCaseCalc();
}

// ============ terminal pane ============
function renderTermPane(pane){
  var t = findTerm(selId);
  if(!t) return;

  var head = document.createElement("div");
  head.className = "casehead";
  head.innerHTML =
    '<span class="code">' + esc(t.id) + '</span>' +
    '<input id="tName" style="flex:1; min-width:140px" value="' + esc(t.name) + '" placeholder="Dealer name">' +
    '<label class="lbl" title="Minimum purchase for a deal — what the player pays at least">MIN</label>' +
    '<input id="tMin" type="number" min="1" step="1" style="width:80px" value="' + esc(t.min) + '">' +
    '<label class="lbl" title="Maximum purchase for one deal — the table values are priced at this">MAX</label>' +
    '<input id="tMax" type="number" min="1" style="width:90px" value="' + esc(t.max) + '">' +
    '<span id="tSumBadge" class="sum"></span>';
  pane.appendChild(head);

  var note = document.createElement("div");
  note.className = "hint2";
  note.innerHTML = 'The values here are priced at <b>the dealer\\'s MAX</b> — at a smaller deal every offer scales by the same ratio. Each purchase shows one offer at a time (up to <b>5</b>): the player takes or refuses, and the fifth is final — so the <b>EV at MAX</b> is computed on the best of 5 (the worst-case scenario for the house).';
  pane.appendChild(note);

  var calc = document.createElement("div");
  calc.className = "calc";
  calc.innerHTML =
    '<span class="lbl">Profit calculator:</span>' +
    '<span class="lbl">EV at MAX deal (best of 5)</span><b id="tEv" class="gold">—</b>' +
    '<span class="sep"></span>' +
    '<span class="lbl">Average single offer</span><b id="tAvg" class="gold">—</b>' +
    '<span class="sep"></span>' +
    '<span class="lbl">House edge (vs EV)</span><b id="tEdge">—</b>' +
    '<span class="note">Monte-Carlo over 5 distinct offers using your percentages. Recommended house edge: 5%-15% — a player who refuses a lot may take less, which only grows the edge.</span>';
  pane.appendChild(calc);

  var tools = document.createElement("div");
  tools.className = "actions";
  tools.innerHTML =
    '<button id="tNorm">Normalize to 100</button>' +
    '<button id="tAdd">+ Add skin</button>' +
    '<button id="tAuto" title="Re-compute every value from the price tables (real price > site table > estimate)">Auto values</button>' +
    '<button id="tReset" class="danger">Reset to original</button>';
  pane.appendChild(tools);

  var tbl = document.createElement("table");
  tbl.innerHTML = '<thead><tr><th style="width:55%">Skin — type to pick from the catalog (or free name)</th><th>Value (coins) at MAX</th><th>Chance (%)</th><th></th></tr></thead><tbody id="tTbody"></tbody>';
  pane.appendChild(scrollWrap(tbl));

  $("#tName").oninput = function(e){ t.name = e.target.value; renderNav(); };
  $("#tMin").oninput = function(e){ t.min = Math.max(1, Math.round(+e.target.value || 1)); renderNav(); };
  $("#tMax").oninput = function(e){ t.max = +e.target.value || 0; updateCalc(); renderNav(); };
  $("#tNorm").onclick = function(){
    var s = sumOf(t.skins); if(s <= 0) return;
    var factor = 100 / s;
    t.skins.forEach(function(k){ k.p = Math.round((+k.p || 0) * factor * 1e6) / 1e6; });
    var acc = sumOf(t.skins);
    var diff = Math.round((100 - acc) * 1e6) / 1e6;
    if(t.skins.length){
      var big = 0;
      for(var i = 1; i < t.skins.length; i++) if((+t.skins[i].p || 0) > (+t.skins[big].p || 0)) big = i;
      t.skins[big].p = Math.round(((+t.skins[big].p || 0) + diff) * 1e6) / 1e6;
    }
    renderItems(); updateCalc(); setBadge(); renderNav();
  };
  $("#tAdd").onclick = function(){ t.skins.push({id:null, n:"", v:0, p:0}); renderItems(); setBadge(); };
  $("#tAuto").onclick = function(){
    var n = 0;
    t.skins.forEach(function(k){
      var g = k.g ? GAME_BY_NAME[k.g] : null;
      if(g){
        var cv = gameValue(g, k.q || "normal", "FT");
        k.v = cv.v; k.pin = false; n++;
      } else if(k.id && skinOf(k.id)){
        k.v = skinOf(k.id).value; k.pin = false; n++;
      }
    });
    renderItems(); updateCalc(); renderNav();
    flash(n ? "Re-computed " + n + " value(s) from the price tables" : "No catalog rows to re-compute");
  };
  $("#tReset").onclick = function(){
    var b = null;
    for(var i = 0; i < BASE_TERMINALS.length; i++) if(BASE_TERMINALS[i].id === t.id) b = BASE_TERMINALS[i];
    if(!b) return;
    t.name = b.name; t.min = +b.min || 1; t.max = +b.max || 0;
    t.skins = b.skins.map(function(s){ return {id:s.id || null, n:s.n, v:+s.v || 0, p:+s.p || 0}; });
    renderPane(); renderNav(); flash("Restored to the original site values");
  };

  function setBadge(){
    var s = Math.round(sumOf(t.skins) * 1e4) / 1e4;
    var ok = Math.abs(s - 100) < 0.01;
    var b = $("#tSumBadge");
    b.textContent = "SUM " + fmtPct(s);
    b.className = "sum " + (ok ? "ok" : "bad");
  }
  function updateCalc(){
    var max = +t.max || 0;
    var ev = best5EV(t.skins), avg = avgDraw(t.skins);
    $("#tEv").textContent = max > 0 ? fmtCoins(ev) : fmtCoins(ev) + " (no MAX)";
    $("#tAvg").textContent = fmtCoins(avg);
    var edgeEl = $("#tEdge");
    if(max > 0 && ev > 0){
      var edge = (max - ev) / max * 100;
      edgeEl.textContent = Math.round(edge * 100) / 100 + "%";
      edgeEl.className = edge >= 0 ? "pos" : "neg";
    } else { edgeEl.textContent = "—"; edgeEl.className = ""; }
  }

  function renderItems(){
    var tb = $("#tTbody"); tb.innerHTML = "";
    t.skins.forEach(function(k, idx){
      var tr = document.createElement("tr");
      var sk = skinOf(k.id);
      var col = sk ? (RARITY_COLORS[sk.rarity] || "#3a4256") : "#3a4256";
      tr.innerHTML =
        '<td><div class="nm">' +
          '<span class="rarity" style="background:' + col + '"></span>' +
          '<span class="picker"><input data-i="' + idx + '" data-k="n" value="' + esc(k.n) + '" placeholder="Skin name"></span>' +
        '</div></td>' +
        '<td><input type="number" min="0" step="0.01" data-i="' + idx + '" data-k="v" style="width:110px" value="' + esc(k.v) + '"></td>' +
        '<td><input type="number" min="0" step="0.000001" data-i="' + idx + '" data-k="p" style="width:100px" value="' + esc(fmtPct(k.p)) + '"></td>' +
        '<td><button class="del danger" data-i="' + idx + '" title="Remove this skin">X</button></td>';
      tb.appendChild(tr);
      var nin = tr.querySelector('input[data-k="n"]');
      var pickFn = function(h){
        k.id = h.id || null; k.n = h.name; k.pin = false;
        k.r = h.r || k.r; k.g = h.g ? h.g.n : null; k.q = h.q || "normal";
        k.v = h.g ? gameValue(h.g, h.q, "FT").v : Math.round(h.v * 100) / 100;
        renderItems(); updateCalc(); renderNav();
      };
      nin.onfocus = function(){ openSugg(idx, nin, pickFn); };
      nin.oninput = function(){ openSugg(idx, nin, pickFn); };
    });
    wireRows();
  }

  function wireRows(){
    var tb = $("#tTbody");
    tb.oninput = function(e){
      var i = +e.target.dataset.i, key = e.target.dataset.k;
      if(isNaN(i) || !key) return;
      var k = t.skins[i];
      if(key === "n"){ k.n = e.target.value; }
      else if(key === "v"){ k.v = +e.target.value || 0; updateCalc(); }
      else if(key === "p"){ k.p = +e.target.value || 0; setBadge(); updateCalc(); renderNav(); }
    };
    tb.onclick = function(e){
      if(!e.target.classList || !e.target.classList.contains("del")) return;
      var i = +e.target.dataset.i;
      t.skins.splice(i, 1);
      renderItems(); setBadge(); updateCalc(); renderNav();
    };
  }

  renderItems(); setBadge(); updateCalc();
}

// ============ export buttons ============
$("#copyBtn").onclick = function(){
  var txt = buildOutput();
  if(!txt){ flash("Nothing changed yet"); return; }
  var o = $("#out"); o.style.display = "block"; o.value = txt;
  navigator.clipboard.writeText(txt).then(function(){
    flash("Copied — paste it into the chat");
  }, function(){
    flash("Clipboard blocked — copy from the box below");
    o.focus(); o.select();
  });
};
$("#dlBtn").onclick = function(){
  var txt = buildOutput();
  if(!txt){ flash("Nothing changed yet"); return; }
  var a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([txt], {type:"text/plain"}));
  a.download = "ROLLBOX-drop-editor-export.txt";
  a.click(); URL.revokeObjectURL(a.href);
};
$("#showBtn").onclick = function(){
  var o = $("#out");
  if(o.style.display === "block"){ o.style.display = "none"; return; }
  o.value = buildOutput() || "(nothing changed yet)";
  o.style.display = "block";
};

// ============ init ============
(function(){
  var uc = 0; for(var k in UNIFIED) if(UNIFIED[k] > 0) uc++;
  var el = document.getElementById("unifiedCount");
  if(el) el.textContent = uc + " real price names · updated " + (UNIFIED_AT ? new Date(UNIFIED_AT).toISOString().slice(0, 10) : "never") + " · 1$ = " + RATE + " coins";
})();
renderNav();
`;
