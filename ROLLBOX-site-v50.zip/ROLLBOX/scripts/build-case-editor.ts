/**
 * CASE EDITOR builder — canonical pipeline (Task 93, user's editor dialect).
 *
 * The user's uploaded ROLLBOX-cases-editor.html is THE canonical editor: BASE
 * carries the full case model (code/name/subtitle/price/kind/rd + items with
 * id/n/v/p/rarity/w) and SKINS carries the per-skin wear registry (wp = coins
 * per wear from generated-wear-prices, wa = availability). This script injects
 * the CURRENT site data into scripts/case-editor-template.html (the user's
 * file with __CASES_BASE__ / __SKINS__ placeholders) and writes
 * download/ROLLBOX-CASE-EDITOR.html.
 *
 * Usage:  bun scripts/build-case-editor.ts
 * Paths are resolved relative to this script — works on any machine.
 */
import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import path from "node:path";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const TEMPLATE = path.join(ROOT, "scripts", "case-editor-template.html");
const LEGACY_SKINS = path.join(ROOT, "scripts", "editor-data", "SKINS.json"); // value-map preservation
const OUT = path.join(ROOT, "download", "ROLLBOX-CASE-EDITOR.html");
const imp = (rel: string) => import(pathToFileURL(path.join(ROOT, rel)).href);

const casesMod = await imp("src/lib/cases.ts");
const { CASES, SKINS: SITE_SKINS, caseItemValue } = casesMod as typeof import("../src/lib/cases");
const { SKIN_WEAR_PRICES, SKIN_WEAR_AVAIL } = await imp("src/lib/generated-wear-prices.ts") as typeof import("../src/lib/generated-wear-prices");
const { WEAR_BY_ID } = await imp("src/lib/wear.ts") as typeof import("../src/lib/wear");

type AnyRec = Record<string, unknown>;

// ---------- serializer (matches the canonical editor's number format) ----------
// Plain JSON.stringify is almost right, but very small weights must keep
// fixed 6-decimal form ("0.000010", "0.000013") instead of shortest-repr /
// exponential notation. Rule inferred from the canonical file: integers and
// normal decimals use String(x); |x| < 0.00005 uses toFixed(6).
function fmtNum(x: number): string {
  if (Number.isInteger(x)) return String(x);
  if (x !== 0 && Math.abs(x) < 0.00005) return x.toFixed(6);
  return String(x);
}
function ser(x: unknown): string {
  if (x instanceof RawJSON) return x.text; // pre-formatted numeric token
  if (x === null) return "null";
  switch (typeof x) {
    case "number": return fmtNum(x);
    case "string": return JSON.stringify(x);
    case "boolean": return String(x);
  }
  if (Array.isArray(x)) return "[" + x.map(ser).join(",") + "]";
  const body = Object.entries(x as AnyRec).map(([k, v]) => JSON.stringify(k) + ":" + ser(v)).join(",");
  return "{" + body + "}";
}
/** A raw numeric token the serializer emits verbatim. */
class RawJSON { constructor(public text: string) {} }
/**
 * rd (ROLLDROP %) keeps the canonical file's one-decimal token when the value
 * is exact at one decimal (70 -> "70.0"), falls back to the general formatter
 * for finer values (0.095 stays "0.095").
 */
function rdToken(rd: number): RawJSON {
  const t = Math.round(rd * 1000) / 1000;
  return new RawJSON(Math.round(t * 10) % 1 === 0 ? t.toFixed(1) : fmtNum(t));
}


// ---------- BASE ----------
// One entry per site case, in site order. Item shape: id,n,v,p,rarity,(w) —
// exactly the user's editor dialect (w omitted when the item has no exterior).
const base = CASES.map((c) => ({
  code: c.code,
  name: c.name,
  subtitle: c.subtitle,
  price: c.price,
  kind: c.kind,
  rd: c.rolldropChance == null ? null : rdToken(Math.round(c.rolldropChance * 100 * 1e6) / 1e6),
  items: c.items.map((it) => {
    const skin = (SITE_SKINS as AnyRec)[it.skinId] as AnyRec | undefined;
    const entry: AnyRec = {
      id: it.skinId,
      n: skin?.name ?? it.skinId,
      v: caseItemValue(it),
      p: it.weight,
      rarity: skin?.rarity ?? "consumer",
    };
    if (it.wear) entry.w = it.wear;
    return entry;
  }),
}));

// ---------- SKINS ----------
// First-occurrence order across the cases; shape {name,value,rarity,wp?,wa?}.
// wp/wa come from the generated wear-price tables; `value` is display-only
// (the editor never reads it) — preserved from the canonical editor for
// existing skins, else the first case-item value, else the site value.
const legacy = JSON.parse(readFileSync(LEGACY_SKINS, "utf8")) as AnyRec;
const skins: AnyRec = {};
const order: string[] = [];
for (const c of CASES) {
  for (const it of c.items) {
    if (skins[it.skinId]) continue;
    const site = (SITE_SKINS as AnyRec)[it.skinId] as AnyRec | undefined;
    const wp = (SKIN_WEAR_PRICES as AnyRec)[it.skinId] as AnyRec | undefined;
    const wa = (SKIN_WEAR_AVAIL as AnyRec)[it.skinId];
    const entry: AnyRec = {
      name: site?.name ?? it.skinId,
      value:
        (legacy[it.skinId] as AnyRec | undefined)?.value ??
        caseItemValue(it),
      rarity: site?.rarity ?? "consumer",
    };
    if (wp && Object.keys(wp).length) entry.wp = wp;
    if (Array.isArray(wa)) entry.wa = wa;
    skins[it.skinId] = entry;
    order.push(it.skinId);
  }
}
// sanity: availability entries outside the case registry are expected (catalog
// skins the cases don't use) — nothing to do.
const orderedSkins: AnyRec = {};
for (const id of order) orderedSkins[id] = skins[id];

// ---------- inject ----------
const html = readFileSync(TEMPLATE, "utf8");
if (!html.includes("__CASES_BASE__") || !html.includes("__SKINS__")) throw new Error("placeholders missing in template");
const out = html.replace("__CASES_BASE__", ser(base)).replace("__SKINS__", ser(orderedSkins));
writeFileSync(OUT, out);

const kb = (n: number) => (n / 1024).toFixed(1) + " KB";
console.log(`editor built: ${OUT}`);
console.log(`cases: ${base.length} | skins: ${order.length} | size: ${kb(out.length)}`);
console.log(`rd values: ${base.filter((c) => c.rd != null).map((c) => c.code + "=" + (c.rd as unknown instanceof RawJSON ? (c.rd as unknown as RawJSON).text : String(c.rd))).join(", ") || "none"}`);
console.log(`wear-by-id sanity: ${WEAR_BY_ID.FN.label}`);
