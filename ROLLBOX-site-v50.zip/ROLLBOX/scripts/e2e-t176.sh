#!/usr/bin/env bash
# e2e-t176.sh — CASE REEL END-OF-SPIN timing E2E (Task 176)
# User spec: the end of the reel used to sit ~2.4s visually frozen (power-6
# crawl) before the winner locked; the ending must close faster.
# Fix: SPIN_MS 8000→6400 + crawl exponent 6→4 (cases only; battles unchanged).
# Probe: arms a click-listener t0 + a 50ms poller that (a) tracks the strip
# transform for the stillness point, (b) records the LOCK instant via the
# standard lock ring (class ring-amber-300, Task 149) and asserts it lands
# within [5.0s, 8.5s] of the click (new ≈ 7.6-7.9s; the old build ≈ 9.3s).
# Anonymous /case/test-rolldrop — zero DB writes. Cleanup after.
set -uo pipefail
cd /home/z/my-project
AB="agent-browser"
SHOT="scripts/e2e-t176"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0

$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open http://localhost:3000/case/test-rolldrop >/dev/null
sleep 3

cta=$($AB eval "!!document.querySelector('button.neon-btn')" 2>/dev/null | rg -o "true|false" | head -1)
[ "$cta" = "true" ] && ok "open CTA present" || fail "open CTA present"

# arm the timing probe (capture-once click listener + 50ms poller)
armed=$($AB eval '(() => { if (window.__t176) return "already"; const btn = document.querySelector("button.neon-btn"); if (!btn) return "no-button"; window.__t176 = { t0: 0, ringAt: null, lastX: null, lastMove: 0, stopAfter: null }; btn.addEventListener("click", () => { window.__t176.t0 = performance.now(); }, { capture: true, once: true }); window.__t176Timer = setInterval(() => { const st = window.__t176; const now = performance.now(); if (!st.t0) return; const s = document.querySelector("div.absolute.flex.will-change-transform"); if (s) { const m = /translate3d\((-?[\d.]+)px/.exec(s.style.transform || ""); if (m) { const x = parseFloat(m[1]); if (st.lastX === null || Math.abs(x - st.lastX) > 0.05) { st.lastX = x; st.lastMove = now; } if (st.stopAfter === null && st.lastMove && now - st.lastMove > 400) st.stopAfter = Math.round(st.lastMove - st.t0); } } if (st.ringAt === null && document.querySelector("[class*=\"ring-amber-300\"]")) st.ringAt = Math.round(now - st.t0); }, 50); return "armed"; })()' 2>/dev/null)
echo "probe: $armed"
echo "$armed" | rg -q "armed" && ok "timing probe armed" || fail "timing probe armed"

# open the case
$AB find first "button.neon-btn" click >/dev/null 2>&1
sleep 10.5

res=$($AB eval "JSON.stringify(window.__t176 || {})" 2>/dev/null | head -1)
echo "probe result: $res"
ring=$(echo "$res" | python3 -c "
import json, sys
raw = sys.stdin.read().strip()
try:
    d = json.loads(json.loads(raw)) if raw.startswith('\"') else json.loads(raw)
except Exception:
    d = {}
print(d.get('ringAt', -1))
")
stop=$(echo "$res" | python3 -c "
import json, sys
raw = sys.stdin.read().strip()
try:
    d = json.loads(json.loads(raw)) if raw.startswith('\"') else json.loads(raw)
except Exception:
    d = {}
print(d.get('stopAfter', -1))
")
echo "LOCK instant after click: ${ring} ms (stillness-after: ${stop} ms)"
# Gate: the new build locks ≈ 8.6s after the click (lead-in ≈ 2.1s + spin 6.4s
# + settle). The old build was ≈ 10.2s (spin 8s) — outside this gate.
if [ "$ring" -ge 5000 ] 2>/dev/null && [ "$ring" -le 9000 ] 2>/dev/null; then
  ok "winner locks fast after the click (${ring} ms — old build ≈ 10200 ms)"
else
  fail "lock timing out of spec: ${ring} ms"
fi
# USER SPEC CORE: the reel must NOT sit frozen before the lock. The old power-6
# tail went still ~3.5s BEFORE the ring fired; power-4 keeps crawling so the
# stillness point coincides with the lock instant itself.
gap=$((ring - stop))
if [ "$gap" -ge 0 ] 2>/dev/null && [ "$gap" -le 800 ] 2>/dev/null; then
  ok "no dead stillness before the lock (gap ${gap} ms — old build ≈ 3500 ms)"
else
  fail "reel still freezes before the lock (gap ${gap} ms)"
fi

$AB screenshot "$SHOT-locked.png" >/dev/null 2>&1

# console + page errors (fresh browser — nothing stale can pollute)
errs=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -5)
if [ -z "$errs" ]; then ok "zero page errors"; else fail "page errors: $errs"; fi

# cleanup
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open about:blank >/dev/null 2>&1 || true

[ "$FAILED" = "0" ] && echo "== E2E t176: ALL PASS ==" || echo "== E2E t176: FAILURES =="
exit $FAILED
