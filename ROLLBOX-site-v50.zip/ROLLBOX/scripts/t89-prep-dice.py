"""Task 89 — prep the user's glass-dice rarity artworks for the site.

For each uploaded die PNG:
  1. trim the fully-transparent margins (alpha bbox) + ~4% padding so the die
     fills its frame (background-size:contain then renders it as large as
     possible in every tile),
  2. pad back to a square canvas,
  3. downscale to 512x512 (backdrops render at <= ~260px; keeps the payload
     light — 5 images ~100-200KB total instead of ~2.3MB),
  4. save to public/rarity/rollbox-<rarity>.png.
"""
from PIL import Image
import os

SRC = "/home/z/my-project/upload"
DST = "/home/z/my-project/public/rarity"
os.makedirs(DST, exist_ok=True)

MAPPING = {
    "rollboxconsumer.png": "rollbox-consumer.png",
    "rollboxmilspec.png": "rollbox-milspec.png",
    "rollboxrestricted.png": "rollbox-restricted.png",
    "rollboxclassified.png": "rollbox-classified.png",
    "rollboxcovert.png": "rollbox-covert.png",
}

PAD = 0.04  # 4% breathing room around the trimmed die
OUT = 512

for src_name, dst_name in MAPPING.items():
    im = Image.open(os.path.join(SRC, src_name)).convert("RGBA")
    bbox = im.getchannel("A").getbbox()
    assert bbox, f"{src_name}: fully transparent?!"
    im = im.crop(bbox)
    # pad back to square with transparency, die centered
    w, h = im.size
    side = int(max(w, h) * (1 + PAD * 2))
    side = (side + 1) // 2 * 2
    canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    canvas.paste(im, ((side - w) // 2, (side - h) // 2), im)
    canvas = canvas.resize((OUT, OUT), Image.LANCZOS)
    out_path = os.path.join(DST, dst_name)
    canvas.save(out_path, optimize=True)
    print(dst_name, canvas.size, f"{os.path.getsize(out_path)//1024}KB")
print("done")
