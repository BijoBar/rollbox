// ============ Task 30 fix-up: exchange-stock v values back on the 1X scale ============
// Task 29 put the stock's site price (v) on the ×10 scale (v = realUSD × 10).
// Task 30 flips USD_TO_COINS back to 1 — this one-shot brings every v back to
// 1:1 with the real-USD market reference (v = p). p is NOT touched (it is the
// real-USD market reference, same semantics as the catalog's p). Future syncs
// keep it at 1:1 automatically: steam-stock.ts derives v via usdToCoins at the
// new rate.
//   bun scripts/t30-fix-exchange-v.mjs --yes

import fs from "fs";
import path from "path";

const STOCK = path.join(process.cwd(), "db", "exchange-stock.json");
const MARKER = path.join(process.cwd(), "db", ".t30-exchange-v-fixed");

if (fs.existsSync(MARKER)) {
  console.error("REFUSED: marker exists — the Task 30 v fix already ran.");
  process.exit(1);
}
if (!process.argv.includes("--yes")) {
  console.error("dry run — add --yes");
  process.exit(0);
}

const stock = JSON.parse(fs.readFileSync(STOCK, "utf8"));
const items = Array.isArray(stock) ? stock : (stock.items ?? []);
let n = 0;
for (const it of items) {
  if (typeof it.v === "number") {
    it.v = Math.max(0.01, Math.round((it.v / 10) * 100) / 100);
    n += 1;
  }
}
fs.writeFileSync(STOCK, JSON.stringify(stock));
fs.writeFileSync(MARKER, new Date().toISOString());
console.log(`✓ ${n} items v ÷10 (p untouched — real-USD market reference)`);
