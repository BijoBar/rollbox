/**
 * Task 65 — unit checks for publicOrigin() (the Steam "localhost sent an
 * invalid response" fix). Dependency-free, runs under bun:
 *   bun scripts/verify-origin-unit.ts
 */
import { publicOrigin, sanitizePublicOrigin } from "../src/lib/server/public-origin";

let pass = 0;
let fail = 0;
const check = (name: string, got: unknown, want: unknown) => {
  const ok = got === want;
  if (ok) pass++;
  else fail++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${ok ? "" : `   got=${JSON.stringify(got)} want=${JSON.stringify(want)}`}`);
};

const req = (headers: Record<string, string>, url = "http://localhost:3000/api/auth/steam/start") =>
  new Request(url, { headers });

// 1 — plain local dev, no proxy, no browser headers
check("plain local dev", publicOrigin(req({ host: "localhost:3000" })), "http://localhost:3000");

// 2 — THE BUG: cloudflared forwards with X-Forwarded-Proto: https while Host
//     stays localhost:3000. nextUrl.origin turned that into https://localhost
//     (ERR_SSL_PROTOCOL_ERROR — "localhost sent an invalid response").
check("cloudflared artifact never yields https://localhost", publicOrigin(req({ host: "localhost:3000", "x-forwarded-proto": "https" })), "http://localhost:3000");

// 3 — proper reverse proxy announces the public host
check("x-forwarded-host (named tunnel/proxy)", publicOrigin(req({ host: "localhost:3000", "x-forwarded-host": "play.example.com", "x-forwarded-proto": "https" })), "https://play.example.com");

// 4 — loopback x-forwarded-host is NOT trusted (falls through to browser/host)
check("loopback xfh not trusted", publicOrigin(req({ host: "localhost:3000", "x-forwarded-host": "localhost:3000", "x-forwarded-proto": "https" })), "http://localhost:3000");

// 5 — quick tunnel: zero-config, the browser's Referer carries the public origin
check("referer (quick tunnel)", publicOrigin(req({ host: "localhost:3000", referer: "https://quiet-gate-abc.trycloudflare.com/login" })), "https://quiet-gate-abc.trycloudflare.com");

// 6 — Origin header beats Referer
check("origin beats referer", publicOrigin(req({ host: "localhost:3000", origin: "https://origin-win.example.com", referer: "https://referer-lose.example.com/login" })), "https://origin-win.example.com");

// 7 — strict mode (Steam callback): browser headers belong to Steam there
check("strict ignores origin/referer", publicOrigin(req({ host: "localhost:3000", origin: "https://steamcommunity.com", referer: "https://steamcommunity.com/x" }, "http://localhost:3000/api/auth/steam/callback"), { strict: true }), "http://localhost:3000");

// 8 — PUBLIC_URL pins everything, even against all other signals
process.env.PUBLIC_URL = "https://rollbox.example.org";
check("PUBLIC_URL pin wins", publicOrigin(req({ host: "localhost:3000", "x-forwarded-host": "play.example.com", "x-forwarded-proto": "https", referer: "https://other.example.net/x" })), "https://rollbox.example.org");
delete process.env.PUBLIC_URL;

// 9 — multi-value forwarded headers: first entry wins
check("multi-value x-forwarded-host", publicOrigin(req({ host: "localhost:3000", "x-forwarded-host": "a.example.com, b.example.com", "x-forwarded-proto": "https,http" })), "https://a.example.com");

// 10 — LAN deployment (START-ROLLBOX-LAN.bat): the LAN host is the public host
check("lan host kept as-is", publicOrigin(req({ host: "192.168.1.7:3000" })), "http://192.168.1.7:3000");

// 11 — production host without any proxy headers
check("bare public host + proto header", publicOrigin(req({ host: "rollbox.gg", "x-forwarded-proto": "https" })), "https://rollbox.gg");

// 12 — sanitizePublicOrigin edges
check("sanitize: junk is null", sanitizePublicOrigin("not a url"), null);
check("sanitize: https loopback is null", sanitizePublicOrigin("https://localhost:3000/api"), null);
check("sanitize: non-http scheme is null", sanitizePublicOrigin("ftp://x.com"), null);
check("sanitize: javascript is null", sanitizePublicOrigin("javascript:alert(1)"), null);
check("sanitize: good url -> bare origin", sanitizePublicOrigin("https://x.com/a?b=1"), "https://x.com");
check("sanitize: empty is null", sanitizePublicOrigin(""), null);
check("sanitize: Origin: null header is null", sanitizePublicOrigin("null"), null);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
