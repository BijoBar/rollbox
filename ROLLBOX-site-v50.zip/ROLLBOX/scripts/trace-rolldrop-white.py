"""Trace the exact attach/detach lifecycle of .rd-white-cover with timestamps."""
import json
import time
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    pg.goto("http://localhost:3000/case/test-rolldrop", wait_until="networkidle")
    pg.evaluate("localStorage.setItem('rb-rolldrop-force','1')")
    pg.reload(wait_until="networkidle")
    pg.wait_for_timeout(600)

    # install an observer BEFORE clicking: logs every childList add/remove in the reel region
    pg.evaluate(
        """() => {
        window.__rdLog = [];
        const log = (m) => window.__rdLog.push([performance.now().toFixed(0), m]);
        const target = document.querySelector('section[aria-label*="unboxing reel"]');
        const mo = new MutationObserver((muts) => {
          for (const m of muts) {
            for (const n of m.addedNodes) if (n.className && String(n.className).includes('rd-white-cover')) log('ATTACH ' + performance.now().toFixed(0));
            for (const n of m.removedNodes) if (n.className && String(n.className).includes('rd-white-cover')) log('DETACH ' + performance.now().toFixed(0));
          }
        });
        mo.observe(target, { childList: true, subtree: true });
        window.__rdT0 = performance.now();
        log('OBSERVER_ARMED');
      }"""
    )

    t0 = time.time()
    pg.click("button:has-text('Open Case')")
    pg.wait_for_selector(".rd-white-cover", state="attached", timeout=25000)
    attached_at = time.time() - t0
    # sample lifetime
    for i in range(8):
        alive = pg.evaluate("!!document.querySelector('.rd-white-cover')")
        pg.wait_for_timeout(150)
    time.sleep(3)
    log = pg.evaluate("window.__rdLog")
    print("attached_at(s after click):", round(attached_at, 2))
    print("lifecycle log:", json.dumps(log, indent=0))
    b.close()
