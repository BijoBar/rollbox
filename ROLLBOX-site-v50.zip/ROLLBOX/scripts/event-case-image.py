#!/usr/bin/env python3
"""
EVENT CASE artwork pipeline (Emerald Drop, USER SPEC R44).

Takes the generated crate render (upload/event-case/event-raw-1.png, black
studio background), keys the background to TRANSPARENT (max-channel
luminance key + hole fill so dark crate parts stay opaque), trims to the
content bbox and fits it centered onto the shared 800x615 transparent
canvas — the same canvas every designed case image uses — and writes
public/cases/event-emerald-drop.webp (q85).

The manifest src/lib/case-images.ts gains the slug by hand (the auto
optimizer only maps RB-\d+ codes; the event case is not one of them).
"""
import os

import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage

ROOT = "/home/z/my-project"
SRC = os.path.join(ROOT, "upload/event-case/event-raw-1.png")
OUT = os.path.join(ROOT, "public/cases/event-emerald-drop.webp")
CANVAS_W, CANVAS_H = 800, 615
QUALITY = 85

im = Image.open(SRC).convert("RGB")
rgb = np.asarray(im).astype(np.float32)
maxc = rgb.max(axis=2)  # max-channel luminance: keeps the green glow, cuts the dark floor

# ---- binary mask: anything lit above the studio-floor level ----
binary = maxc > 50
# fill enclosed dark regions (knife grip, panel gaps) so the crate is SOLID
binary_filled = ndimage.binary_fill_holes(binary)
# component filter: KEEP the crate (largest component: crate + lid + knife)
# plus soft smoke components hanging in the UPPER half — DROP every ground
# patch / floor reflection around the crate's base
H = binary_filled.shape[0]
labels, n = ndimage.label(binary_filled)
sizes = ndimage.sum(binary_filled, labels, range(1, n + 1)) if n else []
keep_mask = np.zeros_like(binary_filled)
if n:
    crate_label = 1 + int(np.argmax(sizes))
    keep_mask |= labels == crate_label
    crate_rows = np.where((labels == crate_label).any(axis=1))[0]
    bottom_row = int(crate_rows.max())
    for lab in range(1, n + 1):
        if lab == crate_label:
            continue
        rows = np.where(labels == lab)[0]
        if len(rows) >= 220 and rows.mean() < 0.5 * H:  # upper-half smoke
            keep_mask |= labels == lab
else:
    bottom_row = H - 1
keep_mask = ndimage.binary_fill_holes(keep_mask)
# fade everything below the crate's contact line (kills residual floor glow)
ygrid = np.arange(H, dtype=np.float32).reshape(-1, 1)
fade = np.clip((bottom_row + 16 - ygrid) / 16.0, 0.0, 1.0)

# ---- soft alpha: hard interior + luminance-ramped glow (smoke, halo) ----
soft = np.clip((maxc - 30.0) / (64.0 - 30.0), 0.0, 1.0)  # 0 below 30, 1 above 64
alpha = np.where(keep_mask, 1.0, soft * 0.85) * fade

# bottom-band cleanup: in the crate's lowest band only dark floor noise may
# linger — fade alpha by brightness so the BRIGHT crate base (gold trim,
# lit carbon) stays and the dim leftover ground smudge (maxc < ~90) dies
band_top = max(0, bottom_row - int(0.15 * H))
ramp_band = np.clip((maxc - 45.0) / (95.0 - 45.0), 0.0, 1.0)
ycol = np.arange(H, dtype=np.float32).reshape(-1, 1).repeat(rgb.shape[1], axis=1)
alpha = np.where(ycol >= band_top, alpha * ramp_band, alpha)

# despeckle the alpha, then a hair of feather for clean edges
a_img = Image.fromarray((alpha * 255).astype(np.uint8))
a_img = a_img.filter(ImageFilter.MedianFilter(3)).filter(ImageFilter.GaussianBlur(0.8))
alpha = np.asarray(a_img).astype(np.float32) / 255.0

rgba = np.dstack([rgb, alpha * 255.0]).astype(np.uint8)
out = Image.fromarray(rgba)

# ---- trim to content + small margin, fit centered on the shared canvas ----
bbox = out.getbbox()
if bbox:
    pad = 6
    l, t, r, b = bbox
    out = out.crop((max(0, l - pad), max(0, t - pad), min(out.width, r + pad), min(out.height, b + pad)))
scale = min(CANVAS_W / out.width, CANVAS_H / out.height, 1.0)
if scale < 1.0:
    out = out.resize((max(1, round(out.width * scale)), max(1, round(out.height * scale))), Image.LANCZOS)
canvas = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
canvas.paste(out, ((CANVAS_W - out.width) // 2, (CANVAS_H - out.height) // 2), out)
canvas.save(OUT, "WEBP", quality=QUALITY, method=6)

print(f"content fit: {out.width}x{out.height} -> {CANVAS_W}x{CANVAS_H} canvas")
print(f"written: {OUT}  ({os.path.getsize(OUT) / 1024:.1f} KB)")

# ---- QC composite on the site's card background (what the player sees) ----
qc = Image.new("RGB", (CANVAS_W, CANVAS_H), (22, 16, 40))  # #161028 card color
qc.paste(canvas, (0, 0), canvas)
qc.save(os.path.join(ROOT, "upload/event-case/event-qc-on-card.png"))
print("QC composite: upload/event-case/event-qc-on-card.png")
