#!/usr/bin/env python3
"""Task 72 verification — SKIN WEAR system.

Static checks (wear lib, generated price tables, catalog wp/wa, editor HTML,
schema) + a live server smoke: RB-TST wear-tagged pulls, per-wear exchange
purchase priced by the SERVER, wear rejection for nonexistent exteriors, and
the sell-back flow. Runs against the dev server on :3000.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import sqlite3
import sys
import time

import requests

BASE = "http://localhost:3000"
DB = "db/custom.db"
SECRET = "rollbox-dev-secret"
PASS: list[str] = []
FAIL: list[str] = []

WEAR_IDS = {"FN", "MW", "FT", "WW", "BS"}
# the demo case's item -> wear contract (src/lib/cases.ts TEST_CASE)
TST_WEAR = {
    "sticker-dragon": None,
    "nova-rising-sun": "FT",
    "dual-berettas-cartel": "MW",
    "ak-47-asiimov": "FT",
    "awp-asiimov": "FT",
    "m4a4-asiimov": "WW",
    "p90-asiimov": "BS",
}


def check(name: str, ok: bool, extra: str = "") -> None:
    (PASS if ok else FAIL).append(name + (f" — {extra}" if (extra and not ok) else ""))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if (extra and not ok) else ""))


def read(*parts: str) -> str:
    with open(os.path.join(*parts), encoding="utf-8") as f:
        return f.read()


def mint(pid: str) -> str:
    body = base64.urlsafe_b64encode(json.dumps({"pid": pid, "exp": int(time.time() * 1000) + 86400000},
                                               separators=(",", ":")).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()
    return body + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")


def sess(pid: str) -> dict:
    return {"rb_session": mint(pid)}


def make_player(tag: str, balance: int = 500) -> str:
    pid = f"p_t72{tag}"
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
        "VALUES (?, 'steam', ?, ?, ?, 0, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
        (pid, f"t72-{tag}-steamid", f"T72 {tag}", balance),
    )
    con.commit()
    con.close()
    return pid


def gen_consts() -> tuple[dict, dict]:
    """Parse the generated wear tables (TS file) into dicts."""
    txt = read("src", "lib", "generated-wear-prices.ts")
    prices = json.loads(re.search(r"SKIN_WEAR_PRICES[^=]*=\s*(\{.*?\});", txt, re.S).group(1))
    avail = json.loads(re.search(r"SKIN_WEAR_AVAIL[^=]*=\s*(\{.*?\});", txt, re.S).group(1))
    return prices, avail


def catalog() -> list[dict]:
    return json.loads(read("public", "skins-catalog.json"))


def main() -> None:
    # ===== static: wear vocabulary =====
    wear_ts = read("src", "lib", "wear.ts")
    for label in ("Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred"):
        check(f"wear.ts defines {label}", f'"{label}"' in wear_ts)
    check("wear.ts exposes entryWearPrice + skinWearValue",
          "export function entryWearPrice" in wear_ts and "export function skinWearValue" in wear_ts)

    # ===== static: generated tables =====
    prices, avail = gen_consts()
    check("generated wear price table populated", len(prices) >= 150, f"skins={len(prices)}")
    asi = prices.get("ak-47-asiimov", {})
    check("ak-47-asiimov (case skin) has real FT wear price", isinstance(asi.get("FT"), int) and asi["FT"] > 0)
    nova = prices.get("nova-rising-sun", {})
    check("nova-rising-sun has real FT wear price", isinstance(nova.get("FT"), int) and nova["FT"] > 0)
    check("availability deviations recorded (wear-locked / vanilla skins)", len(avail) >= 20, f"deviations={len(avail)}")

    # ===== static: catalog wp/wa =====
    cat = catalog()
    byid = {e["id"]: e for e in cat}
    wp_count = sum(1 for e in cat if e.get("wp"))
    check("catalog entries with per-wear prices", wp_count >= 2000, f"wp={wp_count}")
    rl = byid.get("ak-47-redline", {})
    check("catalog Redline carries wp + wa", bool(rl.get("wp")) and rl.get("wa") == ["MW", "FT", "WW", "BS"])
    tiger = byid.get("bayonet-tiger-tooth", {})
    check("Tiger Tooth wa limited to FN/MW", set(tiger.get("wa", [])) == {"FN", "MW"}, str(tiger.get("wa")))
    stickers_with_wp = sum(1 for e in cat if e.get("t") == "sticker" and e.get("wp"))
    check("stickers never get a wear picker", stickers_with_wp == 0)

    # ===== static: schema + editor =====
    schema = read("prisma", "schema.prisma")
    check("schema: InventoryItem.wear + Drop.wear",
          re.search(r"model InventoryItem \{[^}]*wear\s+String\?", schema, re.S) and
          re.search(r"model Drop \{[^}]*wear\s+String\?", schema, re.S))
    con = sqlite3.connect(DB)
    inv_cols = {r[1] for r in con.execute('PRAGMA table_info("InventoryItem")')}
    drop_cols = {r[1] for r in con.execute('PRAGMA table_info("Drop")')}
    con.close()
    check("SQLite: InventoryItem.wear column exists", "wear" in inv_cols)
    check("SQLite: Drop.wear column exists", "wear" in drop_cols)

    cases_ts = read("src", "lib", "cases.ts")
    check("cases.ts: CaseItem carries wear/value override", "wear?: WearId" in cases_ts and "value?: number" in cases_ts)
    check("RB-TST exercises the wear system", 'wear: "FT"' in cases_ts and 'wear: "BS"' in cases_ts)

    ed = read("download", "ROLLBOX-cases-editor.html")
    check("case editor: wear column + picker installed", "מצב (WEAR)" in ed and 'class="wear"' in ed)
    check("case editor: skin price payload injected", '"wp"' in ed and "__SKINS_JSON__" not in ed)

    # ===== static: plumbing =====
    check("api/open returns wear on pulls", "wear: item.wear" in read("src", "app", "api", "open", "route.ts"))
    check("gbattles rolls carry wear", "wear: item.wear" in read("src", "lib", "server", "gbattles.ts").replace("pull.wear", "").replace("rare.wear", "").replace("bonusItem.wear", "") or "caseItemValue" in read("src", "lib", "server", "gbattles.ts"))
    check("BattleReel shows the wear badge", "targetWear" in read("src", "components", "rollbox", "BattleReel.tsx"))
    check("exchange tile has the wear chips", "Pick the exterior" in read("src", "components", "rollbox", "ExchangeView.tsx"))
    check("inventory buy resolves the wear price server-side",
          "catalogWearCoins" in read("src", "app", "api", "inventory", "route.ts"))

    # ===== live: RB-TST wear-tagged pulls =====
    a = make_player("A", 5000)
    r = requests.post(BASE + "/api/open", timeout=20, cookies=sess(a), json={"caseId": "test-rolldrop", "count": 5})
    pulls = r.json().get("pulls", []) if r.ok else []
    check("live: RB-TST opens (5 pulls)", r.status_code == 200 and len(pulls) == 5, f"{r.status_code} {r.text[:120]}")
    wear_ok = True
    val_ok = True
    for p in pulls:
        expect = TST_WEAR.get(p["skinId"], "?")
        if expect != (p.get("wear") or None):
            wear_ok = False
        if expect and p["skinId"] in prices and isinstance(prices[p["skinId"]].get(expect), int):
            if p["value"] != prices[p["skinId"]][expect]:
                val_ok = False
    check("live: every pull carries the item's wear", wear_ok, json.dumps(pulls)[:200])
    check("live: wear pulls pay the market wear price", val_ok, json.dumps(pulls)[:200])

    con = sqlite3.connect(DB)
    rows = con.execute("SELECT skinId, wear FROM \"Drop\" WHERE source='solo' ORDER BY id DESC LIMIT 5").fetchall()
    con.close()
    drop_ok = all(TST_WEAR.get(s, "?") == (w or None) for s, w in rows)
    check("live: Drop rows store the wear", drop_ok and len(rows) == 5, str(rows))

    # ===== live: per-wear exchange purchase (server-priced) =====
    # Task 90: wear prices are CENT-PRECISE — round(usd*10) to the cent
    # (Math.max(0.01, Math.round(usd*1000)/100) in lib/wear.ts), not an integer.
    b = make_player("B", 999999)
    expected = max(0.01, round(rl["wp"]["MW"] * 1000) / 100)
    r = requests.post(BASE + "/api/inventory", timeout=15, cookies=sess(b), json={"entryId": "ak-47-redline", "wear": "MW"})
    data = r.json() if r.ok else {}
    item = data.get("item", {})
    check("live: buy Redline MW -> 200", r.status_code == 200, r.text[:120])
    check("live: server charged the MW wear price", item.get("v") == expected, f"got {item.get('v')} want {expected}")
    check("live: inventory name carries the exterior", item.get("n", "").endswith("(Minimal Wear)"), item.get("n", ""))
    uid = item.get("uid")

    r = requests.post(BASE + "/api/inventory", timeout=15, cookies=sess(b), json={"entryId": "ak-47-redline", "wear": "FN"})
    check("live: nonexistent exterior (Redline FN) rejected", r.status_code == 400, f"{r.status_code} {r.text[:80]}")

    r = requests.post(BASE + "/api/inventory", timeout=15, cookies=sess(b), json={"entryId": "sticker-dragon", "wear": "FT"})
    check("live: sticker + wear rejected", r.status_code == 400, f"{r.status_code} {r.text[:80]}")

    con = sqlite3.connect(DB)
    stored = con.execute("SELECT value, wear FROM InventoryItem WHERE id=?", (uid,)).fetchone() if uid else None
    con.close()
    check("live: DB row stores wear + wear value", bool(stored) and stored[0] == expected and stored[1] == "MW", str(stored))

    r = requests.post(BASE + "/api/inventory/sell", timeout=15, cookies=sess(b), json={"uids": [uid]})
    sold = r.json() if r.ok else {}
    check("live: sell-back credits the wear value", r.status_code == 200 and sold.get("credit") == expected, r.text[:120])

    print(f"\n== {len(PASS)} passed, {len(FAIL)} failed ==")
    if FAIL:
        print("FAILED:", *FAIL, sep="\n  - ")
        sys.exit(1)


if __name__ == "__main__":
    main()
