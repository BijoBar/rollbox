(() => {
  // Task 82-fix EDGING analyzer — reads window.__t82traces (see
  // t82-edge-sample.js) and verifies the user's BOUNDARY RULE + fast SNAP on
  // every spin round it can isolate:
  //   o(t) = vFinal - v(t)  (positive = the center line sits PAST the
  //   winner's center, toward the NEXT tile)
  //   1. the STOP point (crawl-tail plateau + still beat) must sit INSIDE the
  //      winner's own tile:  -0.92*half - 2  <= stopO <= 0.45*half + 2
  //      -> the NEXT skin can never "arrive" at the line (the old 0.95-1.25
  //      bands FAIL here), so nothing fully-passed is ever rolled back from.
  //   2. over the whole plateau+snap tail: maxO <= 0.5*half + 3
  //   3. after the snap the reel rests EXACTLY centered (unstable === 0)
  //   4. the snap itself is FAST: 120ms <= snapDur <= 560ms (the old slow
  //      settle was 450-1200ms -> FAIL)
  // mode 'solo'/'cols': the strip element persists across rounds — segments
  //   are cut between consecutive PARK anchors (transform reset to ~0 before
  //   every deal). mode 'battle': each reel remounts per round — the whole
  //   trace IS one round.
  const mode = window.__t82analyzeMode || 'solo';
  const traces = window.__t82traces || [];
  if (!traces.length) return JSON.stringify({ err: 'no traces', mode });

  function median(xs) {
    const v = [...xs].sort((a, b) => a - b);
    return v.length ? v[Math.floor(v.length / 2)] : 16;
  }

  function analyzeSeg(seg, half) {
    if (seg.length < 12) return null;
    // sampling density: the headless sandbox can render battle rooms at ~7fps
    // (real hardware is 60fps; the motion math is time-based and identical).
    // Density-adaptive thresholds keep the assertions meaningful at any fps.
    const gaps = seg.slice(1).map((p, i) => p.t - seg[i].t).filter((g) => g > 0);
    const med = median(gaps);
    const sparse = med > 150;
    // the snap's DURATION is only measurable when frames are dense enough;
    // at low fps the whole snap can fall between two samples (jump detected,
    // duration unresolvable). A missing snap still fails the rest/centered
    // checks below, so lowering the floor to 0 here is safe.
    const snapResolvable = med <= 100;
    const vFinal = seg[seg.length - 1].v;
    const o = seg.map((p) => ({ t: p.t, o: +(vFinal - p.v).toFixed(2) }));
    let tDone = 0;
    for (const p of o) if (Math.abs(p.o) > 1.5) tDone = p.t;
    const endT = o[o.length - 1].t;
    if (endT - tDone < (sparse ? 100 : 250)) return null; // no clean centered rest captured
    const restTol = sparse ? 2.5 : 1.5;
    let unstable = 0;
    for (const p of o) if (p.t > tDone && Math.abs(p.o) > restTol) unstable++;
    // plateau scan: the crawl-tail + still BEAT (|o| > 3 keeps the final
    // centered rest out; per-bin delta keeps real motion out)
    const tail = o.filter((p) => p.t >= tDone - 2800 && p.t <= tDone + 40);
    if (tail.length < (sparse ? 4 : 20)) return null;
    const maxDelta = sparse ? 1.5 : 0.8;
    const minBins = sparse ? 3 : 8;
    let best = { len: 0, span: 0, val: 0, startT: 0, endT: 0 };
    let run = [];
    for (const p of tail) {
      if (Math.abs(p.o) > 3 && run.length && Math.abs(p.o - run[run.length - 1].o) <= maxDelta) run.push(p);
      else if (Math.abs(p.o) > 3) run = [p];
      else run = [];
      const span = run.length ? run[run.length - 1].t - run[0].t : 0;
      if (run.length > best.len && (span >= 120 || run.length >= minBins)) {
        const vals = run.map((r) => r.o);
        best = {
          len: run.length,
          span,
          val: vals.reduce((a, b) => a + b, 0) / vals.length,
          startT: run[0].t,
          endT: run[run.length - 1].t,
        };
      }
    }
    if (best.len < minBins) return null; // no hold plateau found
    const stopO = +best.val.toFixed(1);
    const snapDur = tDone - best.endT;
    let maxO = -Infinity;
    let minO = Infinity;
    for (const p of o) {
      if (p.t >= best.startT) {
        maxO = Math.max(maxO, p.o);
        minO = Math.min(minO, p.o);
      }
    }
    const pass =
      unstable === 0 &&
      Math.abs(stopO) <= half + 2 &&
      stopO <= 0.45 * half + 2 &&
      stopO >= -0.92 * half - 2 &&
      maxO <= 0.5 * half + 3 &&
      minO >= -0.95 * half - 3 &&
      snapDur >= (snapResolvable ? 80 : 0) &&
      snapDur <= (sparse ? 1400 : 560);
    return {
      stopO,
      fracHalf: +(stopO / half).toFixed(3),
      snapDur,
      holdMs: best.endT - best.startT,
      maxO: +maxO.toFixed(1),
      minO: +minO.toFixed(1),
      unstable,
      half: +half.toFixed(1),
      sparse,
      pass,
    };
  }

  const results = [];
  for (const tr of traces) {
    if (!tr.item || tr.samples.length < 24) continue;
    const half = tr.item / 2;
    const s = tr.samples;
    const segs = [];
    if (mode === 'battle') {
      segs.push(s);
    } else {
      // rest/park anchors: >=250ms runs with <=0.7px movement
      const anchors = [];
      let i = 0;
      while (i < s.length) {
        let j = i + 1;
        while (j < s.length && Math.abs(s[j].v - s[j - 1].v) <= 0.7) j++;
        if (s[j - 1].t - s[i].t >= 250) anchors.push({ a: i, b: j - 1, v: s[j - 1].v });
        i = j;
      }
      const parks = anchors.filter((an) => Math.abs(an.v) < half * 0.5);
      for (let k = 0; k < parks.length; k++) {
        const from = parks[k].b + 1;
        const to = k + 1 < parks.length ? parks[k + 1].a : s.length; // exclusive
        if (to - from > 40) segs.push(s.slice(from, to));
      }
    }
    for (const seg of segs) {
      const travel = Math.abs(seg[seg.length - 1].v - seg[0].v);
      if (travel < half * 6) continue; // not a real spin segment
      const r = analyzeSeg(seg, half);
      if (r) results.push({ ...r, item: tr.item, gap: tr.gap });
    }
  }
  const failed = results.filter((r) => !r.pass);
  return JSON.stringify({
    mode,
    rounds: results.length,
    passed: results.length - failed.length,
    failed: failed.length,
    fracs: results.map((r) => r.fracHalf),
    snapDurs: results.map((r) => r.snapDur),
    details: results,
    verdict: results.length > 0 && failed.length === 0 ? 'PASS' : 'FAIL',
  });
})()
