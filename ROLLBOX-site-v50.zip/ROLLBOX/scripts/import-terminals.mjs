#!/usr/bin/env node
// ============ import-terminals.mjs (Task 23, USER SPEC; Task 26: min) ============
// Reads an editor export (the txt the user copies/downloads — it may contain
// BOTH sections; the dedicated ROLLBOX-terminal-editor.html emits only the
// terminals one) and writes the TERMINALS overlay into
// src/lib/user-terminals.ts. Case lines are ignored here (they were always
// imported by hand into src/lib/user-cases.ts).
//
// Usage:  node scripts/import-terminals.mjs rollbox-terminals.txt
//         cat rollbox-terminals.txt | node scripts/import-terminals.mjs

import fs from "fs";

const ROOT = new URL("..", import.meta.url).pathname;
const raw = (process.argv[2] ? fs.readFileSync(process.argv[2], "utf8") : fs.readFileSync(0, "utf8")).trim();

const terminals = [];
let sawCasesHeader = false;
let sawTerminalsHeader = false;
let caseLineCount = 0;

for (const line of raw.split("\n")) {
  const s = line.trim();
  if (!s) continue;
  if (s === "ROLLBOX-CASES v1") { sawCasesHeader = true; continue; }
  if (s === "ROLLBOX-TERMINALS v1") { sawTerminalsHeader = true; continue; }
  let obj;
  try {
    obj = JSON.parse(s);
  } catch {
    console.warn(`skip (not JSON): ${s.slice(0, 60)}…`);
    continue;
  }
  if (obj && Array.isArray(obj.skins)) {
    terminals.push(obj);
  } else if (obj && (obj.code || obj.del)) {
    caseLineCount++;
  } else {
    console.warn(`skip (unknown line): ${s.slice(0, 60)}…`);
  }
}

if (terminals.length === 0) {
  console.error("No terminal lines found in the export (looked for the ROLLBOX-TERMINALS v1 section).");
  console.error(`(case lines ignored: ${caseLineCount})`);
  process.exit(1);
}

// ---- validate ----
const problems = [];
const ids = new Set();
for (const t of terminals) {
  const tag = t.id ?? "(no id)";
  if (!t.id || !/^[a-z0-9-]{2,24}$/i.test(String(t.id))) problems.push(`${tag}: bad dealer id`);
  if (ids.has(String(t.id))) problems.push(`${tag}: duplicate dealer id`);
  ids.add(String(t.id));
  if (!Array.isArray(t.skins) || t.skins.length < 2) problems.push(`${tag}: a dealer needs at least 2 skins`);
  const sum = (t.skins ?? []).reduce((acc, k) => acc + (+k.p || 0), 0);
  if (Math.abs(sum - 100) > 0.05) problems.push(`${tag}: chances sum to ${sum.toFixed(4)}, not 100`);
  if (!(+t.max > 0)) problems.push(`${tag}: max must be a positive number`);
  if (t.min !== undefined && (!(+t.min >= 1) || !Number.isFinite(+t.min))) problems.push(`${tag}: min must be a number >= 1`);
  for (const k of t.skins ?? []) {
    if (!(+k.v > 0)) problems.push(`${tag}: skin "${k.n}" has value ${k.v}`);
  }
}
if (problems.length) {
  console.error("EXPORT HAS PROBLEMS — fix these in the editor first:");
  for (const p of problems) console.error("  • " + p);
  process.exit(1);
}

// ---- write the overlay ----
const withMin = (t) => ({ id: t.id, name: t.name, ...(t.min !== undefined ? { min: Math.max(1, Math.round(+t.min)) } : {}), max: t.max, skins: t.skins });
const ts = `// ============ USER TERMINALS (Task 23) — DO NOT auto-regenerate ============
// Imported from the TERMINAL EDITOR's ROLLBOX-TERMINALS v1 export by
// scripts/import-terminals.mjs on ${new Date().toISOString().slice(0, 10)}.
// Each dealer here REPLACES the generated dealer with the same id
// (src/lib/terminals.ts DEFAULT_TERMINALS) wholesale.

import type { TerminalDef } from "./terminals";

export const USER_TERMINALS: TerminalDef[] = ${JSON.stringify(terminals.map(withMin), null, 2)};
`;

fs.writeFileSync(`${ROOT}src/lib/user-terminals.ts`, ts);
console.log(`OK — wrote src/lib/user-terminals.ts with ${terminals.length} dealer(s):`);
for (const t of terminals) {
  console.log(`  • ${t.id} — ${t.name} (min ${t.min ?? "default"}, max ${t.max}, ${t.skins.length} skins)`);
}
console.log(`(case lines in the export were ignored: ${caseLineCount})`);
