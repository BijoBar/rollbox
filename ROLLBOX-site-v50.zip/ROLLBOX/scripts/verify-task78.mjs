// Task 78 E2E — the critical two-phase open flow, verified at API + DB level.
// 1. open  -> price charged, win PARKED (OpenPending), no Drop rows, balance = charged-only
// 2. claim -> balance jumps by the exact rolled amount, Drops published, pending flipped
// 3. double claim -> idempotent (no second credit)
// 4. recovery -> a stale unclaimed pending is cashed by GET /api/auth/me
import { PrismaClient } from "@prisma/client";
import crypto from "crypto";

const db = new PrismaClient();
const BASE = "http://localhost:3000";
const secret = () => process.env.AUTH_SECRET || "rollbox-dev-secret";
const sign = (p) => crypto.createHmac("sha256", secret()).update(p).digest("base64url");
const mint = (pid) => {
  const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 864e5 })).toString("base64url");
  return `${body}.${sign(body)}`;
};

let pass = 0, fail = 0;
const ok = (cond, label) => { if (cond) { pass++; console.log("  PASS " + label); } else { fail++; console.log("  FAIL " + label); } };

// --- setup: fresh QA player with a known balance ---
const steamId = "76561198000000078";
const old = await db.player.findUnique({ where: { providerId: steamId } });
if (old) { await db.drop.deleteMany({ where: { playerId: old.id } }); await db.openPending.deleteMany({ where: { playerId: old.id } }); await db.ledger.deleteMany({ where: { playerId: old.id } }); await db.player.delete({ where: { id: old.id } }); }
const player = await db.player.create({
  data: { id: "p_" + crypto.randomBytes(8).toString("hex"), provider: "steam", providerId: steamId, name: "Task78QA", avatar: "", balance: 1000 },
});
const cookie = "rb_session=" + mint(player.id);
const dropsBefore = await db.drop.count();
console.log(`QA player ${player.id} balance=1000 | drops in feed before: ${dropsBefore}`);

// --- pick the cheapest real case ---
const CASES_MOD = await import("./src/lib/cases.ts").catch(() => null);
let caseId = "printstream-cartel", price = 6;
const res0 = await fetch(`${BASE}/api/auth/me`, { headers: { cookie } });
const me0 = await res0.json();
ok(me0?.player?.balance === 1000, "me route returns the fresh player (balance 1000)");

// --- 1. open: charge now, win parked ---
const r1 = await fetch(`${BASE}/api/open`, { method: "POST", headers: { cookie, "Content-Type": "application/json" }, body: JSON.stringify({ caseId, count: 1 }) });
const d1 = await r1.json();
ok(r1.status === 200 && Array.isArray(d1.pulls) && d1.pulls.length === 1, "open 200 with 1 pull");
ok(typeof d1.pendingId === "string" && d1.pendingId.startsWith("op_"), "response carries pendingId");
const afterOpen = await db.player.findUniqueOrThrow({ where: { id: player.id } });
ok(Math.abs(afterOpen.balance - (1000 - price)) < 1e-9, `balance after open = ${1000 - price} (charge ONLY, no win)`);
ok(Math.abs(d1.balance - (1000 - price)) < 1e-9, "response balance is the charged balance");
const pend1 = await db.openPending.findUnique({ where: { id: d1.pendingId } });
ok(!!pend1 && !pend1.claimed && Math.abs(pend1.amount - d1.credited) < 1e-9, "OpenPending row parked unclaimed with the rolled amount");
ok((await db.drop.count()) === dropsBefore, "NO Drop rows while the reel is still spinning");
ok(Math.abs(afterOpen.balance - (1000 - price) - d1.credited) > 1e-9 || d1.credited === 0, "win is NOT on the balance yet");

// --- 2. claim: the reveal finished — now the money lands ---
const r2 = await fetch(`${BASE}/api/open/claim`, { method: "POST", headers: { cookie, "Content-Type": "application/json" }, body: JSON.stringify({ pendingId: d1.pendingId }) });
const d2 = await r2.json();
ok(r2.status === 200 && d2.claimed === true, "claim 200 claimed=true");
ok(Math.abs(d2.balance - (1000 - price + d1.credited)) < 1e-9, `balance after claim = charged + exact rolled win (${1000 - price} + ${d1.credited})`);
const afterClaim = await db.player.findUniqueOrThrow({ where: { id: player.id } });
ok(Math.abs(afterClaim.balance - (1000 - price + d1.credited)) < 1e-9, "DB balance carries the win");
ok((await db.drop.count()) === dropsBefore + 1, "Drop row created AT claim (live feed reveals with the player)");
ok((await db.openPending.findUniqueOrThrow({ where: { id: d1.pendingId } })).claimed === true, "pending flipped to claimed");
const ledgerRows = await db.ledger.findMany({ where: { playerId: player.id }, orderBy: { id: "asc" } });
ok(ledgerRows.some((l) => l.kind === "open_entry" && l.amount === -price) && ledgerRows.some((l) => l.kind === "open_win" && Math.abs(l.amount - d1.credited) < 1e-9), "ledger: open_entry at open, open_win at claim");

// --- 3. double claim: idempotent, no second credit ---
const r3 = await fetch(`${BASE}/api/open/claim`, { method: "POST", headers: { cookie, "Content-Type": "application/json" }, body: JSON.stringify({ pendingId: d1.pendingId }) });
const d3 = await r3.json();
ok(r3.status === 200 && d3.alreadyClaimed === true && Math.abs(d3.balance - afterClaim.balance) < 1e-9, "double claim idempotent — balance unchanged");

// --- 4. recovery: stale pending is cashed by GET /api/auth/me ---
const r4 = await fetch(`${BASE}/api/open`, { method: "POST", headers: { cookie, "Content-Type": "application/json" }, body: JSON.stringify({ caseId, count: 1 }) });
const d4 = await r4.json();
const staleId = d4.pendingId;
await db.openPending.update({ where: { id: staleId }, data: { createdAt: new Date(Date.now() - 120000) } }); // backdate 2 min
const beforeRec = await db.player.findUniqueOrThrow({ where: { id: player.id } });
const r5 = await fetch(`${BASE}/api/auth/me`, { headers: { cookie } });
const d5 = await r5.json();
ok(Math.abs(d5.player.balance - (beforeRec.balance + d4.credited)) < 1e-9, "me route recovered the abandoned round (credited exactly)");
ok((await db.openPending.findUniqueOrThrow({ where: { id: staleId } })).claimed === true, "stale pending claimed by recovery");

// --- 5. fresh pending is NOT raced by recovery ---
const r6 = await fetch(`${BASE}/api/open`, { method: "POST", headers: { cookie, "Content-Type": "application/json" }, body: JSON.stringify({ caseId, count: 1 }) });
const d6 = await r6.json();
const r7 = await fetch(`${BASE}/api/auth/me`, { headers: { cookie } });
const d7 = await r7.json();
ok(Math.abs(d7.player.balance - d6.balance) < 1e-9, "fresh (<60s) pending NOT touched by recovery — the live claim owns it");
const r8 = await fetch(`${BASE}/api/open/claim`, { method: "POST", headers: { cookie, "Content-Type": "application/json" }, body: JSON.stringify({ pendingId: d6.pendingId }) });
ok(r8.status === 200, "the live claim still succeeds after a mid-spin me poll");

// --- cleanup ---
await db.drop.deleteMany({ where: { playerId: player.id } });
await db.openPending.deleteMany({ where: { playerId: player.id } });
await db.ledger.deleteMany({ where: { playerId: player.id } });
await db.player.delete({ where: { id: player.id } });
console.log(`\n== ${pass} passed, ${fail} failed ==`);
await db.$disconnect();
process.exit(fail ? 1 : 0);
