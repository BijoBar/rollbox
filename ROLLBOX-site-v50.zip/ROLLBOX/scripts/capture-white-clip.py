"""Clipped-to-reel screenshot burst — small capture area ≈ 50-150ms latency,
guaranteed inside the 1.5s white window."""
from playwright.sync_api import sync_playwright

OUT = "/home/z/my-project/download/e2e-shots"

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 900, "height": 1100})
    pg.goto("http://localhost:3000/case/test-rolldrop", wait_until="load", timeout=60000)
    pg.evaluate("localStorage.setItem('rb-rolldrop-force','1')")
    pg.reload(wait_until="load", timeout=60000)
    pg.wait_for_timeout(2500)
    pg.click("button:has-text('Open Case')")
    for _ in range(60):
        pg.evaluate(
            "document.querySelector('section[aria-label*=\"unboxing reel\"]')"
            "?.scrollIntoView({block:'center'})"
        )
        pg.wait_for_timeout(100)
    # poll tightly for the cover
    while True:
        if pg.evaluate("!!document.querySelector('.rd-white-cover')"):
            break
        pg.wait_for_timeout(40)
    cover = pg.query_selector(".rd-white-cover")
    box = cover.bounding_box()
    clip = {
        "x": max(0, box["x"] - 6),
        "y": max(0, box["y"] - 6),
        "width": min(888, box["width"] + 12),
        "height": min(1088, box["height"] + 12),
    }
    for i, name in enumerate(["a", "b", "c", "d"]):
        pg.screenshot(path=f"{OUT}/45g-white-{name}.png", clip=clip)
    print("clipped burst done, box:", box)
    b.close()
