#!/usr/bin/env python3
"""Task 68 browser-visual helper: create a fresh player + a 2v2 waiting room,
print the room id, the minted session token and the room URL."""
import base64
import hashlib
import hmac
import json
import sqlite3
import time
import requests

BASE = "http://localhost:3000"
DB = "db/custom.db"
SECRET = "rollbox-dev-secret"

body = base64.urlsafe_b64encode(json.dumps({"pid": "p_e2e68v", "exp": int(time.time() * 1000) + 86400000},
                                           separators=(",", ":")).encode()).decode().rstrip("=")
sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()
token = body + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")
cookies = {"rb_session": token}

con = sqlite3.connect(DB)
con.execute(
    "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
    "VALUES ('p_e2e68v', 'steam', 'e2e68v-steamid', 'T68 Visual', 5000, 0, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
)
con.commit()
con.close()

r = requests.post(BASE + "/api/gbattles", timeout=15, cookies=cookies,
                  json={"type": "2v2", "mode": "standard", "potRule": "winner",
                        "rounds": ["farm-ak47", "farm-ak47"], "private": False})
print("create status:", r.status_code)
bid = r.json().get("id")
print("ROOM_ID=" + str(bid))
print("TOKEN=" + token)
