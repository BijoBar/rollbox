"""Probe: does .rd-white-cover actually render visually? Check computed style
+ stylesheet presence at mount time."""
import json
from playwright.sync_api import sync_playwright

OUT = "/home/z/my-project/download/e2e-shots"

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    errors = []
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.goto("http://localhost:3000/case/test-rolldrop", wait_until="networkidle")
    pg.evaluate("localStorage.setItem('rb-rolldrop-force','1')")
    pg.reload(wait_until="networkidle")
    pg.wait_for_timeout(600)

    css_found = pg.evaluate(
        """() => { let f = [];
        for (const ss of document.styleSheets) {
          try { for (const r of ss.cssRules) { if (r.cssText && r.cssText.includes('rd-white-cover')) f.push(r.cssText.slice(0,120)); } } catch (e) {}
        } return f; }"""
    )
    print("stylesheet rules mentioning rd-white-cover:", json.dumps(css_found))

    pg.click("button:has-text('Open Case')")
    pg.wait_for_selector(".rd-white-cover", state="attached", timeout=25000)
    info = pg.evaluate(
        """() => { const el = document.querySelector('.rd-white-cover');
        if (!el) return 'GONE';
        const cs = getComputedStyle(el);
        const r = el.getBoundingClientRect();
        return { animation: cs.animationName + ' ' + cs.animationDuration,
                 opacity: cs.opacity, bg: cs.backgroundImage.slice(0,60),
                 rect: {w: r.width, h: r.height, x: r.x, y: r.y},
                 parent: el.parentElement?.className?.slice?.(0,80) }; }"""
    )
    print("cover element at mount:", json.dumps(info, indent=1))
    pg.screenshot(path=f"{OUT}/45e-probe-mount.png")
    pg.wait_for_timeout(350)
    info2 = pg.evaluate(
        """() => { const el = document.querySelector('.rd-white-cover');
        if (!el) return 'GONE';
        const cs = getComputedStyle(el);
        return { opacity: cs.opacity, clip: cs.clipPath }; }"""
    )
    print("cover at +350ms:", json.dumps(info2))
    pg.screenshot(path=f"{OUT}/45e-probe-350.png")
    print("pageerrors:", errors[:3])
    b.close()
