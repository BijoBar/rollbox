// Forge a signed rb_session cookie for a test player (sandbox E2E only).
// Usage: node scripts/forge-session.mjs <playerId>
import crypto from "node:crypto";
import fs from "node:fs";

const pid = process.argv[2];
if (!pid) {
  console.error("usage: node scripts/forge-session.mjs <playerId>");
  process.exit(1);
}
const secret = fs.readFileSync("db/.auth-secret", "utf8").trim();
const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 30 * 24 * 3600 * 1000 })).toString("base64url");
const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
console.log(`${body}.${sig}`);
