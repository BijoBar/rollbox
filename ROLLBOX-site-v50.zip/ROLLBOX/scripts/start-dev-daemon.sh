#!/usr/bin/env bash
# ROLLBOX dev-server daemon (python double-fork, reparented to PID 1 so the
# process survives between tool calls). Idempotent: kills any previous
# instance on port 3000 first, waits for HTTP 200, tails dev.log.
set -u
cd /home/z/my-project

# stop any previous next dev / daemonized instance
pkill -f "next dev" 2>/dev/null
pkill -f "rb-dev-daemon" 2>/dev/null
sleep 1

rm -f dev.log

python3 - <<'PY'
import os, sys, time, subprocess, signal

log = open("/home/z/my-project/dev.log", "ab")

def daemon():
    # first fork
    try:
        pid = os.fork()
        if pid > 0:
            os._exit(0)
    except OSError:
        sys.exit(1)
    os.setsid()
    # second fork
    try:
        pid = os.fork()
        if pid > 0:
            os._exit(0)
    except OSError:
        sys.exit(1)
    os.chdir("/home/z/my-project")
    os.umask(0o22)
    # redirect stdio to the log
    os.dup2(log.fileno(), 0)
    os.dup2(log.fileno(), 1)
    os.dup2(log.fileno(), 2)
    proc = subprocess.Popen(
        ["bun", "run", "dev"],
        cwd="/home/z/my-project",
        stdout=log,
        stderr=log,
        env={**os.environ, "PORT": "3000"},
        preexec_fn=os.setpgrp,
    )
    # supervise forever
    while True:
        try:
            _, status = os.wait()
        except InterruptedError:
            continue
        except ChildProcessError:
            pass
        time.sleep(2)
        if proc.poll() is not None:
            new = subprocess.Popen(
                ["bun", "run", "dev"],
                cwd="/home/z/my-project",
                stdout=log,
                stderr=log,
                env={**os.environ, "PORT": "3000"},
                preexec_fn=os.setpgrp,
            )
            proc = new

# marker so pkill can find the supervisor
import ctypes
libc = ctypes.CDLL("libc.so.6", use_errno=True)
argv0 = b"rb-dev-daemon"
buf = ctypes.create_string_buffer(argv0)
libc.prctl(15, buf, 0, 0, 0)  # PR_SET_NAME

daemon()
PY

# wait for the server
for i in $(seq 1 45); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null)
  if [ "$code" = "200" ]; then
    echo "DEV SERVER UP (http 200 after ${i}s)"
    exit 0
  fi
  sleep 1
done
echo "DEV SERVER FAILED TO COME UP — dev.log tail:"
tail -20 dev.log
exit 1
