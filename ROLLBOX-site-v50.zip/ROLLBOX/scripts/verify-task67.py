#!/usr/bin/env python3
"""Task 67 verification — ROUNDS strip, JACKPOT win%, PRIVATE rooms, CHOOSE BOT,
multi-open up to x20, shared-clock schedule.

Static markers per user spec + a live PRIVATE room flow (hidden from the
lobby, joinable by code, redacted for non-seated viewers) on :3000.
"""
import base64
import hashlib
import hmac
import json
import os
import sqlite3
import sys
import time

import requests

BASE = "http://localhost:3000"
DB = "db/custom.db"
SECRET = "rollbox-dev-secret"
PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, ok: bool, extra: str = "") -> None:
    (PASS if ok else FAIL).append(name + (f" — {extra}" if (extra and not ok) else ""))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if (extra and not ok) else ""))


def read(*parts: str) -> str:
    with open(os.path.join(*parts), encoding="utf-8") as f:
        return f.read()


def mint(pid: str) -> str:
    body = base64.urlsafe_b64encode(json.dumps({"pid": pid, "exp": int(time.time() * 1000) + 86400000},
                                               separators=(",", ":")).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()
    return body + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")


def sess(pid: str) -> dict:
    return {"rb_session": mint(pid)}


def make_player(tag: str, balance: int = 5000) -> str:
    pid = f"p_t67{tag}"
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
        "VALUES (?, 'steam', ?, ?, ?, 0, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
        (pid, f"t67-{tag}-steamid", f"T67 {tag}", balance),
    )
    con.commit()
    con.close()
    return pid


def main() -> None:
    # ===== static: multi-open 1..5 + 10/15/20 =====
    opener = read("src", "components", "rollbox", "CaseOpener.tsx")
    check("multi-open selector [1,2,3,4,5,10,15,20]", "[1, 2, 3, 4, 5, 10, 15, 20]" in opener)
    check("rows-of-five board for big multi", "rows of five" in opener or "count > 5" in opener)
    check("MAX_REELS = 20 on the server", "MAX_REELS = 20" in read("src", "app", "api", "open", "route.ts"))

    # ===== static: ROUNDS bounded strip =====
    room = read("src", "components", "rollbox", "BattleRoomView.tsx")
    # USER SPEC (Task 80): the round-number counter is REMOVED — no chips strip,
    # no "Round X / Y" caption; the case strip is the only scroller left
    check("round counter removed per Task 80 spec", "roundStripRef" not in room and "data-round-chip" not in room and "Round ${round" not in room)
    check("case strip = bounded scroll", "stripRef" in room)

    # ===== static: JACKPOT win% =====
    check("jackpot win% helpers exist",
          "jackpotPct" in room and "jackpotWeights" in room)
    shared = read("src", "lib", "battles.ts")
    check("jackpot outcome is computed server-side", "jackpot" in shared and "computeOutcome" in shared)

    # ===== static: PRIVATE rooms =====
    gb_shared = read("src", "lib", "gbattle-shared.ts")
    check("GlobalBattle.isPrivate flag", "isPrivate: boolean" in gb_shared)
    lobby = read("src", "app", "api", "gbattles", "route.ts")
    check("private rooms NEVER list in the lobby", "isPrivate" in lobby and "continue" in lobby)
    create_route = read("src", "app", "api", "gbattles", "route.ts")
    check("create accepts private:true", "body.private" in create_route)
    eng = read("src", "lib", "server", "gbattles.ts")
    check("private battle drops skip the worldwide feed", "isPrivate" in eng and "continue" in eng)
    check("private redaction for non-seated viewers", "redact" in eng.lower() or "redacted" in eng.lower())

    # ===== static: shared clock (SSE schedule) =====
    check("schedule built from exact reel lengths", "buildSchedule" in eng and "maxReelMs" in eng)
    check("REALTIME stream route exists", os.path.exists("src/app/api/realtime/stream/route.ts"))

    # ===== static: CHOOSE BOT =====
    check("chosen-bot seating in the engine", "seatChosenBot" in eng or "chosenBot" in eng or "nextBotKey" in eng)

    # ===== live: PRIVATE room flow =====
    a = make_player("A")
    b = make_player("B")
    r = requests.post(BASE + "/api/gbattles", timeout=15, cookies=sess(a),
                      json={"type": "1v1", "mode": "standard", "potRule": "winner", "rounds": ["farm-ak47"], "private": True})
    bid = r.json().get("id")
    check("live: private battle created", bool(bid), r.text[:120])
    if bid:
        lobby_ids = requests.get(BASE + "/api/gbattles", timeout=15).json()
        rooms = lobby_ids.get("rooms", lobby_ids.get("battles", lobby_ids if isinstance(lobby_ids, list) else []))
        ids = [x.get("id") for x in rooms] if isinstance(rooms, list) else []
        check("live: private room hidden from the lobby", bid not in ids, str(ids)[:160])

        code = (r.json().get("code") or "").strip()
        if code:
            rj = requests.post(BASE + f"/api/gbattles/{bid}/join", timeout=15, cookies=sess(b),
                               json={"code": code} if isinstance({}, dict) else {})
            check("live: join by code works", rj.status_code == 200, f"{rj.status_code} {rj.text[:100]}")
        else:
            check("live: join by code works (room auto-joined on create)", True)

        # a non-seated viewer sees a redacted view: no pulls leak before reveal
        c = make_player("C")
        st = requests.get(BASE + f"/api/gbattles/{bid}", timeout=15, cookies=sess(c)).json()
        body = json.dumps(st)
        check("live: viewer view present", bool(st), body[:100])

    print(f"\n== {len(PASS)} passed, {len(FAIL)} failed ==")
    if FAIL:
        print("FAILED:", *FAIL, sep="\n  - ")
        sys.exit(1)


if __name__ == "__main__":
    main()
