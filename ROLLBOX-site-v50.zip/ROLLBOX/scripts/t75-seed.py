#!/usr/bin/env python3
"""Task 75 browser-E2E seed — a UI player + two finished battles in the DB."""
import json
import sqlite3

DB = "db/custom.db"
PID = "p_t75ui"

con = sqlite3.connect(DB)
con.execute(
    "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
    "VALUES (?, 'steam', 't75-ui-steamid', 'T75 UI Player', 100000, 0, 1, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
    (PID,),
)


def seed(bid, code, finished_ago_s, me_wins, take):
    seats = json.dumps([
        {"key": PID, "name": "T75 UI Player", "team": 0, "color": 0, "isBot": False, "paid": 30},
        {"key": "bot_0", "name": "[RBbot] Vic", "team": 1, "color": 1, "isBot": True, "paid": 0},
    ])
    winners = json.dumps([PID if me_wins else "bot_0"])
    pulls = json.dumps([
        {"playerId": PID, "total": take, "pulls": [{"round": 0, "value": take}]},
        {"playerId": "bot_0", "total": 10, "pulls": [{"round": 0, "value": 10}]},
    ])
    takes = json.dumps({PID: take if me_wins else 0, "bot_0": 0 if me_wins else 60})
    con.execute(
        "INSERT OR REPLACE INTO Battle (id, code, hostId, type, mode, potRule, fast, isPrivate, rounds, entry, status, "
        "colorOrder, seats, pulls, winnerIds, tieIds, potTotal, take, startedAt, totalMs, createdAt, updatedAt, finishedAt) "
        "VALUES (?, ?, ?, '1v1', 'standard', 'winner', 0, 0, '[\"test-rolldrop\"]', 30, 'finished', '[0,1,2,3]', ?, ?, ?, NULL, ?, ?, NULL, NULL, "
        "CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, datetime('now', ?))",
        (bid, code, PID, seats, pulls, winners, take + 10, takes, f"-{finished_ago_s} seconds"),
    )


seed("t75uibold", "RB-OLD", 7200, False, 0)
seed("t75uinew", "RB-NEW", 60, True, 60)
con.commit()
con.close()
print("seeded", PID)
