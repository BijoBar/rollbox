// E2E fixture for Task 183 — FREE CASES (admin gifting + mission prizes).
// --create   : creates a THROWAWAY admin player (balance 0 — the new signup
//              rule) + mints a signed session cookie (printed as JSON).
// --state    : prints the player's freeCases + missions columns.
// --missions : seeds mission counters that complete mission m2 (Battle
//              Rookie) WITHOUT the granted stamp — the lazy claim must pay.
// --cleanup  : deletes the throwaway row and prints the remaining count.
// The members counter is NOT bumped (direct db write, not upsertPlayer) and
// no ledger rows are created by the fixture itself — stats stay untouched.
import { db } from "../src/lib/db";
import { makeSessionToken } from "../src/lib/server/auth";

const ID = "p_e2e_free_t183";

const mode = process.argv[2] ?? "--create";

if (mode === "--create") {
  await db.player.deleteMany({ where: { id: ID } }); // stale fixture from a crashed run
  const p = await db.player.create({
    data: {
      id: ID,
      provider: "steam",
      providerId: "steam_e2e_free_t183",
      name: "E2E Free Test",
      // Task 183: new accounts land with ZERO balance and must deposit.
      balance: 0,
      isAdmin: true, // the gift flow lives in the admin panel
    },
  });
  console.log(JSON.stringify({ id: p.id, balance: p.balance, token: makeSessionToken(p.id) }));
} else if (mode === "--state") {
  const p = await db.player.findUnique({ where: { id: ID } });
  if (!p) {
    console.log(JSON.stringify({ missing: true }));
  } else {
    let free: unknown = {};
    try { free = JSON.parse(p.freeCases ?? "{}"); } catch { free = { garbage: p.freeCases }; }
    let missions: unknown = null;
    try { missions = JSON.parse(p.missions ?? "null"); } catch { missions = null; }
    console.log(JSON.stringify({ freeCases: free, missions, balance: p.balance }));
  }
} else if (mode === "--missions") {
  // m2 Battle Rookie: battles3=3, battlesWon=1, battlesBots=1 → ALL live steps done
  await db.player.update({
    where: { id: ID },
    data: { missions: JSON.stringify({ v: 1, c: { battles3: 3, battlesWon: 1, battlesBots: 1 } }) },
  });
  console.log(JSON.stringify({ seeded: "m2-counters" }));
} else if (mode === "--cleanup") {
  await db.player.deleteMany({ where: { id: ID } });
  const n = await db.player.count();
  console.log(JSON.stringify({ deleted: ID, players: n }));
}
process.exit(0);
