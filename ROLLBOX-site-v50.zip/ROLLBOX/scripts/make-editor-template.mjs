// One-time: turn the user's canonical CASE EDITOR (upload/ROLLBOX-cases-editor.html)
// into the rebuildable template — the two generated data lines (BASE / SKINS)
// become __CASES_BASE__ / __SKINS__ injection placeholders. Everything else is
// preserved byte-for-byte.
import { readFileSync, writeFileSync } from "node:fs";

const SRC = "/home/z/my-project/upload/ROLLBOX-cases-editor.html";
const DST = "/home/z/my-project/scripts/case-editor-template.html";

const lines = readFileSync(SRC, "utf8").split("\n");
let skinsTail = ""; // trailing comment (incl. spacing) after the SKINS statement

const out = lines.map((line) => {
  if (line.startsWith("const BASE = ")) {
    if (!line.trimEnd().endsWith(";")) throw new Error("unexpected BASE line tail: " + line.slice(-30));
    return "const BASE = __CASES_BASE__;";
  }
  if (line.startsWith("const SKINS = ")) {
    const end = line.lastIndexOf("};"); // statement-ending brace (JSON holds no "};")
    if (end === -1) throw new Error("SKINS statement end not found");
    skinsTail = line.slice(end + 2); // spaces + // comment
    return "const SKINS = __SKINS__;" + skinsTail;
  }
  return line;
});

writeFileSync(DST, out.join("\n"));
console.log("template written:", DST, "| SKINS tail preserved:", JSON.stringify(skinsTail.slice(0, 60)));
