import { PrismaClient } from "@prisma/client";

// Ship-day DB scrub — wipes ALL runtime data so the delivered custom.db is
// factory-clean (matches the make-site-zip.sh flow). Local dev tool only —
// it is NOT shipped inside the site ZIP.
const db = new PrismaClient();

const out = {};
out.battle = await db.battle.deleteMany({});
out.ledger = await db.ledger.deleteMany({});
out.inventoryItem = await db.inventoryItem.deleteMany({});
out.drop = await db.drop.deleteMany({});
out.player = await db.player.deleteMany({});
out.counter = await db.counter.deleteMany({});

console.log(
  "scrubbed: " +
    Object.entries(out)
      .map(([k, v]) => `${k}=${v.count}`)
      .join(" ")
);

await db.$disconnect();
