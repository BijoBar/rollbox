(() => {
  const wrap = [...document.querySelectorAll('div.relative.overflow-hidden.rounded-2xl')][0];
  if (!wrap) return JSON.stringify({ err: 'no box' });
  const strip = wrap.querySelector('.absolute.flex.will-change-transform');
  if (!strip) return JSON.stringify({ err: 'no strip' });
  const tiles = [...strip.children];
  const WIN = 52;
  const tile = tiles[WIN];
  if (!tile) return JSON.stringify({ err: 'no tile', n: tiles.length });
  const wr = wrap.getBoundingClientRect();
  const tr = tile.getBoundingClientRect();
  const t1 = tiles[0].getBoundingClientRect();
  const t2 = tiles[1].getBoundingClientRect();
  const item = Math.round(t1.width);
  const gap = Math.round(t2.left - t1.right);
  const dist = item / 2 + gap;
  const offset = Math.round((wr.left + wr.width / 2) - (tr.left + tr.width / 2));
  const glowing = tiles.some(t => (t.className || '').includes('anim-glow-pulse') || (t.className || '').includes('anim-jackpot-glow'));
  return JSON.stringify({ offset, frac: +(offset / dist).toFixed(3), item, gap, glowing });
})()
