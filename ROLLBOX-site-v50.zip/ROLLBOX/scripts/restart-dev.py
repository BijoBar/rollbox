import os, sys, time
pid = os.fork()
if pid == 0:
    os.setsid()
    pid2 = os.fork()
    if pid2 == 0:
        os.chdir("/home/z/my-project")
        with open("/home/z/my-project/dev.log", "wb") as log:
            os.dup2(log.fileno(), 1)
            os.dup2(log.fileno(), 2)
            os.execvp("bun", ["bun", "run", "dev"])
    os._exit(0)
os.waitpid(pid, 0)
print("dev server daemonized")
