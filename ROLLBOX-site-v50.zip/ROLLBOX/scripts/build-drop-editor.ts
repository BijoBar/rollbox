// ============ DROP EDITOR builder (Task 105) ============
// Generates download/ROLLBOX-drop-editor.html — a standalone, ENGLISH-ONLY
// editor that covers EVERY case on the site (standard RB-101..RB-120, farm
// RB-201..RB-210, the free daily LEVEL cases, the TEST case) plus all five
// TERMINALS. The data is injected from the site's REAL data layer, so the
// file always starts from the live site values (USER_CASES overlay included).
//
// Re-run after any content change:  bun run scripts/build-drop-editor.ts
// Export dialects (unchanged): ROLLBOX-CASES v1 + ROLLBOX-TERMINALS v1 —
//   case lines: {code, name, price, kind, rd, items:[{n, v, p, id?, w?}]}
//     - rd is a FRACTION per opening (0.00095 = 0.095%; null = site default)
//     - level (LVL-*) cases export a content-only patch: {code, rd?, items}
//   terminal lines: {id, name, min, max, skins:[{n, v, p, id?}]}

import { writeFileSync, mkdirSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import {
  CASES,
  SKINS,
  caseItemValue,
  type CaseDef,
  type CaseItem,
} from "../src/lib/cases";
import { TERMINALS } from "../src/lib/terminals";
import { SKIN_WEAR_PRICES, SKIN_WEAR_AVAIL } from "../src/lib/generated-wear-prices";
import { skinWearValue, WEARS, USD_TO_COINS, type WearId } from "../src/lib/wear";
import { ROLLDROP_CHANCE } from "../src/lib/rolldrop";
import { renderEditor } from "./drop-editor-template.mjs";

// ---------- skin catalog embed: id -> {name, value, rarity, wp?, wa?} ----------
const skinsEmbed: Record<string, unknown> = {};
for (const [id, s] of Object.entries(SKINS)) {
  const wp = SKIN_WEAR_PRICES[id];
  const wa = SKIN_WEAR_AVAIL[id];
  const entry: Record<string, unknown> = {
    name: s.name,
    value: s.value,
    rarity: s.rarity,
  };
  if (wp) entry.wp = wp;
  if (wa) entry.wa = wa;
  skinsEmbed[id] = entry;
}

// ---------- FULL-GAME skin catalog embed (Task 27) ----------
// USER SPEC: "אפשרות לבחור את כל הסקינים במשחק כבר בDROP DOWN MENU ועל ידי
// חיפוש כולל SOUVENIR וכולל STATRAK, והמחירים יגיעו בהתאם לWEAR אוטומטית".
// Built from the site's own full CS2 DB dumps (scripts/skins-db.json +
// agents-db.json — the same source the catalog was generated from), joined
// with the catalog for rarity, and with the unified price table for real
// steamanalyst (CSFLOAT) prices.
const here = dirname(fileURLToPath(import.meta.url)); // scripts/
const root = join(here, "..");

interface GameEmbed {
  id: string;
  n: string;
  r: string;
  /** null = all five wears; [] = no exterior (agents, vanilla) */
  wa: WearId[] | null;
  st: boolean;
  sv: boolean;
  wp?: Record<string, number>; // per-wear COINS (site numbers)
}

const RARITY_FALLBACK: Record<string, string> = {
  Consumer: "consumer",
  "Industrial Grade": "milspec",
  "Mil-Spec": "milspec",
  Restricted: "restricted",
  Classified: "classified",
  Covert: "covert",
  Contraband: "contraband",
  Extraordinary: "contraband", // gloves + rare special knives
  Master: "classified",
  Superior: "classified",
  Exceptional: "restricted",
  Distinguished: "milspec",
};

const WEAR_BY_LABEL: Record<string, WearId> = Object.fromEntries(
  WEARS.map((w) => [w.id, w.label] as const).map(([id, label]) => [label, id as WearId]),
) as Record<string, WearId>;

const slugify = (s: string): string =>
  s
    .toLowerCase()
    .replace(/★/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

// name -> catalog entry (rarity + id + wear availability + USD-per-wear)
import { readFileSync as rf } from "node:fs";
const catalogRows = JSON.parse(rf(join(root, "public", "skins-catalog.json"), "utf8")) as {
  id: string;
  n: string;
  r: string;
  wp?: Record<string, number>;
  wa?: WearId[];
}[];
const catByName = new Map(catalogRows.map((e) => [e.n.replace(/\s+/g, " ").trim(), e]));

/** tolerant JSON read — a missing dump degrades instead of killing the build */
function loadJsonOrEmpty<T>(file: string, label: string): T[] {
  try {
    return JSON.parse(rf(file, "utf8")) as T[];
  } catch {
    console.warn("WARN: could not read " + label + " — skipping that layer");
    return [];
  }
}

const gameEmbed: GameEmbed[] = [];
const gameSeen = new Set<string>();
function pushGame(name: string, rarityName: string, wears: string[] | null, st: boolean, sv: boolean): void {
  const key = name.replace(/\s+/g, " ").trim();
  if (!key || gameSeen.has(key)) return;
  gameSeen.add(key);
  const cat = catByName.get(key);
  const wp: Record<string, number> | undefined = SKIN_WEAR_PRICES[cat?.id ?? ""];
  gameEmbed.push({
    id: cat?.id ?? slugify(name),
    n: key,
    r: cat?.r ?? RARITY_FALLBACK[rarityName] ?? "consumer",
    wa: wears === null ? null : wears.map((w) => WEAR_BY_LABEL[w]).filter(Boolean),
    st,
    sv,
    ...(wp ? { wp } : {}),
  });
}

for (const s of loadJsonOrEmpty<{ name: string; rarity?: { name?: string }; wears?: { name?: string }[]; stattrak?: boolean; souvenir?: boolean }>(join(root, "scripts", "skins-db.json"), "skins-db.json")) {
  pushGame(
    s.name,
    s.rarity?.name ?? "",
    (s.wears ?? []).map((w) => w.name ?? "").filter(Boolean),
    s.stattrak === true,
    s.souvenir === true,
  );
}
for (const a of loadJsonOrEmpty<{ name: string; rarity?: { name?: string } }>(join(root, "scripts", "agents-db.json"), "agents-db.json")) {
  pushGame(a.name, a.rarity?.name ?? "", [], false, false); // agents: no exterior
}
// RESILIENCE: when the big DB dumps are absent (portable ZIP runs) the picker
// degrades to the catalog's weapons + agents — still every skin the site prices.
if (!gameEmbed.length) {
  console.warn("WARN: skins-db.json / agents-db.json missing — the FULL-GAME picker falls back to the site catalog (no StatTrak/Souvenir flags)");
  for (const e of catalogRows) {
    const isWeapon = !!e.wp;
    const isAgent = !e.wp && !e.wa; // agents / vanilla: no wear table at all
    if (!isWeapon && !isAgent) continue;
    pushGame(e.n, "", e.wa ?? null, false, false);
  }
}

// ---------- unified price table embed (steamanalyst / CSFLOAT, USD) ----------
let unifiedEmbed: Record<string, number> = {};
let unifiedUpdatedAt = 0;
try {
  const t = JSON.parse(rf(join(root, "db", "steamanalyst-prices.json"), "utf8")) as {
    updatedAt?: number;
    prices?: Record<string, { usd?: number }>;
  };
  unifiedUpdatedAt = t.updatedAt ?? 0;
  for (const [name, p] of Object.entries(t.prices ?? {})) {
    if (typeof p?.usd === "number" && p.usd > 0) unifiedEmbed[name] = p.usd;
  }
} catch {
  /* no table yet — the editor falls back to site prices + estimates */
}

// ---------- cases embed ----------
function isNoWearSkin(skinId: string): boolean {
  // stickers / agents / patches / charms — nothing the wear picker applies to
  return !SKIN_WEAR_PRICES[skinId] && !SKIN_WEAR_AVAIL[skinId];
}

function embedItem(item: CaseItem) {
  const skin = SKINS[item.skinId];
  const wear = item.wear ?? null;
  let v: number;
  let pin: boolean;
  let est = false;
  if (item.value != null && Number.isFinite(item.value)) {
    v = item.value; // cent-precise pin typed by the user (caseItemValue prefers it)
    pin = true;
  } else if (wear) {
    const r = skinWearValue(item.skinId, wear, skin?.value ?? 0);
    v = r.value;
    est = r.est;
    pin = false;
  } else {
    v = caseItemValue(item);
    pin = false;
  }
  return {
    id: item.skinId,
    n: skin?.name ?? item.skinId,
    p: item.weight,
    w: wear,
    v,
    pin,
    est,
  };
}

function embedCase(c: CaseDef) {
  return {
    code: c.code,
    name: c.name,
    subtitle: c.subtitle,
    kind: c.kind,
    // nav group: TEST is site-kind "standard" but gets its own group
    grp: c.code === "RB-TST" ? "test" : c.kind,
    price: c.price,
    lvl: c.requiredLevel ?? null,
    rd: c.rolldropChance ?? null, // fraction per opening; null = site default
    items: c.items.map(embedItem),
  };
}

const casesEmbed = CASES.map(embedCase);

// ---------- terminals embed (the merged live table) ----------
const terminalsEmbed = TERMINALS.map((t) => ({
  id: t.id,
  name: t.name,
  subtitle: t.subtitle ?? "",
  min: t.min,
  max: t.max,
  skins: t.skins.map((s) => ({ id: s.id ?? null, n: s.n, v: s.v, p: s.p })),
}));

// ---------- validation ----------
const noWearIds = new Set(
  casesEmbed.flatMap((c) => c.items.map((i) => i.id as string)).filter(isNoWearSkin),
);
let sumWarn = 0;
for (const c of casesEmbed) {
  const s = c.items.reduce((a, i) => a + (i.p || 0), 0);
  if (Math.abs(s - 100) > 0.01) sumWarn++;
}
for (const t of terminalsEmbed) {
  const s = t.skins.reduce((a, i) => a + (i.p || 0), 0);
  if (Math.abs(s - 100) > 0.01) sumWarn++;
}

// ---------- render ----------
const escJson = (x: unknown) => JSON.stringify(x).replace(/</g, "\\u003c");
const html = renderEditor(
  escJson(skinsEmbed),
  escJson(casesEmbed),
  escJson(terminalsEmbed),
  escJson(gameEmbed),
  escJson(unifiedEmbed),
  USD_TO_COINS,
  unifiedUpdatedAt,
);

// Hebrew/RTL guard — the file must be ENGLISH ONLY
const hebrew = html.match(/[\u0590-\u05FF\u200f\u200e]/g);
if (hebrew) {
  console.error("FAIL: Hebrew characters found in the generated HTML:", hebrew.length);
  process.exit(1);
}
if (html.includes('dir="rtl"') || html.includes("lang=\"he\"")) {
  console.error("FAIL: RTL/Hebrew lang attributes found");
  process.exit(1);
}

const out = join(root, "download", "ROLLBOX-drop-editor.html");
writeFileSync(out, html);

// ---------- summary ----------
mkdirSync(join(root, "download"), { recursive: true });
const byKind = (k: string) => casesEmbed.filter((c) => c.grp === k).length;
console.log("DROP EDITOR written:", out);
console.log(
  `cases: ${casesEmbed.length} total — standard:${byKind("standard")} farm:${byKind("farm")} level:${byKind("level")} test:${byKind("test")}`,
);
console.log(`terminals: ${terminalsEmbed.length} (${terminalsEmbed.map((t) => t.id).join(", ")})`);
console.log(`skin catalog: ${Object.keys(skinsEmbed).length} entries (${noWearIds.size} without wear)`);
console.log(`FULL-GAME picker: ${gameEmbed.length} base skins (${gameEmbed.filter((g) => g.st).length} StatTrak-capable, ${gameEmbed.filter((g) => g.sv).length} Souvenir-capable) + unified table: ${Object.keys(unifiedEmbed).length} real prices @ 1$=${USD_TO_COINS}c`);
console.log(`HTML size: ${(html.length / 1024).toFixed(1)} KB`);
console.log(`sum warnings (tables not at 100): ${sumWarn}`);
console.log(`ROLLDROP default: ${ROLLDROP_CHANCE} (${ROLLDROP_CHANCE * 100}%)`);
