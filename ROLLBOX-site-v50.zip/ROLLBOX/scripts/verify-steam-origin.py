#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Task 65 — Steam OpenID origin checks against the LIVE dev server.
The "localhost sent an invalid response" Cloudflare-Tunnel fix.

Run: python scripts/verify-steam-origin.py   (dev server must be on :3000)
"""
import sys
import urllib.parse
import urllib.error
import urllib.request

BASE = "http://localhost:3000"
results = []


def check(name, ok, detail=""):
    results.append(bool(ok))
    print(("PASS  " if ok else "FAIL  ") + name + ("" if ok else f"   [{detail}]"))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


OPENER = urllib.request.build_opener(NoRedirect)


def get_no_redirect(path, headers=None):
    req = urllib.request.Request(BASE + path, headers=headers or {})
    try:
        resp = OPENER.open(req, timeout=25)
        return resp.status, {k.lower(): v for k, v in resp.headers.items()}, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, {k.lower(): v for k, v in e.headers.items()}, e.read()


def start_params(headers):
    """GET /api/auth/steam/start with custom headers -> (status, openid params)."""
    status, hdrs, body = get_no_redirect("/api/auth/steam/start", headers)
    loc = hdrs.get("location", "")
    ok_start = status in (302, 307) and loc.startswith("https://steamcommunity.com/openid/login?")
    if not ok_start:
        return status, loc, None
    q = urllib.parse.urlparse(loc)
    params = {k: v[0] for k, v in urllib.parse.parse_qs(q.query).items()}
    return status, loc, params


# ---------------------------------------------------------------- 1 — plain local dev
status, loc, p = start_params({})
check("1. start route redirects to Steam's openid endpoint",
      p is not None and status in (302, 307), f"status={status} loc={loc[:90]}")
if p is not None:
    check("1a. return_to = http://localhost:3000/api/auth/steam/callback",
          p.get("openid.return_to") == "http://localhost:3000/api/auth/steam/callback",
          str(p.get("openid.return_to")))
    check("1b. realm = http://localhost:3000",
          p.get("openid.realm") == "http://localhost:3000", str(p.get("openid.realm")))

# ------------------------------------- 2 — THE USER'S BUG (cloudflared signature)
# cloudflared forwards to http://localhost:3000 with X-Forwarded-Proto: https
# and Host: localhost:3000. The old code turned that into
# https://localhost:3000 -> Chrome: "localhost sent an invalid response".
status, loc, p = start_params({"X-Forwarded-Proto": "https", "Host": "localhost:3000"})
check("2. BUG REPRO (X-Forwarded-Proto:https + localhost host) stays http://localhost",
      p is not None and p.get("openid.return_to") == "http://localhost:3000/api/auth/steam/callback"
      and p.get("openid.realm") == "http://localhost:3000",
      f"return_to={p.get('openid.return_to') if p else loc[:90]}")

# --------------------------------------------- 3 — named tunnel / reverse proxy
status, loc, p = start_params({"X-Forwarded-Host": "play.example.com", "X-Forwarded-Proto": "https"})
check("3. X-Forwarded-Host builds the public return_to",
      p is not None and p.get("openid.return_to") == "https://play.example.com/api/auth/steam/callback",
      str(p.get("openid.return_to") if p else loc[:90]))
check("3a. realm matches the same public origin",
      p is not None and p.get("openid.realm") == "https://play.example.com",
      str(p.get("openid.realm") if p else ""))

# --------------------------------------------------- 4 — quick tunnel via Referer
status, loc, p = start_params({"Referer": "https://quiet-gate-abc.trycloudflare.com/login"})
check("4. quick-tunnel Referer builds the public return_to (zero-config)",
      p is not None and p.get("openid.return_to") == "https://quiet-gate-abc.trycloudflare.com/api/auth/steam/callback",
      str(p.get("openid.return_to") if p else loc[:90]))

# --------------------------------------------------- 5 — LAN deployment (direct)
status, loc, p = start_params({"Host": "192.168.1.7:3000"})
check("5. LAN host (START-ROLLBOX-LAN.bat) keeps working",
      p is not None and p.get("openid.return_to") == "http://192.168.1.7:3000/api/auth/steam/callback",
      str(p.get("openid.return_to") if p else loc[:90]))

# --------------------------------- 6 — callback error path: forged return_to
# A garbage assertion with a tampered return_to must NEVER become the redirect
# target (the failure redirect uses the strict resolver: localhost here).
forged = urllib.parse.urlencode({
    "openid.ns": "http://specs.openid.net/auth/2.0",
    "openid.mode": "id_res",
    "openid.return_to": "https://evil.example.com/api/auth/steam/callback",
    "openid.identity": "http://steamcommunity.com/openid/id/12345678901234567",
    "openid.claimed_id": "http://steamcommunity.com/openid/id/12345678901234567",
    "openid.sig": "garbage",
    "openid.signed": "ns,mode,return_to",
})
status, hdrs, body = get_no_redirect("/api/auth/steam/callback?" + forged)
loc = hdrs.get("location", "")
check("6. failed verification redirects to /login?error=steam on the LOCAL origin",
      status in (302, 307) and loc == "http://localhost:3000/login?error=steam",
      f"status={status} loc={loc}")
check("6a. forged evil.example.com return_to is ignored",
      "evil.example.com" not in loc, loc)

print()
if all(results):
    print(f"ALL PASS ({len(results)} checks)")
else:
    print(f"FAILED: {results.count(False)} of {len(results)} checks failed")
    sys.exit(1)
