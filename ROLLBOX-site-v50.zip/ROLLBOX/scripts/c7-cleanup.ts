// C7 E2E helper — snapshot / restore the test player's money state and wipe
// every wallet-test artifact so the suite is idempotent and the DB stays
// exactly as it was (players:9, balances intact).
//   bun scripts/c7-cleanup.ts snapshot  -> save p_t66A's balance+missions to .c7-snapshot.json
//   bun scripts/c7-cleanup.ts restore   -> delete test rows + ledger rows +
//                                          wallet config keys, restore the snapshot
import fs from "fs";
import path from "path";
import { db } from "../src/lib/db";

const SNAPSHOT = path.join(process.cwd(), "scripts", ".c7-snapshot.json");
const PID = "p_t66A";
const TEST_LEDGER_KINDS = ["deposit", "withdraw_lock", "withdraw_refund"];
const CONFIG_KEYS = [
  "wallet.enabled",
  "wallet.usdt_address",
  "wallet.minDeposit",
  "wallet.maxDeposit",
  "wallet.minWithdraw",
  "wallet.maxWithdraw",
];

const mode = process.argv[2] ?? "restore";

async function wipeArtifacts() {
  const delDep = await db.depositRequest.deleteMany({ where: { playerId: PID } });
  const delWd = await db.withdrawalRequest.deleteMany({ where: { playerId: PID } });
  const delLed = await db.ledger.deleteMany({ where: { playerId: PID, kind: { in: TEST_LEDGER_KINDS } } });
  const delCfg = await db.siteConfig.deleteMany({ where: { key: { in: CONFIG_KEYS } } });
  console.log(`deleted: deposits=${delDep.count} withdrawals=${delWd.count} ledgerRows=${delLed.count} configKeys=${delCfg.count}`);
}

if (mode === "snapshot") {
  const p = await db.player.findUnique({ where: { id: PID } });
  if (!p) {
    console.error("NO TEST PLAYER");
    process.exit(1);
  }
  fs.writeFileSync(SNAPSHOT, JSON.stringify({ pid: PID, balance: p.balance, missions: p.missions }, null, 2));
  await wipeArtifacts(); // leftover rows from an earlier crashed run
  console.log(`snapshot: balance=${p.balance} missions=${p.missions ? "set" : "null"}`);
  process.exit(0);
}

// ---- restore ----
const snap = JSON.parse(fs.readFileSync(SNAPSHOT, "utf8")) as { pid: string; balance: number; missions: string | null };
await wipeArtifacts();
const p = await db.player.findUnique({ where: { id: snap.pid } });
if (!p) {
  console.error("NO TEST PLAYER");
  process.exit(1);
}
if (Math.abs(p.balance - snap.balance) > 0.005) {
  await db.player.update({ where: { id: snap.pid }, data: { balance: snap.balance, missions: snap.missions } });
  console.log(`restored balance ${p.balance} -> ${snap.balance} (+missions)`);
} else {
  await db.player.update({ where: { id: snap.pid }, data: { missions: snap.missions } });
  console.log(`balance already exact (${p.balance}) — missions restored`);
}
const players = await db.player.count();
console.log(`players now: ${players}`);
process.exit(0);
