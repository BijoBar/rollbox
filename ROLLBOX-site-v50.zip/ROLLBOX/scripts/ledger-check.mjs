import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const rows = await db.ledger.findMany({ where: { playerId: "p_t66A" }, orderBy: { id: "desc" }, take: 8 });
for (const r of rows) console.log(r.kind, r.amount, "bal:", r.balanceAfter, r.ref ?? "");
const p = await db.player.findUnique({ where: { id: "p_t66A" } });
console.log("BALANCE:", p.balance);
await db.$disconnect();
