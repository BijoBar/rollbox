#!/usr/bin/env bash
# Task 43 E2E — part 4: fire button -> vertical picker -> send -> float rises
# from the sender's box. Runs whenever the room is (playing|done).
set -u
AB="agent-browser"
D="/home/z/my-project/download"

echo "=== fire button placement (next to YOUR name) ==="
$AB eval '(() => {
  const fire = document.querySelector("button[aria-label=\"Open the reactions menu\"]");
  if (!fire) return JSON.stringify({fire: false});
  const col = fire.closest("div.relative.flex.flex-col, div[class*=\"relative flex flex-col\"]");
  const header = fire.closest("span.flex.min-w-0");
  const nameEl = header?.querySelector("span.truncate");
  return JSON.stringify({fire: true, inHeaderRow: !!header, nextToName: nameEl?.textContent, insideYourColumn: !!col});
})()' 2>/dev/null | tail -1

echo "=== open picker -> vertical list ==="
$AB eval '(() => { document.querySelector("button[aria-label=\"Open the reactions menu\"]")?.click(); return "clicked"; })()' 2>/dev/null | tail -1
sleep 0.8
$AB eval '(() => {
  const menu = document.querySelector("[role=\"menu\"]");
  if (!menu) return JSON.stringify({menu: false});
  const items = [...menu.querySelectorAll("button[role=\"menuitem\"]")].map(b => b.textContent);
  const cs = getComputedStyle(menu);
  const r = menu.getBoundingClientRect();
  return JSON.stringify({
    menu: true, count: items.length,
    emojis: items.join(""),
    vertical: cs.display.includes("flex") && cs.flexDirection === "column",
    scrollable: menu.scrollHeight > menu.clientHeight,
    maxH: cs.maxHeight, width: Math.round(r.width), height: Math.round(r.height)
  });
})()' 2>/dev/null | tail -1
$AB screenshot "$D/task43-emoji-picker.png" >/dev/null 2>&1

echo "=== send 💀 -> float rises from your box ==="
$AB eval '(() => {
  const skull = [...document.querySelectorAll("[role=\"menu\"] button[role=\"menuitem\"]")].find(b => b.textContent === "💀");
  skull?.click();
  return skull ? "sent 💀" : "NO 💀";
})()' 2>/dev/null | tail -1
$AB eval '(() => {
  const floats = [...document.querySelectorAll(".emoji-float")];
  const box = floats[0]?.closest("div.relative");
  const colHeader = box?.querySelector("span.flex.min-w-0 span.truncate");
  return JSON.stringify({
    floats: floats.length,
    emojis: floats.map(f => f.textContent).join(","),
    insideYourBox: colHeader?.textContent,
    animated: floats[0] ? getComputedStyle(floats[0]).animationName : null,
    fmMotion: floats[0] ? !!floats[0].style.transform && false : null
  });
})()' 2>/dev/null | tail -1
sleep 0.6
$AB screenshot "$D/task43-emoji-float.png" >/dev/null 2>&1

echo "=== spam 12 emojis fast (FPS guard: no framer-motion, capped) ==="
$AB eval '(() => {
  for (let k = 0; k < 12; k++) {
    const fire = document.querySelector("button[aria-label=\"Open the reactions menu\"]");
    if (fire.style) fire.click();
    const item = [...document.querySelectorAll("[role=\"menu\"] button[role=\"menuitem\"]")][k % 17];
    item?.click();
  }
  return "spammed";
})()' 2>/dev/null | tail -1
$AB eval '(() => JSON.stringify({liveFloats: document.querySelectorAll(".emoji-float").length, fmAnimations: document.getAnimations ? document.getAnimations().length : -1}))' 2>/dev/null | tail -1