// Task 80 cleanup: remove QA players (FormatQA + Task78QA) and every battle
// they hosted during the E2E runs — restores the 9p/13b/36l baseline.
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

const qaProviderIds = ["76561198000000077", "76561198000000078"];
let removedBattles = 0;
for (const pid of qaProviderIds) {
  const p = await db.player.findUnique({ where: { providerId: pid } });
  if (!p) continue;
  const b = await db.battle.deleteMany({ where: { hostId: p.id } });
  removedBattles += b.count;
  await db.ledger.deleteMany({ where: { playerId: p.id } });
  await db.drop.deleteMany({ where: { playerId: p.id } });
  await db.inventoryItem.deleteMany({ where: { playerId: p.id } });
  // any open pending from QA runs
  await db.openPending.deleteMany({ where: { playerId: p.id } });
  await db.player.delete({ where: { id: p.id } });
  console.log(`scrubbed ${p.id} (${pid}) + ${b.count} hosted battle(s)`);
}
// hostId is a plain string column (no relation) — QA battles were all hosted
// by the two QA players above and are already gone at this point.
const counts = `${await db.player.count()}p/${await db.battle.count()}b/${await db.ledger.count()}l`;
console.log(`battles removed: ${removedBattles} | DB now: ${counts}`);
await db.$disconnect();
