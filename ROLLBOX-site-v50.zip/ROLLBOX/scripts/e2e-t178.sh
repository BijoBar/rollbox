#!/usr/bin/env bash
# e2e-t178.sh — R37 batch E2E (user's 7 fixes)
# Covers: rolldrop flat 5% everywhere (module runtime + forced flow alive) ·
# "Press open to deal the loot" deleted from the idle reel · FAST battles
# schedule waits for every seat (pad) + exactly 1s between rounds · upgrader
# round-long whoosh that ends at the verdict (alive during, 0 after) ·
# Potential upgrade resets on a fresh pick · YOUR STAKE persists through the
# round and becomes the won skin on a win · the wheel confetti canvas deleted.
# LESSONS (t175/t176/t177): agent-browser eval returns JSON-QUOTED strings —
# never exact-compare, always rg; stale console errors survive navigation —
# close + relaunch per stage for a clean buffer.
set -uo pipefail
cd /home/z/my-project
AB="agent-browser"
SHOT="scripts/e2e-t178"
BASE="http://localhost:3000"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0
check() { $AB eval "$1" 2>/dev/null | rg -o "true|false" | head -1; }
jhas() { echo "$1" | sed 's/\\//g' | rg -q "$2"; }

TOKEN="$(bun scripts/mint-e2e-session.ts 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')"

# ============================================================ STAGE 0 (module)
# the EXACT 5% — the real shipped module, executed in the repo runtime: the
# constant AND the resolver (which must now ignore every per-case override)
mod=$(bun -e "const m = await import('/home/z/my-project/src/lib/rolldrop.ts'); const fake = { items: [], rolldropChance: 0.9 }; console.log(m.ROLLDROP_CHANCE, m.rolldropChanceOf(fake), m.rolldropChanceOf({ items: [] }));" 2>/dev/null | tail -1)
echo "rolldrop module: $mod"
jhas "$mod" "^0\.05 0\.05 0\.05" && ok "rolldrop: flat 5% — constant + resolver ignore overrides" || fail "rolldrop module check ($mod)"

# ============================================================ STAGE A (guest)
$AB close >/dev/null 2>&1 || true
sleep 1
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open "$BASE/case/test-rolldrop" >/dev/null
sleep 3.5

# 1. the idle "Press open to deal the loot" caption is GONE
idle=$($AB eval "(() => { const t = document.body.innerText; return JSON.stringify({ pressOpen: /press open/i.test(t), loot: /deal the loot/i.test(t), openBtn: !!document.querySelector('button.neon-btn') }); })()" 2>/dev/null)
echo "idle reel check: $idle"
jhas "$idle" '"pressOpen":false' && jhas "$idle" '"loot":false' && ok "reel: idle caption deleted (no 'press open' / 'deal the loot')" || fail "reel: idle caption still present ($idle)"
jhas "$idle" '"openBtn":true' && ok "reel: the case page still renders with its OPEN button" || fail "reel: page broken ($idle)"

# 2. the 5% ROLLDROP flow is alive — force-flag → white flash + raredrop reel
$AB storage local set rb-rolldrop-force 1 >/dev/null 2>&1
$AB open "$BASE/case/test-rolldrop" >/dev/null
sleep 3
$AB find first "button.neon-btn" click >/dev/null 2>&1
sleep 4
rd=$(check "!!document.querySelector('img[src*=\"raredrop\"]')")
[ "$rd" = "true" ] && ok "rolldrop: forced flow alive — raredrop flash + bonus reel (5% path intact)" || fail "rolldrop: forced flow broke"
sleep 9
$AB storage local set rb-rolldrop-force 0 >/dev/null 2>&1

# console check for stage A
errsA=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -6)
if [ -z "$errsA" ]; then ok "stage A: zero page errors"; else fail "stage A errors: $errsA"; fi

# ============================================================ STAGE B (session)
$AB close >/dev/null 2>&1 || true
sleep 1
$AB open "$BASE/" >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
sleep 2

# 3. FAST battle — create one, call bots, verify the SERVER schedule pacing
$AB open "$BASE/battles/new" >/dev/null
sleep 3
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>/fast mode/i.test(x.textContent)); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 0.5
fon=$($AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>/fast mode/i.test(x.textContent)&&/on/i.test(x.textContent)); return b?'fast-on':'not-on'; })()" 2>/dev/null)
jhas "$fon" "fast-on" && ok "battle: FAST mode toggled ON" || fail "battle: fast toggle ($fon)"
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.getAttribute('aria-label')==='Add a case to the battle'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 1.2
$AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Community Cases')); t?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 0.8
$AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>(x.getAttribute('aria-label')||'').startsWith('Add T66 Galaxy Case')); t?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 0.5
$AB eval "document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); 'esc'" >/dev/null 2>&1
sleep 0.8
# a SECOND case — two rounds, so an INTER-ROUND gap exists to measure
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.getAttribute('aria-label')==='Add a case to the battle'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 1.2
$AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Community Cases')); t?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 0.8
$AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>(x.getAttribute('aria-label')||'').startsWith('Add T66 Galaxy Case')); t?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 0.5
$AB eval "document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); 'esc'" >/dev/null 2>&1
sleep 0.8
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim()==='Create Battle'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 5
url=$($AB eval "location.pathname" 2>/dev/null | sed 's/\\//g' | rg -o "/battles/[A-Za-z0-9_-]+" | head -1)
if [ -n "$url" ] && [ "$url" != "/battles/new" ]; then ok "battle: room opened at $url"; else fail "battle: did not land in a room ($url)"; fi
BID="${url##*/}"
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Call Bots')); b?.click(); return 'ok'; })()" >/dev/null 2>&1

# poll the public room view until playing, then verify the schedule math
sched="{}"
for i in $(seq 1 20); do
  sleep 1
  st=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>{ const b=d.battle||{}; return JSON.stringify({ st: b.status, fast: b.fast, n: (b.players||[]).length }); })" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$st" '"st":"playing"' && break
done
echo "battle state: $st"
jhas "$st" '"fast":true' && ok "battle: the room IS fast mode" || fail "battle: fast flag ($st)"
sched=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>{ const b=d.battle||{}; const s=b.schedule||[]; const n=(b.players||[]).length||2; const maxReel=1000+Math.max(0,n-2)*150; const det=[]; let good=true; for(let i=0;i<s.length;i++){ const len=s[i].endMs-s[i].startMs; if(len<maxReel+1500){ good=false; det.push('slot'+i+'len='+len); } if(i+1<s.length){ const gap=s[i+1].startMs-s[i].endMs; if(gap<1000){ good=false; det.push('gap'+i+'='+gap); } } } return JSON.stringify({ good, n, slots: s.length, len0: s[0]?s[0].endMs-s[0].startMs:-1, gap0: (s.length>1? s[1].startMs-s[0].endMs : -1), det: det.join(',') }); })" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "schedule check: $sched"
jhas "$sched" '"good":true' && ok "fast schedule: every round ≥ reel+1500ms wait-for-all pad, every gap ≥ 1000ms" || fail "fast schedule math ($sched)"
jhas "$sched" '"gap0":1000' && ok "fast schedule: the between-rounds breather is EXACTLY 1s (2-round fight)" || fail "fast schedule gap0 ($sched)"
# let the fight settle
fin="{}"
for i in $(seq 1 30); do
  sleep 1.5
  fin=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>JSON.stringify({ st:(d.battle||{}).status }))" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$fin" '"st":"finished"' && break
done
jhas "$fin" '"st":"finished"' && ok "battle: fast fight settled cleanly with the new pacing" || fail "battle: never finished ($fin)"
$AB screenshot "$SHOT-battle.png" >/dev/null 2>&1
errsB=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -6)
if [ -z "$errsB" ]; then ok "stage B: zero page errors"; else fail "stage B errors: $errsB"; fi

# ============================================================ STAGE C (upgrader)
# warm the route so the first POST isn't eaten by dev-server compilation
curl -s -o /dev/null -X POST "${BASE}/api/upgrader" -H 'Content-Type: application/json' -d '{}' 2>/dev/null || true
$AB close >/dev/null 2>&1 || true
sleep 1
# session cookie FIRST, then the page — otherwise the guest gate renders
$AB open "$BASE/" >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
$AB open "$BASE/upgrader" >/dev/null
# wait for the upgrader to actually hydrate (spin button + stake tiles present)
ready="false"
for i in $(seq 1 20); do
  sleep 1
  ready=$($AB eval "JSON.stringify({ spin: !!document.querySelector('[data-testid=\"upgrader-spin\"]'), tiles: [...document.querySelectorAll('button')].some(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')) })" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$ready" '"spin":true' && jhas "$ready" '"tiles":true' && ready="true" && break
  ready="false"
done
[ "$ready" = "true" ] && ok "upgrader: page hydrated (spin + stake tiles)" || fail "upgrader: page never hydrated ($ready)"

# 4. the confetti canvas is DELETED from the wheel (only meaningful hydrated)
if [ "$ready" = "true" ]; then
  cnf=$(check "document.querySelectorAll('[data-testid=\"upgrader-wheel\"] canvas').length === 0 && !!document.querySelector('[data-testid=\"upgrader-wheel\"]')")
  [ "$cnf" = "true" ] && ok "upgrader: confetti/spark canvas deleted from the wheel" || fail "upgrader: canvas still present"
fi

# 5. select the cheapest skin → displays fill (regression)
sel=$($AB eval "(() => { const b=[...document.querySelectorAll('button')].filter(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')).sort((a,c)=>{const va=parseFloat(a.getAttribute('aria-label').match(/([\d.]+)\s*coins\)/)?.[1]??1e9), vc=parseFloat(c.getAttribute('aria-label').match(/([\d.]+)\s*coins\)/)?.[1]??1e9); return va-vc;})[0]; b?.click(); return b?'selected':'none'; })()" 2>/dev/null)
jhas "$sel" "selected" && ok "upgrader: cheapest skin selected" || fail "upgrader: no skin to select ($sel)"
sleep 2.2
od=$(check "!!document.querySelector('[data-testid=\"upgrader-outcome-display\"] img')")
[ "$od" = "true" ] && ok "upgrader: outcome display shows the potential prize" || fail "upgrader: outcome display empty"

# 6. install the audio probe (patched loop/start/stop + a createBufferSource
# counter for diagnosis + a ROUND-LONG poller that samples the alive count —
# robust against a slow first POST), arm the verdict timer, SPIN
probe=$($AB eval '(() => { const p = AudioBufferSourceNode.prototype; const b = (typeof AudioScheduledSourceNode !== "undefined") ? AudioScheduledSourceNode.prototype : p; if (!window.__audioProbe) { window.__audioProbe = true; window.__loopSrcs = new Set(); window.__cbsCount = 0; const d = Object.getOwnPropertyDescriptor(p, "loop"); if (!d) return "probe-descriptor-missing"; Object.defineProperty(p, "loop", { get() { return d.get.call(this); }, set(v) { if (v) window.__loopSrcs.add(this); d.set.call(this, v); } }); const startOwner = Object.getOwnPropertyDescriptor(p, "start") ? p : b; const stopOwner = Object.getOwnPropertyDescriptor(p, "stop") ? p : b; const st = Object.getOwnPropertyDescriptor(startOwner, "start"); const sp = Object.getOwnPropertyDescriptor(stopOwner, "stop"); if (!st || !sp) return "probe-descriptor-missing"; Object.defineProperty(startOwner, "start", { value(...a) { this.__started = true; if (this.loop) window.__loopSrcs.add(this); return st.value.apply(this, a); } }); Object.defineProperty(stopOwner, "stop", { value(...a) { this.__stopped = true; return sp.value.apply(this, a); } }); const cbs = AudioContext.prototype.createBufferSource; AudioContext.prototype.createBufferSource = function(...a) { window.__cbsCount++; return cbs.apply(this, a); }; } return "probe-installed"; })()' 2>/dev/null)
jhas "$probe" "probe-installed" && ok "upgrader: audio probe installed" || fail "upgrader: probe ($probe)"
patched=$(check "(Object.getOwnPropertyDescriptor(AudioBufferSourceNode.prototype, 'loop')?.set?.toString() || '').includes('__loopSrcs')")
[ "$patched" = "true" ] && ok "upgrader: probe patch verified live (not vacuous)" || fail "upgrader: probe patch not applied"
selftest=$($AB eval '(() => { const c = new (window.AudioContext||window.webkitAudioContext)(); const s = c.createBufferSource(); s.loop = true; s.start(); const out = JSON.stringify({ started: !!s.__started, inSet: window.__loopSrcs.has(s) }); try { s.stop(); } catch {} c.close(); return out; })()' 2>/dev/null | sed 's/\\//g' | tail -1)
jhas "$selftest" '"started":true' && jhas "$selftest" '"inSet":true' && ok "upgrader: probe self-test — a live loop IS counted" || fail "upgrader: probe self-test ($selftest)"
armed=$($AB eval '(() => { const btn=document.querySelector("[data-testid=\"upgrader-spin\"]"); if(!btn) return "no-btn"; window.__t178={t0:0,landed:0,maxAlive:0,cbsAtMax:0}; btn.addEventListener("click",()=>{window.__t178.t0=Date.now();},{capture:true,once:true}); window.__t178t=setInterval(()=>{ const st=window.__t178; const r=document.querySelector("[data-testid=\"upgrader-result\"]"); if(st.t0&&!st.landed&&r&&r.textContent.trim().length>3) st.landed=Date.now()-st.t0; const alive=[...(window.__loopSrcs||[])].filter((s)=>s.__started&&s.loop&&!s.__stopped).length; if(st.t0&&!st.landed&&alive>st.maxAlive){ st.maxAlive=alive; st.cbsAtMax=window.__cbsCount; } },200); return "armed"; })()' 2>/dev/null)
jhas "$armed" "armed" && ok "upgrader: verdict probe armed" || fail "upgrader: probe ($armed)"
$AB find first "[data-testid=\"upgrader-spin\"]" click >/dev/null 2>&1
sleep 1.5

# 7. MID-ROUND: the stake display still shows the skin (sampled at t+1.5s and
# via the poller; the whoosh MAX comes from the poller after the verdict)
midStake=$(check "!document.querySelector('[data-testid=\"upgrader-stake-display\"]')?.textContent.includes('shows up here BIG')")
[ "$midStake" = "true" ] && ok "upgrader: YOUR STAKE keeps the skin through the whole round" || fail "upgrader: stake display emptied mid-round"
t12=$(check "[...document.querySelectorAll('[data-testid=\"upgrader-wheel\"] svg g')].some(g => (g.getAttribute('style')||'').includes('12000ms'))")
[ "$t12" = "true" ] && ok "upgrader: wheel transition is 12000ms (regression)" || fail "upgrader: 12s transition lost"

# 8. the verdict
sleep 13
res=$($AB eval "JSON.stringify(window.__t178||{})" 2>/dev/null | head -1)
landed=$(echo "$res" | python3 -c "
import json,sys
raw=sys.stdin.read().strip()
try: d=json.loads(json.loads(raw)) if raw.startswith('\"') else json.loads(raw)
except Exception: d={}
print(d.get('landed',-1))
")
if [ "$landed" -ge 11500 ] 2>/dev/null; then ok "upgrader: verdict landed at ${landed}ms (12s spin intact)"; else fail "upgrader: verdict timing ${landed}ms"; fi
whoosh=$($AB eval "JSON.stringify({ maxAlive: (window.__t178||{}).maxAlive ?? -1, cbs: window.__cbsCount ?? -1 })" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "whoosh probe: $whoosh"
jhas "$whoosh" '"maxAlive":[1-9]' && ok "upgrader: the round-long spin sound PLAYED through the round (poller max alive ≥ 1)" || fail "upgrader: whoosh never started ($whoosh)"
alivePost=$($AB eval '[...(window.__loopSrcs || [])].filter((s) => s.__started && s.loop && !s.__stopped).length' 2>/dev/null | rg -o "[0-9]+" | head -1)
alivePost="${alivePost:-?}"
[ "$alivePost" = "0" ] && ok "upgrader: the spin sound ENDED at the final result (alive loops: 0)" || fail "upgrader: whoosh still alive after verdict ($alivePost)"
endStake=$(check "!document.querySelector('[data-testid=\"upgrader-stake-display\"]')?.textContent.includes('shows up here BIG')")
[ "$endStake" = "true" ] && ok "upgrader: YOUR STAKE still holds the skin at end of game (loss keeps it / win shows the won skin)" || fail "upgrader: stake display empty after verdict"
verdict=$($AB eval "(() => { const o=document.querySelector('[data-testid=\"upgrader-outcome-display\"]'); const s=document.querySelector('[data-testid=\"upgrader-stake-display\"]'); return JSON.stringify({ outcome: o?o.textContent.slice(0,80):'', won: !!(s&&s.textContent.toLowerCase().includes('won')), staked: !!(s&&!s.textContent.includes('shows up here BIG')) }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "verdict state: $verdict"
if jhas "$verdict" '"won":true'; then
  ok "upgrader: WIN path — the stake display became the WON skin (chip shown)"
else
  echo "note: round was a loss (real odds) — the win-path chip is asserted by code review + the loss path holds the stake"
  jhas "$verdict" '"staked":true' && ok "upgrader: LOSS path — the staked skin stays on the table" || fail "upgrader: stake vanished ($verdict)"
fi

# 9. fresh pick → "Potential upgrade" resets (nothing until picked)
sel2=$($AB eval "(() => { const b=[...document.querySelectorAll('button')].filter(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')&&x.getAttribute('aria-pressed')!=='true').sort((a,c)=>{const va=parseFloat(a.getAttribute('aria-label').match(/([\d.]+)\s*coins\)/)?.[1]??1e9), vc=parseFloat(c.getAttribute('aria-label').match(/([\d.]+)\s*coins\)/)?.[1]??1e9); return va-vc;})[0]; b?.click(); return b?'picked':'none'; })()" 2>/dev/null)
jhas "$sel2" "picked" && ok "upgrader: a new skin picked for the fresh round" || fail "upgrader: no skin left to pick ($sel2)"
sleep 1.2
reset=$($AB eval "(() => { const o=document.querySelector('[data-testid=\"upgrader-outcome-display\"]'); const r=document.querySelector('[data-testid=\"upgrader-result\"]'); return JSON.stringify({ potential: /potential upgrade/i.test(o?o.textContent:''), staleResult: /result\s*—/i.test(o?o.textContent:''), banner: r?r.textContent.trim().length:0 }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "reset check: $reset"
jhas "$reset" '"potential":true' && jhas "$reset" '"staleResult":false' && jhas "$reset" '"banner":0' && ok "upgrader: Potential upgrade RESET — old verdict gone, nothing until picked" || fail "upgrader: stale verdict persisted ($reset)"
$AB screenshot "$SHOT-upgrader.png" >/dev/null 2>&1

# console + page errors for stage C
errsC=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -6)
if [ -z "$errsC" ]; then ok "stage C: zero page errors"; else fail "stage C errors: $errsC"; fi

# cleanup
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open about:blank >/dev/null 2>&1 || true

[ "$FAILED" = "0" ] && echo "== E2E t178: ALL PASS ==" || echo "== E2E t178: FAILURES =="
exit $FAILED
