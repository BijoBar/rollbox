#!/usr/bin/env python3
"""Task 76 verification — USER CASES RB-101..RB-109 import + CENT-PRECISE economy.

Static checks (Float columns, the user-cases overlay, the cases.ts merge, the
skin-images merge, cent-precise formatters/splits/routes, the editor dump) +
a live server smoke against :3000: open 20x RB-102 and assert the 85%-chance
0.19-coin item credits EXACTLY 0.19 (no integer truncation anywhere in the
charge/credit/ledger/drop chain). Runs against the dev server on :3000.
"""
import json
import os
import sqlite3
import sys
import time

import requests

BASE = "http://localhost:3000"
DB = "db/custom.db"
PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, ok: bool, extra: str = "") -> None:
    (PASS if ok else FAIL).append(name + (f" — {extra}" if (extra and not ok) else ""))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if (extra and not ok) else ""))


def read(*parts: str) -> str:
    with open(os.path.join(*parts), encoding="utf-8") as f:
        return f.read()


# ---------------- static: schema Float columns ----------------
con = sqlite3.connect(DB)
schema_expect = [
    ("Player", "balance"), ("Player", "depositLimit"),
    ("Battle", "entry"), ("Battle", "potTotal"),
    ("Ledger", "amount"), ("Ledger", "balanceAfter"),
    ("InventoryItem", "value"), ("Drop", "value"), ("Counter", "value"),
]
for table, col in schema_expect:
    row = con.execute(f'PRAGMA table_info("{table}")').fetchall()
    ctype = next((r[2] for r in row if r[1] == col), None)
    check(f"schema {table}.{col} is REAL/Float", ctype in ("REAL", "FLOAT", "DOUBLE"), f"got {ctype}")

# ---------------- static: user-cases overlay ----------------
uc = read("src/lib/user-cases.ts")
for code in [f"RB-10{i}" for i in range(1, 10)]:
    check(f"user-cases.ts contains {code}", f'code: "{code}"' in uc)
check("user-cases.ts keeps the cent value 8.85 (P250 Asiimov BS)", "value: 8.85" in uc)
check("user-cases.ts keeps the cent value 0.19 (Dual Berettas Cartel WW)", "value: 0.19" in uc)
check("user-cases.ts carries wear pins (wear: \"WW\")", 'wear: "WW"' in uc)
check("user-cases.ts stickers have no wear (Sticker | Dragon item line)", '{ skinId: "sticker-dragon", weight: 35, value: 0.1 }' in uc)

cases_src = read("src/lib/cases.ts")
check("cases.ts merges USER_CASES over GEN_CASES by code", "USER_CASE_BY_CODE" in cases_src)
check("cases.ts merges USER_SKINS into SKINS", "{ ...GEN_SKINS, ...USER_SKINS }" in cases_src)
check("cases.ts formatCoins is cent-precise", "Math.round(n * 100) / 100" in cases_src)
skin_images = read("src/lib/skin-images.ts")
check("skin-images.ts merges USER_SKIN_IMAGES", "...USER_SKIN_IMAGES" in skin_images)
builder = read("scripts/build-content.mjs")
check("build-content.mjs emit keeps the user-images merge", "...USER_SKIN_IMAGES" in builder)

battles_src = read("src/lib/battles.ts")
check("battles.ts sharedSplit splits in integer cents", "Math.round(pot * 100)" in battles_src)
gbattles_src = read("src/lib/server/gbattles.ts")
check("gbattles.ts pays cent-precise takes", 'Math.round((take[seat.key] ?? 0) * 100) / 100' in gbattles_src)
prof_src = read("src/app/api/profile/battles/route.ts")
check("profile/battles keeps cent-precise takes", 'Math.round((take[player.id] ?? 0) * 100) / 100' in prof_src)
selfcare_src = read("src/app/api/settings/selfcare/route.ts")
check("selfcare deposit amount is cent-precise", "Math.round(Number(body.amount ?? 0) * 100) / 100" in selfcare_src)
drops_dialog = read("src/components/rollbox/CaseDropsDialog.tsx")
check("CaseDropsDialog uses formatOdds (tiny odds visible)", "formatOdds(pct)" in drops_dialog)

# ---------------- static: editor dump mirrors the user cases ----------------
dump = json.loads(read("scripts/cases-dump.json"))
dump_cases = dump.get("cases", dump if isinstance(dump, list) else [])
rb101 = next((c for c in dump_cases if c.get("code") == "RB-101"), None)
if rb101:
    check("editor dump: RB-101 price 12", rb101.get("price") == 12, f"got {rb101.get('price')}")
    it0 = (rb101.get("items") or [{}])[0]
    check("editor dump: RB-101 first item value 8.85", it0.get("value") == 8.85 and it0.get("valueOverride") == 8.85, f"got {it0.get('value')}/{it0.get('valueOverride')}")
else:
    check("editor dump contains RB-101", False)

# ---------------- live: cent-precise open flow ----------------
PID = "p_t76cents"
con.execute('DELETE FROM "Drop" WHERE playerId = ?', (PID,))
con.execute("DELETE FROM Ledger WHERE playerId = ?", (PID,))
con.execute(
    "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
    "VALUES (?, 'steam', 't76-cents-steamid', 'T76 Cents', 500.5, 0, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
    (PID,),
)
con.commit()
stored = con.execute("SELECT balance FROM Player WHERE id = ?", (PID,)).fetchone()[0]
check("Player.balance stores a FLOAT balance (500.5)", abs(stored - 500.5) < 1e-9, f"got {stored}")

from hmac import new as hmac_new
import base64
import hashlib


def mint(pid: str) -> str:
    body = base64.urlsafe_b64encode(json.dumps({"pid": pid, "exp": int(time.time() * 1000) + 86400000},
                                               separators=(",", ":")).encode()).decode().rstrip("=")
    sig = hmac_new("rollbox-dev-secret".encode(), body.encode(), hashlib.sha256).digest()
    return body + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")


cookies = {"rb_session": mint(PID)}

# RB-102 Printstream Cartel: price 6, the 85% item is Dual Berettas Cartel WW = 0.19
r = requests.post(f"{BASE}/api/open", json={"caseId": "printstream-cartel", "count": 20}, cookies=cookies, timeout=60)
check("open 20x RB-102 accepted", r.status_code == 200, f"status {r.status_code} {r.text[:120]}")
data = r.json() if r.status_code == 200 else {}
credited = data.get("credited")
check("open credited is cent-precise (fractional)", isinstance(credited, (int, float)) and abs(credited - round(credited)) > 1e-6, f"credited={credited}")
check("charged = 120 (20 x 6)", data.get("charged") == 120, f"got {data.get('charged')}")

# Task 78: the win is PARKED at the click — nothing credited/published yet
bal_parked = con.execute("SELECT balance FROM Player WHERE id = ?", (PID,)).fetchone()[0]
check("Task78: balance after open = 500.5 - 120 (win parked, NOT credited)", abs(bal_parked - (500.5 - 120)) < 1e-6, f"bal={bal_parked}")
check("Task78: response carries a pendingId", isinstance(data.get("pendingId"), str) and data["pendingId"].startswith("op_"), f"got {data.get('pendingId')}")
check("Task78: no Drop rows before the reveal claim", con.execute('SELECT COUNT(*) FROM "Drop" WHERE playerId = ?', (PID,)).fetchone()[0] == 0)

# Task 78: the reveal finished — claim, THEN the money/drops land
rc = requests.post(f"{BASE}/api/open/claim", json={"pendingId": data.get("pendingId")}, cookies=cookies, timeout=60)
check("claim accepted", rc.status_code == 200 and rc.json().get("claimed") is True, f"status {rc.status_code} {rc.text[:120]}")

drops = con.execute('SELECT value FROM "Drop" WHERE playerId = ? ORDER BY id', (PID,)).fetchall()
vals = [d[0] for d in drops]
check("20 drop rows recorded at claim", len(vals) == 20, f"got {len(vals)}")
cheap = [v for v in vals if abs(v - 0.19) < 1e-9]
check("the 85% item dropped with EXACTLY 0.19 value", len(cheap) >= 10, f"0.19-drops: {len(cheap)}")

sum_drops = sum(vals)
check("credited equals the sum of drop values (cent-exact)", abs(sum_drops - credited) < 1e-6, f"sum={sum_drops} credited={credited}")

bal = con.execute("SELECT balance FROM Player WHERE id = ?", (PID,)).fetchone()[0]
check("balance = 500.5 - 120 + credited (no truncation)", abs(bal - (500.5 - 120 + credited)) < 1e-6, f"bal={bal}")

led = con.execute("SELECT kind, amount, balanceAfter FROM Ledger WHERE playerId = ? ORDER BY id", (PID,)).fetchall()
kinds = [l[0] for l in led]
check("ledger: open_entry then open_win", kinds[:1] == ["open_entry"] and "open_win" in kinds, f"kinds={kinds[:4]}")
win_row = next((l for l in led if l[0] == "open_win"), None)
check("ledger open_win amount is cent-precise", win_row is not None and abs(win_row[1] - credited) < 1e-6, f"got {win_row[1] if win_row else None}")
check("ledger balanceAfter is cent-precise REAL", win_row is not None and abs(win_row[2] - bal) < 1e-6, f"got {win_row[2] if win_row else None}")

# ---------------- live: the case pages render the user content ----------------
home = requests.get(f"{BASE}/", timeout=60).text
check("homepage lists 'Asiimov Protocol'", "Asiimov Protocol" in home)
page = requests.get(f"{BASE}/case/printstream-cartel", timeout=60).text
check("/case/printstream-cartel renders 'Printstream Cartel'", "Printstream Cartel" in page)

# ---------------- scrub ----------------
for table in ('"Drop"', "Ledger", "OpenPending"):
    try:
        con.execute(f"DELETE FROM {table} WHERE playerId = ?", (PID,))
    except Exception:
        pass
con.execute("DELETE FROM Player WHERE id = ?", (PID,))
con.commit()
left = con.execute("SELECT COUNT(*) FROM Player WHERE id = ?", (PID,)).fetchone()[0]
check("DB scrubbed (test player + rows removed)", left == 0)
con.close()

print(f"\n== {len(PASS)} passed, {len(FAIL)} failed ==")
sys.exit(1 if FAIL else 0)
