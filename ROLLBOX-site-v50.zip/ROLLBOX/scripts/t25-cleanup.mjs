// Task 25 — cleanup the disposable UI test player completely
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
const PID = "p_t25ui";

const inv = await db.inventoryItem.deleteMany({ where: { playerId: PID } });
const led = await db.ledger.deleteMany({ where: { playerId: PID } });
const pend = await db.openPending.deleteMany({ where: { playerId: PID } });
const pl = await db.player.deleteMany({ where: { id: PID } });
console.log(`cleanup: inv=${inv.count} ledger=${led.count} pending=${pend.count} player=${pl.count}`);
const total = await db.player.count();
console.log(`players left: ${total}`);
await db.$disconnect();
