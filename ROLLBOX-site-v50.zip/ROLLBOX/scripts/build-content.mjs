// ============ ROLLBOX content builder ============
// Reads the official CS2 DB (skins.json + stickers.json + keychains.json +
// agents.json + patches.json) and real market prices (market.csgo.com) and
// generates:
//   1. src/lib/generated-cases.ts  — SKINS + CASES (20 themed + 9 farm cases)
//   2. src/lib/skin-images.ts      — skinId -> Steam CDN image (case skins only)
//   3. public/skins-catalog.json   — full catalog (skins, stickers, charms,
//                                    agents, patches) with category keys
import { readFileSync, writeFileSync, mkdirSync } from "fs";
import {
  THEMES,
  FARMS,
  FARM_COLORS,
  FARM_TAGLINE,
  FARM_ROSTERS,
  FARM_STICKER,
} from "./themes.mjs";

const DB = JSON.parse(readFileSync("/home/z/my-project/scripts/skins-db.json", "utf8"));
const STICKER_DB = JSON.parse(
  readFileSync("/home/z/my-project/scripts/stickers-db.json", "utf8")
);
const CHARM_DB = JSON.parse(
  readFileSync("/home/z/my-project/scripts/charms-db.json", "utf8")
);
const AGENT_DB = JSON.parse(
  readFileSync("/home/z/my-project/scripts/agents-db.json", "utf8")
);
const PATCH_DB = JSON.parse(
  readFileSync("/home/z/my-project/scripts/patches-db.json", "utf8")
);
const PRICES = JSON.parse(
  readFileSync("/home/z/my-project/scripts/csgotm-prices.json", "utf8")
);

// ---------- price aggregation ----------
const priceByHash = new Map();
for (const it of PRICES.items) {
  const p = parseFloat(it.price);
  if (Number.isFinite(p) && p > 0) priceByHash.set(it.market_hash_name, p);
}

const WEARS = [
  " (Battle-Scarred)",
  " (Well-Worn)",
  " (Field-Tested)",
  " (Minimal Wear)",
  " (Factory New)",
];

function priceFor(name) {
  let best = null;
  for (const w of WEARS) {
    const p = priceByHash.get(name + w);
    if (p && (best === null || p < best)) best = p;
  }
  const direct = priceByHash.get(name); // rare no-wear items
  if (direct && (best === null || direct < best)) best = direct;
  return best;
}

function directPrice(marketHash) {
  const p = priceByHash.get(marketHash);
  return p && p > 0 ? p : null;
}

// ---------- rarity / weapon mapping ----------
const RARITY_MAP = {
  "Consumer Grade": "consumer",
  "Industrial Grade": "consumer",
  "Mil-Spec Grade": "milspec",
  Restricted: "restricted",
  Classified: "classified",
  Covert: "covert",
  // gloves ship as "Extraordinary" in the API — treat as ★ Rare Special
  Extraordinary: "contraband",
  Contraband: "contraband",
};
const RARITY_FALLBACK_PRICE = {
  consumer: 0.1,
  milspec: 1,
  restricted: 4,
  classified: 15,
  covert: 60,
  contraband: 300,
};
// sticker/charm price estimates when the market has no listing
const MISC_FALLBACK_PRICE = {
  consumer: 0.03,
  milspec: 0.08,
  restricted: 0.4,
  classified: 1.5,
  covert: 8,
  contraband: 80,
};
const MISC_RARITY_MAP = {
  "Consumer Grade": "consumer",
  "Industrial Grade": "consumer",
  "High Grade": "milspec",
  Remarkable: "restricted",
  Exotic: "classified",
  Extraordinary: "covert",
  Contraband: "contraband",
  // agent character rarities (blue < purple < pink < red)
  Distinguished: "milspec",
  Exceptional: "restricted",
  Master: "classified",
  Superior: "covert",
};

// ---------- user-specified catalog categories ----------
// The catalog filter groups items exactly per user spec: Knives / Gloves /
// Rifles / Pistols / SMGs / Heavy / Agents / Stickers / Charms / Patches.
const WEAPON_CLASS_MAP = {
  // Rifles (user's exact list)
  "AK-47": "rifles", "AUG": "rifles", "AWP": "rifles", "FAMAS": "rifles",
  "G3SG1": "rifles", "Galil AR": "rifles", "M4A1-S": "rifles", "M4A4": "rifles",
  "SCAR-20": "rifles", "SG 553": "rifles", "SSG 08": "rifles",
  // Pistols (user's exact list)
  "CZ75-Auto": "pistols", "Desert Eagle": "pistols", "Dual Berettas": "pistols",
  "Five-SeveN": "pistols", "Glock-18": "pistols", "P2000": "pistols",
  "P250": "pistols", "R8 Revolver": "pistols", "Tec-9": "pistols", "USP-S": "pistols",
  // SMGs (user's exact list)
  "MAC-10": "smgs", "MP5-SD": "smgs", "MP7": "smgs", "MP9": "smgs",
  "P90": "smgs", "PP-Bizon": "smgs", "UMP-45": "smgs",
  // Heavy (user's exact list)
  "M249": "heavy", "MAG-7": "heavy", "Negev": "heavy", "Nova": "heavy",
  "Sawed-Off": "heavy", "XM1014": "heavy",
  // Equipment — Zeus x27 gets its own category (user-confirmed)
  "Zeus x27": "zeus",
};
const MISC_CAT = { sticker: "stickers", charm: "charms", agent: "agents", patch: "patches" };

// weapon display name -> our 13 SVG art kinds (fallback rendering only)
const KNIFE_ART = {
  Karambit: "karambit", "Talon Knife": "karambit", "Skeleton Knife": "karambit",
  "Shadow Daggers": "karambit", "Kunai Knife": "karambit",
  "M9 Bayonet": "bayonet", Bayonet: "bayonet", "Butterfly Knife": "butterfly",
  "Stiletto Knife": "bayonet", "Huntsman Knife": "bayonet", "Falchion Knife": "bayonet",
  "Bowie Knife": "bayonet", "Flip Knife": "bayonet", "Gut Knife": "bayonet",
  "Survival Knife": "bayonet", "Paracord Knife": "bayonet", "Nomad Knife": "bayonet",
  "Kukri Knife": "bayonet",
};

const ART_KIND = {
  "AK-47": "ak", "M4A4": "m4", "M4A1-S": "m4", "AWP": "awp",
  "Galil AR": "galil", "FAMAS": "galil", "SG 553": "galil", "AUG": "m4",
  "SSG 08": "awp", "SCAR-20": "awp", "G3SG1": "awp",
  "P90": "p90", "MAC-10": "mp9", "MP9": "mp9", "MP7": "mp9", "MP5-SD": "mp9",
  "UMP-45": "mp9", "PP-Bizon": "mp9",
  "Desert Eagle": "deagle", "R8 Revolver": "deagle",
  "Glock-18": "glock", "Tec-9": "glock", "Five-SeveN": "glock",
  "CZ75-Auto": "glock", "Dual Berettas": "glock",
  "USP-S": "usp", "P2000": "usp", "P250": "p250",
  "Nova": "ak", "XM1014": "ak", "MAG-7": "ak", "M249": "galil", "Negev": "galil",
  ...KNIFE_ART,
};

function artFor(apiWeaponName, category) {
  if (category === "Gloves") return "gloves";
  if (category === "Sticker") return "sticker";
  if (category === "Charm") return "charm";
  return ART_KIND[apiWeaponName] ?? "ak";
}

function slug(s) {
  return s
    .toLowerCase()
    .replace(/★/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

// ---------- build catalog entries ----------
const idSeen = new Map();
function ensureUnique(base) {
  const n = (idSeen.get(base) ?? 0) + 1;
  idSeen.set(base, n);
  return n === 1 ? base : `${base}-${n}`;
}

const usedIds = new Set();
const catalog = [];

DB.forEach((s, idx) => {
  const cat = s.category?.name === "Knives" ? "Knife" : s.category?.name ?? "";
  // ★ knives & gloves are always ★ Rare Special on ROLLBOX (site design)
  const isStarItem = cat === "Knife" || cat === "Gloves";
  const rarity = isStarItem
    ? "contraband"
    : RARITY_MAP[s.rarity?.name ?? "Consumer Grade"] ?? "consumer";
  let price = priceFor(s.name);
  let estimated = false;
  if (!price) {
    // star items: estimate from category multiplier only (avoid contraband x250 blowup)
    const base = isStarItem ? 1 : RARITY_FALLBACK_PRICE[rarity];
    price = base * (categoryMul(s) ?? 1);
    estimated = true;
  }
  const weaponName = s.weapon?.name ?? (cat === "Gloves" ? "Gloves" : "Knife");
  const catKey =
    cat === "Knife" ? "knives"
    : cat === "Gloves" ? "gloves"
    : WEAPON_CLASS_MAP[weaponName] ?? null; // anything outside the category map
  const id = ensureUnique(slug(s.name));
  usedIds.add(id);
  catalog.push({
    id,
    name: s.name,
    weapon: weaponName,
    art: artFor(weaponName, cat),
    rarity,
    price: Math.round(price * 100) / 100,
    estimated,
    value: Math.max(1, Math.round(price * 10)),
    image: s.image,
    apiId: s.id,
    category: cat,
    type: "skin",
    catKey,
    wear: undefined,
    _p: price,
  });
});

// ---------- stickers, charms, agents + patches into the catalog ----------
const MISC_META = {
  sticker: { weapon: "Sticker", category: "Sticker" },
  charm: { weapon: "Charm", category: "Charm" },
  agent: { weapon: "Agent", category: "Agent" },
  patch: { weapon: "Patch", category: "Patch" },
};

function pushMisc(db, kind) {
  const meta = MISC_META[kind];
  for (const s of db) {
    const name = s.name;
    if (!name) continue;
    const rarity = MISC_RARITY_MAP[s.rarity?.name ?? "High Grade"] ?? "milspec";
    const marketHash = s.market_hash_name ?? name;
    let price = directPrice(marketHash);
    let estimated = false;
    if (!price) {
      price = MISC_FALLBACK_PRICE[rarity];
      estimated = true;
    }
    const id = ensureUnique(slug(name));
    usedIds.add(id);
    catalog.push({
      id,
      name,
      weapon: meta.weapon,
      art: kind,
      rarity,
      price: Math.round(price * 100) / 100,
      estimated,
      value: Math.max(1, Math.round(price * 10)),
      image: s.image,
      apiId: s.id,
      category: meta.category,
      type: kind,
      catKey: MISC_CAT[kind],
      wear: undefined,
      _p: price,
    });
  }
}

pushMisc(STICKER_DB, "sticker");
pushMisc(CHARM_DB, "charm");
pushMisc(AGENT_DB, "agent");
pushMisc(PATCH_DB, "patch");

// user-specified rarity adjustments: the Howl set (skin + Howling Dawn sticker)
// moves from Contraband to Covert — after stickers are loaded
for (const c of catalog) {
  if (c.name === "M4A4 | Howl" || c.name === "Sticker | Howling Dawn") {
    c.rarity = "covert";
  }
}

function categoryMul(s) {
  const c = s.category?.name;
  if (c === "Knives") return 250;
  if (c === "Gloves") return 180;
  return 1;
}

const byId = new Map(catalog.map((c) => [c.id, c]));

// ---------- user-specified farm rosters (Farm Gloves / Farm Knives) ----------
// Re-prices each roster item to its exact exterior (wear) market price, tags
// the wear, and pins the "Sticker | Gloves On" sticker as the 99.55% farm item.
const rosterByFarm = new Map(); // farmId -> { cheap, premium, farmPct }

for (const [farmId, roster] of Object.entries(FARM_ROSTERS)) {
  const premium = roster.items.map((raw) => {
    const name = typeof raw === "string" ? raw : raw.name;
    const wear = typeof raw === "string" ? roster.wear : raw.wear;
    const entry =
      typeof raw === "object" && raw.vanilla
        ? catalog.find((c) => c.name === raw.vanilla) // vanilla knife (no paint)
        : catalog.find((c) => c.name === "★ " + name);
    if (!entry) throw new Error(`farm roster ${farmId}: item not found in DB: ${name}`);
    if (wear) {
      const p = directPrice(`★ ${name} (${wear})`) ?? entry._p;
      entry._p = p;
      entry.price = Math.round(p * 100) / 100;
      entry.value = Math.max(1, Math.round(p * 10));
      entry.wear = wear;
    }
    return entry;
  });
  if (premium.length !== 9) {
    throw new Error(`farm roster ${farmId}: expected 9 premium items, got ${premium.length}`);
  }
  const stickerEntry = catalog.find((c) => c.name === FARM_STICKER);
  if (!stickerEntry) throw new Error(`farm roster ${farmId}: sticker not found: ${FARM_STICKER}`);
  rosterByFarm.set(farmId, { cheap: stickerEntry, premium, farmPct: 99.55 });
}

// ---------- case assembly helpers ----------
const globallyUsed = new Set();

function themePool(theme) {
  return catalog.filter((c) => {
    if (theme.category && c.category !== theme.category) return false;
    if (theme.weapon && c.weapon !== theme.weapon) return false;
    if (theme.must?.includes(c.name)) return true;
    if (theme.keywords) return theme.keywords.some((k) => c.name.toLowerCase().includes(k));
    return true; // weapon/category-only theme
  });
}

function pickBand(pool, lo, hi, n, fallbackPool) {
  let src = pool.filter((c) => c._p >= lo && c._p < hi);
  if (src.length < n && fallbackPool) {
    const extra = fallbackPool.filter(
      (c) => c._p >= lo && c._p < hi && !src.includes(c)
    );
    src = [...src, ...extra];
  }
  src = src.sort((a, b) => b._p - a._p);
  // prefer skins not already used in other cases; fall back to reused ones
  const fresh = src.filter((c) => !globallyUsed.has(c.id));
  const stale = src.filter((c) => globallyUsed.has(c.id));
  const ordered = [...fresh, ...stale];
  if (ordered.length === 0) return [];
  const out = [];
  for (let i = 0; i < n; i++) {
    const step = ordered.length / n;
    const pick = ordered[Math.min(ordered.length - 1, Math.floor(i * step))];
    if (pick && !out.includes(pick)) out.push(pick);
    else {
      const alt = ordered.find((c) => !out.includes(c));
      if (!alt) break;
      out.push(alt);
    }
  }
  return out;
}

function buildThemedCase(theme, code) {
  const pool = themePool(theme).sort((a, b) => b._p - a._p);
  if (pool.length < 4) throw new Error(`theme ${theme.id}: pool too small (${pool.length})`);
  const jackpot = pool[0];
  const rest = pool.slice(1);
  // mid/cheap bands fall back to the global catalog when the themed pool has
  // nothing in those price ranges (e.g. all-Doppler knives) — keeps EV sane.
  const globalPool = [...catalog].sort((a, b) => b._p - a._p);
  let chosen = [
    ...pickBand(rest, 20, Infinity, 3), // high — themed only
    ...pickBand(rest, 5, 20, 3, globalPool), // mid
    ...pickBand(rest, 0.05, 5, 3, globalPool), // cheap
  ];
  // drop same-name duplicates (e.g. two Doppler phases share one display name)
  chosen = chosen.filter(
    (c, i, arr) => arr.findIndex((x) => x.name === c.name) === i
  );
  // top up to 9 from the pool by descending price if bands came short
  for (const c of rest) {
    if (chosen.length >= 9) break;
    if (c !== jackpot && !chosen.some((x) => x.name === c.name)) chosen.push(c);
  }
  chosen = chosen.filter((c) => c === jackpot || c.name !== jackpot.name);
  chosen = chosen.slice(0, 9);
  chosen.push(jackpot);
  chosen.sort((a, b) => a._p - b._p);
  chosen.forEach((c) => globallyUsed.add(c.id));
  return chosen;
}

// weights for themed cases: jackpot pinned at 0.4%, rest inverse-price^0.85
function themedWeights(items) {
  const rest = items.slice(0, -1);
  const raw = rest.map((c) => Math.pow(1 / c._p, 0.85));
  const sum = raw.reduce((s, x) => s + x, 0);
  return [...rest.map((_, i) => (raw[i] / sum) * 99.6), 0.4];
}

function buildFarmCase(farm) {
  const roster = rosterByFarm.get(farm.id);
  if (roster) return roster;
  let pool;
  if (farm.category) {
    pool = catalog.filter((c) => c.category === farm.category);
  } else {
    pool = catalog.filter((c) => c.weapon === farm.weapon);
  }
  const sorted = [...pool].sort((a, b) => a._p - b._p);
  const cheap = sorted.reduce((best, c) =>
    Math.abs(c._p - 0.2) < Math.abs(best._p - 0.2) ? c : best
  );
  const premiumSrc = sorted.filter((c) => c !== cheap && c._p >= 20);
  const premiumFill = sorted.filter((c) => c !== cheap && c._p < 20).sort((a, b) => b._p - a._p);
  const premium = [];
  const seenNames = new Set();
  for (const c of [...premiumSrc].sort((a, b) => b._p - a._p)) {
    if (premium.length >= 9) break;
    if (seenNames.has(c.name)) continue; // skip same-name phases
    seenNames.add(c.name);
    premium.push(c);
  }
  for (const c of premiumFill) {
    if (premium.length >= 9) break;
    if (seenNames.has(c.name)) continue;
    seenNames.add(c.name);
    premium.push(c);
  }
  premium.sort((a, b) => a._p - b._p); // ascending: 9th = biggest jackpot
  return { cheap, premium, farmPct: 99.5 };
}

/**
 * Farm weights: farm item pinned at `farmPct` (99.5 or 99.55), the remainder
 * distributed inversely by price among the premium items. Weights are rounded
 * to 4 decimals and the (tiny) rounding drift is folded into the largest
 * premium weight so the table sums to EXACTLY 100.
 */
function farmWeights(premium, farmPct) {
  const rest = Math.round((100 - farmPct) * 10000) / 10000;
  const inv = premium.map((c) => 1 / c._p);
  const sum = inv.reduce((s, x) => s + x, 0);
  const rounded = premium.map((_, i) =>
    Math.round(((inv[i] / sum) * rest) * 10000) / 10000
  );
  if (rounded.length) {
    const drift = Math.round((rest - rounded.reduce((s, x) => s + x, 0)) * 10000) / 10000;
    const maxIdx = rounded.indexOf(Math.max(...rounded));
    rounded[maxIdx] = Math.round((rounded[maxIdx] + drift) * 10000) / 10000;
  }
  return [farmPct, ...rounded];
}

// ---------- price ladder ----------
const LADDER = [
  3, 5, 8, 10, 15, 20, 25, 30, 40, 50, 60, 80, 100, 125, 150, 200, 250, 300,
  400, 500, 650, 800, 1000, 1250, 1500, 2000, 2500, 3000, 4000, 5000, 6500,
  8000, 10000, 15000, 20000,
];
function nicePrice(ev) {
  const target = ev * 1.15;
  return LADDER.find((p) => p >= target) ?? Math.ceil(target);
}

function tierLabel(price, isFarm) {
  if (isFarm) return "FARM";
  if (price < 15) return "STARTER";
  if (price < 60) return "RARE";
  if (price < 200) return "ELITE";
  if (price < 700) return "EXOTIC";
  return "LEGENDARY";
}

// ---------- assemble ----------
const CASES = [];
const ALL_SKIN_IDS = new Set();

const RARITY_META_HEX = {
  consumer: "#b0c3d9",
  milspec: "#4b69ff",
  restricted: "#8847ff",
  classified: "#d32ce6",
  covert: "#eb4b4b",
  contraband: "#ffd700",
};

function pushCase(def, items, weights) {
  const ev = items.reduce((s, c, i) => s + (weights[i] / 100) * c.value, 0);
  let price;
  if (def.kind === "farm") {
    // farm economics: spin price sits just above the farm item value, NOT at EV
    const target = Math.max(3, items[0].value * 1.6);
    price = LADDER.find((p) => p >= target) ?? Math.ceil(target);
  } else {
    price = nicePrice(ev);
  }
  CASES.push({
    ...def,
    price,
    tierLabel: tierLabel(price, def.kind === "farm"),
    ev: Math.round(ev * 100) / 100,
    items: items.map((c, i) => ({ skinId: c.id, weight: Math.round(weights[i] * 10000) / 10000 })),
  });
  items.forEach((c) => ALL_SKIN_IDS.add(c.id));
}

// regular case codes RB-101.., farm codes RB-201..
THEMES.forEach((theme, i) => {
  const items = buildThemedCase(theme, i);
  const weights = themedWeights(items);
  pushCase(
    {
      id: theme.id,
      code: `RB-${101 + i}`,
      name: theme.name,
      subtitle: theme.tagline,
      kind: "standard",
      tierColor: theme.colors[0],
      tierColor2: theme.colors[1],
    },
    items,
    weights
  );
});

FARMS.forEach((farm, i) => {
  const { cheap, premium, farmPct } = buildFarmCase(farm);
  const weights = farmWeights(premium, farmPct);
  pushCase(
    {
      id: farm.id,
      code: `RB-${201 + i}`,
      name: farm.name,
      subtitle: FARM_TAGLINE,
      kind: "farm",
      tierColor: FARM_COLORS[0],
      tierColor2: FARM_COLORS[1],
    },
    [cheap, ...premium],
    weights
  );
});

// ---------- emit generated-cases.ts ----------
const skinEntries = [...ALL_SKIN_IDS]
  .map((id) => byId.get(id))
  .filter(Boolean)
  .map((c) => {
    const rm = RARITY_META_HEX[c.rarity];
    const wearPart = c.wear ? `, wear: ${JSON.stringify(c.wear)}` : "";
    return `  "${c.id}": { id: ${JSON.stringify(c.id)}, name: ${JSON.stringify(c.name)}, weapon: ${JSON.stringify(c.art)} as WeaponKind, rarity: ${JSON.stringify(c.rarity)}, value: ${c.value}, colors: ["${rm}", "#14101f"]${wearPart} },`;
  })
  .join("\n");

const caseEntries = CASES.map(
  (c) => `  {
    id: ${JSON.stringify(c.id)},
    code: ${JSON.stringify(c.code)},
    name: ${JSON.stringify(c.name)},
    subtitle: ${JSON.stringify(c.subtitle)},
    kind: ${JSON.stringify(c.kind)},
    tierLabel: ${JSON.stringify(c.tierLabel)},
    price: ${c.price},
    tierColor: ${JSON.stringify(c.tierColor)},
    tierColor2: ${JSON.stringify(c.tierColor2)},
    items: [
${c.items.map((it) => `      { skinId: ${JSON.stringify(it.skinId)}, weight: ${it.weight} },`).join("\n")}
    ],
  },`
).join("\n");

const generated = `// ============ AUTO-GENERATED by scripts/build-content.mjs — do not edit by hand ============
// 20 themed cases + 9 farm cases built from the official CS2 skin database
// with real market prices (weights are inverse-price; farm = 99.5% + 0.5%).

import type { Rarity, WeaponKind } from "./cases";

export interface GenSkin {
  id: string;
  name: string;
  weapon: WeaponKind;
  rarity: Rarity;
  value: number;
  colors: [string, string];
  wear?: string;
}

export const GEN_SKINS: Record<string, GenSkin> = {
${skinEntries}
};

export interface GenCase {
  id: string;
  code: string;
  name: string;
  subtitle: string;
  kind: "standard" | "farm";
  tierLabel: string;
  price: number;
  tierColor: string;
  tierColor2: string;
  items: { skinId: string; weight: number }[];
}

export const GEN_CASES: GenCase[] = [
${caseEntries}
];
`;

writeFileSync("/home/z/my-project/src/lib/generated-cases.ts", generated);

// ---------- emit skin-images.ts (case skins only) ----------
const imgLines = [...ALL_SKIN_IDS]
  .map((id) => byId.get(id))
  .filter((c) => c && c.image)
  .map((c) => `  "${c.id}": ${JSON.stringify(c.image)},`)
  .join("\n");

writeFileSync(
  "/home/z/my-project/src/lib/skin-images.ts",
  `// ============ AUTO-GENERATED skin image hotlinks ============
// Official CS2 renders served from Valve's Steam CDN. Fallback SVG art applies
// when an entry is missing. Re-run scripts/build-content.mjs to regenerate.

export const SKIN_IMAGES: Record<string, string> = {
${imgLines}
};

export function skinImage(skinId: string): string | undefined {
  return SKIN_IMAGES[skinId];
}
`
);

// ---------- emit public/skins-catalog.json ----------
mkdirSync("/home/z/my-project/public", { recursive: true });
const catalogOut = catalog.map((c) => ({
  id: c.id,
  n: c.name,
  w: c.weapon,
  r: c.rarity,
  p: c.price,
  v: c.value,
  img: c.image,
  est: c.estimated ? 1 : undefined,
  ...(c.type !== "skin" ? { t: c.type } : {}),
  ...(c.catKey ? { cat: c.catKey } : {}),
  a: c.art,
}));
writeFileSync("/home/z/my-project/public/skins-catalog.json", JSON.stringify(catalogOut));

// ---------- odds validation (CRITICAL) ----------
// Mirrors formatOdds() in src/lib/cases.ts — no item may ever DISPLAY as 100%.
function oddsDisplay(p) {
  if (p >= 99.995) return "100";
  if (p > 99) return p.toFixed(2);
  if (p >= 10) return p.toFixed(0);
  if (p >= 1) return p.toFixed(1);
  if (p >= 0.1) return p.toFixed(2);
  if (p >= 0.01) return p.toFixed(3);
  return p.toFixed(4);
}
let oddsFailures = 0;
for (const c of CASES) {
  const total = c.items.reduce((s, i) => s + i.weight, 0);
  if (Math.abs(total - 100) > 0.02) {
    console.error(`ODDS FAIL ${c.code} '${c.name}': weights sum to ${total}`);
    oddsFailures++;
  }
  for (const it of c.items) {
    if (oddsDisplay((it.weight / total) * 100) === "100") {
      console.error(`ODDS FAIL ${c.code} '${c.name}': ${it.skinId} would display as 100%`);
      oddsFailures++;
    }
  }
}
console.log(
  oddsFailures
    ? `!!! ODDS VALIDATION FAILED: ${oddsFailures} problem(s)`
    : "ODDS VALIDATION PASSED — all weight tables sum to 100, no item displays as 100%"
);

// ---------- report ----------
console.log("=== CASES ===");
for (const c of CASES) {
  const top = byId.get(c.items[c.items.length - 1].skinId);
  const cheapItem = byId.get(c.items[0].skinId);
  console.log(
    `${c.code} ${c.name.padEnd(22)} ₡${String(c.price).padEnd(6)} EV ₡${String(c.ev).padEnd(8)} top: ${top.name} ($${top._p}) ${c.kind === "farm" ? `| farm item: ${cheapItem.name} ($${cheapItem._p}) @${c.items[0].weight}%` : ""}`
  );
}
console.log("\n=== FARM CASE DETAILS ===");
for (const c of CASES.filter((x) => x.kind === "farm")) {
  const parts = c.items.map((it) => {
    const s = byId.get(it.skinId);
    return `${s.name}${s.wear ? ` [${s.wear}]` : ""}($${s._p} @${it.weight}%)`;
  });
  console.log(`${c.name} ₡${c.price}:\n  ${parts.join("\n  ")}`);
}
console.log("\ncatalog entries:", catalogOut.length, " case skins:", ALL_SKIN_IDS.size);
console.log(
  "catalog breakdown:",
  "skins:", catalog.filter((c) => c.type === "skin").length,
  "stickers:", catalog.filter((c) => c.type === "sticker").length,
  "charms:", catalog.filter((c) => c.type === "charm").length,
  "agents:", catalog.filter((c) => c.type === "agent").length,
  "patches:", catalog.filter((c) => c.type === "patch").length
);
console.log(
  "category breakdown:",
  ["knives", "gloves", "rifles", "pistols", "smgs", "heavy", "zeus", "agents", "stickers", "charms", "patches"]
    .map((k) => `${k}: ${catalog.filter((c) => c.catKey === k).length}`)
    .join("  "),
  "| unclassed:", catalog.filter((c) => !c.catKey).length
);
const missingImg = [...ALL_SKIN_IDS].filter((id) => !byId.get(id)?.image);
console.log("case skins missing image:", missingImg.length, missingImg.slice(0, 5));
const est = catalogOut.filter((c) => c.est).length;
console.log("catalog prices estimated (no market data):", est);
