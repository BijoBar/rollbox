// ============ Task 27 CLI: bun scripts/reprice-steamanalyst.ts ============
// Manual runner for the unified-pricing crawl (the server also runs it
// automatically every 6h once a key exists). Reads the key from
// db/pricing-config.json (apiKey) or the STEAMANALYST_API_KEY env.
//
//   bun scripts/reprice-steamanalyst.ts            — one slice (free: up to the daily budget)
//   bun scripts/reprice-steamanalyst.ts 3000       — one slice capped at 3000 requests (paid tiers)
//   bun scripts/reprice-steamanalyst.ts --queue    — print the queue stats and exit

import { buildQueue, crawlSlice, loadPricingConfig } from "../src/lib/server/pricing-crawl";
import { unifiedCount, unifiedUpdatedAt } from "../src/lib/server/pricing";

const arg = process.argv[2] ?? "";

const cfg = loadPricingConfig();
console.log("== ROLLBOX unified pricing (steamanalyst.com / CSFLOAT) ==");
console.log("tier:", cfg.tier, "| key:", cfg.apiKey ? "present (" + cfg.apiKey.slice(0, 6) + "…)" : "MISSING");
console.log("table:", unifiedCount(), "real prices | last update:", unifiedUpdatedAt() ? new Date(unifiedUpdatedAt()).toISOString() : "never");

const queue = buildQueue();
console.log("queue:", queue.length, "names pending (priority: exchange shelf → cases/terminals → their StatTrak™/Souvenir → catalog weapons+agents → their variants)");
if (arg === "--queue") {
  for (const n of queue.slice(0, 40)) console.log("  -", n);
  process.exit(0);
}

if (!cfg.apiKey) {
  console.error("\nNO API KEY — paste your free steamanalyst.com key into db/pricing-config.json (apiKey)");
  console.error("Get one: https://www.steamanalyst.com → sign up → account dashboard → API.");
  process.exit(1);
}

const max = Number.parseInt(arg, 10);
const summary = await crawlSlice(Number.isFinite(max) && max > 0 ? { maxRequests: max } : undefined);

if (summary.skipped) {
  console.log("skipped:", summary.skipped);
  process.exit(0);
}
console.log("ran:", summary.ran, "| priced:", summary.priced, "| failed:", summary.failed);
console.log("budget left (rolling 24h):", Number.isFinite(summary.budgetLeft) ? summary.budgetLeft : "unlimited");
console.log("queue left:", summary.queueLeft);
if (summary.samplePriced?.length) {
  console.log("sample:");
  for (const s of summary.samplePriced) console.log("  ✓", s);
}
if (summary.error) console.error("last error:", summary.error);
console.log("table now:", unifiedCount(), "real prices");
console.log("\nnext step: bun scripts/apply-unified-prices.ts — migrate the whole site onto the new prices");
