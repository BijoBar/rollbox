#!/usr/bin/env bash
# Task 41 E2E v2 — INVENTORY drawer: skin tiles must be SQUARE & symmetric
# (no longer stretched to the bottom of the screen). Deterministic: inject
# inventory snapshots into localStorage, reload, open drawer, measure.
set -u
AB="agent-browser"
SHOT2="/home/z/my-project/download/task41-inventory-square.png"
SHOT8="/home/z/my-project/download/task41-inventory-8.png"

echo "=== open /skins ==="
$AB open http://localhost:3000/skins >/dev/null 2>&1
sleep 2.5

echo "=== inject 7 extra items (keep real gloves) ==="
$AB eval '(() => {
  const raw = JSON.parse(localStorage.getItem("rollbox-store"));
  const keep = raw.state.inventory.slice(0, 1);
  const mk = (i, n, w, r, v, img, a) => ({uid: "t41-" + i, id: "t41-" + i, n, w, r, p: v / 300, v, img, est: 1, a, at: Date.now()});
  const extra = [
    mk(1, "AK-47 | Redline (Field-Tested)", "AK-47", "classified", 21, "https://community.cloudflare.steamstatic.com/economy/image/-t41ak", "ak"),
    mk(2, "AWP | Asiimov (Field-Tested)", "AWP", "covert", 63, null, "awp"),
    mk(3, "Glock-18 | Water Elemental (Minimal Wear)", "Glock-18", "restricted", 9, null, "pistol"),
    mk(4, "Sticker | Katowice 2014 Titan (Holo)", "Sticker", "exotic", 281830, null, "sticker"),
    mk(5, "★ Moto Gloves | Spearmint (Battle-Scarred)", "★ Moto Gloves", "covert", 249, null, "gloves"),
    mk(6, "M4A1-S | Printstream (Factory New)", "M4A1-S", "covert", 92, null, "m4a1"),
    mk(7, "Desert Eagle | Blaze (Factory New)", "Desert Eagle", "restricted", 41, null, "pistol"),
  ];
  raw.state.inventory = [...keep, ...extra];
  localStorage.setItem("rollbox-store", JSON.stringify(raw));
  return "injected " + raw.state.inventory.length;
})()' 2>/dev/null | tail -1

echo "=== reload ==="
$AB open http://localhost:3000/skins >/dev/null 2>&1
sleep 2.5

echo "=== open drawer (wallet strip button) ==="
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("My Inventory")); b?.click(); return b ? "opened" : "BUTTON NOT FOUND"; })()' 2>/dev/null | tail -1
sleep 1.2

echo "=== geometry check (8 items) ==="
$AB eval '(() => {
  const dlg = document.querySelector("[role=\"dialog\"]");
  if (!dlg) return JSON.stringify({err: "no dialog"});
  const tiles = [...dlg.querySelectorAll("div[title]")];
  const grid = tiles[0]?.parentElement;
  const g = grid?.getBoundingClientRect();
  const r = tiles.slice(0, 8).map(t => { const b = t.getBoundingClientRect(); return [Math.round(b.width), Math.round(b.height), Math.round(b.bottom)]; });
  const sq = r.every(([w, h]) => Math.abs(w - h) <= 1);
  const gapOk = r.length >= 3 ? Math.abs((r[2][2] - r[0][2]) - (r[0][1] + 10)) <= 2 : true;
  const noOverlap = r.length >= 3 ? r[2][2] - r[0][2] >= r[0][1] : true;
  return JSON.stringify({
    count: tiles.length, tiles: r, square: sq, rowsAligned: gapOk, noOverlap,
    gridBottom: g ? Math.round(g.bottom) : null, gridScrollable: grid ? grid.scrollHeight > grid.clientHeight : null,
    vh: window.innerHeight, vw: window.innerWidth
  });
})()' 2>/dev/null | tail -1
$AB screenshot "$SHOT8" >/dev/null 2>&1

echo "=== sell one -> 7 items still square ==="
$AB eval '(() => { const dlg = document.querySelector("[role=\"dialog\"]"); const b = [...dlg.querySelectorAll("button")].find(x => x.textContent.startsWith("Sell ₡")); b?.click(); return b ? "sold" : "NOT FOUND"; })()' 2>/dev/null | tail -1
sleep 0.8
$AB eval '(() => {
  const dlg = document.querySelector("[role=\"dialog\"]");
  const tiles = [...dlg.querySelectorAll("div[title]")];
  const r = tiles.slice(0, 3).map(t => { const b = t.getBoundingClientRect(); return [Math.round(b.width), Math.round(b.height)]; });
  return JSON.stringify({count: tiles.length, square: r.every(([w, h]) => Math.abs(w - h) <= 1), r});
})()' 2>/dev/null | tail -1

echo "=== mobile 390 check ==="
$AB set viewport 390 844 >/dev/null 2>&1
sleep 0.8
$AB eval '(() => {
  const dlg = document.querySelector("[role=\"dialog\"]");
  const tiles = [...dlg.querySelectorAll("div[title]")];
  const r = tiles.slice(0, 2).map(t => { const b = t.getBoundingClientRect(); return [Math.round(b.width), Math.round(b.height)]; });
  return JSON.stringify({count: tiles.length, square: r.every(([w, h]) => Math.abs(w - h) <= 1), r, vw: window.innerWidth});
})()' 2>/dev/null | tail -1
$AB screenshot "/home/z/my-project/download/task41-inventory-mobile.png" >/dev/null 2>&1

echo "=== balance: $($AB eval "JSON.parse(localStorage.getItem('rollbox-store')).state.balance" 2>/dev/null | tail -1)"
echo "=== inv count: $($AB eval "JSON.parse(localStorage.getItem('rollbox-store')).state.inventory.length" 2>/dev/null | tail -1)"
