"""Task 63 probe — play a REAL 1v1 JACKPOT battle (global, DB-backed) and
record exactly what happens at the end:
  1. does the "Jackpot draw" reel open?
  2. what win-% does each player show, and does it match the drop totals?
  3. does the reel land + settle into the DONE verdict?
  4. where is the reel visually (full-page screenshot)?
  5. any client console errors?
"""
import json
import re
import subprocess
import sys
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = Path("/home/z/my-project/download/e2e-shots")
SHOTS.mkdir(parents=True, exist_ok=True)

# ---- mint ONE real DB session + clean the world ---------------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
out = subprocess.run(
    ["bun", "scripts/mint-session.mjs"], capture_output=True, text=True, cwd="/home/z/my-project"
).stdout.strip().splitlines()
A = json.loads(out[0])
print(f"session: A={A['name']}({A['id']})")

console_errors = []

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1440, "height": 1400})
    ctx.add_cookies([{"name": "rb_session", "value": A["token"], "url": BASE}])
    room = ctx.new_page()
    room.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
    room.on("pageerror", lambda e: console_errors.append(str(e)))
    room.on("response", lambda r: console_errors.append(f"HTTP {r.status} {r.url}") if r.status >= 400 else None)

    room.goto(BASE + "/battles/new", wait_until="domcontentloaded")
    room.wait_for_selector("button:has-text('Create Battle')", timeout=20000)
    room.wait_for_timeout(1500)

    # switch the pot rule to JACKPOT (violet option button)
    jp = room.locator("button", has_text="JACKPOT").first
    jp.click(timeout=5000)
    room.wait_for_timeout(400)
    print("JACKPOT option pressed; summary line:")
    try:
        print("   ", room.locator("text=Jackpot mode — odds by unboxed value").first.inner_text(timeout=3000))
    except Exception as e:
        print("    (summary not found)", str(e)[:100])

    # add 2 TEST rounds
    room.get_by_role("button", name="Add a case to the battle").click(timeout=4000)
    room.wait_for_timeout(500)
    room.get_by_role("button", name="Add TEST, price $10").click(timeout=4000)
    room.wait_for_timeout(300)
    room.get_by_role("button", name="Add TEST, price $10").click(timeout=4000)
    room.wait_for_timeout(300)
    room.keyboard.press("Escape")
    room.wait_for_timeout(400)
    room.keyboard.press("Escape")
    # the picker dialog can outlive Escape — wait for the overlay to really detach
    try:
        room.wait_for_selector("[role='dialog']", state="detached", timeout=8000)
    except Exception:
        pass
    room.wait_for_timeout(500)

    room.locator("button:has-text('Create Battle')").first.click(timeout=4000)
    deadline = time.time() + 45
    new_id = ""
    while time.time() < deadline:
        seg = room.url.rstrip("/").split("/")[-1]
        if seg != "new" and "/battles/" in room.url:
            new_id = seg
            break
        time.sleep(0.3)
    if not new_id:
        # hydration-proof fallback: newest waiting battle from the API
        r = ctx.request.get(BASE + "/api/gbattles")
        lst = r.json().get("battles", [])
        if lst:
            new_id = lst[0]["id"]
            room.goto(BASE + "/battles/" + new_id, wait_until="domcontentloaded")
    print("room:", new_id or "NAV FAIL")
    if not new_id:
        sys.exit(1)

    room.wait_for_timeout(2000)
    cb = room.locator("button:has-text('Call Bots')").first
    cb.wait_for(state="visible", timeout=15000)
    cb.click(timeout=4000)
    print("Call Bots pressed — watching for the jackpot reel...")

    saw_rolling = False
    saw_jackpot = False
    jp_pcts = []
    jp_header = ""
    # the real reel is announced ONLY by its own header — the status pill
    # "Jackpot draw after the last round" is visible during the whole fight
    reel_sig = room.locator("text=takes all the drops").first
    deadline = time.time() + 120
    while time.time() < deadline:
        try:
            txt = room.inner_text("body")
        except Exception:
            time.sleep(0.4)
            continue
        if not saw_rolling and ("ROUND 1" in txt.upper() or "ROUND 2" in txt.upper()):
            saw_rolling = True
            print("  rounds rolling...")
        try:
            if reel_sig.is_visible(timeout=120):
                saw_jackpot = True
                room.screenshot(path=str(SHOTS / "63-probe-jackpot-reel.png"), full_page=True)
                wrap = room.locator("div[role='status']").first
                jp_header = wrap.inner_text(timeout=2000)
                jp_pcts = re.findall(r"(\d+(?:\.\d+)?)%", jp_header)
                print("  JACKPOT REEL OPEN — pcts on the reel:", jp_pcts)
                print("  header:", " | ".join(l.strip() for l in jp_header.splitlines() if l.strip())[:300])
                break
        except Exception:
            pass
        if "VICTORY" in txt.upper() or "BATTLE LOST" in txt.upper():
            print("  !! finished with NO jackpot reel observed")
            room.screenshot(path=str(SHOTS / "63-probe-no-reel.png"), full_page=True)
            break
        time.sleep(0.3)

    # wait for the final verdict
    deadline = time.time() + 30
    while time.time() < deadline:
        txt = room.inner_text("body").upper()
        if "VICTORY" in txt or "BATTLE LOST" in txt:
            break
        time.sleep(0.4)
    room.screenshot(path=str(SHOTS / "63-probe-done.png"), full_page=True)
    done_txt = room.inner_text("body")
    verdict = "VICTORY" if "VICTORY" in done_txt.upper() else ("LOST" if "BATTLE LOST" in done_txt.upper() else "?")
    decided = "decided by the jackpot draw" in done_txt.lower()  # the chip renders CSS-uppercase
    print(f"  final verdict: {verdict} | 'Decided by the jackpot draw' chip: {decided}")

    # server truth — totals per player, winner, and the expected odds
    bv = ctx.request.get(BASE + f"/api/gbattles/{new_id}").json()["battle"]
    totals = {r["playerId"]: sum(p["value"] for p in r["pulls"]) for r in (bv.get("results") or [])}
    winner_ids = bv.get("winnerIds") or []
    print("  server totals:", totals)
    print("  server winnerIds:", winner_ids, "| potRule:", bv.get("potRule"), "| mode:", bv.get("mode"))
    ssum = sum(totals.values()) or 1
    you_tot = totals.get(A["id"], 0)
    bot_tot = sum(v for k, v in totals.items() if k != A["id"])
    you_won = A["id"] in winner_ids
    print(f"  expected odds you={(you_tot/ssum*100):.1f}% bot={(bot_tot/ssum*100):.1f}% | you won: {you_won}")
    if jp_pcts:
        print(f"  reel showed {len(jp_pcts)} pct labels: {jp_pcts}")
    else:
        print("  !! reel pct labels NOT FOUND on the page")

    browser.close()

print("\nconsole errors:", len(console_errors))
for e in console_errors[:8]:
    print("  ", e[:200])
