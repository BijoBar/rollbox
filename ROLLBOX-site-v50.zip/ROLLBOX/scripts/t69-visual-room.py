#!/usr/bin/env python3
"""Task 69 visual helper (restore session): mint a session, create a player
with balance and a 2v2 waiting room; print ROOM_ID + TOKEN."""
import base64
import hashlib
import hmac
import json
import sqlite3
import time
import requests

BASE = "http://localhost:3000"
DB = "db/custom.db"
SECRET = "rollbox-dev-secret"

body = base64.urlsafe_b64encode(json.dumps({"pid": "p_t69vis", "exp": int(time.time() * 1000) + 86400000},
                                           separators=(",", ":")).encode()).decode().rstrip("=")
sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()
token = body + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")

con = sqlite3.connect(DB)
con.execute(
    "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
    "VALUES ('p_t69vis', 'steam', 't69vis-steamid', 'T69 Visual', 5000, 0, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
)
con.commit()
con.close()

r = requests.post(BASE + "/api/gbattles", timeout=15, cookies={"rb_session": token},
                  json={"type": "2v2", "mode": "standard", "potRule": "winner",
                        "rounds": ["farm-ak47", "farm-ak47"], "private": False})
bid = r.json().get("id")
print("ROOM_ID=" + str(bid))
print("TOKEN=" + token)
