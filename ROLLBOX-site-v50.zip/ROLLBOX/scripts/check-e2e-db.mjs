import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
console.log(
  "players:", await db.player.count(),
  "| communityCases:", await db.communityCase.count(),
  "| supportMsgs:", await db.supportMessage.count(),
  "| supportCases:", await db.supportCase.count()
);
await db.$disconnect();
