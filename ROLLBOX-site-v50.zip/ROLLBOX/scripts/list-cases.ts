import { CASES } from "../src/lib/cases";
const sorted = [...CASES].filter((c) => c.kind === "standard").sort((a, b) => a.price - b.price).slice(0, 8);
for (const c of sorted) console.log(c.id, c.price);
