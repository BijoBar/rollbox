// Task 26 E2E: inject a legacy-style steam row (img = "~1…" shorthand) to
// prove the GET self-heal expands it. Prints the row id for cleanup.
import crypto from "crypto";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const PID = process.argv[2];
if (!PID) throw new Error("usage: node t26-inject-legacy.mjs <playerId>");

const row = await db.inventoryItem.create({
  data: {
    id: "i_" + crypto.randomBytes(8).toString("hex"),
    playerId: PID,
    entryId: "steam:99999999999",
    data: JSON.stringify({
      id: "steam:99999999999",
      assetid: "99999999999",
      n: "Legacy Test Item (self-heal probe)",
      name: "Legacy Test Item (self-heal probe)",
      w: "Souvenir Legacy Gun",
      r: "milspec",
      p: 1.0,
      v: 10,
      img: "~1i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz",
      quality: "tournament",
    }),
    value: 10,
  },
});
console.log(JSON.stringify({ uid: row.id }));
await db.$disconnect();
