#!/usr/bin/env node
// Slim the skins catalog for shipping: the ~13.4K img URLs repeat the same
// long CDN hosts — store a shorthand ("~1"/"~2"/"~3") and let ExchangeView
// rebuild the full URLs at runtime. Writes the file back IN PLACE (the staged
// copy) and validates the JSON before finishing.
//
//   ~1  https://community.akamai.steamstatic.com/economy/image/
//   ~2  https://cdn.steamstatic.com/apps/730/icons/
//   ~3  https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/

import { readFileSync, writeFileSync } from "node:fs";

const file = process.argv[2];
if (!file) {
  console.error("usage: node slim-catalog.mjs <catalog.json>");
  process.exit(1);
}

const PREFIXES = [
  ["~1", "https://community.akamai.steamstatic.com/economy/image/"],
  ["~2", "https://cdn.steamstatic.com/apps/730/icons/"],
  ["~3", "https://raw.githubusercontent.com/ByMykel/counter-strike-image-tracker/main/static/panorama/images/"],
];

const data = JSON.parse(readFileSync(file, "utf8"));
let saved = 0;
for (const item of data) {
  if (typeof item.img !== "string") continue;
  for (const [short, full] of PREFIXES) {
    if (item.img.startsWith(full)) {
      saved += full.length - short.length;
      item.img = short + item.img.slice(full.length);
      break;
    }
  }
}
// anything that did not match a known prefix stays a full URL — the runtime
// expander only rewrites values that START with a shorthand token
writeFileSync(file, JSON.stringify(data));
const kb = (n) => (n / 1024).toFixed(0) + "KB";
console.log(`catalog slimmed: ${saved.toLocaleString()} chars of prefixes saved (${kb(saved)})`);
