// Probe: match the user's item names (Task 76 spec) against the site catalog
// + the official CS2 DBs — reports which items resolve to an id + image.
import { readFileSync } from "fs";

const catalog = JSON.parse(readFileSync("/home/z/my-project/public/skins-catalog.json", "utf8"));
const byName = new Map(catalog.map((c) => [c.n, c]));
const bySlug = new Map(catalog.map((c) => [c.id, c]));

const CASES = [
  { code: "RB-101", items: [["P250 | Asiimov", "BS"], ["AK-47 | Asiimov", "WW"], ["AWP | Asiimov", "WW"], ["P90 | Asiimov", "WW"], ["Desert Eagle | Heat Treated", "MW"], ["MP9 | Green Plaid", "MW"], ["P250 | Franklin", "FN"]] },
  { code: "RB-102", items: [["Dual Berettas | Cartel", "WW"], ["USP-S | Printstream", "FT"], ["Desert Eagle | Printstream", "BS"], ["AWP | Printstream", "MW"], ["M4A1-S | Printstream", "BS"], ["AK-47 | Cartel", "MW"], ["P250 | Cartel", "BS"]] },
  { code: "RB-103", items: [["Sticker | Dragon", ""], ["SG 553 | Dragon Tech", "FN"], ["Zeus x27 | Dragon Snore", "FT"], ["Desert Eagle | Kumicho Dragon", "MW"], ["P2000 | Imperial Dragon", "FN"], ["Glock-18 | Dragon Tattoo", "FN"], ["SSG 08 | Dragonfire", "FT"]] },
  { code: "RB-104", items: [["SSG 08 | Acid Fade", "FN"], ["Sawed-Off | Amber Fade", "FN"], ["P2000 | Amber Fade", "FN"], ["R8 Revolver | Amber Fade", "FN"], ["Galil AR | Amber Fade", "MW"], ["MAC-10 | Amber Fade", "MW"], ["MP7 | Fade", "FN"], ["MAC-10 | Fade", "FN"], ["M4A1-S | Fade", "FN"], ["AWP | Fade", "FN"]] },
  { code: "RB-105", items: [["R8 Revolver | Crimson Web", "MW"], ["SCAR-20 | Crimson Web", "FT"], ["CZ75-Auto | Crimson Web", "FT"], ["Desert Eagle | Crimson Web", "FT"], ["P250 | Crimson Kimono", "FT"], ["Navaja Knife | Crimson Web", "BS"], ["Shadow Daggers | Crimson Web", "BS"], ["Specialist Gloves | Crimson Web", "FT"]] },
  { code: "RB-106", items: [["UMP-45 | Moonrise", "FN"], ["Zeus x27 | Olympus", "FT"], ["Glock-18 | Moonrise", "FN"], ["Glock-18 | Vogue", "FT"], ["Desert Eagle | Starcade", "WW"], ["AK-47 | Neon Rider", "MW"], ["MAC-10 | Neon Rider", "WW"], ["Shadow Daggers | Gamma Doppler (Phase 4)", "FN"], ["Gut Knife | Doppler (Phase 3)", "FN"], ["Nomad Knife | Doppler (Phase 3)", "FN"]] },
  { code: "RB-107", items: [["Glock-18 | Warhawk", "FT"], ["Glock-18 | Oxide Blaze", "MW"], ["MP9 | Broken Record", "FN"], ["AK-47 | Rat Rod", "BS"], ["Five-SeveN | Case Hardened", "MW"], ["MAC-10 | Case Hardened", "MW"], ["Hydra Gloves | Case Hardened", "MW"], ["Huntsman Knife | Case Hardened", "FT"], ["AK-47 | Case Hardened", "FT"]] },
  { code: "RB-108", items: [["USP-S | Check Engine", "FN"], ["MAG-7 | Heat", "MW"], ["MAC-10 | Carnivore", "FN"], ["P2000 | Obsidian", "MW"], ["XM1014 | Tranquility", "FT"], ["P250 | Muertos", "MW"], ["M4A4 | Hellish", "FT"], ["M4A4 | Hellfire", "WW"], ["MP9 | Hot Rod", "MW"], ["Sticker | HellRaisers | Katowice 2014", ""]] },
  { code: "RB-109", items: [["Sticker | Neon MVP (Lenticular)", ""], ["MP5-SD | Phosphor", "FN"], ["Glock-18 | Vogue", "FN"], ["AWP | Fever Dream", "FN"], ["AWP | Neo-Noir", "FN"], ["AK-47 | Neon Rider", "MW"], ["M4A4 | Desolate Space", "FN"], ["AK-47 | Nightwish", "FN"], ["AK-47 | Neon Revolution", "FN"]] },
];

const KNIFE_PREFIXES = ["Karambit", "Talon Knife", "Skeleton Knife", "Kunai Knife", "M9 Bayonet", "Bayonet", "Butterfly Knife", "Stiletto Knife", "Huntsman Knife", "Falchion Knife", "Bowie Knife", "Flip Knife", "Gut Knife", "Survival Knife", "Paracord Knife", "Nomad Knife", "Kukri Knife", "Navaja Knife", "Shadow Daggers"];
const GLOVE_PREFIXES = ["Specialist Gloves", "Driver Gloves", "Hydra Gloves", "Sport Gloves", "Moto Gloves", "Bloodhound Gloves", "Hand Wraps", "Wrap"];

function candidates(name) {
  const list = [name];
  const isKnife = KNIFE_PREFIXES.some((k) => name.startsWith(k));
  const isGloves = GLOVE_PREFIXES.some((k) => name.startsWith(k));
  if (isKnife || isGloves) list.push("★ " + name);
  // Doppler phases: strip " (Phase N)" and also the space variant
  const phase = name.match(/\((Phase \d+)\)/);
  if (phase) {
    const base = name.replace(/\s*\((Phase \d+)\)/, "");
    list.push(base);
    if (isKnife || isGloves) list.push("★ " + base);
  }
  return list;
}

let total = 0, matched = 0, noImg = 0;
const misses = [], noimgs = [];
for (const c of CASES) {
  for (const [name, wear] of c.items) {
    total++;
    let hit = null, via = "";
    for (const cand of candidates(name)) {
      const e = byName.get(cand);
      if (e) { hit = e; via = cand; break; }
    }
    if (!hit) {
      for (const cand of candidates(name)) {
        const slug = cand.toLowerCase().replace(/★/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
        const e = bySlug.get(slug);
        if (e) { hit = e; via = cand + " [slug]"; break; }
      }
    }
    if (!hit) {
      // last resort: prefix match on catalog names (phase/label drift)
      const base = name.replace(/\s*\((Phase \d+)\)/, "");
      const e = catalog.find((x) => x.n === base || x.n === "★ " + base);
      if (e) { hit = e; via = base + " [base]"; }
    }
    if (hit) {
      matched++;
      if (!hit.img) { noImg++; noimgs.push(`${c.code} ${name} -> ${hit.id} (no img)`); }
      console.log(`OK  ${c.code.padEnd(7)} ${name} -> ${hit.id} img:${hit.img ? "Y" : "N"} via "${via}"`);
    } else {
      misses.push(`${c.code} ${name}`);
      console.log(`MISS ${c.code.padEnd(7)} ${name}`);
    }
  }
}
console.log(`\nTOTAL ${total}  matched ${matched}  missing ${total - matched}  matched-no-img ${noImg}`);
if (misses.length) console.log("MISSES:\n" + misses.join("\n"));
if (noimgs.length) console.log("NO IMG:\n" + noimgs.join("\n"));
