// Extract inline <script> blocks from ROLLBOX_DROPS.html and syntax-check them
import fs from "fs";
const html = fs.readFileSync("/home/z/my-project/download/ROLLBOX_DROPS.html", "utf8");
const re = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
let m, i = 0, fail = 0;
while((m = re.exec(html))){
  const code = m[1];
  if(!code.trim()){ continue; }
  i++;
  const tmp = `/home/z/my-project/scripts/_drops_script_${i}.js`;
  fs.writeFileSync(tmp, code);
  try {
    new Function(code); // parse-only check (does not execute)
    console.log(`script #${i}: OK (${code.length} chars)`);
  } catch(e){
    fail++;
    console.log(`script #${i}: SYNTAX ERROR -> ${e.message}`);
  }
}
// protocol integrity
const ok1 = html.includes('"ROLLBOX-CASES v1"');
const ok2 = html.includes('"ROLLBOX-TERMINALS v1"');
const ok3 = (html.match(/<html lang="he" dir="rtl">/) || []).length === 1;
console.log(`protocol ROLLBOX-CASES v1: ${ok1}; ROLLBOX-TERMINALS v1: ${ok2}; he/rtl root: ${ok3}`);
// new feature sanity
for(const id of ["cTgt","cRec","cApplyRec","REC_EDGE"]){
  console.log(`feature token ${id}: ${html.includes(id) ? "present" : "MISSING"}`);
}
process.exit(fail ? 1 : 0);
