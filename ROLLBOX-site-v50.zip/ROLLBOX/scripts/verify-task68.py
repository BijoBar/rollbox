#!/usr/bin/env python3
"""Task 68 verification — dollar->ROLLBOXCOIN, aura removal, site-wide galaxy,
2v2 CT/T patch art. Static checks + live asset/API probes + a browser-free
server smoke (open case, battle lifecycle) against the dev server on :3000.
Also serves as the RESTORE check: the project tree must match the shipped ZIP.
"""
import base64
import hashlib
import hmac
import json
import os
import sqlite3
import sys
import time
import urllib.request

import requests

BASE = "http://localhost:3000"
DB = "db/custom.db"
SECRET = "rollbox-dev-secret"
PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, ok: bool, extra: str = "") -> None:
    (PASS if ok else FAIL).append(name + (f" — {extra}" if (extra and not ok) else ""))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if (extra and not ok) else ""))


def read(*parts: str) -> str:
    with open(os.path.join(*parts), encoding="utf-8") as f:
        return f.read()


def get_status(path: str) -> int:
    try:
        with urllib.request.urlopen(BASE + path, timeout=10) as r:
            return int(r.status)
    except Exception:
        return -1


def mint(pid: str) -> str:
    body = base64.urlsafe_b64encode(json.dumps({"pid": pid, "exp": int(time.time() * 1000) + 86400000},
                                               separators=(",", ":")).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()
    return body + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")


def sess(pid: str) -> dict:
    return {"rb_session": mint(pid)}


def make_player(tag: str, balance: int = 500) -> str:
    pid = f"p_t69{tag}"
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
        "VALUES (?, 'steam', ?, ?, ?, 0, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
        (pid, f"t69-{tag}-steamid", f"T69 {tag}", balance),
    )
    con.commit()
    con.close()
    return pid


def main() -> None:
    # ===== restored assets =====
    check("coin icon asset present", os.path.getsize("public/rollboxcoin-icon.png") > 5000)
    check("coin large asset present", os.path.getsize("public/rollboxcoin.png") > 20000)
    check("2v2 CT patch art present", os.path.getsize("public/teams/ct.webp") > 20000)
    check("2v2 T patch art present", os.path.getsize("public/teams/t.webp") > 20000)
    for path in ("/rollboxcoin-icon.png", "/rollboxcoin.png", "/teams/ct.webp", "/teams/t.webp"):
        check(f"GET {path} -> 200", get_status(path) == 200)
    battles = read("src", "lib", "battles.ts")
    check("TEAMS map serves the new ct/t art", '"/teams/ct.webp"' in battles and '"/teams/t.webp"' in battles)

    # ===== aura removed / site-wide background =====
    # Task 84 (user spec): the galaxy layer is GONE — the whole site now flies
    # inside the infinite corridor canvas + warp CSS. T68 checks updated to
    # assert the NEW architecture (same precedent as the Task 80 spec flips).
    hero = read("src", "components", "rollbox", "Hero.tsx")
    check("AURA deleted from the Hero crates", "anim-aura-breathe" not in hero and "240,185,11" not in hero)
    css = read("src", "app", "globals.css")
    check("galaxy CSS fully removed", ".galaxy-bg" not in css and "galaxy-twinkle" not in css and "galaxy-shoot" not in css)
    check("warp overlay CSS installed (streaks + flash + arrive)",
          ".warp-overlay" in css and "warp-streak-zoom" in css and "warp-flash-hit" in css and "warp-arrive" in css)
    layout = read("src", "app", "layout.tsx")
    corridor = read("src", "components", "rollbox", "CorridorBackground.tsx")
    check("corridor canvas mounted in the root layout (whole site, fixed behind all)",
          "<CorridorBackground />" in layout and "WarpProvider" in layout)
    check("corridor engine: scroll=walk + warp boost + crate swaps",
          "SCROLL_GAIN" in corridor and "rb-warp-start" in corridor and "rb-warp-done" in corridor
          and "SHUFFLE_EVERY" in corridor and "caseImagePath" in corridor)
    leftovers = []
    for dp, _, fs in os.walk("src"):
        for f in fs:
            if f.endswith(".tsx") and 'className="galaxy-bg' in read(os.path.join(dp, f)):
                leftovers.append(os.path.join(dp, f))
    check("no galaxy layers left anywhere", not leftovers, str(leftovers))

    # ===== ROLLBOXCOIN sweep =====
    check("Coin component exists", os.path.exists("src/components/rollbox/Coin.tsx"))
    coin_users = 0
    for dp, _, fs in os.walk("src/components/rollbox"):
        for f in fs:
            if f.endswith(".tsx") and f != "Coin.tsx" and 'from "./Coin"' in read(os.path.join(dp, f)):
                coin_users += 1
    check("Coin imported across the UI", coin_users >= 14, f"importers={coin_users}")
    bad = []
    for dp, _, fs in os.walk("src/components/rollbox"):
        for f in fs:
            if f.endswith(".tsx"):
                txt = read(os.path.join(dp, f))
                if "$${" in txt or '">$' in txt or '"$"' in txt or ("$5" in txt):
                    bad.append(os.path.join(dp, f))
    check("no $-currency literals left in rollbox UI", not bad, str(bad))
    check("home meta uses Rollboxcoin wording", "$3 spins" not in read("src", "app", "page.tsx") and "Rollboxcoin" in read("src", "app", "page.tsx"))
    check("TOS glossary de-dollared", "($)" not in read("src", "app", "tos", "content.tsx") and "($100)" not in read("src", "app", "tos", "content.tsx"))

    # ===== Task 66-67 regression markers (server + client) =====
    eng = read("src", "lib", "server", "gbattles.ts")
    check("battles server: choose-bot + private + bot keys",
          "seatChosenBot" in eng and "isPrivate" in eng and "nextBotKey" in eng)
    opener = read("src", "components", "rollbox", "CaseOpener.tsx")
    check("multi-open selector 1-5 + 10/15/20", "[1, 2, 3, 4, 5, 10, 15, 20]" in opener)
    check("white flash still deleted", "rd-white" not in opener and "rd-white" not in css)
    # USER SPEC (Task 80): the round counter is REMOVED — chips strip gone
    check("round counter removed per Task 80 spec", "roundStripRef" not in read("src", "components", "rollbox", "BattleRoomView.tsx"))

    # ===== live smoke: open + battle lifecycle =====
    a = make_player("A", 500)
    r = requests.post(BASE + "/api/open", timeout=15, cookies=sess(a), json={"caseId": "farm-ak47", "count": 1})
    pulls = r.json().get("pulls", []) if r.ok else []
    check("live: open case works (1 pull)", r.status_code == 200 and len(pulls) == 1, f"{r.status_code} {r.text[:100]}")
    r = requests.post(BASE + "/api/gbattles", timeout=15, cookies=sess(a),
                      json={"type": "1v1", "mode": "standard", "potRule": "winner", "rounds": ["farm-ak47"], "private": False})
    bid = r.json().get("id")
    check("live: battle created", bool(bid), r.text[:100])
    if bid:
        r = requests.post(BASE + f"/api/gbattles/{bid}/bots", timeout=15, cookies=sess(a), json={"bot": "[RBbot] Gabey"})
        st = requests.get(BASE + f"/api/gbattles/{bid}", timeout=15, cookies=sess(a)).json()
        st = st.get("battle", st)  # the room view is wrapped in {"battle": ...}
        players = st.get("players", [])
        check("live: chosen bot seated + room fills", r.status_code == 200 and any(p.get("isBot") for p in players), r.text[:100])
        check("live: status running", st.get("status") in ("running", "playing", "live"), st.get("status"))

    print(f"\n== {len(PASS)} passed, {len(FAIL)} failed ==")
    if FAIL:
        print("FAILED:", *FAIL, sep="\n  - ")
        sys.exit(1)


if __name__ == "__main__":
    main()
