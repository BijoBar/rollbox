#!/usr/bin/env bash
# Task 43 E2E — part 1: home page (RollBox Official heading, no NEW SITE
# UPDATES, new TOS teaser) + battle picker (category sections, desc order).
set -u
AB="agent-browser"
D="/home/z/my-project/download"

echo "=== 1. home page ==="
$AB open http://localhost:3000/ >/dev/null 2>&1
sleep 3
$AB eval '(() => {
  const h2s = [...document.querySelectorAll("h2")].map(h => h.textContent.trim());
  const body = document.body.textContent;
  return JSON.stringify({
    rollboxOfficial: h2s.some(t => t.replace(/\s+/g," ") === "RollBox Official"),
    oldHeading: body.includes("20 ways to get rich"),
    updatesCard: body.includes("New Site Updates"),
    tosTeaser: body.includes("binding legal agreement") && body.includes("class-action waiver"),
    oldTosTeaser: body.includes("free entertainment demo"),
  });
})()' 2>/dev/null | tail -1
$AB screenshot "$D/task43-home.png" >/dev/null 2>&1

echo "=== 2. battle create → picker ==="
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 2.5
$AB eval '(() => {
  const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim().toLowerCase().includes("add cases") || x.textContent.trim().toLowerCase().includes("choose"));
  return b ? (b.textContent.trim().slice(0,40)) : [...document.querySelectorAll("button")].map(x=>x.textContent.trim()).filter(t=>t&&t.length<30).join("|").slice(0,300);
})()' 2>/dev/null | tail -1