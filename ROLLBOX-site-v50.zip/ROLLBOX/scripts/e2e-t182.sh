#!/bin/bash
# Task 182 (R40) E2E — two missions:
#   A) the rolldrop sound loop: hard guarantees (killLoops at hit + bonus start
#      + the sound.ts leash) — a forced rolldrop must end with ZERO loops alive
#   B) FAST MODE deleted from battles: no toggle on /battles/new, no fast field
#      in the room API, normal schedule math (6400+1000+250), chips + caption
#      deletions from R39 still intact, fight settles cleanly
set -u
AB="agent-browser"
BASE="http://localhost:3000"
SHOT="/home/z/my-project/scripts/e2e-t182"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0
jhas() { echo "$1" | sed 's/\\//g' | rg -q "$2"; }

TOKEN="$(bun scripts/mint-e2e-session.ts 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')"

# ============================================================ STAGE 0 (module)
mod=$(bun -e "const m = await import('/home/z/my-project/src/lib/rolldrop.ts'); const g = await import('/home/z/my-project/src/lib/gbattle-shared.ts'); const c = await import('/home/z/my-project/src/lib/cases.ts'); const tst = c.CASES.find(x=>x.id==='test-rolldrop'); console.log('rd', m.ROLLDROP_CHANCE, m.rolldropChanceOf({ items: [] }), m.rolldropChanceOf(tst), 'reels', g.REEL_YOU_MS, g.REEL_OTHER_MS, 'beat', g.ROUND_BEAT_MS, 'max4', g.maxReelMs(4), 'fastGone', g.REEL_YOU_MS_FAST === undefined && g.ROUND_BEAT_MS_FAST === undefined);" 2>/dev/null | tail -1)
echo "module check: $mod"
jhas "$mod" "rd 0\.0175 0\.0175 0\.7" && ok "module: rolldrop flat 1.75% + TEST override 70% (unchanged)" || fail "module: rolldrop values ($mod)"
jhas "$mod" "reels 6400 6400 beat 250 max4 6400" && ok "module: battle pacing = the NORMAL math only" || fail "module: pacing constants ($mod)"
jhas "$mod" "fastGone true" && ok "module: the FAST constants no longer exist in gbattle-shared" || fail "module: fast constants still exported ($mod)"

# ============================================================ STAGE A (guest, forced rolldrop)
$AB close >/dev/null 2>&1 || true
sleep 1
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB storage local set rb-rolldrop-force 1 >/dev/null 2>&1
$AB open "$BASE/case/test-rolldrop" >/dev/null
sleep 3.5

# audio probe — resolve the descriptor owners at install time (t181 lesson)
probe=$($AB eval '(() => { if (window.__audioProbe) return "probe-installed"; const dp = AudioBufferSourceNode.prototype; const db = (typeof AudioScheduledSourceNode !== "undefined") ? AudioScheduledSourceNode.prototype : dp; const loopOwner = Object.getOwnPropertyDescriptor(dp, "loop") ? dp : db; const loopD = Object.getOwnPropertyDescriptor(loopOwner, "loop"); const startOwner = Object.getOwnPropertyDescriptor(dp, "start") ? dp : db; const stopOwner = Object.getOwnPropertyDescriptor(dp, "stop") ? dp : db; const stD = Object.getOwnPropertyDescriptor(startOwner, "start"); const spD = Object.getOwnPropertyDescriptor(stopOwner, "stop"); if (!loopD || !stD || !spD) return "probe-descriptor-missing"; window.__audioProbe = true; window.__loopSrcs = new Set(); Object.defineProperty(loopOwner, "loop", { get() { return loopD.get.call(this); }, set(v) { if (v) window.__loopSrcs.add(this); loopD.set.call(this, v); } }); Object.defineProperty(startOwner, "start", { value(...a) { this.__started = true; if (this.loop) window.__loopSrcs.add(this); return stD.value.apply(this, a); } }); Object.defineProperty(stopOwner, "stop", { value(...a) { this.__stopped = true; return spD.value.apply(this, a); } }); return "probe-installed"; })()' 2>/dev/null)
jhas "$probe" "probe-installed" && ok "case: audio loop probe installed" || fail "case: probe ($probe)"

# the round-long sampler + raredrop watcher
$AB eval '(() => { window.__samples = []; window.__s0 = 0; window.__rareSeen = false; window.__sampler = setInterval(() => { if (!window.__s0) window.__s0 = Date.now(); const alive = [...(window.__loopSrcs||[])].filter((s)=>s.__started&&s.loop&&!s.__stopped).length; window.__samples.push({ t: Date.now()-window.__s0, alive }); if (document.querySelector("img[src*=raredrop]")) window.__rareSeen = true; }, 150); return "sampler-on"; })()' >/dev/null 2>&1

# the OPEN click is IN-PLACE (a second $AB open would wipe the probe)
$AB find first "button.neon-btn" click >/dev/null 2>&1
echo "waiting out the full rolldrop sequence (~21s)..."
sleep 21
rd=$($AB eval "(() => { const t = document.body.innerText; return JSON.stringify({ rareSeen: window.__rareSeen === true, revealed: /total won|open again/i.test(t) }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "rolldrop flow: $rd"
jhas "$rd" '"rareSeen":true' && ok "rolldrop: forced flow alive — raredrop marker + bonus reel" || fail "rolldrop: forced flow broke ($rd)"

# THE LOOP VERDICT — the whoosh lives once, dies, and NOTHING loops again
loopverdict=$($AB eval '(() => { const s = window.__samples || []; let sawLoop = false, died = false, reborn = -1, tailAlive = -1; for (const x of s) { if (x.alive > 0) sawLoop = true; else if (sawLoop) died = true; if (died && x.alive > 0 && reborn < 0) reborn = x.t; } const tail = s.slice(-8); tailAlive = Math.max(...tail.map(x=>x.alive)); return JSON.stringify({ samples: s.length, sawLoop, died, rebornAtMs: reborn, tailAlive }); })()' 2>/dev/null | sed 's/\\//g' | tail -1)
echo "loop verdict: $loopverdict"
jhas "$loopverdict" '"samples":[1-9]' || fail "loop probe: sampler never ran ($loopverdict)"
jhas "$loopverdict" '"sawLoop":true' && ok "loop probe: the main spin whoosh WAS alive (probe sees real loops)" || fail "loop probe: never saw the whoosh ($loopverdict)"
jhas "$loopverdict" '"rebornAtMs":-1' && ok "rolldrop: NO sound loop lives between the hit and the bonus reel's end (hard-guaranteed)" || fail "rolldrop: a loop came back alive ($loopverdict)"
jhas "$loopverdict" '"tailAlive":0' && ok "rolldrop: ZERO looping sources alive at the end of the sequence" || fail "rolldrop: a loop survived to the tail ($loopverdict)"
$AB storage local set rb-rolldrop-force 0 >/dev/null 2>&1
$AB screenshot "$SHOT-rolldrop.png" >/dev/null 2>&1
errsA=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -6)
if [ -z "$errsA" ]; then ok "stage A: zero page errors"; else fail "stage A errors: $errsA"; fi

# ============================================================ STAGE B (battles, signed in)
$AB close >/dev/null 2>&1 || true
sleep 1
$AB open "$BASE/" >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
sleep 2
$AB open "$BASE/battles/new" >/dev/null
sleep 3

# 1. the FAST MODE toggle is GONE; CRAZY + PRIVATE remain
tog=$($AB eval "(() => { const all=[...document.querySelectorAll('button')]; return JSON.stringify({ fast: all.some(x=>/fast mode/i.test(x.textContent)), crazy: all.some(x=>/crazy mode/i.test(x.textContent)), priv: all.some(x=>/^private (on|off)/i.test(x.textContent.trim())) }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "create toggles: $tog"
jhas "$tog" '"fast":false' && ok "create: the FAST MODE toggle is DELETED" || fail "create: fast toggle still present ($tog)"
jhas "$tog" '"crazy":true' && ok "create: CRAZY MODE toggle still present" || fail "create: crazy toggle missing ($tog)"
jhas "$tog" '"priv":true' && ok "create: PRIVATE toggle still present" || fail "create: private toggle missing ($tog)"

# 2. two rounds → an inter-round gap exists to measure
addcase() {
  $AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.getAttribute('aria-label')==='Add a case to the battle'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
  sleep 1.2
  $AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Community Cases')); t?.click(); return 'ok'; })()" >/dev/null 2>&1
  sleep 0.8
  $AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>(x.getAttribute('aria-label')||'').startsWith('Add T66 Galaxy Case')); t?.click(); return 'ok'; })()" >/dev/null 2>&1
  sleep 0.5
  $AB eval "document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); 'esc'" >/dev/null 2>&1
  sleep 0.8
}
addcase
addcase
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim()==='Create Battle'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 5
url=$($AB eval "location.pathname" 2>/dev/null | sed 's/\\//g' | rg -o "/battles/[A-Za-z0-9_-]+" | head -1)
if [ -n "$url" ] && [ "$url" != "/battles/new" ]; then ok "battle: room opened at $url"; else fail "battle: did not land in a room ($url)"; fi
BID="${url##*/}"

# 3. waiting phase: chips present, 'starts when full' still deleted
waitcap=$($AB eval "(() => { const t = document.body.innerText; return JSON.stringify({ startsWhenFull: /starts when full/i.test(t), waiting: /waiting for players/i.test(t) }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "waiting caption: $waitcap"
jhas "$waitcap" '"startsWhenFull":false' && ok "battle: 'Reel — starts when full' caption STAYS deleted" || fail "battle: waiting caption present"
jhas "$waitcap" '"waiting":true' && ok "battle: the room IS in the waiting phase for the check" || fail "battle: not waiting ($waitcap)"
chipsWait=$($AB eval "(() => { const c=[...document.querySelectorAll('[data-roundchip]')]; return JSON.stringify({ n: c.length, texts: c.map(x=>x.textContent.trim()).join('|') }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "waiting chips: $chipsWait"
jhas "$chipsWait" '"n":2' && ok "battle: round chips rendered (waiting) — R39 keeps them" || fail "battle: waiting chips ($chipsWait)"

# 4. call bots → the fight starts on the NORMAL schedule; the room API must
#    NOT carry a fast field at all
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Call Bots')); b?.click(); return 'ok'; })()" >/dev/null 2>&1
st="{}"
for i in $(seq 1 20); do
  sleep 1
  st=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>{ const b=d.battle||{}; return JSON.stringify({ st: b.status, fastField: ('fast' in b), n: (b.players||[]).length }); })" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$st" '"st":"playing"' && break
done
echo "battle state: $st"
jhas "$st" '"fastField":false' && ok "battle: the room API carries NO fast field (feature deleted server-side)" || fail "battle: fast field ($st)"

# 5. NORMAL schedule — slot = 6400 reel + 1000 pad + 250 beat = 7650, gap 250
#    (a ROLLDROP round = 2*6400 + 500 beat + 1000 hold + 1000 pad + 250 = 15550)
sched=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>{ const b=d.battle||{}; const s=b.schedule||[]; const len0=s[0]?s[0].endMs-s[0].startMs:-1; const len1=s[1]?s[1].endMs-s[1].startMs:-1; const gap0=s.length>1? s[1].startMs-s[0].endMs : -1; return JSON.stringify({ slots: s.length, len0, len1, gap0 }); })" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "normal schedule: $sched"
jhas "$sched" '"len0":7650' && ok "pacing: round 1 = 6400ms reel + 1000ms pad + 250ms beat (7650) — the NORMAL speed" || fail "pacing: slot math ($sched)"
if jhas "$sched" '"len1":7650'; then ok "pacing: round 2 = 7650 (normal)"; elif jhas "$sched" '"len1":15550'; then ok "pacing: round 2 = 15550 — a ROLLDROP round on the normal chain"; else fail "pacing round 2 ($sched)"; fi
jhas "$sched" '"gap0":250' && ok "pacing: the between-rounds breather = the normal 250ms" || fail "pacing gap ($sched)"

# 6. the ACTIVE chip reads "Round 1/2" mid-fight (R39 keeps this)
sleep 2
chipLive=$($AB eval "(() => { const a=document.querySelector('[data-roundchip-active=\"1\"]'); const all=[...document.querySelectorAll('[data-roundchip]')]; return JSON.stringify({ active: a?a.textContent.trim():'', activeN: a?1:0, total: all.length }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "active chip: $chipLive"
jhas "$chipLive" '"active":"Round 1/2"' && ok "battle: the ACTIVE tile chip reads 'Round 1/2'" || fail "battle: active chip ($chipLive)"
$AB screenshot "$SHOT-battle.png" >/dev/null 2>&1

# 7. the fight settles
fin="{}"
for i in $(seq 1 30); do
  sleep 1.5
  fin=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>JSON.stringify({ st:(d.battle||{}).status }))" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$fin" '"st":"finished"' && break
done
echo "battle final: $fin"
jhas "$fin" '"st":"finished"' && ok "battle: the normal-paced fight settles cleanly" || fail "battle: never finished ($fin)"
errsB=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -6)
if [ -z "$errsB" ]; then ok "stage B: zero page errors"; else fail "stage B errors: $errsB"; fi

# 8. lobby: no FAST badge anywhere
$AB open "$BASE/battles" >/dev/null
sleep 3
lob=$($AB eval "(() => { const t = document.body.innerText; return JSON.stringify({ fastBadge: /fast mode|⚡/i.test(t) }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "lobby: $lob"
jhas "$lob" '"fastBadge":false' && ok "lobby: no FAST badge / fast-mode text anywhere" || fail "lobby: fast text present ($lob)"

echo ""
if [ "$FAILED" = "0" ]; then echo "ALL CHECKS PASSED"; else echo "SOME CHECKS FAILED"; fi
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open "about:blank" >/dev/null 2>&1 || true
exit $FAILED
