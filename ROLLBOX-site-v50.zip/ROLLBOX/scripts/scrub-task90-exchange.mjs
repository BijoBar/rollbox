// Task 90 QA cleanup — undoes ONLY the exchange test-purchase made while
// verifying the shopping-cart buy flow (AUG | Commando Company FT, 0.10).
// Targeted like the other task scrubs: it removes the trade_buy ledger row(s)
// + the matching inventory item(s) created in the QA window and refunds the
// player, restoring the 9p/0b/0l + no-inventory baseline. NEVER touches
// anything else (the full wipe is scrub-db.mjs — forbidden since Task 85).
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const CUTOFF_MIN = 240; // QA window: last 4 hours
const since = new Date(Date.now() - CUTOFF_MIN * 60 * 1000);

// the QA buys are the only trade_buy rows ever created manually in QA
const buys = await prisma.ledger.findMany({
  where: { kind: "trade_buy", createdAt: { gte: since } },
});

let removedItems = 0;
for (const row of buys) {
  const del = await prisma.inventoryItem.deleteMany({
    where: { playerId: row.playerId, value: Math.abs(row.amount) },
  });
  removedItems += del.count;
  await prisma.player.update({
    where: { id: row.playerId },
    data: { balance: { increment: Math.abs(row.amount) } }, // refund the QA charge
  });
  await prisma.ledger.delete({ where: { id: row.id } });
  console.log(`undid trade_buy ${row.amount} for player ${row.playerId} (${del.count} item)`);
}
if (buys.length === 0) console.log("no QA trade_buy rows found — nothing to do");

const [p, b, l, inv] = [
  await prisma.player.count(),
  await prisma.battle.count(),
  await prisma.ledger.count(),
  await prisma.inventoryItem.count(),
];
console.log(`DB now: ${p}p/${b}b/${l}l, inventory rows: ${inv} (removed ${removedItems})`);
await prisma.$disconnect();
