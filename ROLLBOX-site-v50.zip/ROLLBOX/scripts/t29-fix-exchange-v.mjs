// ============ Task 29 fix-up: exchange-stock v values back on the ×10 scale ============
// After USD_TO_COINS went back to 10 (Task 29), a sync that ran under the old
// rate=1 re-derived every stock item's v at the 1:1 scale. This one-shot puts
// the SITE PRICE (v) back on the restored ×10 scale; p stays the real-USD
// market reference (same semantics as the catalog's p).
//   bun scripts/t29-fix-exchange-v.mjs --yes

import fs from "fs";
import path from "path";

const STOCK = path.join(process.cwd(), "db", "exchange-stock.json");
const MARKER = path.join(process.cwd(), "db", ".t29-exchange-v-fixed");

if (fs.existsSync(MARKER)) {
  console.error("REFUSED: marker exists — the v fix already ran.");
  process.exit(1);
}
if (!process.argv.includes("--yes")) {
  console.error("dry run — add --yes");
  process.exit(0);
}

const stock = JSON.parse(fs.readFileSync(STOCK, "utf8"));
const items = Array.isArray(stock) ? stock : (stock.items ?? []);
let n = 0;
for (const it of items) {
  if (typeof it.v === "number") {
    it.v = Math.max(0.01, Math.round(it.v * 10 * 100) / 100);
    n += 1;
  }
}
fs.writeFileSync(STOCK, JSON.stringify(stock));
fs.writeFileSync(MARKER, new Date().toISOString());
console.log(`✓ ${n} items v ×10 (p untouched — real-USD market reference)`);
