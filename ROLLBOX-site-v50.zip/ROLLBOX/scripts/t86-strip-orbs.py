"""Task 86: strip the old per-page anim-orb background blobs from every page —
the global corridor is the one and only background now. Keeps .anim-float
(CaseView product image still floats)."""
import pathlib
import re

FILES = [
    "src/components/rollbox/SettingsView.tsx",
    "src/components/rollbox/BreakGuard.tsx",
    "src/components/rollbox/BattleLobbyView.tsx",
    "src/components/rollbox/BalanceHistoryView.tsx",
    "src/components/rollbox/BattleCreateView.tsx",
    "src/components/rollbox/ExchangeView.tsx",
    "src/components/rollbox/CaseView.tsx",
    "src/components/rollbox/ProvablyFairView.tsx",
    "src/components/rollbox/ProfileView.tsx",
]

ORB = re.compile(r'[ \t]*<div\s+className="anim-orb.*?/>[ \t]*\n', re.S)

for f in FILES:
    p = pathlib.Path(f)
    s = p.read_text()
    s2, n = ORB.subn("", s)
    if n:
        p.write_text(s2)
    left = "anim-orb" in s2
    print(f"{f}: removed {n} orb(s), anim-orb still present: {left}")
