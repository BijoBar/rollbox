import { computeOutcome, dropTotal, splitTeamPot, takePerPlayer, type BattlePlayer, type BattleResult } from "/home/z/my-project/src/lib/battles";

const players: BattlePlayer[] = [
  { id: "a", name: "You", isYou: true, isBot: false, team: 0, joinedAt: 1, color: 0 },
  { id: "b", name: "[RBbot] Gabey", isYou: false, isBot: true, team: 0, joinedAt: 2, color: 1 },
  { id: "c", name: "[RBbot] HowToBake", isYou: false, isBot: true, team: 1, joinedAt: 3, color: 2 },
  { id: "d", name: "[RBbot] NULLdoll", isYou: false, isBot: true, team: 1, joinedAt: 4, color: 3 },
];
const settled: BattleResult[] = [
  { playerId: "a", total: 4, pulls: [] },
  { playerId: "b", total: 4, pulls: [] },
  { playerId: "c", total: 4, pulls: [] },
  { playerId: "d", total: 4, pulls: [] },
];
console.log("2v2 crazy 8:8 ->", JSON.stringify(computeOutcome(players, settled, "crazy", true)));
console.log("2v2 standard 8:8 ->", JSON.stringify(computeOutcome(players, settled, "standard", true)));
const settled2: BattleResult[] = [
  { playerId: "a", total: 9, pulls: [] },
  { playerId: "b", total: 4, pulls: [] },
  { playerId: "c", total: 9, pulls: [] },
  { playerId: "d", total: 4, pulls: [] },
];
console.log("2v2 crazy 13:13 ->", JSON.stringify(computeOutcome(players, settled2, "crazy", true)));
console.log("1v1 tie ->", JSON.stringify(computeOutcome(players.slice(0,2), settled.slice(0,2), "standard", false)));
console.log("1v1 crazy win ->", JSON.stringify(computeOutcome(players.slice(0,2), [{playerId:"a",total:2,pulls:[]},{playerId:"b",total:5,pulls:[]}], "crazy", false)));
console.log("split 45 ->", JSON.stringify(splitTeamPot(45, players, [players[0], players[1]], settled)));

// ---- Task 33: payout = total drop value, never the prize pool ----
// example from the user: battle bought for 1000, skins dropped worth 154 -> winner gets 154
const dropResults: BattleResult[] = [
  { playerId: "a", total: 100, pulls: [{ round: 0, skinId: "x", value: 100 }] },
  { playerId: "b", total: 54, pulls: [{ round: 0, skinId: "y", value: 54 }] },
];
console.log("dropTotal [100,54] ->", dropTotal(dropResults), "(expected 154, NOT the entries sum)");
console.log("payout 1v1 -> winner b takes", JSON.stringify({ drops: dropTotal(dropResults) }));
console.log("split 154 ->", JSON.stringify(splitTeamPot(dropTotal(dropResults), players, [players[0], players[1]], dropResults)));
console.log("split 155 (odd remainder to stronger) ->", JSON.stringify(splitTeamPot(155, players, [players[0], players[1]], [{ playerId: "a", total: 9, pulls: [] }, { playerId: "b", total: 4, pulls: [] }])));

// ---- Task 35: takePerPlayer — the TAKE column + profile history source ----
// solo winner takes the whole drop value; losers get nothing (absent from the map)
console.log("takePerPlayer 1v1 (winner b) ->", JSON.stringify(takePerPlayer({ teamMode: false, players: players.slice(0, 2) }, dropResults, ["b"])), "(expected {\"b\":154})");
// 2v2 winners a+b split the drops — even and odd cases
console.log("takePerPlayer 2v2 154 ->", JSON.stringify(takePerPlayer({ teamMode: true, players }, dropResults, ["a", "b"])), "(expected {a:77,b:77})");
console.log("takePerPlayer 2v2 155 ->", JSON.stringify(takePerPlayer({ teamMode: true, players }, [{ playerId: "a", total: 100, pulls: [{ round: 0, skinId: "x", value: 100 }] }, { playerId: "b", total: 55, pulls: [{ round: 0, skinId: "y", value: 55 }] }], ["a", "b"])), "(expected a=78, b=77 — odd coin to the stronger)");

// ---- Task 42: JACKPOT + SHARED pot rules ----
import { drawJackpotWinner, jackpotPct, jackpotWeights, sharedSplit } from "/home/z/my-project/src/lib/battles";
const jp: BattleResult[] = [
  { playerId: "a", total: 60, pulls: [] },
  { playerId: "b", total: 30, pulls: [] },
  { playerId: "c", total: 10, pulls: [] },
];
const jpPlayers = players.slice(0, 3);
const pct = jackpotPct(jpPlayers, jp, false);
console.log("jackpot pct ->", JSON.stringify(pct), "(expected a=60%, b=30%, c=10%)");
const crazyPct = jackpotPct(jpPlayers, jp, true);
console.log("crazy jackpot pct ->", JSON.stringify(crazyPct), "(expected a=10%, b=40%, c=90/90%... c best)");
// sanity: crazy best odds go to the lowest haul (c)
const best = Object.entries(crazyPct).sort((x, y) => y[1] - x[1])[0][0];
console.log("crazy best-odds player ->", best, "(expected c)");
// draw 2000 times: the winner distribution must roughly follow the weights
const w = jackpotWeights(jpPlayers, jp, false);
const tally: Record<string, number> = { a: 0, b: 0, c: 0 };
for (let i = 0; i < 2000; i++) tally[drawJackpotWinner(w)]++;
console.log("draw 2000 ->", JSON.stringify(tally), "(expected a ~1200, b ~600, c ~200)");
// equal totals -> equal weights
const eq = jackpotPct(jpPlayers, [{ playerId: "a", total: 5, pulls: [] }, { playerId: "b", total: 5, pulls: [] }, { playerId: "c", total: 5, pulls: [] }], false);
console.log("equal pct ->", JSON.stringify(eq), "(expected ~33.3 each)");
// shared: equal split with remainder to earliest seats
console.log("shared 100/3 ->", JSON.stringify(sharedSplit(100, jpPlayers)), "(expected a=34,b=33,c=33)");
console.log("shared 154/3 ->", JSON.stringify(sharedSplit(154, jpPlayers)), "(expected a=52,b=51,c=51)");
// shared outcome: everyone is a winner
console.log("shared outcome ->", JSON.stringify(computeOutcome(jpPlayers, jp, "standard", false, "shared")));
// jackpot in team mode: drawn player carries the team
console.log("jackpot 2v2 outcome ->", JSON.stringify(computeOutcome(players, settled2, "standard", true, "jackpot")).slice(0, 80), "...");

// ---- Task 43: 2v2 JACKPOT spins per TEAM ----
import { jackpotTeamPct, jackpotTeamWeights } from "/home/z/my-project/src/lib/battles";
// CT pair unboxes 60+30=90, T pair unboxes 10+0=10 → team odds 90/10
const teamPlayers: BattlePlayer[] = [
  { ...players[0], id: "a", team: 0 },
  { ...players[1], id: "b", team: 0 },
  { ...players[2], id: "c", team: 1 },
  { ...players[3], id: "d", team: 1 },
];
const teamSettled: BattleResult[] = [
  { playerId: "a", total: 60, pulls: [] },
  { playerId: "b", total: 30, pulls: [] },
  { playerId: "c", total: 10, pulls: [] },
  { playerId: "d", total: 0, pulls: [] },
];
const tw = jackpotTeamWeights(teamPlayers, teamSettled, false);
console.log("team weights ->", JSON.stringify(tw), "(expected t0=90, t1=10)");
const tp = jackpotTeamPct(teamPlayers, teamSettled, false);
console.log("team pct ->", JSON.stringify(tp), "(expected t0=90%, t1=10%)");
const teamDrawTally = { t0: 0, t1: 0 };
for (let i = 0; i < 2000; i++) {
  const k = drawJackpotWinner(tw) as "t0" | "t1";
  teamDrawTally[k]++;
}
console.log("team draw 2000 ->", JSON.stringify(teamDrawTally), "(expected t0 ~1800, t1 ~200)");
// crazy inversion at the TEAM level: lowest combined haul draws best
const tpCrazy = jackpotTeamPct(teamPlayers, teamSettled, true);
console.log("team crazy pct ->", JSON.stringify(tpCrazy), "(expected t0=10%, t1=90%)");
