(() => {
  const wraps = [...document.querySelectorAll('div.relative.overflow-hidden.rounded-2xl')];
  const wrap = wraps[0];
  if (!wrap) return JSON.stringify({ err: 'no reel box' });
  const strip = wrap.querySelector('.absolute.flex.will-change-transform');
  if (!strip) return JSON.stringify({ err: 'no strip' });
  const tiles = [...strip.children];
  const winIdx = tiles.findIndex(t => (t.className || '').includes('anim-glow-pulse') || (t.className || '').includes('anim-jackpot-glow') || (t.getAttribute('style') || '').includes('f0b90b'));
  if (winIdx < 0) return JSON.stringify({ err: 'no winner tile', n: tiles.length });
  const wr = wrap.getBoundingClientRect();
  const tr = tiles[winIdx].getBoundingClientRect();
  const t1 = tiles[0].getBoundingClientRect();
  const t2 = tiles[1] ? tiles[1].getBoundingClientRect() : null;
  const item = Math.round(t1.width);
  const gap = t2 ? Math.round(t2.left - t1.right) : 8;
  const offset = Math.round((wr.left + wr.width / 2) - (tr.left + tr.width / 2));
  const dist = item / 2 + gap;
  return JSON.stringify({ winIdx, item, gap, offset, frac: +(offset / dist).toFixed(3) });
})()
