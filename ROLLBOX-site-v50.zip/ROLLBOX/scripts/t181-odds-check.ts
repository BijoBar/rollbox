import { ROLLDROP_CHANCE, rolldropChanceOf } from "../src/lib/rolldrop";
import { CASES } from "../src/lib/cases";
import { REEL_YOU_MS, REEL_OTHER_MS, REEL_STAGGER_MS, ROUND_BEAT_MS, maxReelMs } from "../src/lib/gbattle-shared";

// Task 182 (R40): FAST MODE deleted — only the NORMAL pacing constants remain.
console.log(
  "rolldrop flat:", ROLLDROP_CHANCE,
  "| reel you/other:", REEL_YOU_MS, REEL_OTHER_MS,
  "| stagger:", REEL_STAGGER_MS,
  "| round beat:", ROUND_BEAT_MS,
  "| maxReel(4):", maxReelMs(4),
);
for (const c of CASES) {
  const ch = rolldropChanceOf(c);
  if (ch !== ROLLDROP_CHANCE) console.log("OVERRIDE:", c.id, ch);
}
console.log("total cases:", CASES.length, "(only the TEST override expected above)");
