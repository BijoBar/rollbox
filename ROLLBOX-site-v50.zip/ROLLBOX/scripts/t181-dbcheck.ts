import { PrismaClient } from "@prisma/client";
const p = new PrismaClient();
const player = await p.player.findUnique({ where: { id: "p_t66A" } });
const inv = await p.inventoryItem.count({ where: { playerId: "p_t66A" } });
const rolls = await p.fairRoll.findMany({
  where: { playerId: "p_t66A", game: "upgrader" },
  orderBy: { id: "desc" },
  take: 8,
});
console.log("inventory rows:", inv, "| balance:", player?.balance);
for (const r of rolls) {
  const d = JSON.parse(r.detail) as { win: boolean; chance: number; stake: number };
  console.log(r.id, "mult:", r.ref, "win:", d.win, "chance:", d.chance.toFixed(4), "stake:", d.stake, "nonce:", r.nonce, new Date(r.createdAt).toISOString().slice(11, 19));
}
await p.$disconnect();
