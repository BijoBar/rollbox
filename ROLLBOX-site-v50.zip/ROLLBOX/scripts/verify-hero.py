"""Task 55 verification — the home-page stats strip is 100% DATABASE-real.

Reads /api/stats and asserts the hero renders EXACTLY those values under
the new labels (USERS / CASES OPENED / TOTAL WINS) — after the CountUp
animation settles, reading the DOM's number-above-label order.
"""
import json
import re
import subprocess
import sys
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = Path("/home/z/my-project/download/e2e-shots")
SHOTS.mkdir(parents=True, exist_ok=True)
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS  " if ok else "FAIL  ") + name + ("  — " + detail if detail else ""))

stats = json.loads(subprocess.run(["curl", "-s", BASE + "/api/stats"], capture_output=True, text=True).stdout)
check("stats API responds", all(k in stats for k in ("players", "members", "casesOpened", "coinsPaid")), json.dumps(stats))

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    pg = browser.new_context(viewport={"width": 1440, "height": 900}).new_page()
    pg.goto(BASE + "/", wait_until="domcontentloaded")
    pg.wait_for_timeout(2600)  # let the CountUp animation settle
    body = pg.inner_text("body")

    def dom_value(label):
        # the DOM order is: number \n label
        m = re.search(r"([\d,]+)\s*\n\s*" + label, body)
        return m.group(1) if m else None

    def fresh(label):
        return json.loads(subprocess.run(["curl", "-s", BASE + "/api/stats"], capture_output=True, text=True).stdout)

    def value_matches(label, key, got):
        want = f"{stats[key]:,}"
        return got is not None and got.replace(",", "") == want.replace(",", ""), want

    # the DB can move between the snapshot above and the page's own fetch (a
    # late settle) — the hero's 30s poll must reconcile it; allow one cycle
    ok_users, want_users = value_matches("USERS", "members", dom_value("USERS"))
    ok_cases, want_cases = value_matches("CASES OPENED", "casesOpened", dom_value("CASES OPENED"))
    ok_wins, want_wins = value_matches("TOTAL WINS", "coinsPaid", dom_value("TOTAL WINS"))
    if not (ok_users and ok_cases and ok_wins):
        time.sleep(31)  # one hero refresh cycle
        pg.wait_for_timeout(2000)  # CountUp settles on the refreshed targets
        body = pg.inner_text("body")
        ok_users, want_users = value_matches("USERS", "members", dom_value("USERS"))
        ok_cases, want_cases = value_matches("CASES OPENED", "casesOpened", dom_value("CASES OPENED"))
        ok_wins, want_wins = value_matches("TOTAL WINS", "coinsPaid", dom_value("TOTAL WINS"))

    check("USERS == DB members", ok_users, f"dom={dom_value('USERS')} db={want_users}")
    check("CASES OPENED == DB counter", ok_cases, f"dom={dom_value('CASES OPENED')} db={want_cases}")
    check("TOTAL WINS == DB coinsPaid", ok_wins, f"dom={dom_value('TOTAL WINS')} db={want_wins}")

    check("old labels are gone", "PLAYERS ONLINE" not in body.upper() and "SKINS VALUE WON" not in body.upper())
    pg.screenshot(path=str(SHOTS / "55-hero-stats.png"))
    browser.close()

print("\n===== VERDICT =====")
fails = [r for r in results if not r[1]]
print("RESULT:", "ALL PASS" if not fails else "%d FAILURES" % len(fails))
sys.exit(0 if not fails else 1)
