// ============ USER CASES (Task 76, Task 92: RB-110..RB-120) — DO NOT auto-regenerate ============
// The user's own case definitions for RB-101..RB-120, imported verbatim from
// scripts/user-cases-spec.jsonl (the editor JSONL dialect: n/v/p/w = name /
// value / weight% / wear). Rebuild with:  node scripts/import-user-cases.mjs
//
// - v is the item's coin value OVERRIDE (caseItemValue prefers it) — exactly
//   the number the user typed, cent-precise (0.19 stays 0.19).
// - p is the drop weight in percent (all tables sum to 100).
// - w is the CS2 exterior (FN/MW/FT/WW/BS); absent = no exterior (stickers).
// - Values are typed in Rollboxcoins, the unit the CASE EDITOR displays.
// This file survives `scripts/build-content.mjs` re-runs: the builder only
// regenerates generated-cases.ts, and src/lib/cases.ts merges THIS overlay
// on top (by case code) after every rebuild.

import type { CaseDef, Rarity, WeaponKind } from "./cases";

/** Skins the user's items need that generated-cases.ts doesn't already carry
 *  (values are the catalog's coin value — case items always override). */
export const USER_SKINS: Record<string, { id: string; name: string; weapon: WeaponKind; rarity: Rarity; value: number; colors: [string, string] }> = {
  "p250-asiimov": { id: "p250-asiimov", name: "P250 | Asiimov", weapon: "p250" as WeaponKind, rarity: "classified", value: 127, colors: ["#d32ce6", "#14101f"] },
  "desert-eagle-heat-treated": { id: "desert-eagle-heat-treated", name: "Desert Eagle | Heat Treated", weapon: "deagle" as WeaponKind, rarity: "classified", value: 11, colors: ["#d32ce6", "#14101f"] },
  "mp9-green-plaid": { id: "mp9-green-plaid", name: "MP9 | Green Plaid", weapon: "mp9" as WeaponKind, rarity: "consumer", value: 38, colors: ["#b0c3d9", "#14101f"] },
  "p250-franklin": { id: "p250-franklin", name: "P250 | Franklin", weapon: "p250" as WeaponKind, rarity: "classified", value: 14, colors: ["#d32ce6", "#14101f"] },
  "ak-47-cartel": { id: "ak-47-cartel", name: "AK-47 | Cartel", weapon: "ak" as WeaponKind, rarity: "classified", value: 167, colors: ["#d32ce6", "#14101f"] },
  "p250-cartel": { id: "p250-cartel", name: "P250 | Cartel", weapon: "p250" as WeaponKind, rarity: "classified", value: 102, colors: ["#d32ce6", "#14101f"] },
  "sg-553-dragon-tech": { id: "sg-553-dragon-tech", name: "SG 553 | Dragon Tech", weapon: "galil" as WeaponKind, rarity: "restricted", value: 4, colors: ["#8847ff", "#14101f"] },
  "ssg-08-dragonfire": { id: "ssg-08-dragonfire", name: "SSG 08 | Dragonfire", weapon: "awp" as WeaponKind, rarity: "covert", value: 2469, colors: ["#eb4b4b", "#14101f"] },
  "ssg-08-acid-fade": { id: "ssg-08-acid-fade", name: "SSG 08 | Acid Fade", weapon: "awp" as WeaponKind, rarity: "milspec", value: 8, colors: ["#4b69ff", "#14101f"] },
  "sawed-off-amber-fade": { id: "sawed-off-amber-fade", name: "Sawed-Off | Amber Fade", weapon: "ak" as WeaponKind, rarity: "milspec", value: 2, colors: ["#4b69ff", "#14101f"] },
  "p2000-amber-fade": { id: "p2000-amber-fade", name: "P2000 | Amber Fade", weapon: "usp" as WeaponKind, rarity: "restricted", value: 5, colors: ["#8847ff", "#14101f"] },
  "galil-ar-amber-fade": { id: "galil-ar-amber-fade", name: "Galil AR | Amber Fade", weapon: "galil" as WeaponKind, rarity: "milspec", value: 77, colors: ["#4b69ff", "#14101f"] },
  "mac-10-fade": { id: "mac-10-fade", name: "MAC-10 | Fade", weapon: "mp9" as WeaponKind, rarity: "milspec", value: 508, colors: ["#4b69ff", "#14101f"] },
  "desert-eagle-crimson-web": { id: "desert-eagle-crimson-web", name: "Desert Eagle | Crimson Web", weapon: "deagle" as WeaponKind, rarity: "restricted", value: 116, colors: ["#8847ff", "#14101f"] },
  "p250-crimson-kimono": { id: "p250-crimson-kimono", name: "P250 | Crimson Kimono", weapon: "p250" as WeaponKind, rarity: "consumer", value: 116, colors: ["#b0c3d9", "#14101f"] },
  "navaja-knife-crimson-web": { id: "navaja-knife-crimson-web", name: "★ Navaja Knife | Crimson Web", weapon: "ak" as WeaponKind, rarity: "contraband", value: 560, colors: ["#ffd700", "#14101f"] },
  "shadow-daggers-crimson-web": { id: "shadow-daggers-crimson-web", name: "★ Shadow Daggers | Crimson Web", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 685, colors: ["#ffd700", "#14101f"] },
  "specialist-gloves-crimson-web": { id: "specialist-gloves-crimson-web", name: "★ Specialist Gloves | Crimson Web", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 1019, colors: ["#ffd700", "#14101f"] },
  "ump-45-moonrise": { id: "ump-45-moonrise", name: "UMP-45 | Moonrise", weapon: "mp9" as WeaponKind, rarity: "restricted", value: 6, colors: ["#8847ff", "#14101f"] },
  "glock-18-moonrise": { id: "glock-18-moonrise", name: "Glock-18 | Moonrise", weapon: "glock" as WeaponKind, rarity: "restricted", value: 9, colors: ["#8847ff", "#14101f"] },
  "glock-18-vogue": { id: "glock-18-vogue", name: "Glock-18 | Vogue", weapon: "glock" as WeaponKind, rarity: "classified", value: 40, colors: ["#d32ce6", "#14101f"] },
  "desert-eagle-starcade": { id: "desert-eagle-starcade", name: "Desert Eagle | Starcade", weapon: "deagle" as WeaponKind, rarity: "classified", value: 340, colors: ["#d32ce6", "#14101f"] },
  "shadow-daggers-gamma-doppler-5": { id: "shadow-daggers-gamma-doppler-5", name: "★ Shadow Daggers | Gamma Doppler", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 1077, colors: ["#ffd700", "#14101f"] },
  "gut-knife-doppler-7": { id: "gut-knife-doppler-7", name: "★ Gut Knife | Doppler", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 1219, colors: ["#ffd700", "#14101f"] },
  "nomad-knife-doppler-7": { id: "nomad-knife-doppler-7", name: "★ Nomad Knife | Doppler", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 3896, colors: ["#ffd700", "#14101f"] },
  "glock-18-warhawk": { id: "glock-18-warhawk", name: "Glock-18 | Warhawk", weapon: "glock" as WeaponKind, rarity: "milspec", value: 3, colors: ["#4b69ff", "#14101f"] },
  "glock-18-oxide-blaze": { id: "glock-18-oxide-blaze", name: "Glock-18 | Oxide Blaze", weapon: "glock" as WeaponKind, rarity: "milspec", value: 2, colors: ["#4b69ff", "#14101f"] },
  "mp9-broken-record": { id: "mp9-broken-record", name: "MP9 | Broken Record", weapon: "mp9" as WeaponKind, rarity: "milspec", value: 1, colors: ["#4b69ff", "#14101f"] },
  "ak-47-rat-rod": { id: "ak-47-rat-rod", name: "AK-47 | Rat Rod", weapon: "ak" as WeaponKind, rarity: "restricted", value: 36, colors: ["#8847ff", "#14101f"] },
  "five-seven-case-hardened": { id: "five-seven-case-hardened", name: "Five-SeveN | Case Hardened", weapon: "glock" as WeaponKind, rarity: "restricted", value: 109, colors: ["#8847ff", "#14101f"] },
  "mac-10-case-hardened": { id: "mac-10-case-hardened", name: "MAC-10 | Case Hardened", weapon: "mp9" as WeaponKind, rarity: "restricted", value: 239, colors: ["#8847ff", "#14101f"] },
  "huntsman-knife-case-hardened": { id: "huntsman-knife-case-hardened", name: "★ Huntsman Knife | Case Hardened", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 1602, colors: ["#ffd700", "#14101f"] },
  "usp-s-check-engine": { id: "usp-s-check-engine", name: "USP-S | Check Engine", weapon: "usp" as WeaponKind, rarity: "milspec", value: 5, colors: ["#4b69ff", "#14101f"] },
  "mag-7-heat": { id: "mag-7-heat", name: "MAG-7 | Heat", weapon: "ak" as WeaponKind, rarity: "restricted", value: 13, colors: ["#8847ff", "#14101f"] },
  "mac-10-carnivore": { id: "mac-10-carnivore", name: "MAC-10 | Carnivore", weapon: "mp9" as WeaponKind, rarity: "milspec", value: 3, colors: ["#4b69ff", "#14101f"] },
  "p2000-obsidian": { id: "p2000-obsidian", name: "P2000 | Obsidian", weapon: "usp" as WeaponKind, rarity: "restricted", value: 23, colors: ["#8847ff", "#14101f"] },
  "xm1014-tranquility": { id: "xm1014-tranquility", name: "XM1014 | Tranquility", weapon: "ak" as WeaponKind, rarity: "classified", value: 106, colors: ["#d32ce6", "#14101f"] },
  "p250-muertos": { id: "p250-muertos", name: "P250 | Muertos", weapon: "p250" as WeaponKind, rarity: "classified", value: 124, colors: ["#d32ce6", "#14101f"] },
  "m4a4-hellish": { id: "m4a4-hellish", name: "M4A4 | Hellish", weapon: "m4" as WeaponKind, rarity: "classified", value: 117, colors: ["#d32ce6", "#14101f"] },
  "m4a4-hellfire": { id: "m4a4-hellfire", name: "M4A4 | Hellfire", weapon: "m4" as WeaponKind, rarity: "classified", value: 730, colors: ["#d32ce6", "#14101f"] },
  "mp9-hot-rod": { id: "mp9-hot-rod", name: "MP9 | Hot Rod", weapon: "mp9" as WeaponKind, rarity: "milspec", value: 2161, colors: ["#4b69ff", "#14101f"] },
  "sticker-hellraisers-katowice-2014": { id: "sticker-hellraisers-katowice-2014", name: "Sticker | HellRaisers | Katowice 2014", weapon: "sticker" as WeaponKind, rarity: "milspec", value: 1, colors: ["#4b69ff", "#14101f"] },
  "sticker-neon-mvp-lenticular": { id: "sticker-neon-mvp-lenticular", name: "Sticker | Neon MVP (Lenticular)", weapon: "sticker" as WeaponKind, rarity: "covert", value: 43, colors: ["#eb4b4b", "#14101f"] },
  "mp5-sd-phosphor": { id: "mp5-sd-phosphor", name: "MP5-SD | Phosphor", weapon: "mp9" as WeaponKind, rarity: "classified", value: 46, colors: ["#d32ce6", "#14101f"] },
  "awp-neo-noir": { id: "awp-neo-noir", name: "AWP | Neo-Noir", weapon: "awp" as WeaponKind, rarity: "covert", value: 416, colors: ["#eb4b4b", "#14101f"] },
  "m4a4-desolate-space": { id: "m4a4-desolate-space", name: "M4A4 | Desolate Space", weapon: "m4" as WeaponKind, rarity: "classified", value: 119, colors: ["#d32ce6", "#14101f"] },
  "ak-47-nightwish": { id: "ak-47-nightwish", name: "AK-47 | Nightwish", weapon: "ak" as WeaponKind, rarity: "covert", value: 656, colors: ["#eb4b4b", "#14101f"] },
  "ak-47-neon-revolution": { id: "ak-47-neon-revolution", name: "AK-47 | Neon Revolution", weapon: "ak" as WeaponKind, rarity: "covert", value: 1189, colors: ["#eb4b4b", "#14101f"] },
  "galil-ar-galigator": { id: "galil-ar-galigator", name: "Galil AR | Galigator", weapon: "galil" as WeaponKind, rarity: "restricted", value: 5, colors: ["#8847ff", "#14101f"] },
  "ak-47-emerald-pinstripe": { id: "ak-47-emerald-pinstripe", name: "AK-47 | Emerald Pinstripe", weapon: "ak" as WeaponKind, rarity: "restricted", value: 20, colors: ["#8847ff", "#14101f"] },
  "awp-green-energy": { id: "awp-green-energy", name: "AWP | Green Energy", weapon: "awp" as WeaponKind, rarity: "classified", value: 46, colors: ["#d32ce6", "#14101f"] },
  "awp-atheris": { id: "awp-atheris", name: "AWP | Atheris", weapon: "awp" as WeaponKind, rarity: "restricted", value: 36, colors: ["#8847ff", "#14101f"] },
  "m4a4-full-throttle": { id: "m4a4-full-throttle", name: "M4A4 | Full Throttle", weapon: "m4" as WeaponKind, rarity: "covert", value: 263, colors: ["#eb4b4b", "#14101f"] },
  "shadow-daggers-gamma-doppler": { id: "shadow-daggers-gamma-doppler", name: "★ Shadow Daggers | Gamma Doppler Emerald", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 1077, colors: ["#ffd700", "#14101f"] },
  "glock-18-gamma-doppler": { id: "glock-18-gamma-doppler", name: "Glock-18 | Gamma Doppler Emerald", weapon: "glock" as WeaponKind, rarity: "covert", value: 756, colors: ["#eb4b4b", "#14101f"] },
  "usp-s-blood-tiger": { id: "usp-s-blood-tiger", name: "USP-S | Blood Tiger", weapon: "usp" as WeaponKind, rarity: "milspec", value: 29, colors: ["#4b69ff", "#14101f"] },
  "navaja-knife-tiger-tooth": { id: "navaja-knife-tiger-tooth", name: "★ Navaja Knife | Tiger Tooth", weapon: "ak" as WeaponKind, rarity: "contraband", value: 705, colors: ["#ffd700", "#14101f"] },
  "shadow-daggers-tiger-tooth": { id: "shadow-daggers-tiger-tooth", name: "★ Shadow Daggers | Tiger Tooth", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 700, colors: ["#ffd700", "#14101f"] },
  "falchion-knife-tiger-tooth": { id: "falchion-knife-tiger-tooth", name: "★ Falchion Knife | Tiger Tooth", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 1417, colors: ["#ffd700", "#14101f"] },
  "mag-7-monster-call": { id: "mag-7-monster-call", name: "MAG-7 | Monster Call", weapon: "ak" as WeaponKind, rarity: "restricted", value: 4, colors: ["#8847ff", "#14101f"] },
  "xm1014-monster-melt": { id: "xm1014-monster-melt", name: "XM1014 | Monster Melt", weapon: "ak" as WeaponKind, rarity: "restricted", value: 15, colors: ["#8847ff", "#14101f"] },
  "usp-s-jawbreaker": { id: "usp-s-jawbreaker", name: "USP-S | Jawbreaker", weapon: "usp" as WeaponKind, rarity: "classified", value: 32, colors: ["#d32ce6", "#14101f"] },
  "dual-berettas-flora-carnivora": { id: "dual-berettas-flora-carnivora", name: "Dual Berettas | Flora Carnivora", weapon: "glock" as WeaponKind, rarity: "restricted", value: 4, colors: ["#8847ff", "#14101f"] },
  "sawed-off-devourer": { id: "sawed-off-devourer", name: "Sawed-Off | Devourer", weapon: "ak" as WeaponKind, rarity: "classified", value: 56, colors: ["#d32ce6", "#14101f"] },
  "awp-containment-breach": { id: "awp-containment-breach", name: "AWP | Containment Breach", weapon: "awp" as WeaponKind, rarity: "covert", value: 441, colors: ["#eb4b4b", "#14101f"] },
  "sg-553-colony-iv": { id: "sg-553-colony-iv", name: "SG 553 | Colony IV", weapon: "galil" as WeaponKind, rarity: "classified", value: 57, colors: ["#d32ce6", "#14101f"] },
  "galil-ar-cerberus": { id: "galil-ar-cerberus", name: "Galil AR | Cerberus", weapon: "galil" as WeaponKind, rarity: "restricted", value: 178, colors: ["#8847ff", "#14101f"] },
  "sport-gloves-bronze-morph": { id: "sport-gloves-bronze-morph", name: "★ Sport Gloves | Bronze Morph", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 796, colors: ["#ffd700", "#14101f"] },
  "awp-arsenic-spill": { id: "awp-arsenic-spill", name: "AWP | Arsenic Spill", weapon: "awp" as WeaponKind, rarity: "milspec", value: 3, colors: ["#4b69ff", "#14101f"] },
  "awp-pit-viper": { id: "awp-pit-viper", name: "AWP | Pit Viper", weapon: "awp" as WeaponKind, rarity: "restricted", value: 9, colors: ["#8847ff", "#14101f"] },
  "awp-worm-god": { id: "awp-worm-god", name: "AWP | Worm God", weapon: "awp" as WeaponKind, rarity: "restricted", value: 23, colors: ["#8847ff", "#14101f"] },
  "awp-mortis": { id: "awp-mortis", name: "AWP | Mortis", weapon: "awp" as WeaponKind, rarity: "classified", value: 50, colors: ["#d32ce6", "#14101f"] },
  "awp-exoskeleton": { id: "awp-exoskeleton", name: "AWP | Exoskeleton", weapon: "awp" as WeaponKind, rarity: "restricted", value: 40, colors: ["#8847ff", "#14101f"] },
  "awp-elite-build": { id: "awp-elite-build", name: "AWP | Elite Build", weapon: "awp" as WeaponKind, rarity: "classified", value: 120, colors: ["#d32ce6", "#14101f"] },
  "awp-crakow": { id: "awp-crakow", name: "AWP | Crakow!", weapon: "awp" as WeaponKind, rarity: "classified", value: 176, colors: ["#d32ce6", "#14101f"] },
  "awp-pink-ddpat": { id: "awp-pink-ddpat", name: "AWP | Pink DDPAT", weapon: "awp" as WeaponKind, rarity: "restricted", value: 235, colors: ["#8847ff", "#14101f"] },
  "awp-queen-s-gambit": { id: "awp-queen-s-gambit", name: "AWP | Queen's Gambit", weapon: "awp" as WeaponKind, rarity: "covert", value: 413, colors: ["#eb4b4b", "#14101f"] },
  "awp-longdog": { id: "awp-longdog", name: "AWP | LongDog", weapon: "awp" as WeaponKind, rarity: "covert", value: 395, colors: ["#eb4b4b", "#14101f"] },
  "awp-sovereign-flame": { id: "awp-sovereign-flame", name: "AWP | Sovereign Flame", weapon: "awp" as WeaponKind, rarity: "covert", value: 876, colors: ["#eb4b4b", "#14101f"] },
  "awp-cmyk": { id: "awp-cmyk", name: "AWP | CMYK", weapon: "awp" as WeaponKind, rarity: "covert", value: 933, colors: ["#eb4b4b", "#14101f"] },
  "ak-47-varicamo-grey": { id: "ak-47-varicamo-grey", name: "AK-47 | VariCamo Grey", weapon: "ak" as WeaponKind, rarity: "consumer", value: 1, colors: ["#b0c3d9", "#14101f"] },
  "ak-47-elite-build": { id: "ak-47-elite-build", name: "AK-47 | Elite Build", weapon: "ak" as WeaponKind, rarity: "milspec", value: 15, colors: ["#4b69ff", "#14101f"] },
  "ak-47-steel-delta": { id: "ak-47-steel-delta", name: "AK-47 | Steel Delta", weapon: "ak" as WeaponKind, rarity: "milspec", value: 15, colors: ["#4b69ff", "#14101f"] },
  "ak-47-slate": { id: "ak-47-slate", name: "AK-47 | Slate", weapon: "ak" as WeaponKind, rarity: "restricted", value: 35, colors: ["#8847ff", "#14101f"] },
  "ak-47-nouveau-rouge": { id: "ak-47-nouveau-rouge", name: "AK-47 | Nouveau Rouge", weapon: "ak" as WeaponKind, rarity: "classified", value: 55, colors: ["#d32ce6", "#14101f"] },
  "ak-47-phantom-disruptor": { id: "ak-47-phantom-disruptor", name: "AK-47 | Phantom Disruptor", weapon: "ak" as WeaponKind, rarity: "classified", value: 58, colors: ["#d32ce6", "#14101f"] },
  "ak-47-the-oligarch": { id: "ak-47-the-oligarch", name: "AK-47 | The Oligarch", weapon: "ak" as WeaponKind, rarity: "covert", value: 300, colors: ["#eb4b4b", "#14101f"] },
  "ak-47-consequence-of-the-jinn": { id: "ak-47-consequence-of-the-jinn", name: "AK-47 | Consequence of the Jinn", weapon: "ak" as WeaponKind, rarity: "covert", value: 822, colors: ["#eb4b4b", "#14101f"] },
  "ak-47-vulcan": { id: "ak-47-vulcan", name: "AK-47 | Vulcan", weapon: "ak" as WeaponKind, rarity: "covert", value: 1139, colors: ["#eb4b4b", "#14101f"] },
  "navaja-knife-rust-coat": { id: "navaja-knife-rust-coat", name: "★ Navaja Knife | Rust Coat", weapon: "ak" as WeaponKind, rarity: "contraband", value: 398, colors: ["#ffd700", "#14101f"] },
  "navaja-knife-safari-mesh": { id: "navaja-knife-safari-mesh", name: "★ Navaja Knife | Safari Mesh", weapon: "ak" as WeaponKind, rarity: "contraband", value: 405, colors: ["#ffd700", "#14101f"] },
  "shadow-daggers-safari-mesh": { id: "shadow-daggers-safari-mesh", name: "★ Shadow Daggers | Safari Mesh", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 414, colors: ["#ffd700", "#14101f"] },
  "paracord-knife-rust-coat": { id: "paracord-knife-rust-coat", name: "★ Paracord Knife | Rust Coat", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 436, colors: ["#ffd700", "#14101f"] },
  "navaja-knife-ultraviolet": { id: "navaja-knife-ultraviolet", name: "★ Navaja Knife | Ultraviolet", weapon: "ak" as WeaponKind, rarity: "contraband", value: 465, colors: ["#ffd700", "#14101f"] },
  "shadow-daggers-autotronic": { id: "shadow-daggers-autotronic", name: "★ Shadow Daggers | Autotronic", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 493, colors: ["#ffd700", "#14101f"] },
  "shadow-daggers-lore": { id: "shadow-daggers-lore", name: "★ Shadow Daggers | Lore", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 531, colors: ["#ffd700", "#14101f"] },
  "shadow-daggers-marble-fade": { id: "shadow-daggers-marble-fade", name: "★ Shadow Daggers | Marble Fade", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 940, colors: ["#ffd700", "#14101f"] },
  "flip-knife-black-laminate": { id: "flip-knife-black-laminate", name: "★ Flip Knife | Black Laminate", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 1262, colors: ["#ffd700", "#14101f"] },
  "flip-knife-bright-water": { id: "flip-knife-bright-water", name: "★ Flip Knife | Bright Water", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 1347, colors: ["#ffd700", "#14101f"] },
  "gut-knife-fade": { id: "gut-knife-fade", name: "★ Gut Knife | Fade", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 1342, colors: ["#ffd700", "#14101f"] },
  "falchion-knife-gamma-doppler-4": { id: "falchion-knife-gamma-doppler-4", name: "★ Falchion Knife | Gamma Doppler Phase 3", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 2267, colors: ["#ffd700", "#14101f"] },
  "huntsman-knife-fade": { id: "huntsman-knife-fade", name: "★ Huntsman Knife | Fade", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 2466, colors: ["#ffd700", "#14101f"] },
  "bayonet-tiger-tooth": { id: "bayonet-tiger-tooth", name: "★ Bayonet | Tiger Tooth", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 2821, colors: ["#ffd700", "#14101f"] },
  "huntsman-knife-gamma-doppler": { id: "huntsman-knife-gamma-doppler", name: "★ Huntsman Knife | Gamma Doppler Emerald", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 2172, colors: ["#ffd700", "#14101f"] },
  "hand-wraps-arboreal": { id: "hand-wraps-arboreal", name: "★ Hand Wraps | Arboreal", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 428, colors: ["#ffd700", "#14101f"] },
  "moto-gloves-3rd-commando-company": { id: "moto-gloves-3rd-commando-company", name: "★ Moto Gloves | 3rd Commando Company", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 431, colors: ["#ffd700", "#14101f"] },
  "hand-wraps-giraffe": { id: "hand-wraps-giraffe", name: "★ Hand Wraps | Giraffe", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 422, colors: ["#ffd700", "#14101f"] },
  "broken-fang-gloves-needle-point": { id: "broken-fang-gloves-needle-point", name: "★ Broken Fang Gloves | Needle Point", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 467, colors: ["#ffd700", "#14101f"] },
  "moto-gloves-pow": { id: "moto-gloves-pow", name: "★ Moto Gloves | POW!", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 488, colors: ["#ffd700", "#14101f"] },
  "moto-gloves-smoke-out": { id: "moto-gloves-smoke-out", name: "★ Moto Gloves | Smoke Out", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 834, colors: ["#ffd700", "#14101f"] },
  "specialist-gloves-mogul": { id: "specialist-gloves-mogul", name: "★ Specialist Gloves | Mogul", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 827, colors: ["#ffd700", "#14101f"] },
  "bloodhound-gloves-guerrilla": { id: "bloodhound-gloves-guerrilla", name: "★ Bloodhound Gloves | Guerrilla", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 804, colors: ["#ffd700", "#14101f"] },
  "sport-gloves-red-racer": { id: "sport-gloves-red-racer", name: "★ Sport Gloves | Red Racer", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 1152, colors: ["#ffd700", "#14101f"] },
  "sport-gloves-violet-beadwork": { id: "sport-gloves-violet-beadwork", name: "★ Sport Gloves | Violet Beadwork", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 1797, colors: ["#ffd700", "#14101f"] },
  "sport-gloves-amphibious": { id: "sport-gloves-amphibious", name: "★ Sport Gloves | Amphibious", weapon: "gloves" as WeaponKind, rarity: "contraband", value: 2175, colors: ["#ffd700", "#14101f"] },
  "mac-10-gold-brick": { id: "mac-10-gold-brick", name: "MAC-10 | Gold Brick", weapon: "mp9" as WeaponKind, rarity: "restricted", value: 304, colors: ["#8847ff", "#14101f"] },
  "m4a1-s-golden-coil": { id: "m4a1-s-golden-coil", name: "M4A1-S | Golden Coil", weapon: "m4" as WeaponKind, rarity: "covert", value: 504, colors: ["#eb4b4b", "#14101f"] },
  "huntsman-knife-lore": { id: "huntsman-knife-lore", name: "★ Huntsman Knife | Lore", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 817, colors: ["#ffd700", "#14101f"] },
  "bayonet-lore": { id: "bayonet-lore", name: "★ Bayonet | Lore", weapon: "bayonet" as WeaponKind, rarity: "contraband", value: 2286, colors: ["#ffd700", "#14101f"] },
  "m4a4-urban-ddpat": { id: "m4a4-urban-ddpat", name: "M4A4 | Urban DDPAT", weapon: "m4" as WeaponKind, rarity: "consumer", value: 1, colors: ["#b0c3d9", "#14101f"] },
  "desert-eagle-urban-ddpat": { id: "desert-eagle-urban-ddpat", name: "Desert Eagle | Urban DDPAT", weapon: "deagle" as WeaponKind, rarity: "consumer", value: 14, colors: ["#b0c3d9", "#14101f"] },
  "galil-ar-urban-rubble": { id: "galil-ar-urban-rubble", name: "Galil AR | Urban Rubble", weapon: "galil" as WeaponKind, rarity: "consumer", value: 71, colors: ["#b0c3d9", "#14101f"] },
  "shadow-daggers-urban-masked": { id: "shadow-daggers-urban-masked", name: "★ Shadow Daggers | Urban Masked", weapon: "karambit" as WeaponKind, rarity: "contraband", value: 475, colors: ["#ffd700", "#14101f"] },
  "nova-smart-gun": { id: "nova-smart-gun", name: "Nova | Smart Gun", weapon: "ak" as WeaponKind, rarity: "restricted", value: 20, colors: ["#8847ff", "#14101f"] },
  "cz75-auto-hydraulics": { id: "cz75-auto-hydraulics", name: "CZ75-Auto | Hydraulics", weapon: "glock" as WeaponKind, rarity: "restricted", value: 24, colors: ["#8847ff", "#14101f"] },
  "m4a4-dark-operative": { id: "m4a4-dark-operative", name: "M4A4 | Dark Operative", weapon: "m4" as WeaponKind, rarity: "milspec", value: 2, colors: ["#4b69ff", "#14101f"] },
  "desert-eagle-night-heist": { id: "desert-eagle-night-heist", name: "Desert Eagle | Night Heist", weapon: "deagle" as WeaponKind, rarity: "milspec", value: 167, colors: ["#4b69ff", "#14101f"] },
  "galil-ar-rainbow-spoon": { id: "galil-ar-rainbow-spoon", name: "Galil AR | Rainbow Spoon", weapon: "galil" as WeaponKind, rarity: "classified", value: 217, colors: ["#d32ce6", "#14101f"] },
  "five-seven-heat-treated": { id: "five-seven-heat-treated", name: "Five-SeveN | Heat Treated", weapon: "glock" as WeaponKind, rarity: "restricted", value: 25, colors: ["#8847ff", "#14101f"] },
  "nova-polar-mesh": { id: "nova-polar-mesh", name: "Nova | Polar Mesh", weapon: "ak" as WeaponKind, rarity: "consumer", value: 1, colors: ["#b0c3d9", "#14101f"] },
  "g3sg1-polar-camo": { id: "g3sg1-polar-camo", name: "G3SG1 | Polar Camo", weapon: "awp" as WeaponKind, rarity: "consumer", value: 1, colors: ["#b0c3d9", "#14101f"] },
  "famas-yeti-camo": { id: "famas-yeti-camo", name: "FAMAS | Yeti Camo", weapon: "galil" as WeaponKind, rarity: "milspec", value: 1, colors: ["#4b69ff", "#14101f"] },
  "ump-45-arctic-wolf": { id: "ump-45-arctic-wolf", name: "UMP-45 | Arctic Wolf", weapon: "mp9" as WeaponKind, rarity: "restricted", value: 3, colors: ["#8847ff", "#14101f"] },
  "aug-arctic-wolf": { id: "aug-arctic-wolf", name: "AUG | Arctic Wolf", weapon: "m4" as WeaponKind, rarity: "restricted", value: 15, colors: ["#8847ff", "#14101f"] },
};

/** Steam CDN renders for the user-case skins (merged by skin-images.ts). */
export const USER_SKIN_IMAGES: Record<string, string> = {
  "p250-asiimov": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhzMOwwiFO0OL8PfRSIeOaB2qf19F6ueZhW2fixx53tWqEm4ugeXuebQN0CZJyRrMJuxm4loCyPr_i51TfjtgXzi79kGoXuUXmUJzm",
  "ak-47-asiimov": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0POlPPNSIeOaB2qf19F6ueZhW2e2wEt-t2jcytf6dymSO1JxA5oiRecLsRa5kIfkYr-241aLgotHz3-rkGoXuUp8oX57",
  "awp-asiimov": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V6V-Kf2cGFidxOp_pewnF3nhxEt0sGnSzN76dH3GOg9xC8FyEORftRe-x9PuYurq71bW3d8UnjK-0H0YSTpMGQ",
  "p90-asiimov": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhx8bf_jdk_6v-JaV-KfmeAXGvzedxuPUnTSjikRgksjuBzoz4dXLFb1QoC8QlTLQD4EPqk4LvN-Pns1aMioNBzTK-0H3gQVv65g",
  "desert-eagle-heat-treated": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk7uORbKFsJ_yWMWSR0utJuOB7Syy9kBkY4QKJk4jxNWXGbQZ0CZpyTeBf4xO4m9y1Nuy05wHYg4lNySWr3C1Luyhu4LkKA6As5OSJ2JAJXn6j",
  "mp9-green-plaid": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8js_f9Ttk__6vYaA_H_yaCW-Ej7outuQ8GHrjwkwl52zVno2peXqVbwYoX8N3ReFcsUK7l9PiPuzitgLAy9US-C_U3wM",
  "p250-franklin": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhzMOwwiFO0P-hZqF0H_yaCW-Ej70htLhtF3Dgx0Vz5WrWwtf4JCjEPA8oDZF4FrRZ5xnulNy1Zrvn5wHAy9USTWvgE_Q",
  "dual-berettas-cartel": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL0kp_0-B1a_s2qfaVhIvWBC3OEwP1Js-B7Wyy_qhEutDWR1I38I3yROgAmDZIjFuEJ50S6lNLvMuKx5lPbj9gRySz92HhKuiZp5ekcEf1yPnX3Fyc",
  "usp-s-printstream": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLkjYbf7itX6vytbbZSI-WsG3SA_v5kue99XD2hkBwqjDGMnYftb3yUPFR0XsNyRrNc5kO5ltziMenr5lONj4kXyi2riywc7y9o5LtQAqQ7uvqAkScWnv4",
  "desert-eagle-printstream": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk7OeRbKFsJ8-DHG6e1f1iouRoQha_nBovp3OGmdeqInyVP1V0XsYlRbEI50a5wNyzZr605AyI3t5MmCSohylAuC89_a9cBoMY9UkV",
  "awp-printstream": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_DVL0OK8Yap5M-SBC2ad_uJ_t-l9AX_qlk4k5GyAzo6ocC-QZgZxX8AjEbZY5xnrxtPjM7vnsgGIj9oTmXngznQeg3pfcPs",
  "m4a1-s-printstream": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwjFS4_ega6F_H_OGMWrEwL9lj_F7Rienhgk1tjyIpYPwJiPTcAAoCpsiEO5ZsUbpm9C2Zuni4VHW3o5EzSX62HxP7Sg96-hWVqYi_6TJz1aW0nxrkGs",
  "ak-47-cartel": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiNK0POlPPNSI_GBGmKc_uJ_t-l9ASuywktwtW3dwt79eX6fZlUiCJJ1RbUPtkW8w4LiZe_i4ATYjN8WmH7gznQeZkk4ehM",
  "p250-cartel": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhzMOwwiNK0OL8PfRSI_GBGmKc_uJ_t-l9AX2wlh906m7Uy4v_cXqWaA4gCpUmQLMNsBO_ltfiYuPltAHbgthGmyzgznQeqxXZ9kg",
  "sticker-dragon": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJai0ki7VeTHjMikJm-e5ERsy4T1-kryTRi-moTh-i1Voav_avQ8d6bKWGTDlOgutrU6HivlzR8i6jnczYn8dCiQPFQoApt2RbIU8k7v49P4ENM",
  "sg-553-dragon-tech": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLimcO1qx1Y-s29b_E4c8-QF2WV09FyouBuQCeMmRQguynLw9ygIHnGbgYlDpciEeBYsEPux9ThMuOz4ACLjY1FmX-viitMvCZp5_FCD_QeAJd5TA",
  "zeus-x27-dragon-snore": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLln4Xl7x1Y-s2hfqF_MPGAHViU0-9xv-9WVSymhiIrujqNjsH6dH7FOA8pXJZ0Q-MPshe-lte0Pu6z7lbXio5GmSv83yNJ73k54rlWT-N7rWv6YDXa",
  "desert-eagle-kumicho-dragon": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk7uORbKF-JeKHC2aXzetJu_RkRiq7mhk1sjqKlLD1KCzPKhh0CcBwQLVe5BHrloKyZOnr5w3XiYhDnC39iCpK7X1psrlUWaFw8qXekUifZlV_fDVZ",
  "p2000-imperial-dragon": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL5lYayrXIL0PW9V7Q_cKDDMW6d0etkueBlcC2hlBoovQKJk4jxNWXEbAQmDsQmRbNYsxGwxoC1YrvrsQXXg40QxCX533tJ7Xs-4eYKWKAl5OSJ2JuLIVNl",
  "glock-18-dragon-tattoo": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2kpnj9h1a4s2qeqVqL_6sCWufwuVJvOhuRz39xUl-6miDzI37dHyXOlIkA8MmROVfshO9w9G1Ye-ztgPX34tEyi74jjQJsHi_DRfxVg",
  "ssg-08-dragonfire": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLijZGwpR1Y-s29e6M9eM-XHGaXzuBwufNscDqwmg0ijDGMnYftbyrFPVAoWcQjELQOuxO4k4e1N-nnsQfW2I5Mz3ivi3wb7Stj5ukAUKY7uvqAqS55_Pw",
  "ssg-08-acid-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLijZGwpR1a7s2oaaBoH_eBD3SDze94tN5lRi67gVN05G3QzI6pIn2UOAYhDJMjEeANsBbtlYC2ZbvltA2P2I5FyHmq2Hka8G81tCngBDgW",
  "sawed-off-amber-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLin4Hl-S1d6c2vaZtrIfSWMWqV1e96vOhqcCW6khUz_TuHwt2odHKROA90WZN2Fu4DsEO-mtTlNLiws1SNi99NxHmtj3tI5n11o7FVJSB89LY",
  "p2000-amber-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL5lYayrXIL0POvV6JsJPWsA2KEwOJ6ueJWQyC0nQlpsjvcmd_7dHyVZgdxAsB1QeRZ5BPqlYbmNuvr5lTW2o1Myyyt3ykY7DErvbib25P3aA",
  "r8-revolver-amber-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLjm4Dv8TRe_c2vaZtrIfSWMWqV1e96vOhqcDu2gxIrpTiXpYPwJiPTcAIpDJckF-9cuhfqltDuZujgs1DZj4hDy338jnhM73xusOcKVaos-qPJz1aW9R0yRq8",
  "galil-ar-amber-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2n5rp8SNJ0POvV6JsJPWsA2KEwOJ6ueJWQyC0nQlp52uGm9yodC3GZ1d0CMdyQeJctRDqmtayY-Kz71fW2IIUziz8intK6TErvbiZh4dEMQ",
  "mac-10-amber-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5WxrR1a7s2oaaBoH_2WGmaczed1j-1gSCGn20QlsWqAz4z8d3yfP1IpW8QkQeIN5hXtldTkMuqzsQyNjNgUxX6vjCpXrnE8FVzqUc8",
  "mp7-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8jsHf_CNk6fOqbZtgMKesAm6Xyfo45LQ7Fy3rzR536j6HyYn6J3zFaAcjA5RwQ-9fs0O5m93nMe2x5QHfjZUFk3sMNd5yQw",
  "mac-10-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5WxrR1a7s2oaaBoH_yaCW-Ej-h347AwHyzqx04l4WvSyI77cCjCbQEhW8MjE-NcthG8loXlMujh7g3Ay9USCa6Cs30",
  "m4a1-s-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwjFS4_ega6F_H_GSMWGRxetJvbVoHjqMmRQguynLm92pci2WagEkC5Z5Q7VetkbukIXjNrnm5QPbjt8WxS-vii4b5i5v4fFCD_TfxF4xWg",
  "awp-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_CNk7uW-V6JsJPWsAm6Xyfo45-c5GXDnwB534DuEwtuoIHOfaAYiAsYjF-QItUaxmoC0MO_h5ALcjJUFk3sEzfdk4w",
  "r8-revolver-crimson-web": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLjm4Dv8TRe_c2mcZt6JfKAMWuZxuZi_rdrHny2wkR_sDuHw4muJXuWOwZyAsdzTeNcu0S4ktfkP77htAOPiYlbjXKp8jg9HbM",
  "scar-20-crimson-web": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLinZfyr3Jk5-uRf6FvM8-XD3WbxPxJvOhuRz39lEwhsGqBz9moJHmXawQhDsQhEOUNsBSwkdXiM-3k5AbZjo1MmSiojDQJsHiHhrZ4wA",
  "cz75-auto-crimson-web": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLyhMG1_B1T9s25baZ-H_yaCW-Ej-0u4-VsH3G2x0x-sGXQyY76JXPGOAQkCMAlR-YNsBDqxtHhZerjsgTAy9USIjIDnE8",
  "desert-eagle-crimson-web": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk5-uRf6FvM8-XD3WbxPxJvOhuRz39wEUh5W3Rytyscy7FPAYgWJJzRe4MtUW8loKyZOm3sQzb34lEzyX32zQJsHig-EWd2A",
  "p250-crimson-kimono": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhzMOwwipC0PmnZatjL8-XB2adzuByo957Si2MmRQguynLw9uvI3qVbld2XJF3ROMKtBTqxNO0P-Pj4lbXjt9HySv5hikf6y9s4PFCD_Tv7NBHeA",
  "navaja-knife-crimson-web": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1c9uK9cZtnIfOYBWmZx-tJuPhWWCyxhiIrujqNjsGtJS-eag4iCpN4QrZYsEK_m9K0ZLzl4gOLiYgQxSj2in9Buis_5OZRT-N7rdEUHJYn",
  "shadow-daggers-crimson-web": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV6x0H-eWDHSvzedxuPUnHi3mkRx24j_cn4qgIHnGbwF0A5p1R7UI5xm-k9XnMrjq5gOPj95BxDK-0H2triMq-g",
  "specialist-gloves-crimson-web": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk71ruQBH4jYLf-i5U-fe9V7d9JfOaD2uZ0vpJp-RrXBahkBkYvzSCkpu3JyiSbAQkC8d1E7YJtEXtkIazMruz4lOP3dpGmCyt23hA731v4LkKAL1lpPOyoS0Ibw",
  "ump-45-moonrise": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLkk4a0qB1a7s27ZbQ5dc-eAWie0-dltd56WiegkAkYvzSCkpu3IHzGbQFxCMByE7MJsxC6w9ayN-3ntgPf3YtGmX6tiyxM6X1pt-cCUr1lpPMz7bPahA",
  "zeus-x27-olympus": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLln4Xl7x1B6ue9V7BlNf6XC3WvxuFyj-1gSCGn2xl2sm7XnI6hdC-XPAcmXsF2RLIP4xbslty2NLvqswePjYlEySn33S9XrnE8cYTqlUY",
  "glock-18-moonrise": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2kpnj9h1a7s2pZKtuK8_CVliF0-x3vt5kQCa9qhsipTiXpYPwJiPTcANzXJNyFOEMthXsktHhMLzl4FaK3toWn3iqhi9BvHw9su5UU6Zw-_bJz1aWcX-Jd_0",
  "glock-18-vogue": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2kpnj9h1Y-s2pZKtuK8-WF2KTzuBiseJ9cCW6khUz_T-GyNavdCqRawN1CMFwTOcO5hO7loXiY-zmsQKPi44QzHj22ikcvy11o7FVfFOBmfY",
  "desert-eagle-starcade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk7OeRb6hkNOSWHFiUxO9xvORWQyC0nQlpsD_SnN79JX2WbQ8pXMNwRO5ZsRK8lt21Nb7r4wPXgtgWmCz7hylJ6jErvbgNUrm8Kg",
  "ak-47-neon-rider": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0POlV6poL_6sHG6UxPxJvOhuRz39xkQhsTnVzoygdy7Ea1UoCZQkRe9bs0brl9TvN-m0tVHYjY5CyS35jjQJsHhk4o5zcA",
  "mac-10-neon-rider": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5WxrR1Y-s2jaac8cM-dC2ie0-dytfNWQyC0nQlp5DzTntmgdC7COABxX5NxQrUOtUS5w4LgMu6zsVCK2IJCmyisjitM6DErvbicsEA0SQ",
  "shadow-daggers-gamma-doppler-5": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV6VgH_eSA2qR_up5oPFlSjuMhRUmoDjRpYPwJiPTcFB2DJB3F-4LsBG_kd21Ne23tVPait9HmX6t2n5P6i1q5uoHAKJwq6TJz1aWm5wQ7fM",
  "gut-knife-doppler-7": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1c-uaRaalSM_GDHm-Z0-tJveB7TSW2nAcitwKJk4jxNWWQO1IjW5d4RLUOsEG_lYCxZbjq5QDejYlBnn6o2y9LvCti4OtRUfUl5OSJ2CIbbpiB",
  "nomad-knife-doppler-7": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1U-uaqZ6t_H_GeMXSR0f5-ufNscCSyhx8rtjSfn4vGLSLANkI-DZF4E7EL4xiwxILgMLni41SM3o8Uz3j4h3tJ6ik_sO9WU_F3-KPUjRaBb-NU6ZNx2A",
  "glock-18-warhawk": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2kpnj9h1c_M2pZKtuK8-HBnKexetkj-V8XD2MmRQguynLwo34eXjBbgQnCMB1Q-QN5EXrkdfkNu7m5Ffd2YoTzyr52H5B7nk-5PFCD_Q2xs5K0Q",
  "glock-18-oxide-blaze": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2kpnj9h1Y-s2pZKtuK6HLMWSf0_x5tORncCW6khUz_T_Xn9f6dnvDb1UkDsdwF7IItES6kYK1M-7k7wSI3YwQm3_63XlAvH51o7FVwJirs7M",
  "mp9-broken-record": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8js_f8DIC0OSnZr1hH_yaCW-Ej78gs7M_Hy-xxUUi4WWHyd6tJ33EOAAkXsckE-4M5Baxw9O2ZOO3sgzAy9USMhZdDpQ",
  "ak-47-rat-rod": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiVI0POlPPNSLvmRDGuV09F6ueZhW2fklBx362TTnN36dHiRa1AmW5QlQuVftxO9k4HhZuvksVDc398Rzy32kGoXuR34FNLu",
  "five-seven-case-hardened": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL3l4Dl7idN6vyRabVSL_mfC2OvzedxuPUnH3C1kRsi4jiAw4qtdXjCO1V2WcZxF-EO5xLsxtHmMeKw5g3fit4TnDK-0H1W4XC76Q",
  "mac-10-case-hardened": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5WxrR1a_s2hYahoJM-fB2CY1aAituJtTnvjkUx3tziGmd6hJy-VZlAoWZtwFLRZ5EbpwNLvYb-zsgOKlcsbmn9_3b1O",
  "hydra-gloves-case-hardened": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tg_13jRBnOlo_k7yNk6P6hfqF-H_KfAWiUyeFjvuVWRzC3hxwYsDyWn7DxIDnDO1h1Xv0sHLBS9g7ul9zmMbi35FHYgolMmSj9jS8fvC5jte9RAqctqKCC2QHBYrU64MMCOr_5GlPhveuZ",
  "huntsman-knife-case-hardened": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1P7vG6YadsLM-SH1ifyOJztN5lRi67gVN_4W-Byt-hIi2UbVV2W5p2Fu4PuxmxkdO0Zejj7wff3okWzCT3ji4f8G81tJdWCOsa",
  "ak-47-case-hardened": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiNK0P2nZKFpH_yaCW-Ej7sk5bE8Sn-2lEpz4zndzoyvdHuUPwFzWZYiE7EK4Bi4k9TlY-y24FbAy9USGSiZd5Q",
  "usp-s-check-engine": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLkjYbf7itX6vytbbZSM-CsA2KDydFlsedsWzChkBkYvzSCkpu3Iy6RbQYnXJZ2F7QN4UPqkIfmNeni5laNit1Dyiz42C5JvCdo57xQA71lpPMz6iO7bg",
  "mag-7-heat": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5G3wiFO0P-vb_NSMvWXBmiE_uJ_t-l9AX7nzBsk623dm46odHmUbFd1Dcd2RbINtBXtkNDjMbzj5AGKjt4UyijgznQe8JftFTE",
  "mac-10-carnivore": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5WxrR1a_s2jaadScaCsD2uZxOBJs-BkQBa_nBovp3PSmdqpcy2fPwEoWMciQLYKtBa9lYDmN-zlsVDXiNpAnnmqiHwcv3w5_a9cBiTJtAYY",
  "p2000-obsidian": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL5lYayrXIL0PG7V7Q_cKDDMWiS0udyueBncCW6khUz_W7QzNf4eHKUPA9xDMAkFrMJ40brldGxM-rk4lfago1MzXmrjCwYvC91o7FVDbVY3kE",
  "xm1014-tranquility": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLpk8ewrHZk7OeRcKk8cKHHMWSR0-disfJWQyC0nQlp5zjWnNigIC-falMlWMN2F-cP5Ba-xoXlMri0swTZg41EyX34jS1LuDErvbgNI5zBZg",
  "p250-muertos": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhzMOwwiFO0OL8PfRSLfGdCmacwNF6ueZhW2e1lh51sm3UmN37cHuUbQQhXJtwQO4C4BXsxtHjM-624A3a2IoWySiskGoXuSIJMqiP",
  "m4a4-hellish": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwiFO0P_6afBSNOKSB2mvyet6vN5lRi67gVMj5W_VyNb7Ii-TPFdxCpskQOMDsEOxxNHgYb-xswKKgo8WyH2t3X9J8G81tMARX_8e",
  "m4a4-hellfire": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwiFO0P_6afBSKPWfAmGZ0-tJvOhuRz39zEp24GTXmImsInqWP1AkXpBwE7FetUTswdfkPu7h5QXXithBy32t2DQJsHhDPmtuAA",
  "mp9-hot-rod": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8js_f_Cxk_feqV6hkJ_iHQD7Cl7ou5rlsGyi2wBgh4WyDytmqcC6fbQAhC8chEeZZtRLrw4LlNLz8p1uJeM3XA-E",
  "sticker-hellraisers-katowice-2014": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJai0ki7VeTHjM-sJnCW8Vli_YTxuAm2FVL5m5rs7yNS_Pe8e-o1cqaWXDeWwLhy6bZsG3vlkBt2tWqEn9f4eHyRPAAoWcRxRu8NukTqjJS5YFwAHIOk",
  "sticker-neon-mvp-lenticular": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGJai0ki7VeTHjMmuOHaC619h7cj35VTqVBP4io_fr3IJur2ibap5KfOGAmaC_uBzv-9kWTn9wU1-tj_Xz9msJC2XPVN1DcQmTbIMshe9m9bkNO_j4lOPiY9DzCWoiDQJsHgefWkufw",
  "mp5-sd-phosphor": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8jsPz-R1c_M2jePFSJvWAGm6GwOJJtPNgXxa_nBovp3PRzd-vdCqQOgYgCMYkRrECskLuwdfkZeqz5QKMjYwUnHj33SlI630__a9cBl0Wy4S-",
  "awp-fever-dream": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V7R-OfObAXeR1eZJvOhuRz39kE1w4jiAzNiod3qTOgcgXpAlQ-ML5hjqxtHjZOrrtlHWit9EyCj9iDQJsHhCZP-wUg",
  "awp-neo-noir": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V6poL_6cB3WvzedxuPUnHirrxR4l423SyI39I3KXPwdxWZclQeNZ5EXskYfnNeyw71OMi9lNzDK-0H3r66pOTw",
  "m4a4-desolate-space": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwiFO0P_6afBSJPWAAWuR1etJo_FoTCyMmRQguynLnNepJXPEaQJyDZJ0QOdbsxi7ktS0Y-Li4ADegthGn32ojCJJ7CxosfFCD_SyjfEkHg",
  "ak-47-nightwish": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0POlPPNSLvmUBnOHyP1-j-1gSCGn20glt2nXnt78cnKUbwN2XJp2R-ZbuxHqlNXlMLiw5AHc3toWnCur23hXrnE8p0T2bx4",
  "ak-47-neon-revolution": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0POlPPNSIf6SHGSY2NF6ueZhW2e3w0524mjQzomreXqVbAAhWJF3RuZfuxC5x920Yurh7gONjY0RxHr4kGoXuT5bpI-V",
  "ak-47-wintergreen": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wjFU6s2jbbBsLPyaDViX0-tzvt47cCW6khUz_W-Ay96seSrBaQcnDJRyTbMDuxTsw9bmNLy0sQPb34JNyn_-jS9N6n51o7FVK4Nkj6A",
  "galil-ar-galigator": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2n5rp8SNJ0PWvZK1hH_eSAm6XwPp5ot5lRi67gVN_42_VydytcX3BbQ8pCsB0ReMCtEG_lYLuNuji4AGPjt8Qynj4jXlI8G81tMQ6bFYi",
  "ak-47-emerald-pinstripe": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0OKnZrd5MvmDC1iRyrohj-1gSCGn20t-422Bn4v6eH_FaFcpWcFyRrRbsRK9xN3lNOK0tFPX2YJBmS_4iytXrnE8zwmR9Cc",
  "awp-green-energy": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jde0Pi7ZbRSLPmdC1icyOl-pK8wTCzlxkl_tm7Vz9j6cnLEOA91C5siTOBYsRWwxtC2MOzj5g2I3Y4W02yg2VFgswq6",
  "m4a1-s-fatal-glitch": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwjFS4_ega6F_H_iKC1iD0fdxvOh9TCGMkg8itjO6l9v4cDj4Ml93UtZuQ-4P4xS4kNyxMLvrsgeMiY8QmXj5i39BvSZosetUVPAj-PCGig7IYKp9v8fxFF6Big",
  "awp-atheris": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V7JkMPWBMWuZxuZi_rZsS3zgzU8isW3dnIr6eHKfPVAhDpojEe9YsUW4xta1Nuzm5FDci4NbjXKpmWVQppo",
  "m4a4-full-throttle": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwi8P7qaRe69_MuKHMWCCxOt4j-1gSCGn20kk4mSHn97_eXqTOgMkXpdzR-MNsxO7w9e2Yrnk5VbciIhDznj8iy9XrnE8J4rQ87g",
  "shadow-daggers-gamma-doppler": "https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpovbSsLQJfw-bbeQJD4eOzmYWZlvvwDLbQhGld7cxrj-3--YXygED6-0VsYz-hJNKcIwM8aQ3XqFi7l7_ngpHquJ7LyyZl6SQg5iqInRK0hQYMMLJWkXxH2Q",
  "glock-18-gamma-doppler": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2kpnj9h1a4s2rZaF_IfyXMWqR0-x6tehzSi2MkhEosDa6lob-KT-JPwZzA5J4F-8Mt0a-ktTvNeyws1PfjIsQyiX9h3gYvSpr5bwFWash-7qX0V9IgS2WPw",
  "desert-eagle-emerald-j-rmungandr": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk7v-RYqt_Lc-UHGKVz9F6ueZhW2fqzB51sGiGzNqrJXqWbAYmCpJ0RuYDshm_xNPmZuy07wDY3YwXni6okGoXuekvMmaE",
  "sg-553-tiger-moth": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLimcO1qx1c_M29b_E4c8-HB2CV09F7v_VhcCW6khUz_TnWn9n7cyqRPQ52DpN3QLEPshjrw9zlY-jjs1bWioMQxSj8hyxJu3l1o7FVwqXqqnE",
  "usp-s-blood-tiger": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLkjYbf7itX6vytbbZSKOmsHGKU1edxtfNWQyC0nQlptWWEzd-qd3mVbgR2WZYiFuUMtUG7x4HhYeLhs1fZiN1DnC6viH4Y7TErvbgp6HjWjQ",
  "m4a1-s-blood-tiger": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwjFS4_ega6F_H_iKMXWVxfp_t-R7cCW6khUz_WXWmdmpeXOWbA4jDJolQeMNthnrlIbiMO7m71TfjIpFxH-vjClO6CZ1o7FVlF3bnRA",
  "m4a4-jungle-tiger": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwipC0OSRfK1qJeKsAm6Xyfo457AxHyznxBkmsWzcyYmoeXLCalR2D8R3E-8O5he9wIXmM7zr4QSP3pUFk3sDhAfDyg",
  "p250-bengal-tiger": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhzMOwwipC0OL8PfRSNPmUC3WvzedxuPUnSX7llhghsGjQnNv7I36SZlAjDZMmE-VYskS_kYfkNO2w4QffiItNyjK-0H3QIgynUA",
  "p90-tiger-pit": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLhx8bf_C9k-_upbbZ-H_KBAXCe_uJ_t-l9AX6wxERy4W_UyYytIn2RPQYjDpp2F-Vc4xi8x9e1Pu7n5gfcjYoWzCrgznQeZAcpQ5E",
  "navaja-knife-tiger-tooth": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1c9uK9cZtnIfOYBWmZx-tJse9WWyC0kA8YvC-ElIj8HifOOV5kFMMlRLJf4BK4k9LlZuy35QTYg95NzXmri3tB6yk4sO5XBaoh_PDRhgHfcepqTt5nFFY",
  "shadow-daggers-tiger-tooth": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV6VjH-SaCWKC_uFkse9uSha_nBovp3PUwt-uJHjFOgYlXpt4EbQJshS8loCxP7vr7gDZiItMnir-iC1O7X1s_a9cBp8PQ5hi",
  "falchion-knife-tiger-tooth": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1d7v6tYK1iLs-SAFiEyOlzot5mXSi9khgYvzSCkpu3cCiRZwIiDcZ2ReEO4EW5xtXlMuO05weKjYNBxS-tjytOvC495u0BWb1lpPPh4hsqrQ",
  "flip-knife-tiger-tooth": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1d4_u-V6VjH-SaCWKC_uFkse9uSha_nBovp3OBztqpI3yTbAIgDZslQbFbtUbuw9y2Y7y37gDcjooQxH__h39B5yxt_a9cBoXwL4KP",
  "mag-7-monster-call": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5G3wiFO0P-vb_NSLf-dHXOV09F1se1lcCW6khUz_WncmIz8JHmTa1JyApd5FLEMsES-kNDhM-3i5QKM2Y5AzSr9jngY6Cp1o7FV7cAHRyI",
  "xm1014-monster-melt": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLpk8ewrHZk7OeRZ7JoMuCSHXSvzOF4o_VsXTqMjRAYvzSCkpu3JXqTOg8gDcYhROQDsxPux9bjYezm5waM2YlGnHn22y1BuiY45ewCBL1lpPOtgL12Pw",
  "usp-s-jawbreaker": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLkjYbf7itX6vytbbZSNeODHViUzulxqd5lRi67gVMl62nUyd2scnOVPAcgA5J2TOFY5xLrlN22YbzgsQaI2IlHyiWojnwa8G81tErOD-_J",
  "dual-berettas-flora-carnivora": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL0kp_0-B1Y-s2qfaVhH_WfB3OV0tFzpuhlcC-_mg8mjDGMnYftbynGOA4lDZd4FOZYuxi6kdPvZuLrsgTW2IIQxXn7iSNJ6ic96-YCB_I7uvqA4cV5qzc",
  "sawed-off-devourer": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLin4Hl-S1d6c2tfZt-IeeWCmiWx9FytfdmWju2hyIrujqNjsH8JSnBPQdxDcEiF-FZshS7kdG1NOyz4wKKiYNDmXn3jHkd5n055ulTT-N7rdPAUyyq",
  "awp-containment-breach": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V7JkMuWAMWuZxuZi_rQ6SXq1xURysj_Vw4uhJHOVPQ8oCZt4QrRbtRi6ldPlPu_g4FHaiYNbjXKpcPI_17A",
  "sg-553-colony-iv": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLimcO1qx1Y-s29b_E4c8-BC2aT1eFkj-1gSCGn20Qit2yAn9n8IHKealB2DZIjTO8JsBW7ktDlYu_m5ADWit4Rznn63XtXrnE82sW2soE",
  "galil-ar-cerberus": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2n5rp8SNJ0PG7V6doMvKBG3Svxu96ue1WQyC0nQlpsTjVzdb8IH-UOw8lX8B5EeYJ40a8k4XnPuvqsgzYjt0QnCyqh3wb7DErvbjusqqqdw",
  "awp-hyper-beast": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V6x0MPWBMWWVwP1ij-1gSCGn20pxtm_WzNuoeHKeaFAnCZUiTe5bt0HqxofmZOrm5Q2IjoMQzS_5iShXrnE8NzWs__c",
  "m4a1-s-hyper-beast": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwjFS4_ega6F_H_OGMWrEwL9JuPh5SjuMlxgmoCm6lob-KT-JbwF1WZEjR-YJskK9k9XiYePltAeNjYlAxSn5j34dvCZstb4LB6Ut-7qX0V8Xkv5_2A",
  "five-seven-hyper-beast": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL3l4Dl7idN6vyRa7FSJvmFC3SV1-t4j-lwXyyhlxgmoCm6lob-KT-JO1QgWZVyELEPu0W4l9KzYbzn5Fbf3YkTzn_8hihIvXxtsOoFUKYirLqX0V_f6-eqCw",
  "sport-gloves-bronze-morph": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk5UvzWCL2kpn2-DFk_OKherB0H-CcB3Sfz9Fwou5ucDu2kSIgoTiAlLD1KCzPKhghDJBzTLMCukW6kNblNe-2tlGKj45GyCWrii8f73k95e4HA_AjrvbSkUifZkDjXxpJ",
  "awp-arsenic-spill": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf9Ttk-fO8YadsLf-sHW6d0eJzj_hsQyW8giIrujqNjsH8eS2ePANxXJN3Q-NbtxDtkNexMeri5lfd3doTnij7hiJMuy5jtutQT-N7rTqLZycV",
  "awp-pit-viper": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf9Ttk_PyvY6F-K_mdMWuZxuZi_rQ_GS3mxRwk4jvTyNv6eC-RPQV1W5AlTOZb4xLtw9fuNriw51Hd3otbjXKp4cSTTIs",
  "awp-worm-god": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_DNk7uW-V7B6Kf6WMWuZxuZi_uRoGH3iw0wh4j7cnt6ucSqSZwUkCMB5TLIPsES_kNbuYeOwtgXai4NbjXKpZ4kj0o0",
  "awp-black-box": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_DVL0PCiaadmH_KcFlicyOl-pK9tSXjikEgk6z-Ey9j9JXLDbFMhD8N4ELQJ5BLrk93hM-6ztg3WiI5E02yg2W_lAA_2",
  "awp-mortis": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf-jFk7uW-V6BoIeSbMWuZxuZi_rNtHiuwwRwismWEnNn8JymSZgUiDpd3Ru9ZsxG-xNy2NLzn41DWg41bjXKp5oOAt0A",
  "awp-exoskeleton": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf-jFk7uW-V6F1L-OYC2uV1eF4j-1gSCGn20km5zyEmd2qc3uWZwcnA5MiELIJtxa_w9OyN-nh5wKKj4kTyn78hyNXrnE83OTew2I",
  "awp-ice-coaled": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_DVL0PutbZtuL_GfC2OvzedxuPUnS3u3wR8lsTzTn4qqcXuXOlQmCpUiQOdYtUG_ltXgP-u04wWL3Y9NnjK-0H2dw8uldQ",
  "awp-elite-build": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V6lsM-SWHH6vzedxuPUnSnHmk0Qh4G6HmN-scXmSaQRxXJpwRuZYsxTqxtTnM7nl4gTW2dlFyjK-0H0d8XeEBg",
  "awp-crakow": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk4OSrerRsM-OsDXWRyuFhj-B-Xxa_nBovp3OAyd34cC2VOgUoCZYmF7UCthm_kdGyMry05wHa3t0XxH_23XhP7y9q_a9cBncOjtH9",
  "awp-pink-ddpat": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf9Ttk6_a-abBSMPmdBVicyOl-pK9qHXC2zUpz5DiBn9arJCmXOFd0DZpxQOUDtBC6wNK0MOzl4wXWjYpG02yg2c9nQ1pb",
  "awp-queen-s-gambit": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_DVL0OO7baFjM8-UD2qSyPpJvOhuRz39kUpw42zWntiteSiVaQYhCJJzEeIOukSwl4XmPrmw4VHXjtpExC_33zQJsHjNnJgjQA",
  "awp-redline": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V6diIuKSMWuZxuZi_rUxHS3lzUwm5DjWy976dSiRagd1WJB1RLQP4RK-mtazM-3itQeL2INbjXKpw2eVIZ0",
  "awp-longdog": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_DVL0P6hZqNpL_esAm6Xyfo44rNtFi_kxhx-4WvWnImoJ3mTblJzDJFzR-QP4EK4m9XjZbvk7lCLiZUFk3u2JoT1UA",
  "awp-boom": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf9Ttk7f6vZZt-Kf2DAmKvzedxuPUnTX7mkxhy62iDzYqhdiqXbw4oWZEkE-IDsRa9lIXlMejktFOMi49MmDK-0H2AgUnw_w",
  "awp-sovereign-flame": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_DVL0OGhfqF_JfmUAFiWze97td5lRi67gVNz5zvRnN-qcHKfPFcjXpUmRuILukW9ldHlNOjn5Q2PitoWmSiv3C0a8G81tAj27FZA",
  "awp-cmyk": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf-jFk5vyqbbRoLvSWMWaH0dF6ueZhW2e1zElxtmzQmIv8J3qQalRzW5t0RrYOsBCwlte2Mbmw5AbXiYlAnnn4kGoXuYBQOb0Q",
  "awp-silk-tiger": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_C9k-_upbbZ-H_KfG2KvzedxuPUnTXywkU1x4DvXztz_dH2WZlQkXMEhFrFY5BDrm9HhMurq4AfdiYxAnDK-0H0fPMTeBA",
  "awp-oni-taiji": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwiYbf_jdk7uW-V6xsLv6KD1icyOl-pK9vGCqwkx524G_WnNmsInyXOAVyXJJ0TbNb5EOxxIflYbzj4gDdiNlC02yg2XaKgrAq",
  "ak-47-varicamo-grey": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wjFU6s24abZkI_GeAVicyOl-pK8_TXvhxh5_626Bn477dn-fbQcnXMZzEeMPtxe_w9DhY-OztAXc2IsT02yg2Vc0ERtW",
  "ak-47-uncharted": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0POlPPNSIeqHC2SvzedxuPUnFnCwwBl_5D_Syon8dnyUaQUlD5oiQ7ECuxW7l920ZL-w4AfX2IlByTK-0H0PRM7cOA",
  "ak-47-elite-build": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0POlPPNSLfGAGmKC2NF6ueZhW2e2wh9y5GjTztirdSqfP1dyCpclR7FZ5xe9wNbhZei25FGPjokXxC2vkGoXuQLr5jvs",
  "ak-47-steel-delta": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiVI0POlPPNSM-SBAWmV_uJ_t-l9AXqyk0hy5GWEyduhdC2TPAEjDptzQbRf5EHrmoWyZu22sQLciokQyyzgznQesAEGx_A",
  "ak-47-midnight-laminate": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wjFU6s2neq1pJeOQC2mE_v5jovFlSha_nBovp3PRnt36d36UOlUmCcF2TOZfsRC_ldW1ML625AbZ2dhHyn_7jSgauCtp_a9cBpVVSdXG",
  "ak-47-slate": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiVI0POlPPNSMOKcCGKD0ud5vuBlcCW6khUz_W3Sytb4cCqTOFUpWJtzTOUD5hPsw9a0Yrnrs1SK3ooXzy6shilM5311o7FVYrIufmI",
  "ak-47-searing-rage": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiNQu6WRbbx9LP-AB3GV_uJ_t-l9AXu2lk1xsD-EnI3_JHmeaAV1CZB1RbEJtxfuxNHuMuq251PY3o4UxXjgznQeg4Qz-rg",
  "ak-47-nouveau-rouge": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wipC6s2vY_A6H_6cG3GVwPtJvOhuRz39zBsm5j-HyNqpd32fPVd1AsB3RbEP4xntwdPuM-jl4QaK2NpCzX_23DQJsHjpyGbntg",
  "ak-47-phantom-disruptor": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0POlJfA6H-CbD2mEzuNJtOh6XTyjgRI1jDGMnYftb3qTbQMpCZVxF-8Ku0Xtw4XkYu2xtQSL3d5FxSz-3H5Ovy895epRA6E7uvqAsbzZtpo",
  "ak-47-the-oligarch": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiNQu6WReLFrJvWBMWSF0vp5vd5lRi67gVNz4Tvdn4qoJC3Ba1V1WcdxTbFcsEbpxoHhNunnsVPYitlFm3392C4f8G81tEVBuxrI",
  "ak-47-consequence-of-the-jinn": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiNQu6WRYq1jLs-QAWmDxP9jte9qSha_nBovp3OHm9v6IHuTOgYiA5ZzE-Bb40O6loK2MeLnswff2ogRyS732ywduyc4_a9cBtOamUv2",
  "ak-47-autoexec": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiNQu6WRabF5L_WLC2Svwu97v95lRi67gVN16mzSwtigdn2QPAElXpskQOQIthC8xIXiM-7k4gHfgoMWySyo2y4b8G81tI8PUinm",
  "ak-47-vulcan": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiFO0POlPPNSMuWRDGKC_uJ_t-l9AXCxxEh14zjTztivci2ePQZ2W8NzTecD4BKwloLiYeqxtAOIj9gUyyngznQeF7I6QE8",
  "shadow-daggers-black-laminate": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV6N-H-CGHW-vw-J3s-pWQyi-nBMmpzi6lob-KT-JbQ9zDsMhEO8L4xS7k93mMbu35wOPitpBzij9hngY5ypitexXB_BxqbqX0V9R9Pjb9Q",
  "navaja-knife-rust-coat": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1c9uK9cZtnIfOYBWmZx-tJsfBWXD22kBEYuDOMnIrGLC7DN0N9FMF2E7NbsEWwkYXjMe3r51OKid1MmXr42i0cvSdttb0KAKpz86WCjgDfcepqQnV13Fs",
  "navaja-knife-safari-mesh": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1c9uK9cZtnIfOYBWmZx-tJo_FWQiygnSIzsjO6lob-KT-JZgIlDJFxQbUIsxnsk9zjNrmz7wbfg4IQziT6hi9P5n5j674CWPIlqLqX0V-GxNuRmA",
  "shadow-daggers-safari-mesh": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV7d9H_2WHW-v1e94j-1gSCGn201xtj7dn96hJCmTOlcjCMclELUMtEW5lYDkNum351aLjo5Gynj62ytXrnE8619lrZ4",
  "paracord-knife-rust-coat": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1Y4OCqV6V8H-OHC2Kc_uV4uedscCS2kRQyvnPUzo2qIHjEaFQhC5dyF-ZbsxPpx9C1Y-nq4ACPiIJFzn_-hntJ6yxr_a9cBo1AYhy6",
  "navaja-knife-ultraviolet": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1c9uK9cZtnIfOYBWmZx-tJo-5WXzyhhREijDGMnYftby3FOgUhAsYjTeZetBm4xtXkNbiw5lPbi9pGxCr92itB7C9q4ekDU6c7uvqA74P7bNU",
  "shadow-daggers-autotronic": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV6N-H-CGHW-vwPtiv_V7QCe6liIrujqNjsGrIH2fOFJxX5F1TeICsRe8x4ezY-vj7gHc2N9HxHir3HhK7Cds5L4AT-N7rU0zpOnr",
  "shadow-daggers-lore": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV6d4H-CGHW-vzeFktd5lRi67gVMksWXQz96sIy2UP1B2D8dwRe5b4Be9moDkN7nl4QLYg94UmX-vjHhM8G81tMoT8OiD",
  "shadow-daggers-marble-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV6VgH_2SHGWcxNFwseVscCW6khUz_T_dyI2tJXrFbQN2X5MjTLUCtEa5kYXnYuPh5QGLjowUxXitjixA7nl1o7FVu7_YRqU",
  "flip-knife-urban-masked": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1d4_u-V7d9H-SSHmKv1Px0se9WQyC0nQlp5DnWw46pIy2SOwBxW5VwFOcP5hC4x92zM-6ztVbYjtoTmST_iSNA6DErvbgg2ar9PQ",
  "flip-knife-black-laminate": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1d4_u-V6d4H_afB3ev0vp5vuR-Tjq7qhEutDWR1NqheHqUOAMlXpR0FOVZ4Ba8wIW2P7u35VPX2Y9Azn6s2ihB7S5v5uccEf1yNTyJJU8",
  "flip-knife-bright-water": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1d4_u-V6x0H_-QC2ae_uV4uedscCW6khUz_WyHy4usJS7EOlJxWMMlFrMMsxKxmobnZr_i4leNgohCxCT_iHwfuH11o7FV6J7t-P8",
  "gut-knife-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1c-uaRaaVSJvGXC1icyOl-pK88HyjikUR_6z_UmIyudy-WPVByCpRzQ7UDukbtmofmM-3r4gaKjINH02yg2St2xdPu",
  "falchion-knife-gamma-doppler-4": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1d7v6tYK1iLs-SA1iXwON7sd5tQDmjmRg1jC2Nm5z8chTLN1F4Tox2EecPuha9m4bhZuLhtQTZid4UxCT8h39PvCo54egAVqF2-PaF3QGSL_RjtnjgxS7B",
  "huntsman-knife-fade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1P7vG6YadsLM-SD1iWwOpzj-1gSCGn2x8hsW6DmIqpcXjBZgYkCZt5F7VcthS8ldS2Nr7m5VCMi4gRyyuqjHtXrnE8oar8MtU",
  "bayonet-tiger-tooth": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLzn4_v8ydP0POgV7BkJ_WBMWiCwOBxtd5lRi67gVMhsGrTntn4ci-ROAYlXMBwE7YL5BaxxIHjY-vq7w3X398RxS78iylK8G81tBow9RWL",
  "huntsman-knife-gamma-doppler": "https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpovbSsLQJfx_LLZTRB7dCJlY20kvrxIbrdklRc6ddzhuzI74nxt1i9rBsofWD2IIDDcFQ9MwvV-FO5xejngpK16c6bmyZguiUj7HqMnRfjhBhOOOJxxavJeVUN3dA",
  "hydra-gloves-mangrove": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tg_13jRBnOlo_k7yNk6P6hfqF-H_KfAWiUyeFjvuVWRzC3hxwYtC-An4HGLS7GKl51SP0tEKRS3UL6w5ekWLa7sF2alY9MzyX92ixAvCs-sutWWKd08qDRh17CZOI86JcBcffyH0iGUR9asfh8BNe0yN2QCJM",
  "hand-wraps-arboreal": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu4vx603vRA_Olpfu-TVJ7uK9V6xsLvSEHGaA_uJzsfVhSjuqqhsmsS-MmbD-My7CMGlzW88vKrtT5Uj8jIblMbnksQfb2IlAzXqojCpP6ylp67kLAKBz_6aFjFnCN-I66ZQHdv-5DUPZjQpqjqQ",
  "moto-gloves-3rd-commando-company": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu4r7_lb1QgTykpPf-i5U-fe9V6liNP-BDX6TzetJs-5kQii9kRIYuC6OpYPwJiPTcAZyDMd2F-YIu0a4ktTjP--35Vfb3oMTyy_-iCtM7Hpq5elTBaYirKTJz1aWk_tQEIo",
  "hand-wraps-giraffe": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu4vx603vRA_Olpfu-TVJ7uK9V6xsLvSEHGaA_uJzsfVhSjuqqhsmsS-MmbD-KDnGOFB1Zc4pEr9OrBm6w9bgM-Pi4wLe34tNnCT3jCxJ53s_6rsBUqQkq63V2wnBZOJo55YdZKHw2FL19Wg",
  "specialist-gloves-buckshot": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk71ruQBH4jYLf-i5U-fe9V7d9JfOaD2uZ0vpJtu57Sjqnqh81vCqLpYPwJiPTcFQhAsd5TOcDsxLqwN22ZrjqslDZg4gXnCj2jnlA7Sg54udWB_dz-qbJz1aWpqUo0Nk",
  "broken-fang-gloves-needle-point": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tg_13jRBnOnITv9idV6fOgb5tqLP-FC3Svzv5zouB9Ria9xE0YtTGKiI71HifOOV5kFJQlQbUL4RHukofjY-227wDaidpHnCqs3H5K6So95ekLVKck__bW3Q_fcepqSI673wM",
  "moto-gloves-pow": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu4r7_lb1QgTykpPf-i5U-fe9V6liNP-BDX6TzetJs-lmTCaMlxIovgKJk4jxNWXBPAZ2CpYmTOAO4UWwltOxP-3qswPdgopMzXiviSwavytpsO4FUvEh5OSJ2LE4Jnt4",
  "broken-fang-gloves-jade": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tg_13jRBnOnITv9idV6fOgb5tqLP-FC3Svzv5zouB9Ria9xE0YvjiRm4PwIhTALFN1VP0sHLBS9g65w9exM-Pl5gaKidkRziX22yNIv306571QA6pwrKGDiluTZLxs5ZdXOr_5GlzOqAIa",
  "moto-gloves-smoke-out": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu4r7_lb1QgTykpPf-i5U-fe9V6liNP-BDX6TzetJo-xmRCyMmRQguynLztircXjCaAAkDZp0TO4OsRW8xtznP-7mswXYj4wTnyysiHkc5n5p5PFCD_SXL_AlqA",
  "specialist-gloves-mogul": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk71ruQBH4jYLf-i5U-fe9V7d9JfOaD2uZ0vpJp-hnWyyhnRg_jDGMnYftb3qWagQlX8EjF7YIuhK9m9XiNO2x7gOPjY5HzHj7iiwcv3xi4-pQAPc7uvqAbB4ER4o",
  "bloodhound-gloves-guerrilla": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tg_13jRBnOnJrv8iZT4OegbJtqLP-FC3Svw-J5v-VhQDy9kSIgpjiXiIb1LSr4Ml93UtZuR7QKthCwl4fkNuqw4lPXgosRzi78inwdvyk45e5UUqQkq_aDi1rEZap9v8fy7GQdug",
  "moto-gloves-blood-pressure": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu4r7_lb1QgTykpPf-i5U-fe9V6liNP-BDX6TzetJs-B7TSa9kxQlti-6iIr9HifOOV5kFJp2TeYOsxWxm9OyM7zl5AKIio0XyyiojiJA6C866-YFV6oi_6GBhwHfcepqnQk3Qfo",
  "sport-gloves-red-racer": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk5UvzWCL2kpn2-DFk6P6hfqFSM-CcHHOv0-91tfNWXSy3qhEutDWR1I77dC7GbQ4kWZNwEOJY5xLtwYHuN7yz7lPe2YgTniz2jn5Nv3lj5O0cEf1yHxfMKhM",
  "sport-gloves-omega": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk5UvzWCL2kpn2-DFk_OKherB0H_KfD2Sb_vlzsuNgQS6MjBgrvzKSpYPwJiPTcFAkC5UiRrRZ5BO9ktDnM-q37wCMjN5GxCqvhngb6Chj6u0CVvAj-6fJz1aW3nluLgw",
  "sport-gloves-violet-beadwork": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk5UvzWCL2kpn2-DFk6P6hfqFSM-CcHHOvw-t3tPZmXSKMkRQmvjKLnpzGMT7VLlp1Zc4pEr9OrBWxxofvNOLitQKPid5Hznr-3C9JvHtu4uxTVKMlqaPQilrAM7Fr6cQdZKHwBJ-GjQo",
  "sport-gloves-amphibious": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk5UvzWCL2kpn2-DFk_OKherB0H-CcB3Sfz9Fwou5ucCu_gBgYpDWMjorGLSLANkI-W5R4E7JZtxbskNWxZeLi4QPejdgTmSn62iwbvyw957kDAqog_fXWjBaBb-Pahe96zA",
  "mac-10-gold-brick": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5WxrR1a4s2pZ6hpH_KBB2Sb_uJ_t-l9AX2wwhl35jzRw4yodymWO1R0X5V0FrRc4Bi-m4DuY-2xsgzY39oRmSTgznQe6Q1Q_KE",
  "m4a1-s-golden-coil": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwjFS4_ega6F_H_eAMWrEwL9lj_JnTiK2lxQztgKClYP9HifOOV5kFJclQ-Jb5xW-m9CxPuLq4QTfjd0XzyX6jCpL6X5o5OgDVfYn_a2Ci1rfcepqgV49FrE",
  "huntsman-knife-lore": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1P7vG6YadsLM-QG1iY1OBio-xoQRa_mg8ijDGMnYftb3qfPQZyWJtyFuNe4BG5ktDuY-ritleIid1Hynir3H9KvH055btRV6s7uvqAU_ahZxI",
  "m4a4-the-coalition": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwiVI0P_6afBSI_-SAm6EyOF4j-1gSCGn200jt2_XnIuseX_GaFR0XpEhReULtUKxlIWzP-_gs1HZjI1NzSutiClXrnE8e4r3Ge8",
  "bayonet-lore": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLzn4_v8ydP0PG7V6ZsOf-dC3OvzeFktd5lRi67gVMj5GnXzt__JH-SawdyDJF1ROcCu0K5xNOxZeqx5AOI2oNGnnn23ylJ8G81tNZRAs3w",
  "ak-47-gold-arabesque": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwlcK3wiVI0POlPPNSJ_-fCliR0-90tfJ4WiyMmRQguynLntmvICieOARzCpMhF-BYsRe-xoHvYu_g5lSNj4NDyy2viCwY6Hlu5_FCD_Q1jEqYuQ",
  "m4a4-urban-ddpat": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwipC0PaqeKV5H-WBDFicyOl-pK8xF3DjzR5_4zncnouhcSjGPQ8jA5B3ELFbuhPqloDkPrvjsgXY2t5N02yg2Rf5X8A9",
  "mac-10-urban-ddpat": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8n5WxrR1T9s2qbLRsNM-GHGWvzedxuPUnGXnlwhh-5m7XmYmrJHiUaFJzD8QmTeIC5EG-moKyYerg7g3Z34pMnDK-0H2xTdMbHg",
  "desert-eagle-urban-ddpat": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk5-uRbKB9IeSsG3WS_uJ_t-l9AXm2kxkk42rWn9egc36UOwYiX5N1EOVYsRLtldC0M77g5QXfiN1Fzn_gznQemk8fKYk",
  "galil-ar-urban-rubble": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2n5rp8SNJ0Pq3V7JsMvmQD2qf_vtksuBncCW6khUz_TiDz9b8dXKQaAZ0X8MiRLVZ4RXslIflN-_g4gKIit1BnHn4iSNBvCl1o7FV6ub4EBU",
  "shadow-daggers-urban-masked": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL6kJ_m-B1L-uGmV7d9H-SSHmKv1Px0se9WQyC0nQlp5GTdz4mqcniVPQAkCZYiFrQMs0TslYXmM-7i5wfb3dpEn32viShL7DErvbjmz8a0gQ",
  "nova-smart-gun": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL_kYDhwixU-fORe6lsMuSsAm6Xyfo44OI_G3vhkEUi5W_dw46reXiWbAZzWcN3E-QM5BDul9HiNevkswLeipUFk3v5u-E4uw",
  "cz75-auto-hydraulics": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLyhMG1_B1Y9aX7V6x0JOKSG2uZwv1JvOhuRz39kE135DzRyN2hIHyea1AkA8BwTOYJ4RG6kNzlZOm0sgXX2doRmS6riTQJsHilInmzoA",
  "m4a4-dark-operative": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8ypexwi8P7qaRaqhsI_usHW6UxNF7sfV9Sha_nBovp3ODn4qtdn2RbAN1A8chTOVZuxK5lNDnNerj5Qfc2N0Wznj_h38dvC0__a9cBqB1kqb_",
  "desert-eagle-night-heist": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL1m5fn8Sdk7v-RYKFkM-SsHmuRz_1JoPR7XyW2qhEutDWR1I6uJH-RPQInXJB0F-Vb50bqxt3kN-Kw4VCMjYxCyXmvj3hO6X05t-8cEf1yxd2V6Eg",
  "galil-ar-rainbow-spoon": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2n5rp8SNJ0PO_V7BkNPGdB3Kd_vx3ue9rQD6MkhwrujGEiLD1KCzPKhhxCMclQeAPtUK-xoWxPrvkslOKg4tHzXn-3Xsbvyo647sLVqoh_6XekUifZrx5Pjj5",
  "five-seven-heat-treated": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL3l4Dl7idN6vyRabVSI_GAC1iYwPxyte9sSxa1nAsioDiTn4HGLSLANkI-D5pxEbIDu0btkoXlNuO24wDZ2YhDmH7923tI7ClrsblWAqMj-KPRiBaBb-NawNZy0w",
  "usp-s-spiral-glitch": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLkjYbf7itX6vytbbZSNeODHViD0edkse1WSCW6gR4vjDSXk4v8MijCMEJPVssnHaMUskG4ltXvPr7j7lTfjo4QyS762Coa7y5u5rsCV6NwrKfTjlySMOFstY5DeqjJbNurDA",
  "nova-polar-mesh": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL_kYDhwjFL0P-re6xSIeKQGm6T_u15vvV7TjqnqhEutDWR1I7_dCmXbgEmWJYiFuZc4BPpkoWyYe3jsVbejt8QyiutjXxPuic45-wcEf1ynwKdBSU",
  "g3sg1-polar-camo": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL2zYXnrB1T9s2veqd5KfOsDWie1fx3o_VWQyC0nQlp5D7Xn9n6cn2UP1IoCMF0ROYO4xnsldK1Nbnh5AGM2olDyy-siXwfuzErvbiZGyPTng",
  "famas-yeti-camo": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL3n5vh7h1I4PeRaqh4Jc-VD2qR0tF6ueZhW2fjk01x5jiBytqveXiWOFcnDJMmQeMLskPrmoCzYrzn7wPd3d1Fnyv8kGoXufV393rw",
  "ump-45-arctic-wolf": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLkk4a0qB1Y-s27ZbQ5dc-EBm6ExNFwse9ucCW6khUz_WiGzY6pJyjCZwN1A5p5Q-MCuxa7ldW0Ne3ntQHW2YpFmSv63S1B73t1o7FVFkKgM50",
  "aug-arctic-wolf": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLwi5Hf_jdk7uepV7NlKeSWCGaextF6ueZhW2frxxtxsGrTw46sI33BOAUiXMElFO4L50O9xNLvNOyz4lDd3olMzX6skGoXude_sLiC",
  "mp9-arctic-tri-tone": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyL8js_f-jFk7uCtfK1uH_2DV1icyOl-pK86HHrrwE5ztWSGydv_eCifOAF2DMB5Fu5etEK9lt3hMuLh5gWPitgX02yg2dKG9WA-",
  "xm1014-frost-borre": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Dx60noTyLpk8ewrHZk7v-RY6piNOOsHW6c1-tkj-1gSCGn20V05W2Dw9v8ICjGbQMkWJd4TedZtRGxkNDnNOjqsgGN34MXxX76jH9XrnE82FMLyIU",
  "sport-gloves-frosty": "https://community.akamai.steamstatic.com/economy/image/i0CoZ81Ui0m-9KwlBY1L_18myuGuq1wfhWSaZgMttyVfPaERSR0Wqmu7LAocGIGz3UqlXOLrxM-vMGmW8VNxu5Tk5UvzWCL2kpn2-DFk6P6hfqFSM-CcHHOvwu97v95-RienkA8YvzSCkpu3dXqfbA5zW5N0F-dcu0K8ldDnMuPk4wHdjN9EniWthn4av31v4eoHWL1lpPOyBkNpPQ",
};

/** skinId|wear -> the exact item value the user typed. cases.ts skinWithWear
 *  consults this FIRST so every display path (winner chips, feeds) shows the
 *  case editor's number instead of the market wear table's. */
export const USER_ITEM_VALUES: Record<string, number> = {
  "p250-asiimov|BS": 8.85,
  "ak-47-asiimov|WW": 34.17,
  "awp-asiimov|WW": 64.59,
  "p90-asiimov|WW": 149.84,
  "desert-eagle-heat-treated|MW": 1.78,
  "mp9-green-plaid|MW": 3.82,
  "p250-franklin|FN": 3.98,
  "dual-berettas-cartel|WW": 0.19,
  "usp-s-printstream|FT": 32.15,
  "desert-eagle-printstream|BS": 24.84,
  "awp-printstream|MW": 52.32,
  "m4a1-s-printstream|BS": 115,
  "ak-47-cartel|MW": 15.98,
  "p250-cartel|BS": 5,
  "sticker-dragon|": 0.1,
  "sg-553-dragon-tech|FN": 0.9,
  "zeus-x27-dragon-snore|FT": 8.97,
  "desert-eagle-kumicho-dragon|MW": 20,
  "p2000-imperial-dragon|FN": 27,
  "glock-18-dragon-tattoo|FN": 75,
  "ssg-08-dragonfire|FT": 260,
  "ssg-08-acid-fade|FN": 0.42,
  "sawed-off-amber-fade|FN": 0.47,
  "p2000-amber-fade|FN": 1.24,
  "r8-revolver-amber-fade|FN": 3.37,
  "galil-ar-amber-fade|MW": 7.98,
  "mac-10-amber-fade|MW": 10,
  "mp7-fade|FN": 13,
  "mac-10-fade|FN": 35,
  "m4a1-s-fade|FN": 165,
  "awp-fade|FN": 638,
  "r8-revolver-crimson-web|MW": 0.35,
  "scar-20-crimson-web|FT": 1.24,
  "cz75-auto-crimson-web|FT": 2.17,
  "desert-eagle-crimson-web|FT": 8.91,
  "p250-crimson-kimono|FT": 9.71,
  "navaja-knife-crimson-web|BS": 42,
  "shadow-daggers-crimson-web|BS": 50,
  "specialist-gloves-crimson-web|FT": 109,
  "ump-45-moonrise|FN": 0.97,
  "zeus-x27-olympus|FT": 1.37,
  "glock-18-moonrise|FN": 1.97,
  "glock-18-vogue|FT": 2.15,
  "desert-eagle-starcade|WW": 27.15,
  "ak-47-neon-rider|MW": 54.41,
  "mac-10-neon-rider|WW": 87,
  "shadow-daggers-gamma-doppler-5|FN": 92,
  "gut-knife-doppler-7|FN": 100,
  "nomad-knife-doppler-7|FN": 315,
  "glock-18-warhawk|FT": 0.12,
  "glock-18-oxide-blaze|MW": 0.12,
  "mp9-broken-record|FN": 0.43,
  "ak-47-rat-rod|BS": 1.34,
  "five-seven-case-hardened|MW": 10,
  "mac-10-case-hardened|MW": 17.41,
  "hydra-gloves-case-hardened|MW": 76.74,
  "huntsman-knife-case-hardened|FT": 121.97,
  "ak-47-case-hardened|FT": 185,
  "usp-s-check-engine|FN": 0.95,
  "mag-7-heat|MW": 1.2,
  "mac-10-carnivore|FN": 2.98,
  "p2000-obsidian|MW": 3.21,
  "xm1014-tranquility|FT": 6.78,
  "p250-muertos|MW": 9.27,
  "m4a4-hellish|FT": 13.54,
  "m4a4-hellfire|WW": 57.2,
  "mp9-hot-rod|MW": 150,
  "sticker-hellraisers-katowice-2014|": 500,
  "sticker-neon-mvp-lenticular|": 2.5,
  "mp5-sd-phosphor|FN": 9.5,
  "glock-18-vogue|FN": 10.5,
  "awp-fever-dream|FN": 17.26,
  "awp-neo-noir|FN": 40.97,
  "m4a4-desolate-space|FN": 74.97,
  "ak-47-nightwish|FN": 98.74,
  "ak-47-neon-revolution|FN": 237,
  "ak-47-wintergreen|FT": 0.32,
  "galil-ar-galigator|FT": 0.49,
  "ak-47-emerald-pinstripe|MW": 2.71,
  "awp-green-energy|FT": 4.97,
  "m4a1-s-fatal-glitch|FT": 15,
  "awp-atheris|FN": 37.94,
  "m4a4-full-throttle|MW": 69.54,
  "shadow-daggers-gamma-doppler|FN": 165,
  "glock-18-gamma-doppler|FN": 400,
  "desert-eagle-emerald-j-rmungandr|FN": 495,
  "sg-553-tiger-moth|FT": 0.58,
  "usp-s-blood-tiger|FT": 1.43,
  "m4a1-s-blood-tiger|FT": 2.91,
  "m4a4-jungle-tiger|FT": 5.87,
  "p250-bengal-tiger|FT": 10.15,
  "p90-tiger-pit|FN": 13.54,
  "navaja-knife-tiger-tooth|FN": 53,
  "shadow-daggers-tiger-tooth|FN": 60,
  "falchion-knife-tiger-tooth|FN": 110,
  "flip-knife-tiger-tooth|FN": 175,
  "mag-7-monster-call|MW": 0.56,
  "xm1014-monster-melt|BS": 0.89,
  "usp-s-jawbreaker|WW": 2.11,
  "dual-berettas-flora-carnivora|FN": 2.87,
  "sawed-off-devourer|MW": 5.15,
  "awp-containment-breach|BS": 34.45,
  "sg-553-colony-iv|FN": 43.71,
  "galil-ar-cerberus|MW": 49.87,
  "awp-hyper-beast|FN": 146.71,
  "m4a1-s-hyper-beast|FN": 256.15,
  "five-seven-hyper-beast|MW": 335.15,
  "sport-gloves-bronze-morph|FN": 400,
  "awp-arsenic-spill|FN": 0.45,
  "awp-pit-viper|MW": 0.98,
  "awp-worm-god|MW": 1.75,
  "awp-black-box|FT": 3.45,
  "awp-mortis|MW": 3.75,
  "awp-atheris|MW": 5.45,
  "awp-exoskeleton|MW": 8.24,
  "awp-ice-coaled|MW": 11.12,
  "awp-green-energy|MW": 12.85,
  "awp-elite-build|MW": 14.86,
  "awp-crakow|FT": 18.65,
  "awp-pink-ddpat|MW": 33.34,
  "awp-queen-s-gambit|FT": 45.74,
  "awp-redline|FT": 51.84,
  "awp-asiimov|BS": 64.51,
  "awp-longdog|FT": 68.96,
  "awp-boom|FT": 87.56,
  "awp-sovereign-flame|FT": 108.61,
  "awp-cmyk|FT": 150,
  "awp-silk-tiger|FN": 520,
  "awp-oni-taiji|FN": 585,
  "ak-47-varicamo-grey|FN": 0.1,
  "ak-47-uncharted|MW": 0.43,
  "ak-47-elite-build|WW": 0.75,
  "ak-47-steel-delta|MW": 1.97,
  "ak-47-midnight-laminate|FN": 11.2,
  "ak-47-slate|FN": 12.15,
  "ak-47-searing-rage|FN": 17.5,
  "ak-47-nouveau-rouge|MW": 18.6,
  "ak-47-phantom-disruptor|FN": 23.5,
  "ak-47-the-oligarch|MW": 85,
  "ak-47-consequence-of-the-jinn|FT": 122,
  "ak-47-autoexec|FT": 145,
  "ak-47-vulcan|MW": 320,
  "shadow-daggers-black-laminate|BS": 25,
  "navaja-knife-rust-coat|BS": 25,
  "navaja-knife-safari-mesh|FT": 27,
  "shadow-daggers-safari-mesh|MW": 35,
  "paracord-knife-rust-coat|WW": 40,
  "navaja-knife-ultraviolet|MW": 43,
  "shadow-daggers-autotronic|FN": 65,
  "shadow-daggers-lore|FN": 90,
  "shadow-daggers-marble-fade|MW": 96,
  "shadow-daggers-gamma-doppler-5|MW": 105,
  "flip-knife-urban-masked|MW": 105,
  "flip-knife-black-laminate|MW": 115,
  "flip-knife-bright-water|FN": 115,
  "gut-knife-fade|MW": 140,
  "falchion-knife-gamma-doppler-4|FN": 185,
  "huntsman-knife-fade|FN": 195,
  "bayonet-tiger-tooth|FN": 245,
  "huntsman-knife-gamma-doppler|FN": 550,
  "hydra-gloves-mangrove|BS": 20,
  "hand-wraps-arboreal|BS": 28,
  "moto-gloves-3rd-commando-company|FT": 28,
  "hand-wraps-giraffe|FT": 28,
  "specialist-gloves-buckshot|FT": 30,
  "broken-fang-gloves-needle-point|FT": 35,
  "moto-gloves-pow|WW": 53,
  "broken-fang-gloves-jade|FT": 54,
  "moto-gloves-smoke-out|FT": 95,
  "sport-gloves-bronze-morph|MW": 114,
  "specialist-gloves-mogul|MW": 125,
  "bloodhound-gloves-guerrilla|FT": 189,
  "moto-gloves-blood-pressure|MW": 194,
  "specialist-gloves-crimson-web|MW": 276,
  "sport-gloves-red-racer|MW": 280,
  "sport-gloves-omega|MW": 430,
  "sport-gloves-violet-beadwork|MW": 560,
  "sport-gloves-amphibious|MW": 589,
  "mac-10-gold-brick|BS": 28,
  "ak-47-the-oligarch|FT": 35,
  "m4a1-s-golden-coil|MW": 75,
  "huntsman-knife-lore|FN": 114,
  "m4a4-the-coalition|BS": 125,
  "bayonet-lore|BS": 175,
  "ak-47-gold-arabesque|": 850,
  "m4a4-urban-ddpat|MW": 0.3,
  "mac-10-urban-ddpat|MW": 1.94,
  "desert-eagle-urban-ddpat|MW": 3.75,
  "galil-ar-urban-rubble|FN": 15.94,
  "shadow-daggers-urban-masked|FN": 115,
  "nova-smart-gun|WW": 1,
  "cz75-auto-hydraulics|FT": 1.1,
  "m4a4-dark-operative|FN": 4.94,
  "awp-black-box|MW": 7.12,
  "desert-eagle-night-heist|BS": 11.97,
  "galil-ar-rainbow-spoon|FT": 18.21,
  "five-seven-heat-treated|FN": 18.9,
  "usp-s-spiral-glitch|FN": 71,
  "m4a1-s-fatal-glitch|FN": 89,
  "nova-polar-mesh|FN": 0.1,
  "g3sg1-polar-camo|FN": 0.2,
  "famas-yeti-camo|FN": 0.75,
  "ump-45-arctic-wolf|FN": 1.12,
  "aug-arctic-wolf|MW": 1.94,
  "mp9-arctic-tri-tone|FN": 4.2,
  "xm1014-frost-borre|FT": 65,
  "sport-gloves-frosty|FT": 165,
};

/** The twenty user cases — merged over GEN_CASES by case code in cases.ts. */
export const USER_CASES: CaseDef[] = [
  {
    id: "asiimov-protocol",
    code: "RB-101",
    name: "Asiimov Protocol",
    subtitle: "The future leaked into today — paint it white, shoot it orange.",
    kind: "standard",
    tierLabel: "STARTER",
    price: 12,
    tierColor: "#f0821e",
    tierColor2: "#e8e0d0",
    items: [
      // P250 | Asiimov (BS) — 5%
      { skinId: "p250-asiimov", weight: 5, value: 8.85, wear: "BS" },
      // AK-47 | Asiimov (WW) — 2.225%
      { skinId: "ak-47-asiimov", weight: 2.225, value: 34.17, wear: "WW" },
      // AWP | Asiimov (WW) — 0.625%
      { skinId: "awp-asiimov", weight: 0.625, value: 64.59, wear: "WW" },
      // P90 | Asiimov (WW) — 0.15%
      { skinId: "p90-asiimov", weight: 0.15, value: 149.84, wear: "WW" },
      // Desert Eagle | Heat Treated (MW) — 72%
      { skinId: "desert-eagle-heat-treated", weight: 72, value: 1.78, wear: "MW" },
      // MP9 | Green Plaid (MW) — 10%
      { skinId: "mp9-green-plaid", weight: 10, value: 3.82, wear: "MW" },
      // P250 | Franklin (FN) — 10%
      { skinId: "p250-franklin", weight: 10, value: 3.98, wear: "FN" },
    ],
  },
  {
    id: "printstream-cartel",
    code: "RB-102",
    name: "Printstream Cartel",
    subtitle: "Monochrome money — clean lines, dirty payouts.",
    kind: "standard",
    tierLabel: "STARTER",
    price: 6,
    tierColor: "#eceaf4",
    tierColor2: "#17151d",
    items: [
      // Dual Berettas | Cartel (WW) — 85%
      { skinId: "dual-berettas-cartel", weight: 85, value: 0.19, wear: "WW" },
      // USP-S | Printstream (FT) — 1.25%
      { skinId: "usp-s-printstream", weight: 1.25, value: 32.15, wear: "FT" },
      // Desert Eagle | Printstream (BS) — 1.525%
      { skinId: "desert-eagle-printstream", weight: 1.525, value: 24.84, wear: "BS" },
      // AWP | Printstream (MW) — 0.09%
      { skinId: "awp-printstream", weight: 0.09, value: 52.32, wear: "MW" },
      // M4A1-S | Printstream (BS) — 0.015%
      { skinId: "m4a1-s-printstream", weight: 0.015, value: 115, wear: "BS" },
      // AK-47 | Cartel (MW) — 2.12%
      { skinId: "ak-47-cartel", weight: 2.12, value: 15.98, wear: "MW" },
      // P250 | Cartel (BS) — 10%
      { skinId: "p250-cartel", weight: 10, value: 5, wear: "BS" },
    ],
  },
  {
    id: "dragons-vault",
    code: "RB-103",
    name: "Dragon's Vault",
    subtitle: "Sleeping gold and ancient fire — the rarest hoard on ROLLBOX.",
    kind: "standard",
    tierLabel: "RARE",
    price: 15,
    tierColor: "#f0b90b",
    tierColor2: "#2e7d32",
    items: [
      // Sticker | Dragon — 35%
      { skinId: "sticker-dragon", weight: 35, value: 0.1 },
      // SG 553 | Dragon Tech (FN) — 30%
      { skinId: "sg-553-dragon-tech", weight: 30, value: 0.9, wear: "FN" },
      // Zeus x27 | Dragon Snore (FT) — 25.95%
      { skinId: "zeus-x27-dragon-snore", weight: 25.95, value: 8.97, wear: "FT" },
      // Desert Eagle | Kumicho Dragon (MW) — 4.75%
      { skinId: "desert-eagle-kumicho-dragon", weight: 4.75, value: 20, wear: "MW" },
      // P2000 | Imperial Dragon (FN) — 3.705%
      { skinId: "p2000-imperial-dragon", weight: 3.705, value: 27, wear: "FN" },
      // Glock-18 | Dragon Tattoo (FN) — 0.5%
      { skinId: "glock-18-dragon-tattoo", weight: 0.5, value: 75, wear: "FN" },
      // SSG 08 | Dragonfire (FT) — 0.095%
      { skinId: "ssg-08-dragonfire", weight: 0.095, value: 260, wear: "FT" },
    ],
  },
  {
    id: "fade-factory",
    code: "RB-104",
    name: "Fade Factory",
    subtitle: "Anodized rainbow at 90/10 — the purest flex in the game.",
    kind: "standard",
    tierLabel: "RARE",
    price: 16,
    tierColor: "#f5d442",
    tierColor2: "#e34fa0",
    items: [
      // SSG 08 | Acid Fade (FN) — 20%
      { skinId: "ssg-08-acid-fade", weight: 20, value: 0.42, wear: "FN" },
      // Sawed-Off | Amber Fade (FN) — 10%
      { skinId: "sawed-off-amber-fade", weight: 10, value: 0.47, wear: "FN" },
      // P2000 | Amber Fade (FN) — 20%
      { skinId: "p2000-amber-fade", weight: 20, value: 1.24, wear: "FN" },
      // R8 Revolver | Amber Fade (FN) — 20%
      { skinId: "r8-revolver-amber-fade", weight: 20, value: 3.37, wear: "FN" },
      // Galil AR | Amber Fade (MW) — 10%
      { skinId: "galil-ar-amber-fade", weight: 10, value: 7.98, wear: "MW" },
      // MAC-10 | Amber Fade (MW) — 10%
      { skinId: "mac-10-amber-fade", weight: 10, value: 10, wear: "MW" },
      // MP7 | Fade (FN) — 4.75%
      { skinId: "mp7-fade", weight: 4.75, value: 13, wear: "FN" },
      // MAC-10 | Fade (FN) — 5.1725%
      { skinId: "mac-10-fade", weight: 5.1725, value: 35, wear: "FN" },
      // M4A1-S | Fade (FN) — 0.075%
      { skinId: "m4a1-s-fade", weight: 0.075, value: 165, wear: "FN" },
      // AWP | Fade (FN) — 0.0025%
      { skinId: "awp-fade", weight: 0.0025, value: 638, wear: "FN" },
    ],
  },
  {
    id: "crimson-covenant",
    code: "RB-105",
    name: "Crimson Covenant",
    subtitle: "Woven in red — every thread ends in blood.",
    kind: "standard",
    tierLabel: "STARTER",
    price: 6,
    tierColor: "#eb4b4b",
    tierColor2: "#4a0a0a",
    items: [
      // R8 Revolver | Crimson Web (MW) — 50%
      { skinId: "r8-revolver-crimson-web", weight: 50, value: 0.35, wear: "MW" },
      // SCAR-20 | Crimson Web (FT) — 30%
      { skinId: "scar-20-crimson-web", weight: 30, value: 1.24, wear: "FT" },
      // CZ75-Auto | Crimson Web (FT) — 9%
      { skinId: "cz75-auto-crimson-web", weight: 9, value: 2.17, wear: "FT" },
      // Desert Eagle | Crimson Web (FT) — 5.3325%
      { skinId: "desert-eagle-crimson-web", weight: 5.3325, value: 8.91, wear: "FT" },
      // P250 | Crimson Kimono (FT) — 5.15%
      { skinId: "p250-crimson-kimono", weight: 5.15, value: 9.71, wear: "FT" },
      // ★ Navaja Knife | Crimson Web (BS) — 0.275%
      { skinId: "navaja-knife-crimson-web", weight: 0.275, value: 42, wear: "BS" },
      // ★ Shadow Daggers | Crimson Web (BS) — 0.225%
      { skinId: "shadow-daggers-crimson-web", weight: 0.225, value: 50, wear: "BS" },
      // ★ Specialist Gloves | Crimson Web (FT) — 0.0175%
      { skinId: "specialist-gloves-crimson-web", weight: 0.0175, value: 109, wear: "FT" },
    ],
  },
  {
    id: "doppler-realm",
    code: "RB-106",
    name: "Doppler Realm",
    subtitle: "Liquid galaxy swirls — pick your phase, chase your star.",
    kind: "standard",
    tierLabel: "STARTER",
    price: 11,
    tierColor: "#8847ff",
    tierColor2: "#2a0e5c",
    items: [
      // UMP-45 | Moonrise (FN) — 40.0998%
      { skinId: "ump-45-moonrise", weight: 40.0998, value: 0.97, wear: "FN" },
      // Zeus x27 | Olympus (FT) — 20.45%
      { skinId: "zeus-x27-olympus", weight: 20.45, value: 1.37, wear: "FT" },
      // Glock-18 | Moonrise (FN) — 20.45%
      { skinId: "glock-18-moonrise", weight: 20.45, value: 1.97, wear: "FN" },
      // Glock-18 | Vogue (FT) — 10.85%
      { skinId: "glock-18-vogue", weight: 10.85, value: 2.15, wear: "FT" },
      // Desert Eagle | Starcade (WW) — 7.5%
      { skinId: "desert-eagle-starcade", weight: 7.5, value: 27.15, wear: "WW" },
      // AK-47 | Neon Rider (MW) — 0.355%
      { skinId: "ak-47-neon-rider", weight: 0.355, value: 54.41, wear: "MW" },
      // MAC-10 | Neon Rider (WW) — 0.255%
      { skinId: "mac-10-neon-rider", weight: 0.255, value: 87, wear: "WW" },
      // ★ Shadow Daggers | Gamma Doppler (FN) — 0.0195%
      { skinId: "shadow-daggers-gamma-doppler-5", weight: 0.0195, value: 92, wear: "FN" },
      // ★ Gut Knife | Doppler (FN) — 0.0195%
      { skinId: "gut-knife-doppler-7", weight: 0.0195, value: 100, wear: "FN" },
      // ★ Nomad Knife | Doppler (FN) — 0.00125%
      { skinId: "nomad-knife-doppler-7", weight: 0.00125, value: 315, wear: "FN" },
    ],
  },
  {
    id: "hardened-crown",
    code: "RB-107",
    name: "Hardened Crown",
    subtitle: "Blue gems and lottery patterns — the collector's gamble.",
    kind: "standard",
    tierLabel: "STARTER",
    price: 13,
    tierColor: "#4b69ff",
    tierColor2: "#101c4a",
    items: [
      // Glock-18 | Warhawk (FT) — 20%
      { skinId: "glock-18-warhawk", weight: 20, value: 0.12, wear: "FT" },
      // Glock-18 | Oxide Blaze (MW) — 20%
      { skinId: "glock-18-oxide-blaze", weight: 20, value: 0.12, wear: "MW" },
      // MP9 | Broken Record (FN) — 20%
      { skinId: "mp9-broken-record", weight: 20, value: 0.43, wear: "FN" },
      // AK-47 | Rat Rod (BS) — 18%
      { skinId: "ak-47-rat-rod", weight: 18, value: 1.34, wear: "BS" },
      // Five-SeveN | Case Hardened (MW) — 10%
      { skinId: "five-seven-case-hardened", weight: 10, value: 10, wear: "MW" },
      // MAC-10 | Case Hardened (MW) — 10.7955%
      { skinId: "mac-10-case-hardened", weight: 10.7955, value: 17.41, wear: "MW" },
      // ★ Hydra Gloves | Case Hardened (MW) — 1.15%
      { skinId: "hydra-gloves-case-hardened", weight: 1.15, value: 76.74, wear: "MW" },
      // ★ Huntsman Knife | Case Hardened (FT) — 0.045%
      { skinId: "huntsman-knife-case-hardened", weight: 0.045, value: 121.97, wear: "FT" },
      // AK-47 | Case Hardened (FT) — 0.0095%
      { skinId: "ak-47-case-hardened", weight: 0.0095, value: 185, wear: "FT" },
    ],
  },
  {
    id: "hellfire-club",
    code: "RB-108",
    name: "Hellfire Club",
    subtitle: "Play with fire — burn bright or burn out.",
    kind: "standard",
    tierLabel: "RARE",
    price: 15,
    tierColor: "#ff6a00",
    tierColor2: "#7a0d0d",
    items: [
      // USP-S | Check Engine (FN) — 20%
      { skinId: "usp-s-check-engine", weight: 20, value: 0.95, wear: "FN" },
      // MAG-7 | Heat (MW) — 20%
      { skinId: "mag-7-heat", weight: 20, value: 1.2, wear: "MW" },
      // MAC-10 | Carnivore (FN) — 15%
      { skinId: "mac-10-carnivore", weight: 15, value: 2.98, wear: "FN" },
      // P2000 | Obsidian (MW) — 15%
      { skinId: "p2000-obsidian", weight: 15, value: 3.21, wear: "MW" },
      // XM1014 | Tranquility (FT) — 15%
      { skinId: "xm1014-tranquility", weight: 15, value: 6.78, wear: "FT" },
      // P250 | Muertos (MW) — 7%
      { skinId: "p250-muertos", weight: 7, value: 9.27, wear: "MW" },
      // M4A4 | Hellish (FT) — 5.9%
      { skinId: "m4a4-hellish", weight: 5.9, value: 13.54, wear: "FT" },
      // M4A4 | Hellfire (WW) — 2.0042%
      { skinId: "m4a4-hellfire", weight: 2.0042, value: 57.2, wear: "WW" },
      // MP9 | Hot Rod (MW) — 0.0955%
      { skinId: "mp9-hot-rod", weight: 0.0955, value: 150, wear: "MW" },
      // Sticker | HellRaisers | Katowice 2014 — 0.00025%
      { skinId: "sticker-hellraisers-katowice-2014", weight: 0.00025, value: 500 },
    ],
  },
  {
    id: "neon-district",
    code: "RB-109",
    name: "Neon District",
    subtitle: "Midnight city lights and synthwave payouts.",
    kind: "standard",
    tierLabel: "RARE",
    price: 27,
    tierColor: "#25e0d8",
    tierColor2: "#e3326b",
    items: [
      // Sticker | Neon MVP (Lenticular) — 45%
      { skinId: "sticker-neon-mvp-lenticular", weight: 45, value: 2.5 },
      // MP5-SD | Phosphor (FN) — 40%
      { skinId: "mp5-sd-phosphor", weight: 40, value: 9.5, wear: "FN" },
      // Glock-18 | Vogue (FN) — 5%
      { skinId: "glock-18-vogue", weight: 5, value: 10.5, wear: "FN" },
      // AWP | Fever Dream (FN) — 5%
      { skinId: "awp-fever-dream", weight: 5, value: 17.26, wear: "FN" },
      // AWP | Neo-Noir (FN) — 2.55%
      { skinId: "awp-neo-noir", weight: 2.55, value: 40.97, wear: "FN" },
      // AK-47 | Neon Rider (MW) — 1.25%
      { skinId: "ak-47-neon-rider", weight: 1.25, value: 54.96, wear: "MW" },
      // M4A4 | Desolate Space (FN) — 0.75%
      { skinId: "m4a4-desolate-space", weight: 0.75, value: 74.97, wear: "FN" },
      // AK-47 | Nightwish (FN) — 0.325%
      { skinId: "ak-47-nightwish", weight: 0.325, value: 98.74, wear: "FN" },
      // AK-47 | Neon Revolution (FN) — 0.125%
      { skinId: "ak-47-neon-revolution", weight: 0.125, value: 237, wear: "FN" },
    ],
  },
  {
    id: "emerald-sanctum",
    code: "RB-110",
    name: "Emerald Sanctum",
    subtitle: "Living crystal — the greenest grail room on the site.",
    kind: "standard",
    tierLabel: "STARTER",
    price: 13,
    tierColor: "#1f9f6b",
    tierColor2: "#0a3524",
    items: [
      // AK-47 | Wintergreen (FT) — 30%
      { skinId: "ak-47-wintergreen", weight: 30, value: 0.32, wear: "FT" },
      // Galil AR | Galigator (FT) — 20%
      { skinId: "galil-ar-galigator", weight: 20, value: 0.49, wear: "FT" },
      // AK-47 | Emerald Pinstripe (MW) — 20%
      { skinId: "ak-47-emerald-pinstripe", weight: 20, value: 2.71, wear: "MW" },
      // AWP | Green Energy (FT) — 20%
      { skinId: "awp-green-energy", weight: 20, value: 4.97, wear: "FT" },
      // M4A1-S | Fatal Glitch (FT) — 5.525%
      { skinId: "m4a1-s-fatal-glitch", weight: 5.525, value: 15, wear: "FT" },
      // AWP | Atheris (FN) — 4.275%
      { skinId: "awp-atheris", weight: 4.275, value: 37.94, wear: "FN" },
      // M4A4 | Full Throttle (MW) — 0.18%
      { skinId: "m4a4-full-throttle", weight: 0.18, value: 69.54, wear: "MW" },
      // ★ Shadow Daggers | Gamma Doppler Emerald (FN) — 0.0185%
      { skinId: "shadow-daggers-gamma-doppler", weight: 0.0185, value: 165, wear: "FN" },
      // Glock-18 | Gamma Doppler Emerald (FN) — 0.001%
      { skinId: "glock-18-gamma-doppler", weight: 0.001, value: 400, wear: "FN" },
      // Desert Eagle | Emerald Jörmungandr (FN) — 0.0005%
      { skinId: "desert-eagle-emerald-j-rmungandr", weight: 0.0005, value: 495, wear: "FN" },
    ],
  },
  {
    id: "tiger-tribe",
    code: "RB-111",
    name: "Tiger Tribe",
    subtitle: "Stripes of gold — hunt or be hunted.",
    kind: "standard",
    tierLabel: "STARTER",
    price: 13,
    tierColor: "#f5a623",
    tierColor2: "#191512",
    items: [
      // SG 553 | Tiger Moth (FT) — 28%
      { skinId: "sg-553-tiger-moth", weight: 28, value: 0.58, wear: "FT" },
      // USP-S | Blood Tiger (FT) — 20.9%
      { skinId: "usp-s-blood-tiger", weight: 20.9, value: 1.43, wear: "FT" },
      // M4A1-S | Blood Tiger (FT) — 20.9%
      { skinId: "m4a1-s-blood-tiger", weight: 20.9, value: 2.91, wear: "FT" },
      // M4A4 | Jungle Tiger (FT) — 10.145%
      { skinId: "m4a4-jungle-tiger", weight: 10.145, value: 5.87, wear: "FT" },
      // P250 | Bengal Tiger (FT) — 10.145%
      { skinId: "p250-bengal-tiger", weight: 10.145, value: 10.15, wear: "FT" },
      // P90 | Tiger Pit (FN) — 9.1%
      { skinId: "p90-tiger-pit", weight: 9.1, value: 13.54, wear: "FN" },
      // ★ Navaja Knife | Tiger Tooth (FN) — 0.5075%
      { skinId: "navaja-knife-tiger-tooth", weight: 0.5075, value: 53, wear: "FN" },
      // ★ Shadow Daggers | Tiger Tooth (FN) — 0.225%
      { skinId: "shadow-daggers-tiger-tooth", weight: 0.225, value: 60, wear: "FN" },
      // ★ Falchion Knife | Tiger Tooth (FN) — 0.075%
      { skinId: "falchion-knife-tiger-tooth", weight: 0.075, value: 110, wear: "FN" },
      // ★ Flip Knife | Tiger Tooth (FN) — 0.0025%
      { skinId: "flip-knife-tiger-tooth", weight: 0.0025, value: 175, wear: "FN" },
    ],
  },
  {
    id: "hyper-beast-bazaar",
    code: "RB-112",
    name: "Hyper Beast Bazaar",
    subtitle: "Radioactive street art — loud skins for loud wins.",
    kind: "standard",
    tierLabel: "RARE",
    price: 30,
    tierColor: "#e91e63",
    tierColor2: "#3fa34d",
    items: [
      // MAG-7 | Monster Call (MW) — 20%
      { skinId: "mag-7-monster-call", weight: 20, value: 0.56, wear: "MW" },
      // XM1014 | Monster Melt (BS) — 20%
      { skinId: "xm1014-monster-melt", weight: 20, value: 0.89, wear: "BS" },
      // USP-S | Jawbreaker (WW) — 20%
      { skinId: "usp-s-jawbreaker", weight: 20, value: 2.11, wear: "WW" },
      // Dual Berettas | Flora Carnivora (FN) — 10.5%
      { skinId: "dual-berettas-flora-carnivora", weight: 10.5, value: 2.87, wear: "FN" },
      // Sawed-Off | Devourer (MW) — 10.5%
      { skinId: "sawed-off-devourer", weight: 10.5, value: 5.15, wear: "MW" },
      // AWP | Containment Breach (BS) — 6.5%
      { skinId: "awp-containment-breach", weight: 6.5, value: 34.45, wear: "BS" },
      // SG 553 | Colony IV (FN) — 6.5%
      { skinId: "sg-553-colony-iv", weight: 6.5, value: 43.71, wear: "FN" },
      // Galil AR | Cerberus (MW) — 5.2248%
      { skinId: "galil-ar-cerberus", weight: 5.2248, value: 49.87, wear: "MW" },
      // AWP | Hyper Beast (FN) — 0.755%
      { skinId: "awp-hyper-beast", weight: 0.755, value: 146.71, wear: "FN" },
      // M4A1-S | Hyper Beast (FN) — 0.0125%
      { skinId: "m4a1-s-hyper-beast", weight: 0.0125, value: 256.15, wear: "FN" },
      // Five-SeveN | Hyper Beast (MW) — 0.0075%
      { skinId: "five-seven-hyper-beast", weight: 0.0075, value: 335.15, wear: "MW" },
      // ★ Sport Gloves | Bronze Morph (FN) — 0.00015%
      { skinId: "sport-gloves-bronze-morph", weight: 0.00015, value: 400, wear: "FN" },
    ],
  },
  {
    id: "awp-command",
    code: "RB-113",
    name: "AWP Command",
    subtitle: "One shot, one story — enter the sniper's cathedral.",
    kind: "standard",
    tierLabel: "RARE",
    price: 23,
    tierColor: "#38bdf8",
    tierColor2: "#17346e",
    items: [
      // AWP | Arsenic Spill (FN) — 10.52%
      { skinId: "awp-arsenic-spill", weight: 10.52, value: 0.45, wear: "FN" },
      // AWP | Pit Viper (MW) — 10%
      { skinId: "awp-pit-viper", weight: 10, value: 0.98, wear: "MW" },
      // AWP | Worm God (MW) — 10%
      { skinId: "awp-worm-god", weight: 10, value: 1.75, wear: "MW" },
      // AWP | Black Box (FT) — 10%
      { skinId: "awp-black-box", weight: 10, value: 3.45, wear: "FT" },
      // AWP | Mortis (MW) — 10%
      { skinId: "awp-mortis", weight: 10, value: 3.75, wear: "MW" },
      // AWP | Atheris (MW) — 10%
      { skinId: "awp-atheris", weight: 10, value: 5.45, wear: "MW" },
      // AWP | Exoskeleton (MW) — 10%
      { skinId: "awp-exoskeleton", weight: 10, value: 8.24, wear: "MW" },
      // AWP | Ice Coaled (MW) — 7%
      { skinId: "awp-ice-coaled", weight: 7, value: 11.12, wear: "MW" },
      // AWP | Green Energy (MW) — 7.5%
      { skinId: "awp-green-energy", weight: 7.5, value: 12.85, wear: "MW" },
      // AWP | Elite Build (MW) — 5%
      { skinId: "awp-elite-build", weight: 5, value: 14.86, wear: "MW" },
      // AWP | Crakow! (FT) — 4.5%
      { skinId: "awp-crakow", weight: 4.5, value: 18.65, wear: "FT" },
      // AWP | Pink DDPAT (MW) — 3.35%
      { skinId: "awp-pink-ddpat", weight: 3.35, value: 33.34, wear: "MW" },
      // AWP | Queen's Gambit (FT) — 0.95%
      { skinId: "awp-queen-s-gambit", weight: 0.95, value: 45.74, wear: "FT" },
      // AWP | Redline (FT) — 0.75%
      { skinId: "awp-redline", weight: 0.75, value: 51.84, wear: "FT" },
      // AWP | Asiimov (BS) — 0.225%
      { skinId: "awp-asiimov", weight: 0.225, value: 64.51, wear: "BS" },
      // AWP | LongDog (FT) — 0.125%
      { skinId: "awp-longdog", weight: 0.125, value: 68.96, wear: "FT" },
      // AWP | BOOM (FT) — 0.045%
      { skinId: "awp-boom", weight: 0.045, value: 87.56, wear: "FT" },
      // AWP | Sovereign Flame (FT) — 0.0225%
      { skinId: "awp-sovereign-flame", weight: 0.0225, value: 108.61, wear: "FT" },
      // AWP | CMYK (FT) — 0.0125%
      { skinId: "awp-cmyk", weight: 0.0125, value: 150, wear: "FT" },
      // AWP | Silk Tiger (FN) — 0.000023%
      { skinId: "awp-silk-tiger", weight: 0.000023, value: 520, wear: "FN" },
      // AWP | Oni Taiji (FN) — 0.000013%
      { skinId: "awp-oni-taiji", weight: 0.000013, value: 585, wear: "FN" },
    ],
  },
  {
    id: "ak-imperium",
    code: "RB-114",
    name: "AK Imperium",
    subtitle: "The king's arsenal — from Redline all the way to Fire Serpent.",
    kind: "standard",
    tierLabel: "RARE",
    price: 19,
    tierColor: "#d32f2f",
    tierColor2: "#f0b90b",
    items: [
      // AK-47 | VariCamo Grey (FN) — 15%
      { skinId: "ak-47-varicamo-grey", weight: 15, value: 0.1, wear: "FN" },
      // AK-47 | Wintergreen (FT) — 10%
      { skinId: "ak-47-wintergreen", weight: 10, value: 0.21, wear: "FT" },
      // AK-47 | Uncharted (MW) — 10%
      { skinId: "ak-47-uncharted", weight: 10, value: 0.43, wear: "MW" },
      // AK-47 | Elite Build (WW) — 10%
      { skinId: "ak-47-elite-build", weight: 10, value: 0.75, wear: "WW" },
      // AK-47 | Steel Delta (MW) — 10%
      { skinId: "ak-47-steel-delta", weight: 10, value: 1.97, wear: "MW" },
      // AK-47 | Emerald Pinstripe (MW) — 10%
      { skinId: "ak-47-emerald-pinstripe", weight: 10, value: 2.12, wear: "MW" },
      // AK-47 | Midnight Laminate (FN) — 10%
      { skinId: "ak-47-midnight-laminate", weight: 10, value: 11.2, wear: "FN" },
      // AK-47 | Slate (FN) — 10%
      { skinId: "ak-47-slate", weight: 10, value: 12.15, wear: "FN" },
      // AK-47 | Searing Rage (FN) — 8%
      { skinId: "ak-47-searing-rage", weight: 8, value: 17.5, wear: "FN" },
      // AK-47 | Nouveau Rouge (MW) — 4%
      { skinId: "ak-47-nouveau-rouge", weight: 4, value: 18.6, wear: "MW" },
      // AK-47 | Phantom Disruptor (FN) — 2%
      { skinId: "ak-47-phantom-disruptor", weight: 2, value: 23.5, wear: "FN" },
      // AK-47 | The Oligarch (MW) — 0.952%
      { skinId: "ak-47-the-oligarch", weight: 0.952, value: 85, wear: "MW" },
      // AK-47 | Consequence of the Jinn (FT) — 0.0355%
      { skinId: "ak-47-consequence-of-the-jinn", weight: 0.0355, value: 122, wear: "FT" },
      // AK-47 | AUTOEXEC (FT) — 0.0125%
      { skinId: "ak-47-autoexec", weight: 0.0125, value: 145, wear: "FT" },
      // AK-47 | Vulcan (MW) — 0.000015%
      { skinId: "ak-47-vulcan", weight: 0.000015, value: 320, wear: "MW" },
    ],
  },
  {
    id: "blade-barony",
    code: "RB-115",
    name: "Blade Barony",
    subtitle: "Steel nobility — every pull is a coronation.",
    kind: "standard",
    tierLabel: "ELITE",
    price: 98,
    tierColor: "#9c27b0",
    tierColor2: "#f0b90b",
    items: [
      // ★ Shadow Daggers | Black Laminate (BS) — 20%
      { skinId: "shadow-daggers-black-laminate", weight: 20, value: 25, wear: "BS" },
      // ★ Navaja Knife | Rust Coat (BS) — 20%
      { skinId: "navaja-knife-rust-coat", weight: 20, value: 25, wear: "BS" },
      // ★ Navaja Knife | Safari Mesh (FT) — 15%
      { skinId: "navaja-knife-safari-mesh", weight: 15, value: 27, wear: "FT" },
      // ★ Shadow Daggers | Safari Mesh (MW) — 15%
      { skinId: "shadow-daggers-safari-mesh", weight: 15, value: 35, wear: "MW" },
      // ★ Paracord Knife | Rust Coat (WW) — 15%
      { skinId: "paracord-knife-rust-coat", weight: 15, value: 40, wear: "WW" },
      // ★ Navaja Knife | Ultraviolet (MW) — 10%
      { skinId: "navaja-knife-ultraviolet", weight: 10, value: 43, wear: "MW" },
      // ★ Shadow Daggers | Autotronic (FN) — 1.65%
      { skinId: "shadow-daggers-autotronic", weight: 1.65, value: 65, wear: "FN" },
      // ★ Shadow Daggers | Lore (FN) — 0.85%
      { skinId: "shadow-daggers-lore", weight: 0.85, value: 90, wear: "FN" },
      // ★ Shadow Daggers | Marble Fade (MW) — 0.85%
      { skinId: "shadow-daggers-marble-fade", weight: 0.85, value: 96, wear: "MW" },
      // ★ Shadow Daggers | Gamma Doppler (MW) — 0.45%
      { skinId: "shadow-daggers-gamma-doppler-5", weight: 0.45, value: 105, wear: "MW" },
      // ★ Flip Knife | Urban Masked (MW) — 0.45%
      { skinId: "flip-knife-urban-masked", weight: 0.45, value: 105, wear: "MW" },
      // ★ Flip Knife | Black Laminate (MW) — 0.25%
      { skinId: "flip-knife-black-laminate", weight: 0.25, value: 115, wear: "MW" },
      // ★ Flip Knife | Bright Water (FN) — 0.25%
      { skinId: "flip-knife-bright-water", weight: 0.25, value: 115, wear: "FN" },
      // ★ Gut Knife | Fade (MW) — 0.2125%
      { skinId: "gut-knife-fade", weight: 0.2125, value: 140, wear: "MW" },
      // ★ Falchion Knife | Gamma Doppler Phase 3 (FN) — 0.0355%
      { skinId: "falchion-knife-gamma-doppler-4", weight: 0.0355, value: 185, wear: "FN" },
      // ★ Huntsman Knife | Fade (FN) — 0.00125%
      { skinId: "huntsman-knife-fade", weight: 0.00125, value: 195, wear: "FN" },
      // ★ Bayonet | Tiger Tooth (FN) — 0.00075%
      { skinId: "bayonet-tiger-tooth", weight: 0.00075, value: 245, wear: "FN" },
      // ★ Huntsman Knife | Gamma Doppler Emerald (FN) — 0.000015%
      { skinId: "huntsman-knife-gamma-doppler", weight: 0.000015, value: 550, wear: "FN" },
    ],
  },
  {
    id: "glove-syndicate",
    code: "RB-116",
    name: "Glove Syndicate",
    subtitle: "Dress your hands in fortune — leather, silk, snakeskin.",
    kind: "standard",
    tierLabel: "ELITE",
    price: 119,
    tierColor: "#00bfa5",
    tierColor2: "#4e342e",
    items: [
      // ★ Hydra Gloves | Mangrove (BS) — 14.5%
      { skinId: "hydra-gloves-mangrove", weight: 14.5, value: 20, wear: "BS" },
      // ★ Hand Wraps | Arboreal (BS) — 11%
      { skinId: "hand-wraps-arboreal", weight: 11, value: 28, wear: "BS" },
      // ★ Moto Gloves | 3rd Commando Company (FT) — 11%
      { skinId: "moto-gloves-3rd-commando-company", weight: 11, value: 28, wear: "FT" },
      // ★ Hand Wraps | Giraffe (FT) — 11%
      { skinId: "hand-wraps-giraffe", weight: 11, value: 28, wear: "FT" },
      // ★ Specialist Gloves | Buckshot (FT) — 11%
      { skinId: "specialist-gloves-buckshot", weight: 11, value: 30, wear: "FT" },
      // ★ Broken Fang Gloves | Needle Point (FT) — 10%
      { skinId: "broken-fang-gloves-needle-point", weight: 10, value: 35, wear: "FT" },
      // ★ Moto Gloves | POW! (WW) — 10%
      { skinId: "moto-gloves-pow", weight: 10, value: 53, wear: "WW" },
      // ★ Broken Fang Gloves | Jade (FT) — 10.5%
      { skinId: "broken-fang-gloves-jade", weight: 10.5, value: 54, wear: "FT" },
      // ★ Moto Gloves | Smoke Out (FT) — 6%
      { skinId: "moto-gloves-smoke-out", weight: 6, value: 95, wear: "FT" },
      // ★ Sport Gloves | Bronze Morph (MW) — 4.8%
      { skinId: "sport-gloves-bronze-morph", weight: 4.8, value: 114, wear: "MW" },
      // ★ Specialist Gloves | Mogul (MW) — 0.1684%
      { skinId: "specialist-gloves-mogul", weight: 0.1684, value: 125, wear: "MW" },
      // ★ Bloodhound Gloves | Guerrilla (FT) — 0.0175%
      { skinId: "bloodhound-gloves-guerrilla", weight: 0.0175, value: 189, wear: "FT" },
      // ★ Moto Gloves | Blood Pressure (MW) — 0.0095%
      { skinId: "moto-gloves-blood-pressure", weight: 0.0095, value: 194, wear: "MW" },
      // ★ Specialist Gloves | Crimson Web (MW) — 0.0035%
      { skinId: "specialist-gloves-crimson-web", weight: 0.0035, value: 276, wear: "MW" },
      // ★ Sport Gloves | Red Racer (MW) — 0.00075%
      { skinId: "sport-gloves-red-racer", weight: 0.00075, value: 280, wear: "MW" },
      // ★ Sport Gloves | Omega (MW) — 0.00035%
      { skinId: "sport-gloves-omega", weight: 0.00035, value: 430, wear: "MW" },
      // ★ Sport Gloves | Violet Beadwork (MW) — 0.000015%
      { skinId: "sport-gloves-violet-beadwork", weight: 0.000015, value: 560, wear: "MW" },
      // ★ Sport Gloves | Amphibious (MW) — 0.00001%
      { skinId: "sport-gloves-amphibious", weight: 0.00001, value: 589, wear: "MW" },
    ],
  },
  {
    id: "gold-rush",
    code: "RB-117",
    name: "Gold Rush",
    subtitle: "All that glitters actually pays — strike it rich.",
    kind: "standard",
    tierLabel: "ELITE",
    price: 147,
    tierColor: "#ffd54f",
    tierColor2: "#7a5c00",
    items: [
      // MAC-10 | Gold Brick (BS) — 30%
      { skinId: "mac-10-gold-brick", weight: 30, value: 28, wear: "BS" },
      // AK-47 | The Oligarch (FT) — 25%
      { skinId: "ak-47-the-oligarch", weight: 25, value: 35, wear: "FT" },
      // AWP | Queen's Gambit (FT) — 25%
      { skinId: "awp-queen-s-gambit", weight: 25, value: 39, wear: "FT" },
      // M4A1-S | Golden Coil (MW) — 5%
      { skinId: "m4a1-s-golden-coil", weight: 5, value: 75, wear: "MW" },
      // ★ Huntsman Knife | Lore (FN) — 5%
      { skinId: "huntsman-knife-lore", weight: 5, value: 114, wear: "FN" },
      // M4A4 | The Coalition (BS) — 5%
      { skinId: "m4a4-the-coalition", weight: 5, value: 125, wear: "BS" },
      // ★ Bayonet | Lore (BS) — 5%
      { skinId: "bayonet-lore", weight: 5, value: 175, wear: "BS" },
      // AK-47 | Gold Arabesque — 0.000015%
      { skinId: "ak-47-gold-arabesque", weight: 0.000015, value: 850 },
    ],
  },
  {
    id: "urban-ops",
    code: "RB-118",
    name: "Urban Ops",
    subtitle: "Concrete-jungle warfare — gritty odds, honest steel.",
    kind: "standard",
    tierLabel: "RARE",
    price: 19,
    tierColor: "#90a4ae",
    tierColor2: "#232a30",
    items: [
      // M4A4 | Urban DDPAT (MW) — 25%
      { skinId: "m4a4-urban-ddpat", weight: 25, value: 0.3, wear: "MW" },
      // MAC-10 | Urban DDPAT (MW) — 25%
      { skinId: "mac-10-urban-ddpat", weight: 25, value: 1.94, wear: "MW" },
      // Desert Eagle | Urban DDPAT (MW) — 25%
      { skinId: "desert-eagle-urban-ddpat", weight: 25, value: 3.75, wear: "MW" },
      // Galil AR | Urban Rubble (FN) — 24%
      { skinId: "galil-ar-urban-rubble", weight: 24, value: 15.94, wear: "FN" },
      // ★ Shadow Daggers | Urban Masked (FN) — 1%
      { skinId: "shadow-daggers-urban-masked", weight: 1, value: 115, wear: "FN" },
    ],
  },
  {
    id: "glitch-protocol",
    code: "RB-119",
    name: "Glitch Protocol",
    subtitle: "Reality is buffering — pull the anomaly out of the noise.",
    kind: "standard",
    tierLabel: "RARE",
    price: 21,
    tierColor: "#7c4dff",
    tierColor2: "#00e5ff",
    items: [
      // Nova | Smart Gun (WW) — 20%
      { skinId: "nova-smart-gun", weight: 20, value: 1, wear: "WW" },
      // CZ75-Auto | Hydraulics (FT) — 20%
      { skinId: "cz75-auto-hydraulics", weight: 20, value: 1.1, wear: "FT" },
      // M4A4 | Dark Operative (FN) — 19%
      { skinId: "m4a4-dark-operative", weight: 19, value: 4.94, wear: "FN" },
      // AWP | Black Box (MW) — 10%
      { skinId: "awp-black-box", weight: 10, value: 7.12, wear: "MW" },
      // Desert Eagle | Night Heist (BS) — 10%
      { skinId: "desert-eagle-night-heist", weight: 10, value: 11.97, wear: "BS" },
      // Galil AR | Rainbow Spoon (FT) — 10.4%
      { skinId: "galil-ar-rainbow-spoon", weight: 10.4, value: 18.21, wear: "FT" },
      // Five-SeveN | Heat Treated (FN) — 10.4%
      { skinId: "five-seven-heat-treated", weight: 10.4, value: 18.9, wear: "FN" },
      // USP-S | Spiral Glitch (FN) — 0.1%
      { skinId: "usp-s-spiral-glitch", weight: 0.1, value: 71, wear: "FN" },
      // M4A1-S | Fatal Glitch (FN) — 0.1%
      { skinId: "m4a1-s-fatal-glitch", weight: 0.1, value: 89, wear: "FN" },
    ],
  },
  {
    id: "polar-front",
    code: "RB-120",
    name: "Polar Front",
    subtitle: "Frozen assets — break the ice and thaw the value.",
    kind: "standard",
    tierLabel: "STARTER",
    price: 1,
    tierColor: "#b3e5fc",
    tierColor2: "#3d5a6e",
    items: [
      // Nova | Polar Mesh (FN) — 27.5%
      { skinId: "nova-polar-mesh", weight: 27.5, value: 0.1, wear: "FN" },
      // G3SG1 | Polar Camo (FN) — 27.5%
      { skinId: "g3sg1-polar-camo", weight: 27.5, value: 0.2, wear: "FN" },
      // FAMAS | Yeti Camo (FN) — 7.5%
      { skinId: "famas-yeti-camo", weight: 7.5, value: 0.75, wear: "FN" },
      // UMP-45 | Arctic Wolf (FN) — 7.5%
      { skinId: "ump-45-arctic-wolf", weight: 7.5, value: 1.12, wear: "FN" },
      // AUG | Arctic Wolf (MW) — 19%
      { skinId: "aug-arctic-wolf", weight: 19, value: 1.94, wear: "MW" },
      // MP9 | Arctic Tri-Tone (FN) — 10.55%
      { skinId: "mp9-arctic-tri-tone", weight: 10.55, value: 4.2, wear: "FN" },
      // XM1014 | Frost Borre (FT) — 0.275%
      { skinId: "xm1014-frost-borre", weight: 0.275, value: 65, wear: "FT" },
      // ★ Sport Gloves | Frosty (FT) — 0.175%
      { skinId: "sport-gloves-frosty", weight: 0.175, value: 165, wear: "FT" },
    ],
  },
];
