// E2E helper: mint a signed session cookie for an EXISTING non-admin player.
// Never creates players — Task 136 used the same mechanism.
import { db } from "../src/lib/db";
import { makeSessionToken } from "../src/lib/server/auth";

const player = await db.player.findFirst({ where: { isAdmin: false }, orderBy: { id: "asc" } });
if (!player) {
  console.error("NO PLAYER FOUND");
  process.exit(1);
}
console.log(JSON.stringify({ id: player.id, name: player.name, token: makeSessionToken(player.id) }));
process.exit(0);
