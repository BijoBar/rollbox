# -*- coding: utf-8 -*-
"""Finish translating NEOCASE to English (LTR) by exact line replacement.
Line numbers refer to the CURRENT file state (verified via grep)."""
import re, sys

BASE = "/home/z/my-project/"

# {file: {line_no(1-indexed): new content or None to delete}}
EDITS = {
    "src/components/neocase/CaseOpener.tsx": {
        325: '                        x{(winner.value / caseDef.price).toFixed(1)} the case price!',
        337: '                        toast({ title: `Sold for \u20b1${formatCoins(winner.value)}`, description: "Coins added to your balance." });',
        344: '                    Sell for \u20b1{formatCoins(winner.value)}',
        351: '                    Open Again \u2022 \u20b1{formatCoins(caseDef.price)}',
        359: '                    Keep in Inventory & Close',
        369: '              <p className="mb-2 text-xs font-bold text-white/45">Possible contents:</p>',
    },
    "src/components/neocase/InventoryDrawer.tsx": {
        39: '        side="right"',
        40: None,  # delete style={{ direction: "rtl" }}
        45: '            My Inventory',
        47: '              {inventory.length} items',
        53: '              Total value: \u20b1{formatCoins(totalValue)}',
        58: '                Best drop: \u20b1{formatCoins(bestValue)}',
        70: '              <p className="text-lg font-bold text-white/70">Inventory empty</p>',
        72: '                Open a case from the list and the skins you win will appear here.',
        98: '                            title: `Sold: ${skin.name}`,',
        99: '                            description: `+\u20b1${formatCoins(itemValue(item.skinId))} to your balance`,',
        102: '                        aria-label={`Sell ${skin.name}`}',
        106: '                        Sell \u20b1{formatCoins(itemValue(item.skinId))}',
        120: '                      title: "Entire inventory sold",',
        121: '                      description: `+\u20b1${formatCoins(total)} to your balance`,',
        126: '                  Sell All \u2022 \u20b1{formatCoins(totalValue)}',
    },
    "src/components/neocase/LiveDrops.tsx": {
        9: '  "NitroKing", "ShadowZ", "AceHunter17", "xXNovaXx", "TomerHD", "KobiJudge",',
        10: '  "EitanSniper", "MichalBot", "Zugi_", "AmitBlade", "Roni_Flex",',
        11: '  "DanielPro", "Itay1v9", "LeeTriHard", "OldSchoolOmer", "Gal_Gamer",',
        12: '  "NoamSniper", "Yuval_Clash", "Talia_Frag", "ClutchOmer",',
        62: '      aria-label="Live drops feed"',
    },
    "src/components/neocase/SkinTile.tsx": {
        87: None,  # delete dir="rtl"
    },
}

ok = True
for rel, edits in EDITS.items():
    path = BASE + rel
    lines = open(path, encoding="utf-8").read().split("\n")
    for ln in sorted(edits, reverse=True):  # bottom-up so deletions don't shift
        idx = ln - 1
        if idx >= len(lines):
            print(f"FAIL {rel}:{ln} out of range"); ok = False; continue
        new = edits[ln]
        if new is None:
            print(f"DEL  {rel}:{ln}: {lines[idx].strip()!r}")
            del lines[idx]
        else:
            print(f"SET  {rel}:{ln}")
            lines[idx] = new
    open(path, "w", encoding="utf-8").write("\n".join(lines))

# final safety sweep: any Hebrew or rtl leftovers anywhere in src/?
print("\n--- leftover Hebrew / RTL scan ---")
left = 0
import os
for root, _, files in os.walk(BASE + "src"):
    for f in files:
        if not f.endswith((".ts", ".tsx", ".css")):
            continue
        p = os.path.join(root, f)
        for i, l in enumerate(open(p, encoding="utf-8"), 1):
            if re.search(r"[\u0590-\u05FF]", l) or 'dir="rtl"' in l or 'direction: "rtl"' in l or re.search(r"\bmr-\d|\bml-\d", l) and False:
                print(f"LEFT {p}:{i}: {l.strip()!r}"); left += 1
print("clean" if left == 0 else f"{left} leftovers")
sys.exit(0 if ok else 1)
