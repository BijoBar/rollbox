"""Task 49 E2E — the site is ONE shared multiplayer world on the database.

Proves with two cookie-forged browser contexts (real sessions, no backdoors):
  A. /login renders BOTH sign-in options (Steam + Google).
  B. Player A creates a battle in the original builder -> the room is GLOBAL
     (RB- code, waiting, worldwide hint).
  C. Player B sees the SAME battle in their own lobby and JOINS it from there
     (the server charges B's DB entry) -> the room AUTO-STARTS (full at 2/2).
  D. Both browsers animate the SAME server-rolled pulls on the shared clock
     and reach the same finished outcome; the pot equals the sum of all pulls;
     the winner's DATABASE balance gains exactly the pot; the loser walks at
     balance - entry.
  E. The drops land in the ONE live feed + the site stats counters move.
  F. A solo server roll shows up in the live feed and bumps casesOpened.
"""
import json
import subprocess
import sys
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = Path("/home/z/my-project/download/e2e-shots")
SHOTS.mkdir(parents=True, exist_ok=True)
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS  " if ok else "FAIL  ") + name + ("  — " + detail if detail else ""))

# ---- mint two real DB sessions + clean the world --------------------------
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
out = subprocess.run(
    ["bun", "scripts/mint-session.mjs"], capture_output=True, text=True, cwd="/home/z/my-project"
).stdout.strip().splitlines()
A, B = json.loads(out[0]), json.loads(out[1])
print(f"sessions: A={A['name']}({A['id']}) B={B['name']}({B['id']})")

stats0 = json.loads(subprocess.run(["curl", "-s", BASE + "/api/stats"], capture_output=True, text=True).stdout)

def wait_daily_settled(ctx, timeout=45):
    """Waits until the +300 daily bonus has landed (balance stabilizes above
    the 1300 start) so entry-charge math is exact."""
    deadline = time.time() + timeout
    bal = None
    while time.time() < deadline:
        bal = ctx.request.get(BASE + "/api/auth/me").json()["player"]["balance"]
        if bal != 1300:  # daily (+300) claimed
            return bal
        time.sleep(1.0)
    return bal  # daily never came (already claimed earlier today) — take it as-is

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    ctxA = browser.new_context(viewport={"width": 1440, "height": 900})
    ctxB = browser.new_context(viewport={"width": 1440, "height": 900})
    ctxA.add_cookies([{"name": "rb_session", "value": A["token"], "url": BASE}])
    ctxB.add_cookies([{"name": "rb_session", "value": B["token"], "url": BASE}])
    pa, pb = ctxA.new_page(), ctxB.new_page()

    # ---- A. the login page is STEAM-ONLY (Task 64) -------------------------
    pg = browser.new_context().new_page()
    pg.goto(BASE + "/login", wait_until="domcontentloaded")
    pg.wait_for_timeout(1200)
    body = pg.inner_text("body")
    check("login shows STEAM option", "STEAM" in body.upper())
    check("login shows GOOGLE option", "GOOGLE" not in body.upper())
    resp = pg.request.get(BASE + "/api/auth/google/start")
    check("google auth routes removed (404/405)", resp.status in (404, 405))
    pg.screenshot(path=str(SHOTS / "49-login.png"))
    pg.close()

    # ---- B. A creates a battle in the original builder --------------------
    pa.goto(BASE + "/battles/new", wait_until="domcontentloaded")
    pa.wait_for_timeout(1500)
    # wait for the DATABASE session to load (the builder enables Create once `me` lands)
    try:
        pa.wait_for_selector("button:has-text('Create Battle')", timeout=15000)
        check("A's session loaded in the builder", True)
    except Exception:
        check("A's session loaded in the builder", False)
    # the daily bonus (+300) auto-claims on A's first page load — WAIT for it
    # to land so the ledger baseline is deterministic
    base_bal = wait_daily_settled(ctxA)
    pa.get_by_role("button", name="Add a case to the battle").click(timeout=6000)
    pa.wait_for_timeout(600)
    pa.get_by_role("button", name="Add TEST, price $10").click(timeout=6000)
    pa.wait_for_timeout(400)
    pa.keyboard.press("Escape")
    pa.wait_for_timeout(500)
    pa.locator("button:has-text('Create Battle')").first.click(timeout=5000)
    battle_id = ""
    deadline = time.time() + 12
    while time.time() < deadline:
        seg = pa.url.rstrip("/").split("/")[-1]
        if seg != "new" and "/battles/" in pa.url:
            battle_id = seg
            break
        time.sleep(0.3)
    if not battle_id:
        # hydration-proof fallback: read the newest waiting battle id from the API
        r = ctxA.request.get(BASE + "/api/gbattles")
        lst = r.json().get("battles", [])
        if lst:
            battle_id = lst[0]["id"]
            pa.goto(BASE + f"/battles/{battle_id}", wait_until="domcontentloaded")
    check("A created the battle -> room", bool(battle_id), "id=" + battle_id)
    pa.wait_for_timeout(2200)
    room_txt = pa.inner_text("body")
    room_sum0 = ctxA.request.get(BASE + "/api/gbattles").json()["battles"]
    mine0 = next((r for r in room_sum0 if r["id"] == battle_id), None)
    # the restored room header no longer prints the code — verify it on the server
    check("room is a GLOBAL room (RB- code)", bool(mine0 and mine0["code"].startswith("RB-")),
          "code=" + (mine0["code"] if mine0 else "?"))
    check("room waits for players", "Waiting" in room_txt or "WAITING" in room_txt.upper())
    me_a = ctxA.request.get(BASE + "/api/auth/me").json()["player"]
    check("A's DB entry charged", me_a["balance"] == base_bal - 10, f"bal={me_a['balance']} want={base_bal - 10}")
    room_sum = ctxA.request.get(BASE + "/api/gbattles").json()["battles"]
    mine = next((r for r in room_sum if r["id"] == battle_id), None)
    check("A's battle in the shared list", mine is not None)
    room_code = mine["code"] if mine else "RB-????"

    # ---- C. B sees the SAME battle in their lobby and joins ---------------
    pb.goto(BASE + "/battles", wait_until="domcontentloaded")
    pb.wait_for_timeout(2500)
    try:
        pb.wait_for_selector(f"text=E2E Bravo", timeout=10000)  # DB session loaded
        check("B's session loaded in the lobby", True)
    except Exception:
        check("B's session loaded in the lobby", False)
    time.sleep(1.0)
    base_bal_b = wait_daily_settled(ctxB)
    lob = pb.inner_text("body")
    # the restored rows no longer print codes — the SHARED list is proven by
    # the server API + the joinable row in B's own lobby
    shared_lst = pb.context.request.get(BASE + "/api/gbattles").json().get("battles", [])
    check("B's lobby lists A's battle (shared world)", any(b["id"] == battle_id for b in shared_lst))
    check("B's lobby shows a JOIN for the waiting room", "JOIN" in lob.upper())
    joined = False
    deadline = time.time() + 15
    while time.time() < deadline and not joined:
        try:
            # JOIN on A's battle row specifically (scope by the TEST case tile)
            row = pb.locator(f"div[role='listitem']", has_text="TEST").first
            btn = row.locator("button:has-text('JOIN')").first
            if btn.is_visible():
                btn.click(timeout=2000)
                joined = True
                break
        except Exception:
            pass
        time.sleep(0.6)
    check("B pressed JOIN from the lobby", joined)
    # room auto-started at 2/2 -> B lands in the rolling room
    deadline = time.time() + 20
    while time.time() < deadline:
        if "/battles/" in pb.url and pb.url.rstrip("/").split("/")[-1] not in ("battles", "new"):
            break
        time.sleep(0.3)
    # The server engine auto-starts at 2/2 and can SETTLE during this poll —
    # a winning B already holds the pot here. The EXACT win/lose ledgers are
    # asserted after the finish below; here we pin the charge itself:
    # balance must have moved off the starting base and never below base-entry.
    bal_b = None
    deadline = time.time() + 15
    while time.time() < deadline:
        bal_b = ctxB.request.get(BASE + "/api/auth/me").json()["player"]["balance"]
        if bal_b != base_bal_b:  # the entry charge (± the pot) has landed
            break
        time.sleep(0.5)
    check("B's DB entry charged", bal_b != base_bal_b and bal_b >= base_bal_b - 10,
          f"bal={bal_b} base={base_bal_b} (in-flight={base_bal_b - 10})")
    st = None
    deadline = time.time() + 60
    while time.time() < deadline and st is None:
        try:
            st = ctxA.request.get(BASE + f"/api/gbattles/{battle_id}").json()["battle"]
        except Exception:
            time.sleep(1.0)  # dev-compile hiccup on a fresh route
    # by the time this lands the 1-round TEST battle may ALREADY be finished —
    # either state proves the room auto-started at 2/2
    check("room AUTO-STARTED at 2/2", st is not None and st["status"] in ("playing", "finished"), "status=" + (st["status"] if st else "?"))
    pa.screenshot(path=str(SHOTS / "49-rolling-a.png"))
    pb.screenshot(path=str(SHOTS / "49-rolling-b.png"))

    # ---- D. both finish; ledger exact -------------------------------------
    deadline = time.time() + 90
    fin = None
    while time.time() < deadline:
        st = ctxA.request.get(BASE + f"/api/gbattles/{battle_id}").json()["battle"]
        if st["status"] == "finished":
            fin = st
            break
        time.sleep(1.0)
    check("battle settled server-side", fin is not None)
    if fin:
        time.sleep(2.5)  # let both clients land on the finished view
        pa.screenshot(path=str(SHOTS / "49-done-a.png"))
        pb.screenshot(path=str(SHOTS / "49-done-b.png"))
        pot = fin["potTotal"] or 0
        pulls_sum = sum(p["value"] for r in fin["results"] for p in r["pulls"])
        check("pot = sum of ALL pulls", pot == pulls_sum, f"pot={pot} sum={pulls_sum}")
        wid = (fin["winnerIds"] or [])[0]
        winner, loser = (A, B) if wid == A["id"] else (B, A)
        wa = ctxA.request.get(BASE + "/api/auth/me").json()["player"]["balance"]
        wb = ctxB.request.get(BASE + "/api/auth/me").json()["player"]["balance"]
        wbal = wa if wid == A["id"] else wb
        lbal = wb if wid == A["id"] else wa
        check("winner credited EXACTLY the pot", wbal == base_bal - 10 + pot, f"{wbal} vs {base_bal - 10 + pot}")
        check("loser walks at balance - entry", lbal == base_bal_b - 10, f"{lbal}")
        a_txt, b_txt = pa.inner_text("body"), pb.inner_text("body")
        # the ORIGINAL verdict: VICTORY! on the winner's screen, BATTLE LOST! on the loser's
        both_show = ("VICTORY" in a_txt.upper() or "YOU WIN" in a_txt) and ("VICTORY" in b_txt.upper() or "BATTLE LOST" in b_txt.upper())
        check("both browsers show the finished outcome", both_show)

    # ---- E/F. solo server roll -> live feed + stats ------------------------
    r = ctxA.request.post(BASE + "/api/open", data={"caseId": "test-rolldrop", "count": 1})
    od = r.json()
    check("solo server roll ok", r.ok and "pulls" in od, json.dumps(od)[:90])
    time.sleep(0.6)
    live = ctxB.request.get(BASE + "/api/live").json()["drops"]
    check("solo drop in THE global live feed", any(d.get("user") == A["name"] for d in live))
    live_b = pb.inner_text("body")
    check("B's live-drops bar shows real activity", "LIVE DROPS" in live_b.upper())
    stats1 = json.loads(subprocess.run(["curl", "-s", BASE + "/api/stats"], capture_output=True, text=True).stdout)
    check("casesOpened counter moved (+battle rounds +solo)", stats1["casesOpened"] >= stats0["casesOpened"] + 3,
          f"{stats0['casesOpened']} -> {stats1['casesOpened']}")
    check("players registered counter >= 2", stats1["players"] >= 2, f"{stats1['players']}")
    check("coinsPaid counter > 0", stats1["coinsPaid"] > 0, f"{stats1['coinsPaid']}")
    pb.goto(BASE + "/battles", wait_until="domcontentloaded")
    pb.wait_for_timeout(1800)
    check("lobby renders the shared open-battles list", "OPEN BATTLES" in pb.inner_text("body").upper())
    pb.screenshot(path=str(SHOTS / "49-lobby-stats.png"))

    browser.close()

print("\n===== VERDICT =====")
fails = [r for r in results if not r[1]]
for name, ok, det in results:
    print(("PASS  " if ok else "FAIL  ") + name)
print("RESULT:", "ALL PASS" if not fails else "%d FAILURES" % len(fails))
sys.exit(0 if not fails else 1)
