#!/usr/bin/env python3
# ============ build-terminal-editor.py (Task 26; Task 94: daily vaults) ============
# Builds the DROP EDITOR (ROLLBOX-drop-editor.html) by injecting into
# scripts/terminal-editor.template.html:
#   1. the SKINS catalog + BASE_TERMINALS lines — taken from the CASE EDITOR
#      (single source of truth), with fallback search paths;
#   2. the DAILY_CASES line — parsed straight out of src/lib/level-cases.ts
#      (the 10 free LEVEL vaults: tier + raw [skinId, weight] pairs, exactly
#      as the site normalizes them).
# Re-run whenever the catalog or the daily vaults change:
#   python3 scripts/build-terminal-editor.py
import json
import re
from pathlib import Path

ROOT = Path("/home/z/my-project")
TPL = ROOT / "scripts" / "terminal-editor.template.html"
LEVEL_CASES_TS = ROOT / "src" / "lib" / "level-cases.ts"
OUTS = [
    ROOT / "editor" / "ROLLBOX-terminal-editor.html",
    ROOT / "ROLLBOX-drop-editor.html",
    ROOT / "download" / "ROLLBOX-drop-editor.html",
]
CASES_EDITOR_CANDIDATES = [
    ROOT / "editor" / "ROLLBOX-cases-editor.html",
    ROOT / "upload" / "zip-restore" / "rollbox-site-latest" / "ROLLBOX" / "ROLLBOX-cases-editor.html",
    ROOT / "upload" / "zip-restore" / "ROLLBOX" / "ROLLBOX-cases-editor.html",
]

cases_path = next((p for p in CASES_EDITOR_CANDIDATES if p.exists()), None)
if not cases_path:
    raise SystemExit("ROLLBOX-cases-editor.html not found (looked in editor/ and zip-restore fallbacks)")
cases = cases_path.read_text(encoding="utf-8")
skins_line = next(l for l in cases.splitlines() if l.startswith("const SKINS = "))
base_line = next(l for l in cases.splitlines() if l.startswith("const BASE_TERMINALS = "))

# ---- parse the DAILY vaults (LEVEL 10..100) out of level-cases.ts ----
def balanced_block(text: str, open_idx: int) -> str:
    """text[open_idx] == '[' — return the full [ ... ] block (balanced)."""
    depth = 0
    for i in range(open_idx, len(text)):
        if text[i] == "[":
            depth += 1
        elif text[i] == "]":
            depth -= 1
            if depth == 0:
                return text[open_idx : i + 1]
    raise ValueError("unbalanced brackets")

ts = LEVEL_CASES_TS.read_text(encoding="utf-8")
dailies = []
for m in re.finditer(r"tier:\s*(\d+),", ts):
    tier = int(m.group(1))
    items_m = re.search(r"items:\s*\[", ts[m.end():])
    if not items_m:
        continue
    block = balanced_block(ts, m.end() + items_m.end() - 1)
    pairs = re.findall(r'\[\s*"([a-z0-9-]+)"\s*,\s*([0-9.]+)\s*\]', block)
    if not pairs:
        continue
    dailies.append({"id": f"level-{tier}", "tier": tier, "items": [[sid, float(w)] for sid, w in pairs]})
dailies.sort(key=lambda c: c["tier"])
if len(dailies) != 10:
    raise SystemExit(f"expected 10 daily vaults in level-cases.ts, found {len(dailies)}")
daily_line = "const DAILY_CASES = " + json.dumps(dailies, separators=(",", ":"), ensure_ascii=False) + ";"

tpl = TPL.read_text(encoding="utf-8")
tpl = tpl.replace("//__SKINS_LINE__", skins_line)
tpl = tpl.replace("//__BASE_LINE__", base_line)
tpl = tpl.replace("//__DAILY_LINE__", daily_line)

for out in OUTS:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(tpl, encoding="utf-8")
    print(f"wrote {out} ({out.stat().st_size/1024:.0f} KB)")
print("cases editor :", cases_path)
print("skins line   :", skins_line[:60] + "…")
print("base line    :", base_line[:60] + "…")
print("daily line   :", daily_line[:90] + "…")
print("daily vaults :", [c["id"] for c in dailies])
