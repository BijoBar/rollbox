#!/usr/bin/env bash
# e2e-t177.sh — THE BIG FIX E2E (Task 177)
# Covers: home fair-odds line deleted · provably-fair HOW TO USE link + guide ·
# battle-create CRAZY/FAST/PRIVATE red-OFF/green-ON toggles + green money ·
# community case art on the reel (case page + battle room) · battle winner card
# (WINNER + WON : $x in the winner's square, loser skins transferred, no
# CHOOSE BOT anywhere) · upgrader 12s spin + big displays + $350 cap + live
# verdict ≥12s · support chat live AI reply.
# LESSONS (t175/t176): agent-browser eval returns JSON-QUOTED strings — strip
# backslashes / never exact-compare; innerText applies CSS text-transform
# (compare case-insensitively); textContent does NOT.
set -uo pipefail
cd /home/z/my-project
AB="agent-browser"
SHOT="scripts/e2e-t177"
BASE="http://localhost:3000"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0
check() { $AB eval "$1" 2>/dev/null | rg -o "true|false" | head -1; }
# un-quote an eval JSON string then grep for a pattern
jhas() { echo "$1" | sed 's/\\//g' | rg -q "$2"; }

TOKEN="$(bun scripts/mint-e2e-session.ts 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')"

# ============================================================ STAGE A (guest)
$AB close >/dev/null 2>&1 || true
sleep 1
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open "$BASE/" >/dev/null
sleep 3.5

# 1. home — the fair-odds caption is GONE from every case card
home=$(check "document.body.innerText.includes('Completely fair odds')")
cards=$(check "document.querySelectorAll('a[href^=\"/case/\"]').length >= 3")
[ "$home" = "false" ] && ok "home: 'Completely fair odds' caption deleted" || fail "home: fair-odds caption still present"
[ "$cards" = "true" ] && ok "home: case cards still render" || fail "home: case cards missing"

# 2. provably fair — HOW TO USE link
$AB open "$BASE/provably-fair" >/dev/null
sleep 2.5
lnk=$(check "!!document.querySelector('a[href=\"/provably-fair/how-to-use\"]')")
[ "$lnk" = "true" ] && ok "provably-fair: HOW TO USE link present" || fail "provably-fair: HOW TO USE link missing"

# 3. the guide page itself
$AB open "$BASE/provably-fair/how-to-use" >/dev/null
sleep 2.5
g1=$(check "document.body.innerText.toUpperCase().includes('HOW TO')")
g2=$(check "document.body.innerText.includes('SERVER SEED field')")
g3=$(check "!!document.querySelector('pre')")
[ "$g1" = "true" ] && [ "$g2" = "true" ] && [ "$g3" = "true" ] && ok "guide page renders (steps + copy-where checklist + commands)" || fail "guide page content incomplete"

# 4. battle create — toggles red OFF / green ON + green money + no choose-bot
$AB open "$BASE/battles/new" >/dev/null
sleep 3
off=$($AB eval "(() => { const b=[...document.querySelectorAll('button')]; const norm=(x)=>x.textContent.replace(/\\s+/g,' ').trim().toLowerCase(); const get=(t)=>b.find(x=>norm(x).startsWith(t)); const getInc=(t)=>b.find(x=>norm(x).includes(t)); const c=get('crazy mode'); const f=getInc('fast mode'); const p=get('private'); return JSON.stringify({crazy:!!c&&c.textContent.includes('OFF')&&c.className.includes('border-red-500/40'), fast:!!f&&f.textContent.includes('OFF')&&f.className.includes('border-red-500/40'), priv:!!p&&p.textContent.includes('OFF')&&p.className.includes('border-red-500/40')}); })()" 2>/dev/null)
echo "toggle OFF styles: $off"
jhas "$off" '"crazy":true' && ok "create: CRAZY MODE OFF = red" || fail "create: crazy OFF style ($off)"
jhas "$off" '"fast":true' && ok "create: FAST MODE OFF = red" || fail "create: fast OFF style ($off)"
jhas "$off" '"priv":true' && ok "create: PRIVATE OFF = red" || fail "create: private OFF style ($off)"

# flip CRAZY on → green
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.replace(/\\s+/g,' ').trim().toLowerCase().startsWith('crazy mode')); b?.click(); return 'clicked'; })()" >/dev/null 2>&1
sleep 0.6
on=$($AB eval "(() => { const c=[...document.querySelectorAll('button')].find(x=>x.textContent.includes('Crazy mode ON')); return JSON.stringify({on:!!c, green:!!c&&c.className.includes('from-emerald-400')}); })()" 2>/dev/null)
jhas "$on" '"green":true' && ok "create: CRAZY MODE ON = green" || fail "create: crazy ON style ($on)"

green=$($AB eval "(() => { const row=[...document.querySelectorAll('div')].find(d=>d.textContent.trim().startsWith('Your balance')); const v=row?.querySelector('span.text-emerald-300'); return JSON.stringify({bal:!!row, green:!!v, val:v?.textContent?.trim()}); })()" 2>/dev/null)
echo "balance row: $green"
jhas "$green" '"bal":true' && jhas "$green" '"green":true' && ok "create: money rendered in green" || fail "create: money color ($green)"
nob=$(check "!document.body.innerText.toLowerCase().includes('choose bot')")
[ "$nob" = "true" ] && ok "create: no 'choose bot' anywhere" || fail "create: choose-bot text present"

# ============================================================ STAGE B (session)
$AB close >/dev/null 2>&1 || true
sleep 1
$AB open "$BASE/" >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
sleep 2

# 5. community case art ON THE REEL (case opening screen on-deck art)
$AB open "$BASE/case/cc_mu4yd2w4joap45" >/dev/null
sleep 3.5
cc=$(check "!!document.querySelector('img[src*=\"communitycase\"]')")
[ "$cc" = "true" ] && ok "community case: chosen art renders on the opening screen" || fail "community case: reel art missing"

# 6. battle — create with the community case + FAST, call bots, verify verdict
$AB open "$BASE/battles/new" >/dev/null
sleep 3
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>/fast mode/i.test(x.textContent)); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 0.4
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.getAttribute('aria-label')==='Add a case to the battle'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 1.2
tab=$($AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Community Cases')); t?.click(); return t?'tab-ok':'no-tab'; })()" 2>/dev/null)
echo "picker community tab: $tab"
sleep 0.8
added=$($AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>(x.getAttribute('aria-label')||'').startsWith('Add T66 Galaxy Case')); t?.click(); return t?'added':'no-tile'; })()" 2>/dev/null)
echo "community tile: $added"
jhas "$added" "added" && ok "battle: community case added as the round" || fail "battle: community tile click ($added)"
sleep 0.5
$AB eval "document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); 'esc'" >/dev/null 2>&1
sleep 0.8
created=$($AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim()==='Create Battle'); if(!b||b.disabled) return 'blocked'; b.click(); return 'creating'; })()" 2>/dev/null)
jhas "$created" "creating" && ok "battle: create pressed" || fail "battle: create blocked ($created)"
sleep 5
url=$($AB eval "location.pathname" 2>/dev/null | sed 's/\\//g' | rg -o "/battles/[A-Za-z0-9_-]+" | head -1)
if [ -n "$url" ] && [ "$url" != "/battles/new" ]; then ok "battle: room opened at $url"; else fail "battle: did not land in a room ($url)"; fi
# call the bots
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Call Bots')); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 14
win=$(check "!!document.querySelector('[data-testid=\"battle-winner-card\"]')")
wtext=$($AB eval "(() => { const c=document.querySelector('[data-testid=\"battle-winner-card\"]'); return c?c.textContent:''; })()" 2>/dev/null)
echo "winner card text: $wtext"
echo "$wtext" | sed 's/\\//g' | rg -qi "WINNER" && echo "$wtext" | sed 's/\\//g' | rg -q "WON :" && ok "verdict: winner card shows WINNER + WON : \$x (in the winner's square)" || fail "verdict: winner card text ($wtext)"
[ "$win" = "true" ] && ok "verdict: winner card replaced the reel square" || fail "verdict: no winner card"
tr=$(check "document.body.innerText.toLowerCase().includes('all skins transferred to the winner')")
[ "$tr" = "true" ] && ok "verdict: loser skins transferred to the winner's side" || fail "verdict: transfer note missing"
nob2=$(check "!document.body.innerText.toLowerCase().includes('choose bot')")
[ "$nob2" = "true" ] && ok "room: no CHOOSE BOT anywhere" || fail "room: choose-bot present"
ccroom=$(check "!!document.querySelector('img[src*=\"communitycase\"]')")
[ "$ccroom" = "true" ] && ok "room: community case art rides the battle (strip)" || fail "room: community art missing"
$AB screenshot "$SHOT-battle.png" >/dev/null 2>&1

# 7. upgrader — 12s spin, big displays, cap, labels, live verdict
$AB open "$BASE/upgrader" >/dev/null
sleep 4
u1=$(check "document.body.innerText.toLowerCase().includes('inventory — pick your stake')")
u2=$(check "document.body.innerText.toLowerCase().includes('pick upgrade')")
u3=$(check "document.body.innerText.toLowerCase().includes('max stake \$350 per spin')")
u4=$(check "!!document.querySelector('[data-testid=\"upgrader-stake-display\"]') && !!document.querySelector('[data-testid=\"upgrader-outcome-display\"]')")
[ "$u1" = "true" ] && ok "upgrader: label renamed to Inventory" || fail "upgrader: Inventory label"
[ "$u2" = "true" ] && ok "upgrader: label renamed to PICK UPGRADE" || fail "upgrader: PICK UPGRADE label"
[ "$u3" = "true" ] && ok "upgrader: \$350 cap shown on the panel" || fail "upgrader: cap note"
[ "$u4" = "true" ] && ok "upgrader: big STAKE + OUTCOME displays present" || fail "upgrader: displays missing"
# select the cheapest skin → displays fill
sel=$($AB eval "(() => { const b=[...document.querySelectorAll('button')].filter(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')).sort((a,c)=>{const va=parseFloat(a.getAttribute('aria-label').match(/([\d.]+)\s*coins\)/)?.[1]??1e9), vc=parseFloat(c.getAttribute('aria-label').match(/([\d.]+)\s*coins\)/)?.[1]??1e9); return va-vc;})[0]; b?.click(); return b?'selected':'none'; })()" 2>/dev/null)
jhas "$sel" "selected" && ok "upgrader: cheapest skin selected" || fail "upgrader: no skin to select ($sel)"
sleep 2.2
sd=$(check "document.querySelector('[data-testid=\"upgrader-stake-display\"]')?.textContent.length>25 && !document.querySelector('[data-testid=\"upgrader-stake-display\"]')?.textContent.includes('shows up here BIG')")
od=$(check "!!document.querySelector('[data-testid=\"upgrader-outcome-display\"] img')")
[ "$sd" = "true" ] && ok "upgrader: stake display shows the selected skin" || fail "upgrader: stake display empty"
[ "$od" = "true" ] && ok "upgrader: outcome display shows the potential prize" || fail "upgrader: outcome display empty"
# spin — the verdict must land AFTER ~12s (not earlier)
armed=$($AB eval '(() => { const btn=document.querySelector("[data-testid=\"upgrader-spin\"]"); if(!btn) return "no-btn"; window.__t177={t0:0,landed:0}; btn.addEventListener("click",()=>{window.__t177.t0=Date.now();},{capture:true,once:true}); window.__t177t=setInterval(()=>{ const r=document.querySelector("[data-testid=\"upgrader-result\"]"); if(window.__t177.t0&&!window.__t177.landed&&r&&r.textContent.trim().length>3) window.__t177.landed=Date.now()-window.__t177.t0; },200); return "armed"; })()' 2>/dev/null)
jhas "$armed" "armed" && ok "upgrader: spin probe armed" || fail "upgrader: probe ($armed)"
$AB eval "document.querySelector('[data-testid=\"upgrader-spin\"]')?.click(); 'clicked'" >/dev/null 2>&1
sleep 1.5
t12=$(check "[...document.querySelectorAll('[data-testid=\"upgrader-wheel\"] svg g')].some(g => (g.getAttribute('style')||'').includes('12000ms'))")
[ "$t12" = "true" ] && ok "upgrader: wheel transition is 12000ms (12s spin)" || fail "upgrader: transition is not 12s"
sleep 13
res=$($AB eval "JSON.stringify(window.__t177||{})" 2>/dev/null | head -1)
landed=$(echo "$res" | python3 -c "
import json,sys
raw=sys.stdin.read().strip()
try: d=json.loads(json.loads(raw)) if raw.startswith('\"') else json.loads(raw)
except Exception: d={}
print(d.get('landed',-1))
")
if [ "$landed" -ge 11500 ] 2>/dev/null; then ok "upgrader: verdict landed at ${landed}ms — the 12s tension spin is real"; else fail "upgrader: verdict timing ${landed}ms"; fi
$AB screenshot "$SHOT-upgrader.png" >/dev/null 2>&1

# 8. support chat — live AI reply without any refresh
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.getAttribute('aria-label')==='Open support chat'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 1.2
$AB eval "(() => { const c=[...document.querySelectorAll('button')].find(x=>x.className.includes('rounded-full')&&x.textContent.includes('What')); c?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 3.5
ai=$(check "document.body.innerText.includes('ROLLBOX AI')")
[ "$ai" = "true" ] && ok "support: AI answer lands live (no refresh)" || fail "support: no live AI reply"
$AB screenshot "$SHOT-support.png" >/dev/null 2>&1

# console + page errors
errs=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -8)
if [ -z "$errs" ]; then ok "zero page errors"; else fail "page errors: $errs"; fi

# cleanup
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open about:blank >/dev/null 2>&1 || true

[ "$FAILED" = "0" ] && echo "== E2E t177: ALL PASS ==" || echo "== E2E t177: FAILURES =="
exit $FAILED
