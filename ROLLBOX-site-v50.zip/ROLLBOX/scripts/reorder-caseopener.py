"""Reorder beginRound before startSpin in CaseOpener.tsx (TDZ fix)."""
import re

PATH = "/home/z/my-project/src/components/rollbox/CaseOpener.tsx"
src = open(PATH).read()

START_SPIN_MARK = "  const startSpin = useCallback(() => {"
BEGIN_MARK = "  /** The shared spin pipeline — local and server rolls both land here."

i_spin = src.index(START_SPIN_MARK)
i_begin = src.index(BEGIN_MARK)
assert i_spin < i_begin, f"unexpected order: spin@{i_spin} begin@{i_begin}"

spin_block = src[i_spin:i_begin]
begin_block = src[i_begin:]

# begin_block runs to the end of its useCallback closer + blank line before the
# next top-level statement — find the closer: it ends with "\n  );\n\n" followed
# by "  if (!caseDef) return null;"
END_ANCHOR = "\n  if (!caseDef) return null;"
i_end = begin_block.index(END_ANCHOR)
begin_body = begin_block[: i_end + 1]  # include the trailing newline after ");"
tail = begin_block[i_end + 1 :]

new = src[:i_spin] + begin_body.rstrip() + "\n\n" + spin_block.rstrip() + "\n\n" + tail.lstrip("\n")
open(PATH, "w").write(new)
print("reordered OK")
