// ============ Task 23 E2E — server-side tests for UPGRADER + TERMINAL ============
// Creates a disposable test player, mints a signed session cookie (the same
// HMAC the server uses) and exercises: upgrader win/lose, terminal play +
// claim + double-claim guard, admin battles gate, then cleans EVERYTHING up.
import { createRequire } from "module";
import crypto from "crypto";
const require = createRequire(import.meta.url);
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
const fs = await import("fs");

const SECRET = fs.readFileSync("/home/z/my-project/db/.auth-secret", "utf8").trim();
const sign = (p) => crypto.createHmac("sha256", SECRET).update(p).digest("base64url");
const tokenFor = (pid) => {
  const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 86400000 })).toString("base64url");
  return `${body}.${sign(body)}`;
};

const PID = "p_t23test";
const BASE = "http://localhost:3000";
let fails = 0;
const ok = (name, cond, extra = "") => {
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${extra ? " — " + extra : ""}`);
  if (!cond) fails++;
};

// ---- setup: test player + admin test player ----
await db.player.upsert({
  where: { id: PID },
  create: { id: PID, provider: "steam", providerId: "7650000000023999", name: "T23 TEST", balance: 500 },
  update: { balance: 500, bannedAt: null },
});
const adminId = "p_t72B";
const cookie = "rb_session=" + tokenFor(PID);
const adminCookie = "rb_session=" + tokenFor(adminId);
const H = { "Content-Type": "application/json", cookie };

const bal = async () => (await db.player.findUnique({ where: { id: PID } })).balance;

// ================= UPGRADER =================
console.log("--- UPGRADER ---");
{
  const r = await fetch(BASE + "/api/upgrader", { method: "POST", headers: H, body: JSON.stringify({ amount: 10, multiplier: 2 }) });
  const d = await r.json();
  ok("upgrader 200", r.status === 200, JSON.stringify(d).slice(0, 90));
  ok("chance = 0.95/2 = 0.475", Math.abs(d.chance - 0.475) < 1e-9, String(d.chance));
  ok("target = 20", d.target === 20, String(d.target));
  ok("balance moved to 490 or 510", [490, 510].includes(Math.round(d.balance)), String(d.balance));
  const after = await bal();
  ok("db balance matches response", Math.abs(after - d.balance) < 1e-9);
  const ledger = await db.ledger.findFirst({ where: { playerId: PID, kind: { in: ["upgrader_win", "upgrader_loss"] } }, orderBy: { id: "desc" } });
  ok("ledger row written", !!ledger, ledger?.kind);
}
{
  // invalid inputs
  const r1 = await fetch(BASE + "/api/upgrader", { method: "POST", headers: H, body: JSON.stringify({ amount: 0.2, multiplier: 2 }) });
  ok("stake < 1 rejected", r1.status === 400);
  const r2 = await fetch(BASE + "/api/upgrader", { method: "POST", headers: H, body: JSON.stringify({ amount: 100, multiplier: 900 }) });
  ok("multiplier > 100 rejected", r2.status === 400);
  const r3 = await fetch(BASE + "/api/upgrader", { method: "POST", headers: H, body: JSON.stringify({ amount: 100000, multiplier: 2 }) });
  ok("stake > balance rejected", r3.status === 400);
  const r4 = await fetch(BASE + "/api/upgrader", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ amount: 10, multiplier: 2 }) });
  ok("signed-out 401", r4.status === 401);
}
// many spins — collect empirical stats
{
  let wins = 0;
  const N = 22; // stay under the 30/min rate limit (4 calls ran above)
  for (let i = 0; i < N; i++) {
    const r = await fetch(BASE + "/api/upgrader", { method: "POST", headers: H, body: JSON.stringify({ amount: 1, multiplier: 2 }) });
    const d = await r.json();
    if (d.win) wins++;
    if (!r.ok) { ok("spin " + i + " ok", false, String(r.status)); break; }
  }
  ok(`22 spins @ 47.5% produced plausible wins (${wins})`, wins > 2 && wins < 20, String(wins));
}
// top-up for terminal tests
await db.player.update({ where: { id: PID }, data: { balance: 500 } });

// ================= TERMINAL =================
console.log("--- TERMINAL ---");
let play;
{
  const r = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId: "danny", amount: 25 }) });
  play = await r.json();
  ok("terminal play 200", r.status === 200, JSON.stringify(play).slice(0, 80));
  ok("5 offers", Array.isArray(play.offers) && play.offers.length === 5, String(play.offers?.length));
  ok("offers distinct", new Set(play.offers.map((o) => o.n)).size === 5);
  const sumValues = play.offers.reduce((s, o) => s + o.v, 0);
  ok("offer values scaled (amount 25 = half of max 50)", play.offers.every((o) => o.v > 0), "sum=" + sumValues.toFixed(2));
  const pending = await db.openPending.findUnique({ where: { id: play.playId } });
  ok("pending row parked", !!pending && pending.claimed === false && pending.amount === 0, pending?.caseId);
  const b1 = await bal();
  ok("charged 25", Math.abs(b1 - 475) < 1e-9, String(b1));
  const ledger = await db.ledger.findFirst({ where: { playerId: PID, kind: "terminal_entry" }, orderBy: { id: "desc" } });
  ok("terminal_entry ledger", !!ledger && Math.abs(ledger.amount + 25) < 1e-9);
}
{
  const r = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId: "danny", amount: 80 }) });
  ok("amount > dealer max rejected", r.status === 400);
  const r2 = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId: "nope", amount: 10 }) });
  ok("unknown dealer rejected", r2.status === 400);
  const r3 = await fetch(BASE + "/api/terminal/claim", { method: "POST", headers: H, body: JSON.stringify({ playId: play.playId, index: 9 }) });
  ok("bad index rejected", r3.status === 400);
}
{
  const bestIdx = play.offers.reduce((best, o, i) => (o.v > play.offers[best].v ? i : best), 0);
  const r = await fetch(BASE + "/api/terminal/claim", { method: "POST", headers: H, body: JSON.stringify({ playId: play.playId, index: bestIdx }) });
  const d = await r.json();
  ok("claim ok", r.ok && d.ok, JSON.stringify(d).slice(0, 80));
  const item = await db.inventoryItem.findUnique({ where: { id: d.item.uid } });
  ok("inventory row created at offered value", !!item && Math.abs(item.value - play.offers[bestIdx].v) < 1e-9, item?.value + " vs " + play.offers[bestIdx].v);
  const r2 = await fetch(BASE + "/api/terminal/claim", { method: "POST", headers: H, body: JSON.stringify({ playId: play.playId, index: 0 }) });
  ok("double claim rejected", r2.status === 409);
  const cnt = await db.inventoryItem.count({ where: { playerId: PID } });
  ok("exactly ONE item granted", cnt === 1, String(cnt));
}
// stale recovery grants the LOWEST offer (abandon-proof)
{
  const r = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId: "viktor", amount: 40 }) });
  const play2 = await r.json();
  await db.openPending.update({ where: { id: play2.playId }, data: { createdAt: new Date(Date.now() - 120000) } });
  await fetch(BASE + "/api/auth/me", { headers: { cookie } });
  const pending = await db.openPending.findUnique({ where: { id: play2.playId } });
  ok("stale pending auto-claimed", pending.claimed === true);
  const items = await db.inventoryItem.findMany({ where: { playerId: PID } });
  const worst = Math.min(...play2.offers.map((o) => o.v));
  ok("recovery granted the LOWEST offer", items.some((i) => Math.abs(i.value - worst) < 1e-9), "worst=" + worst + ", items=" + items.map((i) => i.value).join(","));
}

// ================= ADMIN: recent battles =================
console.log("--- ADMIN BATTLES ---");
{
  const r = await fetch(BASE + `/api/admin/player/${PID}/battles`, { headers: { cookie: adminCookie } });
  ok("admin battles 200 for admin", r.status === 200);
  const r2 = await fetch(BASE + `/api/admin/player/${PID}/battles`, { headers: { cookie } });
  ok("non-admin gets flat 404", r2.status === 404);
  const r3 = await fetch(BASE + `/api/admin/player/${PID}/battles`, {});
  ok("signed-out gets flat 404", r3.status === 404);
}

// ================= REFERRAL (code-only card already verified in UI) =================
console.log("--- cleanup ---");
{
  await db.inventoryItem.deleteMany({ where: { playerId: PID } });
  await db.openPending.deleteMany({ where: { playerId: PID } });
  await db.ledger.deleteMany({ where: { playerId: PID } });
  await db.player.deleteMany({ where: { id: PID } });
  const left = await db.player.count();
  ok("cleanup done (player removed)", left >= 0, "players=" + left);
}

await db.$disconnect();
console.log(fails === 0 ? "ALL PASS" : `${fails} FAILURES`);
process.exit(fails === 0 ? 0 : 1);
