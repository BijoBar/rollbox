#!/usr/bin/env bash
# Task 44 E2E — part 1: logo placements + emoji horizontal sticky picker +
# countdown locks (KICK / LEAVE / CALL BOTS disabled).
set -u
AB="agent-browser"
D="/home/z/my-project/download"

echo "=== 1. logo placements (home) ==="
$AB open http://localhost:3000/ >/dev/null 2>&1
sleep 3
$AB eval '(() => {
  const imgs = [...document.querySelectorAll("img[src=\"/rollboxlogo.png\"]")];
  const fav = document.querySelector("link[rel*=\"icon\"]")?.getAttribute("href");
  const top = imgs[0]?.closest("header, nav") !== null || imgs[0]?.closest("[class*=\"fixed\"]") !== null;
  const foot = imgs.some(i => i.closest("footer"));
  return JSON.stringify({ logoCount: imgs.length, favicon: fav, inTopbar: top, inFooter: foot, loaded: imgs.every(i => i.complete && i.naturalWidth > 0) });
})()' 2>/dev/null | tail -1
$AB screenshot "$D/task44-logo-topbar.png" >/dev/null 2>&1

echo "=== 2. create 1v1 battle (farm $3) ==="
$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 2.5
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "Add Case")?.click(); return 1; })()' >/dev/null 2>&1
sleep 1.2
$AB eval '(() => { [...document.querySelectorAll("[role=\"dialog\"] button[aria-label^=\"Add\"]")].find(b => b.getAttribute("aria-label").includes("$3"))?.click(); return 1; })()' >/dev/null 2>&1
sleep 0.3
$AB eval '(() => { document.querySelector("[role=\"dialog\"]")?.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true})); return 1; })()' >/dev/null 2>&1
sleep 0.5
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.includes("Create Battle"))?.click(); return 1; })()' >/dev/null 2>&1
sleep 2.5

echo "=== 3. emoji: horizontal to the LEFT + sticky ==="
$AB eval '(() => {
  const fire = document.querySelector("button[aria-label=\"Open the reactions menu\"]");
  const fr = fire.getBoundingClientRect();
  fire.click();
  return JSON.stringify({fire: [Math.round(fr.left), Math.round(fr.top), Math.round(fr.right)]});
})()' 2>/dev/null | tail -1
sleep 0.7
$AB eval '(() => {
  const menu = document.querySelector("[role=\"menu\"]");
  const fire = document.querySelector("button[aria-label=\"Open the reactions menu\"]");
  if (!menu || !fire) return JSON.stringify({err: "missing"});
  const mr = menu.getBoundingClientRect(), fr = fire.getBoundingClientRect();
  const cs = getComputedStyle(menu);
  return JSON.stringify({
    opensLeft: mr.right <= fr.left + 6,
    horizontal: mr.width > mr.height,
    sameRow: Math.abs((mr.top + mr.height/2) - (fr.top + fr.height/2)) < 12,
    flexRow: cs.flexDirection === "row",
    scrollX: menu.scrollWidth > menu.clientWidth,
    items: menu.querySelectorAll("[role=\"menuitem\"]").length
  });
})()' 2>/dev/null | tail -1
$AB screenshot "$D/task44-emoji-horizontal.png" >/dev/null 2>&1

echo "=== send 2 emojis fast — menu must STAY open ==="
$AB eval '(() => { [...document.querySelectorAll("[role=\"menu\"] [role=\"menuitem\"]")][3]?.click(); return 1; })()' >/dev/null 2>&1
sleep 0.4
$AB eval '(() => { [...document.querySelectorAll("[role=\"menu\"] [role=\"menuitem\"]")][8]?.click(); const m = !!document.querySelector("[role=\"menu\"]"); const f = document.querySelectorAll(".emoji-float").length; return JSON.stringify({menuStillOpen: m, floats: f}); })()' 2>/dev/null | tail -1
$AB eval '(() => { document.querySelector("button[aria-label=\"Open the reactions menu\"]")?.click(); return 1; })()' >/dev/null 2>&1
sleep 0.4
$AB eval 'JSON.stringify({closedByToggle: !document.querySelector("[role=\"menu\"]")})' 2>/dev/null | tail -1

echo "=== 4. countdown locks ==="
$AB eval '(() => { const c = [...document.querySelectorAll("button")].find(b => (b.getAttribute("aria-label") || "").includes("Pick which bot")); c?.click(); return 1; })()' >/dev/null 2>&1
sleep 1
$AB eval '(() => { const bot = [...document.querySelectorAll("[role=\"dialog\"] button")].find(b => b.textContent.includes("[RBbot]")); bot?.click(); return "seated"; })()' 2>/dev/null | tail -1
sleep 0.4
$AB eval '(() => {
  const leave = [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "Leave battle");
  const kick = [...document.querySelectorAll("button")].filter(b => b.textContent.trim() === "Kick");
  const call = [...document.querySelectorAll("button")].find(b => b.textContent.includes("Call Bots"));
  return JSON.stringify({phase: "waiting", leaveDisabled: leave?.disabled, kickChips: kick.length, callDisabled: call?.disabled});
})()' 2>/dev/null | tail -1
sleep 1.2
$AB eval '(() => {
  const cd = document.querySelector(".font-display.text-8xl");
  const leave = [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "Leave battle");
  const kick = [...document.querySelectorAll("button")].filter(b => b.textContent.trim() === "Kick" && !b.disabled);
  const pickChips = [...document.querySelectorAll("button")].filter(b => (b.getAttribute("aria-label") || "").includes("Pick which bot"));
  return JSON.stringify({countdownShowing: !!cd, leaveDisabledDuringCd: leave?.disabled, activeKickChips: kick.length, pickBotChips: pickChips.length});
})()' 2>/dev/null | tail -1
$AB screenshot "$D/task44-countdown-locked.png" >/dev/null 2>&1