#!/usr/bin/env node
// ============ import-dailies.mjs (Task 94) ============
// Reads the DROP EDITOR export (the txt the user copies/downloads) and writes
// the DAILY VAULTS overlay into src/lib/user-dailies.ts. Only the
// "ROLLBOX-DAILY v1" section is consumed here; ROLLBOX-TERMINALS v1 lines
// belong to scripts/import-terminals.mjs and are ignored with a count.
//
// Each line carries { id: "level-<tier>", items: [{ n, p, id? }, ...] } where
// p is the drop percent (sums to 100). Items WITHOUT a catalog id are
// REJECTED — daily-case skins render straight from SKINS[skinId], a free-text
// skin has no catalog entry to draw art/price from.
//
// Usage:  node scripts/import-dailies.mjs rollbox-drop.txt
//         cat rollbox-drop.txt | node scripts/import-dailies.mjs

import fs from "fs";

const ROOT = new URL("..", import.meta.url).pathname;
const LEVEL_TS = `${ROOT}src/lib/level-cases.ts`;
const OUT = `${ROOT}src/lib/user-dailies.ts`;

const raw = (process.argv[2] ? fs.readFileSync(process.argv[2], "utf8") : fs.readFileSync(0, "utf8")).trim();

// the allowed vault ids — derived from the site's own SPECS tiers
const ts = fs.readFileSync(LEVEL_TS, "utf8");
const allowed = new Set([...ts.matchAll(/tier:\s*(\d+),/g)].map((m) => `level-${m[1]}`));

const dailies = [];
let sawTerminals = false;
let terminalLines = 0;

for (const line of raw.split("\n")) {
  const s = line.trim();
  if (!s) continue;
  if (s === "ROLLBOX-CASES v1") continue;
  if (s === "ROLLBOX-TERMINALS v1") { sawTerminals = true; continue; }
  if (s === "ROLLBOX-DAILY v1") continue;
  let obj;
  try {
    obj = JSON.parse(s);
  } catch {
    console.warn(`skip (not JSON): ${s.slice(0, 60)}…`);
    continue;
  }
  if (obj && Array.isArray(obj.items)) {
    dailies.push(obj);
  } else if (obj && Array.isArray(obj.skins)) {
    terminalLines++; // a terminals line — not ours
  } else {
    console.warn(`skip (unknown line): ${s.slice(0, 60)}…`);
  }
}

if (dailies.length === 0) {
  console.error("No daily-vault lines found in the export (looked for the ROLLBOX-DAILY v1 section).");
  console.error(`(terminal lines ignored: ${terminalLines})`);
  process.exit(1);
}

// ---- validate ----
const problems = [];
const seen = new Set();
for (const c of dailies) {
  const tag = c.id ?? "(no id)";
  if (!c.id || !allowed.has(String(c.id))) problems.push(`${tag}: unknown vault id (expected one of ${[...allowed].join(", ")})`);
  if (seen.has(String(c.id))) problems.push(`${tag}: duplicate vault`);
  seen.add(String(c.id));
  if (!Array.isArray(c.items) || c.items.length < 2) problems.push(`${tag}: a vault needs at least 2 skins`);
  const sum = (c.items ?? []).reduce((acc, k) => acc + (+k.p || 0), 0);
  if (Math.abs(sum - 100) > 0.05) problems.push(`${tag}: chances sum to ${sum.toFixed(4)}, not 100`);
  for (const k of c.items ?? []) {
    if (!k.id) problems.push(`${tag}: skin "${k.n}" has no catalog id — pick it from the autocomplete (daily skins render from the catalog)`);
    else if (!(+k.p >= 0)) problems.push(`${tag}: skin "${k.n}" has chance ${k.p}`);
  }
}
if (problems.length) {
  console.error("EXPORT HAS PROBLEMS — fix these in the editor first:");
  for (const p of problems) console.error("  • " + p);
  process.exit(1);
}

// ---- write the overlay ----
const entries = dailies.map((c) => [
  String(c.id),
  c.items.map((k) => [String(k.id), Math.round(+k.p * 1e6) / 1e6]),
]);
const body = entries.map(([id, items]) => {
  const rows = items.map(([sid, w]) => `    ["${sid}", ${w}],`).join("\n");
  return `  "${id}": [\n${rows}\n  ],`;
}).join("\n");

const file = `// ============ USER DAILY VAULTS (Task 94) — DO NOT auto-regenerate ============
// Imported from the DROP EDITOR's ROLLBOX-DAILY v1 export by
// scripts/import-dailies.mjs on ${new Date().toISOString().slice(0, 10)}.
// Each vault id here REPLACES the generated items wholesale
// (src/lib/level-cases.ts SPECS) — weights are already a 100 total.

export const USER_DAILY_OVERRIDES: Record<string, [string, number][]> = {
${body}
};
`;

fs.writeFileSync(OUT, file);
console.log(`OK — wrote src/lib/user-dailies.ts with ${dailies.length} vault(s):`);
for (const c of dailies) {
  console.log(`  • ${c.id} — ${c.items.length} skins (sum ${c.items.reduce((a, k) => a + (+k.p || 0), 0).toFixed(2)})`);
}
if (sawTerminals || terminalLines) {
  console.log(`(terminal lines in the export were ignored: ${terminalLines} — run scripts/import-terminals.mjs for those)`);
}
