#!/usr/bin/env bash
# e2e-t169.sh — REGRESSION TEST for Task 169 (the "READY + drops, no spin" bug)
#
# BUG: a viewer who entered/re-entered a global battle in the LAST beat of its
# shared-clock schedule computed startIdx = rounds.length (one PAST the last
# round) → round set out of range → roundCase undefined → the grid froze on
# "Get ready" squares with every drop revealed instantly — no reel ever mounted.
#
# PROTOCOL (three live 1v1v1 bot battles as p_t66A):
#   1. LATE ENTRY  — open the room inside the final beat (elapsed≈lastEnd-0.6s):
#      the old code froze on "Get ready"; the fix must replay the final reel and
#      land the verdict. FAIL if "Get ready" stays visible >~3s while playing.
#   2. MID ENTRY   — open at round 2 in flight: reels mount live, no freeze.
#   3. EARLY ENTRY — open right at the flip: the normal fight still plays.
# Every scenario must end with the verdict banner (VICTORY!/BATTLE LOST!/POT SPLIT!).
set -euo pipefail
cd /home/z/my-project
BASE=http://localhost:3000
TOKEN=$(bun scripts/mint-e2e-session.ts 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')

api() { curl -s -H "Cookie: rb_session=$TOKEN" -H 'Content-Type: application/json' "$@"; }
field() { python3 -c "import sys,json;d=json.load(sys.stdin);print(eval(\"d$1\"))"; }

echo "== minted p_t66A =="

create_battle() {
  api -X POST "$BASE/api/gbattles" -d '{"type":"1v1v1","mode":"standard","potRule":"winner","rounds":["farm-ak47","farm-ak47","farm-ak47"],"fast":false,"private":false}' | field "['id']"
}
fill_bots() { api -X POST "$BASE/api/gbattles/$1/bots" -d '{}' >/dev/null; }
wait_playing() {
  for i in $(seq 1 40); do
    OUT=$(api "$BASE/api/gbattles/$1" | python3 -c "
import sys,json
d=json.load(sys.stdin)['battle']
print(d['status'], (d['schedule'][-1]['endMs'] if d.get('schedule') else 0), (d['totalMs'] or 0), d['startedAt'] or 0)")
    set -- $OUT
    if [ "$1" = "playing" ]; then echo "$2 $3"; return 0; fi
    sleep 0.4
  done
  echo "NEVER"; return 1
}
elapsed_ms() { echo $(( $(date +%s%3N) - $1 )); }
sleep_until() { # $1=startedAt  $2=targetElapsedMs
  NOW_EL=$(elapsed_ms "$1"); DIFF=$(( $2 - NOW_EL ))
  if [ "$DIFF" -gt 0 ]; then python3 -c "import time;time.sleep($DIFF/1000)"; fi
}

browser_pass() { # $1=battleId $2=startedAt $3=label
  local BID=$1 STARTED=$2 LABEL=$3
  agent-browser open "$BASE/" >/dev/null 2>&1
  agent-browser wait 800 >/dev/null
  agent-browser cookies set rb_session "$TOKEN" >/dev/null
  agent-browser open "$BASE/battles/$BID" >/dev/null
  agent-browser wait 1200 >/dev/null
  LABEL="$LABEL" python3 << 'PYEOF'
import subprocess, time, os, json
label = os.environ["LABEL"]
gr_streak = 0; max_streak = 0; verdict = False; reel_seen = False
t0 = time.time()
JS = """
(() => {
  const txt = document.body.innerText;
  return JSON.stringify({
    gr: /get ready/i.test(txt),
    verdict: /VICTORY!|BATTLE LOST!|POT SPLIT!/i.test(txt),
    reel: !!document.querySelector('[dir="ltr"] [aria-label*="won -"], [dir="ltr"] [aria-label*="won \\u2014"], .anim-lock-flash')
  });
})()
"""
while time.time() - t0 < 26:
    r = subprocess.run(["agent-browser", "eval", JS], capture_output=True, text=True)
    out = (r.stdout or "").strip().splitlines()
    try:
        val = json.loads(out[-1]) if out else {}
        if isinstance(val, str): val = json.loads(val)
    except Exception:
        val = {}
    if val.get("gr"):
        gr_streak += 1; max_streak = max(max_streak, gr_streak)
    else:
        gr_streak = 0
    if val.get("verdict"): verdict = True
    if val.get("reel"): reel_seen = True
    if verdict and time.time() - t0 > 4: break
    time.sleep(0.45)
print(json.dumps({"label": label, "maxGetReadyStreak": max_streak, "verdict": verdict, "reelSeen": reel_seen}))
PYEOF
}

PASS=0; FAIL=0
check() {
  local LABEL; LABEL=$(echo "$1" | python3 -c "import sys,json;print(json.load(sys.stdin)['label'])")
  local STREAK; STREAK=$(echo "$1" | python3 -c "import sys,json;print(json.load(sys.stdin)['maxGetReadyStreak'])")
  local VERDICT; VERDICT=$(echo "$1" | python3 -c "import sys,json;print(json.load(sys.stdin)['verdict'])")
  local REEL; REEL=$(echo "$1" | python3 -c "import sys,json;print(json.load(sys.stdin)['reelSeen'])")
  echo "---- $LABEL: getReadyStreak=$STREAK (limit $2) verdict=$VERDICT reelSeen=$REEL"
  if [ "$STREAK" -le "$2" ] && [ "$VERDICT" = "True" ]; then echo "   PASS"; PASS=$((PASS+1)); else echo "   FAIL"; FAIL=$((FAIL+1)); fi
}

# ===== SCENARIO 1 — LATE ENTRY (the reported bug) =====
echo "== scenario 1: late entry (fetch before the settle, mount after the last round) =="
for RUN in 1 2; do
  BID=$(create_battle); fill_bots "$BID"
  S=$(wait_playing "$BID") || { echo "battle never started"; exit 1; }
  set -- $S; LASTEND=$1; TOTAL=$2
  STARTED=$(( $(date +%s%3N) - $(api "$BASE/api/gbattles/$BID" | python3 -c "import sys,json,time;print(int((time.time()*1000))-json.load(sys.stdin)['battle']['serverNow'])") ))
  # run 1: the room's first GET lands ~700ms before the settle — the mirror
  # still says "playing" while the mount joins the clock AFTER the last beat
  # (the old code froze here). run 2: inside the last round's beat.
  if [ "$RUN" = "1" ]; then TARGET=$(( TOTAL - 700 )); else TARGET=$(( LASTEND - 800 )); fi
  sleep_until "$STARTED" "$TARGET"
  echo "   battle $BID entered at elapsed $(elapsed_ms $STARTED)ms (lastEnd=${LASTEND}ms total=${TOTAL}ms)"
  OUT=$(browser_pass "$BID" "$STARTED" "late-$RUN")
  check "$OUT" 5
done

# ===== SCENARIO 2 — MID ENTRY (round 2 in flight) =====
echo "== scenario 2: mid entry (round 2 spinning) =="
BID=$(create_battle); fill_bots "$BID"
S=$(wait_playing "$BID"); set -- $S; LASTEND=$1; TOTAL=$2
STARTED=$(( $(date +%s%3N) - $(api "$BASE/api/gbattles/$BID" | python3 -c "import sys,json,time;print(int((time.time()*1000))-json.load(sys.stdin)['battle']['serverNow'])") ))
sleep_until "$STARTED" 6500
OUT=$(browser_pass "$BID" "$STARTED" "mid")
check "$OUT" 5

# ===== SCENARIO 3 — EARLY ENTRY (normal fight unchanged) =====
echo "== scenario 3: early entry (round 0 from the flip) =="
BID=$(create_battle); fill_bots "$BID"
S=$(wait_playing "$BID"); set -- $S; LASTEND=$1; TOTAL=$2
STARTED=$(( $(date +%s%3N) - $(api "$BASE/api/gbattles/$BID" | python3 -c "import sys,json,time;print(int((time.time()*1000))-json.load(sys.stdin)['battle']['serverNow'])") ))
sleep_until "$STARTED" 900
OUT=$(browser_pass "$BID" "$STARTED" "early")
check "$OUT" 5

echo "== RESULT: PASS=$PASS FAIL=$FAIL =="
[ "$FAIL" = "0" ]
