#!/usr/bin/env bash
# e2e-t183.sh — FREE CASES system (USER SPEC Task 183)
# Covers: (0) freecases grant/consume unit math · (A) the admin panel GIFT
# control lands boxes in the DB + FREE CASES detail · (B) the FREE ×N chip on
# the case card + case page, the OPEN button flips to FREE, and an open with
# ZERO balance succeeds because the server burns the free units first ·
# (C) mission m2 completion lazily pays one FREE RB-106 (idempotent) with the
# CLAIMED chip on the board · (D) registration grants NO money (balance 0, no
# signup ledger row) · cleanup restores players:9.
# LESSONS (t175-t182): agent-browser eval returns JSON-quoted strings — never
# exact-compare, always rg; React controlled selects need the native value
# setter + a bubbling change event; set the session cookie BEFORE opening a
# gated page.
set -uo pipefail
cd /home/z/my-project
AB="agent-browser"
BASE="http://localhost:3000"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0
jhas() { echo "$1" | sed 's/\\//g' | rg -q "$2"; }

# ============================================================ STAGE 0 (unit)
# the grant/consume CAS math against the real DB on the fixture player
bun scripts/t183-fixture.ts --create >/dev/null 2>&1
unit=$(bun -e "
import { grantFreeCases, consumeFreeCases } from './src/lib/server/freecases';
const g1 = await grantFreeCases('p_e2e_free_t183', 'doppler-realm', 2);
const c1 = await consumeFreeCases('p_e2e_free_t183', 'doppler-realm', 1);
const c2 = await consumeFreeCases('p_e2e_free_t183', 'doppler-realm', 5);
const c3 = await consumeFreeCases('p_e2e_free_t183', 'doppler-realm', 1);
console.log(JSON.stringify({ g1: g1?.['doppler-realm'], c1: c1.used, left1: c1.freeCases['doppler-realm'] ?? 0, c2: c2.used, left2: c2.freeCases['doppler-realm'] ?? 0, c3: c3.used }));
" 2>/dev/null | tail -1)
echo "unit: $unit"
jhas "$unit" '"g1":2' && jhas "$unit" '"c1":1' && jhas "$unit" '"left1":1' && jhas "$unit" '"c2":1' && jhas "$unit" '"left2":0' && jhas "$unit" '"c3":0' \
  && ok "unit: grant 2 → consume 1 (left 1) → over-consume 1 (left 0) → consume empty 0" || fail "unit math ($unit)"
bun scripts/t183-fixture.ts --create >/dev/null 2>&1 # fresh row for the browser stages

# ============================================================ STAGE A (admin UI)
TOKEN="$(bun scripts/t183-fixture.ts --create 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')"
$AB close >/dev/null 2>&1 || true
sleep 1
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open "$BASE/" >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
$AB open "$BASE/admin" >/dev/null
sleep 2
# the panel mount (mounted → session → 2FA gate) can take a beat — poll for it
gate="{}"
for i in 1 2 3 4 5 6; do
  gate=$($AB eval "(() => JSON.stringify({ panel: !!document.querySelector('main[aria-label=\"Admin panel\"]'), locked: /admin locked/i.test(document.body.innerText) }))()" 2>/dev/null)
  echo "$gate" | rg -q '"panel":true' && break
  sleep 1.5
done
jhas "$gate" '"panel":true' && ok "admin: panel open for the fixture admin (no 2FA lock)" || fail "admin: panel gate ($gate)"

# search the fixture player by site id and open the overlay
$AB eval "(() => { const i = document.querySelector('input[aria-label=\"Search players by site ID\"]'); if (!i) return 'no-input'; const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; setter.call(i, 'p_e2e_free_t183'); i.dispatchEvent(new Event('input', { bubbles: true })); return 'typed'; })()" >/dev/null 2>&1
sleep 2.5
$AB eval "(() => { const btn = [...document.querySelectorAll('button')].find(b => b.textContent?.includes('p_e2e_free_t183')); if (!btn) return 'no-row'; btn.click(); return 'clicked'; })()" >/dev/null 2>&1
sleep 1.5

# gift 2 × RB-106 (Doppler Realm) through the GIFT FREE CASES control
gift=$($AB eval "(() => { const sel = document.querySelector('select[aria-label=\"Case to gift\"]'); if (!sel) return JSON.stringify({ sel: false }); const sset = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set; sset.call(sel, 'doppler-realm'); sel.dispatchEvent(new Event('change', { bubbles: true })); const inp = document.querySelector('input[aria-label=\"How many free boxes\"]'); const iset = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; iset.call(inp, '2'); inp.dispatchEvent(new Event('input', { bubbles: true })); return JSON.stringify({ sel: true, qty: inp.value, options: sel.options.length }); })()" 2>/dev/null)
echo "gift control: $gift"
jhas "$gift" '"sel":true' && jhas "$gift" '"qty":"2"' && ok "admin: gift control present (case select + qty)" || fail "admin: gift control ($gift)"

$AB eval "(() => { const b = [...document.querySelectorAll('button')].find(x => x.textContent?.trim() === 'GIFT'); if (!b) return 'no-btn'; b.click(); return 'gifted'; })()" >/dev/null 2>&1
sleep 2

detail=$($AB eval "(() => { const els = [...document.querySelectorAll('p')]; const d = els.find(p => /free cases \(gifts/i.test(p.textContent ?? '')); const val = d?.parentElement?.textContent ?? ''; return JSON.stringify({ has: !!d, rb106: val.includes('RB-106 ×2'), toast: /gifted to/i.test(document.body.innerText) }); })()" 2>/dev/null)
echo "gift result: $detail"
jhas "$detail" '"rb106":true' && ok "admin: FREE CASES detail shows RB-106 ×2" || fail "admin: detail missing ($detail)"
jhas "$detail" '"toast":true' && ok "admin: gift toast fired" || fail "admin: toast missing ($detail)"

dbstate="$(bun scripts/t183-fixture.ts --state 2>/dev/null | tail -1)"
jhas "$dbstate" '"doppler-realm":2' && ok "db: Player.freeCases = {doppler-realm: 2}" || fail "db: state ($dbstate)"

# ============================================================ STAGE B (chips + free open)
$AB open "$BASE/" >/dev/null
sleep 3
card=$($AB eval "(() => { const a = document.querySelector('a[href=\"/case/doppler-realm\"]'); const chip = a?.querySelector('[data-freechip=\"1\"]'); return JSON.stringify({ card: !!a, chip: !!chip, text: chip?.textContent?.replace(/\\s+/g, ' ') ?? '' }); })()" 2>/dev/null)
echo "home card: $card"
jhas "$card" '"chip":true' && jhas "$card" 'FREE ×2' && ok "home: Doppler Realm card shows FREE ×2 next to the name" || fail "home: chip ($card)"

$AB open "$BASE/case/doppler-realm" >/dev/null
sleep 3.5
page=$($AB eval "(() => { const chip = document.querySelector('h1 [data-freechip=\"1\"]'); const btn = [...document.querySelectorAll('button')].find(b => /open case/i.test(b.textContent ?? '')); return JSON.stringify({ chip: chip?.textContent?.replace(/\\s+/g, ' ') ?? '', btn: btn?.textContent?.replace(/\\s+/g, ' ') ?? '' }); })()" 2>/dev/null)
echo "case page: $page"
jhas "$page" 'FREE ×2' && ok "case page: h1 carries the FREE ×2 chip" || fail "case page: h1 chip ($page)"
jhas "$page" 'Open Case • FREE' && ok "case page: OPEN button reads FREE (2 boxes cover x1)" || fail "case page: button ($page)"

# the fixture player has balance 0 — ONLY the free burn makes this open pass
$AB find first "button.neon-btn" click >/dev/null 2>&1
sleep 2.5
opened=$($AB eval "(() => { const chip = document.querySelector('h1 [data-freechip=\"1\"]'); const broke = /not enough funds/i.test(document.body.innerText); return JSON.stringify({ chip: chip?.textContent?.replace(/\\s+/g, ' ') ?? '', broke, spinning: /unlocking/i.test(document.body.innerText) || !!document.querySelector('[data-phase]') }); })()" 2>/dev/null)
echo "open result: $opened"
jhas "$opened" '"broke":false' && ok "open: ZERO balance did NOT block the open (free units burned)" || fail "open: blocked despite free boxes ($opened)"
jhas "$opened" 'FREE ×1' && ok "open: chip dropped to FREE ×1 after the round consumed one box" || fail "open: chip did not drop ($opened)"

sleep 9 # let the round settle before the console-error read

# ============================================================ STAGE C (missions pay RB-106)
bun scripts/t183-fixture.ts --missions >/dev/null 2>&1
m1="$(curl -s -H "Cookie: rb_session=$TOKEN" "$BASE/api/missions")"
echo "missions 1: $(echo "$m1" | head -c 300)"
jhas "$m1" '"granted":\["m2"\]' && ok "missions: completed m2 lazily granted (granted=[m2])" || fail "missions: first read did not grant ($m1)"
# the prize lands in the player's freeCases (read via /api/auth/me — the
# missions route itself carries only the mission state)
me1="$(curl -s -H "Cookie: rb_session=$TOKEN" "$BASE/api/auth/me")"
jhas "$me1" '"doppler-realm":2' && ok "missions: the RB-106 prize landed in freeCases (1 left + 1 prize = 2)" || fail "missions: freeCases missing the prize ($me1)"
m2="$(curl -s -H "Cookie: rb_session=$TOKEN" "$BASE/api/missions")"
jhas "$m2" '"granted":\[\]' && ok "missions: second read grants NOTHING (idempotent)" || fail "missions: double grant ($m2)"
jhas "$m2" '"g":\["m2"\]' && ok "missions: state.g carries the paid mission" || fail "missions: g stamp missing ($m2)"

$AB open "$BASE/missions" >/dev/null
sleep 3
board=$($AB eval "(() => { const cards = [...document.querySelectorAll('article')]; const m2 = cards.find(c => /battle rookie/i.test(c.textContent ?? '')); const footer = m2?.querySelector('footer')?.textContent?.replace(/\\s+/g, ' ') ?? ''; return JSON.stringify({ claimed: /claimed/i.test(m2?.textContent ?? ''), chip: footer }); })()" 2>/dev/null)
echo "board: $board"
jhas "$board" '"claimed":true' && jhas "$board" 'FREE RB-106 ×1 — CLAIMED' && ok "missions board: m2 reward chip reads FREE RB-106 ×1 — CLAIMED" || fail "missions board: claimed chip ($board)"

# ============================================================ STAGE D (signup = $0)
signup=$(bun -e "
import { db } from './src/lib/db';
import { upsertPlayer } from './src/lib/server/auth';
const before = await db.counter.findUnique({ where: { key: 'members' } });
const p = await upsertPlayer('steam', 'steam_e2e_signup_t183', 'E2E Signup', null);
const ledger = await db.ledger.count({ where: { playerId: p.id } });
const okZero = p.balance === 0;
await db.player.delete({ where: { id: p.id } });
if (before) await db.counter.update({ where: { key: 'members' }, data: { value: before.value } });
console.log(JSON.stringify({ balance: p.balance, okZero, ledger }));
" 2>/dev/null | tail -1)
echo "signup: $signup"
jhas "$signup" '"okZero":true' && jhas "$signup" '"ledger":0' && ok "signup: NEW account = balance 0, ZERO ledger rows (must deposit)" || fail "signup ($signup)"

# console errors across the browser stages
errs=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -8)
if [ -z "$errs" ]; then ok "browser: zero page errors through admin/home/case/missions"; else fail "browser errors: $errs"; fi

# ============================================================ cleanup
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open "about:blank" >/dev/null 2>&1
clean="$(bun scripts/t183-fixture.ts --cleanup 2>/dev/null | tail -1)"
echo "cleanup: $clean"
jhas "$clean" '"players":9' && ok "cleanup: fixture deleted — players back to 9" || fail "cleanup ($clean)"

echo "=================================================="
[ "$FAILED" = "0" ] && echo "ALL CHECKS PASSED" || echo "SOME CHECKS FAILED"
exit $FAILED
