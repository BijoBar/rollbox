// ============ Task 72: per-wear price generation ============
// Sources (all local, one bulk HTTP call upstream):
//   scripts/csgotm-prices.json  — market.csgo.com bulk prices (USD, ALL wears)
//   scripts/skins-db.json       — official CS2 DB (in-game wear availability)
//   scripts/cases-dump.json     — the case registry (skinId + name per skin)
// Outputs:
//   src/lib/generated-wear-prices.ts — SKIN_WEAR_PRICES (skinId -> wear -> COINS)
//                                      + SKIN_WEAR_AVAIL (only skins whose
//                                        in-game wears differ from the full 5)
// Coin conversion = round(USD * 10) — the same ×10 scale the catalog uses.
import { readFileSync, writeFileSync } from "fs";

const ROOT = "/home/z/my-project";
const PRICES = JSON.parse(readFileSync(`${ROOT}/scripts/csgotm-prices.json`, "utf8"));
const DB = JSON.parse(readFileSync(`${ROOT}/scripts/skins-db.json`, "utf8"));
const DUMP = JSON.parse(readFileSync(`${ROOT}/scripts/cases-dump.json`, "utf8"));

const WEARS = [
  ["FN", "Factory New"],
  ["MW", "Minimal Wear"],
  ["FT", "Field-Tested"],
  ["WW", "Well-Worn"],
  ["BS", "Battle-Scarred"],
];
const LABEL_TO_ID = Object.fromEntries(WEARS.map(([id, label]) => [label, id]));

const priceByHash = new Map();
for (const it of PRICES.items) {
  const p = parseFloat(it.price);
  if (Number.isFinite(p) && p > 0) priceByHash.set(it.market_hash_name, p);
}

// official-DB wears per base name
const wearsByName = new Map();
for (const s of DB) {
  const list = (s.wears ?? []).map((w) => LABEL_TO_ID[w.name]).filter(Boolean);
  wearsByName.set(s.name, list);
}
const ALL_IDS = WEARS.map(([id]) => id);

// unique case skins
const skins = new Map();
const cases = Array.isArray(DUMP) ? DUMP : DUMP.cases;
for (const c of cases) {
  for (const it of c.items) {
    if (!skins.has(it.skinId)) skins.set(it.skinId, it.name);
  }
}

const PRICES_OUT = {};
const AVAIL_OUT = {};
let pricedCombos = 0;
let pricedSkins = 0;
let availDeviations = 0;

for (const [skinId, name] of skins) {
  const inGame = wearsByName.get(name);
  const wp = {};
  for (const [wid, label] of WEARS) {
    const p = priceByHash.get(`${name} (${label})`);
    if (p) {
      wp[wid] = Math.round(p * 10);
      pricedCombos++;
    }
  }
  if (Object.keys(wp).length > 0) {
    PRICES_OUT[skinId] = wp;
    pricedSkins++;
  }
  // availability: only record when the skin does NOT come in all five wears
  // (stickers/charms/agents/patches are not weapon skins at all -> empty array
  // = no wear picker; vanilla knives also land on the empty array)
  if (!Array.isArray(inGame) || inGame.join(",") !== ALL_IDS.join(",")) {
    AVAIL_OUT[skinId] = Array.isArray(inGame) ? inGame : [];
    availDeviations++;
  }
}

const ts = new Date(PRICES.time * 1000).toISOString().slice(0, 10);
const header = `// ============ GENERATED FILE — do not edit by hand ============
// Per-wear market prices for every case skin (Task 72).
// Source: market.csgo.com bulk prices (${ts}) via scripts/gen-wear-prices.mjs.
// Values are COINS: round(USD x 10) — the catalog's own conversion.
// A missing wear = no market listing right now; runtime falls back to the
// wear.ts factor estimate. Availability (SKIN_WEAR_AVAIL) lists the wears a
// skin actually comes in, from the official CS2 DB — recorded ONLY when it
// differs from all five (vanilla knives = empty array: no wear picker).

export type GenWearId = "FN" | "MW" | "FT" | "WW" | "BS";

export const SKIN_WEAR_PRICES: Record<string, Partial<Record<GenWearId, number>>> = ${JSON.stringify(PRICES_OUT, null, 1)};

export const SKIN_WEAR_AVAIL: Record<string, GenWearId[]> = ${JSON.stringify(AVAIL_OUT, null, 1)};
`;

writeFileSync(`${ROOT}/src/lib/generated-wear-prices.ts`, header);
console.log(
  `skins: ${skins.size} | skins with prices: ${pricedSkins} | priced combos: ${pricedCombos}/${skins.size * 5} | availability deviations: ${availDeviations}`
);
