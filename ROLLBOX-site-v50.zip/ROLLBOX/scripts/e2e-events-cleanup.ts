// EVENTS E2E cleanup — removes the TEST artifacts while keeping real gameplay:
//  - the test community case (cc_e2e "E2E Battle Crate")
//  - the EventStat wager rows created by the test opens (board purity)
// Keeps: the two finished battles + their ledger rows + the live-feed drops
// (consistent gameplay records, same as previous battle E2Es).
import { db } from "../src/lib/db";

const ccId = process.argv[2];
if (!ccId) {
  console.error("usage: bun scripts/e2e-events-cleanup.ts <ccId>");
  process.exit(1);
}

const cc = await db.communityCase.findUnique({ where: { id: ccId } });
console.log("community case:", cc ? `${cc.name} (${cc.id})` : "not found");
if (cc) await db.communityCase.delete({ where: { id: ccId } });

const stats = await db.eventStat.findMany();
console.log("EventStat rows before:", stats.map((s) => `${s.playerId}:w${s.wagered}:o${s.opened}`).join(", ") || "none");
const del = await db.eventStat.deleteMany();
console.log("EventStat rows deleted:", del.count);

const players = await db.player.count();
const battles = await db.battle.count();
const ccs = await db.communityCase.count();
const ev = await db.eventStat.count();
const t66 = await db.player.findUnique({ where: { id: "p_t66A" }, select: { balance: true, name: true } });
console.log(`players: ${players} | battles: ${battles} | communityCases: ${ccs} | eventStat: ${ev}`);
console.log(`p_t66A: name=${t66?.name} balance=${t66?.balance}`);
await db.$disconnect();
