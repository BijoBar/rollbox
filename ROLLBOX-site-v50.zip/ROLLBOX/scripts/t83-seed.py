#!/usr/bin/env python3
"""Task 83 browser-E2E seed — a handful of ledger rows for FormatQA so the
dedicated BALANCE HISTORY page can be verified with real table content."""
import sqlite3

DB = "db/custom.db"
PID = "p_b9e865f108a2b605"  # FormatQA (minted by scripts/mint-format-qa.mjs)

ROWS = [
    ("signup", 500, 500),
    ("daily", 300, 800),
    ("open_entry", -100, 700),
    ("open_win", 240.55, 940.55),
    ("battle_entry", -50, 890.55),
    ("battle_win", 180.25, 1070.8),
]

con = sqlite3.connect(DB)
con.execute("DELETE FROM Ledger WHERE playerId = ?", (PID,))
for kind, amount, after in ROWS:
    con.execute(
        "INSERT INTO Ledger (playerId, kind, amount, balanceAfter, ref, createdAt) "
        "VALUES (?, ?, ?, ?, NULL, datetime('now', '-2 hours'))",
        (PID, kind, amount, after),
    )
con.commit()
n = con.execute("SELECT COUNT(*) FROM Ledger WHERE playerId = ?", (PID,)).fetchone()[0]
con.close()
print(f"ledger rows for {PID}: {n}")
