// C7 grand cleanup — restores the EXACT pre-test state after the API + browser
// E2E rounds. The test money must not stay on any balance and the test config
// must not stay in the site config (a fake deposit address is dangerous to
// leave configured).
//   pre-test baseline balance: 4558.129999999999  (captured by the first
//   snapshot, printed in the suite output before any money moved)
//   depTotal credited during tests: 50 (api run 1) + 50 (api run 2) + 25
//   (browser) = 125  -> subtracted back from the missions counters.
import { db } from "../src/lib/db";

const PID = "p_t66A";
const BASELINE = 4558.129999999999;
const LEDGER_KINDS = ["deposit", "withdraw_lock", "withdraw_refund"];
const CONFIG_KEYS = [
  "wallet.enabled",
  "wallet.usdt_address",
  "wallet.minDeposit",
  "wallet.maxDeposit",
  "wallet.minWithdraw",
  "wallet.maxWithdraw",
];

const delDep = await db.depositRequest.deleteMany({ where: { playerId: PID } });
const delWd = await db.withdrawalRequest.deleteMany({ where: { playerId: PID } });
const delLed = await db.ledger.deleteMany({ where: { playerId: PID, kind: { in: LEDGER_KINDS } } });
const delCfg = await db.siteConfig.deleteMany({ where: { key: { in: CONFIG_KEYS } } });
console.log(`deleted: deposits=${delDep.count} withdrawals=${delWd.count} ledgerRows=${delLed.count} configKeys=${delCfg.count}`);

const p = await db.player.findUnique({ where: { id: PID } });
if (!p) throw new Error("no test player");

// missions: depTotal was bumped by every approved deposit (+125 total)
let missionsOut: string | null = null;
let missionsNote = "missions: none";
if (p.missions) {
  const m = JSON.parse(p.missions) as { v?: number; c?: Record<string, number> };
  if (m.c && typeof m.c.depTotal === "number") {
    const before = m.c.depTotal;
    m.c.depTotal = Math.max(0, Math.round((before - 125) * 100) / 100);
    missionsNote = `missions.depTotal ${before} -> ${m.c.depTotal}`;
  }
  missionsOut = JSON.stringify(m);
}

await db.player.update({
  where: { id: PID },
  data: { balance: BASELINE, missions: missionsOut },
});
const after = await db.player.findUnique({ where: { id: PID }, select: { balance: true } });
console.log(`balance ${p.balance} -> ${after?.balance} (baseline ${BASELINE}); ${missionsNote}`);

const players = await db.player.count();
const pending = (await db.depositRequest.count()) + (await db.withdrawalRequest.count());
console.log(`players: ${players} | remaining wallet rows anywhere: ${pending}`);
process.exit(0);
