// Task 74: per-case Expected Value (EV) + fair-price analysis.
// Reads the LIVE registry (src/lib/cases.ts + wear.ts — market wear prices,
// manual overrides, everything) and dumps scripts/case-ev.json for the
// fair-price Excel builder.
//
// EV(case) = SUM(weight_i / totalWeight * caseItemValue(item_i))
// The weights already ARE the win percentages (they sum to ~100).
//
// Run: bun scripts/case-ev.ts

import { CASES, caseItemValue, SKINS } from "../src/lib/cases";
import { WEAR_BY_ID, type WearId } from "../src/lib/wear";
import { writeFileSync } from "node:fs";

interface ItemRow {
  caseCode: string;
  caseName: string;
  skinId: string;
  name: string;
  wear: string; // "" = no exterior (stickers, charms, legacy items)
  value: number;
  weight: number; // == win percentage
  contribution: number; // weight * value (pre-normalization helper)
  rarity: string;
}

interface CaseRow {
  code: string;
  name: string;
  kind: string;
  tierLabel: string;
  price: number;
  itemCount: number;
  weightSum: number;
  ev: number;
  minItem: string;
  minValue: number;
  maxItem: string;
  maxValue: number;
  currentEdgePct: number; // (price - EV) / price * 100 — the house edge as-is
  topContributors: { name: string; pct: number; value: number }[];
}

const caseRows: CaseRow[] = [];
const itemRows: ItemRow[] = [];

for (const c of CASES) {
  const weightSum = c.items.reduce((s, i) => s + i.weight, 0);
  let ev = 0;
  let minItem = { name: "", value: Infinity };
  let maxItem = { name: "", value: -Infinity };

  for (const item of c.items) {
    const skin = SKINS[item.skinId];
    const value = caseItemValue(item);
    const name = skin ? skin.name : item.skinId;
    const wearLabel = item.wear ? WEAR_BY_ID[item.wear as WearId].label : "";
    ev += (item.weight / weightSum) * value;
    if (value < minItem.value) minItem = { name, value };
    if (value > maxItem.value) maxItem = { name, value };
    itemRows.push({
      caseCode: c.code,
      caseName: c.name,
      skinId: item.skinId,
      name,
      wear: wearLabel,
      value,
      weight: item.weight,
      contribution: item.weight * value,
      rarity: skin?.rarity ?? "",
    });
  }

  const ranked = [...c.items]
    .map((i) => ({
      name: SKINS[i.skinId]?.name ?? i.skinId,
      pct: (i.weight / weightSum) * 100,
      value: caseItemValue(i),
    }))
    .sort((a, b) => b.pct * b.value - a.pct * a.value)
    .slice(0, 3);

  caseRows.push({
    code: c.code,
    name: c.name,
    kind: c.kind,
    tierLabel: c.tierLabel,
    price: c.price,
    itemCount: c.items.length,
    weightSum: Math.round(weightSum * 100) / 100,
    ev: Math.round(ev * 100) / 100,
    minItem: minItem.name,
    minValue: minItem.value,
    maxItem: maxItem.name,
    maxValue: maxItem.value,
    currentEdgePct: c.price > 0 ? Math.round(((c.price - ev) / c.price) * 10000) / 100 : 0,
    topContributors: ranked,
  });
}

caseRows.sort((a, b) => a.price - b.price);
writeFileSync(
  new URL("./case-ev.json", import.meta.url),
  JSON.stringify({ generatedAt: new Date().toISOString(), cases: caseRows, items: itemRows }, null, 1)
);

// console summary
console.log("code       kind      price      EV   edge%   min->max");
for (const r of caseRows) {
  console.log(
    r.code.padEnd(10),
    r.kind.padEnd(9),
    String(r.price).padStart(6),
    String(r.ev).padStart(8),
    String(r.currentEdgePct).padStart(7),
    `${r.minValue}->${r.maxValue} (${r.itemCount} items)`
  );
}
console.log(`\n${caseRows.length} cases, ${itemRows.length} items -> scripts/case-ev.json`);
const losers = caseRows.filter((r) => r.currentEdgePct < 5);
console.log(`cases with edge < 5%: ${losers.length} -> ${losers.map((l) => l.code).join(", ")}`);
