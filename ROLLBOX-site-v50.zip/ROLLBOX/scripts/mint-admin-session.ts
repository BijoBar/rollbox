// E2E helper: mint a signed session cookie for the ADMIN player (p_t72B).
import { db } from "../src/lib/db";
import { makeSessionToken } from "../src/lib/server/auth";
const p = await db.player.findUnique({ where: { id: "p_t72B" } });
if (!p || !p.isAdmin) { console.error("NO ADMIN"); process.exit(1); }
console.log(JSON.stringify({ id: p.id, name: p.name, token: makeSessionToken(p.id) }));
process.exit(0);
