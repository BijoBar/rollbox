// Task 167 E2E (API): 2FA gate + audit trail + giveaways + banner + RB-TST
// hiding + personal history. Run: bun scripts/e2e-t167.ts  (dev server ON).
import { db } from "../src/lib/db";
import { makeSessionToken } from "../src/lib/server/auth";
import { totpCode } from "../src/lib/server/totp";

const BASE = "http://localhost:3000";
let pass = 0;
let fail = 0;
const ok = (cond: boolean, label: string) => {
  if (cond) {
    pass++;
    console.log(`  PASS  ${label}`);
  } else {
    fail++;
    console.log(`  FAIL  ${label}`);
  }
};

const step = () => Math.floor(Date.now() / 1000 / 30);

function jar() {
  const cookies = new Map<string, string>();
  return {
    absorb(res: Response) {
      const raw = res.headers.getSetCookie?.() ?? [];
      for (const c of raw) {
        const [pair] = c.split(";");
        const eq = pair.indexOf("=");
        cookies.set(pair.slice(0, eq), pair.slice(eq + 1));
      }
    },
    header() {
      return [...cookies.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
    },
  };
}

async function call(j: ReturnType<typeof jar>, path: string, init?: RequestInit) {
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: { ...(init?.headers ?? {}), Cookie: j.header() },
    redirect: "manual",
  });
  j.absorb(res);
  return res;
}

const admin = await db.player.findFirst({ where: { isAdmin: true } });
const player = await db.player.findFirst({ where: { isAdmin: false } });
if (!admin || !player) {
  console.error("missing admin/player rows");
  process.exit(1);
}
const adminJ = jar();
const playerJ = jar();
adminJ.absorb(new Response(null, { headers: { "set-cookie": `rb_session=${makeSessionToken(admin.id)}; Path=/` } }));
playerJ.absorb(new Response(null, { headers: { "set-cookie": `rb_session=${makeSessionToken(player.id)}; Path=/` } }));

console.log("== 1. 2FA lifecycle ==");
{
  const r0 = await call(adminJ, "/api/admin/2fa");
  const d0 = (await r0.json()) as { configured: boolean; enabled: boolean };
  ok(r0.status === 200 && !d0.enabled, "2fa status: fresh admin, disabled");
  const r1 = await call(adminJ, "/api/admin/2fa", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "begin" }) });
  const d1 = (await r1.json()) as { secret: string; uri: string };
  ok(r1.status === 200 && d1.secret.length >= 32 && d1.uri.startsWith("otpauth://totp/ROLLBOX"), "begin returns base32 secret + otpauth URI");
  const bad = await call(adminJ, "/api/admin/2fa", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "confirm", code: "000000" }) });
  ok(bad.status === 400, "confirm with WRONG code -> 400");
  const goodCode = totpCode(d1.secret, step());
  const r2 = await call(adminJ, "/api/admin/2fa", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "confirm", code: goodCode }) });
  ok(r2.status === 200, "confirm with real TOTP code -> enabled");
  const gated = await call(adminJ, "/api/admin/players");
  ok(gated.status === 404, "admin API WITHOUT unlock cookie -> flat 404 (the gate)");
  const ru = await call(adminJ, "/api/admin/2fa/unlock", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: totpCode(d1.secret, step()) }) });
  ok(ru.status === 200, "unlock with real code -> 200 + rb_2fa cookie");
  const r3 = await call(adminJ, "/api/admin/players");
  ok(r3.status === 200, "admin API WITH unlock -> 200");
  const nonAdmin = await call(playerJ, "/api/admin/players");
  ok(nonAdmin.status === 404, "non-admin on admin API -> 404");
  const badUnlock = await call(playerJ, "/api/admin/2fa/unlock", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: "111111" }) });
  ok(badUnlock.status === 404, "non-admin cannot even knock on the unlock door");
}

console.log("== 2. Giveaways ==");
let gwId = "";
const prize = 7.5;
{
  const before = (await call(playerJ, "/api/auth/me")).clone();
  const meBefore = (await before.json()) as { player?: { balance: number } };
  const balBefore = meBefore.player?.balance ?? 0;

  const rc = await call(adminJ, "/api/admin/giveaways", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: "E2E Friday Pot", prizeCoins: prize, prizeLabel: "TEST skin", winnerCount: 1, endsAt: Date.now() + 3600_000 }) });
  const dc = (await rc.json()) as { ok?: boolean; id?: string };
  ok(rc.status === 200 && !!dc.id, "admin creates giveaway");
  gwId = dc.id ?? "";
  const rj = await call(playerJ, `/api/giveaways/${gwId}/join`, { method: "POST" });
  ok(rj.status === 200, "player joins");
  const rj2 = await call(playerJ, `/api/giveaways/${gwId}/join`, { method: "POST" });
  ok(rj2.status === 409, "second join -> 409 (one entry per player)");
  const rd = await call(adminJ, `/api/admin/giveaways/${gwId}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "draw" }) });
  const dd = (await rd.json()) as { winners?: { playerId: string }[] };
  ok(rd.status === 200 && dd.winners?.[0]?.playerId === player.id, "admin draws -> the single entrant wins");
  const meAfter = (await (await call(playerJ, "/api/auth/me")).json()) as { player?: { balance: number } };
  ok(Math.abs((meAfter.player?.balance ?? 0) - (balBefore + prize)) < 0.001, `balance +${prize} credited exactly`);
  const rd2 = await call(adminJ, `/api/admin/giveaways/${gwId}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "draw" }) });
  ok(rd2.status === 409, "second draw -> 409 (CAS, double-pay impossible)");
  const pub = (await (await call(playerJ, "/api/giveaways")).json()) as { recent: { id: string; winners: unknown[] }[] };
  ok(pub.recent.some((g) => g.id === gwId && g.winners.length === 1), "public winners wall shows the result");
  const gp = (await (await call(playerJ, "/api/giveaways")).json()) as { active: unknown[] };
  ok(gp.active.length === 0, "drawn pot left the active list");
}

console.log("== 3. Broadcast banner ==");
{
  const off = (await (await call(playerJ, "/api/banner")).json()) as { on: boolean };
  ok(!off.on, "banner off by default");
  const save = await call(adminJ, "/api/admin/banner", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ on: true, text: "E2E banner test — join the Friday pot", tone: "gold" }) });
  ok(save.status === 200, "admin saves banner");
  const on = (await (await call(playerJ, "/api/banner")).json()) as { on: boolean; text: string };
  ok(on.on && on.text.includes("E2E banner test"), "public /api/banner serves it to players");
}

console.log("== 4. Audit trail ==");
{
  const d = (await (await call(adminJ, "/api/admin/audit?page=1")).json()) as { rows: { action: string }[] };
  const acts = d.rows.map((r) => r.action);
  for (const a of ["2fa.enable", "2fa.unlock", "giveaway.create", "giveaway.draw", "banner.save"]) {
    ok(acts.includes(a), `audit row: ${a}`);
  }
}

console.log("== 5. RB-TST hidden, route alive ==");
{
  const home = await (await fetch(`${BASE}/`)).text();
  ok(!home.includes("test-rolldrop") && !home.includes("RB-TST"), "home page has no TEST case");
  const route = await fetch(`${BASE}/case/test-rolldrop`);
  ok(route.status === 200, "direct /case/test-rolldrop still renders (E2E lifeline)");
}

console.log("== 6. Personal history ==");
{
  const opens = (await (await call(playerJ, "/api/history?tab=opens&page=1")).json()) as { rows: unknown[]; total: number };
  ok(opens.rows.length > 0 && opens.total > 0, "opens tab serves drops");
  const money = (await (await call(playerJ, "/api/history?tab=money&page=1")).json()) as { rows: { kind: string }[] };
  ok(money.rows.length > 0 && money.rows.some((r) => r.kind === "giveaway_win"), "money tab serves ledger incl. giveaway_win");
  const battles = await call(playerJ, "/api/history?tab=battles&page=1");
  ok(battles.status === 200, "battles tab responds");
}

console.log("== 7. Cleanup ==");
{
  const secret = await db.siteConfig.findUnique({ where: { key: "admin.totpSecret" } });
  if (secret?.value) {
    await call(adminJ, "/api/admin/2fa", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "disable", code: totpCode(secret.value, step()) }) });
  }
  ok(((await db.siteConfig.findUnique({ where: { key: "admin.totpEnabled" } }))?.value ?? "0") !== "1", "2FA disabled again (site returns to pre-test state)");

  if (gwId) {
    await db.giveawayEntry.deleteMany({ where: { giveawayId: gwId } });
    await db.giveaway.delete({ where: { id: gwId } }).catch(() => null);
  }
  const ledgerKinds = await db.ledger.findMany({ where: { playerId: player.id, kind: "giveaway_win" } });
  let refund = 0;
  for (const row of ledgerKinds) refund += row.amount;
  await db.ledger.deleteMany({ where: { playerId: player.id, kind: "giveaway_win" } });
  await db.auditLog.deleteMany({ where: { action: { in: ["2fa.enable", "2fa.unlock", "giveaway.create", "giveaway.draw", "banner.save"] } } });
  await db.siteConfig.deleteMany({ where: { key: { in: ["site.bannerOn", "site.bannerText", "site.bannerTone"] } } });
  if (refund > 0) {
    const p = await db.player.findUnique({ where: { id: player.id }, select: { balance: true } });
    if (p) await db.player.update({ where: { id: player.id }, data: { balance: p.balance - refund } });
  }
  ok(true, `test giveaway + ledger + audit rows removed, $${refund.toFixed(2)} refunded to ${player.name}`);
}

const players = await db.player.count();
ok(players === 9, `players:9 intact (got ${players})`);

console.log(`\nRESULT: ${pass} PASS / ${fail} FAIL`);
process.exit(fail ? 1 : 0);
