/* eslint-disable @typescript-eslint/no-require-imports -- CommonJS run via bun */
// t94 — restore the demo baseline after test sessions.
// Baseline: 9 players with their starting balances, 0 battles / 0 ledger /
// 0 drops, p_t72B parked at 999999, and every battle-pass field reset
// (xp=0, level=1, dailyOpens=NULL — the Task 104 DB battle pass).
// NEVER wipes or scrubs the DB — only updates rows back to the baseline.
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// the 9 demo players and their baseline balances
const BASELINE = [
  { id: "p_t66A", balance: 4999 },
  { id: "p_t67A", balance: 4997 },
  { id: "p_t67B", balance: 5000 },
  { id: "p_t67C", balance: 5000 },
  { id: "p_t69A", balance: 494 },
  { id: "p_t72A", balance: 4950 },
  { id: "p_t72B", balance: 999999 },
  { id: "p_t75A", balance: 7189 },
  { id: "p_t75B", balance: 5000 },
];

(async () => {
  for (const { id, balance } of BASELINE) {
    // Steam OpenID is the only sign-in — every baseline player is a steam row
    await prisma.player.upsert({
      where: { id },
      update: { balance, xp: 0, level: 1, dailyOpens: null },
      create: {
        id,
        provider: "steam",
        providerId: `baseline_${id}`,
        name: id.replace(/^p_/, "").replace(/([A-Z])/g, " $1").trim(),
        balance,
      },
    });
  }
  // wipe session activity back to zero (players are kept)
  await prisma.ledger.deleteMany({});
  const battles = prisma.battle ? await prisma.battle.deleteMany({}) : null;
  const drops = prisma.drop ? await prisma.drop.deleteMany({}) : null;

  const players = await prisma.player.count();
  const b = (await prisma.battle?.count?.()) ?? 0;
  const l = await prisma.ledger.count();
  const d = (await prisma.drop?.count?.()) ?? 0;
  const t72b = await prisma.player.findUnique({ where: { id: "p_t72B" } });
  console.log(
    `baseline OK — players: ${players}, battles: ${b}, ledger: ${l}, drops: ${d}, t72B: ${t72b.balance}`
  );
  await prisma.$disconnect();
})().catch((e) => {
  console.error("baseline restore FAILED:", e.message);
  process.exit(1);
});
