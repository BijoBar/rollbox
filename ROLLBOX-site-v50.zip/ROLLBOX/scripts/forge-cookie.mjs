// Dev/test helper — forge a signed rb_session cookie for a player id.
// Usage: node scripts/forge-cookie.mjs <playerId>   (prints the cookie value)
// The signing secret lives in db/.auth-secret (same file the server reads).
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const pid = process.argv[2];
if (!pid) {
  console.error("usage: node scripts/forge-cookie.mjs <playerId>");
  process.exit(1);
}

const secret = fs.readFileSync(path.join(process.cwd(), "db", ".auth-secret"), "utf8").trim();
const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 1000 * 60 * 60 * 24 * 365 * 5 })).toString("base64url");
const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
console.log(`${body}.${sig}`);
