// ============ Task 29: REVERT the Task-28 denomination (×10 restore) ============
// USER SPEC: "the skin prices in the cases (including battles) go back to the
// prices they had before — they were already dollars". The Task-28 ÷10 pass
// treated the pre-flip numbers as ROLLCOIN at 10 per $; the owner ruled those
// numbers were ALREADY USD, so the whole numeric denomination change is
// rolled back while the green-$ display layer stays.
//
// What this script does (run ONLY once, guarded by a marker):
//   1. Player.balance × 10 for EVERY player (cent-precise) + a ledger audit
//      row per change ("Task 29 denomination restore: balance ×10").
//   2. db/exchange-stock.json — every item's p and v × 10 (backup first).
//
// The five price data files are restored from .bak-t27 separately (cp), the
// guest wallet via the store's v10 persist migration. InventoryItem rows are
// NOT touched (the red line — historic purchase records).
//
//   bun scripts/t29-restore-economy.mjs --yes

import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const MARKER = path.join(process.cwd(), "db", ".t29-economy-restored");
const T27_MARKER = path.join(process.cwd(), "db", ".t27-balances-scaled");
const STOCK = path.join(process.cwd(), "db", "exchange-stock.json");

if (fs.existsSync(MARKER)) {
  console.error("REFUSED: db/.t29-economy-restored exists — the restore already ran once.");
  process.exit(1);
}
if (!fs.existsSync(T27_MARKER)) {
  console.error("REFUSED: db/.t27-balances-scaled missing — the ÷10 never ran, nothing to restore.");
  process.exit(1);
}

const x10 = (n) => Math.max(0.01, Math.round(n * 10 * 100) / 100);

// ---------- 1. player balances ×10 ----------
const players = await db.player.findMany({ select: { id: true, name: true, balance: true } });
console.log("Players found:", players.length);
for (const p of players) console.log("  -", p.name ?? p.id, "balance:", p.balance, "→", x10(p.balance));

console.log("\nThis multiplies every balance by 10 (revert of the Task-28 ÷10). THIS CONSOLE IS NOT A CONFIRMATION.");
if (!process.argv.includes("--yes")) process.exit(0);

for (const p of players) {
  const next = x10(p.balance);
  await db.player.update({ where: { id: p.id }, data: { balance: next } });
  await db.ledger
    .create({
      data: {
        playerId: p.id,
        kind: "admin_comp",
        amount: Math.round((next - p.balance) * 100) / 100,
        balanceAfter: next,
        ref: "Task 29 denomination restore: balance ×10 (prices reverted to the pre-Task-28 scale)",
      },
    })
    .catch(() => {});
  console.log("✓", p.name ?? p.id, p.balance, "→", next);
}

// ---------- 2. exchange stock ×10 ----------
const stock = JSON.parse(fs.readFileSync(STOCK, "utf8"));
const items = Array.isArray(stock) ? stock : (stock.items ?? []);
let scaled = 0;
for (const it of items) {
  if (typeof it.p === "number") it.p = x10(it.p);
  if (typeof it.v === "number") it.v = x10(it.v);
  scaled += 1;
}
fs.copyFileSync(STOCK, STOCK + ".bak-t29");
fs.writeFileSync(STOCK, JSON.stringify(stock));
console.log(`✓ exchange-stock.json: ${scaled} items p/v ×10 (backup at .bak-t29)`);

fs.writeFileSync(MARKER, new Date().toISOString());
console.log("Marker written: db/.t29-economy-restored");
await db.$disconnect();
