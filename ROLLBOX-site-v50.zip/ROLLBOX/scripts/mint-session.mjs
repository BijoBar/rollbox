// Mints two test players + signed session tokens for the E2E.
// Usage: bun scripts/mint-session.mjs  → prints two JSON lines
import { PrismaClient } from "@prisma/client";
import crypto from "crypto";

const db = new PrismaClient();
const secret = process.env.AUTH_SECRET || "rollbox-dev-secret";

const sign = (payload) => crypto.createHmac("sha256", secret).update(payload).digest("base64url");
const token = (pid) => {
  const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 30 * 864e5 })).toString("base64url");
  return `${body}.${sign(body)}`;
};

const make = async (name, n) => {
  const providerId = `e2e-${name.toLowerCase()}-${Date.now()}`;
  const player = await db.player.create({
    data: { id: `p_e2e${n}_${crypto.randomBytes(4).toString("hex")}`, provider: "steam", providerId, name, balance: 1300 },
  });
  return { name: player.name, id: player.id, token: token(player.id), balance: player.balance };
};

const a = await make("E2E Alpha", "a");
const b = await make("E2E Bravo", "b");
console.log(JSON.stringify(a));
console.log(JSON.stringify(b));
await db.$disconnect();
