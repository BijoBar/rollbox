#!/usr/bin/env python3
"""Task 57: swap Seats/BattleGrid/BattleColumn for the unified BattleArea+RoundReel."""
import io, sys

path = "/home/z/my-project/src/components/rollbox/BattleRoomView.tsx"
with io.open(path, encoding="utf-8") as f:
    lines = f.readlines()

# locate boundaries
start = next(i for i, l in enumerate(lines) if "/* ===== waiting room" in l)
end = None
for i in range(start, len(lines)):
    if "function BattleColumn(" in lines[i]:
        # find the closing brace of BattleColumn (the line '}' at column 0 after it)
        j = i
        while lines[j].rstrip() != "}":
            j += 1
        end = j
        break
assert start is not None and end is not None, "boundaries not found"
# sanity: the block we are replacing must contain Seats, BattleGrid, BattleColumn
block = "".join(lines[start : end + 1])
assert "function Seats(" in block and "function BattleGrid(" in block and "function BattleColumn(" in block
assert "function DropTile" not in block

with io.open("/home/z/my-project/scripts/frag-battlearea.txt", encoding="utf-8") as f:
    frag = f.read()
if not frag.endswith("\n"):
    frag += "\n"

out = lines[:start] + [frag] + lines[end + 1 :]
with io.open(path, "w", encoding="utf-8") as f:
    f.writelines(out)
print(f"replaced lines {start + 1}..{end + 1} with the unified BattleArea + RoundReel")
