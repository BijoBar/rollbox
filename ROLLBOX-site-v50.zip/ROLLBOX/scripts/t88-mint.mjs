// Mints an rb_session cookie for a dedicated E2E test player and seeds his
// inventory with catalog skins so the UPGRADER / TERMINAL flows are testable.
// Usage: bun scripts/t88-mint.mjs  → prints "COOKIE=<value>" and "PID=<id>"
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const ROOT = "/home/z/my-project";

function signingSecret() {
  const file = path.join(ROOT, "db", ".auth-secret");
  try {
    const s = fs.readFileSync(file, "utf8").trim();
    if (s.length >= 32) return s;
  } catch {}
  // the dev server creates it on boot — force-read after a second
  throw new Error("db/.auth-secret missing — start the dev server once first");
}

const sign = (payload) =>
  crypto.createHmac("sha256", signingSecret()).update(payload).digest("base64url");

const makeToken = (pid) => {
  const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 30 * 864e5 })).toString("base64url");
  return `${body}.${sign(body)}`;
};

const catalog = JSON.parse(fs.readFileSync(path.join(ROOT, "public", "skins-catalog.json"), "utf8"));
const byId = new Map(catalog.map((e) => [e.id, e]));

// cheap skins to stake in the upgrader
const SEED_IDS = [
  "awp-safari-mesh", // classic 0.1$ style stake
  "mp9-arctic-tri-tone",
  "m4a4-magnesium",
  "glock-18-groundwater",
  "p250-sand-dune",
].filter((id) => byId.has(id));
// a dozen disposable 1-coin stakes for repeated spin probes
const FILLER_IDS = Array(14).fill("p250-sand-dune");

const PID = "p_t88a"; // deterministic id — cleanup deletes exactly this one

const player = await db.player.upsert({
  where: { id: PID },
  create: {
    id: PID,
    provider: "steam",
    providerId: "e2e-t88a",
    name: "T88 A",
    balance: 5000,
    refCode: "T88TEST1",
  },
  update: { bannedAt: null },
});

// seed a few inventory items (skip when already seeded)
const existing = await db.inventoryItem.findMany({ where: { playerId: PID } });
if (existing.length < 16) {
  for (const id of [...SEED_IDS, ...FILLER_IDS]) {
    const e = byId.get(id);
    const { wp: _wp, wa: _wa, ...base } = e;
    await db.inventoryItem.create({
      data: {
        id: "i_" + crypto.randomBytes(8).toString("hex"),
        playerId: PID,
        entryId: e.id,
        data: JSON.stringify(base),
        value: e.v,
      },
    });
  }
}

const token = makeToken(PID);
console.log("PID=" + PID);
console.log("COOKIE=" + token);
await db.$disconnect();
