// ============ Task 30 FINAL denomination: divide every player balance by 10 ============
// USER SPEC: "תחזיר את המחירים של הסקינים חזרה ל1X בכל האתר בחזרה. לא טוב הX10"
// — the X10 scale (restored by Task 29) is NOT good; the whole economy goes
// back to 1X (every site price = the real market USD 1:1, USD_TO_COINS = 1).
// The five price files were restored from the *.scaled-t28 snapshots (cp) and
// the rate flipped in wear.ts; THIS script re-denominates the DB side so
// purchasing power stays exactly 1:1 (same pattern the owner approved in
// Task 28 and in Task 29's reverse pass).
//
// What it does: Player.balance ÷ 10 (cent-precise, 0.01 floor) for EVERY
// player, plus a ledger audit row per change. InventoryItem rows are NOT
// touched — historic purchase records (the red line).
//
// Idempotency guard: db/.t30-balances-scaled prevents a double run.
//
//   bun scripts/t30-scale-balances.mjs --yes

import fs from "fs";
import path from "path";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const MARKER = path.join(process.cwd(), "db", ".t30-balances-scaled");

if (fs.existsSync(MARKER)) {
  console.error("REFUSED: db/.t30-balances-scaled exists — the Task 30 ÷10 already ran.");
  console.error("Delete the marker file first if this is genuinely a second, intended run.");
  process.exit(1);
}

const div10 = (n) => Math.max(0.01, Math.round((n / 10) * 100) / 100);

const players = await db.player.findMany({ select: { id: true, name: true, balance: true } });
console.log("Players found:", players.length);
for (const p of players) console.log("  -", p.name ?? p.id, "balance:", p.balance, "→", div10(p.balance));

console.log("\nThis divides every balance by 10 (Task 30: back to the 1X scale). THIS CONSOLE IS NOT A CONFIRMATION.");
if (!process.argv.includes("--yes")) process.exit(0);

for (const p of players) {
  const next = div10(p.balance);
  await db.player.update({ where: { id: p.id }, data: { balance: next } });
  await db.ledger.create({
    data: {
      playerId: p.id,
      kind: "admin_comp",
      amount: Math.round((next - p.balance) * 100) / 100,
      balanceAfter: next,
      ref: "Task 30 denomination: balance /10 (final 1X scale — 1$ = 1 coin)",
    },
  }).catch(() => {});
  console.log("✓", p.name ?? p.id, p.balance, "→", next);
}

fs.writeFileSync(MARKER, new Date().toISOString());
console.log("\nMarker written: db/.t30-balances-scaled");
