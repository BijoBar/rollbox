#!/usr/bin/env bash
# Task 45 E2E — solo ROLLDROP (forced): white flash + extra rare reel + audit.
set -u
AB="agent-browser"
D="/home/z/my-project/download"

echo "=== home: wide logo + floating raredrop ==="
$AB open http://localhost:3000/ >/dev/null 2>&1
sleep 3.5
$AB eval '(() => {
  const wide = document.querySelector("header img[src=\"/rollboxlogo.png\"]");
  const icon = document.querySelector("header img[src=\"/rollboxlogo-icon.png\"]");
  const float = document.querySelector(".anim-float img[src=\"/raredrop.png\"]");
  return JSON.stringify({
    wideLogo: !!wide && wide.complete && wide.naturalWidth > 0,
    iconHiddenOnDesktop: icon === null || getComputedStyle(icon).display === "none",
    floatingRaredrop: !!float && float.complete && float.naturalWidth > 0,
    favicon: document.querySelector("link[rel*=\"icon\"]")?.getAttribute("href")
  });
})' 2>&1 | tail -1
$AB screenshot "$D/task45-home.png" >/dev/null 2>&1

echo "=== solo rolldrop (forced) ==="
$AB eval 'localStorage.setItem("rb-rolldrop-force", "1")' >/dev/null 2>&1
$AB eval 'JSON.parse(localStorage.getItem("rollbox-store")).state.balance' 2>&1 | tail -1
$AB eval 'document.querySelector("a[href=\"/case/farm-ak47\"]") !== null' 2>&1 | tail -1
$AB eval 'document.querySelector("a[href=\"/case/farm-ak47\"]").click()' >/dev/null 2>&1
sleep 2.5
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => /Open Case/i.test(x.textContent) && !x.disabled); b?.click(); return b ? "spin" : "nobtn"; })' 2>&1 | tail -1
echo "--- poll for the white flash (spin ends ~9s) ---"
for i in $(seq 1 24); do
  sleep 0.6
  R=$($AB eval '(() => { const f = document.querySelector(".rd-flash"); const cover = document.querySelector(".rd-white-cover"); const t = document.body.textContent; return JSON.stringify({flash: !!f, cover: !!cover, spinningAgain: t.includes("slowing down") || t.includes("Here it comes")}); })' 2>/dev/null | tail -1)
  echo "poll$i: $R"
  case "$R" in *'"flash":true'*) $AB screenshot "$D/task45-flash.png" >/dev/null 2>&1; break ;; esac
done
echo "--- wait for the extra reel to land (+1s over normal = ~7.5s) ---"
sleep 8.5
$AB eval '(() => {
  const st = JSON.parse(localStorage.getItem("rollbox-store")).state;
  const win = document.body.textContent.match(/₡[0-9,.]+/g)?.slice(0, 4)?.join(" ");
  return JSON.stringify({
    balance: st.balance,
    revealed: document.body.textContent.includes("Open Again"),
    nonce: st.pfNonce
  });
})' 2>&1 | tail -1
$AB screenshot "$D/task45-solo-bonus-landed.png" >/dev/null 2>&1