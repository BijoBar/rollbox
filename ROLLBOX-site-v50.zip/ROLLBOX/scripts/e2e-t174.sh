#!/usr/bin/env bash
# e2e-t174.sh — UPGRADER visual rebuild E2E (Task 174)
# Verifies: reactor core renders (SVG + aura + spark canvas), default 2x/47.5%,
# inventory card selection, live spin choreography (CHARGING state, verdict
# banner lands), multiplier switch to 10x (9.5% chance), zero console/page
# errors, mobile 375x812 zero horizontal overflow. Cleanup after.
set -uo pipefail
cd /home/z/my-project
AB="agent-browser"
TOKEN="$(bun scripts/mint-e2e-session.ts | sed -E 's/.*"token":"([^"]+)".*/\1/')"
SHOT="scripts/e2e-t174"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0

check() { $AB eval "$1" 2>/dev/null | rg -o "true|false" | head -1; }

$AB cookies clear >/dev/null 2>&1 || true
$AB open http://localhost:3000/upgrader >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
$AB reload >/dev/null
sleep 2.5

# 1. the reactor core renders: svg wheel + spark canvas + aura
w=$(check "!!document.querySelector('[data-testid=\"upgrader-wheel\"] svg')")
c=$(check "!!document.querySelector('[data-testid=\"upgrader-wheel\"] canvas')")
[ "$w" = "true" ] && ok "wheel svg present" || fail "wheel svg present"
[ "$c" = "true" ] && ok "spark canvas present" || fail "spark canvas present"

# 2. default readout: 2x target, 47.5% win (uppercase CSS — case-insensitive check)
d=$(check "/47\\.5%\\s*win/i.test(document.body.innerText)")
[ "$d" = "true" ] && ok "default 2x readout (47.5% win)" || fail "default 2x readout"

# 3. pick one inventory skin — the spin button arms with its label
$AB find first "button[aria-label^='Stake']" click >/dev/null 2>&1
sleep 0.4
armed=$(check "document.querySelector('[data-testid=\"upgrader-spin\"]').innerText.includes('UPGRADE 1 SKIN')")
[ "$armed" = "true" ] && ok "spin button armed (UPGRADE 1 SKIN)" || fail "spin button armed"

# 4. spin — CHARGING state + charge bar, then the verdict lands
$AB find first "[data-testid='upgrader-spin']" click >/dev/null 2>&1
sleep 0.8
charging=$(check "document.body.innerText.includes('CHARGING')")
[ "$charging" = "true" ] && ok "CHARGING state visible" || fail "CHARGING state visible"
$AB screenshot "$SHOT-spinning.png" >/dev/null 2>&1
sleep 5.2
res=$($AB eval "document.querySelector('[data-testid=\"upgrader-result\"]').innerText" 2>/dev/null | head -3 | tr '\n' ' ')
echo "verdict: $res"
if echo "$res" | rg -q "UPGRADED!|FAILED"; then ok "verdict banner landed"; else fail "verdict banner landed"; fi

# 5. multiplier switch to 10x — the chance readout morphs to 9.5%
$AB find text "10×" click >/dev/null 2>&1
sleep 0.8
ch=$($AB eval "document.querySelector('[data-testid=\"upgrader-chance-panel\"]').innerText" 2>/dev/null | tail -1)
echo "10x chance panel: $ch"
echo "$ch" | rg -q "9.50" && ok "10x chance = 9.50%" || fail "10x chance = 9.50%"
$AB screenshot "$SHOT-desktop.png" >/dev/null 2>&1

# 6. console + page errors
errs=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -5)
if [ -z "$errs" ]; then ok "zero page errors"; else fail "page errors: $errs"; fi

# 7. mobile 375x812 — zero horizontal overflow
$AB set viewport 375 812 >/dev/null
$AB reload >/dev/null
sleep 2.2
ov=$(check "document.documentElement.scrollWidth <= 375")
[ "$ov" = "true" ] && ok "mobile 375px: zero horizontal overflow" || fail "mobile 375px: horizontal overflow"
$AB screenshot "$SHOT-mobile.png" >/dev/null 2>&1
$AB set viewport 1440 900 >/dev/null

# 8. cleanup
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB open about:blank >/dev/null 2>&1 || true

[ "$FAILED" = "0" ] && echo "== E2E t174: ALL PASS ==" || echo "== E2E t174: FAILURES =="
exit $FAILED
