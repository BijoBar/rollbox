#!/usr/bin/env python3
"""Event page background: resize the uploaded 2816x1536 JPEG to a web-friendly
1920w hero (quality 80, progressive) -> public/event-bg.jpg."""
from PIL import Image
import os

SRC = "/home/z/my-project/upload/rollboxevent.jpg"
DST = "/home/z/my-project/public/event-bg.jpg"

img = Image.open(SRC).convert("RGB")
w, h = img.size
target_w = 1920
if w > target_w:
    img = img.resize((target_w, round(h * target_w / w)), Image.LANCZOS)
img.save(DST, "JPEG", quality=80, optimize=True, progressive=True)
print("saved", DST, img.size, os.path.getsize(DST), "bytes")
