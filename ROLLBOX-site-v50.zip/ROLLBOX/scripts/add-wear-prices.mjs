// ============ Task 72: inject per-wear prices into the exchange catalog ============
// public/skins-catalog.json entries that are WEAR-ABLE (t undefined = weapon
// skins / knives / gloves / zeus) gain:
//   wp: { FN?: usd, MW?: usd, FT?: usd, WW?: usd, BS?: usd } — real market
//       prices per wear (market.csgo.com bulk dump)
//   wa: ["FN",...] — in-game wear availability, recorded ONLY when the skin
//       does not come in all five wears (official CS2 DB)
// Stickers / charms / agents / patches and vanilla knives stay untouched.
import { readFileSync, writeFileSync } from "fs";

const ROOT = "/home/z/my-project";
const PRICES = JSON.parse(readFileSync(`${ROOT}/scripts/csgotm-prices.json`, "utf8"));
const DB = JSON.parse(readFileSync(`${ROOT}/scripts/skins-db.json`, "utf8"));
const CATALOG = JSON.parse(readFileSync(`${ROOT}/public/skins-catalog.json`, "utf8"));

const WEARS = [
  ["FN", "Factory New"],
  ["MW", "Minimal Wear"],
  ["FT", "Field-Tested"],
  ["WW", "Well-Worn"],
  ["BS", "Battle-Scarred"],
];
const LABEL_TO_ID = Object.fromEntries(WEARS.map(([id, label]) => [label, id]));

const priceByHash = new Map();
for (const it of PRICES.items) {
  const p = parseFloat(it.price);
  if (Number.isFinite(p) && p > 0) priceByHash.set(it.market_hash_name, p);
}
const wearsByName = new Map();
for (const s of DB) {
  wearsByName.set(
    s.name,
    (s.wears ?? []).map((w) => LABEL_TO_ID[w.name]).filter(Boolean)
  );
}
const ALL_IDS = WEARS.map(([id]) => id);

let withWp = 0;
let withWa = 0;
let pricedCombos = 0;
for (const e of CATALOG) {
  if (e.t !== undefined) continue; // stickers/charms/agents/patches: no wears
  const inGame = wearsByName.get(e.n);
  if (!Array.isArray(inGame) || inGame.length === 0) continue; // vanilla knives etc.
  const wp = {};
  for (const [wid, label] of WEARS) {
    const p = priceByHash.get(`${e.n} (${label})`);
    if (p) {
      wp[wid] = Math.round(p * 100) / 100;
      pricedCombos++;
    }
  }
  if (Object.keys(wp).length > 0) {
    e.wp = wp;
    withWp++;
  }
  if (inGame.join(",") !== ALL_IDS.join(",")) {
    e.wa = inGame;
    withWa++;
  }
}

writeFileSync(`${ROOT}/public/skins-catalog.json`, JSON.stringify(CATALOG));
console.log(
  `catalog entries: ${CATALOG.length} | with wp: ${withWp} | with wa: ${withWa} | priced combos: ${pricedCombos}`
);
