#!/usr/bin/env bash
# Task 43 E2E — part 3: battle room (KICK a bot + fire emoji button +
# vertical picker + float rises from the sender's box).
set -u
AB="agent-browser"
D="/home/z/my-project/download"

echo "=== close picker, pick 2x cheap case, create 1v1 ==="
$AB eval '(() => {
  const dlg = document.querySelector("[role=\"dialog\"]");
  const farm3 = [...dlg.querySelectorAll("button[aria-label^=\"Add\"]")].find(b => b.getAttribute("aria-label").includes("₡3"));
  farm3?.click();
  return farm3 ? "added ₡3 case" : "case?";
})()' 2>/dev/null | tail -1
sleep 0.5
$AB eval '(() => {
  document.querySelector("[role=\"dialog\"] button[aria-label^=\"Add\"]")?.closest("[role=\"dialog\"]");
  // close the dialog via Escape-like overlay click
  const overlay = document.querySelector("[data-slot=\"dialog-overlay\"]") || document.querySelector("[data-state=\"open\"].fixed");
  (overlay ?? document.querySelector("[role=\"dialog\"]")).dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true}));
  return "esc";
})()' 2>/dev/null | tail -1
sleep 0.8
$AB eval '(() => {
  const b = [...document.querySelectorAll("button")].find(x => x.textContent.includes("Create Battle"));
  b?.click();
  return b ? "created" : "NOT FOUND";
})()' 2>/dev/null | tail -1
sleep 2.5
$AB eval '(() => JSON.stringify({url: location.pathname, seats: [...document.querySelectorAll("button")].filter(b => b.getAttribute("aria-label")?.includes("Pick which bot")).length}))' 2>/dev/null | tail -1

echo "=== seat a hand-picked bot on the EMPTY seat ==="
$AB eval '(() => {
  const chip = [...document.querySelectorAll("button")].find(b => b.getAttribute("aria-label")?.includes("Pick which bot plays in this empty seat"));
  chip?.click();
  return chip ? "chip clicked" : "NO CHIP";
})()' 2>/dev/null | tail -1
sleep 1
$AB eval '(() => {
  const dlg = document.querySelector("[role=\"dialog\"]");
  const bot = [...dlg.querySelectorAll("button")].find(b => b.textContent.includes("[RBbot]"));
  const name = bot?.textContent.match(/\[RBbot\][^\n]*/)?.[0];
  bot?.click();
  return name || "NO BOT";
})()' 2>/dev/null | tail -1
sleep 1.2
$AB eval '(() => {
  const kick = [...document.querySelectorAll("button")].filter(b => b.textContent.trim() === "Kick");
  return JSON.stringify({ kickButtons: kick.length, roomFull: !!document.body.textContent.match(/Waiting for players/) });
})()' 2>/dev/null | tail -1
$AB screenshot "$D/task43-kick-visible.png" >/dev/null 2>&1

echo "=== KICK the bot ==="
$AB eval '(() => {
  const kick = [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "Kick");
  kick?.click();
  return kick ? "kicked" : "NO KICK";
})()' 2>/dev/null | tail -1
sleep 1
$AB eval '(() => {
  const kick = [...document.querySelectorAll("button")].filter(b => b.textContent.trim() === "Kick");
  const empty = document.body.textContent.includes("Waiting...");
  const toast = document.body.textContent.includes("Bot kicked");
  const countdown = document.querySelector(".font-display.text-8xl");
  return JSON.stringify({ kickAfter: kick.length, emptySeatBack: empty, toast, countdownShowing: !!countdown });
})()' 2>/dev/null | tail -1

echo "=== re-seat bot (room must be usable again) ==="
$AB eval '(() => {
  const chip = [...document.querySelectorAll("button")].find(b => b.getAttribute("aria-label")?.includes("Pick which bot plays in this empty seat"));
  chip?.click();
  return chip ? "chip" : "NO CHIP";
})()' 2>/dev/null | tail -1
sleep 1
$AB eval '(() => {
  const bot = [...document.querySelectorAll("[role=\"dialog\"] button")].find(b => b.textContent.includes("[RBbot]"));
  bot?.click();
  return "seated";
})()' 2>/dev/null | tail -1
sleep 1
$AB eval '(() => JSON.stringify({kickButtons: [...document.querySelectorAll("button")].filter(b => b.textContent.trim() === "Kick").length}))' 2>/dev/null | tail -1