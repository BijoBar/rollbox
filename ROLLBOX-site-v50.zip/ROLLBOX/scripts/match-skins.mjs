// Match ROLLBOX's 32 skins against the official CS2 community database.
// Output: matched list with icon_url for hotlinking.
import { readFileSync, writeFileSync } from "fs";

const db = JSON.parse(readFileSync("/home/z/my-project/scripts/skins-db.json", "utf8"));

// Extract skin display names from cases.ts
const casesSrc = readFileSync("/home/z/my-project/src/lib/cases.ts", "utf8");
const idNamePairs = [...casesSrc.matchAll(/"([a-z0-9-]+)":\s*\{\s*id:\s*"([a-z0-9-]+)",\s*name:\s*"([^"]+)"/g)]
  .map((m) => ({ fileKey: m[1], id: m[2], name: m[3] }));

console.log("skins in cases.ts:", idNamePairs.length);

const byName = new Map(db.map((s) => [s.name, s]));
// in-game alias: our display name -> official DB name
const ALIASES = new Map([["★ Butterfly | Doppler", "★ Butterfly Knife | Doppler"]]);

const results = [];
const missing = [];
for (const p of idNamePairs) {
  const hit = byName.get(ALIASES.get(p.name) ?? p.name);
  if (hit && hit.image) {
    results.push({ id: p.id, name: p.name, apiId: hit.id, image: hit.image });
  } else {
    missing.push(p);
  }
}

console.log("matched:", results.length, " missing:", missing.length);
if (missing.length) {
  console.log("\nMISSING:");
  for (const m of missing) console.log(" -", m.id, "=>", m.name);
  // fuzzy suggestions for missing ones
  console.log("\nSUGGESTIONS:");
  for (const m of missing) {
    const base = m.name.replace("★ ", "").split("|")[1]?.trim().toLowerCase() ?? "";
    const weapon = m.name.replace("★ ", "").split("|")[0].trim().toLowerCase();
    const cands = db.filter(
      (s) => s.name.toLowerCase().includes(base.slice(0, 6)) && s.name.toLowerCase().includes(weapon.slice(0, 4))
    ).slice(0, 4);
    for (const c of cands) console.log(`   ${m.name}  ~~>  ${c.name}`);
  }
}

writeFileSync("/home/z/my-project/scripts/skin-match.json", JSON.stringify(results, null, 2));

// Generate src/lib/skin-images.ts for hotlinking
const ts = `// ============ Skin image hotlinks ============
// Auto-generated from the official CS2 community database (ByMykel/CSGO-API).
// Images are served directly from Valve's Steam CDN. Do not edit by hand —
// re-run scripts/match-skins.mjs to regenerate.

export const SKIN_IMAGES: Record<string, string> = {
${results.map((r) => `  "${r.id}": "${r.image}",`).join("\n")}
};

export function skinImage(skinId: string): string | undefined {
  return SKIN_IMAGES[skinId];
}
`;
writeFileSync("/home/z/my-project/src/lib/skin-images.ts", ts);

console.log("\nwrote scripts/skin-match.json + src/lib/skin-images.ts");
