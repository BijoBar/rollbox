// Test-player cleanup: removes the minted test player and ALL his rows
// (inventory items cascade via playerId FK, ledger rows are filtered too).
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const PROVIDER_ID = "t9x-exchange-tester";
const player = await db.player.findUnique({ where: { providerId: PROVIDER_ID } });
if (player) {
  await db.inventoryItem.deleteMany({ where: { playerId: player.id } });
  await db.ledger.deleteMany({ where: { playerId: player.id } }).catch(() => {});
  await db.player.delete({ where: { id: player.id } });
  console.log("removed " + player.id);
} else {
  console.log("nothing to remove");
}
await db.$disconnect();
