#!/bin/bash
# Task 182 v3 — DEFINITIVE tracer: node ids + creator stack signature.
set -u
BASE="http://localhost:3000"

agent-browser close >/dev/null 2>&1 || true
sleep 1

echo "== open /case/test-rolldrop =="
agent-browser open "$BASE/case/test-rolldrop" >/dev/null
sleep 6

echo "== install v3 tracer =="
agent-browser eval '
(() => {
  if (window.__tracer) return "already";
  window.__log = [];
  window.__alive = new Map();
  window.__tArm = null;
  let nid = 0;
  const t0ms = () => Math.round(performance.now());
  const BS = AudioBufferSourceNode.prototype;
  const Sched = AudioScheduledSourceNode.prototype;
  const dStart = Object.getOwnPropertyDescriptor(BS, "start") || Object.getOwnPropertyDescriptor(Sched, "start");
  const dStop  = Object.getOwnPropertyDescriptor(BS, "stop")  || Object.getOwnPropertyDescriptor(Sched, "stop");
  const origStart = dStart.value, origStop = dStop.value;
  const onBS = Object.getOwnPropertyDescriptor(BS, "start") ? BS : Sched;
  const sig = () => {
    const st = (new Error()).stack || "";
    const lines = st.split("\n").map(s => s.trim()).filter(s => s.includes("/") && !s.includes("eval"));
    return lines.slice(0, 4).join(" | ").slice(0, 400);
  };
  const nStart = function(...a) {
    if (window.__tArm !== null && this.loop === true) {
      const id = ++nid;
      this.__id = id;
      window.__alive.set(id, { t0: t0ms() - window.__tArm, stack: sig() });
      window.__log.push({ ev: "s", id, t: t0ms() - window.__tArm });
    }
    return origStart.apply(this, a);
  };
  const nStop = function(...a) {
    if (this.__id && window.__alive.has(this.__id)) {
      const m = window.__alive.get(this.__id);
      window.__log.push({ ev: "e", id: this.__id, t: t0ms() - window.__tArm, life: (t0ms() - window.__tArm) - m.t0 });
      window.__alive.delete(this.__id);
    }
    return origStop.apply(this, a);
  };
  Object.defineProperty(onBS, "start", { value: nStart, writable: true, configurable: true });
  Object.defineProperty(onBS, "stop",  { value: nStop,  writable: true, configurable: true });
  window.__tracer = true;
  return "v3-installed";
})()
' > /tmp/t182c-install.txt 2>&1
cat /tmp/t182c-install.txt

agent-browser eval 'window.__tArm = Math.round(performance.now()); "armed"' >/dev/null
agent-browser eval '
(() => {
  const btns = Array.from(document.querySelectorAll("button"));
  const b = btns.find((x) => /OPEN\b/i.test(x.textContent || ""));
  if (!b) return "NO-OPEN-BUTTON";
  b.click();
  return "clicked";
})()
' > /tmp/t182c-click.txt 2>&1
cat /tmp/t182c-click.txt

echo "== wait 27s =="
sleep 27

echo "== loop events (id/ev/t) =="
agent-browser eval 'JSON.stringify(window.__log)' > /tmp/t182c-log.json 2>&1
echo "== creator stacks of long-lived loops (life>2000ms) =="
agent-browser eval '
JSON.stringify(Array.from(window.__alive.entries()).map(([id, m]) => ({ id, ...m })))
' > /tmp/t182c-alive.json 2>&1
agent-browser eval '
(() => {
  const log = window.__log;
  const life = {};
  for (const e of log) {
    if (e.ev === "s") life[e.id] = { t0: e.t, t1: null };
    else if (e.ev === "e" && life[e.id]) life[e.id].t1 = e.t;
  }
  const long = Object.entries(life).filter(([id, m]) => m.t1 === null || (m.t1 - m.t0) > 2000);
  return JSON.stringify(long.map(([id, m]) => ({ id, ...m, stack: (window.__alive.get(+id) || {}).stack || "closed-see-below" })));
})()
' > /tmp/t182c-long.json 2>&1
head -c 3500 /tmp/t182c-long.json
echo ""
echo "== still alive at end =="
head -c 2000 /tmp/t182c-alive.json
echo ""
echo "== bonus marker seen? (board outcome) =="
agent-browser eval '
(() => {
  const txt = document.body.innerText || "";
  return JSON.stringify({
    hasTotalWon: /TOTAL WON/i.test(txt),
    hasBonus: /BONUS/i.test(txt),
    spinning: /SPINNING/i.test(txt),
  });
})()
'
