// Compare the canonical CASE EDITOR (BASE/SKINS) against the current site data.
// Usage: bun scripts/compare-editor-data.ts [editor.html]   (default: the last
// user-uploaded canonical file kept in scripts/editor-data/CANONICAL-editor.html)
import { readFileSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import path from "node:path";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const EDITOR = process.argv[2] ?? path.join(ROOT, "scripts", "editor-data", "CANONICAL-editor.html");

// --- extract BASE + SKINS from the editor file ---
const html = readFileSync(EDITOR, "utf8");
const lines = html.split("\n");
const baseLine = lines.find((l) => l.startsWith("const BASE = "));
const skinsLine = lines.find((l) => l.startsWith("const SKINS = "));
if (!baseLine || !skinsLine) throw new Error("BASE/SKINS lines not found");
const BASE = JSON.parse(baseLine.replace(/^const BASE = /, "").replace(/;\s*$/, ""));
const SKINS = JSON.parse(skinsLine.replace(/^const SKINS = /, "").replace(/;\s*\/\/.*$/, "").trim());

// --- load site data by importing the real modules ---
const imp = (rel: string) => import(pathToFileURL(path.join(ROOT, rel)).href);
const { CASES, SKINS: SITE_SKINS } = await imp("src/lib/cases.ts") as typeof import("../src/lib/cases");
const { SKIN_WEAR_PRICES, SKIN_WEAR_AVAIL } = await imp("src/lib/generated-wear-prices.ts") as typeof import("../src/lib/generated-wear-prices");

const siteByCode = new Map(CASES.map((c) => [c.code, c]));

let problems = 0;
const note = (msg: string) => { console.log("  ⚠ " + msg); problems++; };

console.log("=== BASE vs site CASES ===");
console.log(`editor BASE: ${BASE.length} cases | site CASES: ${CASES.length}`);

for (const eb of BASE) {
  const sc = siteByCode.get(eb.code);
  if (!sc) { note(`${eb.code}: NOT on site`); continue; }
  // header fields
  if (sc.name !== eb.name) note(`${eb.code}: name "${sc.name}" vs "${eb.name}"`);
  if (sc.subtitle !== eb.subtitle) note(`${eb.code}: subtitle differs`);
  if (sc.price !== eb.price) note(`${eb.code}: price ${sc.price} vs ${eb.price}`);
  if (sc.kind !== eb.kind) note(`${eb.code}: kind ${sc.kind} vs ${eb.kind}`);
  const siteRd = sc.rolldropChance == null ? null : Math.round(sc.rolldropChance * 100000) / 1000 * 100 / 100; // keep raw
  const siteRdPct = sc.rolldropChance == null ? null : sc.rolldropChance * 100;
  const ebRd = eb.rd == null ? null : eb.rd;
  const match = siteRdPct == null && ebRd == null ? true : siteRdPct != null && ebRd != null && Math.abs(siteRdPct - ebRd) < 1e-9;
  if (!match) note(`${eb.code}: rd site ${siteRdPct} vs editor ${ebRd}`);
  // items
  if (sc.items.length !== eb.items.length) note(`${eb.code}: item count ${sc.items.length} vs ${eb.items.length}`);
  for (let i = 0; i < Math.min(sc.items.length, eb.items.length); i++) {
    const si = sc.items[i], ei = eb.items[i];
    if (si.skinId !== ei.id) { note(`${eb.code}[${i}]: id ${si.skinId} vs ${ei.id}`); continue; }
    if (si.weight !== ei.p) note(`${eb.code}[${i}] ${ei.id}: weight ${si.weight} vs ${ei.p}`);
    if ((si.wear ?? null) !== (ei.w ?? null)) note(`${eb.code}[${i}] ${ei.id}: wear ${si.wear} vs ${ei.w}`);
    // value: site override vs editor v
    const siteVal = si.value ?? null;
    if (siteVal != null && Math.abs(siteVal - ei.v) > 1e-9) note(`${eb.code}[${i}] ${ei.id}: value ${siteVal} vs ${ei.v}`);
    if (siteVal == null) console.log(`  ℹ ${eb.code}[${i}] ${ei.id}: no site value override (editor v=${ei.v} — derived)`);
    // name check via site skins happens below (SKINS section)
  }
}

// cases on site missing from editor
for (const sc of CASES) if (!BASE.find((b) => b.code === sc.code)) note(`site case ${sc.code} missing from editor BASE`);

console.log("\n=== SKINS vs site registries ===");
let ids = Object.keys(SKINS);
console.log(`editor SKINS: ${ids.length} entries`);
for (const id of ids) {
  const es = SKINS[id];
  const ss = SITE_SKINS?.[id];
  if (!ss) { note(`SKINS[${id}]: not in site SKINS registry`); continue; }
  if (ss.name !== es.name) note(`SKINS[${id}]: name "${ss.name}" vs "${es.name}"`);
  if (ss.rarity !== es.rarity) note(`SKINS[${id}]: rarity ${ss.rarity} vs ${es.rarity}`);
  const siteWp = (SKIN_WEAR_PRICES as any)[id];
  if (es.wp && !siteWp) note(`SKINS[${id}]: editor has wp, site has none`);
  if (siteWp && !es.wp) note(`SKINS[${id}]: site has wp, editor none`);
  if (es.wp && siteWp) {
    for (const w of Object.keys(es.wp)) {
      if ((siteWp as any)[w] !== es.wp[w]) note(`SKINS[${id}].wp.${w}: site ${(siteWp as any)[w]} vs editor ${es.wp[w]}`);
    }
  }
  const siteWa = (SKIN_WEAR_AVAIL as any)?.[id];
  const eWa = es.wa ?? null;
  const sWa = siteWa === undefined ? null : siteWa;
  if (JSON.stringify(eWa) !== JSON.stringify(sWa)) note(`SKINS[${id}].wa: site ${JSON.stringify(sWa)} vs editor ${JSON.stringify(eWa)}`);
}

// which site case-skins are missing from the editor registry (would break autocomplete/wear picks)
const usedIds = new Set<string>();
for (const sc of CASES) for (const it of sc.items) usedIds.add(it.skinId);
for (const id of usedIds) if (!SKINS[id]) note(`case skin ${id} used on site but missing from editor SKINS`);

console.log(`\n=== DONE: ${problems} problem(s) ===`);
