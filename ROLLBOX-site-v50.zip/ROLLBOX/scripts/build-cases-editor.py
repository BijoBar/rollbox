# Inject the live case registry into the HTML editor template (Task 72:
# also injects per-skin wear prices + availability, and per-item wear state).
import json

DUMP = "/home/z/my-project/scripts/cases-dump.json"
TPL = "/home/z/my-project/scripts/cases-editor-template.html"
OUT = "/home/z/my-project/download/ROLLBOX-cases-editor.html"

dump = json.load(open(DUMP, encoding="utf-8"))
cases = []
for c in dump["cases"]:
    cases.append({
        "code": c["code"],
        "name": c["name"],
        "subtitle": c["subtitle"],
        "price": c["price"],
        "kind": c["kind"],
        "rd": c["rolldropChance"] * 100 if c["rolldropChance"] else None,
        "items": [
            # v = the EFFECTIVE value (base value, wear price, or override)
            dict(
                {"id": it["skinId"], "n": it["name"], "v": it["value"], "p": it["weight"], "rarity": it["rarity"]},
                **({"w": it["wear"]} if it.get("wear") else {}),
            )
            for it in c["items"]
        ],
    })

# skinId -> wear price table (coins) + in-game availability (only deviations)
skins = dump.get("skins", {})

payload = json.dumps(cases, ensure_ascii=False, separators=(",", ":"))
skins_payload = json.dumps(skins, ensure_ascii=False, separators=(",", ":"))

# Task 92: Python serializes tiny weights (0.000015) in exponent form
# ("1.5e-05") — valid JSON but ugly inside the editor's number inputs.
# Rewrite every exponent float back to plain decimal notation.
import re

def _deexpon(m):
    return format(float(m.group(0)), "f")

_exp = re.compile(r"-?\d+\.?\d*e[+-]\d+")
payload = _exp.sub(_deexpon, payload)
skins_payload = _exp.sub(_deexpon, skins_payload)

assert "</script" not in payload.lower() and "</script" not in skins_payload.lower(), "unsafe payload"

html = open(TPL, encoding="utf-8").read()
assert "__CASES_JSON__" in html and "__SKINS_JSON__" in html, "placeholder missing"
html = html.replace("__CASES_JSON__", payload).replace("__SKINS_JSON__", skins_payload)

n_items = sum(len(c["items"]) for c in cases)
n_wear = sum(1 for c in cases for it in c["items"] if it.get("w"))
open(OUT, "w", encoding="utf-8").write(html)
print(f"written {OUT} | cases={len(cases)} items={n_items} wear-items={n_wear} skins={len(skins)} size={len(html)//1024}KB")
