// ============ ROLLBOX content design: 20 themed cases + 9 farm cases ============

/**
 * Theme selectors:
 *   must      — exact skin display names that MUST be in the case (if they exist in DB)
 *   keywords  — case-insensitive substrings; a skin matches if it contains ANY keyword
 *   weapon    — exact weapon display name filter (e.g. "AWP", "AK-47", "M4A4"...)
 *   category  — category filter ("Knife", "Gloves")
 *   colors    — [tierColor, tierColor2] accent pair
 *   tagline   — case subtitle
 */
export const THEMES = [
  {
    id: "asiimov-protocol",
    name: "Asiimov Protocol",
    keywords: ["asiimov"],
    colors: ["#f0821e", "#e8e0d0"],
    tagline: "The future leaked into today — paint it white, shoot it orange.",
  },
  {
    id: "printstream-cartel",
    name: "Printstream Cartel",
    keywords: ["printstream"],
    colors: ["#eceaf4", "#17151d"],
    tagline: "Monochrome money — clean lines, dirty payouts.",
  },
  {
    id: "dragons-vault",
    name: "Dragon's Vault",
    must: [
      "AWP | Dragon Lore",
      "AK-47 | Fire Serpent",
      "Desert Eagle | Kumicho Dragon",
      "AK-47 | Aquamarine Revenge",
    ],
    keywords: ["dragon"],
    colors: ["#f0b90b", "#2e7d32"],
    tagline: "Sleeping gold and ancient fire — the rarest hoard on ROLLBOX.",
  },
  {
    id: "fade-factory",
    name: "Fade Factory",
    keywords: ["fade"],
    colors: ["#f5d442", "#e34fa0"],
    tagline: "Anodized rainbow at 90/10 — the purest flex in the game.",
  },
  {
    id: "crimson-covenant",
    name: "Crimson Covenant",
    keywords: ["crimson web", "code red", "redline"],
    colors: ["#eb4b4b", "#4a0a0a"],
    tagline: "Woven in red — every thread ends in blood.",
  },
  {
    id: "doppler-realm",
    name: "Doppler Realm",
    keywords: ["doppler"],
    colors: ["#8847ff", "#2a0e5c"],
    tagline: "Liquid galaxy swirls — pick your phase, chase your star.",
  },
  {
    id: "hardened-crown",
    name: "Hardened Crown",
    keywords: ["case hardened", "blue laminate", "blue titanium"],
    colors: ["#4b69ff", "#101c4a"],
    tagline: "Blue gems and lottery patterns — the collector's gamble.",
  },
  {
    id: "hellfire-club",
    name: "Hellfire Club",
    keywords: ["blaze", "fire elemental", "wildfire", "inferno", "desert-fire", "flame"],
    colors: ["#ff6a00", "#7a0d0d"],
    tagline: "Play with fire — burn bright or burn out.",
  },
  {
    id: "neon-district",
    name: "Neon District",
    keywords: ["neon rider", "neo-noir", "neon boost", "neon proliferator", "hyper burst"],
    colors: ["#25e0d8", "#e3326b"],
    tagline: "Midnight city lights and synthwave payouts.",
  },
  {
    id: "emerald-sanctum",
    name: "Emerald Sanctum",
    keywords: ["gamma doppler", "emerald"],
    colors: ["#1f9f6b", "#0a3524"],
    tagline: "Living crystal — the greenest grail room on the site.",
  },
  {
    id: "tiger-tribe",
    name: "Tiger Tribe",
    keywords: ["tiger"],
    colors: ["#f5a623", "#191512"],
    tagline: "Stripes of gold — hunt or be hunted.",
  },
  {
    id: "hyper-beast-bazaar",
    name: "Hyper Beast Bazaar",
    keywords: ["hyper beast", "mother of beasts", "beast of prey"],
    colors: ["#e91e63", "#3fa34d"],
    tagline: "Radioactive street art — loud skins for loud wins.",
  },
  {
    id: "awp-command",
    name: "AWP Command",
    weapon: "AWP",
    colors: ["#38bdf8", "#17346e"],
    tagline: "One shot, one story — enter the sniper's cathedral.",
  },
  {
    id: "ak-imperium",
    name: "AK Imperium",
    weapon: "AK-47",
    colors: ["#d32f2f", "#f0b90b"],
    tagline: "The king's arsenal — from Redline all the way to Fire Serpent.",
  },
  {
    id: "blade-barony",
    name: "Blade Barony",
    category: "Knife",
    colors: ["#9c27b0", "#f0b90b"],
    tagline: "Steel nobility — every pull is a coronation.",
  },
  {
    id: "glove-syndicate",
    name: "Glove Syndicate",
    category: "Gloves",
    colors: ["#00bfa5", "#4e342e"],
    tagline: "Dress your hands in fortune — leather, silk, snakeskin.",
  },
  {
    id: "gold-rush",
    name: "Gold Rush",
    keywords: ["gold"],
    colors: ["#ffd54f", "#7a5c00"],
    tagline: "All that glitters actually pays — strike it rich.",
  },
  {
    id: "urban-ops",
    name: "Urban Ops",
    keywords: ["urban"],
    colors: ["#90a4ae", "#232a30"],
    tagline: "Concrete-jungle warfare — gritty odds, honest steel.",
  },
  {
    id: "glitch-protocol",
    name: "Glitch Protocol",
    keywords: ["chromatic aberration", "glitch", "cortex", "cyber"],
    colors: ["#7c4dff", "#00e5ff"],
    tagline: "Reality is buffering — pull the anomaly out of the noise.",
  },
  {
    id: "polar-front",
    name: "Polar Front",
    keywords: ["polar", "arctic", "frost", "winter", "candy cane", "ice capped"],
    colors: ["#b3e5fc", "#3d5a6e"],
    tagline: "Frozen assets — break the ice and thaw the value.",
  },
];

/**
 * Farm cases: 99.5% to hit the cheap farm item (~$0.20 for weapons), 0.5%
 * split across the premium items ($20+, weighted inversely by price).
 * Zeus has only 7 skins in the whole game, so its farm runs 1 farm item +
 * 6 premiums (the other 6 Zeus skins) — same inverse-price math.
 */
export const FARMS = [
  { id: "farm-m4a4", name: "Farm M4A4", weapon: "M4A4" },
  { id: "farm-m4a1s", name: "Farm M4A1-S", weapon: "M4A1-S" },
  { id: "farm-ak47", name: "Farm AK-47", weapon: "AK-47" },
  { id: "farm-deagle", name: "Farm Deagle", weapon: "Desert Eagle" },
  { id: "farm-glock", name: "Farm Glock", weapon: "Glock-18" },
  { id: "farm-usps", name: "Farm USP-S", weapon: "USP-S" },
  { id: "farm-awp", name: "Farm AWP", weapon: "AWP" },
  { id: "farm-gloves", name: "Farm Gloves", category: "Gloves" },
  { id: "farm-knives", name: "Farm Knives", category: "Knife" },
  { id: "farm-zeus", name: "Farm Zeus", weapon: "Zeus x27" },
];

/**
 * Explicit farm rosters (user-specified): the "farm item" is the
 * "Sticker | Gloves On" sticker pinned at 99.55%, the remaining 0.45% is
 * distributed inversely by price across the 9 premium items below.
 * wear: exact exterior for the premium item (null = vanilla / no exterior).
 */
export const FARM_ROSTERS = {
  "farm-gloves": {
    wear: "Minimal Wear",
    items: [
      "Hydra Gloves | Case Hardened",
      "Hydra Gloves | Emerald",
      "Moto Gloves | Blood Pressure",
      "Specialist Gloves | Chocolate Chesterfield",
      "Broken Fang Gloves | Jade",
      "Hand Wraps | Desert Shamagh",
      "Sport Gloves | Blaze",
      "Specialist Gloves | Buckshot",
      "Hydra Gloves | Mangrove",
    ],
  },
  "farm-knives": {
    wear: "Minimal Wear",
    items: [
      "Shadow Daggers | Black Laminate",
      { name: "Navaja Knife | VANILLA", wear: null, vanilla: "★ Navaja Knife" },
      "Navaja Knife | Blue Steel",
      "Paracord Knife | Scorched",
      { name: "Nomad Knife | Tiger Tooth", wear: "Factory New" },
      "Gut Knife | Bright Water",
      "Flip Knife | Autotronic",
      "Classic Knife | Fade",
      "Bowie Knife | Marble Fade",
    ],
  },
};

/** Farm item for roster farms — the "Gloves ON" sticker at 99.55%. */
export const FARM_STICKER = "Sticker | Gloves On";

export const FARM_COLORS = ["#34d399", "#065f46"];
export const FARM_TAGLINE =
  "Grind machine — 99.5% farm item, 0.5% pure jackpot. Endless spins, tiny cost.";
