#!/usr/bin/env bash
# e2e-t172.sh — REGRESSION TEST for Task 172 (ALT-TAB reel reset + server-time reels)
#
# BUG: switching away from the tab (ALT-TAB to another app) and coming back
# RESET the in-flight battle reel: the Task-169 wake handler re-ran the FULL
# clock which wiped the reveal state (setRevealed({}) + setRound(-1)), so the
# in-flight reel unmounted and REPLAYED from zero. Reels were also
# mount-relative (performance.now), so a frozen tab always lost its position.
#
# FIX under test: (1) BattleReel startAtMs — wall-clock seekable reels, the
# position is a pure function of the server schedule + poll offset; (2) the
# wake handler runs the RESYNC pass (no state wipe, chain rebuild only).
#
# PROTOCOL (live bot battles as p_t66A):
#   1. WAKE CONTINUITY — enter early, catch a spinning reel, mark its strip
#      DOM node + transform, hide the tab (visibilityState override + event),
#      wake it, and require: SAME strip node (no remount), transform kept
#      moving FORWARD (no reset to ~0), and the verdict still lands.
#   2. HIDE ACROSS A ROUND FLIP — hide for longer (past the round boundary),
#      wake, require the room advanced (never backward), a live reel seen,
#      zero "Get ready" freeze streak, verdict lands.
#   3. MID-ROUND RELOAD (seek-on-join) — reload inside round 1's spin; the
#      freshly mounted reel must appear ALREADY DEEP into the strip (seeked
#      to the server-true position), never restart from the top; verdict lands.
set -euo pipefail
cd /home/z/my-project
BASE=http://localhost:3000
TOKEN=$(bun scripts/mint-e2e-session.ts 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')

api() { curl -s -H "Cookie: rb_session=$TOKEN" -H 'Content-Type: application/json' "$@"; }
field() { python3 -c "import sys,json;d=json.load(sys.stdin);print(eval(\"d$1\"))"; }

echo "== minted p_t66A =="

create_battle() {
  api -X POST "$BASE/api/gbattles" -d '{"type":"1v1v1","mode":"standard","potRule":"winner","rounds":["farm-ak47","farm-ak47","farm-ak47"],"fast":false,"private":false}' | field "['id']"
}
fill_bots() { api -X POST "$BASE/api/gbattles/$1/bots" -d '{}' >/dev/null; }
server_started_at() { python3 -c "import sys,json,time;print(int(time.time()*1000)-json.load(sys.stdin)['battle']['serverNow'])"; }
wait_playing() {
  for i in $(seq 1 40); do
    OUT=$(api "$BASE/api/gbattles/$1" | python3 -c "
import sys,json
d=json.load(sys.stdin)['battle']
print(d['status'], (d['schedule'][-1]['endMs'] if d.get('schedule') else 0), (d['totalMs'] or 0))")
    set -- $OUT
    if [ "$1" = "playing" ]; then echo "$2 $3"; return 0; fi
    sleep 0.4
  done
  echo "NEVER"; return 1
}
elapsed_ms() { echo $(( $(date +%s%3N) - $1 )); }
sleep_until() { local DIFF=$(( $2 - $(elapsed_ms "$1") )); if [ "$DIFF" -gt 0 ]; then python3 -c "import time;time.sleep($DIFF/1000)"; fi; }

open_room() {
  agent-browser open "$BASE/" >/dev/null 2>&1
  agent-browser wait 700 >/dev/null
  agent-browser cookies set rb_session "$TOKEN" >/dev/null
  agent-browser open "$BASE/battles/$1" >/dev/null 2>&1
  agent-browser wait 1200 >/dev/null
}

PASS=0; FAIL=0
report() { if [ "$1" = "0" ]; then echo "   PASS"; PASS=$((PASS+1)); else echo "   FAIL"; FAIL=$((FAIL+1)); fi; }

# ===== SCENARIO 1 — WAKE CONTINUITY (the reported ALT-TAB reset) =====
echo "== scenario 1: wake mid-spin keeps the same reel moving forward =="
BID=$(create_battle); fill_bots "$BID"
S=$(wait_playing "$BID"); set -- $S; LASTEND=$1; TOTAL=$2
STARTED=$(( $(date +%s%3N) - $(api "$BASE/api/gbattles/$BID" | server_started_at) ))
sleep_until "$STARTED" 1400   # inside round 0's spin
open_room "$BID"
agent-browser wait 900 >/dev/null   # reels spinning by now
OUT=$(python3 << PYEOF
import subprocess, time, json

def ev(js):
    r = subprocess.run(["agent-browser", "eval", js], capture_output=True, text=True)
    out = (r.stdout or "").strip().splitlines()
    try:
        v = json.loads(out[-1]) if out else {}
        return json.loads(v) if isinstance(v, str) else v
    except Exception:
        return {}

MARK_WAIT = """(() => {
  const strip = document.querySelector('.reel-fade-t')?.parentElement?.querySelector('.will-change-transform');
  if (!strip) return JSON.stringify({ok: false});
  const m = strip.style.transform.match(/,\\s*(-?[\\d.]+)px/);
  const y = m ? Math.abs(parseFloat(m[1])) : 0;
  // only mark a reel that is genuinely MID-SPIN (5%..70% of the ~14k strip)
  if (y < 500 || y > 10000) return JSON.stringify({ok: false, y});
  window.__rbWakeStrip = strip;
  window.__rbWakeT1 = strip.style.transform;
  return JSON.stringify({ok: true, t1: strip.style.transform, y});
})()"""

HIDE = """(() => {
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' });
  document.dispatchEvent(new Event('visibilitychange'));
  return JSON.stringify({hidden: document.visibilityState === 'hidden'});
})()"""

WAKE = """(() => {
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' });
  document.dispatchEvent(new Event('visibilitychange'));
  return JSON.stringify({visible: document.visibilityState === 'visible'});
})()"""

CHECK = """(() => {
  const strip = window.__rbWakeStrip;
  const txt = document.body.innerText;
  return JSON.stringify({
    sameNode: !!strip && strip.isConnected && document.contains(strip),
    t2: strip && strip.isConnected ? strip.style.transform : null,
    t1: window.__rbWakeT1 || null,
    gr: /get ready/i.test(txt),
    verdict: /VICTORY!|BATTLE LOST!|POT SPLIT!/i.test(txt)
  });
})()"""

def y(p):
    m = re.search(r',\s*(-?\d+(?:\.\d+)?)px', p or '')
    return float(m.group(1)) if m else None

import re
# wait for a reel that is genuinely mid-spin before hiding (max 10s)
res = {}
t_mark = time.time()
while time.time() - t_mark < 10:
    res = ev(MARK_WAIT)
    if res.get("ok"):
        break
    time.sleep(0.15)
if not res.get("ok"):
    print(json.dumps({"error": "no mid-spin reel found to mark", "lastProbe": res})); raise SystemExit(0)
ev(HIDE)
time.sleep(1.3)          # the "sleeping" window
ev(WAKE)
time.sleep(0.35)         # let the wake frame + resync land
c = ev(CHECK)
t1, t2 = y(c.get("t1")), y(c.get("t2"))
# the strip scrolls toward -totalY: forward = same-or-more-negative. A reset
# would jump the position back toward ~0 (y2 >> y1). Settle snap may pull the
# winner back toward dead-center by up to ~half a cell → 250px tolerance.
forward = t1 is not None and t2 is not None and t2 <= t1 + 250
same = c.get("sameNode") is True
# wait for the verdict (battle ends ~16s; we joined at ~1.4s + 1.3 hidden)
deadline = time.time() + 22
while time.time() < deadline:
    c2 = ev(CHECK)
    if c2.get("verdict"):
        c = c2; break
    time.sleep(0.5)
print(json.dumps({
  "sameNode": same, "t1": t1, "t2": t2, "forward": forward,
  "gr": bool(c.get("gr")), "verdict": bool(c.get("verdict"))
}))
PYEOF
)
echo "$OUT"
OK=$(echo "$OUT" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(0 if d.get('sameNode') and d.get('forward') and d.get('verdict') and not d.get('gr') else 1)" 2>/dev/null || echo 1)
report "$OK"

# ===== SCENARIO 2 — HIDE ACROSS A ROUND FLIP =====
echo "== scenario 2: hide across the round boundary, wake, fight continues =="
BID=$(create_battle); fill_bots "$BID"
S=$(wait_playing "$BID"); set -- $S; LASTEND=$1; TOTAL=$2
STARTED=$(( $(date +%s%3N) - $(api "$BASE/api/gbattles/$BID" | server_started_at) ))
sleep_until "$STARTED" 2600   # near the end of round 0
open_room "$BID"
agent-browser wait 700 >/dev/null
OUT=$(python3 << PYEOF
import subprocess, time, json, re

def ev(js):
    r = subprocess.run(["agent-browser", "eval", js], capture_output=True, text=True)
    out = (r.stdout or "").strip().splitlines()
    try:
        v = json.loads(out[-1]) if out else {}
        return json.loads(v) if isinstance(v, str) else v
    except Exception:
        return {}

HIDE = """(() => {
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' });
  document.dispatchEvent(new Event('visibilitychange'));
  return JSON.stringify({ok: true});
})()"""
WAKE = """(() => {
  Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' });
  document.dispatchEvent(new Event('visibilitychange'));
  return JSON.stringify({ok: true});
})()"""
POLL = """(() => {
  const txt = document.body.innerText;
  const rounds = [...document.querySelectorAll('[data-round]')].map(e => Number(e.dataset.round));
  return JSON.stringify({
    round: rounds.length ? Math.max(...rounds) : -1,
    gr: /get ready/i.test(txt),
    verdict: /VICTORY!|BATTLE LOST!|POT SPLIT!/i.test(txt),
    reelSeen: !!document.querySelector('[aria-label*="won"], .anim-lock-flash')
  });
})()"""

ev(HIDE)
time.sleep(3.4)          # round 0 ends + round 1 starts while "hidden"
ev(WAKE)
max_round = -1; gr_streak = 0; max_gr = 0; verdict = False; reel = False
deadline = time.time() + 20
while time.time() < deadline:
    s = ev(POLL)
    max_round = max(max_round, s.get("round", -1))
    gr_streak = gr_streak + 1 if s.get("gr") else 0
    max_gr = max(max_gr, gr_streak)
    verdict = verdict or bool(s.get("verdict"))
    reel = reel or bool(s.get("reelSeen"))
    if verdict and time.time() > deadline - 18:
        break
    time.sleep(0.45)
print(json.dumps({"maxRound": max_round, "maxGetReadyStreak": max_gr, "verdict": verdict, "reelSeen": reel}))
PYEOF
)
echo "$OUT"
OK=$(echo "$OUT" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(0 if d.get('maxRound',-1) >= 1 and d.get('maxGetReadyStreak',99) <= 4 and d.get('verdict') else 1)" 2>/dev/null || echo 1)
report "$OK"

# ===== SCENARIO 3 — MID-ROUND RELOAD (seek-on-join, decisive) =====
# A seeked reel NEVER spins past its scheduled lock: every mounted-reel
# sample satisfies (locked) OR (elapsed-since-reel-start ≤ 2660ms + slack).
# A REPLAYED reel (old behavior) is still unlocked long after sa+2660 —
# caught by the "spinning past schedule" detector. Join latency immune.
echo "== scenario 3: reload inside round 1 — reel never spins past its schedule =="
BID=$(create_battle); fill_bots "$BID"
S=$(wait_playing "$BID"); set -- $S; LASTEND=$1; TOTAL=$2
STARTED=$(( $(date +%s%3N) - $(api "$BASE/api/gbattles/$BID" | server_started_at) ))
SLOT1=$(api "$BASE/api/gbattles/$BID" | python3 -c "import sys,json;print(json.load(sys.stdin)['battle']['schedule'][1]['startMs'])")
sleep_until "$STARTED" $(( SLOT1 + 500 ))   # round 1 just started
open_room "$BID"
OUT=$(STARTED="$STARTED" SLOT1="$SLOT1" python3 << PYEOF
import subprocess, time, json, os

def ev(js):
    r = subprocess.run(["agent-browser", "eval", js], capture_output=True, text=True)
    out = (r.stdout or "").strip().splitlines()
    try:
        v = json.loads(out[-1]) if out else {}
        return json.loads(v) if isinstance(v, str) else v
    except Exception:
        return {}

POLL = """(() => {
  const r = document.querySelector('[data-testid="round-reel"]');
  const sa = r ? (r.dataset.startAt || null) : null;
  const rounds = [...document.querySelectorAll('[data-round]')].map(e => Number(e.dataset.round));
  return JSON.stringify({
    sa,
    locked: !!document.querySelector('[aria-label*="won"]'),
    maxRound: rounds.length ? Math.max(...rounds) : -1,
    gr: /get ready/i.test(document.body.innerText),
    verdict: /VICTORY!|BATTLE LOST!|POT SPLIT!/i.test(document.body.innerText)
  });
})()"""

# REEL_LOCK = REEL_YOU_MS(2400) + edging hold+settle(260) — the shared-clock
# lock instant. A reel still unlocked past this + slack = replaying (BUG).
REEL_LOCK = 2660
SLACK = 900
max_round = -1; gr_streak = 0; max_gr = 0; verdict = False
spun_past = 0; seek_seen = False; saw_reel = False
t0 = time.time()
while time.time() - t0 < 24:
    s = ev(POLL)
    max_round = max(max_round, s.get("maxRound", -1))
    gr_streak = gr_streak + 1 if s.get("gr") else 0
    max_gr = max(max_gr, gr_streak)
    verdict = verdict or bool(s.get("verdict"))
    sa = s.get("sa")
    if sa:
        saw_reel = True
        el = time.time() * 1000 - float(sa)
        if el > 600:  # mounted deep enough to prove a seek, not a fresh spin
            seek_seen = True
        if not s.get("locked") and el > REEL_LOCK + SLACK:
            spun_past += 1
    if verdict:
        break
    time.sleep(0.15)
print(json.dumps({
    "sawReel": saw_reel, "seekSeen": seek_seen, "spunPastSchedule": spun_past,
    "maxRound": max_round, "maxGetReadyStreak": max_gr, "verdict": verdict
}))
PYEOF
)
echo "$OUT"
OK=$(echo "$OUT" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(0 if d.get('sawReel') and d.get('spunPastSchedule',99)==0 and d.get('maxRound',-1)>=1 and d.get('maxGetReadyStreak',99)<=4 and d.get('verdict') else 1)" 2>/dev/null || echo 1)
report "$OK"

agent-browser cookies clear >/dev/null 2>&1 || true
agent-browser storage local clear >/dev/null 2>&1 || true
agent-browser open about:blank >/dev/null 2>&1 || true

echo "== RESULT: PASS=$PASS FAIL=$FAIL =="
[ "$FAIL" = "0" ]
