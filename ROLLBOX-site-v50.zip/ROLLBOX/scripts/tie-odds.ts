// Print each Farm case's value distribution and the 1v1 1-round tie odds.
import { CASES, SKINS } from "../src/lib/cases";

for (const c of CASES.filter((x) => x.kind === "farm")) {
  const wSum = c.items.reduce((s, i) => s + i.weight, 0);
  const byVal = new Map<number, number>();
  for (const it of c.items) {
    const v = SKINS[it.skinId]?.value ?? 0;
    byVal.set(v, (byVal.get(v) ?? 0) + it.weight);
  }
  let pTie = 0;
  for (const w of byVal.values()) pTie += (w / wSum) ** 2;
  console.log(
    c.id.padEnd(14),
    "₡" + String(c.price).padEnd(3),
    "items:", String(c.items.length).padEnd(3),
    "values:", [...byVal.keys()].join("/").padEnd(14),
    "pTie(1r 1v1):", pTie.toFixed(3)
  );
}
