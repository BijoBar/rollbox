#!/usr/bin/env bash
# C7 PHASE 1 — API-level E2E for the real-crypto wallet (deposits/withdrawals).
# Uses the minted E2E player (p_t66A) and admin (p_t72B). Cleanup happens in
# scripts/c7-cleanup.ts afterwards — this script only prints a machine-readable
# PASS/FAIL line per check.
set -u
cd /home/z/my-project

BASE="http://localhost:3000"
PT_JSON=$(bun scripts/mint-e2e-session.ts)
AT_JSON=$(bun scripts/mint-admin-session.ts)
PT=$(printf '%s' "$PT_JSON" | python3 -c "import sys,json;print(json.load(sys.stdin)['token'])")
AT=$(printf '%s' "$AT_JSON" | python3 -c "import sys,json;print(json.load(sys.stdin)['token'])")
PID=$(printf '%s' "$PT_JSON" | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")
AID=$(printf '%s' "$AT_JSON" | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")
echo "player=$PID admin=$AID"

ADDR=$(python3 -c "print('T'+'a'*33)")      # format-valid fake TRC-20 address (base58, no l/I/O/0)
TX1=$(python3 -c "print('a'*64)")
TX2=$(python3 -c "print('b'*64)")

# fresh state: snapshot the player's money + wipe leftovers from earlier runs
bun scripts/c7-cleanup.ts snapshot

pass=0; fail=0
check() { # check <name> <expected> <actual>
  if [ "$2" = "$3" ]; then pass=$((pass+1)); echo "PASS $1"; else fail=$((fail+1)); echo "FAIL $1 (expected=$2 actual=$3)"; fi
}

# snapshot initial balance for the report
B0=$(curl -s -b "rb_session=$PT" "$BASE/api/auth/me" | python3 -c "import sys,json;print(json.load(sys.stdin)['player']['balance'])")
echo "initial balance: $B0"

# 1. wallet shape (state-independent — the config is (re)saved below)
r=$(curl -s -b "rb_session=$PT" "$BASE/api/wallet")
check "wallet-get-shape" "True True" "$(printf '%s' "$r" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['enabled'], isinstance(d['methods'], list))")"

# 2. non-admin cannot read the admin queue
check "admin-wallet-gate" "404" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" "$BASE/api/admin/wallet")"

# 3. admin saves config
r=$(curl -s -b "rb_session=$AT" -H 'Content-Type: application/json' -X POST "$BASE/api/admin/wallet/config" \
  -d "{\"values\":{\"wallet.enabled\":\"1\",\"wallet.usdt_address\":\"$ADDR\",\"wallet.minDeposit\":\"10\",\"wallet.maxDeposit\":\"100\",\"wallet.minWithdraw\":\"10\",\"wallet.maxWithdraw\":\"50\"}}")
check "admin-config-save" "True" "$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")"

# 3b. invalid address refused
check "admin-config-bad-address" "400" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$AT" -H 'Content-Type: application/json' -X POST "$BASE/api/admin/wallet/config" -d '{"values":{"wallet.usdt_address":"0xDEADBEEF"}}')"

# 4. wallet now exposes the address
r=$(curl -s -b "rb_session=$PT" "$BASE/api/wallet")
check "wallet-get-address" "$ADDR" "$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['methods'][0]['address'])")"

# 5. deposit without declaration -> 400
check "deposit-no-declaration" "400" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/deposit" -d "{\"amountUsd\":50,\"txid\":\"$TX1\",\"declared\":false}")"

# 6. bad txid -> 400
check "deposit-bad-txid" "400" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/deposit" -d '{"amountUsd":50,"txid":"nothex","declared":true}')"

# 7. below min -> 400
check "deposit-below-min" "400" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/deposit" -d "{\"amountUsd\":5,\"txid\":\"$TX1\",\"declared\":true}")"

# 8. over max -> 400
check "deposit-over-max" "400" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/deposit" -d "{\"amountUsd\":150,\"txid\":\"$TX1\",\"declared\":true}")"

# 9. valid deposit -> pending
r=$(curl -s -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/deposit" -d "{\"amountUsd\":50,\"txid\":\"$TX1\",\"declared\":true}")
check "deposit-ok" "pending" "$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['request']['status'])")"
DEP_ID=$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['request']['id'])")

# 10. same txid again -> 409
check "deposit-dup-txid" "409" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/deposit" -d "{\"amountUsd\":20,\"txid\":\"$TX1\",\"declared\":true}")"

# 11. admin queue shows it
r=$(curl -s -b "rb_session=$AT" "$BASE/api/admin/wallet")
check "admin-queue-pending" "1" "$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['pendingDeposits'])")"

# 12. double-approve guard: approve once
r=$(curl -s -b "rb_session=$AT" -H 'Content-Type: application/json' -X POST "$BASE/api/admin/wallet/deposit/$DEP_ID" -d '{"action":"approve"}')
check "deposit-approve" "approved" "$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['status'])")"
B1=$(curl -s -b "rb_session=$PT" "$BASE/api/auth/me" | python3 -c "import sys,json;print(round(json.load(sys.stdin)['player']['balance'],2))")
check "deposit-credited" "$(python3 -c "print(round($B0+50,2))")" "$B1"

# 13. second approve -> 409
check "deposit-double-approve" "409" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$AT" -H 'Content-Type: application/json' -X POST "$BASE/api/admin/wallet/deposit/$DEP_ID" -d '{"action":"approve"}')"

# 14. withdrawal: bad address -> 400
check "withdraw-bad-address" "400" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/withdraw" -d '{"amountCoins":20,"address":"0xdeadbeef","declared":true}')"

# 15. withdrawal over balance -> 400
check "withdraw-over-balance" "400" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/withdraw" -d "{\"amountCoins\":99999,\"address\":\"$ADDR\",\"declared\":true}")"

# 16. valid withdrawal -> coins locked instantly
r=$(curl -s -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/withdraw" -d "{\"amountCoins\":20,\"address\":\"$ADDR\",\"declared\":true}")
check "withdraw-ok" "pending" "$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['request']['status'])")"
WD_ID=$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['request']['id'])")
B2=$(printf '%s' "$r" | python3 -c "import sys,json;print(round(json.load(sys.stdin)['balance'],2))")
check "withdraw-locked" "$(python3 -c "print(round($B1-20,2))")" "$B2"

# 17. second pending withdrawal -> 429
check "withdraw-one-at-a-time" "429" "$(curl -s -o /dev/null -w '%{http_code}' -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/withdraw" -d "{\"amountCoins\":10,\"address\":\"$ADDR\",\"declared\":true}")"

# 18. admin rejects -> instant refund
r=$(curl -s -b "rb_session=$AT" -H 'Content-Type: application/json' -X POST "$BASE/api/admin/wallet/withdraw/$WD_ID" -d '{"action":"reject","note":"test rejection"}')
check "withdraw-reject" "rejected" "$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['status'])")"
check "withdraw-refunded" "$(python3 -c "print(round($B1,2))")" "$(printf '%s' "$r" | python3 -c "import sys,json;print(round(json.load(sys.stdin)['balance'],2))")"

# 19. admin marks a PAID flow (new withdrawal then paid)
r=$(curl -s -b "rb_session=$PT" -H 'Content-Type: application/json' -X POST "$BASE/api/wallet/withdraw" -d "{\"amountCoins\":10,\"address\":\"$ADDR\",\"declared\":true}")
WD2=$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['request']['id'])")
r=$(curl -s -b "rb_session=$AT" -H 'Content-Type: application/json' -X POST "$BASE/api/admin/wallet/withdraw/$WD2" -d "{\"action\":\"paid\",\"payoutTxid\":\"$TX2\"}")
check "withdraw-paid" "paid" "$(printf '%s' "$r" | python3 -c "import sys,json;print(json.load(sys.stdin)['status'])")"

# 20. ledger audit rows exist
LEDCHECK=$(curl -s -b "rb_session=$PT" "$BASE/api/ledger" | python3 -c "
import sys,json
d=json.load(sys.stdin)
rows=d.get('rows') or d.get('ledger') or d.get('items') or []
kinds={r.get('kind') for r in rows}
print('deposit' in kinds, 'withdraw_lock' in kinds, 'withdraw_refund' in kinds)")
check "ledger-kinds-present" "True True True" "$LEDCHECK"

echo "---- API E2E: $pass passed, $fail failed ----"
exit $([ $fail -eq 0 ] && echo 0 || echo 1)
