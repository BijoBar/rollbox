#!/usr/bin/env python3
"""Task 83 splice — remove the SETTINGS panel + SelfCareConfirm render from
ProfileView.tsx (they moved to SettingsView.tsx / the /settings page).

Deletes (1-indexed, inclusive):
  1017..1233  the settings motion.div (Main settings + Sign out + Self care)
  1236..1248  the SelfCareConfirm render block
Boundary lines are asserted before touching anything.
"""
import sys

PATH = "src/components/rollbox/ProfileView.tsx"

with open(PATH, encoding="utf-8") as f:
    lines = f.read().split("\n")

# sanity — 1-indexed line -> expected prefix / exact content
assert lines[1016].lstrip().startswith("{/* USER SPEC (Task 75): SETTINGS"), f"L1017: {lines[1016]!r}"
assert lines[1232] == "        </motion.div>", f"L1233: {lines[1232]!r}"
assert lines[1233] == "      </div>", f"L1234: {lines[1233]!r}"
assert lines[1235].lstrip().startswith("{/* the second confirmation"), f"L1236: {lines[1235]!r}"
assert lines[1247] == "      )}", f"L1248: {lines[1247]!r}"
assert lines[1248] == "    </main>", f"L1249: {lines[1248]!r}"

out = lines[0:1016] + lines[1233:1235] + lines[1248:]
with open(PATH, "w", encoding="utf-8") as f:
    f.write("\n".join(out))

print(f"spliced OK: {len(lines)} -> {len(out)} lines")
print("tail:")
print("\n".join(out[-8:]))
