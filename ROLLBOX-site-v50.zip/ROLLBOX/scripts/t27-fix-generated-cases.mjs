// ============ Task 27 one-shot: scale generated-cases.ts skin values ÷10 ============
// The first apply-unified-prices.ts run had a regex bug (^" vs indented lines):
// SKIN values in generated-cases.ts were skipped while case prices WERE scaled.
// This one-shot finishes that pass (values only — prices are already done).
// Idempotency marker: db/.t27-cases-values-scaled
import fs from "fs";
import path from "path";

const ROOT = path.join(path.dirname(new URL(import.meta.url).pathname), "..");
const FILE = path.join(ROOT, "src", "lib", "generated-cases.ts");
const MARKER = path.join(ROOT, "db", ".t27-cases-values-scaled");

if (fs.existsSync(MARKER)) {
  console.error("REFUSED: marker exists — values already scaled once.");
  process.exit(1);
}

let src = fs.readFileSync(FILE, "utf8");
let n = 0;
src = src.replace(
  /^(\s*"(?:[a-z0-9-]+)": \{ id: "(?:[a-z0-9-]+)", name: "([^"]+)",[^}]*?value: )(\d+(?:\.\d+)?)(,)/gm,
  (_m, head, name, val, tail) => {
    n++;
    return head + Math.round((parseFloat(val) / 10) * 100) / 100 + tail;
  },
);
fs.writeFileSync(FILE, src);
fs.writeFileSync(MARKER, new Date().toISOString());
console.log(`✓ generated-cases.ts skin values ÷10: ${n} lines scaled`);

// sanity: show a few known rows
for (const m of src.matchAll(/"(ak-47-asiimov|ak-47-fire-serpent|ak-47-crossfade)": \{[^}]*?value: ([\d.]+)/g)) {
  console.log("  ", m[1], "→", m[2]);
}
