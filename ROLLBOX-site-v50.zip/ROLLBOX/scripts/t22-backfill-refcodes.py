#!/usr/bin/env python3
"""Task 22 backfill: give every existing Player a unique referral code.
Codes: 8 chars from an unambiguous alphabet (no 0/O/1/I). Idempotent —
players that already carry a code are skipped. Never touches balances."""
import secrets
import sqlite3

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

def new_code() -> str:
    return "".join(secrets.choice(ALPHABET) for _ in range(8))

con = sqlite3.connect("/home/z/my-project/db/custom.db")
rows = con.execute("SELECT id FROM Player WHERE refCode IS NULL").fetchall()
taken = {r[0] for r in con.execute("SELECT refCode FROM Player WHERE refCode IS NOT NULL")}
for (pid,) in rows:
    code = new_code()
    while code in taken:
        code = new_code()
    taken.add(code)
    con.execute("UPDATE Player SET refCode = ? WHERE id = ?", (code, pid))
    print(f"  {pid}: {code}")
con.commit()
print(f"done — {len(rows)} players got codes, total with codes:",
      con.execute("SELECT COUNT(*) FROM Player WHERE refCode IS NOT NULL").fetchone()[0])
