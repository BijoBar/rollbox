# VERIFY Task 56 — the waiting room is battle-shaped: one column per seat,
# square (future reel) on top + rectangle (picture + name) below, empty seats
# show "WAITING FOR PLAYER" — and a real DB avatar renders as the picture.
import json, subprocess, time
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
SHOTS = Path("/home/z/my-project/download/e2e-shots")
SHOTS.mkdir(parents=True, exist_ok=True)
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS  " if ok else "FAIL  ") + name + ("  — " + detail if detail else ""))

# clean world + mint one session + give the player a real avatar URL
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
out = subprocess.run(["bun", "scripts/mint-session.mjs"], capture_output=True, text=True, cwd="/home/z/my-project").stdout.strip().splitlines()
A = json.loads(out[0])
subprocess.run(
    ["bun", "-e",
     f"const {{PrismaClient}}=require('@prisma/client'); const db=new PrismaClient(); "
     f"(async()=>{{ await db.player.update({{ where:{{ id:'{A['id']}' }}, data:{{ avatar:'/logo.svg' }} }}); await db.$disconnect(); }})()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
print(f"session: A={A['name']}({A['id']}) avatar=/logo.svg")

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1440, "height": 1000})
    ctx.add_cookies([{"name": "rb_session", "value": A["token"], "url": BASE}])
    room = ctx.new_page()

    room.goto(BASE + "/battles/new", wait_until="domcontentloaded")
    room.wait_for_selector("button:has-text('Create Battle')", timeout=15000)
    room.get_by_role("button", name="Add a case to the battle").click(timeout=4000)
    room.wait_for_timeout(600)
    room.get_by_role("button", name="Add TEST, price $10").click(timeout=4000)
    room.wait_for_timeout(400)
    room.keyboard.press("Escape")
    for _ in range(10):  # wait until the picker dialog is fully gone
        if room.locator('[data-slot="dialog-overlay"][data-state="open"]').count() == 0:
            break
        room.wait_for_timeout(300)
        room.keyboard.press("Escape")
    room.wait_for_timeout(400)
    room.locator("button:has-text('Create Battle')").first.click(timeout=4000)

    deadline = time.time() + 20
    while time.time() < deadline:
        seg = room.url.rstrip("/").split("/")[-1]
        if seg != "new" and "/battles/" in room.url:
            break
        time.sleep(0.3)
    if room.url.rstrip("/").endswith("/new"):
        # hydration-proof fallback (same as the official suite): full-load the
        # newest waiting battle straight from the shared server list
        lst = ctx.request.get(BASE + "/api/gbattles").json().get("battles", [])
        if lst:
            room.goto(BASE + "/battles/" + lst[0]["id"], wait_until="domcontentloaded")
            room.wait_for_timeout(2500)
    check("navigated into room", "/battles/" in room.url and not room.url.endswith("/new"), room.url)
    room.wait_for_timeout(2500)  # poll + render

    body = room.inner_text("body")
    check("waiting title renders", "WAITING FOR PLAYERS" in body.upper())
    n_empty = body.count("WAITING FOR PLAYER") - body.count("WAITING FOR PLAYERS")
    check("empty square says WAITING FOR PLAYER (caps)", n_empty >= 1, f"empty squares={n_empty}")

    check("filled column shows the future-reel hint", "REEL — STARTS WHEN FULL" in body.upper())
    check("rectangle shows MY name under the picture", "E2E Alpha" in body)
    avatar_img = room.locator(".aspect-square ~ div img[src='/logo.svg'], div img[src='/logo.svg']").first
    check("REAL avatar picture renders in the rectangle", avatar_img.count() > 0 or room.locator("img[src='/logo.svg']").count() > 0)

    room.screenshot(path=str(SHOTS / "56-waiting-columns.png"))

    # fill the seat -> the battle starts on its own; the reel takes over the square
    try:
        room.locator("button:has-text('Call Bots')").first.click(timeout=5000)
        check("Call Bots pressed", True)
    except Exception as e:
        check("Call Bots pressed", False, str(e)[:120])

    started = False
    deadline = time.time() + 30
    while time.time() < deadline:
        if "ROLLING" in room.inner_text("body").upper() or room.locator("canvas, .rd-white-cover").count() > 0:
            started = True
            break
        time.sleep(0.5)
    if started:
        room.wait_for_timeout(1200)
        check("playing columns render with the avatar", room.locator("img[src='/logo.svg']").count() > 0)
        room.screenshot(path=str(SHOTS / "56-playing-columns.png"))
    else:
        check("playing columns render with the avatar", False, "battle never started rolling")

    deadline = time.time() + 120
    finished = False
    while time.time() < deadline:
        t = room.inner_text("body").upper()
        if "VICTORY" in t or "BATTLE LOST" in t or "FINISHED" in t:
            finished = True
            break
        time.sleep(1.0)
    check("battle reached a finished state", finished)

    browser.close()

# scrub the E2E battle + player afterwards
subprocess.run(
    ["bun", "-e", "const {PrismaClient}=require('@prisma/client'); const db=new PrismaClient(); "
     "(async()=>{ await db.battle.deleteMany({}); await db.drop.deleteMany({}); "
     "await db.player.deleteMany({where:{name:{startsWith:'E2E '}}}); await db.counter.updateMany({data:{value:0}}); await db.$disconnect(); })()"],
    capture_output=True, text=True, cwd="/home/z/my-project",
)
print("RESULT:", "ALL PASS" if all(r[1] for r in results) else "FAILURES")
