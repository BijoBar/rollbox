#!/usr/bin/env bash
# make-site-zip.sh — rebuild the ROLLBOX one-click site package (recreated in
# Task 167; the original was lost in the Sep-19 workspace rollback).
#
# Usage: scripts/make-site-zip.sh <version> <build-tag>
#   e.g.  scripts/make-site-zip.sh v32 R26
#
# Produces the three standing copies:
#   download/ROLLBOX-site.zip  public/ROLLBOX-site.zip  public/ROLLBOX-site-v<version>.zip
# and deletes every older public/ROLLBOX-site-v*.zip.
#
# Package content = exactly what a working checkout needs (the v31 package
# layout): project configs + db/ (custom.db + .auth-secret) + prisma/ +
# public/ (minus nested zips) + scripts/ + src/ — NO node_modules/.next/.git.
# .env is rewritten to a relative DATABASE_URL so the package runs anywhere.
set -euo pipefail

VERSION="${1:?usage: make-site-zip.sh <version> <build-tag>}"
TAG="${2:?usage: make-site-zip.sh <version> <build-tag>}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date -u +'%Y-%m-%d %H:%M:%S')"

cd "$ROOT"

# --- SANITY CHECKS (fail the build before a broken package ships) ---
grep -q 'price: 28.88' src/lib/cases.ts || {
  echo "SANITY FAIL: TEST case price 28.88 missing from src/lib/cases.ts — economy drift?"; exit 1; }
grep -q "BUILD_TAG = " src/lib/build-info.ts || {
  echo "SANITY FAIL: BUILD_TAG missing from src/lib/build-info.ts"; exit 1; }
grep -q "$TAG" src/lib/build-info.ts || {
  echo "SANITY FAIL: build-info.ts does not carry $TAG — bump it first."; exit 1; }
grep -q "/ROLLBOX-site-$VERSION.zip" src/app/layout.tsx || {
  echo "SANITY FAIL: layout.tsx anchor is not $VERSION — update it first."; exit 1; }

echo "stamp: $TAG ($VERSION) at $STAMP"
cat > VERSION.txt <<EOF
ROLLBOX SITE PACKAGE — BUILD STAMP
=================================
Built (UTC): $STAMP
Economy: Task-114 retune — RB-101..RB-120 + RB-TST (hidden); ROLLDROP 1.75% on EVERY case (R38), TEST case override 70% (direct link only)
Quick check after unzip: Asiimov Protocol \$4.04 / Fade Factory \$9.93 / TEST \$28.88 (direct link only)
On-site check: every page shows the R47 badge "INFINITE CORRIDOR · BUILD 2026-09-26 $TAG" (bottom-left).
No badge = you are running an OLD copy.
Wallet: C7 Phase 1 — real USDT (TRC-20) deposits & payouts, admin-reviewed (/wallet + admin WALLET tab).
Events: EMERALD DROP — limited event case + wager-race board, top-5 prizes (/event), community & event cases playable in battles.
Task 167: admin TOTP 2FA + audit trail, giveaways (/giveaways), broadcast banner + case stats (admin TOOLS), full history (/profile/history), RB-TST hidden from public listings.
Task 168: header cleanup — one GAMES dropdown (Case Battles, Upgrader, Events, Terminal), CASES link removed, larger 2xl logo, GIVEAWAYS back in the top bar.
Task 169: battle fix — entering/re-entering a battle in its final beat (or waking a backgrounded tab) no longer freezes on "Get ready" with drops revealed: the clock clamps to the last round and replays its reel.
Task 170: backgrounds — the corridor no longer draws the ROLLBOX floor wordmark or the wall logo signs; the home, /upgrader and /battles pages wear their uploaded artworks (rollboxbackground/rollboxupgrader/rollboxcasebattle.jpg) as 50%-opacity fixed backdrops over the corridor.
Task 172: server-time battle reels — every reel is wall-clock seekable (startAtMs = battle start + slot + poll offset), the tab-wake resync no longer wipes the reveal state (that was the visible ALT-TAB reel reset), and a mid-battle reload mounts the reel at the exact server-true position. Reels can never reset or replay from zero on wake.
Task 173: true-first-paint reels — a reel mounted already deep into its schedule (the frozen keep-reel at every round flip, a wake remount, a mid-battle reload of an elapsed spin) no longer flashes the strip head for a frame: locked/tension boot from the wall clock during the first render and a pre-paint layout effect seeks the strip to the exact server-true frame and fires its lock exactly once. Forensic probe (scripts/e2e-t172-debug3.sh) proved every seat locks on its own schedule; the E2E detector now reads spunPastSchedule=0 strictly.
Task 171: default backdrop — rollboxbackground.jpg now rides EVERY page at 50% opacity (root layout); /upgrader, /battles (+ battle rooms) keep their own artwork, /event keeps event-bg, /terminal keeps its own full-screen background.
Task 174: UPGRADER rebuilt as a reactor core — layered counter-rotating tick rings, gradient glow chance-arc that morphs with the multiplier, shockwave rings + glitch sting, animated numbers everywhere, risk-colored charge cells with live chance meters, charge-bar spin button, provably-fair link. Same server-side provably-fair game, aim math, hold semantics and API contract.
R37 (Tasks 175-178): flat 5% ROLLDROP on every case · idle reel caption deleted · FAST battles breathe (wait-for-all pad + exactly 1s between rounds) · the upgrader spins with a round-long sound that ends at the verdict · Potential upgrade resets on a fresh pick · YOUR STAKE holds through the game and becomes the won skin · wheel confetti deleted.
Task 180: DOWNLOAD DATA — the package download asks for the owner's password first; a permanently banned player can now sign IN and meets an honest full-screen PERMANENTLY BANNED shield (every action route still refuses them server-side).
R39 (Task 181): FAST battles = x2.5 the normal reel speed (2560ms, never skipped) · "Reel — starts when full" deleted · the battle case strip shows the ROUND NUMBER on every box (the active one reads "Round X/Y") · ROLLDROP retuned to 1.75% everywhere with the TEST case back at 70% · the rolldrop sound can no longer loop through the bonus reel · the upgrader stake cap raised to \$1000 · the Potential upgrade image holds through the whole spin · a WIN auto-stakes the won skin into the picker · a LOSS dissolves the staked skins in smoke.
R40 (Task 182): FAST MODE DELETED from battles entirely — no toggle on the create screen, no ⚡ badges, no fast field anywhere in the API; every battle plays the normal case-style pacing (6400ms reels, 250ms round breather). The rolldrop sound loop is now IMPOSSIBLE: the sound engine gained a hard leash (any whoosh dies by itself at most 16s after its last energy push) plus unconditional killLoops() fired at the rolldrop hit and at the bonus-reel start — after a hit, zero looping layers exist until the sequence ends. Round-number chips and the deleted waiting caption stay. If a downloaded copy still shows Fast mode or still drones, it is a STALE CACHE: re-download this package (or hard-refresh Ctrl+Shift+R).
R41 (Task 183): FREE CASES — admins can gift free boxes to any player (admin panel → player overlay → GIFT FREE CASES); the DB keeps the exact per-player, per-case quantity (Player.freeCases) and every case a player owns free shows a green FREE ×N chip next to its name on the home cards and the case page (no free boxes = plain name, no chip). Opening a case burns the player's free units FIRST — the paid charge only covers the remainder, so a fully-covered open costs NOTHING (even at zero balance). Every completed mission now pays ONE FREE RB-106 (Doppler Realm) automatically — the board's Reward chip flips to CLAIMED. Registration grants NO money at all: a new account starts at balance 0 and must deposit (the old \$5 first-login bonus is gone).
R42 (Task 184): the missions board reads "FREE Doppler Realm Case" (the case's real name, not the RB-106 code) everywhere — the intro line, every Reward chip and the claim toast. "Special for you" on the home page now ALSO carries every GIFTED free case the player owns — full case cards with their FREE ×N chip under a "YOUR FREE CASES" caption, static AND player-built community boxes, appearing the moment a gift lands and disappearing when the last box burns (no free boxes → the block is simply not there). The EXCHANGE now lists BOTH site Steam accounts — bijobarmain AND BijoBarStg — merged into one shelf by the same 5-minute sync (all-or-nothing: a failed read on either account freezes the list instead of falsely unlisting it). The upgrader's spin button now reads UPGRADING… (was CHARGING…) and the thin loading bar that crawled under the label until the verdict is DELETED.
R43 (Task 186): WEAPON CONDITION everywhere — every skin on the whole site (battles, cases, upgrader, exchange, terminal, inventory, history) lists its exterior IN ITS OWN COLOR: Factory New #48ff00 / Minimal Wear #ddff00 / Field-Tested #ffe600 / Well Worn #ff9100 / Battle-Scarred #ff3300; no skin renders without a condition (default Field-Tested). R44 (Task 187): LIVE DROPS spells the condition in FULL words ("MW" reads "Minimal Wear"). R44b/R44c (Task 188): all designed case artwork was REMOVED at the owner's request — every case renders the procedural neon-crate art again, and THIS PACKAGE SHIPS ZERO CASE IMAGES (public/cases is empty pending new owner-supplied artwork).
R44d (Task 191): PACKAGE SLIMMED — QA screenshots, stale catalog backups, dead media (rollboxcoin images, raredrop-classic, the duplicate hyphenated rarity set, rolldrop.mp4 + rolldrop-hit.webm, logo.svg) and the build-tool DBs (scripts/skins-db.json, stickers-db.json, csgotm-prices.json — catalog REBUILD inputs only; the site serves public/skins-catalog.json and needs none of them) no longer travel in the package. Nothing the runtime touches was removed.
R45 (Task 194): TEAM ART SWAPPED — the owner's new CT + T emblems (silver/blue pliers-and-wings = CT, bronze/orange crossed-knives-and-star = T) now serve as public/teams/{ct,t}.webp, converted to 512x512 RGBA transparent webp. Delivered via postimages direct links after the upload channel stayed dead.
R46 (Task 195): 2v2 TEAM PICK — after CREATE BATTLE in 2v2 the creator chooses the side first: a CHOOSE YOUR TEAM dialog with the CT and T emblems (team-colored glow cards); the pick rides the create API (team: 0|1) and the host takes the LEFT seat of the chosen team. 1v1/1v1v1/1v1v1v1 keep the one-click create.
R47 (Task 196): BATTLES UPDATE x4 — (1) PLAY WITH BOTS toggle on the create screen (red OFF / green ON, like CRAZY MODE and PRIVATE): a battle created with it ON fills EVERY empty seat with [RBbot] bots the moment it opens and rolls immediately. (2) The waiting-room caption "Play with bots — every player must press Call Bots" is DELETED completely. (3) LEAVE BATTLE never kills a room anymore — the host walks out like anyone else (seat opens, entry refunds) and the room STAYS in the battles list, empty or with the remaining players, ready for anyone to join and play it with bots or other players. (4) The lobby search filters (max entry / custom budget / favorites-only) are DELETED and replaced by MODE chips with the emoji next to every name — STANDARD ✊, CRAZYMODE 😵‍💫, SHARED 🤝, JACKPOT 🎲 — plus the players row written exactly as "Players : 2, 3, 4, 2vs2" (2=1v1, 3=1v1v1, 4=1v1v1v1, 2VS2=teams).
Continuity: this package carries worklog.md at its root — the COMPLETE task-by-task development history (~192 tasks). A new agent continuing from this package MUST read worklog.md first and append to it (next Task ID = 192).
EOF

# --- stage the package tree ---
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/ROLLBOX"

cp -R src prisma public scripts db "$STAGE/ROLLBOX/"
cp package.json bun.lock tsconfig.json next.config.ts tailwind.config.ts postcss.config.mjs \
   eslint.config.mjs components.json next-env.d.ts README-HE.md .gitignore worklog.md "$STAGE/ROLLBOX/"
printf 'DATABASE_URL=file:../db/custom.db\n' > "$STAGE/ROLLBOX/.env"
cp VERSION.txt "$STAGE/ROLLBOX/VERSION.txt"

# nested zips never travel inside the package; junk markers stay out too
# Task 190: the owner's case-art archive (RB-case-images-archive.zip) lives in
# public/ ONLY for the download link — it must NEVER travel inside a package.
rm -f "$STAGE/ROLLBOX/public/ROLLBOX-site"*.zip \
      "$STAGE/ROLLBOX/public/RB-case-images-archive.zip"
# Task 191: build-tool DBs stay in the dev workspace only — the site runs on
# public/skins-catalog.json (untouched); these are its REBUILD INPUTS (~28MB).
rm -f "$STAGE/ROLLBOX/scripts/stickers-db.json" \
      "$STAGE/ROLLBOX/scripts/skins-db.json" \
      "$STAGE/ROLLBOX/scripts/csgotm-prices.json"

# --- zip it ---
mkdir -p download
( cd "$STAGE" && zip -qr -X "$STAGE/ROLLBOX-site-$VERSION.zip" ROLLBOX )
cp "$STAGE/ROLLBOX-site-$VERSION.zip" download/ROLLBOX-site.zip
cp "$STAGE/ROLLBOX-site-$VERSION.zip" public/ROLLBOX-site.zip
cp "$STAGE/ROLLBOX-site-$VERSION.zip" "public/ROLLBOX-site-$VERSION.zip"

# --- retire older versioned copies ---
for old in public/ROLLBOX-site-v*.zip; do
  [ "$old" = "public/ROLLBOX-site-$VERSION.zip" ] && continue
  rm -f "$old"
done

md5sum download/ROLLBOX-site.zip public/ROLLBOX-site.zip "public/ROLLBOX-site-$VERSION.zip"
echo "done: ROLLBOX-site-$VERSION.zip ($TAG)"
