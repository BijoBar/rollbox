// Task 184 — EXCHANGE two-account check: the served catalog must contain
// assets from BOTH Steam accounts (bijobarmain + BijoBarStg), verified
// against the LIVE inventory assetid sets.
import { getStock } from "../src/lib/server/steam-stock";

const view = await getStock({ forceSync: true });
const have = new Set(view.items.map((i) => i.assetid));

const live = async (id64: string): Promise<string[]> => {
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch("https://steamcommunity.com/inventory/" + id64 + "/730/2?l=english&count=2000", {
        headers: { "User-Agent": "Mozilla/5.0" },
        signal: AbortSignal.timeout(15000),
      });
      const d = (await r.json()) as { assets?: { assetid: string }[] } | null;
      if (d && Array.isArray(d.assets)) return d.assets.map((a) => a.assetid);
      // Steam serves a literal `null` body when throttled — back off and retry
      await new Promise((res) => setTimeout(res, 3000));
    } catch {
      await new Promise((res) => setTimeout(res, 2000));
    }
  }
  return [];
};

const a1 = await live("76561199844753068"); // bijobarmain
await new Promise((r) => setTimeout(r, 1200));
const a2 = await live("76561199379772748"); // BijoBarStg
const from1 = a1.filter((id) => have.has(id));
const from2 = a2.filter((id) => have.has(id));
console.log(
  JSON.stringify({
    ok: view.ok,
    count: view.items.length,
    acct1Live: a1.length,
    acct1Served: from1.length,
    acct2Live: a2.length,
    acct2Served: from2.length,
    err: view.error ?? null,
  }),
);
process.exit(0);
