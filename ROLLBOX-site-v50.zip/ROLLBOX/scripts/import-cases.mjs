#!/usr/bin/env node
// ============ import-cases.mjs (Task 95) ============
// Reads the DROP EDITOR export (the txt the user copies/downloads) and lands
// the "ROLLBOX-CASES v1" section into src/lib/user-cases.ts — the overlay the
// site merges OVER the generated cases (src/lib/cases.ts, by case code).
// ROLLBOX-DAILY v1 lines belong to scripts/import-dailies.mjs and
// ROLLBOX-TERMINALS v1 lines to scripts/import-terminals.mjs — both are
// ignored here with a count.
//
// Each case line carries { code, name, price, items: [{ n, v, p, id?, w? }] }
// where p is the drop percent (sums to 100), v the coin value the item pays
// and w the CS2 exterior (FN/MW/FT/WW/BS). A case line REPLACES that case's
// user overlay entry wholesale (name/price/items); its shell (id, subtitle,
// kind, tier label, colors) is preserved from scripts/drop-editor-base.json —
// regenerate that file with `bun scripts/build-drop-editor.mjs` after content
// rebuilds.
//
// Items WITHOUT a catalog id are free-text: the name is matched against the
// catalog (case-insensitive); a truly new name gets a synthesized USER_SKINS
// entry (slug id + guessed weapon/rarity) so the site can render it.
//
// Usage:  node scripts/import-cases.mjs rollbox-drop.txt
//         cat rollbox-drop.txt | node scripts/import-cases.mjs

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const BASE = path.join(ROOT, "scripts", "drop-editor-base.json");
const OUT = path.join(ROOT, "src", "lib", "user-cases.ts");

const raw = (process.argv[2] ? fs.readFileSync(process.argv[2], "utf8") : fs.readFileSync(0, "utf8")).trim();
if (!fs.existsSync(BASE)) {
  console.error("scripts/drop-editor-base.json not found — run `bun scripts/build-drop-editor.mjs` first.");
  process.exit(1);
}
const base = JSON.parse(fs.readFileSync(BASE, "utf8"));
const baseByCode = new Map(base.cases.map((c) => [c.code, c]));
const catalogById = new Map(Object.entries(base.skins));
// base.skins values are {n, v, r} — the id is the object's KEY, so map name -> key
const catalogByName = new Map([...catalogById.entries()].map(([id, s]) => [s.n.toLowerCase(), id]));

// ---- split the export into its sections ----
const caseLines = [];
let section = null;
const counts = { cases: 0, dailies: 0, terminals: 0, skipped: 0 };
for (const line of raw.split("\n")) {
  const s = line.trim();
  if (!s) continue;
  if (s === "ROLLBOX-CASES v1") { section = "cases"; continue; }
  if (s === "ROLLBOX-DAILY v1") { section = "dailies"; continue; }
  if (s === "ROLLBOX-TERMINALS v1") { section = "terminals"; continue; }
  let obj;
  try {
    obj = JSON.parse(s);
  } catch {
    counts.skipped++;
    continue;
  }
  if (section === "cases" && obj && Array.isArray(obj.items)) caseLines.push(obj);
  else if (section === "dailies" && obj && Array.isArray(obj.items)) counts.dailies++;
  else if (section === "terminals" && obj && Array.isArray(obj.skins)) counts.terminals++;
  else counts.skipped++;
}

if (caseLines.length === 0) {
  console.error("No case lines found in the export (looked for the ROLLBOX-CASES v1 section).");
  console.error(`(daily lines ignored: ${counts.dailies}, terminal lines ignored: ${counts.terminals}, unparsed: ${counts.skipped})`);
  process.exit(1);
}

// ---- validation ----
const WEAR_IDS = new Set(["FN", "MW", "FT", "WW", "BS"]);
const problems = [];
const seen = new Set();
for (const c of caseLines) {
  const tag = c.code ?? "(no code)";
  if (!c.code || !baseByCode.has(String(c.code))) {
    problems.push(`${tag}: unknown case code (the editor only knows the site's own cases: RB-101…RB-120, RB-201…RB-210, RB-TST)`);
    continue;
  }
  if (seen.has(String(c.code))) problems.push(`${tag}: duplicate case`);
  seen.add(String(c.code));
  if (!Array.isArray(c.items) || c.items.length < 2) problems.push(`${tag}: a case needs at least 2 skins`);
  const sum = (c.items ?? []).reduce((acc, k) => acc + (+k.p || 0), 0);
  if (Math.abs(sum - 100) > 0.05) problems.push(`${tag}: chances sum to ${sum.toFixed(4)}, not 100`);
  for (const k of c.items ?? []) {
    if (!(+k.v >= 0) || !Number.isFinite(+k.v)) problems.push(`${tag}: skin "${k.n}" has value ${k.v}`);
    if (!(+k.p >= 0)) problems.push(`${tag}: skin "${k.n}" has chance ${k.p}`);
    if (k.w != null && !WEAR_IDS.has(k.w)) problems.push(`${tag}: skin "${k.n}" has unknown exterior "${k.w}" (use FN/MW/FT/WW/BS)`);
  }
}
if (problems.length) {
  console.error("EXPORT HAS PROBLEMS — fix these in the editor first:");
  for (const p of problems) console.error("  • " + p);
  process.exit(1);
}

// ---- free-text skins: match by name, else synthesize a USER_SKINS entry ----
const RARITY_COLOR = { consumer: "#b0c3d9", milspec: "#4b69ff", restricted: "#8847ff", classified: "#d32ce6", covert: "#eb4b4b", contraband: "#ffd700" };
const slugify = (n) => n.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "custom-skin";
const guessWeapon = (n) => {
  const s = n.toLowerCase();
  if (s.startsWith("sticker |") || s.startsWith("sticker ")) return "sticker";
  if (s.startsWith("patch |") || s.startsWith("patch ")) return "patch";
  if (s.startsWith("charm |") || s.startsWith("charm ")) return "charm";
  if (s.includes("gloves")) return "gloves";
  if (s.includes("★")) return "karambit";
  if (s.includes("agent") || s.includes(" | ") && /crew|squad|badge|heir| SWAT| FBI| IDF|CT|T\b/.test(s)) return "agent";
  return "ak";
};
const guessRarity = (v) => (v >= 500 ? "contraband" : v >= 100 ? "covert" : v >= 30 ? "classified" : v >= 8 ? "restricted" : v >= 2 ? "milspec" : "consumer");

const newSkins = []; // synthesized USER_SKINS entries
const resolvedItems = new Map(); // code -> items [{skinId, weight, value, wear?}]
for (const c of caseLines) {
  const items = c.items.map((k) => {
    let skinId = k.id ? String(k.id) : null;
    if (!skinId && k.n) {
      const hit = catalogByName.get(String(k.n).trim().toLowerCase());
      if (hit) skinId = hit;
    }
    if (!skinId) {
      const name = String(k.n).trim() || "Custom Skin";
      let id = slugify(name);
      while (catalogById.has(id) || newSkins.some((s) => s.id === id)) id = id.replace(/-\d+$/, "") + "-2";
      const value = Math.round((+k.v || 0) * 100) / 100;
      const rarity = guessRarity(value);
      newSkins.push({ id, name, weapon: guessWeapon(name), rarity, value, color: RARITY_COLOR[rarity] });
      catalogById.set(id, { n: name, v: value, r: rarity });
      catalogByName.set(name.toLowerCase(), id);
      skinId = id;
    }
    const item = { skinId, weight: Math.round((+k.p || 0) * 1e6) / 1e6, value: Math.round((+k.v || 0) * 1e6) / 1e6 };
    if (k.w) item.wear = k.w;
    return item;
  });
  resolvedItems.set(String(c.code), items);
}

// ---- build the new USER_CASES overlay (export content + preserved shells) ----
const overlayCodes = new Set([...base.cases.filter((c) => c.userOverlay).map((c) => c.code), ...resolvedItems.keys()]);
const userCases = [];
for (const b of base.cases) {
  if (!overlayCodes.has(b.code)) continue;
  const exp = caseLines.find((c) => String(c.code) === b.code);
  const items = exp ? resolvedItems.get(b.code) : b.items.map((it) => {
    const item = { skinId: it.id, weight: it.p, value: it.v ?? undefined };
    if (item.value == null) delete item.value;
    if (it.w) item.wear = it.w;
    return item;
  });
  userCases.push({
    id: b.id,
    code: b.code,
    name: exp ? String(exp.name).trim() || b.name : b.name,
    subtitle: b.subtitle,
    kind: b.kind,
    tierLabel: b.tierLabel,
    price: exp ? Math.max(0, +exp.price || 0) : b.price,
    tierColor: b.tierColor,
    tierColor2: b.tierColor2,
    items,
  });
}
// stable code order (RB-101.. before RB-2xx, RB-TST last — same as the site)
const codeNum = (code) => {
  const m = /^RB-(\d+)$/.exec(code);
  return m ? Number(m[1]) : Number.MAX_SAFE_INTEGER;
};
userCases.sort((a, b) => codeNum(a.code) - codeNum(b.code));

// ---- USER_ITEM_VALUES: regenerate from the final overlay items ----
const itemValues = {};
for (const c of userCases) {
  for (const it of c.items) {
    itemValues[`${it.skinId}|${it.wear ?? ""}`] = it.value ?? 0;
  }
}

// ---- emit the new user-cases.ts (surgical block replacement) ----
let ts = fs.readFileSync(OUT, "utf8");

// 1) append synthesized USER_SKINS entries just before the block's closing };
if (newSkins.length) {
  const start = ts.indexOf("export const USER_SKINS:");
  if (start === -1) {
    console.error("user-cases.ts: USER_SKINS block not found — cannot add new skins.");
    process.exit(1);
  }
  const close = ts.indexOf("\n};", start);
  const additions = newSkins
    .map((s) => `  ${JSON.stringify(s.id)}: { id: ${JSON.stringify(s.id)}, name: ${JSON.stringify(s.name)}, weapon: ${JSON.stringify(s.weapon)} as WeaponKind, rarity: ${JSON.stringify(s.rarity)} as Rarity, value: ${s.value}, colors: [${JSON.stringify(s.color)}, "#14101f"] },`)
    .join("\n");
  ts = ts.slice(0, close) + "\n" + additions + ts.slice(close);
}

// 2) replace the USER_ITEM_VALUES block
{
  const start = ts.indexOf("export const USER_ITEM_VALUES:");
  if (start === -1) {
    console.error("user-cases.ts: USER_ITEM_VALUES block not found.");
    process.exit(1);
  }
  const close = ts.indexOf("\n};", start) + "\n};".length;
  const block =
    "export const USER_ITEM_VALUES: Record<string, number> = " +
    JSON.stringify(itemValues, null, 2) + ";";
  ts = ts.slice(0, start) + block + ts.slice(close);
}

// 3) replace the USER_CASES block (the last export in the file) wholesale
{
  const start = ts.indexOf("export const USER_CASES:");
  if (start === -1) {
    console.error("user-cases.ts: USER_CASES block not found.");
    process.exit(1);
  }
  const body = userCases
    .map((c) => {
      const items = c.items
        .map((it) => {
          const parts = [`skinId: ${JSON.stringify(it.skinId)}`, `weight: ${it.weight}`, `value: ${it.value}`];
          if (it.wear) parts.push(`wear: ${JSON.stringify(it.wear)}`);
          return "      { " + parts.join(", ") + " },";
        })
        .join("\n");
      return [
        "  {",
        `    id: ${JSON.stringify(c.id)},`,
        `    code: ${JSON.stringify(c.code)},`,
        `    name: ${JSON.stringify(c.name)},`,
        `    subtitle: ${JSON.stringify(c.subtitle)},`,
        `    kind: ${JSON.stringify(c.kind)},`,
        `    tierLabel: ${JSON.stringify(c.tierLabel)},`,
        `    price: ${c.price},`,
        `    tierColor: ${JSON.stringify(c.tierColor)},`,
        `    tierColor2: ${JSON.stringify(c.tierColor2)},`,
        "    items: [",
        items,
        "    ],",
        "  },",
      ].join("\n");
    })
    .join("\n");
  const block = `// ============ USER CASES — the DROP EDITOR overlay ============
// Re-written by scripts/import-cases.mjs on ${new Date().toISOString().slice(0, 10)} from the
// DROP EDITOR's ROLLBOX-CASES v1 export (percent + value + exterior per skin).
// Each entry here REPLACES the generated case of the same code
// (src/lib/generated-cases.ts / the TEST case) when src/lib/cases.ts merges.

export const USER_CASES: CaseDef[] = [
${body}
];
`;
  ts = ts.slice(0, start) + block;
}

fs.writeFileSync(OUT, ts);

const touched = [...resolvedItems.keys()];
console.log(`OK — wrote src/lib/user-cases.ts with ${userCases.length} case overlay(s); ${touched.length} updated from the export:`);
for (const code of touched) {
  const c = userCases.find((x) => x.code === code);
  console.log(`  • ${code} — ${c.name} (price ${c.price}, ${c.items.length} skins)`);
}
if (newSkins.length) console.log(`  + ${newSkins.length} new catalog skin(s) synthesized: ${newSkins.map((s) => s.id).join(", ")}`);
console.log(`(daily lines ignored: ${counts.dailies}, terminal lines ignored: ${counts.terminals}, unparsed: ${counts.skipped})`);
