#!/usr/bin/env bash
# Task 43 E2E — part 2: case picker (RollBox Official / Farm sections,
# automatic expensive→cheap order, VIEW DROPS still present).
set -u
AB="agent-browser"
D="/home/z/my-project/download"

echo "=== open picker ==="
$AB eval '(() => { const b = [...document.querySelectorAll("button")].find(x => x.textContent.trim() === "Add Case"); b?.click(); return b ? "opened" : "NOT FOUND"; })()' 2>/dev/null | tail -1
sleep 1.5

echo "=== sections + order ==="
$AB eval '(() => {
  const dlg = document.querySelector("[role=\"dialog\"]");
  if (!dlg) return JSON.stringify({err: "no dialog"});
  const t = dlg.textContent;
  const headers = [...dlg.querySelectorAll("h4")].map(h => h.textContent.trim());
  // first case tile price in each section
  const sec = [...dlg.querySelectorAll("h4")].map(h => {
    let el = h.parentElement; // header row
    let grid = null, n = 0;
    while (el && el !== dlg) { el = el.nextElementSibling || el.parentElement?.nextElementSibling; if (!el) break; if (el.querySelector("button[aria-label^=\"Add\"]")) { grid = el; break; } }
    return h.textContent.trim();
  });
  const prices = [...dlg.querySelectorAll("button[aria-label^=\"Add\"]")].slice(0, 30).map(b => {
    const m = b.getAttribute("aria-label").match(/price $([0-9.]+)/);
    return m ? parseFloat(m[1]) : null;
  });
  // find where farm section starts by locating the SECOND h4 grid
  return JSON.stringify({ headers, first6prices: prices.slice(0, 6), farmHeader: t.includes("Farm Cases"), officialHeader: t.includes("RollBox Official"), viewDrops: !!dlg.querySelector("span[aria-label^=\"View the drops\"]") });
})()' 2>/dev/null | tail -1

echo "=== per-section order probe ==="
$AB eval '(() => {
  const dlg = document.querySelector("[role=\"dialog\"]");
  const h4s = [...dlg.querySelectorAll("h4")];
  const out = {};
  for (const h of h4s) {
    // the grid is the next sibling of the header row inside the section div
    const section = h.closest("div > div")?.parentElement || h.parentElement.parentElement;
    let grid = h.parentElement.nextElementSibling;
    while (grid && !grid.querySelector("button[aria-label^=\"Add\"]")) grid = grid.nextElementSibling;
    if (!grid) { out[h.textContent.trim()] = "grid?"; continue; }
    const prices = [...grid.querySelectorAll("button[aria-label^=\"Add\"]")].map(b => parseFloat(b.getAttribute("aria-label").match(/price $([0-9.]+)/)?.[1] ?? "0"));
    const desc = prices.every((p, i) => i === 0 || prices[i-1] >= p);
    out[h.textContent.trim()] = { n: prices.length, first: prices[0], last: prices[prices.length-1], desc };
  }
  return JSON.stringify(out);
})()' 2>/dev/null | tail -1
$AB screenshot "$D/task43-picker-sections.png" >/dev/null 2>&1