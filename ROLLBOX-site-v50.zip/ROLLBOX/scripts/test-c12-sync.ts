// C12 E2E support: simulate a Steam re-login for p_t66A through the REAL
// upsertPlayer path and prove the custom identity survives it.
import { upsertPlayer } from "../src/lib/server/auth";

async function main() {
  const before = await prismaSnapshot();
  console.log("BEFORE LOGIN-SYNC:", JSON.stringify(before));
  // The Steam persona arrives DIFFERENT from the custom nickname:
  const p = await upsertPlayer("steam", "t66-A-steamid", "Brand New Steam Name", null);
  console.log(
    "AFTER LOGIN-SYNC:",
    JSON.stringify({ name: p.name, nameCustom: p.nameCustom, steamName: p.steamName }),
  );
  if (p.name !== "RB Tester") throw new Error("FAIL: custom name was clobbered by the Steam sync");
  if (p.steamName !== "Brand New Steam Name") throw new Error("FAIL: steam persona not snapshotted");
  console.log("SYNC-OVERRIDE VERIFIED: nickname survived, Steam persona snapshotted");
  await prisma.$disconnect();
}

async function prismaSnapshot() {
  const p = await prisma.player.findUnique({
    where: { id: "p_t66A" },
    select: { name: true, nameCustom: true, steamName: true },
  });
  return p;
}

import { db as prisma } from "../src/lib/db";
main().catch((e) => {
  console.error("E2E-SYNC-TEST FAILED:", e.message);
  process.exit(1);
});
