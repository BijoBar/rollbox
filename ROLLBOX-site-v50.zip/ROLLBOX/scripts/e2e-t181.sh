#!/usr/bin/env bash
# e2e-t181.sh — R38 batch E2E (user's 7 fixes) — v2
# Covers: FAST battles = x2.5 the normal reel (2560ms, stagger 0, 1s beat) ·
# "Reel — starts when full" deleted · round-number chips on the case strip ·
# rolldrop flat 1.75% + the TEST case override 70% · the rolldrop sound-loop
# bug (no looping audio layer may live between the hit and the bonus reel's
# end) · upgrader cap $1000 · the Potential upgrade image HOLDS through the
# whole spin · WIN auto-stakes the won skin · LOSS dissolves the stake in
# smoke.
# LESSONS (t175..t181): agent-browser eval returns JSON-QUOTED strings —
# never exact-compare, always rg; session cookie BEFORE opening a gated page;
# aria-pressed="false" is truthy AND multiplier buttons carry it too — filter
# Stake buttons by aria-label; ONE page open per probe (a second open WIPES
# the patch); `loop`/`start`/`stop` live on EITHER prototype depending on the
# Chrome build — resolve the owner at install time.
set -uo pipefail
cd /home/z/my-project
AB="agent-browser"
SHOT="scripts/e2e-t181"
BASE="http://localhost:3000"

ok() { echo "PASS — $1"; }
fail() { echo "FAIL — $1"; FAILED=1; }
FAILED=0
check() { $AB eval "$1" 2>/dev/null | rg -o "true|false" | head -1; }
jhas() { echo "$1" | sed 's/\\//g' | rg -q "$2"; }

TOKEN="$(bun scripts/mint-e2e-session.ts 2>/dev/null | sed -E 's/.*"token":"([^"]+)".*/\1/')"

# ============================================================ STAGE 0 (module)
mod=$(bun -e "const m = await import('/home/z/my-project/src/lib/rolldrop.ts'); const g = await import('/home/z/my-project/src/lib/gbattle-shared.ts'); const c = await import('/home/z/my-project/src/lib/cases.ts'); const tst = c.CASES.find(x=>x.id==='test-rolldrop'); console.log('rd', m.ROLLDROP_CHANCE, m.rolldropChanceOf({ items: [] }), m.rolldropChanceOf(tst), 'fast', g.REEL_YOU_MS_FAST, g.REEL_OTHER_MS_FAST, g.REEL_STAGGER_MS_FAST, g.ROUND_BEAT_MS_FAST);" 2>/dev/null | tail -1)
echo "module check: $mod"
jhas "$mod" "rd 0\.0175 0\.0175 0\.7" && ok "module: rolldrop flat 1.75% + TEST override 70%" || fail "module: rolldrop values ($mod)"
jhas "$mod" "fast 2560 2560 0 1000" && ok "module: FAST reels 2560ms (= 6400/2.5) stagger 0, beat 1s" || fail "module: fast constants ($mod)"

# ============================================================ STAGE A (guest)
$AB close >/dev/null 2>&1 || true
sleep 1
$AB cookies clear >/dev/null 2>&1 || true
$AB storage local clear >/dev/null 2>&1 || true
$AB storage local set rb-rolldrop-force 1 >/dev/null 2>&1
$AB open "$BASE/case/test-rolldrop" >/dev/null
sleep 3.5

# 1. ROLLDROP SOUND-LOOP probe — resolve the descriptor owners at install time
probe=$($AB eval '(() => { if (window.__audioProbe) return "probe-installed"; const dp = AudioBufferSourceNode.prototype; const db = (typeof AudioScheduledSourceNode !== "undefined") ? AudioScheduledSourceNode.prototype : dp; const loopOwner = Object.getOwnPropertyDescriptor(dp, "loop") ? dp : db; const loopD = Object.getOwnPropertyDescriptor(loopOwner, "loop"); const startOwner = Object.getOwnPropertyDescriptor(dp, "start") ? dp : db; const stopOwner = Object.getOwnPropertyDescriptor(dp, "stop") ? dp : db; const stD = Object.getOwnPropertyDescriptor(startOwner, "start"); const spD = Object.getOwnPropertyDescriptor(stopOwner, "stop"); if (!loopD || !stD || !spD) return "probe-descriptor-missing"; window.__audioProbe = true; window.__loopSrcs = new Set(); Object.defineProperty(loopOwner, "loop", { get() { return loopD.get.call(this); }, set(v) { if (v) window.__loopSrcs.add(this); loopD.set.call(this, v); } }); Object.defineProperty(startOwner, "start", { value(...a) { this.__started = true; if (this.loop) window.__loopSrcs.add(this); return stD.value.apply(this, a); } }); Object.defineProperty(stopOwner, "stop", { value(...a) { this.__stopped = true; return spD.value.apply(this, a); } }); return "probe-installed"; })()' 2>/dev/null)
jhas "$probe" "probe-installed" && ok "case: audio loop probe installed" || fail "case: probe ($probe)"
selftest=$($AB eval '(() => { const c = new (window.AudioContext||window.webkitAudioContext)(); const s = c.createBufferSource(); s.loop = true; s.start(); const out = JSON.stringify({ inSet: window.__loopSrcs.has(s) }); try { s.stop(); } catch {} c.close(); return out; })()' 2>/dev/null | sed 's/\\//g' | tail -1)
jhas "$selftest" '"inSet":true' && ok "case: probe self-test — a live loop IS counted" || fail "case: probe self-test ($selftest)"

# the ROUND-LONG sampler: every 150ms record {t, alive} + watch for the
# raredrop marker img — the rolldrop bug signature is a loop ALIVE again
# AFTER the main whoosh died (the hit → bonus-reel window)
$AB eval '(() => { window.__samples = []; window.__s0 = 0; window.__rareSeen = false; window.__sampler = setInterval(() => { if (!window.__s0) window.__s0 = Date.now(); const alive = [...(window.__loopSrcs||[])].filter((s)=>s.__started&&s.loop&&!s.__stopped).length; window.__samples.push({ t: Date.now()-window.__s0, alive }); if (document.querySelector("img[src*=raredrop]")) window.__rareSeen = true; }, 150); return "sampler-on"; })()' >/dev/null 2>&1

# 2. the forced ROLLDROP flow at the new rate — the OPEN is an IN-PAGE click
# (t181 lesson: a second $AB open would WIPE the probe + sampler)
$AB find first "button.neon-btn" click >/dev/null 2>&1
echo "waiting out the full rolldrop sequence (~20s)..."
sleep 20
rd=$($AB eval "(() => { const t = document.body.innerText; return JSON.stringify({ rareSeen: window.__rareSeen === true, revealed: /total won|open again/i.test(t) }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "rolldrop flow: $rd"
jhas "$rd" '"rareSeen":true' && ok "rolldrop: forced flow alive — raredrop marker + bonus reel" || fail "rolldrop: forced flow broke ($rd)"

# 3. THE LOOP VERDICT — after the main whoosh first dies, no loop may EVER
# come back alive (the old bug: a loop droned from the hit to the bonus end)
loopverdict=$($AB eval '(() => { const s = window.__samples || []; let sawLoop = false, died = false, reborn = -1; for (const x of s) { if (x.alive > 0) sawLoop = true; else if (sawLoop) died = true; if (died && x.alive > 0 && reborn < 0) reborn = x.t; } return JSON.stringify({ samples: s.length, sawLoop, died, rebornAtMs: reborn }); })()' 2>/dev/null | sed 's/\\//g' | tail -1)
echo "loop verdict: $loopverdict"
jhas "$loopverdict" '"samples":[1-9]' || fail "loop probe: sampler never ran ($loopverdict)"
jhas "$loopverdict" '"sawLoop":true' && ok "loop probe: the main spin whoosh WAS alive (probe sees real loops)" || fail "loop probe: never saw the whoosh ($loopverdict)"
jhas "$loopverdict" '"rebornAtMs":-1' && ok "rolldrop: NO sound loop lives between the hit and the bonus reel's end (bug fixed)" || fail "rolldrop: a loop came back alive ($loopverdict)"
$AB storage local set rb-rolldrop-force 0 >/dev/null 2>&1
$AB screenshot "$SHOT-rolldrop.png" >/dev/null 2>&1
errsA=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -6)
if [ -z "$errsA" ]; then ok "stage A: zero page errors"; else fail "stage A errors: $errsA"; fi

# ============================================================ STAGE B (battles)
$AB close >/dev/null 2>&1 || true
sleep 1
$AB open "$BASE/" >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
sleep 2
$AB open "$BASE/battles/new" >/dev/null
sleep 3
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>/fast mode/i.test(x.textContent)); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 0.5
fon=$($AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>/fast mode/i.test(x.textContent)&&/on/i.test(x.textContent)); return b?'fast-on':'not-on'; })()" 2>/dev/null)
jhas "$fon" "fast-on" && ok "battle: FAST mode toggled ON" || fail "battle: fast toggle ($fon)"
addcase() {
  $AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.getAttribute('aria-label')==='Add a case to the battle'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
  sleep 1.2
  $AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Community Cases')); t?.click(); return 'ok'; })()" >/dev/null 2>&1
  sleep 0.8
  $AB eval "(() => { const t=[...document.querySelectorAll('button')].find(x=>(x.getAttribute('aria-label')||'').startsWith('Add T66 Galaxy Case')); t?.click(); return 'ok'; })()" >/dev/null 2>&1
  sleep 0.5
  $AB eval "document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); 'esc'" >/dev/null 2>&1
  sleep 0.8
}
addcase
addcase # two rounds → an inter-round gap exists to measure
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim()==='Create Battle'); b?.click(); return 'ok'; })()" >/dev/null 2>&1
sleep 5
url=$($AB eval "location.pathname" 2>/dev/null | sed 's/\\//g' | rg -o "/battles/[A-Za-z0-9_-]+" | head -1)
if [ -n "$url" ] && [ "$url" != "/battles/new" ]; then ok "battle: room opened at $url"; else fail "battle: did not land in a room ($url)"; fi
BID="${url##*/}"

# 4. the "Reel — starts when full" caption is DELETED from the waiting squares
waitcap=$($AB eval "(() => { const t = document.body.innerText; return JSON.stringify({ startsWhenFull: /starts when full/i.test(t), waiting: /waiting for players/i.test(t) }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "waiting caption: $waitcap"
jhas "$waitcap" '"startsWhenFull":false' && ok "battle: 'Reel — starts when full' caption DELETED" || fail "battle: waiting caption still present"
jhas "$waitcap" '"waiting":true' && ok "battle: the room IS in the waiting phase for the check" || fail "battle: not waiting ($waitcap)"

# 5. the round-number chips — visible while WAITING (plain numbers 1..N)
chipsWait=$($AB eval "(() => { const c=[...document.querySelectorAll('[data-roundchip]')]; return JSON.stringify({ n: c.length, first: c[0]?.textContent.trim() ?? '', texts: c.map(x=>x.textContent.trim()).join('|') }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "waiting chips: $chipsWait"
jhas "$chipsWait" '"n":2' && ok "battle: round chips rendered on every strip tile (waiting)" || fail "battle: waiting chips ($chipsWait)"

# call bots → the fight starts on the fast schedule
$AB eval "(() => { const b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim().startsWith('Call Bots')); b?.click(); return 'ok'; })()" >/dev/null 2>&1
st="{}"
for i in $(seq 1 20); do
  sleep 1
  st=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>{ const b=d.battle||{}; return JSON.stringify({ st: b.status, fast: b.fast, n: (b.players||[]).length }); })" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$st" '"st":"playing"' && break
done
echo "battle state: $st"
jhas "$st" '"fast":true' && ok "battle: the room IS fast mode" || fail "battle: fast flag ($st)"

# 6. FAST x2.5 schedule — slot = 2560 + 1500 pad = 4060, gap EXACTLY 1000
sched=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>{ const b=d.battle||{}; const s=b.schedule||[]; const len0=s[0]?s[0].endMs-s[0].startMs:-1; const len1=s[1]?s[1].endMs-s[1].startMs:-1; const gap0=s.length>1? s[1].startMs-s[0].endMs : -1; return JSON.stringify({ slots: s.length, len0, len1, gap0 }); })" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "fast schedule: $sched"
jhas "$sched" '"len0":4060' && ok "fast x2.5: round 1 = 2560ms reel + 1500ms wait-for-all pad (4060)" || fail "fast x2.5 slot math ($sched)"
# len1 = 4060 (normal) OR 8120 = a ROLLDROP round (2x2560 + 500 beat + 1000 hold + 1500 pad)
if jhas "$sched" '"len1":4060'; then ok "fast x2.5: round 2 = 4060 (normal)"; elif jhas "$sched" '"len1":8120'; then ok "fast x2.5: round 2 = 8120 - a ROLLDROP round on the 2560-based chain"; else fail "fast x2.5 round 2 ($sched)"; fi
jhas "$sched" '"gap0":1000' && ok "fast x2.5: the between-rounds breather stays EXACTLY 1s" || fail "fast x2.5 gap ($sched)"

# 7. the ACTIVE chip reads "Round X/2" mid-fight
sleep 2
chipLive=$($AB eval "(() => { const a=document.querySelector('[data-roundchip-active=\"1\"]'); const all=[...document.querySelectorAll('[data-roundchip]')]; return JSON.stringify({ active: a?a.textContent.trim():'', activeN: a?1:0, total: all.length }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "active chip: $chipLive"
jhas "$chipLive" '"active":"Round 1/2"' && ok "battle: the ACTIVE tile chip reads 'Round 1/2' (which round + how many left)" || fail "battle: active chip ($chipLive)"
$AB screenshot "$SHOT-battle.png" >/dev/null 2>&1

# let the fight settle
fin="{}"
for i in $(seq 1 30); do
  sleep 1.5
  fin=$($AB eval "fetch('/api/gbattles/$BID').then(r=>r.json()).then(d=>JSON.stringify({ st:(d.battle||{}).status }))" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$fin" '"st":"finished"' && break
done
jhas "$fin" '"st":"finished"' && ok "battle: fast fight settled cleanly" || fail "battle: never finished ($fin)"
errsB=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -6)
if [ -z "$errsB" ]; then ok "stage B: zero page errors"; else fail "stage B errors: $errsB"; fi

# ============================================================ STAGE C (upgrader)
curl -s -o /dev/null -X POST "${BASE}/api/upgrader" -H 'Content-Type: application/json' -d '{}' 2>/dev/null || true
$AB close >/dev/null 2>&1 || true
sleep 1
$AB open "$BASE/" >/dev/null
$AB cookies set rb_session "$TOKEN" >/dev/null
$AB open "$BASE/upgrader" >/dev/null
ready="false"
for i in $(seq 1 20); do
  sleep 1
  ready=$($AB eval "JSON.stringify({ spin: !!document.querySelector('[data-testid=\"upgrader-spin\"]'), tiles: [...document.querySelectorAll('button')].some(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')) })" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$ready" '"spin":true' && jhas "$ready" '"tiles":true' && ready="true" && break
  ready="false"
done
[ "$ready" = "true" ] && ok "upgrader: page hydrated (spin + stake tiles)" || fail "upgrader: page never hydrated ($ready)"

# 8. the cap — $1000 on the panel
cap=$($AB eval "(() => { const t=[...document.querySelectorAll('p')].find(x=>/max stake/i.test(x.textContent)); return JSON.stringify({ txt: t?t.textContent.trim():'' }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "cap text: $cap"
jhas "$cap" 'Max stake \$1000 per spin' && ok "upgrader: the stake cap is \$1000 (panel text)" || fail "upgrader: cap text ($cap)"

# helper: pick the cheapest stake tile
pickcheapest() {
  $AB eval "(() => { const b=[...document.querySelectorAll('button')].filter(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')&&x.getAttribute('aria-pressed')!=='true').sort((a,c)=>{const va=parseFloat(a.getAttribute('aria-label').match(/([\d.]+)\s*coins\)/)?.[1]??1e9), vc=parseFloat(c.getAttribute('aria-label').match(/([\d.]+)\s*coins\)/)?.[1]??1e9); return va-vc;})[0]; b?.click(); return b?'selected':'none'; })()" 2>/dev/null
}
# helper: count picked STAKE tiles only (multiplier buttons carry aria-pressed too)
pickedcount() {
  $AB eval "[...document.querySelectorAll('button[aria-pressed=\"true\"]')].filter(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')).length" 2>/dev/null | rg -o "[0-9]+" | head -1
}

# 9. THE POTENTIAL IMAGE HOLDS THROUGH THE WHOLE SPIN (first round, 1.05x)
pickcheapest >/dev/null
sleep 2.2
spin1=$($AB eval "(() => { const o=document.querySelector('[data-testid=\"upgrader-outcome-display\"]'); const imgBefore=!!o?.querySelector('img'); document.querySelector('[data-testid=\"upgrader-spin\"]')?.click(); return JSON.stringify({ imgBefore }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
jhas "$spin1" '"imgBefore":true' && ok "upgrader: the Potential upgrade image is up before the spin" || fail "upgrader: no preview before spin ($spin1)"
sleep 3
mid=$($AB eval "(() => { const o=document.querySelector('[data-testid=\"upgrader-outcome-display\"]'); const btn=document.querySelector('[data-testid=\"upgrader-spin\"]'); return JSON.stringify({ midSpin: !!btn && /charging/i.test(btn.textContent), imgMid: !!o?.querySelector('img') }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "mid-spin: $mid"
jhas "$mid" '"midSpin":true' && ok "upgrader: sampled at t+3s — the wheel is still running" || fail "upgrader: spin ended too early ($mid)"
jhas "$mid" '"imgMid":true' && ok "upgrader: the Potential upgrade image STAYS through the spin (R38)" || fail "upgrader: the potential image vanished mid-spin ($mid)"

# 10. verdict sample at t+12.6s — INSIDE the 1.75s smoke window
sleep 9.6
verdict=$($AB eval "(() => { const o=document.querySelector('[data-testid=\"upgrader-outcome-display\"]'); const s=document.querySelector('[data-testid=\"upgrader-stake-display\"]'); const win=/upgraded/i.test(o?.textContent??''); const inner=s?.querySelector('[data-smoke]'); const smoke=inner?.getAttribute('data-smoke'); const smokeItem=!!s?.querySelector('.upg-smoke-item'); const empty=!!s&&(s.textContent.includes('shows up here BIG')); const pressed=[...document.querySelectorAll('button[aria-pressed=\"true\"]')].filter(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')).length; return JSON.stringify({ win, smoke, smokeItem, empty, autoPicked: pressed }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
echo "verdict1: $verdict"
if jhas "$verdict" '"win":true'; then
  ok "upgrader: WIN verdict on the 1.05x run"
  jhas "$verdict" '"autoPicked":1' && ok "upgrader: the won skin is AUTO-STAKED (exactly 1 picked tile)" || fail "upgrader: win without auto-stake ($verdict)"
  sleep 2.5
  still=$(pickedcount)
  [ "$still" = "1" ] && ok "upgrader: the auto-stake HOLDS (still picked 2.5s later)" || fail "upgrader: auto-stake lost (picked=$still)"
  WINOK=1
else
  ok "upgrader: LOSS verdict on the 1.05x run — the smoke checks ride this round"
  jhas "$verdict" '"smoke":"1"' && ok "upgrader: the stake display IS smoking at the verdict" || fail "upgrader: no smoke at the loss verdict ($verdict)"
  jhas "$verdict" '"smokeItem":true' && ok "upgrader: the staked skin carries the dissolve class" || fail "upgrader: no dissolve class ($verdict)"
  sleep 2.5
  post=$($AB eval "(() => { const s=document.querySelector('[data-testid=\"upgrader-stake-display\"]'); const inner=s?.querySelector('[data-smoke]'); return JSON.stringify({ empty: !!(s&&s.textContent.includes('shows up here BIG')), smoke: inner?.getAttribute('data-smoke') }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
  jhas "$post" '"empty":true' && ok "upgrader: the stake display EMPTIED after the smoke" || fail "upgrader: stake display never emptied ($post)"
  WINOK=0
fi

# 11. the OTHER outcome — 10x (90.5% loss) or 1.05x again (90.5% win)
# whichever path did not run above gets its dedicated round now (≤3 tries)
run_round() { # $1 = multiplier button label ('10×' or '1.05×')
  local m="$1"
  $AB eval "(() => { const b=[...document.querySelectorAll('button[aria-pressed]')].find(x=>x.textContent.trim().startsWith('$m')); b?.click(); return 'ok'; })()" >/dev/null 2>&1
  sleep 0.4
  pickcheapest >/dev/null
  sleep 2.2
  $AB find first "[data-testid=\"upgrader-spin\"]" click >/dev/null 2>&1
  sleep 12.6
  $AB eval "(() => { const o=document.querySelector('[data-testid=\"upgrader-outcome-display\"]'); const s=document.querySelector('[data-testid=\"upgrader-stake-display\"]'); const win=/upgraded/i.test(o?.textContent??''); const inner=s?.querySelector('[data-smoke]'); const smoke=inner?.getAttribute('data-smoke'); const smokeItem=!!s?.querySelector('.upg-smoke-item'); const pressed=[...document.querySelectorAll('button[aria-pressed=\"true\"]')].filter(x=>(x.getAttribute('aria-label')||'').startsWith('Stake ')).length; window.__v={win,smoke,smokeItem,autoPicked:pressed}; return 'ok'; })()" >/dev/null 2>&1
  $AB eval "JSON.stringify(window.__v||{})" 2>/dev/null | sed 's/\\//g' | tail -1
}

if [ "${WINOK:-0}" = "1" ]; then
  # need a LOSS round for the smoke — 10x loses 90.5%
  LOSSDONE=0
  for attempt in 1 2 3; do
    v=$(run_round "10×")
    echo "loss attempt $attempt: $v"
    if jhas "$v" '"win":false'; then
      jhas "$v" '"smoke":"1"' && jhas "$v" '"smokeItem":true' && ok "upgrader: LOSS — the stake dissolves in SMOKE (dissolve class + puffs riding)" || fail "upgrader: loss without the smoke display ($v)"
      sleep 2.5
      post=$($AB eval "(() => { const s=document.querySelector('[data-testid=\"upgrader-stake-display\"]'); const inner=s?.querySelector('[data-smoke]'); return JSON.stringify({ empty: !!(s&&s.textContent.includes('shows up here BIG')), smoke: inner?.getAttribute('data-smoke') }); })()" 2>/dev/null | sed 's/\\//g' | tail -1)
      jhas "$post" '"empty":true' && ok "upgrader: the stake display EMPTIED after the smoke (the skin is gone)" || fail "upgrader: stake display never emptied ($post)"
      LOSSDONE=1
      break
    fi
  done
  [ "$LOSSDONE" = "1" ] || fail "upgrader: no loss round observed in 3 tries (10x)"
else
  # need a WIN round for the auto-stake — 1.05x wins 90.5%
  WINDONE=0
  for attempt in 1 2 3; do
    v=$(run_round "1.05×")
    echo "win attempt $attempt: $v"
    if jhas "$v" '"win":true'; then
      jhas "$v" '"autoPicked":1' && ok "upgrader: WIN — the won skin is AUTO-STAKED into the picker" || fail "upgrader: win without auto-stake ($v)"
      wonchip=$(check "document.querySelector('[data-testid=\"upgrader-stake-display\"]')?.textContent.toLowerCase().includes('won')")
      [ "$wonchip" = "true" ] && ok "upgrader: the stake display shows the WON skin" || fail "upgrader: WON chip missing"
      sleep 2.5
      still=$(pickedcount)
      [ "$still" = "1" ] && ok "upgrader: the auto-stake HOLDS (still picked 2.5s later)" || fail "upgrader: auto-stake lost (picked=$still)"
      WINDONE=1
      break
    fi
  done
  [ "$WINDONE" = "1" ] || fail "upgrader: no win round observed in 3 tries (1.05x)"
fi
$AB screenshot "$SHOT-upgrader.png" >/dev/null 2>&1
errsC=$($AB errors 2>/dev/null | rg -v "^$|No errors|↔" | head -6)
if [ -z "$errsC" ]; then ok "stage C: zero page errors"; else fail "stage C errors: $errsC"; fi

# ============================================================ summary
echo "==================================="
if [ "$FAILED" = "0" ]; then echo "E2E-t181: ALL CHECKS PASSED"; else echo "E2E-t181: FAILURES PRESENT"; fi
exit $FAILED
