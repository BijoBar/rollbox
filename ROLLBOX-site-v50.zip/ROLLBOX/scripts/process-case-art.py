#!/usr/bin/env python3
"""
R44 USER SPEC — process every generated case render (upload/cases-gen/<slug>.png,
pure-black void background) into the site's shared transparent canvas format:

  max-channel luminance key -> hole fill (solid crate) -> component filter
  (crate + upper-half smoke; floor/reflection comps dropped) -> contact-line
  fade -> bottom-band brightness ramp -> despeckle/feather -> trim -> fit
  centered on the shared 800x615 canvas -> public/cases/<slug>.webp (q85)

Also builds QC contact sheets (12 thumbs each, on the site's card color) so
every design can be reviewed at a glance: scripts/qc-sheet-<n>.png
"""
import glob
import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage

ROOT = "/home/z/my-project"
SRC_DIR = os.path.join(ROOT, "upload/cases-gen")
OUT_DIR = os.path.join(ROOT, "public/cases")
CANVAS_W, CANVAS_H = 800, 615
QUALITY = 85
CARD = (22, 16, 40)  # #161028 — what the player sees behind the crate


def process(src_path: str) -> str | None:
    slug = os.path.splitext(os.path.basename(src_path))[0]
    im = Image.open(src_path).convert("RGB")
    rgb = np.asarray(im).astype(np.float32)
    maxc = rgb.max(axis=2)

    binary = maxc > 50
    binary_filled = ndimage.binary_fill_holes(binary)
    H, W = binary_filled.shape
    labels, n = ndimage.label(binary_filled)
    keep_mask = np.zeros_like(binary_filled)
    if not n:
        return None
    sizes = ndimage.sum(binary_filled, labels, range(1, n + 1))
    crate_label = 1 + int(np.argmax(sizes))
    keep_mask |= labels == crate_label
    crate_rows = np.where((labels == crate_label).any(axis=1))[0]
    bottom_row = int(crate_rows.max())
    for lab in range(1, n + 1):
        if lab == crate_label:
            continue
        rows = np.where(labels == lab)[0]
        if len(rows) >= 220 and rows.mean() < 0.5 * H:  # upper-half smoke
            keep_mask |= labels == lab
    keep_mask = ndimage.binary_fill_holes(keep_mask)

    ygrid = np.arange(H, dtype=np.float32).reshape(-1, 1)
    fade = np.clip((bottom_row + 16 - ygrid) / 16.0, 0.0, 1.0)

    soft = np.clip((maxc - 30.0) / (64.0 - 30.0), 0.0, 1.0)
    alpha = np.where(keep_mask, 1.0, soft * 0.85) * fade

    band_top = max(0, bottom_row - int(0.15 * H))
    ramp_band = np.clip((maxc - 45.0) / (95.0 - 45.0), 0.0, 1.0)
    ycol = np.broadcast_to(ygrid, maxc.shape)
    alpha = np.where(ycol >= band_top, alpha * ramp_band, alpha)

    a_img = Image.fromarray((alpha * 255).astype(np.uint8))
    a_img = a_img.filter(ImageFilter.MedianFilter(3)).filter(ImageFilter.GaussianBlur(0.8))
    alpha = np.asarray(a_img).astype(np.float32) / 255.0

    rgba = np.dstack([rgb, alpha * 255.0]).astype(np.uint8)
    out = Image.fromarray(rgba)
    bbox = out.getbbox()
    if not bbox:
        return None
    pad = 6
    l, t, r, b = bbox
    out = out.crop((max(0, l - pad), max(0, t - pad), min(out.width, r + pad), min(out.height, b + pad)))
    scale = min(CANVAS_W / out.width, CANVAS_H / out.height, 1.0)
    if scale < 1.0:
        out = out.resize((max(1, round(out.width * scale)), max(1, round(out.height * scale))), Image.LANCZOS)
    canvas = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    canvas.paste(out, ((CANVAS_W - out.width) // 2, (CANVAS_H - out.height) // 2), out)
    out_path = os.path.join(OUT_DIR, f"{slug}.webp")
    canvas.save(out_path, "WEBP", quality=QUALITY, method=6)
    return f"{slug}.webp  {os.path.getsize(out_path) / 1024:.0f}KB"


raws = sorted(glob.glob(os.path.join(SRC_DIR, "*.png")))
ok, bad = [], []
for p in raws:
    r = process(p)
    (ok if r else bad).append(r or os.path.basename(p))
    print(f"  {r or 'FAILED ' + os.path.basename(p)}")
print(f"\nprocessed={len(ok)} failed={len(bad)}")

# ---- QC contact sheets: 12 thumbs per sheet on the card background ----
TH_W, TH_H, LABEL_H = 258, 200, 18
COLS, ROWS = 4, 3
sheets = math.ceil(len(raws) / (COLS * ROWS))
for s in range(sheets):
    sheet = Image.new("RGB", (COLS * TH_W, ROWS * (TH_H + LABEL_H)), CARD)
    dr = ImageDraw.Draw(sheet)
    for i, p in enumerate(raws[s * COLS * ROWS : (s + 1) * COLS * ROWS]):
        slug = os.path.splitext(os.path.basename(p))[0]
        webp = os.path.join(OUT_DIR, f"{slug}.webp")
        if not os.path.exists(webp):
            continue
        thumb = Image.open(webp).convert("RGBA")
        thumb.thumbnail((TH_W - 8, TH_H - 8))
        cell_x = (i % COLS) * TH_W
        cell_y = (i // COLS) * (TH_H + LABEL_H)
        sheet.paste(thumb, (cell_x + (TH_W - thumb.width) // 2, cell_y + (TH_H - thumb.height) // 2), thumb)
        dr.text((cell_x + 6, cell_y + TH_H + 3), slug, fill=(255, 255, 255))
    out = os.path.join(ROOT, "scripts", f"qc-sheet-{s + 1}.png")
    sheet.save(out)
    print(f"QC sheet: {out}")
