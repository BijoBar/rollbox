#!/usr/bin/env node
// ============ import-user-cases.mjs — rebuild src/lib/user-cases.ts ============
// Restored pipeline (lost in a sandbox reset). Input: scripts/user-cases-spec.jsonl
// in the ROLLBOX-CASES v1 export dialect of the CASE EDITOR / DROPS editor:
//   {"code","name","price","kind","rd","items":[{"n","v","p","id","w"}]}
//   n=display name, v=coin value override, p=weight% (table sums to 100),
//   id=site skinId, w=wear (FN/MW/FT/WW/BS, absent for stickers), rd=ROLLDROP
//   chance as a FRACTION (0.00725 -> 0.725%, RB-TST 0.9 -> 90%) — matches the
//   site's CaseDef.rolldropChance units (TEST case 0.7 == the old 70%).
//
// What it preserves from the current user-cases.ts (system-owned cosmetics):
//   USER_SKINS + USER_SKIN_IMAGES blocks verbatim, and per-case id-slug /
//   subtitle / tierLabel / tierColor / tierColor2 keyed by case code.
// What it regenerates from the spec: prices, item lists (weight/value/wear),
//   rolldropChance, USER_ITEM_VALUES (skinId|wear -> typed value).
//
// RB-TST is NOT part of USER_CASES — the TEST case is hardcoded as TEST_CASE
// in src/lib/cases.ts. This script VALIDATES that block against the spec's
// RB-TST line and fails loudly on drift (price / rd / items).
//
// Usage: node scripts/import-user-cases.mjs [--check]
//   --check  validate only, do not write src/lib/user-cases.ts

import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SPEC = path.join(ROOT, "scripts/user-cases-spec.jsonl");
const TS_OUT = path.join(ROOT, "src/lib/user-cases.ts");
const GEN = path.join(ROOT, "src/lib/generated-cases.ts");
const CASES_TS = path.join(ROOT, "src/lib/cases.ts");

const CHECK_ONLY = process.argv.includes("--check");
const WEARS = new Set(["FN", "MW", "FT", "WW", "BS"]);

// ---------- load spec ----------
const lines = readFileSync(SPEC, "utf8").split("\n").map((l) => l.trim()).filter(Boolean);
if (lines[0] !== "ROLLBOX-CASES v1") {
  console.error(`FATAL: spec header must be "ROLLBOX-CASES v1", got: ${lines[0]}`);
  process.exit(1);
}
const specCases = [];
for (const [i, line] of lines.slice(1).entries()) {
  let obj;
  try {
    obj = JSON.parse(line);
  } catch (e) {
    console.error(`FATAL: spec line ${i + 2} is not valid JSON: ${e.message}`);
    process.exit(1);
  }
  if (!/^RB-(\d+|TST)$/.test(obj.code)) {
    console.error(`FATAL: spec line ${i + 2}: unexpected code format "${obj.code}"`);
    process.exit(1);
  }
  specCases.push(obj);
}

// ---------- registry of known skin ids ----------
const genSrc = readFileSync(GEN, "utf8");
const known = new Set();
for (const m of genSrc.matchAll(/"([a-z0-9-]+)": \{ id: "/g)) known.add(m[1]);

// ---------- current user-cases.ts: preserve + meta ----------
const cur = readFileSync(TS_OUT, "utf8");
function extractBlock(name) {
  const start = cur.indexOf(`export const ${name}`);
  if (start < 0) throw new Error(`cannot find export const ${name} in current user-cases.ts`);
  const end = cur.indexOf("\n};", start);
  if (end < 0) throw new Error(`cannot find end of ${name} block`);
  return cur.slice(start, end + 3); // includes trailing "};"
}
const USER_SKINS_BLOCK = extractBlock("USER_SKINS");
const USER_SKIN_IMAGES_BLOCK = extractBlock("USER_SKIN_IMAGES");
for (const m of USER_SKINS_BLOCK.matchAll(/^  "([a-z0-9-]+)": \{ id: "/gm)) known.add(m[1]);

// per-code cosmetics meta (id slug / subtitle / tierLabel / tierColor / tierColor2 / old price)
const casesBlockStart = cur.indexOf("export const USER_CASES: CaseDef[] = [");
const casesBlock = cur.slice(casesBlockStart);
const META = {};
const objRe = /  \{\r?\n    id: "([^"]+)",\r?\n    code: "([^"]+)",\r?\n    name: "([^"]+)",\r?\n    subtitle: "((?:[^"\\]|\\.)*)",\r?\n    kind: "([^"]+)",\r?\n    tierLabel: "([^"]+)",\r?\n    price: ([0-9.]+),\r?\n    tierColor: "([^"]+)",\r?\n    tierColor2: "([^"]+)",/g;
for (const m of casesBlock.matchAll(objRe)) {
  META[m[2]] = {
    id: m[1], name: m[3], subtitle: m[4], kind: m[5],
    tierLabel: m[6], price: Number(m[7]), tierColor: m[8], tierColor2: m[9],
  };
}

// ---------- validate spec ----------
const errors = [];
const itemValues = new Map(); // "skinId|wear" -> value (first occurrence wins)
const userSpec = specCases.filter((c) => c.code !== "RB-TST");
const tstSpec = specCases.find((c) => c.code === "RB-TST");

for (const c of userSpec) {
  if (c.kind !== "standard") errors.push(`${c.code}: kind "${c.kind}" — only standard cases may be imported`);
  if (!META[c.code]) errors.push(`${c.code}: no cosmetics meta in current user-cases.ts (new case? add id/subtitle/tierLabel/tierColor/tierColor2 first)`);
  const sum = c.items.reduce((s, it) => s + it.p, 0);
  if (Math.abs(sum - 100) > 1e-3) errors.push(`${c.code}: weights sum to ${sum}, expected 100`);
  for (const it of c.items) {
    if (!known.has(it.id)) errors.push(`${c.code}: unknown skin id "${it.id}" (not in GEN_SKINS/USER_SKINS)`);
    if (it.w && !WEARS.has(it.w)) errors.push(`${c.code}: bad wear "${it.w}" on ${it.id}`);
    if (typeof it.v !== "number" || !(it.v >= 0)) errors.push(`${c.code}: bad value ${it.v} on ${it.id}`);
    const key = `${it.id}|${it.w ?? ""}`;
    if (itemValues.has(key) && itemValues.get(key) !== it.v) {
      errors.push(`${c.code}: conflicting value for ${key}: ${itemValues.get(key)} vs ${it.v}`);
    } else {
      itemValues.set(key, it.v);
    }
  }
}
if (errors.length) {
  console.error("FATAL — spec validation failed:");
  for (const e of errors) console.error("  - " + e);
  process.exit(1);
}

// ---------- validate RB-TST against TEST_CASE in cases.ts ----------
if (tstSpec) {
  const casesSrc = readFileSync(CASES_TS, "utf8");
  const tcStart = casesSrc.indexOf("const TEST_CASE: CaseDef = {");
  const tcEnd = casesSrc.indexOf("\n};", tcStart);
  const tc = casesSrc.slice(tcStart, tcEnd);
  const tstErrors = [];
  const price = Number(/price: ([0-9.]+),/.exec(tc)?.[1]);
  const rd = Number(/rolldropChance: ([0-9.]+),/.exec(tc)?.[1]);
  if (price !== tstSpec.price) tstErrors.push(`price: site ${price} != spec ${tstSpec.price}`);
  if (rd !== tstSpec.rd) tstErrors.push(`rolldropChance: site ${rd} != spec ${tstSpec.rd}`);
  const itemRe = /\{ skinId: "([^"]+)", weight: ([0-9.]+)(?:, value: ([0-9.]+))?(?:, wear: "([A-Z]+)")?\s*\}/g;
  const siteItems = [...tc.slice(tc.indexOf("items: [")).matchAll(itemRe)].map(
    (m) => ({ id: m[1], p: Number(m[2]), v: m[3] != null ? Number(m[3]) : undefined, w: m[4] }),
  );
  const specItems = tstSpec.items.map((it) => ({ id: it.id, p: it.p, v: it.v, w: it.w }));
  if (siteItems.length !== specItems.length) {
    tstErrors.push(`item count: site ${siteItems.length} != spec ${specItems.length}`);
  } else {
    for (const [i, s] of specItems.entries()) {
      const t = siteItems[i];
      if (s.id !== t.id || s.p !== t.p || s.v !== t.v || s.w !== t.w) {
        tstErrors.push(`item ${i}: site ${JSON.stringify(t)} != spec ${JSON.stringify(s)}`);
      }
    }
  }
  if (tstErrors.length) {
    console.error("FATAL — RB-TST (TEST_CASE in src/lib/cases.ts) drifted from the spec:");
    for (const e of tstErrors) console.error("  - " + e);
    console.error("Fix TEST_CASE by hand to match the RB-TST spec line, then re-run.");
    process.exit(1);
  }
}

// ---------- emit ----------
const num = (x) => String(x);
const out = [];
out.push(`// ============ USER CASES (Task 114: price/value/ROLLDROP retune) — DO NOT auto-regenerate ============`);
out.push(`// The user's own case definitions for RB-101..RB-120, imported verbatim from`);
out.push(`// scripts/user-cases-spec.jsonl (ROLLBOX-CASES v1 editor export dialect:`);
out.push(`// n/v/p/w = name / value / weight% / wear; rd = ROLLDROP chance as a fraction).`);
out.push(`// Rebuild with:  node scripts/import-user-cases.mjs`);
out.push(`//`);
out.push(`// - v is the item's coin value OVERRIDE (caseItemValue prefers it) — exactly`);
out.push(`//   the number the user typed, cent-precise (0.19 stays 0.19).`);
out.push(`// - p is the drop weight in percent (all tables sum to 100).`);
out.push(`// - w is the CS2 exterior (FN/MW/FT/WW/BS); absent = no exterior (stickers).`);
out.push(`// - rd (per-case ROLLDROP chance, fraction) lands on rolldropChance;`);
out.push(`//   0.00725 -> 0.725% per opening for every standard case.`);
out.push(`// - Values are typed in Rollboxcoins, the unit the CASE EDITOR displays.`);
out.push(`// This file survives \`scripts/build-content.mjs\` re-runs: the builder only`);
out.push(`// regenerates generated-cases.ts, and src/lib/cases.ts merges THIS overlay`);
out.push(`// on top (by case code) after every rebuild.`);
out.push(``);
out.push(`import type { CaseDef, Rarity, WeaponKind } from "./cases";`);
out.push(``);
out.push(USER_SKINS_BLOCK);
out.push(``);
out.push(USER_SKIN_IMAGES_BLOCK);
out.push(``);
out.push(`/** skinId|wear -> the exact item value the user typed. cases.ts skinWithWear`);
out.push(` *  consults this FIRST so every display path (winner chips, feeds) shows the`);
out.push(` *  case editor's number instead of the market wear table's. */`);
out.push(`export const USER_ITEM_VALUES: Record<string, number> = {`);
for (const [key, v] of itemValues) out.push(`  "${key}": ${num(v)},`);
out.push(`};`);
out.push(``);
out.push(`/** The twenty user cases — merged over GEN_CASES by case code in cases.ts. */`);
out.push(`export const USER_CASES: CaseDef[] = [`);
for (const c of userSpec) {
  const meta = META[c.code];
  out.push(`  {`);
  out.push(`    id: ${JSON.stringify(meta.id)},`);
  out.push(`    code: ${JSON.stringify(c.code)},`);
  out.push(`    name: ${JSON.stringify(c.name)},`);
  out.push(`    subtitle: ${JSON.stringify(meta.subtitle)},`);
  out.push(`    kind: "standard",`);
  out.push(`    tierLabel: ${JSON.stringify(meta.tierLabel)},`);
  out.push(`    price: ${num(c.price)},`);
  out.push(`    tierColor: ${JSON.stringify(meta.tierColor)},`);
  out.push(`    tierColor2: ${JSON.stringify(meta.tierColor2)},`);
  if (c.rd != null) out.push(`    rolldropChance: ${num(c.rd)},`);
  out.push(`    items: [`);
  for (const it of c.items) {
    const wear = it.w ? ` (${it.w})` : "";
    out.push(`      // ${it.n}${wear} — ${it.p}%`);
    const fields = [`skinId: ${JSON.stringify(it.id)}`, `weight: ${num(it.p)}`, `value: ${num(it.v)}`];
    if (it.w) fields.push(`wear: ${JSON.stringify(it.w)}`);
    out.push(`      { ${fields.join(", ")} },`);
  }
  out.push(`    ],`);
  out.push(`  },`);
}
out.push(`];`);
out.push(``);

const next = out.join("\n");
if (!CHECK_ONLY) {
  writeFileSync(TS_OUT, next);
  console.log(`OK — wrote ${TS_OUT} (${next.length} bytes)`);
} else {
  console.log(`CHECK OK — ${next.length} bytes would be written`);
}

// ---------- summary: prices + implied house edge (sanity vs the editor) ----------
console.log("\ncase    price old -> new    avg     implied edge   ROLLDROP");
for (const c of specCases) {
  const avg = c.items.reduce((s, it) => s + it.v * it.p, 0) / 100;
  const edge = c.price > 0 ? ((c.price - avg) / c.price) * 100 : 0;
  const oldPrice = c.code === "RB-TST" ? 10 : META[c.code]?.price;
  console.log(
    `${c.code}  ${String(oldPrice ?? "?").padStart(6)} -> ${String(c.price).padStart(7)}  ${avg.toFixed(3).padStart(8)}  ${edge.toFixed(2).padStart(9)}%   ${(c.rd * 100).toFixed(3)}%`,
  );
}
console.log(`\nUSER_ITEM_VALUES entries: ${itemValues.size}`);
