#!/usr/bin/env bash
# UPGRADER wheel-geometry E2E probe — spins the real UI N times and checks
# that the pointer lands INSIDE the green arc exactly when the verdict is WIN.
# One line per spin: mult | arcDeg | theta | phi | verdict | MATCH/MISMATCH
set -u
CD="agent-browser"

SAMPLE_JS='(() => {
  const svg = document.querySelector("svg[viewBox=\"0 0 280 280\"]");
  if (!svg) return JSON.stringify({err:"no svg"});
  const g = svg.querySelector("g");
  const mat = new DOMMatrix(getComputedStyle(g).transform);
  const th = ((Math.atan2(mat.b, mat.a) * 180 / Math.PI) % 360 + 360) % 360;
  const arc = svg.querySelector("circle[stroke=\"#22c55e\"]");
  const dashStr = arc ? (arc.getAttribute("stroke-dasharray") || "") : "";
  const dash = parseFloat(dashStr);
  const C = 2 * Math.PI * 118;
  const arcDeg = dashStr ? dash / C * 360 : -1;
  const main = document.querySelector("main") || document.body;
  const txt = main.innerText || "";
  const win = /UPGRADED!/.test(txt);
  const fail = /FAILED/.test(txt);
  const center = (txt.match(/([0-9.]+)×/) || [])[1] || "?";
  const hist = (txt.match(/([WL])\s*\n?\s*[0-9.]+× @/g) || []).length;
  return JSON.stringify({ th, arcDeg, win, fail, mult: center, hist });
})()'

spin_once() { # $1 = mult button label e.g. "1.5× 63.3%"
  $CD find text "Sand Dune" click >/dev/null 2>&1
  if [ -n "${1:-}" ]; then
    $CD find role button click --name "$1" >/dev/null 2>&1
  fi
  $CD find role button click --name "UPGRADE 1 SKIN" >/dev/null 2>&1
  sleep 5.6
  $CD eval "$SAMPLE_JS"
}

echo "=== 6 spins @ default 2x ==="
for i in 1 2 3 4 5 6; do
  R=$(spin_once)
  echo "spin$i: $R"
done

echo "=== 6 spins @ 1.5x ==="
for i in 1 2 3 4 5 6; do
  R=$(spin_once "1.5× 63.3%")
  echo "spin$i: $R"
done

echo "=== 4 spins @ 10x ==="
for i in 1 2 3 4; do
  R=$(spin_once "10× 9.5%")
  echo "spin$i: $R"
done

echo "=== 4 spins @ 50x ==="
for i in 1 2 3 4; do
  R=$(spin_once "50× 1.9%")
  echo "spin$i: $R"
done
