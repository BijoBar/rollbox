#!/bin/bash
# Task 82-fix EDGING probe runner — 8 solo rounds on hyper-beast-bazaar.
# Each round: click OPEN -> inject the temporal sampler -> wait -> analyze.
# Results land in /home/z/my-project/scripts/t82-out/round-<n>.json
set -u
S="agent-browser --session t82"
OUT=/home/z/my-project/scripts/t82-out
mkdir -p "$OUT"
SAMPLER=$(cat /home/z/my-project/scripts/t82-edge-sample.js)
ANALYZER=$(cat /home/z/my-project/scripts/t82-edge-analyze.js)

N=${1:-8}
for i in $(seq 1 "$N"); do
  echo "=== round $i ==="
  $S eval "[...document.querySelectorAll('button')].find(b=>/Open (Case|Again)/.test(b.textContent)&&!b.disabled)?.click(); 'clicked'" >/dev/null 2>&1
  $S eval "window.__t82cfg={mode:'solo',dur:11500}; $SAMPLER" >/dev/null 2>&1
  if [ "$i" = "1" ]; then
    sleep 8.3; $S screenshot "$OUT/hold-round1.png" >/dev/null 2>&1
    sleep 1.2; $S screenshot "$OUT/locked-round1.png" >/dev/null 2>&1
    sleep 3.2
  else
    sleep 12.5
  fi
  $S eval "window.__t82analyzeMode='solo'; $ANALYZER" > "$OUT/round-$i.json" 2>&1
  tail -c 400 "$OUT/round-$i.json"; echo
done
echo "ALL ROUNDS DONE"
