// Task 28 — mint a disposable test player + inventory items + signed session cookie
import { createRequire } from "module";
import crypto from "crypto";
const require = createRequire(import.meta.url);
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
const fs = await import("fs");

const SECRET = fs.readFileSync("/home/z/my-project/db/.auth-secret", "utf8").trim();
const sign = (p) => crypto.createHmac("sha256", SECRET).update(p).digest("base64url");
const PID = "p_t28ui";

await db.player.upsert({
  where: { id: PID },
  create: { id: PID, provider: "steam", providerId: "7650000000028000", name: "T28 UI", balance: 800 },
  update: { balance: 800, bannedAt: null },
});

// clean previous inventory rows, then grant a few CHEAP catalog skins to stake
await db.inventoryItem.deleteMany({ where: { playerId: PID } });

const catalog = JSON.parse(fs.readFileSync("/home/z/my-project/public/skins-catalog.json", "utf8"));
const want = ["ak-47-safari-mesh", "aug-triqua", "mp9-storm", "sg-553-candy-apple"];
const picks = [];
for (const id of want) {
  const e = catalog.find((c) => c.id === id);
  if (e && e.v <= 50) picks.push(e);
}
// fallback: cheapest entries if some ids are missing
while (picks.length < 4) {
  const e = catalog[Math.floor(Math.random() * catalog.length)];
  if (e.v >= 1 && e.v <= 10 && !picks.some((p) => p.id === e.id)) picks.push(e);
}
for (const e of picks) {
  const { wp: _wp, wa: _wa, ...base } = e;
  await db.inventoryItem.create({
    data: {
      id: "i_" + crypto.randomBytes(8).toString("hex"),
      playerId: PID,
      entryId: e.id,
      data: JSON.stringify(base),
      value: e.v,
    },
  });
}

const total = picks.reduce((s, e) => s + e.v, 0);
console.error("granted:", picks.map((p) => `${p.n} (${p.v})`).join(", "), "| stake total:", total);
const body = Buffer.from(JSON.stringify({ pid: PID, exp: Date.now() + 86400000 })).toString("base64url");
console.log("rb_session=" + body + "." + sign(body));
await db.$disconnect();
