// ============ Task 24 E2E — TERMINAL page redesign: per-dealer MINIMUMS ============
// Disposable test player + signed session cookie (same HMAC as the server).
// Checks the NEW min deal (1/10/30/70/300), max unchanged, one full
// play->claim cycle at DANNY, then cleans EVERYTHING up.
import { createRequire } from "module";
import crypto from "crypto";
const require = createRequire(import.meta.url);
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();
const fs = await import("fs");

const SECRET = fs.readFileSync("/home/z/my-project/db/.auth-secret", "utf8").trim();
const sign = (p) => crypto.createHmac("sha256", SECRET).update(p).digest("base64url");
const tokenFor = (pid) => {
  const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 86400000 })).toString("base64url");
  return `${body}.${sign(body)}`;
};

const PID = "p_t24test";
const BASE = "http://localhost:3000";
let fails = 0;
const ok = (name, cond, extra = "") => {
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${extra ? " — " + extra : ""}`);
  if (!cond) fails++;
};

await db.player.upsert({
  where: { id: PID },
  create: { id: PID, provider: "steam", providerId: "7650000000024000", name: "T24 TEST", balance: 800 },
  update: { balance: 800, bannedAt: null },
});
const cookie = "rb_session=" + tokenFor(PID);
const H = { "Content-Type": "application/json", cookie };

const bal = async () => (await db.player.findUnique({ where: { id: PID } })).balance;

// ===== 1. the MIN matrix (below-min must 400 with the dealer's own min) =====
const belowCases = [
  ["danny", 0.5, 1],
  ["viktor", 5, 10],
  ["wolf", 29, 30],
  ["sasha", 69, 70],
  ["boss", 299, 300],
];
for (const [dealerId, amt, min] of belowCases) {
  const r = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId, amount: amt }) });
  const d = await r.json();
  ok(`below-min ${dealerId} ${amt} -> 400`, r.status === 400 && String(d.error ?? "").includes(`minimum deal is ${min}`), d.error ?? "");
}

// exact minimums must PASS everywhere (charge then immediate claim of cheapest)
for (const [dealerId, min] of [["danny", 1], ["viktor", 10], ["wolf", 30], ["sasha", 70], ["boss", 300]]) {
  const r = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId, amount: min }) });
  const d = await r.json();
  if (r.status === 200 && d.playId) {
    ok(`at-min ${dealerId} ${min} -> 200`, true, `5 offers: ${d.offers.length}`);
    // approve cheapest to settle cleanly
    const worst = d.offers.reduce((best, o, i) => (o.v < d.offers[best].v ? i : best), 0);
    const rc = await fetch(BASE + "/api/terminal/claim", { method: "POST", headers: H, body: JSON.stringify({ playId: d.playId, index: worst }) });
    ok(`at-min ${dealerId} claim -> 200`, rc.status === 200);
  } else {
    ok(`at-min ${dealerId} ${min} -> 200`, false, d.error ?? `status ${r.status}`);
  }
}

// ===== 2. max unchanged =====
const rMax = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId: "danny", amount: 50.01 }) });
ok("danny 50.01 -> 400 max", rMax.status === 400);
const rMax2 = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId: "danny", amount: 50 }) });
ok("danny 50 (max) -> 200", rMax2.status === 200);
if (rMax2.status === 200) {
  const d = await rMax2.json();
  await fetch(BASE + "/api/terminal/claim", { method: "POST", headers: H, body: JSON.stringify({ playId: d.playId, index: 0 }) });
}

// ===== 3. full-cycle math at DANNY 25 =====
const before = await bal();
const r = await fetch(BASE + "/api/terminal/play", { method: "POST", headers: H, body: JSON.stringify({ dealerId: "danny", amount: 25 }) });
const play = await r.json();
ok("play danny 25 ok", r.status === 200 && play.offers.length === 5);
const afterCharge = await bal();
ok("charged exactly 25", Math.abs(before - afterCharge - 25) < 1e-9, `${before} -> ${afterCharge}`);
const worstIdx = play.offers.reduce((best, o, i) => (o.v < play.offers[best].v ? i : best), 0);
const rc = await fetch(BASE + "/api/terminal/claim", { method: "POST", headers: H, body: JSON.stringify({ playId: play.playId, index: worstIdx }) });
const claim = await rc.json();
ok("claim cheapest ok", rc.status === 200 && claim.item?.uid);
const item = claim.item ? await db.inventoryItem.findUnique({ where: { id: claim.item.uid } }) : null;
ok("inventory row at offered value", !!item && Math.abs(item.value - play.offers[worstIdx].v) < 1e-9, item?.value + " vs " + play.offers[worstIdx].v);

// ===== 4. cleanup EVERYTHING the test touched =====
await db.inventoryItem.deleteMany({ where: { playerId: PID } });
await db.openPending.deleteMany({ where: { playerId: PID } });
await db.ledger.deleteMany({ where: { playerId: PID } });
await db.player.delete({ where: { id: PID } }).catch(() => {});
const left = await db.player.count();
ok("cleanup — players back to 9", left === 9, "count=" + left);

console.log(fails === 0 ? "\nALL PASS" : `\n${fails} FAILURES`);
process.exit(fails === 0 ? 0 : 1);
