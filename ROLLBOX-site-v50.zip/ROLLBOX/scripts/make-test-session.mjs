// E2E helper (Task 136): issue a valid rb_session cookie value for a player id.
// Same scheme as src/lib/server/auth.ts — body = base64url({pid,exp}) +
// "." + HMAC-SHA256(secret, body) base64url. Secret resolution mirrors the
// server: AUTH_SECRET env when 16+ chars, else db/.auth-secret.
import crypto from "crypto";
import fs from "fs";

const [, , pid] = process.argv;
if (!pid) {
  console.error("usage: bun scripts/make-test-session.mjs <playerId>");
  process.exit(1);
}

let secret = process.env.AUTH_SECRET;
if (!secret || secret.length < 16) {
  secret = fs.readFileSync("db/.auth-secret", "utf8").trim();
}

const body = Buffer.from(JSON.stringify({ pid, exp: Date.now() + 30 * 24 * 3600 * 1000 })).toString("base64url");
const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
console.log(`${body}.${sig}`);
