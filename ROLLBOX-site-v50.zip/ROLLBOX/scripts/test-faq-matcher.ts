// Matcher sanity check for the Task-138 FAQ (no DB, pure functions).
import { matchFaq, SUPPORT_FAQ } from "../src/lib/support-faq";

const cases: Array<[string, string | null]> = [
  ["Can I get a refund?", "Can I get a refund?"], // chip click = exact match
  ["i want a refund", "Can I get a refund?"],
  ["give me my money back", "Can I get a refund?"],
  ["How long do withdrawals take?", "How long do withdrawals take?"],
  ["my withdrawal never arrived", "How long do withdrawals take?"],
  ["when will my skins arrive", "How long do withdrawals take?"],
  ["how do i deposit funds", "How do I deposit funds?"],
  ["i want to top up my wallet", "How do I deposit funds?"],
  ["I have another question", "I have another question"],
  ["i have an other question", "I have another question"],
  ["can i talk to a human", "I have another question"],
  ["hello there", null], // no match → fallback
  ["what is the best case", null], // must NOT be hijacked
];

let bad = 0;
for (const [text, want] of cases) {
  const got = matchFaq(text);
  const ok = (got?.question ?? null) === want;
  if (!ok) bad++;
  console.log(`${ok ? "PASS" : "FAIL"}  "${text}" -> ${got?.question ?? "FALLBACK"}`);
}
console.log(`chips: ${SUPPORT_FAQ.length} (expected 4)`);
if (SUPPORT_FAQ.length !== 4) bad++;
process.exit(bad ? 1 : 0);
