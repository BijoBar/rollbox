import { GEN_CASES, GEN_SKINS } from "../src/lib/generated-cases";

// mirror of oddsPct (avoids cross-import friction)
function oddsPct(c: { items: { skinId: string; weight: number }[] }, skinId: string): number {
  const total = c.items.reduce((s, i) => s + i.weight, 0);
  const w = c.items.find((i) => i.skinId === skinId)?.weight ?? 0;
  return total > 0 ? (w / total) * 100 : 0;
}

for (const c of GEN_CASES.filter((x) => x.kind === "standard").slice(0, 5)) {
  const pcts = c.items.map((i) => oddsPct(c, i.skinId)).sort((a, b) => a - b);
  const rareCum = pcts.filter((p) => p <= 10).reduce((s, p) => s + p, 0);
  console.log(c.name, "| rarest:", pcts.slice(0, 3).map((p) => p.toFixed(2) + "%").join("/"), "| cumulative ≤10% items:", rareCum.toFixed(1) + "%");
}
