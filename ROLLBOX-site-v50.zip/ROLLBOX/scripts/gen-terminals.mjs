// ============================================================
// TERMINAL defaults generator + EV tuner (Task 23)
// - extracts the skin catalog from the user's CASE EDITOR html
// - builds 5 dealers (max 50/100/500/1000/5000), 10 skins each
// - tunes the chance vectors so E[best-of-5 offers] ~= 90% of
//   the amount paid (house edge ~10%) via Monte-Carlo search
// - writes src/lib/terminals.ts (DEFAULT_TERMINALS) and prints
//   the editor's BASE_TERMINALS JSON to scripts/terminal-bases.json
// ============================================================
import fs from "fs";
import path from "path";
import crypto from "crypto";

const ROOT = "/home/z/my-project";
const editorHtml = fs.readFileSync(path.join(ROOT, "upload", "ROLLBOX-cases-editor.html"), "utf8");

// --- 1) extract the SKINS catalog (name/value/rarity per id) ---
const skStart = editorHtml.indexOf("const SKINS = ");
const skEnd = editorHtml.indexOf(";", skStart);
if (skStart < 0 || skEnd < 0) throw new Error("SKINS map not found in editor html");
const SKINS = JSON.parse(editorHtml.slice(skStart + 14, skEnd));
const catalog = Object.entries(SKINS)
  .map(([id, s]) => ({ id, name: s.name, value: +s.value, rarity: s.rarity }))
  .filter((s) => Number.isFinite(s.value) && s.value > 0.04)
  .sort((a, b) => a.value - b.value);
console.log(`catalog skins: ${catalog.length}`);

// --- 2) dealers ---
const DEALERS = [
  { id: "danny", name: "DANNY", subtitle: "The corner plug — small deals, quick flips.", max: 50 },
  { id: "viktor", name: "VIKTOR", subtitle: "Cold hands, warm offers.", max: 100 },
  { id: "wolf", name: "MR. WOLF", subtitle: "Cleans up any inventory. No questions asked.", max: 500 },
  { id: "sasha", name: "SASHA", subtitle: "High stakes, sharper suits.", max: 1000 },
  { id: "boss", name: "THE BOSS", subtitle: "You don't call The Boss. The Boss calls you.", max: 5000 },
];

// value profile (as fraction of the dealer max) — the 10 rungs every dealer offers
const RUNGS = [0.04, 0.09, 0.16, 0.26, 0.4, 0.6, 0.85, 1.25, 2.2, 8];
const usedIds = new Set(); // no skin repeats across dealers (variety)

function pickSkin(target) {
  let best = null;
  let bestD = Infinity;
  for (const s of catalog) {
    if (usedIds.has(s.id)) continue;
    const d = Math.abs(Math.log(s.value / target));
    // small preference for real weapon skins over stickers for looks
    const bonus = s.id.startsWith("sticker") || s.id.startsWith("patch") ? Math.log(1.35) : 0;
    if (d + bonus < bestD) {
      bestD = d + bonus;
      best = s;
    }
  }
  if (!best) return catalog[0];
  usedIds.add(best.id);
  return best;
}

// --- 3) Monte-Carlo: E[best of 5 distinct weighted draws] ---
// draws without replacement, renormalising the weights each pick
function evBest5(skins, chances, iters) {
  let acc = 0;
  const n = skins.length;
  const alive = new Array(n);
  for (let it = 0; it < iters; it++) {
    alive.fill(true);
    let best = 0;
    for (let k = 0; k < 5; k++) {
      let total = 0;
      for (let i = 0; i < n; i++) if (alive[i]) total += chances[i];
      let r = crypto.randomBytes(4).readUInt32LE(0) / 0x100000000 * total;
      let pick = n - 1;
      for (let i = 0; i < n; i++) {
        if (!alive[i]) continue;
        r -= chances[i];
        if (r <= 0) { pick = i; break; }
      }
      alive[pick] = false;
      const v = skins[pick].v;
      if (v > best) best = v;
    }
    acc += best;
  }
  return acc / iters;
}

const ITERS = 4000;

for (const dealer of DEALERS) {
  const skins = RUNGS.map((f) => {
    const s = pickSkin(dealer.max * f);
    return { id: s.id, n: s.name, v: Math.round(s.value * 100) / 100 };
  });
  // start: descending chances, most mass on the low rungs
  let chances = [20, 19, 17, 14, 11, 8, 6, 3.5, 1.2, 0.3];
  const target = dealer.max * 0.9; // EV goal: 90% of the MAX deal
  let ev = evBest5(skins, chances, ITERS);
  let bestSet = chances.slice();
  let bestErr = Math.abs(ev - target);
  // hill-climb: nudge % between random rungs, keep improvements
  let cur = chances.slice();
  let curEv = ev;
  for (let step = 0; step < 900; step++) {
    const cand = cur.slice();
    const a = crypto.randomInt(0, 10);
    let b = crypto.randomInt(0, 10);
    if (b === a) b = (b + 1 + crypto.randomInt(0, 9)) % 10;
    const shift = Math.min(cand[a], Math.max(0.05, dealer.max * 0.01 * (0.5 + crypto.randomBytes(1)[0] / 255)));
    cand[a] = Math.max(0.02, cand[a] - shift);
    cand[b] = Math.max(0.02, cand[b] + shift);
    const e = evBest5(skins, cand, ITERS);
    const err = Math.abs(e - target);
    if (err < bestErr - 1) {
      bestErr = err;
      bestSet = cand.slice();
    }
    if (err < Math.abs(curEv - target)) {
      cur = cand;
      curEv = e;
    }
  }
  // final polish with a bigger sample on the winner
  let polish = bestSet.slice();
  let polishEv = evBest5(skins, polish, 12000);
  for (let step = 0; step < 250; step++) {
    const cand = polish.slice();
    const a = crypto.randomInt(0, 10);
    let b = crypto.randomInt(0, 10);
    if (b === a) b = (b + 1 + crypto.randomInt(0, 9)) % 10;
    const shift = Math.min(cand[a], 0.4 + crypto.randomBytes(1)[0] / 40);
    cand[a] = Math.max(0.02, cand[a] - shift);
    cand[b] = Math.max(0.02, cand[b] + shift);
    const e = evBest5(skins, cand, 12000);
    if (Math.abs(e - target) < Math.abs(polishEv - target)) {
      polish = cand;
      polishEv = e;
    }
  }
  // normalise to exactly 100
  const sum = polish.reduce((s, c) => s + c, 0);
  let chances2 = polish.map((c) => Math.round((c * 100 / sum) * 10000) / 10000);
  const drift = Math.round((100 - chances2.reduce((s, c) => s + c, 0)) * 10000) / 10000;
  chances2[0] = Math.round((chances2[0] + drift) * 10000) / 10000;
  const finalEv = evBest5(skins, chances2, 20000);
  dealer.skins = skins.map((s, i) => ({ ...s, p: chances2[i] }));
  dealer.ev = finalEv;
  console.log(
    `${dealer.name}: EV=${finalEv.toFixed(1)} / max=${dealer.max} (${((finalEv / dealer.max) * 100).toFixed(1)}%), sum=${chances2.reduce((s, c) => s + c, 0).toFixed(2)}`,
  );
}

// --- 4) write the outputs ---
const baseTerminals = DEALERS.map((d) => ({
  id: d.id,
  name: d.name,
  subtitle: d.subtitle,
  max: d.max,
  skins: d.skins,
}));

fs.writeFileSync(path.join(ROOT, "scripts", "terminal-bases.json"), JSON.stringify(baseTerminals, null, 1));

const ts = `// ============ TERMINAL — the 5 weapon dealers (Task 23, USER SPEC) ============
// Five dealers, each with a MAX deal: 50 / 100 / 500 / 1000 / 5000. A deal
// scales the pool: the skin values here are priced AT THE DEALER'S MAX, and
// the offer you see is worth (value x amount/max). Each dealer carries 10
// skins with a % chance each; a purchase draws 5 DISTINCT offers and the
// player approves exactly ONE of them.
// Defaults generated by scripts/gen-terminals.mjs (Monte-Carlo tuned so the
// best-of-5 expected value lands at ~90% of the amount paid). The CASE
// EDITOR exports (ROLLBOX-TERMINALS v1) overlay these via user-terminals.ts.

import { USER_TERMINALS } from "./user-terminals";

export interface TerminalSkin {
  id: string | null; // catalog skin id (image + weapon art); null = custom
  n: string; // display name
  v: number; // coin value AT THE DEALER'S MAX deal
  p: number; // draw chance, percent (the dealer's table sums to 100)
}

export interface TerminalDef {
  id: string;
  name: string;
  subtitle: string;
  max: number;
  skins: TerminalSkin[];
}

export const DEFAULT_TERMINALS: TerminalDef[] = ${JSON.stringify(baseTerminals, null, 2)};

// the editor overlay replaces a dealer wholesale by id; unknown ids append
const BY_ID = new Map(DEFAULT_TERMINALS.map((d) => [d.id, d]));
const merged = DEFAULT_TERMINALS.map((d) => {
  const u = USER_TERMINALS.find((x) => x.id === d.id);
  return u ? { ...d, ...u } : d;
});
for (const u of USER_TERMINALS) if (!BY_ID.has(u.id)) merged.push(u);

export const TERMINALS: TerminalDef[] = merged;

/** one weighted draw index over a skin table (renormalised) */
export function drawWeightedIndex(skins: TerminalSkin[]): number {
  const total = skins.reduce((s, k) => s + Math.max(0, k.p), 0);
  let r = Math.random() * total;
  for (let i = 0; i < skins.length; i++) {
    r -= Math.max(0, skins[i].p);
    if (r <= 0) return i;
  }
  return skins.length - 1;
}

/** the dealer's pre-written tablet lines (flavor, Task 23) */
export const DEALER_LINES: Record<string, string[]> = {
  danny: [
    "Yo! Fresh stock just landed. Let's talk.",
    "Small pockets? Small problem. Pick a deal.",
    "Everything's legit. Mostly. Look around.",
  ],
  viktor: [
    "I don't haggle. I offer. You choose.",
    "Cold storage is full today. Good day to buy.",
    "One deal. One skin. Make it count.",
  ],
  wolf: [
    "You have exactly one shot. Make it interesting.",
    "I cleaned bigger messes than your inventory.",
    "Everyone gets an offer. Not everyone listens.",
  ],
  sasha: [
    "Darling, the good stuff is behind the counter. This IS the counter.",
    "Big coins, bigger taste. Show me both.",
    "Sign here, shine forever.",
  ],
  boss: [
    "Everything in this vault has a price. Today, it's yours to pick.",
    "I was told you might come. The vault is open.",
    "Respect the numbers and the numbers respect you.",
  ],
};
`;

fs.writeFileSync(path.join(ROOT, "src", "lib", "terminals.ts"), ts);
console.log("wrote src/lib/terminals.ts + scripts/terminal-bases.json");
