#!/usr/bin/env bash
# Task 43 E2E — part 6: capture the team wheel LIVE (both team cells) + banner.
set -u
AB="agent-browser"
D="/home/z/my-project/download"

$AB open http://localhost:3000/battles/new >/dev/null 2>&1
sleep 2.5
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "2 Vs 2")?.click(); return "2v2"; })()' 2>/dev/null | tail -1
sleep 0.3
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "JACKPOT")?.click(); return "jp"; })()' 2>/dev/null | tail -1
sleep 0.3
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "Add Case")?.click(); return "picker"; })()' 2>/dev/null | tail -1
sleep 1.2
$AB eval '(() => { [...document.querySelectorAll("[role=\"dialog\"] button[aria-label^=\"Add\"]")].find(b => b.getAttribute("aria-label").includes("$3"))?.click(); return "case"; })()' 2>/dev/null | tail -1
sleep 0.3
$AB eval '(() => { document.querySelector("[role=\"dialog\"]")?.dispatchEvent(new KeyboardEvent("keydown", {key: "Escape", bubbles: true})); return "esc"; })()' 2>/dev/null | tail -1
sleep 0.5
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.includes("Create Battle"))?.click(); return "created"; })()' 2>/dev/null | tail -1
sleep 2.2
$AB eval '(() => { [...document.querySelectorAll("button")].find(b => b.textContent.includes("Call Bots"))?.click(); return "bots in"; })()' 2>/dev/null | tail -1

echo "=== poll for the reel ==="
for i in $(seq 1 40); do
  sleep 0.5
  R=$($AB eval '(() => {
    const status = document.querySelector("[role=\"status\"]");
    if (!status) return "no-reel";
    const names = [...status.querySelectorAll("span[title]")].map(s => s.getAttribute("title"));
    const hasCT = names.includes("Team CT"), hasT = names.includes("Team T");
    const pcts = [...status.querySelectorAll(".font-display.rounded")].map(x => x.textContent);
    const banner = status.textContent.match(/Team C[TT] wins the jackpot/)?.[0] ?? null;
    return JSON.stringify({hasCT, hasT, uniqPcts: [...new Set(pcts)].slice(0,4), banner});
  })()' 2>/dev/null | tail -1)
  echo "poll$i: $R"
  case "$R" in
    *banner*Team*) break ;;
  esac
done
$AB screenshot "$D/task43-jackpot-team-reel.png" >/dev/null 2>&1
sleep 7
$AB eval 'JSON.stringify({phase: document.body.textContent.includes("Decided by the jackpot draw") ? "decided-by-jackpot" : "other", lostOrWon: document.body.textContent.includes("BATTLE LOST") ? "lost" : (document.body.textContent.includes("VICTORY") ? "won" : "?")})' 2>/dev/null | tail -1
$AB screenshot "$D/task43-jackpot-team-verdict.png" >/dev/null 2>&1