// E2E fixture for Task 180 — banned sign-in flow.
// --create   : creates a THROWAWAY banned player + mints a signed session
//              cookie for it (printed as JSON). The row is disposable.
// --cleanup  : deletes the throwaway row and prints the remaining count.
// The members counter is NOT bumped (direct db write, not upsertPlayer) and
// no ledger/inventory rows are created — the site stats stay untouched.
import { db } from "../src/lib/db";
import { makeSessionToken } from "../src/lib/server/auth";

const ID = "p_e2e_ban_t180";

const mode = process.argv[2] ?? "--create";

if (mode === "--create") {
  await db.player.deleteMany({ where: { id: ID } }); // stale fixture from a crashed run
  const p = await db.player.create({
    data: {
      id: ID,
      provider: "steam",
      providerId: "steam_e2e_ban_t180",
      name: "E2E Ban Test",
      balance: 5,
      bannedAt: new Date(),
    },
  });
  console.log(JSON.stringify({ id: p.id, bannedAt: p.bannedAt, token: makeSessionToken(p.id) }));
} else if (mode === "--cleanup") {
  await db.player.deleteMany({ where: { id: ID } });
  const n = await db.player.count();
  console.log(JSON.stringify({ deleted: ID, players: n }));
}
process.exit(0);
