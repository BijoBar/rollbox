#!/usr/bin/env python3
"""Task 66 verification — CALL BOTS.

USER SPEC: every battle room can be filled with the site's bots ([RBbot] tag),
the host can CHOOSE which bot sits, bots only take EMPTY seats, the bot vote
fills the room, and bot pulls never reach the public live feed.
Static markers + a live bots flow against the dev server on :3000.
"""
import base64
import hashlib
import hmac
import json
import sqlite3
import sys
import time

import requests

BASE = "http://localhost:3000"
DB = "db/custom.db"
SECRET = "rollbox-dev-secret"
PASS: list[str] = []
FAIL: list[str] = []


def check(name: str, ok: bool, extra: str = "") -> None:
    (PASS if ok else FAIL).append(name + (f" — {extra}" if (extra and not ok) else ""))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if (extra and not ok) else ""))


def read(*parts: str) -> str:
    with open(os.path.join(*parts), encoding="utf-8") as f:
        return f.read()


import os  # noqa: E402


def mint(pid: str) -> str:
    body = base64.urlsafe_b64encode(json.dumps({"pid": pid, "exp": int(time.time() * 1000) + 86400000},
                                               separators=(",", ":")).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()
    return body + "." + base64.urlsafe_b64encode(sig).decode().rstrip("=")


def sess(pid: str) -> dict:
    return {"rb_session": mint(pid)}


def make_player(tag: str, balance: int = 5000) -> str:
    pid = f"p_t66{tag}"
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT OR REPLACE INTO Player (id, provider, providerId, name, balance, casesOpened, battlesWon, lastDailyAt, createdAt, lastSeenAt) "
        "VALUES (?, 'steam', ?, ?, ?, 0, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
        (pid, f"t66-{tag}-steamid", f"T66 {tag}", balance),
    )
    con.commit()
    con.close()
    return pid


def main() -> None:
    # ===== static markers =====
    battles = read("src", "lib", "battles.ts")
    check("[RBbot] tag enforced", "[RBbot]" in battles and "RBBOT_NAMES" in battles)
    check("makeBot factory exists", "export function makeBot" in battles)
    check("makeBotBattle local-fill exists", "export function makeBotBattle" in battles)

    eng = read("src", "lib", "server", "gbattles.ts")
    check("bots vote carried into seats", "botsVote" in eng)
    check("chosen-bot seating (Task 66/67)", "seatChosenBot" in eng or "nextBotKey" in eng)
    check("bots-only-fill-empty-seats", "openSeat" in eng and "makeBot" in eng)
    check("bot provider never hits the feed", '"bot"' in eng)

    bots_route = read("src", "app", "api", "gbattles", "[id]", "bots", "route.ts")
    check("POST /bots endpoint exists", "export async function POST" in bots_route)
    check("bots endpoint rejects unknown bot", "RBBOT_NAMES" in bots_route or "not_found" in bots_route or "400" in bots_route)

    seat_view = read("src", "components", "rollbox", "BattleRoomView.tsx")
    check("room UI: CALL BOTS vote + bot seating", "callBots" in seat_view and "PLAY WITH BOTS" in seat_view)

    # ===== live flow: create room, seat a chosen bot, room fills =====
    a = make_player("A")
    r = requests.post(BASE + "/api/gbattles", timeout=15, cookies=sess(a),
                      json={"type": "1v1", "mode": "standard", "potRule": "winner", "rounds": ["farm-ak47"], "private": False})
    bid = r.json().get("id")
    check("live: battle created", bool(bid), r.text[:120])
    if bid:
        r = requests.post(BASE + f"/api/gbattles/{bid}/bots", timeout=15, cookies=sess(a), json={"bot": "[RBbot] Gabey"})
        check("live: chosen bot seated", r.status_code == 200, r.text[:120])
        st = requests.get(BASE + f"/api/gbattles/{bid}", timeout=15, cookies=sess(a)).json()
        st = st.get("battle", st)
        players = st.get("players", [])
        check("live: room auto-fills and starts", any(p.get("isBot") for p in players) and st.get("status") in ("running", "playing", "live"),
              json.dumps({"status": st.get("status"), "players": [p.get("name") for p in players]})[:160])
        check("live: bot carries the [RBbot] tag", any(p.get("isBot") and "[RBbot]" in (p.get("name") or "") for p in players))

        r = requests.post(BASE + f"/api/gbattles/{bid}/bots", timeout=15, cookies=sess(a), json={"bot": "Not-A-Bot"})
        check("live: unknown bot rejected", r.status_code in (400, 404), str(r.status_code))

        # the room's battle id must NOT be joinable twice
        r = requests.post(BASE + f"/api/gbattles/{bid}/join", timeout=15, cookies=sess(a), json={})
        check("live: re-join full room rejected", r.status_code >= 400, str(r.status_code))

    # bot pulls must never land in the public feed
    con = sqlite3.connect(DB)
    bot_drops = con.execute("SELECT COUNT(*) FROM \"Drop\" WHERE provider='bot' AND source='battle' AND battleId IS NULL").fetchone()[0]
    con.close()
    check("db: bot drops always bound to a battle", bot_drops == 0)

    print(f"\n== {len(PASS)} passed, {len(FAIL)} failed ==")
    if FAIL:
        print("FAILED:", *FAIL, sep="\n  - ")
        sys.exit(1)


if __name__ == "__main__":
    main()
