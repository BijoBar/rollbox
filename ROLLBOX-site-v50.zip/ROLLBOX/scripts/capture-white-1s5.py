"""One-shot capture of the 1.5s white-on-reel-only moment (small viewport =
fast screenshots; scroll the reel into view right after the click)."""
from playwright.sync_api import sync_playwright

OUT = "/home/z/my-project/download/e2e-shots"

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 900, "height": 1100})
    pg.goto("http://localhost:3000/case/test-rolldrop", wait_until="load", timeout=60000)
    pg.evaluate("localStorage.setItem('rb-rolldrop-force','1')")
    pg.reload(wait_until="load", timeout=60000)
    pg.wait_for_timeout(2500)

    pg.click("button:has-text('Open Case')")
    # keep the reel framed (the click scrolls to the button below it)
    for _ in range(40):
        pg.evaluate(
            "document.querySelector('section[aria-label*=\"unboxing reel\"]')"
            "?.scrollIntoView({block:'center'})"
        )
        if pg.evaluate("!!document.querySelector('.rd-white-cover')"):
            break
        pg.wait_for_timeout(120)
    # attached — shoot the same frame chain fast
    pg.screenshot(path=f"{OUT}/45f-white-1s5-a.png")
    pg.wait_for_timeout(250)
    pg.screenshot(path=f"{OUT}/45f-white-1s5-b.png")
    pg.wait_for_timeout(250)
    pg.screenshot(path=f"{OUT}/45f-white-1s5-c.png")
    dur = pg.evaluate(
        """() => { const el = document.querySelector('.rd-white-cover');
        return el ? getComputedStyle(el).animationDuration : 'detached'; }"""
    )
    print("animationDuration:", dur)
    pg.wait_for_timeout(2500)
    pg.screenshot(path=f"{OUT}/45f-after-white.png")
    b.close()
