// Dump the full case registry (cases + resolved skin data) to JSON
// so the case editor builder can pre-fill every case with its items.
// Task 72: items may carry a wear + value override; the top-level "skins"
// section exposes per-skin wear prices (coins) + in-game wear availability.
import { CASES, caseItemValue, SKINS } from "../src/lib/cases";
import { SKIN_WEAR_PRICES, SKIN_WEAR_AVAIL } from "../src/lib/generated-wear-prices";
import { writeFileSync } from "node:fs";

const cases = CASES.map((c) => ({
  id: c.id,
  code: c.code,
  name: c.name,
  subtitle: c.subtitle,
  kind: c.kind,
  tierLabel: c.tierLabel,
  price: c.price,
  rolldropChance: c.rolldropChance ?? null,
  items: c.items.map((it) => {
    const s = SKINS[it.skinId];
    return {
      skinId: it.skinId,
      name: s?.name ?? it.skinId,
      // the EFFECTIVE value (wear price / override included) — what the editor shows
      value: caseItemValue(it),
      rarity: s?.rarity ?? "consumer",
      weight: it.weight,
      ...(it.wear ? { wear: it.wear } : {}),
      ...(it.value != null ? { valueOverride: it.value } : {}),
    };
  }),
}));

const skins: Record<string, unknown> = {};
for (const c of cases) {
  for (const it of c.items) {
    if (skins[it.skinId]) continue;
    skins[it.skinId] = {
      name: it.name,
      value: it.value,
      rarity: it.rarity,
      ...(SKIN_WEAR_PRICES[it.skinId] ? { wp: SKIN_WEAR_PRICES[it.skinId] } : {}),
      ...(SKIN_WEAR_AVAIL[it.skinId] ? { wa: SKIN_WEAR_AVAIL[it.skinId] } : {}),
    };
  }
}

const out = { generatedAt: new Date().toISOString(), cases, skins };

const totalItems = cases.reduce((n, c) => n + c.items.length, 0);
const sums = cases.map((c) => ({ code: c.code, sum: +c.items.reduce((s, i) => s + i.weight, 0).toFixed(4) }));
console.log("cases:", cases.length, "items:", totalItems, "skins:", Object.keys(skins).length);
console.table(sums);

writeFileSync(new URL("./cases-dump.json", import.meta.url), JSON.stringify(out, null, 2));
console.log("written scripts/cases-dump.json");
