// Builds a test editor export (ROLLBOX-CASES v1 dialect) to exercise the
// import merge: a tweaked RB-110 + a brand-new RB-121. Dev-only artifact.
import { readFileSync, writeFileSync } from "node:fs";

const BASE = JSON.parse(
  readFileSync("/home/z/my-project/scripts/editor-data/BASE.json", "utf8")
);

const lines = ["ROLLBOX-CASES v1"];

// 1) changed RB-110 — weight swap (sum stays 100) + one value tweak
const rb110 = BASE.find((c) => c.code === "RB-110");
const items = rb110.items.map((i) => ({ ...i }));
items[0].p = +(items[0].p + 1);
items[1].p = +(items[1].p - 1);
items[2].v = 9.99;
lines.push(JSON.stringify({
  code: "RB-110",
  name: rb110.name,
  price: rb110.price,
  kind: rb110.kind,
  rd: rb110.rd,
  items,
}));

// 2) brand-new RB-121 — two known skins (with id) + one unknown (name only)
lines.push(JSON.stringify({
  code: "RB-121",
  name: "Test Box",
  price: 25,
  kind: "standard",
  rd: 5,
  items: [
    { id: "ak-47-asiimov", n: "AK-47 | Asiimov", v: 415, p: 60, w: "FT" },
    { id: "sticker-dragon", n: "Sticker | Dragon", v: 3, p: 30 },
    { n: "AK-47 | Super Test Skin", v: 10, p: 10 },
  ],
}));

writeFileSync("/home/z/my-project/scripts/editor-data/test-export.txt", lines.join("\n") + "\n");
console.log("test export written (2 deltas: RB-110 tweak, RB-121 new)");
